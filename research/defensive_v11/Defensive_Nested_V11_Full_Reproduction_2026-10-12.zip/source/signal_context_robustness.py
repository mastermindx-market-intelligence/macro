"""Descriptive robustness of the fixed V11 crossover-context comparison.
No strategy fitting or new price data. These are exploratory intervals, not
multiplicity-adjusted causal effects or prospective success probabilities.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parent;O=R/'results'

def run():
 d=pd.read_csv(O/'signal_state_events.csv');d['q']=pd.to_datetime(d.signal_date).dt.to_period('Q');d['year']=pd.to_datetime(d.signal_date).dt.year
 d['win']=(d.net>0).astype(float);d['target8_hit']=(d.target8=='TARGET').astype(float)
 qs=pd.period_range(d.q.min(),d.q.max(),freq='Q');nq=len(qs);B=4000;block=4
 rng=np.random.default_rng(611024);starts=rng.integers(0,nq,size=(B,int(np.ceil(nq/block))))
 sample=((starts[:,:,None]+np.arange(block))%nq).reshape(B,-1)[:,:nq]
 out=[];matched=[]
 for (panel,frame),g in d.groupby(['panel','frame']):
  joint=g[g.cell=='JOINT']
  for control in ['NEITHER','WEEKLY_ONLY','TWO_WEEK_ONLY']:
   other=g[g.cell==control]
   for metric in ['net','win','target8_hit']:
    a=joint.groupby('q')[metric].agg(['sum','count']).reindex(qs,fill_value=0)
    b=other.groupby('q')[metric].agg(['sum','count']).reindex(qs,fill_value=0)
    ac=a['count'].to_numpy()[sample].sum(axis=1);bc=b['count'].to_numpy()[sample].sum(axis=1);ok=(ac>0)&(bc>0)
    dist=a['sum'].to_numpy()[sample].sum(axis=1)[ok]/ac[ok]-b['sum'].to_numpy()[sample].sum(axis=1)[ok]/bc[ok]
    ys=[]
    for year in sorted(g.year.unique()):
     x=joint[joint.year!=year][metric];z=other[other.year!=year][metric]
     if len(x) and len(z):ys.append(float(x.mean()-z.mean()))
    eligible=joint.q.nunique()>=8 and other.q.nunique()>=8
    out.append({'panel':panel,'frame':frame,'control':control,'metric':metric,'joint_n':len(joint),'control_n':len(other),'joint_quarters':joint.q.nunique(),'control_quarters':other.q.nunique(),'difference':joint[metric].mean()-other[metric].mean(),'block_ci_low':float(np.quantile(dist,.025)) if eligible else np.nan,'block_ci_high':float(np.quantile(dist,.975)) if eligible else np.nan,'leave_year_out_min':min(ys),'leave_year_out_max':max(ys),'interval_eligible':eligible})
   # Equal-weight stock-year differences, with both cells present. No imputation.
   a=joint.groupby(['symbol','year']).agg(n=('net','size'),mean=('net','mean'),win=('win','mean'),hit=('target8_hit','mean'))
   b=other.groupby(['symbol','year']).agg(n=('net','size'),mean=('net','mean'),win=('win','mean'),hit=('target8_hit','mean'))
   x=a.join(b,how='inner',lsuffix='_joint',rsuffix='_control')
   matched.append({'panel':panel,'frame':frame,'control':control,'matched_stock_years':len(x),'joint_events_covered':int(x.n_joint.sum()),'control_events_covered':int(x.n_control.sum()),'equal_stratum_return_difference':float((x.mean_joint-x.mean_control).mean()),'equal_stratum_win_difference':float((x.win_joint-x.win_control).mean()),'equal_stratum_target8_difference':float((x.hit_joint-x.hit_control).mean())})
 pd.DataFrame(out).to_csv(O/'signal_context_block_audit.csv',index=False)
 pd.DataFrame(matched).to_csv(O/'signal_context_matched_audit.csv',index=False)
 meta={'status':'exploratory, no adjusted hypothesis-test acceptance','comparisons':len(out),'replicates':B,'block_calendar_quarters':block,'sampled_calendar_quarters':len(qs),'shared_time_clusters':'all stocks in a sampled quarter remain together','missing_group_bootstraps':'excluded rather than zero-filled','matched_design':'equal weight stock-year strata that contain both cells; selected coverage disclosed, not point-in-time forecast'}
 (O/'signal_context_inference.json').write_text(json.dumps(meta,indent=2))
 print('CORE_DAILY_BLOCK',pd.DataFrame(out).query("panel=='CORE5' and frame=='1D' and control=='NEITHER'").round(6).to_json(orient='records'))
 print('MATCHED_CORE',pd.DataFrame(matched).query("panel=='CORE5' and frame=='1D'").round(6).to_json(orient='records'))
 print('PEER_DAILY_BLOCK',pd.DataFrame(out).query("panel=='PEERS13' and frame=='1D' and control=='NEITHER'").round(6).to_json(orient='records'))
if __name__=='__main__':run()
