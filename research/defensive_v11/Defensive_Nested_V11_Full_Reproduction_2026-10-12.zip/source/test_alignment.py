import unittest
import numpy as np
from alignment import decision
class AlignmentTests(unittest.TestCase):
 def test_prior_cross_enters_after_arm_not_retroactively(self):
  bull=np.zeros(20,bool);bull[4]=True;hist=np.ones(20)
  self.assertEqual(decision(6,15,bull,hist,5),(6,4,'RECENT_BULL_IN_FORCE'))
 def test_stale_state_requires_new_cross(self):
  bull=np.zeros(20,bool);bull[[0,12]]=True;hist=np.ones(20)
  self.assertEqual(decision(8,15,bull,hist,5),(12,12,'FRESH_AFTER_ARM'))
 def test_failed_state_not_admitted(self):
  bull=np.zeros(20,bool);bull[[4,12]]=True;hist=-np.ones(20)
  self.assertEqual(decision(6,15,bull,hist,5),(12,12,'FRESH_AFTER_ARM'))
 def test_no_cross_stays_skipped(self):
  self.assertEqual(decision(6,15,np.zeros(20,bool),np.ones(20),5),(None,None,'NO_CONFIRMATION'))
if __name__=='__main__':unittest.main(verbosity=2)
