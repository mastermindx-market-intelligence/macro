import unittest
import numpy as np
import pandas as pd
import signal_context as s

class SignalContextTests(unittest.TestCase):
 def test_disjoint_cells_and_unknown(self):
  ix=pd.RangeIndex(5)
  w=pd.DataFrame({'count':[201]*4+[199],'recent3':[10,10,60,60,10],'k':[10]*5},index=ix)
  b=pd.DataFrame({'count':[201]*5,'recent2':[10,50,10,50,10],'k':[10]*5},index=ix)
  self.assertEqual(s.cells(w,b).tolist(),['JOINT','WEEKLY_ONLY','TWO_WEEK_ONLY','NEITHER','UNKNOWN'])
 def test_flat_or_unknown_not_neither(self):
  w=pd.DataFrame({'count':[201],'recent3':[np.nan],'k':[np.nan]})
  b=pd.DataFrame({'count':[201],'recent2':[50.],'k':[50.]})
  self.assertEqual(s.cells(w,b).iloc[0],'UNKNOWN')
 def test_nonoverlap_selected_without_returns(self):
  self.assertEqual(s.nonoverlap([0,12,125,126,200,252],126),[0,126,252])
 def test_open_target_before_later_low(self):
  self.assertEqual(s.barrier(np.array([[109,110,90,101]]),100,.08,.05),'TARGET')
 def test_ambiguous_samebar_conservative(self):
  self.assertEqual(s.barrier(np.array([[100,110,90,101]]),100,.08,.05),'STOP')
 def test_timeout_not_loss(self):
  self.assertEqual(s.barrier(np.array([[100,102,99,101]]),100,.08,.05),'TIMEOUT')
 def test_closed_fraction_unknown_empty(self):
  self.assertTrue(np.isnan(s.safe_mean([])))
if __name__=='__main__':unittest.main(verbosity=2)
