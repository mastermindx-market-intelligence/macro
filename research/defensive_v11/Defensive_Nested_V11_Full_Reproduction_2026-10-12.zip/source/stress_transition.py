"""Fixed V11 new-stress transition audit. Research events, not portfolio weights.
No acquisition or tuned conditions. All path data come from admitted V11 caches.
"""
from pathlib import Path
import numpy as np
import pandas as pd
import empirical as e
R=Path(__file__).resolve().parent;O=R/'results'

def simulate(path,states,prior_state,atr,react=False,stop_multiple=None,fee=.0005):
 path=np.asarray(path,float)
 if len(path)==0 or len(path)!=len(states) or atr<=0:raise ValueError('Invalid input')
 entry=path[0,0];stop=entry-stop_multiple*atr if stop_multiple is not None else -np.inf
 low=entry;high=entry;pending=False;prev=prior_state;reason='COMMON_END';price=path[-1,3];ex=len(path)-1
 for i,(op,h,l,c) in enumerate(path):
  low=min(low,op);high=max(high,op)
  if op<=stop:price=op;reason='STOP_GAP';ex=i;break
  if pending:price=op;reason='NEW_STRESS';ex=i;break
  if l<=stop:
   price=stop;low=min(low,stop);reason='STOP_INTRADAY';ex=i;break
  # On a stopped day high-before-stop order is unknown, so no fictitious MFE.
  low=min(low,l);high=max(high,h)
  pending=bool(react and states[i]=='STRESS_WORSENING' and prev!='STRESS_WORSENING')
  prev=states[i]
 return dict(net=float(price/entry*(1-fee)/(1+fee)-1),exit_i=ex,exit_price=float(price),reason=reason,mae=float(low/entry-1),mfe=float(high/entry-1),sessions=ex+1)

def main():
 p=pd.read_csv(O/'primary_labeled_events.csv');p=p[(p['mode']=='confirmed')&(p.horizon==126)&(p.status=='FILLED')&p.frame.isin(['1D','2D'])].copy();rows=[]
 for sym,g in p.groupby('symbol'):
  cache=pd.read_pickle(O/f'{sym}_cache.pkl');d=cache['daily'];reg=cache['regime'].market_regime
  tr=pd.concat([d.high-d.low,(d.high-d.close.shift()).abs(),(d.low-d.close.shift()).abs()],axis=1).max(axis=1);atr=e.original.rma(tr,14)
  for event in g.itertuples():
   sig=int(d.index.get_indexer([pd.Timestamp(event.signal_date)])[0]);j=sig+1;end=int(d.index.get_indexer([pd.Timestamp(event.exit_date)])[0]);path=d.iloc[j:end+1][['open','high','low','close']].to_numpy(float)
   for react in [False,True]:
    for multiple in [None,3]:
     x=simulate(path,reg.iloc[j:end+1].tolist(),reg.iloc[sig],float(atr.iloc[sig]),react,multiple)
     if not react and multiple is None:assert abs(x['net']-event.net)<1e-10
     rows.append(dict(symbol=sym,panel=event.panel,frame=event.frame,episode=event.episode,entry_date=event.entry_date,signal_date=event.signal_date,common_end=event.exit_date,real_exit=str(d.index[j+x['exit_i']].date()),market_transition_exit=react,stop='NONE' if multiple is None else '3ATR',baseline_net=event.net,incremental=x['net']-event.net,**x))
 z=pd.DataFrame(rows);z.to_csv(O/'stress_transition_events.csv',index=False)
 z['positive']=z.net>0;z['stress_exit']=z.reason=='NEW_STRESS';z['stop_exit']=z.reason.str.startswith('STOP');z['era']=np.where(pd.to_datetime(z.signal_date)<pd.Timestamp('2023-01-01'),'2018_2022','2023_2026')
 def summary(keys):return z.groupby(keys).agg(n=('net','size'),win=('positive','mean'),mean=('net','mean'),median=('net','median'),incremental=('incremental','mean'),mae=('mae','mean'),worst_mae=('mae','min'),mean_sessions=('sessions','mean'),stress_exits=('stress_exit','sum'),stop_exits=('stop_exit','sum')).reset_index()
 summary(['panel','frame','market_transition_exit','stop']).to_csv(O/'stress_transition_summary.csv',index=False)
 summary(['symbol','frame','market_transition_exit','stop']).to_csv(O/'stress_transition_by_stock.csv',index=False)
 summary(['panel','frame','era','market_transition_exit','stop']).to_csv(O/'stress_transition_era.csv',index=False)
 print('CORE_DAILY',summary(['panel','frame','market_transition_exit','stop']).query("panel=='CORE5' and frame=='1D'").round(5).to_json(orient='records'))
 print('PEERS_DAILY',summary(['panel','frame','market_transition_exit','stop']).query("panel=='PEERS13' and frame=='1D'").round(5).to_json(orient='records'))
 print('ROWS',len(z),'same admitted entries; only event paths, not an investable portfolio.')
if __name__=='__main__':main()
