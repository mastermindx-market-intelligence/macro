import unittest
import numpy as np
import pandas as pd
from management import replay

class CycleManagementTests(unittest.TestCase):
 def data(self):
  ix=pd.bdate_range('2020-01-02',periods=9);d=pd.DataFrame({'open':100.,'high':101.,'low':99.,'close':100.},index=ix)
  f=pd.DataFrame({'episode':1,'bull':False,'bear':False,'weekly_bear':False,'two_week_k':10.,'two_week_fresh':False,'atr':1.,'weekly_k':10.,'weekly_fresh':False,'weekly_stoch_bear':False},index=ix)
  f.loc[ix[0],'bull']=True;return d,f
 def test_fresh_weekly_upper_then_rollover(self):
  d,f=self.data();f.loc[f.index[2],['weekly_k','weekly_fresh']]=[90,True];f.loc[f.index[4],'weekly_stoch_bear']=True
  x=replay(d,f,'weekly_stoch',None,1);self.assertEqual(x['trades'].iloc[0].exit_date,d.index[5]);self.assertEqual(x['trades'].iloc[0].reason,'WEEKLY_STOCH_ROLLOVER')
 def test_stale_upper_does_not_arm(self):
  d,f=self.data();f['weekly_k']=90;f.loc[f.index[4],'weekly_stoch_bear']=True
  self.assertEqual(len(replay(d,f,'weekly_stoch',None,1)['trades']),0)
 def test_preentry_upper_does_not_arm(self):
  d,f=self.data();f.loc[f.index[0],['weekly_k','weekly_fresh']]=[90,True];f.loc[f.index[4],'weekly_stoch_bear']=True
  self.assertEqual(len(replay(d,f,'weekly_stoch',None,1)['trades']),0)
 def test_losing_lower_cross_cuts_failed_attempt_next_open(self):
  d,f=self.data();d.loc[d.index[2],'close']=98.5;d.loc[d.index[2],'low']=98.;f.loc[f.index[2],'bear']=True
  x=replay(d,f,'repair_failure',None,1);self.assertEqual(x['trades'].iloc[0].exit_date,d.index[3]);self.assertEqual(x['trades'].iloc[0].reason,'FAILED_RECOVERY')
 def test_profitable_lower_cross_is_not_exit(self):
  d,f=self.data();d.loc[d.index[2],['close','high']]=[105.,106.];f.loc[f.index[2],'bear']=True
  self.assertEqual(len(replay(d,f,'repair_failure',None,1)['trades']),0)
 def test_existing_weekly_rule_unchanged(self):
  d,f=self.data();f.loc[f.index[2],'weekly_bear']=True
  a=replay(d,f,'weekly',3,1);b=replay(d,f.drop(columns=['weekly_k','weekly_fresh','weekly_stoch_bear']),'weekly',3,1)
  pd.testing.assert_frame_equal(a['trades'],b['trades']);pd.testing.assert_frame_equal(a['equity'],b['equity'])
if __name__=='__main__':unittest.main(verbosity=2)
