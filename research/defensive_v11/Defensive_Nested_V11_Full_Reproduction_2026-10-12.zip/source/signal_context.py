"""V11 state-at-crossover attribution. New descriptive study, not a fitted gate.
Reads only existing V11 native frames and emits derived observations.
"""
from pathlib import Path
import json,math
import numpy as np
import pandas as pd
import empirical as e
R=Path(__file__).resolve().parent;O=R/'results'

def cells(w,b):
 known=(w['count']>=200)&(b['count']>=200)&w.k.notna()&b.k.notna()&w.recent3.notna()&b.recent2.notna()
 a=w.recent3.le(20);z=b.recent2.le(20)&b.k.lt(60)
 return pd.Series(np.where(~known,'UNKNOWN',np.where(a&z,'JOINT',np.where(a,'WEEKLY_ONLY',np.where(z,'TWO_WEEK_ONLY','NEITHER')))),index=w.index)

def nonoverlap(indices,h):
 out=[];last=-10**9
 for i in indices:
  if i-last>=h:out.append(int(i));last=int(i)
 return out

def safe_mean(x):return float(np.mean(x)) if len(x) else np.nan

def barrier(path,entry,target,stop):
 hi=entry*(1+target);lo=entry*(1-stop)
 for o,h,l,c in path:
  if o<=lo:return 'STOP'
  if o>=hi:return 'TARGET'
  if l<=lo:return 'STOP'
  if h>=hi:return 'TARGET'
 return 'TIMEOUT'

def summarize(g):
 return {'n':len(g),'positive':int((g.net>0).sum()),'win':safe_mean(g.net>0),'mean':safe_mean(g.net),'median':float(g.net.median()) if len(g) else np.nan,'mae':safe_mean(g.mae),'mfe':safe_mean(g.mfe),'target8_first':safe_mean(g.target8=='TARGET'),'stop5_before8':safe_mean(g.target8=='STOP'),'target15_first':safe_mean(g.target15=='TARGET'),'calendar_quarters':int(pd.to_datetime(g.signal_date).dt.to_period('Q').nunique())}

def run():
 rows=[]
 for sym in e.STOCKS:
  c=pd.read_pickle(O/f'{sym}_cache.pkl');d=c['daily'];ix=d.index;w=c['slow']['confirmed_W'];b=c['slow']['confirmed_2W_0'];state=cells(w,b);market=c['regime']
  for frame in ['1D','2D']:
   lo=c['lower'][frame+'_0'];hits=np.flatnonzero(lo.bull.to_numpy(bool)&(state!='UNKNOWN').to_numpy()&(ix>=pd.Timestamp('2018-01-01')))
   eligible=[int(i) for i in hits if i+126<len(d)];separated=set(nonoverlap(eligible,126))
   for i in eligible:
    j=i+1;end=i+126;entry=float(d.open.iloc[j]);path=d.iloc[j:end+1];p=path[['open','high','low','close']].to_numpy(float)
    rows.append({'symbol':sym,'panel':'CORE5' if sym in e.CORE else 'PEERS13','frame':frame,'signal_date':str(ix[i].date()),'entry_date':str(ix[j].date()),'exit_date':str(ix[end].date()),'cell':state.iloc[i],'market_regime':market.market_regime.iloc[i],'net':float(d.close.iloc[end]/entry*.9995/1.0005-1),'mae':float(path.low.min()/entry-1),'mfe':float(path.high.max()/entry-1),'target8':barrier(p,entry,.08,.05),'target15':barrier(p,entry,.15,.05),'spaced_before_outcomes':i in separated})
 df=pd.DataFrame(rows);df.to_csv(O/'signal_state_events.csv',index=False)
 out=[]
 for sample,g in [('ALL_CROSSES_OVERLAPPING',df),('SPACED126_BEFORE_OUTCOMES',df[df.spaced_before_outcomes])]:
  for keys,s in g.groupby(['panel','frame','cell']):out.append(dict(zip(['panel','frame','cell'],keys))|{'sample':sample}|summarize(s))
  for keys,s in g.groupby(['panel','frame']):out.append(dict(zip(['panel','frame'],keys))|{'cell':'ALL','sample':sample}|summarize(s))
 summ=pd.DataFrame(out);summ.to_csv(O/'signal_state_summary.csv',index=False)
 per=[]
 for keys,g in df.groupby(['symbol','frame','cell']):per.append(dict(zip(['symbol','frame','cell'],keys))|summarize(g))
 pd.DataFrame(per).to_csv(O/'signal_state_by_stock.csv',index=False)
 print('CORE_DAILY',summ[(summ.panel=='CORE5')&(summ.frame=='1D')].round(5).to_json(orient='records'))
 print('PEER_DAILY',summ[(summ.panel=='PEERS13')&(summ.frame=='1D')&(summ['sample']=='ALL_CROSSES_OVERLAPPING')].round(5).to_json(orient='records'))
 print('EVENTS',len(df),'CAUTION state-at-cross differs from persistent master-watch entry; no alpha or causal gate accepted.')

if __name__=='__main__':run()
