import unittest,tempfile
from pathlib import Path
import run_events as r
class AggregationTests(unittest.TestCase):
 def test_aggregate_cannot_be_its_own_input(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)
   for n in ['MCD_episode_results.csv','WM_episode_results.csv','all_episode_results.csv']:(p/n).touch()
   self.assertEqual([x.name for x in r.input_files(p)],['MCD_episode_results.csv','WM_episode_results.csv'])
if __name__=='__main__':unittest.main()
