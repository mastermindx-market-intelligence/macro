"""Frozen V11 paired empirical episodes; all price inputs are original V1."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import json,hashlib,sys
import numpy as np
import pandas as pd
import empirical as e
R=Path(__file__).resolve().parent
OUT=R/'results'

def stock_study(sym):
    fs,cal=e.load_inputs();d=fs[sym];reg=e.regimes(fs['SPY']);rows=[];watches=[];checks=[]
    start=int(d.index.searchsorted('2018-01-01'))
    daily=e.snapshots(d.close,cal,'1D');short=daily.k.rolling(5,min_periods=1).min().le(20)&daily.k.notna()
    s200=d.close.rolling(200).mean();s50=d.close.rolling(50).mean();trend=(d.close>s200)&(s50>s50.shift(20))
    lowercache={'1D_0':daily};slowcache={}
    core=sym in e.CORE
    phases=[0,1] if core else [0]
    for mode in ['confirmed','developing']:
      w=e.snapshots(d.close,cal,'1W',mode);slowcache[mode+'_W']=w
      for p in phases:
        b=e.snapshots(d.close,cal,'2W',mode,p);slowcache[f'{mode}_2W_{p}']=b
        for warm in ([200,120] if core and p==0 else [200]):
          st=start if warm==200 else int(d.index.searchsorted('2015-01-01'))
          ready=(w['count']>=warm)&(b['count']>=warm)
          ctx=(ready&w.recent3.le(20)&b.recent2.le(20)&w.k.notna()&b.k.notna()).to_numpy(bool)
          frames=['1D','2D','3D','1W'] if core and p==0 and warm==200 else ['1D','2D']
          for frame in frames:
            lowerphases=[0,1] if core and frame=='2D' and p==0 and warm==200 else [0]
            for lp in lowerphases:
              key=f'{frame}_{lp}'
              if key not in lowercache:lowercache[key]=e.snapshots(d.close,cal,frame,'confirmed',lp)
              low=lowercache[key];ep=e.episodes(ctx,b.k.to_numpy(float),low.bull.to_numpy(bool),start_i=st)
              tag={'symbol':sym,'mode':mode,'two_week_phase':p,'frame':frame,'lower_phase':lp,'warmup':warm}
              for z in ep:
                a=z['arm_i'];t=z['signal_i'];r=reg.iloc[a]
                detail={**tag,**z,'arm_date':str(d.index[a].date()),'signal_date':str(d.index[t].date()) if t is not None else None,'regime_arm':r.market_regime,'stock_trend_arm':bool(trend.iloc[a]),'weekly_k_arm':float(w.k.iloc[a]),'two_week_k_arm':float(b.k.iloc[a]),'weekly_hist_improving_arm':bool(w.change.iloc[a]>0),'deep_2w_arm':bool(b.deep.iloc[a]),'market_ret10_arm':float(r.market_ret10),'market_dd_arm':float(r.market_drawdown)}
                watches.append(detail)
                for horizon in [63,126,252]:
                  base=e.event_outcome(d,a,t,horizon)
                  main={**tag,'episode':z['episode'],'regime_arm':r.market_regime,'stock_trend_arm':bool(trend.iloc[a]),'weekly_repair_arm':bool(w.change.iloc[a]>0),'deep_2w_arm':bool(b.deep.iloc[a]),**base}
                  if t is not None:
                    main.update(short_washout_at_signal=bool(short.iloc[t]),weekly_repair_at_signal=bool(w.change.iloc[t]>0),regime_signal=str(reg.market_regime.iloc[t]),two_week_k_signal=float(b.k.iloc[t]),lower_macd_signal=float(low.macd.iloc[t]),lower_rsi_signal=float(low.rsi.iloc[t]))
                    # Same entry, entry-anchored horizon: different estimand from arm-anchored.
                    if t+horizon<len(d):main['entry_horizon_net']=float(d.close.iloc[t+horizon]/d.open.iloc[t+1]*.9995/1.0005-1)
                    if main.get('status')=='FILLED':
                      spy=fs['SPY'];j=t+1;end=a+horizon
                      main['spy_excess']=float(main['net']-(spy.close.iloc[end]/spy.open.iloc[j]*.9995/1.0005-1))
                  rows.append(main)
    # Verify native indicator equality on the actual daily input and prefix invariance
    # of one closed/developing two-week slice (not another strategy performance run).
    bch=e.batch(d.close)
    errors={c:float(np.nanmax(np.abs(daily[c]-bch[c]))) for c in ['rsi','macd','signal','hist','k','d']}
    assert max(errors.values())<1e-9
    cut=3501
    for mode in ['confirmed','developing']:
      part=e.snapshots(d.close.iloc[:cut],cal,'2W',mode,0);full=slowcache[f'{mode}_2W_0'].iloc[:cut]
      pd.testing.assert_frame_equal(part,full)
    checks.append({'symbol':sym,'daily_rows':len(d),'native_daily_batch_max_error':max(errors.values()),'actual_prefix_checks':2})
    pd.DataFrame(rows).to_csv(OUT/f'{sym}_episode_results.csv',index=False)
    pd.DataFrame(watches).to_csv(OUT/f'{sym}_watches.csv',index=False)
    # Cache only our own newly computed frames to avoid needless recomputation.
    pd.to_pickle({'daily':d,'calendar':cal,'lower':lowercache,'slow':slowcache,'regime':reg},OUT/f'{sym}_cache.pkl')
    (OUT/f'{sym}_checks.json').write_text(json.dumps(checks,indent=2))
    return {'symbol':sym,'scenario_rows':len(rows),'watch_scenario_rows':len(watches),'primary_watch_n':sum(x['mode']=='confirmed' and x['frame']=='1D' and x['warmup']==200 and x['two_week_phase']==0 and x['lower_phase']==0 for x in watches)}

def summary(df,keys):
    output=[]
    for key,g in df.groupby(keys,dropna=False):
      key=key if isinstance(key,tuple) else (key,);v=dict(zip(keys,key));complete=g[g.status!='INCOMPLETE'];filled=complete[complete.status=='FILLED']
      v.update(watches=len(g),complete=len(complete),filled=len(filled),skipped=int((complete.status=='SKIPPED').sum()),incomplete=int((g.status=='INCOMPLETE').sum()))
      for out,col,sub in [('mean_trade','net',filled),('median_trade','net',filled),('mean_watch_policy','net',complete),('mean_immediate','baseline',complete),('incremental','incremental',complete),('entry_delay','delay',filled),('mae','mae',filled),('mfe','mfe',filled),('entry_horizon_mean','entry_horizon_net',filled),('spy_excess','spy_excess',filled)]:
        v[out]=float(sub[col].median() if out=='median_trade' else sub[col].mean()) if len(sub) and col in sub else None
      v['win']=float((filled.net>0).mean()) if len(filled) else None
      output.append(v)
    return pd.DataFrame(output)

def input_files(root):
    return sorted(root/f'{s}_episode_results.csv' for s in e.STOCKS if (root/f'{s}_episode_results.csv').exists())

def collect():
    files=input_files(OUT)
    df=pd.concat([pd.read_csv(p) for p in files],ignore_index=True)
    keys=['symbol','mode','two_week_phase','frame','lower_phase','warmup','horizon','episode']
    assert not df.duplicated(keys).any(), 'Duplicate scenario identities'
    df.to_csv(OUT/'all_episode_results.csv',index=False)
    summ=summary(df,['symbol','mode','two_week_phase','frame','lower_phase','warmup','horizon']);summ.to_csv(OUT/'all_episode_summary.csv',index=False)
    primary=df[(df.two_week_phase==0)&(df.lower_phase==0)&(df.warmup==200)&df.frame.isin(['1D','2D'])]
    summary(primary,['mode','frame','horizon','regime_arm']).to_csv(OUT/'market_regime_summary.csv',index=False)
    summary(primary,['symbol','mode','frame','horizon','stock_trend_arm']).to_csv(OUT/'stock_trend_summary.csv',index=False)
    core=summ[summ.symbol.isin(e.CORE)&(summ.two_week_phase==0)&(summ.lower_phase==0)&(summ.warmup==200)&(summ.horizon==126)&summ.frame.isin(['1D','2D'])]
    print('CORE_126_PAIRED',core[['symbol','mode','frame','watches','complete','filled','win','mean_trade','mean_immediate','mean_watch_policy','incremental','entry_delay','mae','mfe']].round(5).to_json(orient='records'),flush=True)
    print('RESEARCH_ONLY total_scenario_rows',len(df),'stocks',df.symbol.nunique(),flush=True)

if __name__=='__main__':
    symbols=sys.argv[1:] or e.CORE
    if symbols==['collect']:collect()
    else:
      with ProcessPoolExecutor(max_workers=3) as ex:
        for f in as_completed([ex.submit(stock_study,s) for s in symbols]):print(json.dumps(f.result()),flush=True)
      collect()
