"""V11 small semantic sensitivity, not a tuned or validated trading gate.
Distinguishes recent short StochRSI floor from a bullish short cross still in
force; the original long watch and first RSI-MACD crossover remain fixed.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import empirical as e
from run_events import summary
from signal_context import cells
R=Path(__file__).resolve().parent;O=R/'results'

def stoch_in_force(d,window=8):
 cross=(d.k>d.d)&(d.k.shift()<=d.d.shift())
 return cross.rolling(window+1,min_periods=1).max().eq(1)&d.k.ge(d.d)&d.k.rolling(window+1,min_periods=1).min().le(20)&d.k.notna()&d.d.notna()

def run():
 out=[];allrows=[];horizon=[];regime=[]
 for sym in e.CORE:
  c=pd.read_pickle(O/f'{sym}_cache.pkl');daily=c['lower']['1D_0'];w=c['slow']['confirmed_W'];b=c['slow']['confirmed_2W_0'];joint=cells(w,b).eq('JOINT');inforce=stoch_in_force(daily,8)
  ep=pd.read_csv(O/f'{sym}_episode_results.csv');ep=ep[(ep['mode']=='confirmed')&(ep.two_week_phase==0)&(ep.lower_phase==0)&(ep.warmup==200)&ep.frame.isin(['1D','2D'])]
  # Fixed original episodes with the longest horizon available; same cohorts for every horizon.
  mature=ep[(ep.horizon==252)&(ep.status!='INCOMPLETE')][['frame','episode']]
  cohort=ep.merge(mature,on=['frame','episode'],how='inner');horizon.append(cohort)
  for name,condition in [('short_stoch_bull_in_force8',inforce),('joint_context_still_present',joint)]:
   g=ep[ep.horizon==126].copy();dates=pd.to_datetime(g.signal_date);keep=condition.reindex(dates).fillna(False).to_numpy(bool)
   reject=(g.status=='FILLED').to_numpy()&~keep
   g.loc[reject,'status']='SKIPPED';g.loc[reject,'net']=0.;g.loc[reject,'incremental']=-g.loc[reject,'baseline']
   g['gate']=name;allrows.append(g);sm=summary(g,['symbol','frame','horizon']);sm['gate']=name;out.append(sm)
  print('SEMANTIC_GATE',sym,flush=True)
 pd.concat(out).to_csv(O/'semantic_gate_summary.csv',index=False)
 pd.concat(allrows).to_csv(O/'semantic_gate_events.csv',index=False)
 summary(pd.concat(horizon),['symbol','frame','horizon']).to_csv(O/'common_mature_horizon_summary.csv',index=False)
 # Entry-time (not arm-time) regime summaries on the same primary candidates.
 p=pd.read_csv(O/'primary_labeled_events.csv');p=p[(p.panel=='CORE5')&(p['mode']=='confirmed')&(p.frame=='1D')&(p.horizon==126)&(p.status=='FILLED')]
 for col in ['regime_signal','rates_signal']:
  x=summary(p,[col]);x=x.rename(columns={col:'regime'});x['basis']=col
  for i,row in x.iterrows():
   g=p[p[col]==row.regime]
   x.loc[i,'unique_arm_dates']=pd.to_datetime(g.arm_date).nunique();x.loc[i,'arm_quarters']=pd.to_datetime(g.arm_date).dt.to_period('Q').nunique()
  regime.append(x)
 pd.concat(regime).to_csv(O/'entry_regime_summary.csv',index=False)
 # Preserve known dates on immature events WITHOUT assigning performance.
 original=pd.read_csv(O/'primary_labeled_events.csv');core=original[original.symbol.isin(e.CORE)&(original['mode']=='confirmed')&original.frame.isin(['1D','2D'])&(original.horizon==126)].copy()
 for sym in e.CORE:
  c=pd.read_pickle(O/f'{sym}_cache.pkl');ix=c['daily'].index
  watches=pd.read_csv(O/f'{sym}_watches.csv');watches=watches[(watches['mode']=='confirmed')&(watches.two_week_phase==0)&(watches.lower_phase==0)&(watches.warmup==200)&watches.frame.isin(['1D','2D'])]
  for row in watches.itertuples():
   if pd.notna(row.signal_i):
    mask=(core.symbol==sym)&(core.frame==row.frame)&(core.episode==row.episode);i=int(row.signal_i)
    core.loc[mask,'signal_date']=str(ix[i].date())
    if i+1<len(ix):core.loc[mask,'entry_date']=str(ix[i+1].date())
 core.to_csv(O/'core_episode_ledger_complete_metadata.csv',index=False)
 (R/'semantic_gate_spec.json').write_text(json.dumps({'status':'exploratory after V11 review, no parameter optimization','short_stoch':'K crosses above D within8 prior daily bars, K>=D now, K touched20 within8 prior bars; no requirement K<=20 on trigger','joint_at_signal':'same fixed first RSI-MACD cross passes only if both recent slow washouts still present; rejected remains cash','common_horizons':'same set of original episodes with252 complete arm sessions; compare63/126/252, not selected by future return','entry_regimes':'descriptive labels at first crossover, not retrospectively assigned final regime','immature_metadata':'known signal/entry retained, outcome remains unknown'},indent=2))
 print('SEMANTIC_SUMMARY',pd.concat(out)[['symbol','frame','gate','complete','filled','win','mean_trade','incremental']].round(5).to_json(orient='records'),flush=True)
if __name__=='__main__':run()
