"""Supplemental timing comparison: recent lower cross may predate known slow context.
The order never precedes the long-context arm; data inputs and master episodes
remain frozen. No network, orders, optimization or production writes.
"""
from pathlib import Path
import numpy as np
import pandas as pd
import empirical as e
from run_events import summary
from management import make_features,replay
R=Path(__file__).resolve().parent;O=R/'results'

def decision(arm,end,bull,hist,lookback=5):
    prior=np.flatnonzero(bull[max(0,arm-lookback):arm+1])
    if np.isfinite(hist[arm]) and hist[arm]>0 and len(prior):
        cross=max(0,arm-lookback)+int(prior[-1])
        return arm,cross,'RECENT_BULL_IN_FORCE'
    after=np.flatnonzero(bull[arm:end])
    if len(after):
        cross=arm+int(after[0]);return cross,cross,'FRESH_AFTER_ARM'
    return None,None,'NO_CONFIRMATION'

def aligned_features(cache,mode,frame,lookback=5):
    d,f=make_features(cache,mode,frame);full=cache['daily'];lo=cache['lower'][frame+'_0']
    wf=pd.read_csv(O/f"{cache.get('symbol','')}_watches.csv") if 'symbol' in cache else None
    # Read master ids created by the same frozen watch builder, not a new detector.
    starts=f[(f.episode>0)&f.episode.ne(f.episode.shift(fill_value=0))]
    ff=f.copy();nchanged=0
    for date,row in starts.iterrows():
        a=int(full.index.get_indexer([date])[0]);recent=np.flatnonzero(lo.bull.iloc[max(0,a-lookback):a+1].to_numpy(bool))
        if len(recent) and lo['hist'].iloc[a]>0:
            if not ff.loc[date,'bull']:nchanged+=1
            ff.loc[date,'bull']=True
    return d,ff,nchanged

def run():
    events=[];sums=[];trades=[]
    for sym in e.STOCKS:
      cache=pd.read_pickle(O/f'{sym}_cache.pkl');d=cache['daily'];reg=cache['regime']
      w=pd.read_csv(O/f'{sym}_watches.csv');w=w[(w.warmup==200)&(w.two_week_phase==0)&(w.lower_phase==0)&w.frame.isin(['1D','2D'])]
      for mode in ['confirmed','developing']:
        for frame in ['1D','2D']:
          low=cache['lower'][frame+'_0'];bull=low.bull.to_numpy(bool);hist=low['hist'].to_numpy(float)
          ww=w[(w['mode']==mode)&(w.frame==frame)]
          for z in ww.itertuples():
            a=int(z.arm_i);end=int(z.end_i);old=int(z.signal_i) if pd.notna(z.signal_i) else None
            t,actual,reason=decision(a,end,bull,hist,5)
            for horizon in [63,126,252]:
              before=e.event_outcome(d,a,old,horizon);after=e.event_outcome(d,a,t,horizon)
              row={'symbol':sym,'mode':mode,'frame':frame,'episode':z.episode,'rule':'recent5_or_fresh','arm_date':str(d.index[a].date()),'indicator_cross_date':str(d.index[actual].date()) if actual is not None else None,'confirmation_type':reason,'regime_arm':z.regime_arm,'stock_trend_arm':z.stock_trend_arm,**after}
              if before['status']!='INCOMPLETE':row.update(fresh_rule_net=before['net'],alignment_delta=after['net']-before['net'],fresh_status=before['status'])
              if t is not None:
                row['regime_signal']=str(reg.market_regime.iloc[t])
                if t+horizon<len(d):row['entry_horizon_net']=float(d.close.iloc[t+horizon]/d.open.iloc[t+1]*.9995/1.0005-1)
              events.append(row)
          if sym in e.CORE:
            dd,ff,nchanged=aligned_features(cache,mode,frame)
            for rule in ['lower','weekly','cycle']:
              x=replay(dd,ff,rule,3,1,10)
              tag={'symbol':sym,'mode':mode,'frame':frame,'exit_rule':rule,'entry_rule':'recent5_or_fresh','atr_multiple':3,'attempts':1,'additional_arm_signals':nchanged}
              sums.append({**tag,**x['summary']})
              if len(x['trades']):trades.append(x['trades'].assign(**tag))
    ev=pd.DataFrame(events);ev.to_csv(O/'alignment_events.csv',index=False)
    sm=summary(ev,['symbol','mode','frame','horizon'])
    extra=ev.groupby(['symbol','mode','frame','horizon'],dropna=False).agg(mean_delta_vs_fresh=('alignment_delta','mean'),recent_admissions=('confirmation_type',lambda x:int((x=='RECENT_BULL_IN_FORCE').sum()))).reset_index()
    sm=sm.merge(extra,on=['symbol','mode','frame','horizon']);sm.to_csv(O/'alignment_summary.csv',index=False)
    pd.DataFrame(sums).to_csv(O/'alignment_policy_summary.csv',index=False)
    pd.concat(trades,ignore_index=True).to_csv(O/'alignment_policy_trades.csv',index=False)
    s=sm[sm.symbol.isin(e.CORE)&(sm['mode']=='confirmed')&(sm.horizon==126)]
    print('CORE_ALIGNMENT',s[['symbol','frame','complete','filled','recent_admissions','win','mean_trade','incremental','entry_delay','mean_delta_vs_fresh']].round(5).to_json(orient='records'),flush=True)
    print('Alignment scenario rows',len(ev),'policy combinations',len(sums),flush=True)

if __name__=='__main__':run()
