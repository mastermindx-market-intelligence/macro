"""V11 source/species robustness and episode-path inspection; exploratory only."""
from pathlib import Path
import numpy as np
import pandas as pd
import empirical as e
from alignment import decision
from run_events import summary
R=Path(__file__).resolve().parent;O=R/'results'

def signal_prices(d,basis):
    if basis=='adjusted':return d.copy()
    if basis!='split_only':raise ValueError('Unknown price basis')
    x=d.copy()
    for c in ['open','high','low','close']:
        if c in x:x[c]=x[c]/x.factor
    return x

def run():
    out=[];paths=[]
    for sym in e.CORE:
      c=pd.read_pickle(O/f'{sym}_cache.pkl');d=c['daily'];cal=c['calendar'];start=int(d.index.searchsorted('2018-01-01'))
      variants=[('rsi_macd_12_26_9','adjusted',(12,26,9)),('split_only_signals','split_only',(14,60,5))]
      for variant,basis,lengths in variants:
       prices=signal_prices(d,basis)
       for mode in ['confirmed','developing']:
        if basis=='adjusted':w=c['slow'][mode+'_W'];b=c['slow'][mode+'_2W_0']
        else:w=e.snapshots(prices.close,cal,'1W',mode);b=e.snapshots(prices.close,cal,'2W',mode)
        ctx=((w['count']>=200)&(b['count']>=200)&w.recent3.le(20)&b.recent2.le(20)&w.k.notna()&b.k.notna()).to_numpy(bool)
        for frame in ['1D','2D']:
          lo=e.snapshots(prices.close,cal,frame,'confirmed',0,lengths);ep=e.episodes(ctx,b.k.to_numpy(float),lo.bull.to_numpy(bool),start_i=start)
          for z in ep:
            a=z['arm_i'];fresh=z['signal_i'];recent,_,_=decision(a,z['end_i'],lo.bull.to_numpy(bool),lo['hist'].to_numpy(float))
            for rule,t in [('first_fresh',fresh),('recent5_or_fresh',recent)]:
              for h in [63,126,252]:out.append({'symbol':sym,'variant':variant,'mode':mode,'frame':frame,'entry_rule':rule,'episode':z['episode'],**e.event_outcome(d,a,t,h)})
      primary=pd.read_csv(O/f'{sym}_episode_results.csv');primary=primary[(primary['mode']=='confirmed')&(primary.two_week_phase==0)&(primary.lower_phase==0)&(primary.warmup==200)&(primary.horizon==126)&primary.frame.isin(['1D','2D'])&(primary.status=='FILLED')]
      w=c['slow']['confirmed_W'];b=c['slow']['confirmed_2W_0']
      tr=pd.concat([d.high-d.low,(d.high-d.close.shift()).abs(),(d.low-d.close.shift()).abs()],axis=1).max(axis=1);atr=e.original.rma(tr,14)
      for row in primary.itertuples():
        i=int(d.index.get_indexer([pd.Timestamp(row.signal_date)])[0]);j=i+1;z=int(d.index.get_indexer([pd.Timestamp(row.exit_date)])[0]);p=float(d.open.iloc[j]);bars=d.iloc[j:z+1][['open','high','low','close']].to_numpy(float)
        t8=e.original.barrier(bars,p,p,.08,.05);t15=e.original.barrier(bars,p,p,.15,.05)
        draw=float(d.low.iloc[j:z+1].min()/p-1);a=float(atr.iloc[i]);maxpos=int(d.high.iloc[j:z+1].to_numpy().argmax())+j
        paths.append({'symbol':sym,'frame':row.frame,'episode':row.episode,'arm_date':row.arm_date,'signal_date':row.signal_date,'entry_date':row.entry_date,'exit_date':row.exit_date,'net':row.net,'mfe':row.mfe,'mae':row.mae,'mfe_date':str(d.index[maxpos].date()),'mfe_sessions_after_entry':maxpos-j,'three_atr_stop_pct':3*a/p,'three_atr_breached_in_window':bool(draw<=-3*a/p),'target8_before_stop5':int(t8),'target15_before_stop5':int(t15),'weekly_stoch_bull_at_signal':bool(w.k.iloc[i]>=w.d.iloc[i]),'two_week_stoch_bull_at_signal':bool(b.k.iloc[i]>=b.d.iloc[i]),'weekly_k':float(w.k.iloc[i]),'weekly_d':float(w.d.iloc[i]),'two_week_k':float(b.k.iloc[i]),'two_week_d':float(b.d.iloc[i]),'regime_signal':row.regime_signal})
      print('SOURCE_SENSITIVITY',sym,flush=True)
    x=pd.DataFrame(out);x.to_csv(O/'price_species_sensitivity_events.csv',index=False)
    s=summary(x,['symbol','variant','mode','frame','entry_rule','horizon']);s.to_csv(O/'price_species_sensitivity_summary.csv',index=False)
    q=pd.DataFrame(paths);q.to_csv(O/'core_path_audit.csv',index=False)
    p=[]
    for key,g in q.groupby(['symbol','frame']):
      p.append({'symbol':key[0],'frame':key[1],'n':len(g),'positive':int((g.net>0).sum()),'three_atr_breached':int(g.three_atr_breached_in_window.sum()),'positive_and_three_atr_breached':int(((g.net>0)&g.three_atr_breached_in_window).sum()),'target8_before_stop5':int((g.target8_before_stop5==1).sum()),'stop5_before_target8':int((g.target8_before_stop5==-1).sum()),'target15_before_stop5':int((g.target15_before_stop5==1).sum()),'median_mae':float(g.mae.median()),'median_mfe':float(g.mfe.median()),'median_three_atr_stop':float(g.three_atr_stop_pct.median())})
    pd.DataFrame(p).to_csv(O/'core_path_summary.csv',index=False)
    print('CORE_PRICE_SPECIES',s[(s['mode']=='confirmed')&(s.horizon==126)&(s.entry_rule=='first_fresh')][['symbol','variant','frame','filled','win','mean_trade','incremental']].round(5).to_json(orient='records'),flush=True)
    print('CORE_PATHS',pd.DataFrame(p).round(5).to_json(orient='records'),flush=True)

if __name__=='__main__':run()
