"""V11 exploratory effect-modification audit, fixed specifications, no orders.
Only existing original-input-derived V11 frames and lagged rates are consumed.
No fitting, parameter search, historical state revision or performance promotion.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import empirical as e
from regime_audit import macro_frame
R=Path(__file__).resolve().parent;O=R/'results'

def atr_race(path,entry,atr):
 if not np.isfinite(atr) or atr<=0:raise ValueError('Positive known ATR required')
 hi=entry+2*atr;lo=entry-1.5*atr
 for op,h,l,c in path:
  if op<=lo:return 'STOP'
  if op>=hi:return 'TARGET'
  if l<=lo:return 'STOP'
  if h>=hi:return 'TARGET'
 return 'TIMEOUT'

def matched(d,keys):
 a=d[d.cell=='JOINT'].groupby(keys).agg(n=('net','size'),mean=('net','mean'),hit=('hit','mean'))
 b=d[d.cell=='NEITHER'].groupby(keys).agg(n=('net','size'),mean=('net','mean'),hit=('hit','mean'))
 z=a.join(b,how='inner',lsuffix='_joint',rsuffix='_neither')
 return dict(strata=len(z),joint_covered=int(z.n_joint.sum()),control_covered=int(z.n_neither.sum()),net_difference=float((z.mean_joint-z.mean_neither).mean()),hit_difference=float((z.hit_joint-z.hit_neither).mean()))

def summarize(g,keys):
 return g.groupby(keys,dropna=False).agg(n=('net','size'),win=('positive','mean'),mean=('net','mean'),median=('net','median'),atr_target_first=('hit','mean'),atr_stop_first=('stop','mean'),mean_mae=('mae','mean'),mean_atr_pct=('atr_pct','mean'),quarters=('quarter','nunique')).reset_index()

def main():
 d=pd.read_csv(O/'signal_state_events.csv');base=pd.read_pickle(O/'MCD_cache.pkl');macro=macro_frame(base['daily'].index)
 for sym,g in d.groupby('symbol'):
  cache=pd.read_pickle(O/f'{sym}_cache.pkl');p=cache['daily'];w=cache['slow']['confirmed_W'];b=cache['slow']['confirmed_2W_0']
  tr=pd.concat([p.high-p.low,(p.high-p.close.shift()).abs(),(p.low-p.close.shift()).abs()],axis=1).max(axis=1);atr=e.original.rma(tr,14)
  dates=pd.to_datetime(g.signal_date);d.loc[g.index,'rate_state']=macro.rate_regime.reindex(dates).to_numpy()
  d.loc[g.index,'weekly_repair']=w.change.reindex(dates).gt(0).to_numpy();d.loc[g.index,'deep_2w']=b.deep.reindex(dates).to_numpy()
  for row in g.itertuples():
   i=int(p.index.get_indexer([pd.Timestamp(row.signal_date)])[0]);j=i+1;z=i+126;a=float(atr.iloc[i]);entry=float(p.open.iloc[j])
   assert p.index[z]==pd.Timestamp(row.exit_date)
   d.loc[row.Index,'atr_race']=atr_race(p.iloc[j:z+1][['open','high','low','close']].to_numpy(float),entry,a)
   d.loc[row.Index,'atr_pct']=a/entry
 d['hit']=d.atr_race.eq('TARGET').astype(int);d['stop']=d.atr_race.eq('STOP').astype(int);d['positive']=d.net.gt(0).astype(int)
 dates=pd.to_datetime(d.signal_date);d['year']=dates.dt.year;d['quarter']=dates.dt.to_period('Q').astype(str);d['era']=np.where(dates<pd.Timestamp('2023-01-01'),'2018_2022','2023_2026')
 d.to_csv(O/'context_extension_events.csv',index=False)
 for name,keys in [('context_risk_normalized',['panel','frame','cell']),('context_market_interaction',['panel','frame','market_regime','cell']),('context_rates_interaction',['panel','frame','rate_state','cell']),('context_era',['panel','frame','era','cell']),('context_by_stock',['symbol','frame','cell'])]:
  summarize(d,keys).to_csv(O/(name+'.csv'),index=False)
 js=d[d.cell=='JOINT'].copy();summarize(js,['panel','frame','weekly_repair','deep_2w']).to_csv(O/'joint_internal_context.csv',index=False)
 ms=[]
 for (panel,frame),g in d.groupby(['panel','frame']):
  for keys in [['symbol','year'],['symbol','year','market_regime'],['symbol','year','rate_state']]:
   ms.append({'panel':panel,'frame':frame,'matching':'+'.join(keys),**matched(g,keys)})
 pd.DataFrame(ms).to_csv(O/'context_balanced_comparison.csv',index=False)
 print('RISK_NORMALIZED_CORE_DAILY');print(summarize(d[(d.panel=='CORE5')&(d.frame=='1D')],['cell']).round(5).to_string(index=False))
 print('ERA_CORE_DAILY');print(summarize(d[(d.panel=='CORE5')&(d.frame=='1D')&d.cell.isin(['JOINT','NEITHER'])],['era','cell']).round(5).to_string(index=False))
 print('BALANCED_CORE_DAILY');print(pd.DataFrame(ms).query("panel=='CORE5' and frame=='1D'").round(5).to_string(index=False))
 print('REVIEW_ONLY',len(d),'events; no new signals, returns or parameters selected by this audit.')
if __name__=='__main__':main()
