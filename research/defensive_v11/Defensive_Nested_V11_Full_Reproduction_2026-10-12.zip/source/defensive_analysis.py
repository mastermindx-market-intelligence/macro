"""Defensive compounders: reproducible, research-only causal event study.
Prices are vendor-adjusted proxies, not audited executable portfolio returns.
Never use retrospective pivot labels as input to a trading signal.
"""
from pathlib import Path
import json, hashlib, warnings
import numpy as np
import pandas as pd
from scipy.stats import norm
ROOT=Path(__file__).resolve().parent
STOCKS=['MCD','WMT','WM','COST','PG','RSG','KO','PEP','CL','CHD','KMB','MDLZ','HSY','CLX','JNJ','ADP','CTAS','KR']
COST=.001
PERIODS={'train':('2011-01-01','2018-12-31'),'validation':('2019-01-01','2022-12-31'),'test':('2023-01-01','2026-10-08')}

def rma(s,n):
    x=s.to_numpy(dtype=float); out=np.full(len(x),np.nan)
    valid=np.flatnonzero(np.isfinite(x))
    if len(valid)<n: return pd.Series(out,index=s.index)
    start=valid[0]; k=start+n-1
    if not np.isfinite(x[start:k+1]).all(): raise ValueError('Interior seed NaN')
    out[k]=x[start:k+1].mean()
    for i in range(k+1,len(x)):
        out[i]=((n-1)*out[i-1]+x[i])/n if np.isfinite(x[i]) else out[i-1]
    return pd.Series(out,index=s.index)

def rsi(s,n=14):
    d=s.diff(); up=rma(d.clip(lower=0),n); dn=rma(-d.clip(upper=0),n)
    v=100-100/(1+up/dn)
    return v.mask((dn==0)&(up>0),100).mask((dn==0)&(up==0),50)

def features(d,weekly=True):
    f=d.copy(); c=f.close
    for n in [5,20,50,200]:
        f[f'e{n}']=c.ewm(span=n,adjust=False,min_periods=n).mean()
        f[f's{n}']=c.rolling(n).mean()
    tr=pd.concat([f.high-f.low,(f.high-c.shift()).abs(),(f.low-c.shift()).abs()],axis=1).max(axis=1)
    f['atr']=rma(tr,14); f['rsi']=rsi(c)
    f['macd']=c.ewm(span=12,adjust=False,min_periods=12).mean()-c.ewm(span=26,adjust=False,min_periods=26).mean()
    f['hist']=f.macd-f.macd.ewm(span=9,adjust=False,min_periods=9).mean()
    f['z']=f.macd/np.sqrt(f.macd.pow(2).rolling(80).mean().shift())
    rmin=f.rsi.rolling(14).min(); rmax=f.rsi.rolling(14).max()
    raw=100*(f.rsi-rmin)/(rmax-rmin)
    f['stoch']=raw.mask(rmax==rmin,50).rolling(3).mean()
    f['stretch']=(c-f.e20)/f.atr
    f['trend']=(c>f.s200)&(f.s50>f.s50.shift(20))
    f['weekly_trend']=False
    if weekly:
        w=c.resample('W-FRI').last(); e=w.ewm(span=40,adjust=False,min_periods=40).mean()
        wt=(w>e)&(e>e.shift(4))
        f['weekly_trend']=wt.reindex(f.index,method='ffill').fillna(False).astype(bool)
    return f

def signals(f):
    c=f.close; br=c>f.high.shift(); improve=f['hist']>f['hist'].shift()
    touch20=((f.low<=f.e20)&(f.rsi<55)).rolling(5).max().eq(1)
    touch50=(f.low<=f.s50+.25*f.atr).rolling(10).max().eq(1)
    prevlow=f.low.rolling(20).min().shift()
    cp=(c-f.low)/(f.high-f.low).replace(0,np.nan)
    return {
      'price_break_only':br,
      'rsi30_recovery':(f.rsi>30)&(f.rsi.shift()<=30),
      'macd_below_zero_cross':(f['hist']>0)&(f['hist'].shift()<=0)&(f.macd<0),
      'trend_ema20_pullback':f.trend&touch20&br,
      'trend_sma50_reset':f.trend&touch50&(f.rsi.rolling(5).min()<=45)&improve&br,
      'stress_price_reclaim':(f.rsi.rolling(5).min()<=35)&improve&br&(c>f.e5),
      'failed_breakdown':(f.low<prevlow)&(c>prevlow)&(cp>=.65)&(f.rsi<50),
    }

def tops(f):
    s=(f.stretch>=2)&(f.rsi>=65)
    return {'rsi70_first_cross':(f.rsi>=70)&(f.rsi.shift()<70),
      'atr_stretch2':s&~s.shift(fill_value=False),
      'stretch_price_failure':(f.stretch.rolling(5).max()>=2)&(f.close<f.low.shift())&(f['hist']<f['hist'].shift()),
      'sma50_loss':(f.close<f.s50)&(f.close.shift()>=f.s50.shift())}

def nonoverlap(indices,horizon):
    out=[]; last=-10**9
    for i in indices:
        if int(i)-last>=horizon: out.append(int(i)); last=int(i)
    return out

def period(start,end,intraday=False):
    ps={'train':('2024-10-14','2025-10-08'),'test':('2025-10-09','2026-10-08')} if intraday else PERIODS
    s=pd.Timestamp(start).date(); e=pd.Timestamp(end).date()
    for k,(a,b) in ps.items():
        if s>=pd.Timestamp(a).date() and e<=pd.Timestamp(b).date(): return k
    return None

def barrier(path,entry,atr,target=2,stop=1.5):
    lo=entry-stop*atr; hi=entry+target*atr
    for o,h,l,c in path:
        if o<=lo: return -1
        if o>=hi: return 1
        if l<=lo: return -1
        if h>=hi: return 1
    return 0

def load_daily(s):
    raw=json.loads((ROOT/f'{s}_1d.json').read_text())['chart']['result'][0]
    q=raw['indicators']['quote'][0]
    ix=pd.to_datetime(raw['timestamp'],unit='s',utc=True).tz_convert('America/New_York').normalize().tz_localize(None)
    d=pd.DataFrame(q,index=ix).dropna(subset=['open','high','low','close'])
    adj=pd.Series(raw['indicators']['adjclose'][0]['adjclose'],index=ix)
    d['raw_close']=d.close; d['factor']=adj.reindex(d.index)/d.close
    d.loc[:,['open','high','low','close']]=d[['open','high','low','close']].mul(d.factor,axis=0)
    d=d.loc[d.index<pd.Timestamp('2026-10-09')]
    if d.index.duplicated().any(): raise ValueError(s+' duplicate dates')
    if not ((d.high>=d[['open','close']].max(axis=1)-1e-6)&(d.low<=d[['open','close']].min(axis=1)+1e-6)&(d.low>0)).all(): raise ValueError(s+' invalid OHLC')
    return d

def boot(g,col,B=1200):
    if len(g)<2: return [None,None,None]
    q=pd.to_datetime(g.entry,utc=True).dt.tz_localize(None).dt.to_period('Q').astype(str)
    x=g.groupby(q)[col].agg(['sum','count'])
    if len(x)<3: return [None,None,None]
    rng=np.random.default_rng(7291); picks=rng.integers(0,len(x),size=(B,len(x)))
    v=x['sum'].to_numpy()[picks].sum(axis=1)/x['count'].to_numpy()[picks].sum(axis=1)
    return [float(np.quantile(v,.025)),float(np.quantile(v,.975)),float(min(1,2*min((np.sum(v<=0)+1)/(B+1),(np.sum(v>=0)+1)/(B+1))))]

def summarize(events,keys):
    out=[]
    for k,g in events.groupby(keys,sort=False):
        if not isinstance(k,tuple): k=(k,)
        row=dict(zip(keys,k)); lo,hi,p=boot(g,'net')
        row.update(n=len(g),win=float((g.net>0).mean()),mean=float(g.net.mean()),median=float(g.net.median()),mfe=float(g.mfe.mean()),mae=float(g.mae.mean()),ci_low=lo,ci_high=hi)
        for col in ['spy_excess','matched_excess','target2','target3']:
            if col in g: row[col]=float(g[col].mean())
        if 'matched_excess' in g:
            row['edge_ci_low'],row['edge_ci_high'],row['p_edge']=boot(g,'matched_excess')
        out.append(row)
    return pd.DataFrame(out)

def matched_baseline(f,horizon):
    """Retrospective year/trend control, purged at the SAME evaluation boundaries.

    A validation control must never consume a held-out outcome. Signal date,
    next-open date and exit date must all remain within one evaluation period.
    """
    dates=pd.Series(f.index,index=f.index)
    entry=dates.shift(-1); exit_date=dates.shift(-horizon)
    valid=pd.Series(False,index=f.index)
    for start,end in PERIODS.values():
        valid |= (dates>=pd.Timestamp(start))&(entry>=pd.Timestamp(start))&(exit_date<=pd.Timestamp(end))
    forward=(f.close.shift(-horizon)/f.open.shift(-1)-1-COST).where(valid)
    ref=pd.DataFrame({'forward':forward,'year':f.index.year,'trend':f.trend})
    return ref.groupby(['year','trend']).forward.transform('mean')

def daily_events(fs):
    rows=[]; spy=fs['SPY']
    for sym in STOCKS:
        f=fs[sym]; sigs=signals(f); sigs.update(tops(f)); n=len(f)
        for horizon in [5,10,20]:
            matched=matched_baseline(f,horizon)
            for rule,sig in sigs.items():
                for label,(pa,pb) in PERIODS.items():
                    idx=np.flatnonzero(sig.fillna(False).to_numpy()&(f.index>=pd.Timestamp(pa))&(f.index<=pd.Timestamp(pb)))
                    idx=[i for i in idx if i+1<n and i+horizon<n and period(f.index[i+1],f.index[i+horizon])==label]
                    for i in nonoverlap(idx,horizon):
                        j=i+1; z=i+horizon; entry=float(f.open.iloc[j]); path=f.iloc[j:z+1]
                        p=path[['open','high','low','close']].to_numpy(); atr=float(f.atr.iloc[i])
                        net=float(f.close.iloc[z]/entry-1-COST)
                        spyret=float(spy.close.loc[f.index[z]]/spy.open.loc[f.index[j]]-1-COST)
                        rows.append({'symbol':sym,'rule':rule,'horizon':horizon,'period':label,'signal':str(f.index[i].date()),'entry':str(f.index[j].date()),'exit':str(f.index[z].date()),'net':net,'mfe':float(path.high.max()/entry-1),'mae':float(path.low.min()/entry-1),'spy_excess':net-spyret,'matched_excess':net-float(matched.iloc[i]),'target2':barrier(p,entry,atr,2,1.5)==1,'target3':barrier(p,entry,atr,3,1.5)==1,'rsi':float(f.rsi.iloc[i]),'weekly_trend':bool(f.weekly_trend.iloc[i]),'trend':bool(f.trend.iloc[i])})
    return pd.DataFrame(rows)

def census(fs):
    rows=[]; piv=[]; spyret=fs['SPY'].close.pct_change()
    for sym in STOCKS:
        f=fs[sym]; x=f.loc['2011-01-01':]; rt=x.close.pct_change(); b=spyret.reindex(rt.index)
        peak=x.close.cummax(); w=10
        for i in range(260,len(f)-w):
            for kind,series in [('bottom',f.low),('top',f.high)]:
                seg=series.iloc[i-w:i+w+1]
                is_pivot=(series.iloc[i]==seg.min()) if kind=='bottom' else (series.iloc[i]==seg.max())
                if is_pivot:
                    past=f.iloc[max(0,i-20):i+1]
                    piv.append({'symbol':sym,'kind':kind,'date':str(f.index[i].date()),'rsi':float(f.rsi.iloc[i]),'trend':bool(f.trend.iloc[i]),'stretch':float(f.stretch.iloc[i]),'depth':float(f.low.iloc[i]/past.high.max()-1),'z':float(f.z.iloc[i])})
        rows.append({'symbol':sym,'n_daily':len(f),'start':str(f.index[0].date()),'end':str(f.index[-1].date()),'median_atr_pct':float((x.atr/x.close).median()),'trend_fraction':float(x.trend.mean()),'above200_fraction':float((x.close>x.s200).mean()),'beta_spy':float(rt.cov(b)/b.var()),'max_drawdown':float((x.close/peak-1).min()),'adjusted_cagr':float((x.close.iloc[-1]/x.close.iloc[0])**(365.25/(x.index[-1]-x.index[0]).days)-1),'latest_raw_close':float(f.raw_close.iloc[-1]),'latest_rsi':float(f.rsi.iloc[-1]),'latest_trend':bool(f.trend.iloc[-1])})
    p=pd.DataFrame(piv); c=pd.DataFrame(rows)
    for sym in STOCKS:
        lo=p[(p.symbol==sym)&(p.kind=='bottom')]; hi=p[(p.symbol==sym)&(p.kind=='top')]; tl=lo[lo.trend]
        vals={'pivot_bottoms':len(lo),'bull_pivot_bottoms':len(tl),'median_bottom_rsi':lo.rsi.median(),'median_bull_bottom_rsi':tl.rsi.median(),'bottoms_below30_fraction':(lo.rsi<30).mean(),'median_bull_pullback':tl.depth.median(),'median_top_rsi':hi.rsi.median(),'tops_above70_fraction':(hi.rsi>70).mean()}
        for k,v in vals.items(): c.loc[c.symbol==sym,k]=v
    return c,p

def load_hourly(s,day):
    raw=json.loads((ROOT/f'{s}_60m.json').read_text())['chart']['result'][0]
    ix=pd.to_datetime(raw['timestamp'],unit='s',utc=True).tz_convert('America/New_York')
    b=pd.DataFrame(raw['indicators']['quote'][0],index=ix).dropna(subset=['open','high','low','close'])
    minute=b.index.hour*60+b.index.minute
    b=b[(minute>=570)&(minute<960)&(b.index.date<pd.Timestamp('2026-10-09').date())].copy()
    dates=b.index.normalize().tz_localize(None)
    fac=day.factor.reindex(dates).to_numpy()
    if not np.isfinite(fac).all(): raise ValueError(s+' absent daily factor')
    b.loc[:,['open','high','low','close']]=b[['open','high','low','close']].mul(fac,axis=0)
    # Yahoo early-close records include missing 12:30 bars and malformed 13:00
    # zero-volume aggregates. Never reconstruct those bars from daily data.
    excluded=[]; expected=[570,630,690,750,810,870,930]
    for date,g in b.groupby(b.index.date):
        observed=list(g.index.hour*60+g.index.minute)
        if observed!=expected or not (g.volume>0).all(): excluded.append(date)
    b=b[~np.isin(b.index.date,excluded)].copy()
    b['end']=b.index+pd.Timedelta(hours=1)
    for date,g in b.groupby(b.index.date):
        last=g.index[-1]; b.loc[last,'end']=last+pd.Timedelta(minutes=30)
    if b.index.duplicated().any(): raise ValueError(s+' duplicate hourly bars')
    if not ((b.high>=b[['open','close']].max(axis=1)-1e-6)&(b.low<=b[['open','close']].min(axis=1)+1e-6)&(b.low>0)).all(): raise ValueError(s+' invalid hourly OHLC')
    b.attrs['excluded_dates']=[str(x) for x in excluded]
    return b

def aggregate_intraday(b,hours):
    rows=[]; stamps=[]
    dates=b.index.date; bucket=((b.index.hour*60+b.index.minute-570)//(hours*60))
    for (date,gid),g in b.groupby([dates,bucket],sort=True):
        start=g.index[0]; end=g.end.iloc[-1]
        rows.append({'open':g.open.iloc[0],'high':g.high.max(),'low':g.low.min(),'close':g.close.iloc[-1],'volume':g.volume.sum(),'end':end,'minutes':(end-start).total_seconds()/60})
        stamps.append(start)
    return pd.DataFrame(rows,index=pd.DatetimeIndex(stamps))

def intraday_events(fs,bs):
    rows=[]; signals_cache={}; dayindex=fs['SPY'].index
    for sym in STOCKS:
        b=bs[sym]; d=fs[sym]; dates=b.index.normalize().tz_localize(None)
        for hours in [1,2,3,4]:
            f=features(aggregate_intraday(b,hours),weekly=False)
            fd=f.index.normalize().tz_localize(None)
            trend=d.trend.shift(1).reindex(fd).to_numpy()
            reset=d.rsi.rolling(5).min().shift(1).reindex(fd).to_numpy()
            br=f.close>f.high.shift(); imp=f['hist']>f['hist'].shift()
            ss={'macd_cross':(f['hist']>0)&(f['hist'].shift()<=0)&(f.macd<0),
                'reset_price_break':trend&(reset<=55)&(f.rsi.rolling(3).min()<=40)&br&imp,
                'extreme_price_break':(f.z.rolling(5).min()<=-1.5)&(f.rsi.rolling(5).min()<=35)&(f.stoch.rolling(5).min()<=20)&br&imp}
            for rule,sig in ss.items():
                hits=[]
                for i in np.flatnonzero(sig.fillna(False).to_numpy()):
                    j=int(b.index.searchsorted(f.end.iloc[i],side='left'))
                    if j>=len(b): continue
                    hits.append((i,j))
                signals_cache[(sym,hours,rule)]=[(str(b.index[j]),float(b.open.iloc[j])) for i,j in hits]
                for horizon in [5,10]:
                    last_end={}
                    for i,j in hits:
                        day=pd.Timestamp(b.index[j].date()); di=dayindex.get_indexer([day])[0]
                        if di<0 or di+horizon-1>=len(dayindex): continue
                        exitday=dayindex[di+horizon-1]
                        z=int(np.searchsorted(dates.to_numpy(),exitday.to_datetime64(),side='right'))-1
                        if z<j or z>=len(b) or dates[z]!=exitday: continue
                        label=period(day,exitday,True)
                        if label is None or j<=last_end.get(label,-1): continue
                        path=b.iloc[j:z+1]
                        if len(set(path.index.date))!=horizon: continue
                        last_end[label]=z; entry=float(b.open.iloc[j])
                        net=float(path.close.iloc[-1]/entry-1-COST)
                        spy=bs['SPY']; sj=spy.index.searchsorted(b.index[j]); sz=spy.index.searchsorted(b.end.iloc[z],side='left')-1
                        if sj>=len(spy) or sz<sj: continue
                        spyret=float(spy.close.iloc[sz]/spy.open.iloc[sj]-1-COST)
                        rows.append({'symbol':sym,'hours':hours,'rule':rule,'horizon':horizon,'period':label,'signal':str(f.end.iloc[i]),'entry':str(b.index[j]),'exit':str(b.end.iloc[z]),'net':net,'mfe':float(path.high.max()/entry-1),'mae':float(path.low.min()/entry-1),'spy_excess':net-spyret})
    return pd.DataFrame(rows),signals_cache

def select_daily(summary):
    choices=[]
    rules=list(signals(features(pd.DataFrame({'open':[1.]*250,'high':[2.]*250,'low':[.5]*250,'close':[1.]*250,'volume':[1]*250},index=pd.bdate_range('2020-01-01',periods=250)))))
    rules.remove('price_break_only')
    for sym in STOCKS:
        a=summary[(summary.symbol==sym)&(summary.horizon==20)&(summary.rule.isin(rules))]
        tr=a[a.period=='train'].set_index('rule'); va=a[a.period=='validation'].set_index('rule')
        eligible=[]
        for rule in tr.index.intersection(va.index):
            t=tr.loc[rule]; v=va.loc[rule]
            if t.n>=12 and v.n>=8 and t.matched_excess>0 and v.matched_excess>0:
                se=(v.edge_ci_high-v.edge_ci_low)/3.92 if np.isfinite(v.edge_ci_high) and np.isfinite(v.edge_ci_low) else np.inf
                eligible.append((float(v.matched_excess-.5*se),rule))
        if eligible:
            score,rule=max(eligible); test=a[(a.period=='test')&(a.rule==rule)]
            obj={'symbol':sym,'selected_rule':rule,'validation_score':score}
            if len(test): obj.update(test.iloc[0].to_dict())
        else: obj={'symbol':sym,'selected_rule':'NO_QUALIFIED_CANDIDATE'}
        choices.append(obj)
    return pd.DataFrame(choices)

def main():
    fs={s:features(load_daily(s)) for s in STOCKS+['SPY','XLP','XLI','XLY']}
    manifest=json.loads((ROOT/'manifest.json').read_text())
    for m in manifest:
        assert hashlib.sha256((ROOT/m['filename']).read_bytes()).hexdigest()==m['sha256']
    c,p=census(fs); c.to_csv(ROOT/'census.csv',index=False); p.to_csv(ROOT/'retrospective_pivots.csv',index=False)
    e=daily_events(fs); e.to_csv(ROOT/'daily_events.csv',index=False)
    s=summarize(e,['symbol','rule','horizon','period']); s.to_csv(ROOT/'daily_summary.csv',index=False)
    pooled=summarize(e,['rule','horizon','period']); pooled.to_csv(ROOT/'daily_pooled.csv',index=False)
    choice=select_daily(s); choice.to_csv(ROOT/'locked_selection.csv',index=False)
    bs={sym:load_hourly(sym,fs[sym]) for sym in STOCKS+['SPY']}
    qa=[]
    for sym,b in bs.items():
        diff=b.index.symmetric_difference(bs['SPY'].index)
        qa.append({'symbol':sym,'hourly_bars':len(b),'timestamps_different_from_spy':len(diff),'first':str(b.index[0]),'last':str(b.index[-1])})
    ie,cache=intraday_events(fs,bs); ie.to_csv(ROOT/'intraday_events.csv',index=False)
    ins=summarize(ie,['symbol','hours','rule','horizon','period']); ins.to_csv(ROOT/'intraday_summary.csv',index=False)
    inp=summarize(ie,['hours','rule','horizon','period']); inp.to_csv(ROOT/'intraday_pooled.csv',index=False)
    (ROOT/'intraday_signal_times.json').write_text(json.dumps({str(k):v for k,v in cache.items()}))
    (ROOT/'qa.json').write_text(json.dumps({'manifest_hashes_verified':len(manifest),'daily_ohlc_valid':True,'intraday':qa,'daily_event_count':len(e),'intraday_event_count':len(ie),'scope':'Research only. No production rule or trade action.'},indent=2))
    print('CENSUS'); print(c[['symbol','median_atr_pct','above200_fraction','median_bull_bottom_rsi','bottoms_below30_fraction','median_bull_pullback','tops_above70_fraction']].round(4).to_string(index=False))
    print('LOCKED DAILY SELECTION'); print(choice.reindex(columns=['symbol','selected_rule','n','mean','matched_excess','edge_ci_low','edge_ci_high']).round(4).to_string(index=False))
    print('FILES',len(list(ROOT.glob('*'))),'DAILY_EVENTS',len(e),'INTRADAY_EVENTS',len(ie))

if __name__=='__main__': main()
