"""V11 post-primary cycle-management hypotheses; no threshold optimization."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import empirical as e
import management as m
import management_before_extension as old
from alignment import aligned_features
R=Path(__file__).resolve().parent;O=R/'results'

def add_weekly(cache,f):
    w=cache['slow']['confirmed_W'];gap=w.k-w.d
    # The previous daily row carries the previous completed weekly observation.
    bear=w.fresh&(gap<0)&(gap.shift()>=0)
    out=f.copy();out['weekly_k']=w.k.reindex(f.index);out['weekly_fresh']=w.fresh.reindex(f.index);out['weekly_stoch_bear']=bear.reindex(f.index)
    return out

def run():
    rows=[];ledgers=[];curves={};identities=0
    for sym in e.CORE:
      c=pd.read_pickle(O/f'{sym}_cache.pkl')
      for mode in ['confirmed','developing']:
       for frame in ['1D','2D']:
        d,base=m.make_features(c,mode,frame)
        # Fresh independent numerical check of unchanged earlier-policy outputs.
        for rule in ['lower','weekly','cycle']:
          a=old.replay(d,base,rule,3,1);b=m.replay(d,base,rule,3,1)
          pd.testing.assert_frame_equal(a['trades'],b['trades']);pd.testing.assert_frame_equal(a['equity'],b['equity']);identities+=1
        for entry in ['first_fresh','recent5_or_fresh']:
          if entry=='recent5_or_fresh':dd,f,_=aligned_features(c,mode,frame)
          else:dd,f=d,base
          f=add_weekly(c,f)
          for rule in ['weekly_stoch','repair_failure']:
            for mult in ([3.,5.] if mode=='confirmed' else [3.]):
              z=m.replay(dd,f,rule,mult,1)
              tag={'symbol':sym,'mode':mode,'frame':frame,'entry_rule':entry,'exit_rule':rule,'atr_multiple':mult,'attempts':1,'cost_bps':10}
              rows.append({**tag,**z['summary']})
              if len(z['trades']):ledgers.append(z['trades'].assign(**tag))
              curves['|'.join(map(str,tag.values()))]=z['equity']
      print('CYCLE_POLICY_CHECKED',sym,flush=True)
    df=pd.DataFrame(rows);df.to_csv(O/'cycle_extension_summary.csv',index=False)
    pd.concat(ledgers,ignore_index=True).to_csv(O/'cycle_extension_trades.csv',index=False)
    pd.to_pickle(curves,O/'cycle_extension_equities.pkl')
    (O/'management_identity_check.json').write_text(json.dumps({'old_new_actual_policy_equity_and_trade_comparisons':identities,'all_exact':True},indent=2))
    x=df[(df['mode']=='confirmed')&(df.entry_rule=='first_fresh')&(df.atr_multiple==3)]
    print('CORE_CYCLE',x[['symbol','frame','exit_rule','entries','closed','win','cagr','max_dd','exposure']].round(5).to_json(orient='records'),flush=True)
    print('UNCHANGED_BASE_POLICIES',identities,'NEW_COMBINATIONS',len(df),flush=True)

if __name__=='__main__':run()
