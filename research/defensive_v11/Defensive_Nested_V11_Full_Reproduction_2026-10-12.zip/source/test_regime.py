import unittest
import pandas as pd
import numpy as np
from regime_audit import align_macro
class RegimeTests(unittest.TestCase):
 def test_lag_no_same_day_information(self):
  ix=pd.bdate_range('2020-01-06',periods=12);s=pd.Series(np.arange(12.),index=ix)
  a=align_macro(s,ix,2,7);self.assertTrue(pd.isna(a.iloc[1]));self.assertEqual(a.iloc[4],2.)
 def test_future_perturbation_does_not_change_past(self):
  ix=pd.bdate_range('2020-01-06',periods=15);s=pd.Series(np.arange(15.),index=ix);a=align_macro(s,ix,2,7);s.iloc[10:]=999;b=align_macro(s,ix,2,7)
  pd.testing.assert_series_equal(a.iloc[:12],b.iloc[:12])
 def test_stale_is_unknown(self):
  ix=pd.bdate_range('2020-01-06',periods=20);s=pd.Series([1.],index=ix[:1]);a=align_macro(s,ix,2,7);self.assertTrue(pd.isna(a.iloc[-1]))
 def test_missing_does_not_become_zero(self):
  ix=pd.bdate_range('2020-01-06',periods=10);a=align_macro(pd.Series(np.nan,index=ix),ix,2,7);self.assertTrue(a.isna().all())
if __name__=='__main__':unittest.main(verbosity=2)
