"""Descriptive V11 rates/market conditioning; no fitted live gate or orders.
Reads only previously acquired FRED input series, never V3 result tables.
"""
from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd
import empirical as e
from run_events import summary
R=Path(__file__).resolve().parent;O=R/'results'

def align_macro(series,index,lag=2,max_age=7):
    s=pd.to_numeric(series,errors='coerce').dropna().sort_index()
    if s.empty:return pd.Series(np.nan,index=index)
    union=s.index.union(index);dates=pd.Series(s.index,index=s.index)
    v=s.reindex(union).ffill().reindex(index).shift(lag)
    known=dates.reindex(union).ffill().reindex(index).shift(lag)
    age=(pd.Series(index,index=index)-known).dt.days
    return v.where(age<=max_age)

def macro_frame(index):
    p=Path('/tmp/mmx_defensive_regimes_v3_20261009/inputs');f=pd.DataFrame(index=index)
    for name in ['DFII10','DGS10','BAA10Y','VIXCLS']:
        d=pd.read_csv(p/(name+'.csv'));ix=pd.to_datetime(d.iloc[:,0]);s=pd.Series(pd.to_numeric(d.iloc[:,1],errors='coerce').to_numpy(),index=ix)
        f[name]=align_macro(s,index)
    f['real63']=f.DFII10.diff(63);f['nominal63']=f.DGS10.diff(63);f['credit21']=f.BAA10Y.diff(21)
    known=f[['real63','credit21']].notna().all(axis=1)
    f['rate_regime']=np.where(~known,'UNKNOWN',np.where(f.credit21>=.20,'CREDIT_WIDENING',np.where(f.real63>=.25,'REAL_YIELD_PRESSURE',np.where(f.real63<=-.25,'REAL_YIELD_RELIEF','MIXED_STABLE'))))
    return f

def block_interval(g,column='incremental',rep=3000):
    g=g[g.status!='INCOMPLETE'].dropna(subset=[column]);n=len(g)
    if n==0:return dict(n=0,quarters=0,mean=None,low=None,high=None)
    q=pd.to_datetime(g.arm_date).dt.to_period('Q');idx=pd.period_range('2018Q1','2026Q3',freq='Q')
    stats=g.assign(q=q).groupby('q')[column].agg(['sum','count']).reindex(idx,fill_value=0)
    active=int((stats['count']>0).sum());mean=float(g[column].mean())
    if active<8:return dict(n=n,quarters=active,mean=mean,low=None,high=None)
    rng=np.random.default_rng(41882);nn=len(idx);length=4;starts=rng.integers(0,nn,size=(rep,int(np.ceil(nn/length))))
    samples=(starts[:,:,None]+np.arange(length)[None,None,:])%nn;samples=samples.reshape(rep,-1)[:,:nn]
    denom=stats['count'].to_numpy()[samples].sum(axis=1);num=stats['sum'].to_numpy()[samples].sum(axis=1)
    v=num[denom>0]/denom[denom>0]
    return dict(n=n,quarters=active,mean=mean,low=float(np.quantile(v,.025)),high=float(np.quantile(v,.975)))

def run():
    df=pd.read_csv(O/'all_episode_results.csv');primary=df[(df.two_week_phase==0)&(df.lower_phase==0)&(df.warmup==200)&df.frame.isin(['1D','2D'])].copy()
    cache=pd.read_pickle(O/'MCD_cache.pkl');m=macro_frame(cache['daily'].index)
    primary['rates_arm']=m.rate_regime.reindex(pd.to_datetime(primary.arm_date)).to_numpy()
    primary['rates_signal']=m.rate_regime.reindex(pd.to_datetime(primary.signal_date)).to_numpy()
    primary['period']=np.where(pd.to_datetime(primary.arm_date)<pd.Timestamp('2023-01-01'),'2018_2022','2023_2026')
    primary['panel']=np.where(primary.symbol.isin(e.CORE),'CORE5','PEERS13')
    primary.to_csv(O/'primary_labeled_events.csv',index=False)
    summary(primary,['panel','mode','frame','horizon','rates_arm']).to_csv(O/'rates_regime_summary.csv',index=False)
    summary(primary,['panel','mode','frame','horizon','regime_arm']).to_csv(O/'panel_market_regime_summary.csv',index=False)
    summary(primary,['symbol','mode','frame','horizon','period']).to_csv(O/'period_summary.csv',index=False)
    blocks=[]
    for k,g in primary.groupby(['symbol','mode','frame','horizon']):blocks.append(dict(zip(['symbol','mode','frame','horizon'],k))|block_interval(g))
    pd.DataFrame(blocks).to_csv(O/'paired_block_intervals.csv',index=False)
    gates=[]
    for gate,col in [('daily_stoch_washout','short_washout_at_signal'),('weekly_repair','weekly_repair_at_signal'),('deep_2w_macd','deep_2w_arm')]:
      altered=primary.copy();rejected=(altered.status=='FILLED')&~altered[col].fillna(False).astype(bool)
      altered.loc[rejected,'status']='SKIPPED';altered.loc[rejected,'net']=0.;altered.loc[rejected,'incremental']=-altered.loc[rejected,'baseline']
      gs=summary(altered,['symbol','mode','frame','horizon']);gs['gate']=gate;gates.append(gs)
    pd.concat(gates,ignore_index=True).to_csv(O/'same_first_cross_gate_summary.csv',index=False)
    # Recovered baseline: same stock, same lower crossover, same entry horizon.
    allcross=[]
    for sym in e.STOCKS:
      p=O/f'{sym}_cache.pkl'
      if not p.exists():continue
      c=pd.read_pickle(p);d=c['daily'];ix=d.index
      for frame in ['1D','2D']:
        lo=c['lower'][frame+'_0']
        for i in np.flatnonzero(lo.bull.to_numpy(bool)&(ix>=pd.Timestamp('2018-01-01'))):
          for h in [63,126,252]:
            if i+h>=len(d):continue
            allcross.append({'symbol':sym,'frame':frame,'horizon':h,'signal_date':str(ix[i].date()),'year':int(ix[i].year),'net':float(d.close.iloc[i+h]/d.open.iloc[i+1]*.9995/1.0005-1)})
    ac=pd.DataFrame(allcross);ac.to_csv(O/'unconditioned_crossover_events.csv',index=False)
    cs=[]
    for key,g in primary[(primary.status=='FILLED')&primary.entry_horizon_net.notna()].groupby(['symbol','mode','frame','horizon']):
      sym,mode,frame,h=key;a=ac[(ac.symbol==sym)&(ac.frame==frame)&(ac.horizon==h)]
      ref=a.groupby('year').net.agg(['mean','count']);years=pd.to_datetime(g.signal_date).dt.year
      expected=ref['mean'].reindex(years).to_numpy();counts=ref['count'].reindex(years).to_numpy();ok=counts>=3
      cs.append({'symbol':sym,'mode':mode,'frame':frame,'horizon':h,'nested_n':len(g),'nested_win':float((g.entry_horizon_net>0).mean()),'nested_mean':float(g.entry_horizon_net.mean()),'all_cross_n':len(a),'all_cross_win':float((a.net>0).mean()),'all_cross_mean':float(a.net.mean()),'year_matched_n':int(ok.sum()),'year_matched_excess':float(np.mean(g.entry_horizon_net.to_numpy()[ok]-expected[ok])) if ok.any() else None})
    pd.DataFrame(cs).to_csv(O/'unconditioned_comparison.csv',index=False)
    core=primary[(primary.panel=='CORE5')&(primary['mode']=='confirmed')&(primary.frame=='1D')&(primary.horizon==126)]
    print('CORE_RATE_STATES',summary(core,['rates_arm'])[['rates_arm','complete','filled','win','mean_trade','mean_immediate','incremental']].round(5).to_json(orient='records'),flush=True)
    print('CORE_MARKET_STATES',summary(core,['regime_arm'])[['regime_arm','complete','filled','win','mean_trade','mean_immediate','incremental']].round(5).to_json(orient='records'),flush=True)
    x=pd.DataFrame(cs);print('CORE_UNFILTERED_COMPARISON',x[x.symbol.isin(e.CORE)&(x['mode']=='confirmed')&(x.horizon==126)].round(5).to_json(orient='records'),flush=True)
    print('JOINED',len(primary),'events, all-cross control',len(ac),flush=True)

if __name__=='__main__':run()
