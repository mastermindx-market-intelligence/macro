"""Package verified V11 derived results and sources; no price acquisition."""
from pathlib import Path
import pandas as pd,json,lzma,base64,hashlib,zipfile
R=Path(__file__).resolve().parent;O=R/'results';tables={}
def put(key,name,cols,select=lambda d:d):
 original=pd.read_csv(O/name);chosen=select(original)
 d=original.loc[chosen] if isinstance(chosen,pd.Series) else chosen
 assert isinstance(d,pd.DataFrame)
 values=d[cols].round(7).astype(object);values=values.where(pd.notna(values),None)
 tables[key]={'columns':cols,'rows':values.values.tolist(),'source_file':name,'source_sha256':hashlib.sha256((O/name).read_bytes()).hexdigest()}
C=['MCD','WMT','WM','COST','PG']
put('Setup comparison','signal_state_summary.csv',['panel','cell','n','positive','win','mean','mae','mfe','target8_first','target15_first','calendar_quarters'],lambda d:(d.frame=='1D')&(d['sample']=='ALL_CROSSES_OVERLAPPING'))
put('By stock','context_by_stock.csv',['symbol','cell','n','win','mean','atr_target_first','mean_mae','mean_atr_pct','quarters'],lambda d:(d.frame=='1D')&d.cell.isin(['JOINT','NEITHER']))
put('First entries','all_episode_summary.csv',['symbol','mode','frame','complete','filled','win','mean_trade','mean_immediate','incremental','entry_delay','mae'],lambda d:d.symbol.isin(C)&(d.warmup==200)&(d.two_week_phase==0)&(d.lower_phase==0)&d.frame.isin(['1D','2D'])&(d.horizon==126))
put('Market states','context_market_interaction.csv',['market_regime','cell','n','win','mean','atr_target_first','mean_mae','quarters'],lambda d:(d.panel=='CORE5')&(d.frame=='1D')&d.cell.isin(['JOINT','NEITHER']))
put('Rates states','context_rates_interaction.csv',['rate_state','cell','n','win','mean','atr_target_first','mean_mae','quarters'],lambda d:(d.panel=='CORE5')&(d.frame=='1D')&d.cell.isin(['JOINT','NEITHER']))
put('Risk units','context_risk_normalized.csv',['panel','cell','n','win','mean','atr_target_first','atr_stop_first','mean_mae','mean_atr_pct'],lambda d:d.frame.eq('1D'))
put('Era stability','context_era.csv',['panel','era','cell','n','win','mean','atr_target_first','mean_mae'],lambda d:d.frame.eq('1D')&d.cell.isin(['JOINT','NEITHER']))
put('New stress exits','stress_transition_summary.csv',['panel','market_transition_exit','stop','n','win','mean','incremental','mae','worst_mae','mean_sessions','stress_exits','stop_exits'],lambda d:d.frame.eq('1D'))
put('Managed policies','policy_summary.csv',['symbol','frame','exit_rule','entries','closed','win','cagr','max_dd','exposure','holding_cagr'],lambda d:d.symbol.isin(C)&d['mode'].eq('confirmed')&d.atr_multiple.eq(3)&d.attempts.eq(1)&d.cost_bps.eq(10)&d.gate.eq('none'))
put('Additional cycle exits','cycle_extension_summary.csv',['symbol','frame','exit_rule','entries','closed','win','cagr','max_dd','exposure'],lambda d:d.symbol.isin(C)&d['mode'].eq('confirmed')&d.atr_multiple.eq(3)&d.attempts.eq(1)&d.cost_bps.eq(10))
put('Episode ledger','core_episode_ledger_complete_metadata.csv',['symbol','frame','episode','arm_date','signal_date','entry_date','exit_date','status','net','baseline','incremental','mae','mfe','regime_signal','rates_signal'])
put('Path diagnostics','core_path_summary.csv',['symbol','frame','n','positive','three_atr_breached','positive_and_three_atr_breached','target8_before_stop5','target15_before_stop5','median_mae','median_mfe','median_three_atr_stop'])
put('Confirmation gates','semantic_gate_summary.csv',['symbol','frame','gate','complete','filled','win','mean_trade','incremental'])
put('Intervals','signal_context_block_audit.csv',['panel','frame','control','metric','joint_n','control_n','difference','block_ci_low','block_ci_high','leave_year_out_min','leave_year_out_max'],lambda d:d.control.eq('NEITHER'))
put('Matched comparisons','context_balanced_comparison.csv',['panel','frame','matching','strata','joint_covered','control_covered','net_difference','hit_difference'])
meta={'study':'V11 actual-stock nested washout evidence','cutoff':'2026-10-08','evaluation_start':'2018-01-01','delivery_date':'2026-10-12','source_root':str(R),'kind':'Curated derived results, not raw vendor bars or live trades','original_input_manifest_sha256':'69703435b594cca35ea7f8e26673dc719c0ec9b3db3dc802df9ca531e0ce6ed3','tests':(R/'delivery_tests_20261012.log').read_text()}
raw=json.dumps({'metadata':meta,'tables':tables},separators=(',',':'),allow_nan=False).encode();text=base64.b64encode(lzma.compress(raw,preset=9)).decode();(R/'curated_delivery_20261012.b64').write_text(text);(R/'curated_delivery_20261012.json').write_bytes(raw)
# Full reproducibility archive retains all research source/specification and all
# derived CSV/JSON results, but excludes raw source series and cache pickle files.
files={}
for p in sorted(R.glob('*.py')):files['source/'+p.name]=p.read_bytes()
files['source/defensive_analysis.py']=(Path('/tmp/mmx_defensive_compounders_20261009')/'defensive_analysis.py').read_bytes()
for p in sorted(R.glob('*spec.json')):files['specifications/'+p.name]=p.read_bytes()
for n in ['verification.json','rates_input_manifest.json','delivery_tests_20261012.log']:
 files[n]=(R/n).read_bytes()
for p in sorted(O.iterdir()):
 if p.suffix in ['.csv','.json']:files['results/'+p.name]=p.read_bytes()
files['curated_results.json']=raw
readme='''# Defensive nested washout V11: empirical research, not live trading

Evaluation: January2018 through October8,2026. Source snapshots: original V1 final-vintage vendor data, 2010 onward. This archive includes full research source, tests, predeclared and explicitly exploratory extensions, all derived CSV/JSON outputs, and a curated results view. It contains NO original equity OHLC files, FRED raw series, cache pickle files, credentials, broker calls or production changes.

The main sources retain their executed M2 paths for provenance. To reproduce, provide legitimately licensed original input snapshots (matching the inventory identities) at the documented original-input path and original FRED files at the documented rate-input path. Put source files together in a directory with a results subdirectory; run test discovery there. `run_events.py`, `management.py`, `regime_audit.py`, `sensitivity.py`, `alignment.py`, `run_cycle.py`, `signal_context.py`, `signal_context_robustness.py`, `semantic_gate.py`, `context_extension.py` and `stress_transition.py` describe the pipeline. The code is not a one-click data downloader and exact user-chart parity remains unverified. The results come from previously examined history, not a fresh blind holdout.

Count distinct watches separately from alternative-policy scenario rows. Cross events and their six-month outcomes may overlap and cluster across stocks. Dataset intervals are exploratory and are not adjusted for the entire research-selection history. Frozen percentage barriers and ATR barriers answer different risk questions. No generated trade sizes or production strategy acceptance.

The original optional verify_cache.py write and earlier V3 computed-result/V4 acquisition operations were not retried. V11 is the separately admitted use of original successfully acquired source snapshots. All recorded writes in this archive are research effects only.
'''
files['README.md']=readme.encode();manifest={k:hashlib.sha256(v).hexdigest() for k,v in files.items()};files['MANIFEST.json']=json.dumps(manifest,indent=2).encode()
z=R/'Defensive_Nested_V11_Full_Reproduction_2026-10-12.zip'
with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as a:
 for k,v in files.items():a.writestr(k,v)
with zipfile.ZipFile(z) as a:
 assert a.testzip() is None
 for k,h in manifest.items():assert hashlib.sha256(a.read(k)).hexdigest()==h
receipt={'curated_raw_sha256':hashlib.sha256(raw).hexdigest(),'curated_raw_bytes':len(raw),'base64_chars':len(text),'tables':{k:len(v['rows']) for k,v in tables.items()},'archive':str(z),'archive_bytes':z.stat().st_size,'archive_sha256':hashlib.sha256(z.read_bytes()).hexdigest(),'archive_members':len(files),'member_hashes_verified':len(manifest)}
(R/'delivery_receipt_20261012.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
