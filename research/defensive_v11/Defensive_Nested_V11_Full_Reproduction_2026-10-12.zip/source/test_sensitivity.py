import unittest
import numpy as np
import pandas as pd
import empirical as e
from sensitivity import signal_prices

class SensitivityTests(unittest.TestCase):
 def test_alternate_rsimacd_stream_matches_batch(self):
  x=pd.Series(100+np.sin(np.arange(700)/17)*8+np.arange(700)*.01)
  s=e.NativeState(12,26,9);a=pd.DataFrame([s.step(v) for v in x]);b=e.batch(x,12,26,9)
  for c in ['rsi','macd','signal','hist','k','d']:np.testing.assert_allclose(a[c],b[c],equal_nan=True,atol=1e-9)
 def test_adjusted_input_not_mutated(self):
  d=pd.DataFrame({'open':[49.],'high':[51.],'low':[48.],'close':[50.],'raw_close':[100.],'factor':[.5]});old=d.copy()
  s=signal_prices(d,'split_only');self.assertEqual(s.close.iloc[0],100.);self.assertEqual(s.open.iloc[0],98.)
  pd.testing.assert_frame_equal(old,d)
 def test_adjusted_case_is_same_price_basis(self):
  d=pd.DataFrame({'close':[50.],'factor':[.5]});pd.testing.assert_frame_equal(signal_prices(d,'adjusted'),d)
 def test_unknown_basis_rejected(self):
  with self.assertRaises(ValueError):signal_prices(pd.DataFrame(), 'unknown')
if __name__=='__main__':unittest.main(verbosity=2)
