"""V11 tests for the empirical adapter; no network or production effects."""
import unittest
import numpy as np
import pandas as pd
import empirical as e

class EmpiricalTests(unittest.TestCase):
    def prices(self,n=1000):
        ix=pd.bdate_range('2010-01-04',periods=n)
        c=100+np.arange(n)*.01+8*np.sin(np.arange(n)/17)+3*np.cos(np.arange(n)/43)
        return pd.DataFrame({'open':c-.1,'high':c+.8,'low':c-.8,'close':c,'volume':1000},index=ix)
    def test_stream_batch_identity(self):
        d=self.prices();s=e.NativeState();f=pd.DataFrame([s.step(x) for x in d.close],index=d.index)
        b=e.batch(d.close)
        for col in ['rsi','macd','signal','hist','k','d']:np.testing.assert_allclose(f[col],b[col],equal_nan=True,atol=1e-10)
    def test_partial_week_not_committed(self):
        d=self.prices();cal=pd.bdate_range(d.index[0],periods=1020)
        f=e.snapshots(d.loc[:'2010-01-13'].close,cal,'1W','confirmed');self.assertEqual(f.iloc[-1]['count'],1)
    def test_preview_does_not_mutate(self):
        s=e.NativeState()
        for p in self.prices(350).close:s.step(p)
        before=(s.count,s.last,s.up,s.down,s.fast,s.slow,s.signal);s.preview(90.)
        self.assertEqual(before,(s.count,s.last,s.up,s.down,s.fast,s.slow,s.signal))
    def test_prefix_invariance(self):
        d=self.prices();cal=pd.bdate_range(d.index[0],periods=1040)
        for mode in ['confirmed','developing']:
            a=e.snapshots(d.close,cal,'2W',mode,1);b=e.snapshots(d.close.iloc[:817],cal,'2W',mode,1)
            pd.testing.assert_frame_equal(a.iloc[:817],b)
    def test_unknown_future_calendar_cannot_complete_tail(self):
        d=self.prices(100)
        with self.assertRaises(ValueError):e.snapshots(d.close,d.index,'2W','confirmed')
    def test_first_trigger_and_episode_reset(self):
        ctx=np.zeros(30,bool);ctx[2:6]=True;ctx[22:27]=True;k=np.where(ctx,10.,70.)
        cross=np.zeros(30,bool);cross[[4,5,24]]=True
        eps=e.episodes(ctx,k,cross,window=10,clear_n=5)
        self.assertEqual([(r['arm_i'],r['signal_i']) for r in eps],[(2,4),(22,24)])
    def test_next_open_pairing(self):
        d=self.prices(40);r=e.event_outcome(d,2,4,10)
        self.assertEqual(r['entry_date'],str(d.index[5].date()));self.assertEqual(r['exit_date'],str(d.index[12].date()))
        self.assertAlmostEqual(r['net'],d.close.iloc[12]/d.open.iloc[5]*(1-.0005)/(1+.0005)-1)
    def test_missed_event_is_cash_not_deleted(self):
        r=e.event_outcome(self.prices(40),2,None,10);self.assertEqual(r['status'],'SKIPPED');self.assertEqual(r['net'],0.)
        self.assertAlmostEqual(r['incremental'],-r['baseline'])
    def test_incomplete_is_not_loss(self):
        r=e.event_outcome(self.prices(40),30,32,20);self.assertEqual(r['status'],'INCOMPLETE');self.assertNotIn('net',r)
    def test_native_cross_not_forward_filled(self):
        d=self.prices();cal=pd.bdate_range(d.index[0],periods=1040);f=e.snapshots(d.close,cal,'2D','confirmed')
        self.assertTrue((~f.bull|f.fresh).all())

if __name__=='__main__':unittest.main(verbosity=2)
