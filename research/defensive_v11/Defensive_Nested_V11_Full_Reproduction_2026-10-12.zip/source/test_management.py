import unittest
import pandas as pd
import numpy as np
from management import replay

class ManagementTests(unittest.TestCase):
 def data(self):
  ix=pd.bdate_range('2020-01-02',periods=8)
  d=pd.DataFrame({'open':100.,'high':101.,'low':99.,'close':100.},index=ix)
  f=pd.DataFrame({'episode':1,'bull':False,'bear':False,'weekly_bear':False,'two_week_k':10.,'two_week_fresh':False,'atr':1.},index=ix);f.loc[ix[0],'bull']=True
  return d,f
 def test_entry_is_next_open_and_entry_day_stop(self):
  d,f=self.data();d.iloc[1,d.columns.get_loc('low')]=95.
  x=replay(d,f,'weekly',3,1);self.assertEqual(x['trades'].iloc[0].entry_date,d.index[1]);self.assertAlmostEqual(x['trades'].iloc[0].exit_price,97.)
 def test_gap_stop_fills_at_open(self):
  d,f=self.data();d.loc[d.index[2],['open','high','low','close']]=[90,91,89,90]
  x=replay(d,f,'weekly',3,1);self.assertEqual(x['trades'].iloc[0].reason,'STOP_GAP');self.assertAlmostEqual(x['trades'].iloc[0].exit_price,90)
 def test_weekly_signal_fills_next_open(self):
  d,f=self.data();f.loc[f.index[2],'weekly_bear']=True;d.loc[d.index[3],['open','high','low','close']]=[105,106,104,105]
  x=replay(d,f,'weekly',3,1);self.assertEqual(x['trades'].iloc[0].exit_date,d.index[3]);self.assertEqual(x['trades'].iloc[0].reason,'WEEKLY_BEAR')
 def test_stale_slow_overbought_cannot_arm_exit(self):
  d,f=self.data();f['two_week_k']=90.;f.loc[f.index[2],'weekly_bear']=True
  x=replay(d,f,'cycle',3,1);self.assertEqual(len(x['trades']),0);self.assertTrue(x['summary']['open_position'])
 def test_retry_keeps_first_loss(self):
  d,f=self.data();d.loc[d.index[1],'low']=95.;f.loc[f.index[2],'bear']=True;f.loc[f.index[3],'bull']=True
  x=replay(d,f,'weekly',3,2);self.assertEqual(x['summary']['entries'],2);self.assertEqual(len(x['trades']),1);self.assertLess(x['summary']['ending_equity'],1)
 def test_one_attempt_stays_one(self):
  d,f=self.data();d.loc[d.index[1],'low']=95.;f.loc[f.index[2],'bear']=True;f.loc[f.index[3],'bull']=True
  self.assertEqual(replay(d,f,'weekly',3,1)['summary']['entries'],1)
 def test_future_bear_cannot_change_earlier_equity(self):
  d,f=self.data();a=replay(d,f,'weekly',3,1);f.loc[f.index[-2],'weekly_bear']=True;b=replay(d,f,'weekly',3,1)
  np.testing.assert_allclose(a['equity'].value.iloc[:-2],b['equity'].value.iloc[:-2])

if __name__=='__main__':unittest.main(verbosity=2)
