import unittest
import numpy as np
import stress_transition as s
class StressTransitionTests(unittest.TestCase):
 def tape(self):return np.array([[100,101,99,100],[100,105,98,101],[90,150,20,140],[100,102,99,101]],float)
 def test_new_stress_fills_next_open(self):
  x=s.simulate(self.tape(),['SUPPORTED','STRESS_WORSENING','SUPPORTED','SUPPORTED'],'SUPPORTED',1,True,None)
  self.assertEqual(x['exit_i'],2);self.assertEqual(x['reason'],'NEW_STRESS');self.assertEqual(x['exit_price'],90.)
  self.assertAlmostEqual(x['mae'],-.1);self.assertAlmostEqual(x['mfe'],.05)
 def test_entry_stress_not_a_new_transition(self):
  x=s.simulate(self.tape(),['STRESS_WORSENING']*4,'STRESS_WORSENING',1,True,None)
  self.assertEqual(x['reason'],'COMMON_END')
 def test_gap_stop_precedes_scheduled_exit(self):
  x=s.simulate(self.tape(),['SUPPORTED','STRESS_WORSENING','SUPPORTED','SUPPORTED'],'SUPPORTED',1,True,3)
  self.assertEqual(x['reason'],'STOP_GAP');self.assertEqual(x['exit_price'],90.)
 def test_entry_day_stop(self):
  p=self.tape();p[0,2]=95
  x=s.simulate(p,['SUPPORTED']*4,'SUPPORTED',1,False,3)
  self.assertEqual(x['exit_i'],0);self.assertEqual(x['exit_price'],97.)
 def test_holding_cost_formula(self):
  x=s.simulate(self.tape(),['SUPPORTED']*4,'SUPPORTED',1,False,None)
  self.assertAlmostEqual(x['net'],101/100*.9995/1.0005-1)
 def test_future_after_exit_cannot_change_result(self):
  p=self.tape();a=s.simulate(p,['SUPPORTED','STRESS_WORSENING','SUPPORTED','SUPPORTED'],'SUPPORTED',1,True,None)
  p[3]=[500,600,400,510]
  b=s.simulate(p,['SUPPORTED','STRESS_WORSENING','SUPPORTED','SUPPORTED'],'SUPPORTED',1,True,None)
  self.assertEqual(a,b)
if __name__=='__main__':unittest.main(verbosity=2)
