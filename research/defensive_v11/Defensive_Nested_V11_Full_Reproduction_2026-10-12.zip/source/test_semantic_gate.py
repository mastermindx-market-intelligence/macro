import unittest
import numpy as np
import pandas as pd
import semantic_gate as s
class SemanticGateTests(unittest.TestCase):
 def test_cross_can_remain_valid_above_20(self):
  d=pd.DataFrame({'k':[10.,8.,12.,30.],'d':[15.,12.,10.,20.]})
  self.assertTrue(s.stoch_in_force(d,8).iloc[-1])
 def test_no_cross_means_no_confirmation(self):
  d=pd.DataFrame({'k':[10.,11.,12.],'d':[5.,6.,7.]})
  self.assertFalse(s.stoch_in_force(d,8).iloc[-1])
 def test_lost_kd_bias_invalidates(self):
  d=pd.DataFrame({'k':[10.,8.,12.,5.],'d':[15.,12.,10.,10.]})
  self.assertFalse(s.stoch_in_force(d,8).iloc[-1])
 def test_future_prices_cannot_change_past_gate(self):
  d=pd.DataFrame({'k':[10.,8.,12.,30.,15.,5.,20.],'d':[15.,12.,10.,20.,17.,10.,15.]})
  pd.testing.assert_series_equal(s.stoch_in_force(d,3).iloc[:4],s.stoch_in_force(d.iloc[:4],3))
if __name__=='__main__':unittest.main(verbosity=2)
