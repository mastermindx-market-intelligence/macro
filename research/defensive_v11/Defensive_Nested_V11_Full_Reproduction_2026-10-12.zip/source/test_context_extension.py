import unittest
import numpy as np
import pandas as pd
import context_extension as x
class ContextExtensionTests(unittest.TestCase):
 def test_barrier_same_daily_bar_is_conservative(self):
  self.assertEqual(x.atr_race(np.array([[100,104,97,101.]]),100,2),'STOP')
 def test_gap_target_before_later_low(self):
  self.assertEqual(x.atr_race(np.array([[105,106,95,99.]]),100,2),'TARGET')
 def test_invalid_atr_rejected(self):
  with self.assertRaises(ValueError):x.atr_race(np.array([[100,101,99,100.]]),100,0)
 def test_matched_only_common_strata(self):
  d=pd.DataFrame({'symbol':['A','A','A','B'],'year':[2020]*4,'market_regime':['X']*4,'cell':['JOINT','NEITHER','NEITHER','JOINT'],'net':[.2,.1,.0,.9],'hit':[1,0,1,1]})
  a=x.matched(d,['symbol','year','market_regime'])
  self.assertEqual(a['strata'],1);self.assertEqual(a['joint_covered'],1)
  self.assertAlmostEqual(a['net_difference'],.15)
 def test_no_common_strata_is_unknown(self):
  d=pd.DataFrame({'symbol':['A','B'],'year':[2020,2020],'market_regime':['X','X'],'cell':['JOINT','NEITHER'],'net':[.2,.1],'hit':[1,0]})
  a=x.matched(d,['symbol','year','market_regime'])
  self.assertEqual(a['strata'],0);self.assertTrue(np.isnan(a['net_difference']))
if __name__=='__main__':unittest.main(verbosity=2)
