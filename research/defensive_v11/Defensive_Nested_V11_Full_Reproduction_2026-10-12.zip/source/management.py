"""V11 explicit single-position policy replay. No orders or external writes.
Initial risk is known before entry; gap fills precede low tests; indicator exits
fill the next open. One unit account is normalization, not recommended sizing.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import empirical as e
R=Path(__file__).resolve().parent;O=R/'results'

def replay(d,f,exit_rule='weekly',atr_multiple=3.,attempt_limit=1,cost_bps=10.,max_hold=252):
    if exit_rule not in ['lower','weekly','cycle','time','weekly_stoch','repair_failure']:raise ValueError('Exit rule')
    if not d.index.equals(f.index) or len(d)==0:raise ValueError('Aligned nonempty input required')
    if atr_multiple is not None and atr_multiple<=0:raise ValueError('Positive ATR multiple or None required')
    fee=cost_bps/20000;cash=1.;pos=None;pending=None;exit_pending=None;counts={};last_bear={};last_signal={};last_exit={};entries=0;trades=[];curve=[];peak=1.
    bars=d[['open','high','low','close']].to_numpy(float);idx=d.index
    vals=f[['episode','bull','bear','weekly_bear','two_week_k','two_week_fresh','atr']].to_numpy()
    wk=f.get('weekly_k',pd.Series(np.nan,index=f.index)).to_numpy(float)
    wf=f.get('weekly_fresh',pd.Series(False,index=f.index)).to_numpy(bool)
    ws=f.get('weekly_stoch_bear',pd.Series(False,index=f.index)).to_numpy(bool)
    if exit_rule in ['weekly_stoch','repair_failure'] and not {'weekly_k','weekly_fresh','weekly_stoch_bear'}.issubset(f.columns):
        raise ValueError('Weekly-stoch exit requires fresh native weekly inputs')
    def close_trade(i,price,reason):
        nonlocal cash,pos,exit_pending
        cash=pos['shares']*price*(1-fee);ep=pos['episode']
        trades.append({'episode':ep,'attempt':pos['attempt'],'signal_date':idx[pos['signal_i']],'entry_date':idx[pos['entry_i']],'entry_price':pos['entry_price'],'exit_date':idx[i],'exit_price':price,'reason':reason,'sessions':i-pos['entry_i']+1,'net':cash/pos['capital_before']-1,'capital_before':pos['capital_before'],'capital_after':cash})
        last_exit[ep]=i;pos=None;exit_pending=None
    for i,(o,h,l,c) in enumerate(bars):
        ep,bull,bear,wb,k,fresh,atr=vals[i];ep=int(ep)
        if pos is not None:
            if o<=pos['stop']:close_trade(i,o,'STOP_GAP')
            elif exit_pending is not None:close_trade(i,o,exit_pending)
        if pending is not None and pos is None:
            p=pending;pending=None;this_ep=p['episode'];number=counts.get(this_ep,0)+1;counts[this_ep]=number
            floor=max(0.,o-atr_multiple*p['atr']) if atr_multiple is not None else 0.
            pos={'episode':this_ep,'attempt':number,'signal_i':p['signal_i'],'entry_i':i,'entry_price':o,'capital_before':cash,'shares':cash/(o*(1+fee)),'stop':floor,'extended':False}
            last_signal[this_ep]=p['signal_i'];cash=0.;entries+=1
        if pos is not None and l<=pos['stop']:close_trade(i,min(o,pos['stop']) if o<=pos['stop'] else pos['stop'],'STOP_INTRADAY')
        if bear and ep>0:last_bear[ep]=i
        if pos is not None:
            if fresh and np.isfinite(k) and k>=80:pos['extended']=True
            if wf[i] and np.isfinite(wk[i]) and wk[i]>=80:pos['weekly_extended']=True
            reason=None
            if exit_rule=='lower' and bear:reason='LOWER_BEAR'
            elif exit_rule=='weekly' and wb:reason='WEEKLY_BEAR'
            elif exit_rule=='cycle' and pos['extended'] and wb:reason='CYCLE_BEAR'
            elif exit_rule in ['weekly_stoch','repair_failure'] and pos.get('weekly_extended',False) and ws[i]:reason='WEEKLY_STOCH_ROLLOVER'
            elif exit_rule=='repair_failure' and bear and c<pos['entry_price']*(1+fee)/(1-fee):reason='FAILED_RECOVERY'
            if reason is None and i-pos['entry_i']+1>=max_hold:reason='TIME_CAP'
            if reason:exit_pending=reason
        if bull and ep>0 and pos is None and exit_pending is None and counts.get(ep,0)<attempt_limit and np.isfinite(atr) and atr>0:
            allow=counts.get(ep,0)==0 or (i-last_exit.get(ep,i)>=1 and last_bear.get(ep,-1)>last_signal.get(ep,-1))
            if allow:pending={'episode':ep,'signal_i':i,'atr':float(atr)}
        value=cash if pos is None else pos['shares']*c;peak=max(peak,value)
        curve.append({'date':idx[i],'value':value,'drawdown':value/peak-1,'exposed':pos is not None})
    t=pd.DataFrame(trades,columns=['episode','attempt','signal_date','entry_date','entry_price','exit_date','exit_price','reason','sessions','net','capital_before','capital_after']);q=pd.DataFrame(curve).set_index('date')
    years=max((idx[-1]-idx[0]).days/365.25,1/365.25);end=float(q.value.iloc[-1])
    s={'ending_equity':end,'net_return':end-1,'cagr':end**(1/years)-1,'max_dd':float(q.drawdown.min()),'entries':entries,'closed':len(t),'win':float((t.net>0).mean()) if len(t) else None,'mean_trade':float(t.net.mean()) if len(t) else None,'median_trade':float(t.net.median()) if len(t) else None,'avg_sessions':float(t.sessions.mean()) if len(t) else None,'exposure':float(q.exposed.mean()),'open_position':pos is not None,'pending_entry':pending is not None,'pending_exit':exit_pending is not None,'unpaid_exit_fee':pos is not None}
    return {'summary':s,'trades':t,'equity':q}

def make_features(cache,mode,frame,phase=0,lower_phase=0,start='2018-01-01',warm=200,gate=None):
    d=cache['daily'];w=cache['slow'][mode+'_W'];b=cache['slow'][f'{mode}_2W_{phase}'];lo=cache['lower'][f'{frame}_{lower_phase}'];wc=cache['slow']['confirmed_W'];bc=cache['slow'][f'confirmed_2W_{phase}'];dd=cache['lower']['1D_0']
    ctx=((w['count']>=warm)&(b['count']>=warm)&w.recent3.le(20)&b.recent2.le(20)&w.k.notna()&b.k.notna()).to_numpy(bool)
    start_i=int(d.index.searchsorted(start));eps=e.episodes(ctx,b.k.to_numpy(float),lo.bull.to_numpy(bool),start_i=start_i)
    ids=np.zeros(len(d),int)
    for ep in eps:ids[ep['arm_i']:ep['end_i']]=ep['episode']
    tr=pd.concat([d.high-d.low,(d.high-d.close.shift()).abs(),(d.low-d.close.shift()).abs()],axis=1).max(axis=1);atr=e.original.rma(tr,14)
    bull=lo.bull&(ids>0)
    if gate=='short':bull &= dd.k.rolling(5,min_periods=1).min().le(20)&dd.k.notna()
    if gate=='weekly_repair':bull &= w.change>0
    if gate=='deep':bull &= b.deep
    f=pd.DataFrame({'episode':ids,'bull':bull,'bear':lo.bear,'weekly_bear':wc.bear,'two_week_k':bc.k,'two_week_fresh':bc.fresh,'atr':atr},index=d.index)
    return d.iloc[start_i:],f.iloc[start_i:]

def run_all():
    sums=[];ledgers=[];equities={}
    for sym in e.STOCKS:
      p=O/f'{sym}_cache.pkl'
      if not p.exists():continue
      cache=pd.read_pickle(p)
      for mode in ['confirmed','developing']:
        for frame in ['1D','2D']:
          d,f=make_features(cache,mode,frame)
          plans=[(rule,3.,1,10.,None) for rule in ['lower','weekly','cycle']]
          if sym in e.CORE and mode=='confirmed':
            plans += [('cycle',v,1,10.,None) for v in [None,2.,5.]]
            plans += [('cycle',3.,2,10.,None),('cycle',3.,1,30.,None)]
            plans += [('cycle',3.,1,10.,g) for g in ['short','weekly_repair','deep']]
          for rule,mul,attempts,cost,gate in plans:
            if gate is not None:dd,ff=make_features(cache,mode,frame,gate=gate)
            else:dd,ff=d,f
            x=replay(dd,ff,rule,mul,attempts,cost);tag={'symbol':sym,'mode':mode,'frame':frame,'exit_rule':rule,'atr_multiple':mul,'attempts':attempts,'cost_bps':cost,'gate':gate or 'none'}
            hold=float(d.close.iloc[-1]/d.open.iloc[0]*.9995/1.0005-1);yrs=(d.index[-1]-d.index[0]).days/365.25
            sums.append({**tag,**x['summary'],'holding_cagr':(1+hold)**(1/yrs)-1})
            if len(x['trades']):ledgers.append(x['trades'].assign(**tag))
            if gate is None and mul==3 and attempts==1 and cost==10:equities[f'{sym}|{mode}|{frame}|{rule}']=x['equity']
      print('MANAGED',sym,flush=True)
    s=pd.DataFrame(sums);s.to_csv(O/'policy_summary.csv',index=False)
    pd.concat(ledgers,ignore_index=True).to_csv(O/'policy_trade_ledger.csv',index=False)
    pd.to_pickle(equities,O/'policy_equities.pkl')
    core=s[s.symbol.isin(e.CORE)&(s['mode']=='confirmed')&(s.atr_multiple==3)&(s.attempts==1)&(s.cost_bps==10)&(s.gate=='none')]
    print('CORE_MANAGED',core[['symbol','frame','exit_rule','cagr','max_dd','entries','closed','win','exposure','holding_cagr']].round(5).to_json(orient='records'),flush=True)

if __name__=='__main__':run_all()
