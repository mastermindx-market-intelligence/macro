"""V23 incremental condition test after long W+2W context is observable.
Comparison remains descriptive and repeatedly inspected; no live trading.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
def paired_strata(d,control,keys):
    if control=='JOINT':raise ValueError('Control cannot be identical to treatment')
    x=d[d.cell.isin(['JOINT',control])].copy()
    if x.empty:return pd.DataFrame(columns=keys+['JOINT',control,'difference'])
    y=x.groupby(keys+['cell']).beta_spread.mean().unstack('cell')
    for c in ['JOINT',control]:
        if c not in y:y[c]=np.nan
    z=y.dropna(subset=['JOINT',control]).reset_index()
    z['difference']=z['JOINT']-z[control]
    return z
def block_contrast(d,control,rep=4000,block=4):
    x=d[d.cell.isin(['JOINT',control])].copy()
    if x.empty:return {'interval':None}
    x['q']=pd.to_datetime(x.signal_date).dt.to_period('Q')
    full=pd.period_range(x.q.min(),x.q.max(),freq='Q')
    totals={}
    for name in ['JOINT',control]:
        a=x[x.cell==name].groupby('q').beta_spread.agg(['sum','count']).reindex(full,fill_value=0)
        totals[name]=(a['sum'].to_numpy(),a['count'].to_numpy())
    active={k:int((v[1]>0).sum()) for k,v in totals.items()}
    if min(active.values())<8:return {'interval':None,'active_quarters':active}
    rng=np.random.default_rng(231013);n=len(full)
    s=rng.integers(0,n,size=(rep,int(np.ceil(n/block))))
    idx=((s[:,:,None]+np.arange(block))%n).reshape(rep,-1)[:,:n]
    a,b=totals['JOINT'];u,v=totals[control]
    na=b[idx].sum(axis=1);nv=v[idx].sum(axis=1)
    valid=(na>0)&(nv>0)
    values=a[idx].sum(axis=1)[valid]/na[valid]-u[idx].sum(axis=1)[valid]/nv[valid]
    return {'interval':'exploratory_not_multipleadjusted','low':float(np.quantile(values,.025)),'high':float(np.quantile(values,.975)),'active_quarters':active,'replicates':len(values)}
def run():
    d=pd.read_csv(ROOT/'results/V22_ALL_CROSS_EVENTS.csv')
    assert len(d)==2771
    d['year']=pd.to_datetime(d.signal_date).dt.year
    rows=[];strata=[]
    for (panel,frame),g in d.groupby(['panel','frame']):
        for control in ['TWO_WEEK_ONLY','WEEKLY_ONLY','NEITHER']:
            treated=g[g.cell=='JOINT'];ctrl=g[g.cell==control]
            interval=block_contrast(g,control)
            a=paired_strata(g,control,['symbol','year'])
            b=paired_strata(g,control,['symbol','year','market_regime'])
            rows.append({'panel':panel,'frame':frame,'control':control,
                         'joint_events':len(treated),'control_events':len(ctrl),
                         'joint_beta_spread_mean':float(treated.beta_spread.mean()),
                         'control_beta_spread_mean':float(ctrl.beta_spread.mean()),
                         'naive_difference':float(treated.beta_spread.mean()-ctrl.beta_spread.mean()),
                         'block_low':interval.get('low'),'block_high':interval.get('high'),
                         'block_status':interval['interval'],
                         'matched_stock_year_n':len(a),'matched_stock_year_mean_difference':float(a.difference.mean()) if len(a) else None,
                         'matched_stock_year_regime_n':len(b),
                         'matched_stock_year_regime_difference':float(b.difference.mean()) if len(b) else None,
                         'source_status':'exploratory historical, no claim of conditional causality'})
            if len(a):
                t=a.copy();t['panel']=panel;t['frame']=frame;t['control']=control;t['matching']='symbol_year'
                strata.append(t)
            if len(b):
                t=b.copy();t['panel']=panel;t['frame']=frame;t['control']=control;t['matching']='symbol_year_regime'
                strata.append(t)
    output=pd.DataFrame(rows)
    output.to_csv(ROOT/'results/V23_CONTRASTS.csv',index=False)
    # Unmatched cells are never filled with zero. Since control column names differ,
    # concatenate with union schema and explicit keys.
    pd.concat(strata,ignore_index=True).to_csv(ROOT/'results/V23_MATCHED_STRATA.csv',index=False)
    meta={'original_v22_events':len(d),'comparisons':len(output),'no_new_bars':True,'no_strategy_optimization':True,'past_2018_2026_not_holdout':True,'monthly_outcome_selection_adjustment':'NOT_PERFORMED'}
    (ROOT/'results/V23_VERIFICATION.json').write_text(json.dumps(meta,indent=2))
    print('V23_PRIMARY',output.query("panel=='CORE5' and frame=='1D'").round(6).to_json(orient='records'))
    print('V23_PEERS',output.query("panel=='PEERS13' and frame=='1D'").round(6).to_json(orient='records'))
    print('VERIFICATION',json.dumps(meta))
if __name__=='__main__':run()
