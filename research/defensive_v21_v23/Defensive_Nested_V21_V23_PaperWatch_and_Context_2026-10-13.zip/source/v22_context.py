"""V22 all-eligible fresh RSI-MACD crossovers: recent W+2W context and
beta-adjusted 20-to-63 owned-session cross-sectional recovery.
No additional signals, new market data, fitted parameters or brokerage.
"""
from pathlib import Path
import sys,json
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[2]
THIS=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source'))
import v12_engine as inputs
CORE=['MCD','WMT','WM','COST','PG']
PEERS=['RSG','KO','PEP','CL','CHD','KMB','MDLZ','HSY','CLX','JNJ','ADP','CTAS','KR']
NATIVE_STOCKS=CORE+PEERS
def beta_series(stock,spy):
 if not stock.index.equals(spy.index):raise ValueError('Unaligned price dates')
 a=np.log(stock.astype(float)).diff()
 b=np.log(spy.astype(float)).diff()
 denom=b.rolling(252,min_periods=200).var(ddof=1).shift(1)
 num=a.rolling(252,min_periods=200).cov(b).shift(1)
 ratio=num/denom.where(denom>=1e-12)
 return ratio
def manual_beta_before(stock,spy,i):
 if not stock.index.equals(spy.index):raise ValueError('Unaligned price dates')
 a=np.log(stock).diff().iloc[max(0,i-252):i]
 b=np.log(spy).diff().iloc[max(0,i-252):i]
 good=np.isfinite(a)&np.isfinite(b)
 if good.sum()<200:return np.nan
 x=a[good].to_numpy(float);y=b[good].to_numpy(float)
 if np.var(y)<1e-12:return np.nan
 return float(np.cov(x,y,ddof=0)[0,1]/np.var(y))
def residual(stock,spy,beta,signal_i,start_i,end_i):
 if not stock.index.equals(spy.index) or signal_i>=start_i or start_i>=end_i or end_i>=len(stock):raise ValueError('Clock/alignment')
 if not np.isfinite(beta):return np.nan
 return float(np.log(stock.iloc[end_i]/stock.iloc[start_i])-beta*np.log(spy.iloc[end_i]/spy.iloc[start_i]))
def pair_year(d):
 x=d[d.cell.isin(['JOINT','NEITHER'])]
 if x.duplicated(['symbol','year','cell']).any():
  y=x.groupby(['symbol','year','cell']).residual.mean().unstack('cell')
 else:y=x.set_index(['symbol','year','cell']).residual.unstack('cell')
 out=y.dropna(subset=['JOINT','NEITHER']).reset_index()
 out['difference']=out['JOINT']-out['NEITHER']
 return out
def quarter_ci(df,reps=4000,block=4):
 x=df[df.cell.isin(['JOINT','NEITHER'])].copy()
 if x.empty:return {'interval':None}
 x['q']=pd.to_datetime(x.signal_date).dt.to_period('Q')
 years=pd.period_range(x.q.min(),x.q.max(),freq='Q')
 stats={}
 for cell in ['JOINT','NEITHER']:
  group=x[x.cell==cell].groupby('q').residual.agg(['sum','count']).reindex(years,fill_value=0)
  stats[cell]=(group['sum'].to_numpy(),group['count'].to_numpy())
 active={k:int((v[1]>0).sum()) for k,v in stats.items()}
 if min(active.values())<8:return {'interval':None,'active_quarters':active}
 rng=np.random.default_rng(221013)
 n=len(years);start=rng.integers(0,n,size=(reps,int(np.ceil(n/block))))
 idx=((start[:,:,None]+np.arange(block))%n).reshape(reps,-1)[:,:n]
 a,ac=stats['JOINT'];b,bc=stats['NEITHER']
 ad=a[idx].sum(axis=1);an=ac[idx].sum(axis=1);bd=b[idx].sum(axis=1);bn=bc[idx].sum(axis=1)
 valid=(an>0)&(bn>0);vals=ad[valid]/an[valid]-bd[valid]/bn[valid]
 return {'interval':'exploratory_unadjusted','low':float(np.quantile(vals,.025)),'high':float(np.quantile(vals,.975)),'active_quarters':active,'replicates':len(vals)}
def run():
 original=pd.read_csv(ROOT/'v11_published/results/signal_state_events.csv')
 assert len(original)==2771
 stock_prices={s:inputs.load_daily(s).close for s in NATIVE_STOCKS+['SPY']}
 spy=stock_prices['SPY'];ix=spy.index
 assert all(x.index.equals(ix) for x in stock_prices.values())
 betas={s:beta_series(stock_prices[s],spy) for s in NATIVE_STOCKS}
 # Sanity check spot values against prior unvectorized exact calculator.
 for sym in ['MCD','WMT','PG','CLX']:
  for i in [2050,2900,4000]:
   est=betas[sym].iloc[i];ind=manual_beta_before(stock_prices[sym],spy,i)
   assert abs(est-ind)<1e-9,(sym,i,est,ind)
 new=[];errs=[]
 for row in original.itertuples():
  sig=int(ix.get_loc(pd.Timestamp(row.signal_date)));entry=sig+1
  assert str(ix[entry].date())==row.entry_date
  dest=int(ix.get_loc(pd.Timestamp(row.exit_date)))
  source_net=float(stock_prices[row.symbol].iloc[dest]/inputs.load_daily(row.symbol).open.iloc[entry]*.9995/1.0005-1) if False else None
  # Original V11 126-entry-session result is reconciled using already cached inputs
  if dest<entry+125:raise ValueError('Truncated source event')
  start=entry+19;end=entry+62
  if end>=len(ix):raise ValueError('Unexpected incomplete crossover source')
  group=CORE if row.panel=='CORE5' else PEERS
  others=[s for s in group if s!=row.symbol]
  sp_seg=float(np.log(spy.iloc[end]/spy.iloc[start]))
  selected=residual(stock_prices[row.symbol],spy,betas[row.symbol].iloc[sig],sig,start,end)
  peermean=float(np.mean([residual(stock_prices[s],spy,betas[s].iloc[sig],sig,start,end) for s in others]))
  net=selected-peermean
  raw=float(np.log(stock_prices[row.symbol].iloc[end]/stock_prices[row.symbol].iloc[start])-np.mean([np.log(stock_prices[s].iloc[end]/stock_prices[s].iloc[start]) for s in others]))
  new.append({'symbol':row.symbol,'panel':row.panel,'frame':row.frame,'cell':row.cell,'signal_date':row.signal_date,'entry_date':row.entry_date,'year':int(pd.Timestamp(row.signal_date).year),'market_regime':row.market_regime,'beta_spread':net,'raw_log_spread':raw,'residual':net,'spy_segment_log':sp_seg,'beta_selected':float(betas[row.symbol].iloc[sig]),'selected_net_from_v11':float(row.net)})
 d=pd.DataFrame(new)
 assert len(d)==len(original) and not d[['beta_spread','raw_log_spread','beta_selected']].isna().any().any()
 d.to_csv(THIS/'results/V22_ALL_CROSS_EVENTS.csv',index=False)
 out=[];contrasts=[]
 for (panel,frame,cell),g in d.groupby(['panel','frame','cell']):
  out.append({'panel':panel,'frame':frame,'cell':cell,'n':len(g),'mean_beta_residual_spread':float(g.beta_spread.mean()),'mean_raw_log_spread':float(g.raw_log_spread.mean()),'positive_relative':float((g.beta_spread>0).mean()),'unique_quarters':pd.to_datetime(g.signal_date).dt.to_period('Q').nunique(),'mean_selected_beta':float(g.beta_selected.mean())})
 for (panel,frame),g in d.groupby(['panel','frame']):
  base=g[g.cell=='JOINT'];other=g[g.cell=='NEITHER'];k=quarter_ci(g)
  paired=pair_year(g)
  yr=pd.to_datetime(g.signal_date).dt.year
  lo=[float(g[(yr!=y)&(g.cell=='JOINT')].beta_spread.mean()-g[(yr!=y)&(g.cell=='NEITHER')].beta_spread.mean()) for y in sorted(yr.unique())]
  contrasts.append({'panel':panel,'frame':frame,'n_joint':len(base),'n_neither':len(other),'mean_joint':float(base.beta_spread.mean()),'mean_neither':float(other.beta_spread.mean()),'difference_joint_minus_neither':float(base.beta_spread.mean()-other.beta_spread.mean()),'interval_low':k.get('low'),'interval_high':k.get('high'),'matched_stock_year_strata':len(paired),'matched_stock_year_mean_difference':float(paired.difference.mean()) if len(paired) else None,'leave_year_min':min(lo),'leave_year_max':max(lo),'active_quarters':k.get('active_quarters')})
 pd.DataFrame(out).to_csv(THIS/'results/V22_CELLS.csv',index=False)
 pd.DataFrame(contrasts).to_csv(THIS/'results/V22_CONTRASTS.csv',index=False)
 m={'source_cross_events':len(original),'calculation_events':len(d),'all_original_1D_2D_crosses_represented':True,'method':'stock beta known from preceding252 sessions, 20th-close to63rd-close selected minus other core/peer group stock residual','no_new_vendor_data':True,'no_live_position':True,'not_adjusted_for_history_or_experiment_family':True}
 (THIS/'results/VERIFICATION.json').write_text(json.dumps(m,indent=2))
 print('V22_CELLS',pd.DataFrame(out).round(6).to_json(orient='records'))
 print('V22_CONTRAST',pd.DataFrame(contrasts).round(6).to_json(orient='records'))
 print('VERIFICATION',json.dumps(m))
if __name__=='__main__':run()
