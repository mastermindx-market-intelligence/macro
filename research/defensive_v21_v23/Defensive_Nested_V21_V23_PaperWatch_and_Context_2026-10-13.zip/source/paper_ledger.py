"""V21 historical as-of 2026-10-08, paper-only watch ledger.
Native price bars exactly the previously inspected V12 accepted source; no
network, no live quote, no broker, no trade execution, no prospective claim.
"""
from pathlib import Path
import sys,json
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[2]
THIS=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source'))
sys.path.insert(0,str(ROOT/'v11_published/source'))
import v12_engine as v
import empirical as e
STOCKS=e.STOCKS
ASOF='2026-10-08'
def can_mark_filled(signal_i,n):
 return signal_i is not None and signal_i+1<n
def classify(last_watch,n):
 if last_watch is None or last_watch.get('end_i')!=n:return {'state':'NO_ACTIVE_WATCH'}
 sig=last_watch.get('signal_i')
 if sig is not None and (sig<0 or sig>=n):raise ValueError('Signal index exceeds observed cutoff')
 if sig is None:return {'state':'WATCH_ACTIVE_UNTRIGGERED'}
 if sig==n-1:return {'state':'LAST_BAR_CROSS_UNFILLED'}
 if can_mark_filled(sig,n):return {'state':'WATCH_FIRED_EARLIER'}
 raise ValueError('Inconsistent signal state')
def run():
 out=[];primary=[]
 expected=pd.read_csv(ROOT/'results/frozen_watch_schedule.csv')
 completed_v11=0;reconciled=0
 for sym in STOCKS:
  d=v.load_daily(sym);ix=d.index;calendar=ix.append(pd.DatetimeIndex(v.CALENDAR_TAIL))
  assert str(ix[-1].date())==ASOF
  trigger={}
  for frame in ['1D','2D']:
   trigger[frame]=e.snapshots(d.close,calendar,frame,'confirmed',0)
  for mode in ['confirmed','developing']:
   w,b,context=e.feature_context(d,calendar,mode=mode,phase=0,warmup=200)
   for frame in ['1D','2D']:
    lo=trigger[frame]
    watches=e.episodes(context,b.k.to_numpy(float),lo.bull.to_numpy(bool),start_i=int(ix.searchsorted('2018-01-01')))
    last=watches[-1] if watches else None
    c=classify(last,len(ix))
    sig=None if last is None else last['signal_i']
    rec={'symbol':sym,'frame':frame,'context_mode':mode,'asof':ASOF,'cutoff_stale_on_authored_date':'2026-10-13','past_watch_count':len(watches),
      'last_arm':str(ix[last['arm_i']].date()) if last is not None else None,
      'last_arm_days_ago':int(len(ix)-1-last['arm_i']) if last is not None else None,
      'last_signal':str(ix[sig].date()) if sig is not None else None,
      'asof_state':c['state'],'current_joint_context':bool(context[-1]),
      'weekly_k':float(w.k.iloc[-1]) if pd.notna(w.k.iloc[-1]) else None,
      'two_week_k':float(b.k.iloc[-1]) if pd.notna(b.k.iloc[-1]) else None,
      'weekly_recent3_min':float(w.recent3.iloc[-1]) if pd.notna(w.recent3.iloc[-1]) else None,
      'two_week_recent2_min':float(b.recent2.iloc[-1]) if pd.notna(b.recent2.iloc[-1]) else None,
      'weekly_count':int(w['count'].iloc[-1]),'two_week_count':int(b['count'].iloc[-1]),
      'lower_histogram':float(lo['hist'].iloc[-1]) if pd.notna(lo['hist'].iloc[-1]) else None,
      'lower_fresh':bool(lo['fresh'].iloc[-1]),'lower_new_bull_on_cutoff':bool(lo['bull'].iloc[-1]),
      'following_open_observed':False if sig==len(ix)-1 else None,'chart_parity_verified':False,
      'new_broker_order':False}
    out.append(rec)
    if mode=='confirmed':
      hist=expected[(expected.symbol==sym)&(expected.frame==frame)].sort_values('episode')
      if len(hist)!=len(watches):raise AssertionError(f'Baseline watch count mismatch {sym} {frame}: {len(hist)} vs {len(watches)}')
      for i,(row,watch) in enumerate(zip(hist.itertuples(),watches)):
       if int(row.arm_i)!=watch['arm_i']:raise AssertionError('Arm mismatch '+sym+frame+str(i))
       match=pd.isna(row.signal_i) if watch['signal_i'] is None else float(row.signal_i)==float(watch['signal_i'])
       if not match:raise AssertionError('Signal mismatch '+sym+frame+str(i))
       reconciled+=1
      completed_v11+=len(watches)
      primary.append(rec)
  print('ASOF_LEDGER_DONE',sym,flush=True)
 data=pd.DataFrame(out)
 data.to_csv(THIS/'results/ASOF_2026-10-08_WATCH_LEDGER.csv',index=False)
 core=data[(data.symbol.isin(e.CORE))&(data.context_mode=='confirmed')]
 core.to_csv(THIS/'results/CORE_ASOF_2026-10-08.csv',index=False)
 summary=data.groupby(['context_mode','frame','asof_state']).size().rename('count').reset_index()
 summary.to_csv(THIS/'results/SNAPSHOT_STATUS_COUNTS.csv',index=False)
 record={'stock_count':len(STOCKS),'date':ASOF,'source_sessions':len(ix),'scenarios':len(data),
       'primary_replayed_watches':completed_v11,'V12_watch_rows':len(expected),
       'exact_watch_arms_and_signals_reconciled':reconciled,
       'no_data_beyond_asof':True,'no_live_trade_or_fill_claim':True,
       'current_information_asof_2026_10_13':False,'unverified_user_chart_settings':True}
 assert completed_v11==reconciled==len(expected)
 (THIS/'results/VERIFICATION.json').write_text(json.dumps(record,indent=2))
 print('CORE_LIVE_LAGGED',core[['symbol','frame','asof_state','last_arm','last_signal','weekly_k','two_week_k','lower_new_bull_on_cutoff']].round(3).to_json(orient='records'))
 print('STATE_COUNTS',summary.to_json(orient='records'))
 print('RECONCILIATION',json.dumps(record))
if __name__=='__main__':run()
