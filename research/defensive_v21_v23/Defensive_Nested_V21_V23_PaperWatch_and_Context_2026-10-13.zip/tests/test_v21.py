"""Historical as-of watch ledger, no live signal claims."""
import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import paper_ledger as p
class LedgerTests(unittest.TestCase):
 def test_no_watch(self):
  self.assertEqual(p.classify(None,4217)['state'],'NO_ACTIVE_WATCH')
 def test_exact_final_signal_is_not_filled(self):
  x={'arm_i':4190,'end_i':4217,'signal_i':4216}
  z=p.classify(x,4217)
  self.assertEqual(z['state'],'LAST_BAR_CROSS_UNFILLED')
 def test_signal_older_is_not_new_trade(self):
  x={'arm_i':4190,'end_i':4217,'signal_i':4215}
  self.assertEqual(p.classify(x,4217)['state'],'WATCH_FIRED_EARLIER')
 def test_watch_without_cross_is_waiting(self):
  x={'arm_i':4190,'end_i':4217,'signal_i':None}
  self.assertEqual(p.classify(x,4217)['state'],'WATCH_ACTIVE_UNTRIGGERED')
 def test_expired_is_not_active(self):
  x={'arm_i':4190,'end_i':4201,'signal_i':4200}
  self.assertEqual(p.classify(x,4217)['state'],'NO_ACTIVE_WATCH')
 def test_future_extreme_does_not_unlock_trade(self):
  x={'arm_i':4210,'end_i':4217,'signal_i':4217}
  with self.assertRaises(ValueError):p.classify(x,4217)
 def test_no_unobserved_current_fill(self):
  self.assertFalse(p.can_mark_filled(4216,4217))
  self.assertTrue(p.can_mark_filled(4215,4217))
if __name__=='__main__':unittest.main(verbosity=2)