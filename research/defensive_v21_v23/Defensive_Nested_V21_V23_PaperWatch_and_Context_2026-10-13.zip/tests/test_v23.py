"""V23 incremental W+2W context comparison, no outcome fitting."""
import unittest,sys
from pathlib import Path
import pandas as pd
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import v23_incremental as z
class Incremental(unittest.TestCase):
 def sample(self):
  return pd.DataFrame([
   ('MCD',2019,'SUPPORTED','JOINT',.20),('MCD',2019,'SUPPORTED','TWO_WEEK_ONLY',.10),
   ('WM',2020,'STRESS_REPAIR','JOINT',.05),('PG',2021,'TRANSITION','TWO_WEEK_ONLY',-.10)
  ],columns=['symbol','year','market_regime','cell','beta_spread'])
 def test_matching_excludes_unpaired(self):
  x=z.paired_strata(self.sample(), 'TWO_WEEK_ONLY',['symbol','year'])
  self.assertEqual(len(x),1);self.assertAlmostEqual(x.difference.iloc[0],.10)
 def test_regime_matching_does_not_mix_regime_cells(self):
  x=z.paired_strata(self.sample(),'TWO_WEEK_ONLY',['symbol','year','market_regime'])
  self.assertEqual(len(x),1)
 def test_diff_asymmetric_sign(self):
  s=self.sample();x=z.paired_strata(s,'TWO_WEEK_ONLY',['symbol','year'])
  self.assertGreater(x.difference.mean(),0.)
 def test_empty_contrast_has_no_fabricated_zero(self):
  s=self.sample();self.assertEqual(len(z.paired_strata(s,'NEITHER',['symbol','year'])),0)
 def test_few_quarters_unknown(self):
  d=pd.DataFrame({'signal_date':['2019-02-01','2019-05-02'],'cell':['JOINT','TWO_WEEK_ONLY'],'beta_spread':[.2,.1]})
  self.assertIsNone(z.block_contrast(d,'TWO_WEEK_ONLY')['interval'])
 def test_future_unrelated_rows_cannot_alter_old_matched_difference(self):
  s=self.sample();a=z.paired_strata(s,'TWO_WEEK_ONLY',['symbol','year']).difference.iloc[0]
  extra=pd.DataFrame([{'symbol':'MCD','year':2028,'market_regime':'SUPPORTED','cell':'JOINT','beta_spread':99.}])
  self.assertEqual(a,z.paired_strata(pd.concat([s,extra]),'TWO_WEEK_ONLY',['symbol','year']).difference.iloc[0])
if __name__=='__main__':unittest.main(verbosity=2)