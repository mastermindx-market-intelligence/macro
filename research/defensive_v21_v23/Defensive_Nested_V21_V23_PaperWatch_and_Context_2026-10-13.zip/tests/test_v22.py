"""V22 same-lower-crossover washout-class contrast, causality tests."""
import unittest,sys
from pathlib import Path
import pandas as pd,numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import v22_context as c
class Context(unittest.TestCase):
 def prices(self):
  ix=pd.bdate_range('2018-01-02',periods=400)
  rg=np.random.default_rng(19);market=rg.normal(0,.01,400)
  spy=pd.Series(np.exp(np.cumsum(market)),index=ix)
  stock=pd.Series(np.exp(np.cumsum(1.2*market+rg.normal(0,.004,400))),index=ix)
  return stock,spy
 def test_beta_rolling_pre_signal_matches_manual(self):
  a,s=self.prices();b=c.beta_series(a,s)
  for i in [250,300,399]:
   self.assertAlmostEqual(b.iloc[i],c.manual_beta_before(a,s,i),places=9)
 def test_beta_prefix_no_future(self):
  a,s=self.prices();x=c.beta_series(a,s)
  a.iloc[330:]*=3.;s.iloc[330:]*=.2
  y=c.beta_series(a,s);self.assertAlmostEqual(x.iloc[329],y.iloc[329],places=9)
 def test_initial_insufficient_is_unknown(self):
  a,s=self.prices();b=c.beta_series(a,s)
  self.assertTrue(np.isnan(b.iloc[100]))
 def test_future_relative_segment_exact(self):
  a,s=self.prices();v=c.residual(a,s,1.,200,219,262)
  self.assertAlmostEqual(v,np.log(a.iloc[262]/a.iloc[219])-np.log(s.iloc[262]/s.iloc[219]))
 def test_clock_invalid_rejected(self):
  a,s=self.prices()
  with self.assertRaises(ValueError):c.residual(a,s,1.,200,270,262)
 def test_matching_does_not_impute_missing(self):
  d=pd.DataFrame({'symbol':['MCD','MCD','WM'],'year':[2018,2018,2018],'cell':['JOINT','NEITHER','JOINT'],'residual':[.10,.04,.20]})
  m=c.pair_year(d)
  self.assertEqual(len(m),1);self.assertAlmostEqual(m.iloc[0].difference,.06)
 def test_only_few_quarters_no_interval(self):
  d=pd.DataFrame({'signal_date':['2020-03-02']*3,'cell':['JOINT','NEITHER','NEITHER'],'residual':[.1,0.,0.]})
  self.assertIsNone(c.quarter_ci(d)['interval'])
 def test_future_context_not_relabelled(self):
  a,s=self.prices();old=c.beta_series(a,s).iloc[300]
  a.iloc[300:]=a.iloc[300:]*10.
  self.assertAlmostEqual(old,c.beta_series(a,s).iloc[300])
if __name__=='__main__':unittest.main(verbosity=2)