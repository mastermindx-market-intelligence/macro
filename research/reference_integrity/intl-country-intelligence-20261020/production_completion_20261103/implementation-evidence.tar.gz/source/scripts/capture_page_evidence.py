#!/usr/bin/env python3
"""Bounded browser evidence capture + UX-smell census for registry-listed pages.

What this is
------------
An *evidence* tool, not a judge and not a crawler. It walks a fixed list of routes
taken from the product page registry (``data/product_experience/page_registry.json``,
schema ``mastermind.page_registry.v1``), loads each one anonymously in a real
browser, screenshots a declared state matrix, and records a set of literally
measurable page facts. It scores nothing, ranks nothing, and labels no page good
or bad — a heuristic here identifies a review target for a human, and that is the
whole of its authority.

Contract
--------
1. **Anonymous only.** No credential is ever entered, synthesized, or read. Free /
   Essential / Pro states are recorded as explicit *gaps* with a reason, never as a
   capture. Because the run is anonymous, no premium payload can enter the
   artifacts by construction.
2. **A state that could not be captured is recorded, never omitted and never
   faked.** Loading/empty/stale/error page states are gaps with a reason; a page
   that 404s or times out is ``captured: false`` with the error text. ``--force-state``
   (opt-in, off by default) can put the *presentation* of one of those states on
   screen by toggling the class or attribute the page's own CSS keys it off — and
   is labelled as exactly that everywhere it appears, because a forced class shows
   the state's styling, not data the page really returned. The gap row stays; it
   flips to ``captured: true`` with the forcing named.
3. **No browser is never a pass.** ``playwright`` is imported lazily inside
   ``playwright_page_driver``; a missing library or chromium binary raises
   ``CaptureUnavailable`` and the CLI exits nonzero with outcome
   ``verifier_unavailable``, writing no artifact over the committed evidence.
4. **The driver is an injected seam** (``PageDriver``). Tests supply an in-memory
   fake; production supplies playwright. Nothing in the test path imports a browser.
5. **Off the render path.** Never wired into CI or the nightly — a render-budget
   law repo does not spend 4 cores on screenshots. Run it locally.
6. **Screenshots are content-addressed and local.** ``evidence/<sha256[:16]>.png``
   is gitignored; only the manifest + smell report (which carry the digests) are
   committed.
7. **A console error names the asset it came from.** Each entry is
   ``{"text": ..., "source_url": ...}`` and every response the page took a 4xx/5xx
   on is listed separately in ``failed_responses``. The 2026-08 census recorded a
   bare ``"401"`` on 12 of 13 P0 pages and could not say which request produced
   it — an unattributable error is a dead end for the human who has to fix it.
   **Evidence outlives the load.** A page that 401s and then times out settling is
   exactly the page this exists for, so console errors and failed responses are
   carried out of a failed observation and harvested before any state is skipped.
8. **No subprocess, no directory enumeration, anywhere in this module.** Both are
   statically opaque edges, and ``scripts/ci_scope_dependencies.py`` widens a
   module carrying one to every ``data/**`` path it mentions — which re-reds the
   ci_pack narrow-diff contract through the ``product-experience-capture`` job.
   ``_git_head_sha`` therefore reads ``.git`` by hand and the self-check tracks
   the files it wrote instead of globbing for them. The tradeoff is real and is
   stated where it applies (``self_check``): a write ledger cannot see a file the
   manifest never names, which a glob could.
9. **Provenance is named, never asserted.** ``_git_head_sha`` reports the git
   directory that answered alongside the sha, and the manifest prints both — the
   walk finds the *nearest* ``.git`` above ``--site-dir``, which is not proof that
   that checkout produced the directory being served.
10. **Timing numbers are lab numbers.** ``timing_basis`` is ``"lab"`` in every
   manifest: LCP, CLS, the INP proxy and resource timing are measured inside this
   local, anonymous, synthetic-viewport capture and are never numbers from real
   users. A value the driver could not observe is ``null``, never a zero.

Locale/theme are applied the way the site's own toggle applies them
(``templates/theme.js``): ``setTheme`` sets ``data-theme`` on ``<html>`` and
persists ``localStorage.theme`` while clearing ``themeAuto``; ``setLang`` sets
``data-lang``, syncs ``documentElement.lang``, and persists ``localStorage.lang``.
Both are seeded pre-navigation *and* re-applied post-load through the page's own
``window.setTheme`` / ``window.setLang`` when present, and the state actually
observed on ``<html>`` is written back into the manifest.

Usage::

    python3 scripts/capture_page_evidence.py --self-check
    python3 scripts/capture_page_evidence.py --site-dir site --priority P0 --repo macro
    python3 scripts/capture_page_evidence.py --base-url https://www.mastermind-x.com \\
        --routes /index.html --viewports desktop --themes light,dark --max-pages 1
    python3 scripts/capture_page_evidence.py --site-dir site --routes /macro.html \\
        --force-state "empty:.is-empty" --force-state "error:[data-state=error]"
    python3 scripts/capture_page_evidence.py --site-dir site --routes /macro.html \\
        --viewports narrow-320,tablet-768
"""

from __future__ import annotations

import argparse
import functools
import hashlib
import http.server
import json
import os
import re
import socketserver
import struct
import sys
import tempfile
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Mapping, Protocol, Sequence

MODULE_REF = "scripts/capture_page_evidence.py"
# 1.1.0: attributed console errors, failed_responses, honest --routes selection.
# 1.2.0: failed-load evidence is kept, and target gains resolved_gitdir_or_none.
# 1.3.0: force_state can capture real hover/focus interaction states by selector.
# 1.4.0: per-cell lab timing block (LCP / CLS / INP proxy / resource timing) with
#        a manifest-wide timing_basis, plus the narrow-320 and tablet-768 viewports.
# This is stamped into every artifact as provenance, so it moves whenever the
# emitted shape does — two byte-different manifests must never claim one version.
TOOL_VERSION = "1.4.0"

# v2: a console error carries the asset it came from, and a page carries the
# responses that failed. v1 recorded bare error strings, which the census could
# not attribute to anything.
MANIFEST_SCHEMA = "mastermind.p0_evidence.v2"
SMELL_SCHEMA = "mastermind.ux_smell_report.v1"
REGISTRY_SCHEMA = "mastermind.page_registry.v1"

DEFAULT_REGISTRY = "data/product_experience/page_registry.json"
DEFAULT_OUTPUT_DIR = "data/product_experience/evidence"
DEFAULT_MANIFEST = "data/product_experience/p0_evidence_manifest.json"
DEFAULT_SMELLS = "data/product_experience/ux_smell_report.json"

# A census identifies itself. This is not a crawler: it follows no link, obeys a
# hard page cap, sleeps between loads, and only ever requests registry routes.
USER_AGENT = "mastermind-page-census/1.0 (internal product observability)"

# narrow-320 and tablet-768 exist for the latency-release program's small-screen
# evidence cells. They are opt-in keys, never part of the default --viewports
# triple, so a default run's axes stay byte-identical to what they always were.
# The program design names widths only; the heights are the B23 fallback pair
# (720 / 1024) because no design line states otherwise.
VIEWPORTS: Mapping[str, tuple[int, int]] = {
    "desktop": (1440, 900),
    "tablet": (820, 1180),
    "mobile": (390, 844),
    "narrow-320": (320, 720),
    "tablet-768": (768, 1024),
}
SUPPORTED_LOCALES: tuple[str, ...] = ("en", "zh")
SUPPORTED_THEMES: tuple[str, ...] = ("light", "dark")

# Every timing number this tool records is a LAB number: measured in this local,
# anonymous, synthetic-viewport capture, never telemetry from real users. The
# manifest declares the basis once, and a value the driver could not observe is
# null — never a synthesized 0.
TIMING_BASIS = "lab"
# inp_proxy_ms is the max Event Timing duration among the interactions the driver
# actually scripted (the force-state hover/focus calls); null when there were
# none. server_timing travels as the raw list the Performance API reported.
TIMING_KEYS: tuple[str, ...] = (
    "lcp_ms",
    "cls",
    "inp_proxy_ms",
    "resource_count",
    "transfer_bytes",
    "server_timing",
)

ACCESS_ANONYMOUS = "anonymous"
GATED_ACCESS_STATES: tuple[str, ...] = ("free", "essential", "pro")
GATED_ACCESS_REASON = "requires authenticated session; not automatable without approved fixtures"
SYNTHETIC_PAGE_STATES: tuple[str, ...] = ("loading", "empty", "stale", "error")
SYNTHETIC_PAGE_STATE_REASON = "state not synthesizable against static output"

# Forced presentation states (opt-in, --force-state). A migration packet must ship
# loading/empty/stale/error shots, and against static output the DATA path cannot
# be driven — but the PRESENTATION usually can, because the estate keys those
# states off a class or a data-attribute. So this forces the hook and says so: the
# capture is labelled a forced presentation in the state row, in the gap row, and
# in the file name, and never claims the page's own data path ran.
FORCE_STATE_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9_-]*$")
FORCE_STATE_CLASS_RE = re.compile(r"^\.?([A-Za-z_-][A-Za-z0-9_-]*)$")
FORCE_STATE_ATTR_RE = re.compile(r"""^\[([A-Za-z_:][-A-Za-z0-9_:.]*)(?:=["']?([^"'\]]*)["']?)?\]$""")
FORCE_STATE_INTERACTION_RE = re.compile(r"^(hover|focus)\((.+)\)$", re.DOTALL)
FORCE_STATE_SYNTAX = (
    'expected NAME:TARGET, where NAME is a lowercase slug (it becomes a file-name '
    'suffix) and TARGET is a class (".is-empty" or "is-empty"), an attribute '
    'selector ("[data-state=empty]" or "[data-empty]"), or a real browser '
    'interaction ("hover(.factor-cell)" or "focus(.search-trigger)")'
)
FORCE_STATE_REASON = (
    "captured by forced presentation; the page's own data path was not exercised, "
    "so the shot shows this state's styling, not content the page really returned"
)

# A family row stands for many concrete URLs (per-ticker analyzers, per-slug
# dossiers). Capturing "the family" is meaningless, so a family is skipped unless
# the registry row names one concrete exemplar to stand in for it.
FAMILY_ROUTE_KINDS = frozenset({"family", "template", "pattern", "dynamic", "parameterized"})
EXEMPLAR_FIELDS: tuple[str, ...] = ("exemplar_route", "exemplar_url", "exemplar")
_ROUTE_PLACEHOLDERS: tuple[str, ...] = ("{", "<", "*", "/:")

# --routes replaces registry selection wholesale, so the parser's --priority /
# --repo defaults describe a filter that never ran. Recording them anyway is how a
# terminal manifest came to claim repo "macro" while capturing app.mastermind-x.com.
ROUTES_SELECTION_NOTE = (
    "--routes overrode registry selection; the --priority and --repo filters were not applied"
)

OUTCOME_CAPTURED = "captured"
OUTCOME_PARTIAL = "partial"
OUTCOME_UNAVAILABLE = "verifier_unavailable"

EXIT_OK = 0
EXIT_USAGE = 2
EXIT_PARTIAL = 3
EXIT_UNAVAILABLE = 4

INSTALL_HINT = (
    "python3 -m pip install playwright && python3 -m playwright install chromium"
)

# Every probe below is APPROXIMATE and says so in the report. They exist to point a
# human at a page, never to decide anything about it.
DEFAULT_OBSERVER_CONFIG: Mapping[str, Any] = {
    # Class-name heuristics: this estate has no single panel component, so a
    # "panel" is whatever looks like one. Over- and under-counts are expected.
    "panel_selectors": [".card", ".panel", "[class*='card']"],
    "long_paragraph_words": 120,
    "asof_probe": {
        "selectors": ["[data-asof]", ".asof", ".freshness"],
        "text_patterns": ["as of", "数据截至"],
    },
    "source_probe": {
        "selectors": ["[data-source]", ".source", ".provenance", "[data-src]"],
        "text_patterns": ["source:", "来源", "数据来源"],
    },
    # Distinct-match lists are capped so a committed artifact stays bounded.
    "max_hit_samples": 25,
}

METRIC_KEYS: tuple[str, ...] = (
    "document_height_px",
    "section_count",
    "heading_counts",
    "duplicate_heading_texts",
    "panel_count",
    "visible_word_count",
    "long_paragraph_count",
    "raw_slug_hits",
    "raw_slug_hit_count",
    "todo_placeholder_hits",
    "todo_placeholder_hit_count",
    "horizontal_overflow",
    "elements_wider_than_viewport",
    "console_error_count",
    "request_count",
    "payload_bytes_total",
    "asof_present",
    "source_present",
    "screenshot_completion",
)

METRIC_NOTES: Mapping[str, str] = {
    "section_count": "direct <section> children of <body> plus direct element children of <main>; an approximation of 'how many blocks is this page'",
    "panel_count": "class-name heuristic over the configured selector list; both over- and under-counts are expected",
    "visible_word_count": "whitespace-split innerText of <body>; Chinese text is not word-segmented, so a zh capture undercounts relative to en",
    "raw_slug_hits": "visible text matching 3+ segment snake_case; legitimate identifiers (file names, API keys quoted on purpose) match too",
    "duplicate_heading_texts": "case-folded visible heading text seen more than once; a repeated section label across tabs is a legitimate duplicate",
    "asof_present": "approximate contract probe (selector OR case-insensitive text pattern); absence is a prompt to look, not a verdict",
    "source_present": "approximate contract probe (selector OR case-insensitive text pattern); absence is a prompt to look, not a verdict",
    "payload_bytes_total": "sum of response body sizes reported by the driver for the reference state; excludes bodies the driver could not size",
    "console_error_count": "distinct console 'error' texts across every state of the page the driver attempted, captured or not — a state that failed to load is often the one carrying the evidence",
    "screenshot_completion": "captured states / attempted states for this page; states the registry excludes are not attempted and are recorded as gaps",
}

MD_DISCLAIMER = (
    "Heuristics identify review targets; they do not determine that a page is bad."
)


class CaptureUnavailable(RuntimeError):
    """No real browser is reachable. Never downgraded to a successful capture."""


class RegistryError(RuntimeError):
    """The page registry is missing or unreadable. Reported cleanly, never traced."""


@dataclass(frozen=True)
class ForceState:
    """One forced presentation state: a label plus the hook that turns it on."""

    name: str
    kind: str  # "class" | "attribute" | "hover" | "focus"
    value: str  # class/attribute value, or the CSS selector for an interaction
    attribute: str | None = None
    spec: str = ""  # the raw CLI token, echoed into the manifest verbatim

    def as_payload(self) -> dict[str, Any]:
        """The shape handed to the browser and written into the manifest axes."""

        return {
            "name": self.name,
            "kind": self.kind,
            "value": self.value,
            "attribute": self.attribute,
            "spec": self.spec,
        }


def parse_force_state(raw: str) -> ForceState:
    """Parse one ``NAME:TARGET`` token, or raise with the syntax spelled out."""

    token = raw.strip()
    # partition() splits on the FIRST colon only, so a target may contain one.
    name, separator, target = token.partition(":")
    name = name.strip().lower()
    target = target.strip()
    if not separator or not name or not target:
        raise argparse.ArgumentTypeError(f"--force-state {token!r}: {FORCE_STATE_SYNTAX}")
    if not FORCE_STATE_NAME_RE.match(name):
        raise argparse.ArgumentTypeError(f"--force-state {token!r}: {name!r} is not a usable name; {FORCE_STATE_SYNTAX}")
    attribute = FORCE_STATE_ATTR_RE.match(target)
    if attribute is not None:
        # A bare ``[data-empty]`` sets the attribute to "", which is exactly how a
        # boolean HTML attribute is spelled.
        return ForceState(
            name=name, kind="attribute", value=attribute.group(2) or "", attribute=attribute.group(1), spec=token
        )
    interaction = FORCE_STATE_INTERACTION_RE.match(target)
    if interaction is not None:
        selector = interaction.group(2).strip()
        if not selector:
            raise argparse.ArgumentTypeError(
                f"--force-state {token!r}: interaction selector is empty; {FORCE_STATE_SYNTAX}"
            )
        return ForceState(
            name=name, kind=interaction.group(1), value=selector, attribute=None, spec=token
        )
    css_class = FORCE_STATE_CLASS_RE.match(target)
    if css_class is not None:
        return ForceState(name=name, kind="class", value=css_class.group(1), attribute=None, spec=token)
    raise argparse.ArgumentTypeError(
        f"--force-state {token!r}: {target!r} is not a class, attribute, hover(), or focus() target; "
        f"{FORCE_STATE_SYNTAX}"
    )


def parse_force_states(raw_values: Sequence[str]) -> tuple[ForceState, ...]:
    """Parse every ``--force-state``. A repeated NAME is an error, not last-wins."""

    parsed: list[ForceState] = []
    seen: dict[str, str] = {}
    for raw in raw_values:
        state = parse_force_state(raw)
        if state.name in seen:
            raise argparse.ArgumentTypeError(
                f"--force-state {state.name!r} was given twice ({seen[state.name]!r} and "
                f"{state.spec!r}); one name is one file-name suffix, so the second would "
                "silently overwrite the first"
            )
        seen[state.name] = state.spec
        parsed.append(state)
    return tuple(parsed)


@dataclass(frozen=True)
class CaptureCell:
    """One capture cell: a page plus the exact state to put it in."""

    page_id: str
    route: str
    viewport: str
    width: int
    height: int
    locale: str
    theme: str
    access: str = ACCESS_ANONYMOUS
    force_state: ForceState | None = None

    @property
    def cell_id(self) -> str:
        base = f"{self.page_id}|{self.viewport}|{self.locale}|{self.theme}|{self.access}"
        # The rest state keeps its historical id; only a forced cell is suffixed, so
        # adding this feature renamed no cell that already existed.
        return base if self.force_state is None else f"{base}|{self.force_state.name}"


@dataclass(frozen=True)
class CellObservation:
    """Exactly what the driver saw in one cell. Nothing here is a judgement."""

    cell_id: str
    loaded: bool
    error: str | None = None
    screenshot_png: bytes = b""
    observed: Mapping[str, Any] = field(default_factory=dict)
    # ``{"text": str, "source_url": str | None}`` — an error nobody can attribute
    # to an asset is a dead end, so the source URL travels with the text and is
    # null only when the driver genuinely had none (a pageerror has no location).
    console_errors: tuple[Mapping[str, Any], ...] = ()
    # ``{"url": str, "status": int}`` for every response the page took a 4xx/5xx
    # on. This is what turns a bare "401" console line into a named request.
    failed_responses: tuple[Mapping[str, Any], ...] = ()
    request_count: int = 0
    payload_bytes_total: int = 0
    applied_theme: str | None = None
    applied_locale: str | None = None
    # The forced state the driver could actually confirm on the element, or None.
    # A page that strips the hook is disclosed, never filed under a state it never
    # entered — the same discipline the theme/locale mismatch gap already applies.
    applied_force_state: str | None = None
    # Lab timing the driver observed for this cell (TIMING_KEYS), or None when the
    # driver cannot observe timing at all. Absence is honest: it serializes as
    # nulls, never as zeros, and it is never filled in from anything else.
    timing: Mapping[str, Any] | None = None


class PageDriver(Protocol):
    """The injected observer seam. Tests supply a fake; production supplies playwright."""

    def capture(
        self, *, url: str, cell: CaptureCell, timeout_s: float
    ) -> CellObservation:  # pragma: no cover - protocol
        ...


# ---------------------------------------------------------------------------
# serialization helpers
# ---------------------------------------------------------------------------


def canonical_json_bytes(payload: Mapping[str, Any]) -> bytes:
    """Serialize deterministically so two runs with the same --as-of are byte-equal."""

    return (
        json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2, separators=(",", ": "))
        + "\n"
    ).encode("utf-8")


def module_source_sha256() -> str:
    return hashlib.sha256(Path(__file__).resolve().read_bytes()).hexdigest()


def _utc_now() -> str:
    return datetime.now(tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _png_dimensions(png: bytes) -> tuple[int, int] | None:
    """Read width/height out of the PNG IHDR — no image library, no dependency."""

    if len(png) < 24 or png[:8] != b"\x89PNG\r\n\x1a\n" or png[12:16] != b"IHDR":
        return None
    width, height = struct.unpack(">II", png[16:24])
    return int(width), int(height)


def _is_hex_sha(value: str) -> bool:
    return len(value) == 40 and all(char in "0123456789abcdef" for char in value.lower())


def _read_text(path: Path) -> str | None:
    """One known path, read or not. No enumeration, no subprocess — see docstring §8.

    ``ValueError`` is caught alongside ``OSError`` because ``Path.read_text``
    raises it *before* any syscall when the path carries an embedded NUL — and the
    ref name handed to this function comes verbatim out of a ``.git/HEAD`` that may
    be half-written. Anything unexpected returns None, as advertised.
    """

    try:
        return path.read_text(encoding="utf-8", errors="ignore").strip()
    except (OSError, ValueError):
        return None


# Only these ref namespaces are per-worktree; everything else — ``refs/heads/*``
# above all — lives in the common dir and MUST be resolved from there first. The
# inverse order returns a stale or planted sha where git returns the real one.
PER_WORKTREE_REF_PREFIXES: tuple[str, ...] = (
    "refs/bisect/",
    "refs/worktree/",
    "refs/rewritten/",
)


@dataclass(frozen=True)
class GitHeadRead:
    """What the hand-rolled ``.git`` reader resolved, and which git dir answered.

    ``gitdir`` is reported even when ``sha`` is None: naming where the reader
    looked is what makes the manifest's provenance line auditable rather than
    asserted.
    """

    sha: str | None
    gitdir: Path | None


def _git_head_sha(start: Path) -> GitHeadRead:
    """Resolve HEAD by reading ``.git`` by hand. Best-effort, never guessed.

    ``git rev-parse`` used to do this, but a subprocess is an opaque edge to the CI
    scope analyzer and widens this module's suite to every ``data/**`` path it names.
    The walk is upward because ``--site-dir`` is usually a subdirectory of the
    checkout — and, exactly like git, it is unbounded, so the git directory it
    lands on is *the nearest one above the path* and nothing more. That is why the
    answering gitdir travels back with the sha: the caller must be able to print
    what actually answered instead of claiming a relationship nobody checked.
    Anything unexpected — no ``.git``, a symbolic ref that resolves nowhere,
    content that is not a sha — returns a null sha: this field is provenance, and a
    wrong sha is worse than an honest null.
    """

    gitdir: Path | None = None
    for candidate in (start, *start.parents):
        marker = candidate / ".git"
        if marker.is_dir():
            gitdir = marker
            break
        if marker.is_file():  # linked worktree: ".git" is a pointer file
            pointer = _read_text(marker)
            if not pointer or not pointer.startswith("gitdir:"):
                return GitHeadRead(None, None)
            target = Path(pointer.split(":", 1)[1].strip())
            gitdir = target if target.is_absolute() else marker.parent / target
            break
    if gitdir is None:
        return GitHeadRead(None, None)

    head = _read_text(gitdir / "HEAD")
    if head is None:
        return GitHeadRead(None, gitdir)
    if _is_hex_sha(head):
        return GitHeadRead(head.lower(), gitdir)  # detached HEAD
    if not head.startswith("ref:"):
        return GitHeadRead(None, gitdir)
    ref = head.split(":", 1)[1].strip()

    # A linked worktree keeps its own HEAD but shares refs with the common dir.
    common = gitdir
    pointer = _read_text(gitdir / "commondir")
    if pointer:
        target = Path(pointer)
        common = target if target.is_absolute() else gitdir / target

    per_worktree = ref.startswith(PER_WORKTREE_REF_PREFIXES)
    for base in ((gitdir, common) if per_worktree else (common, gitdir)):
        loose = _read_text(base / ref)
        if loose is not None:
            return GitHeadRead(loose.lower() if _is_hex_sha(loose) else None, gitdir)

    packed = _read_text(common / "packed-refs")
    for line in (packed or "").splitlines():
        line = line.strip()
        if not line or line.startswith(("#", "^")):  # comment / peeled tag
            continue
        sha, _, name = line.partition(" ")
        if name.strip() == ref and _is_hex_sha(sha):
            return GitHeadRead(sha.lower(), gitdir)
    return GitHeadRead(None, gitdir)


def site_dir_target(site_dir: Path) -> dict[str, Any]:
    """The manifest's ``target`` block for ``--site-dir``, claiming only what was read.

    The old text — "git HEAD of the checkout that produced --site-dir" — asserted a
    relationship nothing ever checked: the walk lands on the NEAREST git directory
    at or above the path (git's own rule), which may be a home-directory repo that
    produced none of these files. So the gitdir that answered is printed next to
    the sha and the source line names it. Kept a plain function, not inlined into
    ``main``, so this claim is testable without opening the loopback server.
    """

    head = _git_head_sha(site_dir)
    if head.gitdir is None:
        source = "no git directory was found at or above --site-dir; nothing resolved"
    elif head.sha is None:
        source = (
            "unresolved: HEAD of the nearest git directory at or above --site-dir "
            f"({head.gitdir}) did not read back as a sha"
        )
    else:
        source = (
            f"HEAD of the nearest git directory at or above --site-dir: {head.gitdir} "
            "(nearest-above is git's own rule; that this checkout produced --site-dir "
            "is not verified)"
        )
    return {
        "kind": "site_dir",
        "base_url": None,
        "site_dir": str(site_dir),
        "resolved_sha_or_none": head.sha,
        "resolved_gitdir_or_none": str(head.gitdir) if head.gitdir is not None else None,
        "resolved_sha_source": source,
    }


# ---------------------------------------------------------------------------
# registry selection
# ---------------------------------------------------------------------------


def load_registry(path: Path | str) -> list[dict[str, Any]]:
    """Read the registry another builder owns. Tolerant of its container shape."""

    registry_path = Path(path)
    if not registry_path.exists():
        raise RegistryError(
            f"page registry not found: {registry_path} "
            "(build it with scripts/build_product_page_registry.py, or pass --routes to "
            "capture an explicit list without a registry)"
        )
    try:
        document = json.loads(registry_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise RegistryError(f"page registry is not readable JSON: {registry_path}: {exc}") from exc

    if isinstance(document, list):
        rows: Any = document
    elif isinstance(document, dict):
        schema = document.get("schema")
        if schema and schema != REGISTRY_SCHEMA:
            print(
                f"::warning title=capture-page-evidence::registry schema is {schema!r}, "
                f"expected {REGISTRY_SCHEMA!r}; reading it anyway",
                flush=True,
            )
        rows = document.get("pages") or document.get("rows") or document.get("entries") or []
    else:
        raise RegistryError(f"page registry root must be an object or a list: {registry_path}")

    if not isinstance(rows, list):
        raise RegistryError(f"page registry rows must be a list: {registry_path}")
    return [row for row in rows if isinstance(row, dict)]


def _row_list_field(row: Mapping[str, Any], key: str, allowed: Sequence[str]) -> tuple[str, ...] | None:
    """Read a declared axis (themes/locales). ``None`` means the registry is silent.

    The registry writes the sentinel ``"unknown"`` for an axis it could not resolve,
    so an unresolvable declaration must read as SILENT, never as "supports nothing" —
    the latter would expand to zero cells and hand back a page with no evidence at
    all. Silence attempts every requested axis and records what the page settled on.
    """

    raw = row.get(key)
    if raw is None:
        return None
    if isinstance(raw, str):
        raw = [part.strip() for part in raw.split(",")]
    if not isinstance(raw, (list, tuple)):
        return None
    values = tuple(v for v in (str(item).strip().lower() for item in raw) if v in allowed)
    return values or None


def exemplar_route(row: Mapping[str, Any]) -> str | None:
    for key in EXEMPLAR_FIELDS:
        value = row.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


def is_family_row(row: Mapping[str, Any]) -> bool:
    kind = str(row.get("route_kind") or "").strip().lower()
    if kind in FAMILY_ROUTE_KINDS:
        return True
    route = str(row.get("route") or "")
    return any(token in route for token in _ROUTE_PLACEHOLDERS)


def normalize_row(row: Mapping[str, Any], *, index: int) -> dict[str, Any]:
    route = str(row.get("route") or "").strip()
    page_id = str(row.get("page_id") or "").strip() or (route or f"row_{index}")
    family = is_family_row(row)
    exemplar = exemplar_route(row)
    return {
        "page_id": page_id,
        "route": route,
        "capture_route": exemplar if (family and exemplar) else route,
        "repo": str(row.get("repo") or "").strip().lower(),
        "priority": str(row.get("priority") or "").strip().upper(),
        "route_kind": str(row.get("route_kind") or "").strip().lower(),
        "is_family": family,
        "exemplar": exemplar,
        "themes": _row_list_field(row, "themes", SUPPORTED_THEMES),
        "locales": _row_list_field(row, "locales", SUPPORTED_LOCALES),
    }


def select_rows(
    rows: Sequence[Mapping[str, Any]],
    *,
    priority: str | None,
    repo: str | None,
    max_pages: int,
) -> tuple[list[dict[str, Any]], list[dict[str, str]]]:
    """Pick the rows to capture. Returns (selected, excluded-with-reason)."""

    selected: list[dict[str, Any]] = []
    excluded: list[dict[str, str]] = []
    want_priority = (priority or "").strip().upper()
    want_repo = (repo or "").strip().lower()

    for index, raw in enumerate(rows):
        row = normalize_row(raw, index=index)
        if want_priority and row["priority"] and row["priority"] != want_priority:
            continue
        if want_repo and row["repo"] and row["repo"] != want_repo:
            continue
        if not row["capture_route"]:
            excluded.append({"page_id": row["page_id"], "reason": "row carries no route"})
            continue
        if row["is_family"] and not row["exemplar"]:
            excluded.append(
                {
                    "page_id": row["page_id"],
                    "reason": "route family with no exemplar route; a family stands for many URLs and is not itself capturable",
                }
            )
            continue
        selected.append(row)

    selected.sort(key=lambda row: (row["capture_route"], row["page_id"]))
    if max_pages > 0 and len(selected) > max_pages:
        for row in selected[max_pages:]:
            excluded.append(
                {"page_id": row["page_id"], "reason": f"beyond the --max-pages cap of {max_pages}"}
            )
        selected = selected[:max_pages]
    return selected, excluded


def synthesize_rows(routes: Sequence[str], registry_rows: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    """--routes override: reuse a matching registry row, else synthesize a minimal one.

    Synthesized rows declare no themes/locales, so the requested axes are all
    attempted — the registry is what narrows a page to (say) dark-only.
    """

    by_route: dict[str, dict[str, Any]] = {}
    for index, raw in enumerate(registry_rows):
        row = normalize_row(raw, index=index)
        for key in {row["route"], row["capture_route"]}:
            if key:
                by_route.setdefault(key, row)

    out: list[dict[str, Any]] = []
    seen: set[str] = set()
    for route in routes:
        route = route.strip()
        if not route or route in seen:
            continue
        seen.add(route)
        match = by_route.get(route)
        if match is not None:
            out.append(dict(match))
            continue
        page_id = route.strip("/").replace("/", "_") or "root"
        out.append(
            {
                "page_id": page_id,
                "route": route,
                "capture_route": route,
                "repo": "",
                "priority": "",
                "route_kind": "explicit_override",
                "is_family": False,
                "exemplar": None,
                "themes": None,
                "locales": None,
            }
        )
    return out


# ---------------------------------------------------------------------------
# state matrix
# ---------------------------------------------------------------------------


def state_matrix(
    row: Mapping[str, Any],
    *,
    viewports: Sequence[str],
    locales: Sequence[str],
    themes: Sequence[str],
    force_states: Sequence[ForceState] = (),
) -> tuple[list[CaptureCell], list[dict[str, Any]]]:
    """Expand one row into cells, and record the axes the registry excludes as gaps.

    Forced states multiply the matrix rather than replacing it: every
    viewport/locale/theme yields the page at rest plus one cell per forced state.
    With no ``--force-state`` the matrix is byte-identical to what it always was.
    """

    gaps: list[dict[str, Any]] = []

    declared_locales = row.get("locales")
    declared_themes = row.get("themes")

    use_locales = [loc for loc in locales if declared_locales is None or loc in declared_locales]
    use_themes = [theme for theme in themes if declared_themes is None or theme in declared_themes]

    for locale in locales:
        if locale not in use_locales:
            gaps.append(
                {
                    "dimension": "locale",
                    "value": locale,
                    "captured": False,
                    "reason": f"registry declares locales {sorted(declared_locales or ())} for this page",
                }
            )
    for theme in themes:
        if theme not in use_themes:
            gaps.append(
                {
                    "dimension": "theme",
                    "value": theme,
                    "captured": False,
                    "reason": f"registry declares themes {sorted(declared_themes or ())} for this page",
                }
            )

    cells: list[CaptureCell] = []
    for viewport in viewports:
        width, height = VIEWPORTS[viewport]
        for locale in use_locales:
            for theme in use_themes:
                for force_state in (None, *force_states):
                    cells.append(
                        CaptureCell(
                            page_id=str(row["page_id"]),
                            route=str(row["capture_route"]),
                            viewport=viewport,
                            width=width,
                            height=height,
                            locale=locale,
                            theme=theme,
                            force_state=force_state,
                        )
                    )
    return cells, gaps


def access_and_page_state_gaps(
    forced_page_states: Mapping[str, str] | None = None,
) -> list[dict[str, Any]]:
    """The states this tool refuses to fake. Recorded on every page, always.

    ``forced_page_states`` maps a page-state name to the ``--force-state`` spec that
    ACTUALLY produced a shot for it on this page. Such a state keeps its row here
    rather than disappearing from the ledger: it flips to ``captured: true`` with the
    forcing named, because a forced class is the state's styling and not its data.
    """

    forced = dict(forced_page_states or {})
    gaps: list[dict[str, Any]] = [
        {"dimension": "access", "value": state, "captured": False, "reason": GATED_ACCESS_REASON}
        for state in GATED_ACCESS_STATES
    ]
    for state in SYNTHETIC_PAGE_STATES:
        spec = forced.get(state)
        gaps.append(
            {
                "dimension": "page_state",
                "value": state,
                "captured": False,
                "reason": SYNTHETIC_PAGE_STATE_REASON,
            }
            if spec is None
            else {
                "dimension": "page_state",
                "value": state,
                "captured": True,
                "reason": f"{FORCE_STATE_REASON} (--force-state {spec})",
            }
        )
    return gaps


# ---------------------------------------------------------------------------
# metrics assembly
# ---------------------------------------------------------------------------


def _null_metrics() -> dict[str, Any]:
    """Every metric key present, all null. A page with no capture still has a shape."""

    metrics: dict[str, Any] = {key: None for key in METRIC_KEYS}
    metrics["screenshot_completion"] = 0.0
    metrics["measured_in"] = None
    metrics["by_viewport"] = {}
    return metrics


def _null_timing() -> dict[str, Any]:
    """Every timing key present, all null. An unobserved value is null, not 0."""

    return {key: None for key in TIMING_KEYS}


def _timing_from(observation: CellObservation) -> dict[str, Any]:
    """Copy the six lab timing numbers out of an observation, nulls for the rest.

    Values pass through untouched — a driver's honest 0 stays 0 — and a driver
    that reported no timing at all yields the all-null block. Only server_timing
    is normalized (tuple -> list) so canonical JSON stays deterministic; its
    entries travel exactly as the Performance API shaped them.
    """

    timing = _null_timing()
    reported = observation.timing
    if not reported:
        return timing
    for key in ("lcp_ms", "cls", "inp_proxy_ms", "resource_count", "transfer_bytes"):
        timing[key] = reported.get(key)
    raw_server_timing = reported.get("server_timing")
    # None means "could not observe"; an empty list is an observed empty and must
    # survive as one, so only a genuine None stays null.
    timing["server_timing"] = None if raw_server_timing is None else list(raw_server_timing)
    return timing


def _metrics_from(observed: Mapping[str, Any]) -> dict[str, Any]:
    hits = list(observed.get("raw_slug_hits") or ())
    todos = list(observed.get("todo_placeholder_hits") or ())
    return {
        "document_height_px": observed.get("document_height_px"),
        "section_count": observed.get("section_count"),
        "heading_counts": dict(observed.get("heading_counts") or {}),
        "duplicate_heading_texts": list(observed.get("duplicate_heading_texts") or ()),
        "panel_count": observed.get("panel_count"),
        "visible_word_count": observed.get("visible_word_count"),
        "long_paragraph_count": observed.get("long_paragraph_count"),
        "raw_slug_hits": hits,
        "raw_slug_hit_count": observed.get("raw_slug_hit_count", len(hits)),
        "todo_placeholder_hits": todos,
        "todo_placeholder_hit_count": observed.get("todo_placeholder_hit_count", len(todos)),
        "horizontal_overflow": observed.get("horizontal_overflow"),
        "elements_wider_than_viewport": observed.get("elements_wider_than_viewport"),
        "asof_present": observed.get("asof_present"),
        "source_present": observed.get("source_present"),
    }


def _page_metrics(
    captured: Sequence[tuple[CaptureCell, CellObservation]],
    *,
    attempted: int,
    console_errors: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    metrics = _null_metrics()
    metrics["screenshot_completion"] = round(len(captured) / attempted, 4) if attempted else 0.0
    # The metric note says "distinct console 'error' TEXTS", and it keeps that
    # meaning under attribution: one message emitted by two assets is one text.
    metrics["console_error_count"] = len({str(entry.get("text") or "") for entry in console_errors})
    if not captured:
        return metrics

    # The reference state is the first captured cell in matrix order: one page load
    # is one measurement, so a single blob is reported rather than a blend of six.
    ref_cell, ref_obs = captured[0]
    metrics.update(_metrics_from(ref_obs.observed))
    metrics["request_count"] = ref_obs.request_count
    metrics["payload_bytes_total"] = ref_obs.payload_bytes_total
    metrics["measured_in"] = {
        "viewport": ref_cell.viewport,
        "locale": ref_cell.locale,
        "theme": ref_cell.theme,
        "access": ref_cell.access,
    }

    by_viewport: dict[str, Any] = {}
    for cell, observation in captured:
        if cell.viewport in by_viewport:
            continue
        by_viewport[cell.viewport] = {
            "document_height_px": observation.observed.get("document_height_px"),
            "horizontal_overflow": observation.observed.get("horizontal_overflow"),
            "elements_wider_than_viewport": observation.observed.get("elements_wider_than_viewport"),
        }
    metrics["by_viewport"] = by_viewport
    return metrics


# ---------------------------------------------------------------------------
# capture run
# ---------------------------------------------------------------------------


def screenshot_name(digest: str, state_suffix: str | None = None) -> str:
    """The one place the evidence file-name format lives. Readers reuse it."""

    stem = digest[:16] if not state_suffix else f"{digest[:16]}--{state_suffix}"
    return f"{stem}.png"


def write_screenshot(png: bytes, output_dir: Path, *, state_suffix: str | None = None) -> tuple[Path, str]:
    """Content-address the bytes. Identical states across pages share one file.

    A forced-state shot carries its state name in the file (``<sha>--empty.png``) so
    a reviewer can tell the four required state shots apart in a directory listing
    without opening the manifest. The digest still addresses the bytes.
    """

    digest = hashlib.sha256(png).hexdigest()
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / screenshot_name(digest, state_suffix)
    if not path.exists():
        path.write_bytes(png)
    return path, digest


def page_url(base: str, route: str) -> str:
    if route.startswith(("http://", "https://")):
        return route
    return base.rstrip("/") + "/" + route.lstrip("/")


def run_capture(
    *,
    rows: Sequence[Mapping[str, Any]],
    driver: PageDriver,
    base_url: str,
    output_dir: Path,
    manifest_dir: Path,
    viewports: Sequence[str],
    locales: Sequence[str],
    themes: Sequence[str],
    delay_ms: int,
    timeout_s: float,
    generated_at: str,
    target: Mapping[str, Any],
    excluded: Sequence[Mapping[str, str]] = (),
    selection: Mapping[str, Any] | None = None,
    force_states: Sequence[ForceState] = (),
) -> dict[str, Any]:
    """Drive every cell of every row sequentially. Returns manifest + smell payloads."""

    manifest_pages: list[dict[str, Any]] = []
    smell_pages: list[dict[str, Any]] = []
    # What this run actually wrote, recorded at the call site. The self-check
    # verifies its files from this ledger instead of enumerating the output
    # directory — see the module docstring §8 on why no glob lives here.
    written_pngs: set[str] = set()

    for row in rows:
        cells, axis_gaps = state_matrix(
            row, viewports=viewports, locales=locales, themes=themes, force_states=force_states
        )
        gaps: list[dict[str, Any]] = list(axis_gaps)
        # Which forced states this page actually got a shot for. Filled by the loop
        # and only then turned into gap rows: a page that failed to load forced
        # nothing, and must not claim it did.
        forced_captured: dict[str, str] = {}
        states: list[dict[str, Any]] = []
        captured: list[tuple[CaptureCell, CellObservation]] = []
        # Deduped per page in first-seen order: the same error from two assets is
        # two entries, the same error from one asset in six states is one.
        console_entries: list[dict[str, Any]] = []
        console_seen: set[tuple[str, str | None]] = set()
        failed_responses: list[dict[str, Any]] = []
        failed_seen: set[tuple[str, int]] = set()
        # A route that failed to load once is not hammered five more times; the
        # remaining cells are recorded as not attempted, with the load error.
        page_failure: str | None = None

        for position, cell in enumerate(cells):
            entry: dict[str, Any] = {
                "viewport": cell.viewport,
                "locale": cell.locale,
                "theme": cell.theme,
                "access": cell.access,
                "viewport_width": cell.width,
                "viewport_height": cell.height,
                # null on the page at rest; the state's name on a forced shot, so a
                # reader never has to infer which row is the forced one.
                "force_state": None if cell.force_state is None else cell.force_state.name,
                # Present on every row for shape, all null until a driver observes
                # lab timing for this cell.
                "timing": _null_timing(),
            }
            if page_failure is not None:
                entry.update(
                    {
                        "captured": False,
                        "reason": f"page load failed on an earlier state, remaining states not attempted: {page_failure}",
                    }
                )
                states.append(entry)
                continue

            url = page_url(base_url, cell.route)
            try:
                observation = driver.capture(url=url, cell=cell, timeout_s=timeout_s)
            except CaptureUnavailable:
                raise
            except Exception as exc:  # a broken page is an observation, not a crash
                observation = CellObservation(
                    cell_id=cell.cell_id, loaded=False, error=f"{type(exc).__name__}: {exc}"
                )

            # Evidence is harvested from EVERY observation, before any state is
            # skipped: an auth-gated page that 401s and then times out settling is
            # the exact page this feature exists for, and harvesting below the
            # ``continue``s published an empty console_errors for it. Lab timing
            # follows the same discipline — a load that failed late may still have
            # observed an LCP, and a driver that observed nothing keeps its nulls.
            entry["timing"] = _timing_from(observation)
            for error in observation.console_errors:
                text = str(error.get("text") or "")
                source_url = error.get("source_url") or None
                key = (text, source_url)
                if key in console_seen:
                    continue
                console_seen.add(key)
                console_entries.append({"text": text, "source_url": source_url})
            for failure in observation.failed_responses:
                failed_url = str(failure.get("url") or "")
                status = int(failure.get("status") or 0)
                if (failed_url, status) in failed_seen:
                    continue
                failed_seen.add((failed_url, status))
                failed_responses.append({"url": failed_url, "status": status})

            if delay_ms > 0 and position < len(cells) - 1:
                time.sleep(delay_ms / 1000.0)

            if not observation.loaded:
                page_failure = observation.error or "page did not load"
                entry.update({"captured": False, "reason": page_failure})
                states.append(entry)
                continue

            png = observation.screenshot_png
            if not png:
                entry.update({"captured": False, "reason": "driver returned no screenshot bytes"})
                states.append(entry)
                continue

            suffix = None if cell.force_state is None else cell.force_state.name
            path, digest = write_screenshot(png, output_dir, state_suffix=suffix)
            written_pngs.add(path.name)
            dimensions = _png_dimensions(png)
            entry.update(
                {
                    "captured": True,
                    "file": os.path.relpath(path, manifest_dir).replace(os.sep, "/"),
                    "sha256": digest,
                    "bytes": len(png),
                    "width": dimensions[0] if dimensions else None,
                    "height": dimensions[1] if dimensions else None,
                    "applied_theme": observation.applied_theme,
                    "applied_locale": observation.applied_locale,
                }
            )
            if cell.force_state is not None:
                entry["applied_force_state"] = observation.applied_force_state
                if observation.applied_force_state == cell.force_state.name:
                    forced_captured[cell.force_state.name] = cell.force_state.spec
                else:
                    # The hook never took. The shot exists, but it is the page at
                    # rest wearing a forced-state file name, so say so instead of
                    # letting the file name assert a state nobody saw.
                    gaps.append(
                        {
                            "dimension": "force_state_application",
                            "value": cell.force_state.name,
                            "captured": True,
                            "reason": (
                                f"--force-state {cell.force_state.spec} did not take on "
                                f"{cell.viewport}/{cell.locale}/{cell.theme}; the driver "
                                f"confirmed {observation.applied_force_state!r}"
                            ),
                        }
                    )
            if observation.applied_theme not in (None, cell.theme) or observation.applied_locale not in (
                None,
                cell.locale,
            ):
                # The page's own toggle refused the requested state. Say so rather
                # than filing the screenshot under a state it does not show.
                gaps.append(
                    {
                        "dimension": "state_application",
                        "value": f"{cell.viewport}/{cell.locale}/{cell.theme}",
                        "captured": True,
                        "reason": (
                            f"page settled on theme={observation.applied_theme!r} "
                            f"locale={observation.applied_locale!r}"
                        ),
                    }
                )
            states.append(entry)
            captured.append((cell, observation))

        # Forced shots are evidence, never census input: a forced-empty page would
        # drag visible_word_count and section_count away from what the page actually
        # renders. Metrics are measured on the rest cells only, and
        # screenshot_completion counts rest cells only so an unforced run's numbers
        # are unchanged by the presence of this flag.
        rest_captured = [pair for pair in captured if pair[0].force_state is None]
        rest_attempted = sum(1 for cell in cells if cell.force_state is None)
        metrics = _page_metrics(
            rest_captured, attempted=rest_attempted, console_errors=console_entries
        )
        gaps.extend(access_and_page_state_gaps(forced_captured))
        page_payload = {
            "page_id": row["page_id"],
            "route": row["capture_route"],
            "registry_route": row.get("route") or row["capture_route"],
            "route_kind": row.get("route_kind") or "",
            "states": states,
            "metrics": metrics,
            "console_errors": [dict(entry) for entry in console_entries],
            "failed_responses": [dict(entry) for entry in failed_responses],
            "gaps": gaps,
        }
        manifest_pages.append(page_payload)
        smell_pages.append(
            {
                "page_id": row["page_id"],
                "route": row["capture_route"],
                "metrics": metrics,
            }
        )

    attempted_total = sum(len(page["states"]) for page in manifest_pages)
    captured_total = sum(
        1 for page in manifest_pages for state in page["states"] if state.get("captured")
    )
    outcome = OUTCOME_CAPTURED
    if any(all(not state.get("captured") for state in page["states"]) for page in manifest_pages):
        outcome = OUTCOME_PARTIAL
    if manifest_pages and captured_total == 0:
        outcome = OUTCOME_PARTIAL

    manifest = {
        "schema": MANIFEST_SCHEMA,
        "generated_at": generated_at,
        "tool": {
            "module_ref": MODULE_REF,
            "version": TOOL_VERSION,
            "module_sha256": module_source_sha256(),
            "user_agent": USER_AGENT,
        },
        "target": dict(target),
        "axes": {
            "viewports": {name: list(VIEWPORTS[name]) for name in viewports},
            "locales": list(locales),
            "themes": list(themes),
            "access": [ACCESS_ANONYMOUS],
            "force_states": [state.as_payload() for state in force_states],
        },
        # Declares the basis of every timing number below: measured in this local
        # anonymous capture, so a reader cannot mistake it for production traffic.
        "timing_basis": TIMING_BASIS,
        "selection": dict(selection or {}),
        "excluded": [dict(item) for item in excluded],
        "outcome": outcome,
        "totals": {
            "pages": len(manifest_pages),
            "states_attempted": attempted_total,
            "states_captured": captured_total,
        },
        "honesty": {
            "access": "anonymous only; no credential is entered, stored, or synthesized, so no premium payload can enter these artifacts",
            "gaps": "states that were not captured are recorded with a reason; nothing is inferred for them",
            "authority": "this tool measures and screenshots; it scores, ranks, and judges nothing",
        },
        "pages": manifest_pages,
    }
    if force_states:
        manifest["honesty"]["force_states"] = (
            "a forced state is either a class/attribute toggled on <body> or a real "
            "browser hover/focus applied to a selector before the shot; it shows that "
            "state's presentation, not data the page returned; metrics are measured on "
            "the rest cells only, and a state that did not take is recorded as a gap"
        )

    smells = {
        "schema": SMELL_SCHEMA,
        "generated_at": generated_at,
        "tool": {"module_ref": MODULE_REF, "version": TOOL_VERSION},
        "target": dict(target),
        "disclaimer": MD_DISCLAIMER,
        "metric_notes": dict(METRIC_NOTES),
        "pages": smell_pages,
    }
    # ``written_pngs`` is a run receipt, not manifest content: the self-check
    # byte-compares two manifests, and the file set is not part of the schema.
    return {"manifest": manifest, "smells": smells, "written_pngs": sorted(written_pngs)}


# ---------------------------------------------------------------------------
# markdown emitter
# ---------------------------------------------------------------------------


def render_markdown(smells: Mapping[str, Any]) -> str:
    rows = sorted(smells.get("pages") or [], key=lambda page: (page.get("route") or "", page.get("page_id") or ""))
    lines = [
        "# Page evidence — measured facts",
        "",
        f"_{MD_DISCLAIMER}_",
        "",
        f"Generated {smells.get('generated_at')} · schema `{smells.get('schema')}`",
        "",
        "| route | page_id | words | h1 | panels | height px | h-overflow | slug hits | TODO hits | as-of | source | shots |",
        "| --- | --- | ---: | ---: | ---: | ---: | :---: | ---: | ---: | :---: | :---: | ---: |",
    ]

    def cell(value: Any) -> str:
        if value is None:
            return "—"
        if isinstance(value, bool):
            return "yes" if value else "no"
        return str(value)

    for page in rows:
        metrics = page.get("metrics") or {}
        headings = metrics.get("heading_counts") or {}
        lines.append(
            "| {route} | {page_id} | {words} | {h1} | {panels} | {height} | {overflow} | {slugs} | {todos} | {asof} | {source} | {shots} |".format(
                route=page.get("route", ""),
                page_id=page.get("page_id", ""),
                words=cell(metrics.get("visible_word_count")),
                h1=cell(headings.get("h1")),
                panels=cell(metrics.get("panel_count")),
                height=cell(metrics.get("document_height_px")),
                overflow=cell(metrics.get("horizontal_overflow")),
                slugs=cell(metrics.get("raw_slug_hit_count")),
                todos=cell(metrics.get("todo_placeholder_hit_count")),
                asof=cell(metrics.get("asof_present")),
                source=cell(metrics.get("source_present")),
                shots=cell(metrics.get("screenshot_completion")),
            )
        )

    lines.extend(["", "## Metric notes", ""])
    for key in sorted(smells.get("metric_notes") or {}):
        lines.append(f"- **{key}** — {smells['metric_notes'][key]}")
    lines.append("")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# local site server (light_mode_sweep pattern)
# ---------------------------------------------------------------------------


class _QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *args: Any) -> None:  # noqa: D102 - silence per-request noise
        return


def serve_site_dir(site_dir: Path) -> tuple[socketserver.TCPServer, int]:
    """Serve a built site on an ephemeral loopback port. Threaded: a page fans out."""

    handler = functools.partial(_QuietHandler, directory=str(site_dir))
    httpd = socketserver.ThreadingTCPServer(("127.0.0.1", 0), handler)
    httpd.daemon_threads = True
    port = httpd.server_address[1]
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    return httpd, port


# ---------------------------------------------------------------------------
# playwright driver (lazily imported; never at module scope)
# ---------------------------------------------------------------------------

# Seeded BEFORE any page script runs. theme.js re-derives the theme from the hour
# when localStorage.themeAuto === '1' (its boot lift), which would silently
# override an attribute stamp — so the seed clears themeAuto, exactly the way the
# site's own setTheme() does on an explicit choice.
_STATE_SEED_SCRIPT = """
(state) => {
  try {
    localStorage.setItem('theme', state.theme);
    localStorage.removeItem('themeAuto');
    localStorage.setItem('lang', state.locale);
  } catch (e) {}
}
"""


def state_seed_source(state: dict[str, Any]) -> str:
    """The init-script source that seeds ``state`` before any page script runs.

    ``add_init_script`` takes source, not ``(fn, arg)``, so the seed is wrapped as
    an IIFE with the state literal baked in. The statement is TERMINATED with a
    semicolon on purpose: an init script is plain text that callers concatenate
    onto (a wrapper appending its own IIFE after a newline is the documented
    shape), and an unterminated ``(fn)(arg)`` followed by ``(function(){...})()``
    parses as ONE call-of-a-call — ``(intermediate value)(...) is not a
    function`` — thrown before the page's first script, surfacing in the manifest
    as a page ``console_error`` with no source URL (sanctions_map, 2026-09-08).
    """
    return f"({_STATE_SEED_SCRIPT.strip()})({json.dumps(state)});"

# Applied AFTER load through the page's own toggle when it exposes one, so the
# capture goes through the same code path a user's click does (theme.js sets
# data-theme / data-lang on <html>, syncs documentElement.lang, and fires the
# themechange / langchange events the widgets listen for).
_APPLY_STATE_SCRIPT = """
(state) => {
  const docEl = document.documentElement;
  if (typeof window.setTheme === 'function') { window.setTheme(state.theme); }
  else {
    docEl.setAttribute('data-theme', state.theme);
    try { localStorage.setItem('theme', state.theme); localStorage.removeItem('themeAuto'); } catch (e) {}
  }
  if (typeof window.setLang === 'function') { window.setLang(state.locale); }
  else {
    docEl.setAttribute('data-lang', state.locale);
    try { docEl.lang = state.locale === 'zh' ? 'zh-CN' : 'en'; } catch (e) {}
    try { localStorage.setItem('lang', state.locale); } catch (e) {}
  }
  return {
    theme: docEl.getAttribute('data-theme'),
    locale: docEl.getAttribute('data-lang') || 'en',
  };
}
"""

# Waits for theme.js's skyToggleFx flourish (.sky-fx sun|moon) to be removed from
# the document before the screenshot fires, so the captured cell shows the settled
# page.  A no-op when the element never appears (reduced-motion, no theme.js, etc.)
# and gives up quietly after timeout_ms with a False return — never raises.
def _wait_transient_fx_gone(
    page, *, selector: str = ".sky-fx", timeout_ms: int = 3000
) -> bool:
    try:
        page.wait_for_function(
            f"(sel) => !document.querySelector(sel)",
            arg=selector,
            timeout=timeout_ms,
        )
        return True
    except Exception:
        return False


# Applied AFTER theme/locale and immediately before the observer and the shot.
# Class/attribute forcing stays the smallest possible body mutation. Hover/focus
# forcing below uses the browser's real interaction primitives against a selector;
# neither path deletes nodes, fakes data, or synthesizes content.
_FORCE_STATE_SCRIPT = """
(force) => {
  const el = document.body || document.documentElement;
  if (!el) { return {applied: null}; }
  if (force.kind === 'class') {
    el.classList.add(force.value);
    return {applied: el.classList.contains(force.value) ? force.name : null};
  }
  el.setAttribute(force.attribute, force.value);
  return {applied: el.getAttribute(force.attribute) === force.value ? force.name : null};
}
"""

def _apply_interaction_force(page: Any, force: ForceState, *, timeout_ms: int = 3000) -> str | None:
    """Apply one real browser hover/focus state and verify that it actually took.

    This helper is deliberately browser-library agnostic: it consumes only the
    tiny locator surface Playwright exposes, so hermetic tests can exercise the
    production decision path without importing or launching a browser.
    """

    if force.kind not in {"hover", "focus"}:
        return None
    try:
        locator = page.locator(force.value).first
        if force.kind == "hover":
            locator.hover(timeout=timeout_ms)
            applied = locator.evaluate("(el) => el.matches(':hover')")
        else:
            locator.focus(timeout=timeout_ms)
            applied = locator.evaluate("(el) => document.activeElement === el")
    except Exception:
        return None
    return force.name if applied else None


# One observer, one page load, one JSON blob. Every number here is a count of
# something a human could count by hand; none of them is combined into a score.
# innerText is layout-aware, so the estate's same-DOM bilingual spans (.l-en /
# .l-zh, hidden by CSS off data-lang) are excluded automatically for the locale
# that is not showing — which is why the text metrics use innerText, not
# textContent.
_OBSERVER_SCRIPT = r"""
(cfg) => {
  const docEl = document.documentElement;
  const vw = docEl.clientWidth;
  const isVisible = (el) => {
    if (!el) return false;
    const s = getComputedStyle(el);
    if (s.display === 'none' || s.visibility === 'hidden') return false;
    if (parseFloat(s.opacity || '1') === 0) return false;
    return el.getClientRects().length > 0;
  };
  const textOf = (el) => ((el && el.innerText) || '').trim();
  const bodyText = textOf(document.body);
  const lowerBody = bodyText.toLowerCase();

  const mainEl = document.querySelector('main');
  const sectionCount =
    document.querySelectorAll('body > section').length + (mainEl ? mainEl.children.length : 0);

  const headingCounts = {};
  const headingTexts = [];
  for (let level = 1; level <= 6; level += 1) {
    const nodes = Array.from(document.querySelectorAll('h' + level)).filter(isVisible);
    headingCounts['h' + level] = nodes.length;
    nodes.forEach((node) => {
      const t = textOf(node);
      if (t) headingTexts.push(t.toLowerCase());
    });
  }
  const seen = new Map();
  headingTexts.forEach((t) => seen.set(t, (seen.get(t) || 0) + 1));
  const duplicates = Array.from(seen.entries())
    .filter(([, count]) => count > 1)
    .map(([t]) => t)
    .sort();

  const panelSelector = (cfg.panel_selectors || []).join(',');
  const panelCount = panelSelector
    ? Array.from(document.querySelectorAll(panelSelector)).filter(isVisible).length
    : 0;

  const words = bodyText.split(/\s+/).filter(Boolean);
  const longParagraphs = Array.from(document.querySelectorAll('p'))
    .filter(isVisible)
    .filter((p) => textOf(p).split(/\s+/).filter(Boolean).length > (cfg.long_paragraph_words || 120))
    .length;

  const cap = cfg.max_hit_samples || 25;
  const slugMatches = bodyText.match(/\b[a-z][a-z0-9]+(?:_[a-z0-9]+){2,}\b/g) || [];
  const slugDistinct = Array.from(new Set(slugMatches)).sort();
  const todoMatches = bodyText.match(/TODO|FIXME|PLACEHOLDER|lorem ipsum/gi) || [];
  const todoDistinct = Array.from(new Set(todoMatches.map((m) => m.toLowerCase()))).sort();

  const widerThanViewport = Array.from(document.querySelectorAll('*')).filter((el) => {
    if (!isVisible(el)) return false;
    return el.getBoundingClientRect().width > vw + 1;
  }).length;

  const probe = (spec) => {
    if (!spec) return false;
    const selectors = (spec.selectors || []).join(',');
    if (selectors && Array.from(document.querySelectorAll(selectors)).some(isVisible)) return true;
    return (spec.text_patterns || []).some((p) => lowerBody.includes(String(p).toLowerCase()));
  };

  return {
    document_height_px: docEl.scrollHeight,
    section_count: sectionCount,
    heading_counts: headingCounts,
    duplicate_heading_texts: duplicates.slice(0, cap),
    panel_count: panelCount,
    visible_word_count: words.length,
    long_paragraph_count: longParagraphs,
    raw_slug_hits: slugDistinct.slice(0, cap),
    raw_slug_hit_count: slugDistinct.length,
    todo_placeholder_hits: todoDistinct.slice(0, cap),
    todo_placeholder_hit_count: todoDistinct.length,
    horizontal_overflow: docEl.scrollWidth > docEl.clientWidth,
    elements_wider_than_viewport: widerThanViewport,
    asof_present: probe(cfg.asof_probe),
    source_present: probe(cfg.source_probe),
  };
}
"""


# Seeded before any page script (an init script, like the state seed) so the
# buffered observers see the whole load. Each entry type is subscribed
# individually and each subscription is individually optional: an engine that
# rejects one type must not lose the others, and a context where the whole store
# is absent harvests nulls, never zeros. Everything buffered here is a LAB
# measurement of this synthetic load.
_TIMING_INIT_SCRIPT = """
() => {
  if (window.__cpeTiming) { return; }
  const store = {lcp: null, cls: 0.0, events: []};
  window.__cpeTiming = store;
  try {
    new PerformanceObserver((list) => {
      const entries = list.getEntries();
      for (let i = 0; i < entries.length; i += 1) {
        const entry = entries[i];
        if (store.lcp === null || entry.startTime > store.lcp) { store.lcp = entry.startTime; }
      }
    }).observe({type: 'largest-contentful-paint', buffered: true});
  } catch (e) {}
  try {
    new PerformanceObserver((list) => {
      const entries = list.getEntries();
      for (let i = 0; i < entries.length; i += 1) {
        const entry = entries[i];
        if (!entry.hadRecentInput) { store.cls += entry.value; }
      }
    }).observe({type: 'layout-shift', buffered: true});
  } catch (e) {}
  try {
    new PerformanceObserver((list) => {
      const entries = list.getEntries();
      for (let i = 0; i < entries.length; i += 1) { store.events.push(entries[i]); }
    }).observe({type: 'event', buffered: true, durationThreshold: 16});
  } catch (e) {}
}
"""


def timing_init_source() -> str:
    """The init-script source that starts the buffered timing observers.

    Wrapped and terminated exactly like ``state_seed_source``: init scripts are
    plain text callers concatenate onto, and an unterminated call is the
    documented parse hazard (see that function's docstring).
    """

    return f"({_TIMING_INIT_SCRIPT.strip()})();"


# Evaluated once, after load settles, to drain the buffered observers and the
# resource-timing buffer into the six lab timing numbers. Returns null (not a
# partial dict) when the init script never ran, so the whole block stays null.
_TIMING_SNAPSHOT_SCRIPT = r"""
() => {
  const store = window.__cpeTiming || null;
  if (!store) { return null; }
  const nav = (performance.getEntriesByType('navigation') || [])[0] || null;
  const resources = performance.getEntriesByType('resource') || [];
  const serverTiming = [];
  if (nav && nav.serverTiming) {
    for (const st of nav.serverTiming) { serverTiming.push(st); }
  }
  for (const resource of resources) {
    if (resource.serverTiming) {
      for (const st of resource.serverTiming) { serverTiming.push(st); }
    }
  }
  // INP proxy: the longest Event Timing duration among entries the browser
  // attributes to an interaction. The only interactions this driver scripts are
  // the force-state hover/focus calls, so with none of those the list is empty
  // and the value is null — never a synthesized 0.
  const interactions = [];
  for (const entry of store.events) {
    if (entry.interactionId) { interactions.push(entry.duration); }
  }
  return {
    lcp_ms: store.lcp,
    cls: store.cls,
    inp_proxy_ms: interactions.length ? Math.max.apply(null, interactions) : null,
    resource_count: resources.length,
    transfer_bytes: resources.reduce((total, r) => total + (r.transferSize || 0), 0),
    server_timing: serverTiming.map((st) => ({
      name: st.name, duration: st.duration, description: st.description,
    })),
  };
}
"""


def playwright_page_driver(
    *,
    headless: bool = True,
    user_agent: str = USER_AGENT,
    observer_config: Mapping[str, Any] | None = None,
    settle_ms: int = 400,
) -> PageDriver:  # pragma: no cover - needs a browser
    """Build the real driver. Imported lazily; a missing browser raises, never passes."""

    try:
        from playwright.sync_api import sync_playwright
    except ImportError as exc:
        raise CaptureUnavailable(
            f"playwright is not importable: {exc}. Install with: {INSTALL_HINT}"
        ) from exc

    try:
        manager = sync_playwright().start()
    except Exception as exc:
        raise CaptureUnavailable(
            f"playwright runtime is unavailable: {exc}. Install with: {INSTALL_HINT}"
        ) from exc
    try:
        browser = manager.chromium.launch(headless=headless)
    except Exception as exc:
        manager.stop()
        raise CaptureUnavailable(
            f"no chromium binary is installed: {exc}. Install with: {INSTALL_HINT}"
        ) from exc
    return _PlaywrightDriver(manager, browser, user_agent, dict(observer_config or DEFAULT_OBSERVER_CONFIG), settle_ms)


class _PlaywrightDriver:  # pragma: no cover - needs a browser
    """Thin adapter. It reports what it saw; it decides nothing about the page."""

    def __init__(
        self,
        manager: Any,
        browser: Any,
        user_agent: str,
        observer_config: Mapping[str, Any],
        settle_ms: int,
    ) -> None:
        self._manager = manager
        self._browser = browser
        self._user_agent = user_agent
        self._observer_config = observer_config
        self._settle_ms = settle_ms

    def capture(self, *, url: str, cell: CaptureCell, timeout_s: float) -> CellObservation:
        state = {"theme": cell.theme, "locale": cell.locale}
        context = self._browser.new_context(
            viewport={"width": cell.width, "height": cell.height},
            user_agent=self._user_agent,
            locale="zh-CN" if cell.locale == "zh" else "en-US",
            color_scheme=cell.theme,
            device_scale_factor=1,
        )
        # Terminated IIFE source (see state_seed_source): safe to concatenate onto.
        context.add_init_script(state_seed_source(state))
        # Buffered timing observers must exist before any page script runs, or the
        # load's LCP/shift/event entries are gone before anything can buffer them.
        context.add_init_script(timing_init_source())
        page = context.new_page()
        console_errors: list[dict[str, Any]] = []
        failed_responses: list[dict[str, Any]] = []
        counters = {"requests": 0, "bytes": 0}

        def _on_console(msg: Any) -> None:
            if msg.type != "error":
                return
            # msg.location is a dict in the sync API, but a console message can
            # arrive without one; an unattributed error is recorded as such rather
            # than dropped.
            try:
                source_url = (msg.location or {}).get("url") or None
            except Exception:
                source_url = None
            console_errors.append({"text": msg.text, "source_url": source_url})

        def _on_response(response: Any) -> None:
            try:
                if response.status >= 400:
                    failed_responses.append(
                        {"url": response.url, "status": int(response.status)}
                    )
            except Exception:
                # A response object the driver cannot read is not evidence of a
                # failure; it is simply not recorded.
                pass

        page.on("console", _on_console)
        # A pageerror is an uncaught exception, not a resource: it has no URL, and
        # claiming one would be a fabricated attribution.
        page.on("pageerror", lambda err: console_errors.append({"text": f"pageerror: {err}", "source_url": None}))
        page.on("response", _on_response)
        page.on("request", lambda _req: counters.__setitem__("requests", counters["requests"] + 1))

        def _on_finished(request: Any) -> None:
            try:
                counters["bytes"] += int(request.sizes().get("responseBodySize") or 0)
            except Exception:
                # A response the driver cannot size is simply not counted; the
                # metric note says payload_bytes_total excludes them.
                pass

        page.on("requestfinished", _on_finished)

        def _failed(error: str) -> CellObservation:
            """A failed load still carries what the listeners already saw.

            The 401-then-timeout page is the whole reason these listeners exist;
            returning a bare error here published ``console_errors: []`` for it.
            """

            return CellObservation(
                cell_id=cell.cell_id,
                loaded=False,
                error=error,
                console_errors=tuple(console_errors),
                failed_responses=tuple(failed_responses),
                request_count=int(counters["requests"]),
                payload_bytes_total=int(counters["bytes"]),
            )

        try:
            response = page.goto(url, wait_until="load", timeout=timeout_s * 1000)
            if response is None:
                return _failed("no response")
            if not response.ok:
                # A top-level 4xx/5xx is precisely a failed response worth naming;
                # the listener already recorded it, and it travels out with this.
                return _failed(f"HTTP {response.status}")
            page.wait_for_timeout(self._settle_ms)
            applied = page.evaluate(_APPLY_STATE_SCRIPT.strip(), state) or {}
            _wait_transient_fx_gone(page)
            page.wait_for_timeout(self._settle_ms)
            applied_force: str | None = None
            if cell.force_state is not None:
                if cell.force_state.kind in {"hover", "focus"}:
                    applied_force = _apply_interaction_force(
                        page, cell.force_state, timeout_ms=max(1, int(timeout_s * 1000))
                    )
                else:
                    forced = page.evaluate(
                        _FORCE_STATE_SCRIPT.strip(), cell.force_state.as_payload()
                    ) or {}
                    applied_force = forced.get("applied")
                # The state's own transition has to finish before the shot, or the
                # screenshot catches the page mid-fade.
                _wait_transient_fx_gone(page)
                page.wait_for_timeout(self._settle_ms)
            observed = page.evaluate(_OBSERVER_SCRIPT.strip(), dict(self._observer_config)) or {}
            # Drained after the same settles the observer waited out, so late LCP
            # candidates and trailing shifts are inside the numbers. A page where
            # the init script never took yields None and stays all-null.
            timing = page.evaluate(_TIMING_SNAPSHOT_SCRIPT.strip()) or None
            screenshot = page.screenshot(full_page=True)
            return CellObservation(
                cell_id=cell.cell_id,
                loaded=True,
                screenshot_png=screenshot,
                observed=observed,
                console_errors=tuple(console_errors),
                failed_responses=tuple(failed_responses),
                request_count=int(counters["requests"]),
                payload_bytes_total=int(counters["bytes"]),
                applied_theme=applied.get("theme"),
                applied_locale=applied.get("locale"),
                applied_force_state=applied_force,
                timing=timing,
            )
        except Exception as exc:
            return _failed(f"{type(exc).__name__}: {exc}")
        finally:
            context.close()

    def close(self) -> None:
        self._browser.close()
        self._manager.stop()


# ---------------------------------------------------------------------------
# self-check
# ---------------------------------------------------------------------------


def _tiny_png(width: int, height: int, fill: int) -> bytes:
    """A real PNG (valid IHDR) so content-addressing and dimension reads are exercised."""

    import zlib

    def chunk(tag: bytes, data: bytes) -> bytes:
        return (
            struct.pack(">I", len(data))
            + tag
            + data
            + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
        )

    ihdr = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)
    raw = b"".join(b"\x00" + bytes([fill, fill, fill]) * width for _ in range(height))
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr) + chunk(b"IDAT", zlib.compress(raw)) + chunk(
        b"IEND", b""
    )


class _SelfCheckDriver:
    """Canned observations. Opens no browser, no socket, no page."""

    def capture(self, *, url: str, cell: CaptureCell, timeout_s: float) -> CellObservation:
        fill = 7 if cell.theme == "dark" else 240
        if cell.force_state is not None:
            # A forced state must produce DIFFERENT bytes, or the suffix assertions
            # below would pass against a file the rest-state shot already wrote and
            # prove nothing about forced capture.
            fill = (fill + 1 + sum(ord(char) for char in cell.force_state.name)) % 251
        return CellObservation(
            cell_id=cell.cell_id,
            loaded=True,
            screenshot_png=_tiny_png(4, 3, fill),
            observed={
                "document_height_px": 3200,
                "section_count": 6,
                "heading_counts": {"h1": 1, "h2": 4, "h3": 2, "h4": 0, "h5": 0, "h6": 0},
                "duplicate_heading_texts": [],
                "panel_count": 9,
                "visible_word_count": 812,
                "long_paragraph_count": 1,
                "raw_slug_hits": ["regime_state_score"],
                "raw_slug_hit_count": 1,
                "todo_placeholder_hits": [],
                "todo_placeholder_hit_count": 0,
                "horizontal_overflow": False,
                "elements_wider_than_viewport": 0,
                "asof_present": True,
                "source_present": False,
            },
            # Attributed console error + a failing response, so the self-check
            # exercises the attribution path end to end and not just the shape.
            console_errors=(
                {"text": "TypeError: canned", "source_url": "http://127.0.0.1:0/assets/canned.js"},
            ),
            failed_responses=({"url": "http://127.0.0.1:0/api/canned", "status": 401},),
            request_count=31,
            payload_bytes_total=812_345,
            applied_theme=cell.theme,
            applied_locale=cell.locale,
            applied_force_state=None if cell.force_state is None else cell.force_state.name,
            # Deterministic lab numbers, constants like every other canned value
            # above. inp_proxy_ms stays null on purpose: this driver scripts no
            # interaction, and a null — not a 0 — is what an unobserved timing
            # value must look like.
            timing={
                "lcp_ms": 1180.5,
                "cls": 0.01,
                "inp_proxy_ms": None,
                "resource_count": 27,
                "transfer_bytes": 640_512,
                "server_timing": (
                    {"name": "edge", "duration": 12.5, "description": "cache miss"},
                ),
            },
        )


def self_check() -> tuple[bool, dict[str, Any]]:
    """Prove the pipeline end to end with a canned driver: no browser, no network."""

    rows = [
        {
            "page_id": "macro",
            "route": "/macro.html",
            "capture_route": "/macro.html",
            "repo": "macro",
            "priority": "P0",
            "route_kind": "static",
            "is_family": False,
            "exemplar": None,
            "themes": None,
            "locales": None,
        },
        {
            "page_id": "dark_only",
            "route": "/terminal.html",
            "capture_route": "/terminal.html",
            "repo": "macro",
            "priority": "P0",
            "route_kind": "static",
            "is_family": False,
            "exemplar": None,
            "themes": ("dark",),
            "locales": ("en",),
        },
    ]
    findings: list[str] = []
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        output_dir = root / "evidence"
        payloads = [
            run_capture(
                rows=rows,
                driver=_SelfCheckDriver(),
                base_url="http://127.0.0.1:0",
                output_dir=output_dir,
                manifest_dir=root,
                viewports=("desktop", "mobile"),
                locales=("en", "zh"),
                themes=("light", "dark"),
                delay_ms=0,
                timeout_s=5,
                generated_at="2026-01-01T00:00:00Z",
                target={
                    "kind": "self_check",
                    "base_url": None,
                    "site_dir": None,
                    "resolved_sha_or_none": None,
                    "resolved_gitdir_or_none": None,
                },
                selection={"mode": "registry", "priority": "P0", "repo": "macro"},
            )
            for _ in range(2)
        ]
        manifest = payloads[0]["manifest"]

        if canonical_json_bytes(payloads[0]["manifest"]) != canonical_json_bytes(payloads[1]["manifest"]):
            findings.append("two runs with a pinned as-of produced different manifests")

        # Did the run do its job at all? Every check below this line is a shape or
        # set comparison, and all of them pass vacuously over an empty capture — a
        # driver that captured nothing scored ok=True with zero screenshots on
        # disk. A check that cannot fail is not a check, so the run's own totals
        # are asserted first: ``_SelfCheckDriver`` captures EVERY cell it is
        # handed, so anything short of that is a defect in the pipeline.
        totals = manifest["totals"]
        if manifest["outcome"] != OUTCOME_CAPTURED:
            findings.append(
                f"the self-check run reported outcome {manifest['outcome']!r}, not {OUTCOME_CAPTURED!r}"
            )
        if totals["states_captured"] <= 0:
            findings.append(
                "the self-check captured no state at all: the canned driver returned nothing "
                "usable, and every remaining assertion would pass vacuously"
            )
        elif totals["states_captured"] != totals["states_attempted"]:
            findings.append(
                f"the canned driver captures every cell, but only {totals['states_captured']} of "
                f"{totals['states_attempted']} attempted states were captured"
            )
        if totals["pages"] <= 0:
            findings.append("the self-check produced no page at all")
        if manifest.get("timing_basis") != TIMING_BASIS:
            findings.append(f"the manifest must declare timing_basis {TIMING_BASIS!r}")

        pages = {page["page_id"]: page for page in manifest["pages"]}
        dark_only = pages.get("dark_only")
        if dark_only is None:
            findings.append("dark_only page missing from the manifest")
        else:
            if any(state["theme"] == "light" for state in dark_only["states"]):
                findings.append("registry-declared dark-only page produced a light state")
            if any(state["locale"] == "zh" for state in dark_only["states"]):
                findings.append("registry-declared en-only page produced a zh state")
            gap_values = {gap["value"] for gap in dark_only["gaps"]}
            if not {"light", "zh"} <= gap_values:
                findings.append("excluded axes were not recorded as gaps")

        for page in manifest["pages"]:
            if not any(state.get("captured") for state in page["states"]):
                findings.append(f"{page['page_id']}: not one state was captured")
            missing = [key for key in METRIC_KEYS if key not in page["metrics"]]
            if missing:
                findings.append(f"{page['page_id']}: metrics missing {missing}")
            for state in page["states"]:
                timing = state.get("timing")
                if not isinstance(timing, dict) or set(timing) != set(TIMING_KEYS):
                    findings.append(f"{page['page_id']}: a state lost its lab timing shape")
                    continue
                if state.get("captured") and timing["lcp_ms"] is None:
                    findings.append(
                        f"{page['page_id']}: the canned driver reports lcp_ms, but a captured "
                        "state recorded null"
                    )
                if timing["inp_proxy_ms"] is not None:
                    findings.append(
                        f"{page['page_id']}: no interaction is scripted by the canned driver, "
                        "so inp_proxy_ms must be null, not a number"
                    )
            access_gaps = {gap["value"] for gap in page["gaps"] if gap["dimension"] == "access"}
            if set(GATED_ACCESS_STATES) - access_gaps:
                findings.append(f"{page['page_id']}: gated access states not recorded as gaps")
            if any(state.get("access") != ACCESS_ANONYMOUS for state in page["states"]):
                findings.append(f"{page['page_id']}: a state claims a non-anonymous access tier")
            if not all(
                set(error) == {"text", "source_url"} for error in page["console_errors"]
            ):
                findings.append(f"{page['page_id']}: a console error lost its attribution shape")
            if not all(
                set(failure) == {"url", "status"} for failure in page["failed_responses"]
            ):
                findings.append(f"{page['page_id']}: a failed response lost its url/status shape")

        # The canned driver emits one attributed console error and one failing
        # response per cell, so an empty aggregate means the harvest path dropped
        # them — the defect the 2026-08 review found on failed-load pages. Without
        # this, the two shape checks above are ``all([])`` and always true.
        if not any(page["console_errors"] for page in manifest["pages"]):
            findings.append(
                "no console error reached the manifest, so the attribution shape check above "
                "asserted nothing: the canned driver emits one per cell"
            )
        if not any(page["failed_responses"] for page in manifest["pages"]):
            findings.append(
                "no failed response reached the manifest, so the url/status shape check above "
                "asserted nothing: the canned driver emits one per cell"
            )

        # Content-addressing is checked against the run's own write ledger and the
        # paths the manifest names — never by enumerating the directory (docstring
        # §8). Reading a known path is fine; discovering one is the opaque edge.
        # Honest tradeoff against the ``glob("*.png")`` this replaced, in both
        # directions: the ledger is filled by the same loop that fills ``sha256``,
        # so on its own it is a tautology — the per-state re-hash below is what
        # makes it a check, and *that* is stronger than the old name-only
        # comparison. What no ledger can see is a file the manifest never names: a
        # stray, a truncated leftover, another run's output. The glob could. This
        # is acceptable only because the whole self-check runs inside a fresh
        # TemporaryDirectory that nothing else writes to.
        shas = {
            state["sha256"]
            for page in manifest["pages"]
            for state in page["states"]
            if state.get("captured")
        }
        expected = {f"{sha[:16]}.png" for sha in shas}
        if len(expected) != len(shas):
            findings.append(
                f"{len(shas)} distinct digests collapse onto {len(expected)} file names: "
                "the 16-hex prefix collided"
            )
        for index, payload in enumerate(payloads, start=1):
            if set(payload["written_pngs"]) != expected:
                findings.append(
                    f"run {index} wrote {sorted(payload['written_pngs'])}, "
                    f"the manifest names {sorted(expected)}"
                )
        for page in manifest["pages"]:
            for state in page["states"]:
                if not state.get("captured"):
                    continue
                name = Path(state["file"]).name
                try:
                    body = (output_dir / name).read_bytes()
                except OSError as exc:
                    findings.append(f"{name}: the file this state names is unreadable: {exc}")
                    continue
                digest = hashlib.sha256(body).hexdigest()
                if name != f"{digest[:16]}.png":
                    findings.append(f"{name} is not addressed by its own content")
                if digest != state["sha256"]:
                    findings.append(
                        f"{name}: manifest digest {state['sha256'][:16]} does not match the bytes on disk"
                    )

        # ---- forced presentation states -----------------------------------
        # A third run, forced. The two runs above stay unforced so the
        # byte-reproducibility comparison keeps testing what it always did, and
        # this one is compared against them: the flag has to ADD evidence without
        # moving a single census number.
        forced_states = parse_force_states(["empty:.is-empty", "focus:[data-probe=focus]"])
        forced_dir = root / "evidence_forced"
        forced_payload = run_capture(
            rows=rows,
            driver=_SelfCheckDriver(),
            base_url="http://127.0.0.1:0",
            output_dir=forced_dir,
            manifest_dir=root,
            viewports=("desktop", "mobile"),
            locales=("en", "zh"),
            themes=("light", "dark"),
            delay_ms=0,
            timeout_s=5,
            generated_at="2026-01-01T00:00:00Z",
            target={
                "kind": "self_check",
                "base_url": None,
                "site_dir": None,
                "resolved_sha_or_none": None,
                "resolved_gitdir_or_none": None,
            },
            selection={"mode": "registry", "priority": "P0", "repo": "macro"},
            force_states=forced_states,
        )
        forced_manifest = forced_payload["manifest"]

        expected_states = manifest["totals"]["states_attempted"] * (1 + len(forced_states))
        if forced_manifest["totals"]["states_attempted"] != expected_states:
            findings.append(
                f"forcing 2 states over {manifest['totals']['states_attempted']} cells should "
                f"attempt {expected_states} states, got {forced_manifest['totals']['states_attempted']}"
            )
        if forced_manifest["totals"]["states_captured"] != expected_states:
            findings.append("the canned driver captures every cell, but a forced cell was not captured")

        # Captured rows only: a run whose driver returned nothing has no ``file`` to
        # read, and the totals check above already recorded that failure. This
        # degrades to a finding rather than a KeyError.
        forced_rows = [
            state
            for page in forced_manifest["pages"]
            for state in page["states"]
            if state.get("force_state") and state.get("captured")
        ]
        if not forced_rows:
            findings.append(
                "not one captured state row carried a force_state, so every forced-state "
                "assertion below would pass vacuously"
            )
        for state in forced_rows:
            name = state["force_state"]
            if state.get("applied_force_state") != name:
                findings.append(f"forced state {name!r} was not confirmed applied by the driver")
            file_name = Path(state["file"]).name
            if f"--{name}.png" not in file_name:
                findings.append(f"forced shot {file_name!r} does not carry its --{name} suffix")
            if file_name != screenshot_name(state["sha256"], name):
                findings.append(f"forced shot {file_name!r} is not addressed by its own content + state")
        # The rest rows must keep the unsuffixed name, or the suffix check above
        # would be satisfied by suffixing everything.
        for page in forced_manifest["pages"]:
            for state in page["states"]:
                if state.get("force_state") or not state.get("captured"):
                    continue
                file_name = Path(state["file"]).name
                if file_name != screenshot_name(state["sha256"]):
                    findings.append(f"rest shot {file_name!r} was renamed by the forced-state feature")
        # Distinct bytes per state, or a forced shot would be the rest shot wearing
        # a forced name.
        for page in forced_manifest["pages"]:
            by_cell: dict[tuple[str, str, str], set[str]] = {}
            for state in page["states"]:
                if not state.get("captured"):
                    continue
                key = (state["viewport"], state["locale"], state["theme"])
                by_cell.setdefault(key, set()).add(state["sha256"])
            for key, digests in by_cell.items():
                if len(digests) != 1 + len(forced_states):
                    findings.append(
                        f"{page['page_id']} {key}: {len(digests)} distinct shots for "
                        f"{1 + len(forced_states)} states — a forced shot duplicated another state"
                    )
        if set(forced_payload["written_pngs"]) != {
            screenshot_name(state["sha256"], state.get("force_state"))
            for page in forced_manifest["pages"]
            for state in page["states"]
            if state.get("captured")
        }:
            findings.append("the forced run's write ledger disagrees with the files its manifest names")

        for page in forced_manifest["pages"]:
            page_states = {gap["value"]: gap for gap in page["gaps"] if gap["dimension"] == "page_state"}
            if set(page_states) != set(SYNTHETIC_PAGE_STATES):
                findings.append(f"{page['page_id']}: forcing a state changed the page_state gap ledger")
            empty = page_states.get("empty") or {}
            if empty.get("captured") is not True or "empty:.is-empty" not in str(empty.get("reason")):
                findings.append(
                    f"{page['page_id']}: a forced 'empty' state did not flip its gap row to a "
                    "captured forced presentation naming the spec"
                )
            for name in ("loading", "stale", "error"):
                unforced = page_states.get(name) or {}
                if unforced.get("captured") is not False or unforced.get("reason") != SYNTHETIC_PAGE_STATE_REASON:
                    findings.append(f"{page['page_id']}: unforced state {name!r} lost its gap row")
            # 'focus' is not one of the four synthesizable states, so it must not
            # invent a page_state row for itself.
            if "focus" in page_states:
                findings.append(f"{page['page_id']}: a custom forced state invented a page_state gap row")

        forced_metrics = {page["page_id"]: page["metrics"] for page in forced_manifest["pages"]}
        for page in manifest["pages"]:
            if forced_metrics.get(page["page_id"]) != page["metrics"]:
                findings.append(
                    f"{page['page_id']}: forced shots moved the census metrics; they are evidence, "
                    "not measurements"
                )

        for bad in ("empty", "empty:", ":.is-empty", "empty:div > .x", "empty:[bad", "-empty:.x"):
            try:
                parse_force_state(bad)
            except argparse.ArgumentTypeError:
                continue
            findings.append(f"--force-state accepted the malformed spec {bad!r}")
        # A name is lower-cased on the way in, so one spelling is one file-name
        # suffix. Without this, "Empty" and "empty" would be two files on Linux and
        # one on macOS — the case-sensitivity split that reds CI and not the desk.
        if parse_force_state("Empty:.is-empty").name != "empty":
            findings.append("--force-state did not normalize a state name to lower case")
        for duplicate in (["empty:.a", "empty:.b"], ["empty:.a", "Empty:.b"]):
            try:
                parse_force_states(duplicate)
            except argparse.ArgumentTypeError:
                continue
            findings.append(f"--force-state accepted {duplicate!r}; the second would overwrite the first")
        attribute = parse_force_state("locked:[data-locked]")
        if attribute.kind != "attribute" or attribute.attribute != "data-locked" or attribute.value != "":
            findings.append("a bare attribute target did not parse to an empty-valued attribute")

        markdown = render_markdown(payloads[0]["smells"])
        if MD_DISCLAIMER not in markdown:
            findings.append("markdown emitter dropped the disclaimer")

    summary = {
        "module_ref": MODULE_REF,
        "version": TOOL_VERSION,
        "module_sha256": module_source_sha256(),
        "manifest_schema": MANIFEST_SCHEMA,
        "smell_schema": SMELL_SCHEMA,
        "registry_schema_expected": REGISTRY_SCHEMA,
        "viewports": {name: list(dims) for name, dims in VIEWPORTS.items()},
        "locales": list(SUPPORTED_LOCALES),
        "themes": list(SUPPORTED_THEMES),
        "timing_basis": TIMING_BASIS,
        "timing_keys": list(TIMING_KEYS),
        "access_captured": [ACCESS_ANONYMOUS],
        "access_gaps": {state: GATED_ACCESS_REASON for state in GATED_ACCESS_STATES},
        "page_state_gaps": {state: SYNTHETIC_PAGE_STATE_REASON for state in SYNTHETIC_PAGE_STATES},
        "force_state_syntax": FORCE_STATE_SYNTAX,
        "force_state_disclosure": FORCE_STATE_REASON,
        "metrics": list(METRIC_KEYS),
        "user_agent": USER_AGENT,
        "findings": findings,
        "ok": not findings,
    }
    return not findings, summary


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def _csv_list(raw: str, allowed: Sequence[str], flag: str) -> list[str]:
    values = [part.strip().lower() for part in raw.split(",") if part.strip()]
    unknown = [value for value in values if value not in allowed]
    if unknown:
        raise argparse.ArgumentTypeError(f"{flag}: unknown value(s) {unknown}; allowed {list(allowed)}")
    seen: list[str] = []
    for value in values:
        if value not in seen:
            seen.append(value)
    return seen


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument("--registry", default=DEFAULT_REGISTRY)
    parser.add_argument("--priority", default="P0")
    parser.add_argument("--repo", default="macro")
    parser.add_argument("--base-url", help="live origin to capture against")
    parser.add_argument("--site-dir", help="built site directory to serve locally")
    parser.add_argument("--routes", help="comma list of routes; overrides registry selection")
    parser.add_argument("--output-dir", default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--manifest", default=DEFAULT_MANIFEST)
    parser.add_argument("--smells", default=DEFAULT_SMELLS)
    parser.add_argument("--emit-md", help="also render the smell report as a markdown table")
    parser.add_argument("--viewports", default="desktop,tablet,mobile")
    parser.add_argument("--locales", default="en,zh")
    parser.add_argument("--themes", default="light,dark")
    parser.add_argument("--max-pages", type=int, default=30)
    parser.add_argument("--delay-ms", type=int, default=500, help="politeness sleep between page loads")
    parser.add_argument(
        "--settle-ms", type=int, default=400,
        help=(
            "pause (each, x3: before state apply, after state apply, after any forced "
            "state) before the driver reads/shoots the page. Default 400ms is fine for "
            "a page with no >400ms one-shot animation on theme/locale apply; a page "
            "whose shared chrome runs a longer transition (e.g. templates/theme.js's "
            "skyToggleFx() sun/moon flourish, ~1100ms, fired by _APPLY_STATE_SCRIPT's "
            "window.setTheme() call) needs a larger value so the shot is taken after "
            "that transition's own cleanup, not mid-animation."
        ),
    )
    parser.add_argument("--timeout-s", type=float, default=30.0)
    parser.add_argument("--as-of", help="pin generated_at (ISO); makes a run byte-reproducible")
    parser.add_argument(
        "--observer-config", help="JSON file overriding panel selectors / probes / caps"
    )
    parser.add_argument("--headed", action="store_true", help="run the browser headed")
    parser.add_argument(
        "--force-state",
        action="append",
        default=[],
        metavar="NAME:TARGET",
        dest="force_state",
        help=(
            "repeatable; capture an extra shot per cell with a class/attribute forced "
            'on <body>, e.g. --force-state "empty:.is-empty" '
            '--force-state "error:[data-state=error]". Files gain a --NAME suffix. '
            "This forces the state's STYLING, not its data, and is labelled as such."
        ),
    )
    parser.add_argument("--self-check", action="store_true", help="canned end-to-end proof; opens no browser")
    return parser


def main(
    argv: Sequence[str] | None = None,
    *,
    driver_factory: Callable[..., PageDriver] | None = None,
) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.self_check:
        ok, summary = self_check()
        print(json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True))
        if not ok:
            print(
                "::error title=capture-page-evidence::self-check failed: "
                + "; ".join(summary["findings"]),
                flush=True,
            )
            return 1
        return EXIT_OK

    try:
        viewports = _csv_list(args.viewports, tuple(VIEWPORTS), "--viewports")
        locales = _csv_list(args.locales, SUPPORTED_LOCALES, "--locales")
        themes = _csv_list(args.themes, SUPPORTED_THEMES, "--themes")
        force_states = parse_force_states(args.force_state or ())
    except argparse.ArgumentTypeError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_USAGE
    if not (viewports and locales and themes):
        print("error: --viewports, --locales and --themes each need at least one value", file=sys.stderr)
        return EXIT_USAGE

    if bool(args.base_url) == bool(args.site_dir):
        print("error: pass exactly one of --base-url or --site-dir", file=sys.stderr)
        return EXIT_USAGE

    observer_config = dict(DEFAULT_OBSERVER_CONFIG)
    if args.observer_config:
        try:
            observer_config.update(json.loads(Path(args.observer_config).read_text(encoding="utf-8")))
        except (OSError, json.JSONDecodeError) as exc:
            print(f"error: --observer-config is not readable JSON: {exc}", file=sys.stderr)
            return EXIT_USAGE

    explicit_routes = [part.strip() for part in (args.routes or "").split(",") if part.strip()]
    registry_path = Path(args.registry)
    registry_rows: list[dict[str, Any]] = []
    excluded: list[dict[str, str]] = []
    try:
        if explicit_routes and not registry_path.exists():
            # Pure override mode: no registry on disk, minimal rows synthesized.
            rows = synthesize_rows(explicit_routes, [])
        else:
            registry_rows = load_registry(registry_path)
            if explicit_routes:
                rows = synthesize_rows(explicit_routes, registry_rows)
            else:
                rows, excluded = select_rows(
                    registry_rows,
                    priority=args.priority,
                    repo=args.repo,
                    max_pages=args.max_pages,
                )
    except RegistryError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_USAGE

    if args.max_pages > 0 and len(rows) > args.max_pages:
        for row in rows[args.max_pages :]:
            excluded.append(
                {"page_id": row["page_id"], "reason": f"beyond the --max-pages cap of {args.max_pages}"}
            )
        rows = rows[: args.max_pages]

    if not rows:
        print(
            "::warning title=capture-page-evidence::no page matched the selection "
            f"(priority={args.priority!r} repo={args.repo!r}); nothing captured",
            flush=True,
        )
        return EXIT_USAGE

    httpd: socketserver.TCPServer | None = None
    if args.site_dir:
        site_dir = Path(args.site_dir).resolve()
        if not site_dir.is_dir():
            print(f"error: --site-dir is not a directory: {site_dir}", file=sys.stderr)
            return EXIT_USAGE
        # Provenance is read BEFORE the server exists: this runs outside the
        # try/finally that shuts the socket down, so anything raising here used to
        # leak a listening server (a half-written .git/HEAD did exactly that until
        # ``_read_text`` learned to catch ValueError).
        target = site_dir_target(site_dir)
        httpd, port = serve_site_dir(site_dir)
        base_url = f"http://127.0.0.1:{port}"
    else:
        base_url = str(args.base_url)
        target = {
            "kind": "base_url",
            "base_url": base_url,
            "site_dir": None,
            "resolved_sha_or_none": None,
            "resolved_gitdir_or_none": None,
            "resolved_sha_source": "unavailable: a live origin does not disclose the commit it is serving",
        }

    factory = driver_factory or playwright_page_driver
    try:
        driver = factory(
            headless=not args.headed,
            user_agent=USER_AGENT,
            observer_config=observer_config,
            settle_ms=max(0, args.settle_ms),
        )
    except CaptureUnavailable as exc:
        if httpd is not None:
            httpd.shutdown()
        print(
            f"::error title=capture-page-evidence::{OUTCOME_UNAVAILABLE}: {exc}",
            flush=True,
        )
        print(
            json.dumps(
                {
                    "outcome": OUTCOME_UNAVAILABLE,
                    "reason": str(exc),
                    "install": INSTALL_HINT,
                    "artifacts_written": [],
                },
                ensure_ascii=False,
                indent=2,
                sort_keys=True,
            )
        )
        return EXIT_UNAVAILABLE

    manifest_path = Path(args.manifest)
    smells_path = Path(args.smells)
    # What actually selected these pages. Under --routes the registry filters never
    # ran, so priority/repo are null with the reason attached rather than echoing
    # parser defaults — a manifest that claims repo "macro" while capturing another
    # origin is a false provenance claim, which is exactly what this tool refuses.
    selection: dict[str, Any] = {
        "max_pages": args.max_pages,
        "registry": str(registry_path),
        "registry_rows": len(registry_rows),
        "explicit_routes": explicit_routes,
        "selected": len(rows),
    }
    if explicit_routes:
        selection.update(
            {"mode": "explicit_routes", "priority": None, "repo": None, "note": ROUTES_SELECTION_NOTE}
        )
    else:
        selection.update({"mode": "registry", "priority": args.priority, "repo": args.repo})
    try:
        payloads = run_capture(
            rows=rows,
            driver=driver,
            base_url=base_url,
            output_dir=Path(args.output_dir),
            manifest_dir=manifest_path.parent if str(manifest_path.parent) else Path("."),
            viewports=viewports,
            locales=locales,
            themes=themes,
            delay_ms=max(0, args.delay_ms),
            timeout_s=args.timeout_s,
            generated_at=(args.as_of or _utc_now()),
            target=target,
            excluded=excluded,
            selection=selection,
            force_states=force_states,
        )
    finally:
        close = getattr(driver, "close", None)
        if callable(close):
            close()
        if httpd is not None:
            httpd.shutdown()

    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_bytes(canonical_json_bytes(payloads["manifest"]))
    smells_path.parent.mkdir(parents=True, exist_ok=True)
    smells_path.write_bytes(canonical_json_bytes(payloads["smells"]))
    if args.emit_md:
        md_path = Path(args.emit_md)
        md_path.parent.mkdir(parents=True, exist_ok=True)
        md_path.write_text(render_markdown(payloads["smells"]), encoding="utf-8")

    totals = payloads["manifest"]["totals"]
    print(f"outcome: {payloads['manifest']['outcome']}")
    print(f"pages: {totals['pages']}  states: {totals['states_captured']}/{totals['states_attempted']} captured")
    print(f"manifest: {manifest_path}")
    print(f"smells: {smells_path}")
    if args.emit_md:
        print(f"markdown: {args.emit_md}")

    blind_pages = [
        page["page_id"]
        for page in payloads["manifest"]["pages"]
        if not any(state.get("captured") for state in page["states"])
    ]
    if blind_pages:
        print(
            "::warning title=capture-page-evidence::captured no state at all for: "
            + ", ".join(blind_pages),
            flush=True,
        )
        return EXIT_PARTIAL
    return EXIT_OK


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
