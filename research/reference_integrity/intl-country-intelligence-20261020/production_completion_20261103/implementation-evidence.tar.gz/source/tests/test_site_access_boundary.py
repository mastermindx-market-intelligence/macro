"""Static serving-boundary drift and client-artifact leak tripwires."""
from __future__ import annotations

import hashlib
import re
import shlex
import subprocess
from fnmatch import fnmatchcase
from pathlib import Path

import pytest
import yaml

ROOT = Path(__file__).resolve().parents[1]
POLICY = yaml.safe_load((ROOT / "config" / "site_access.yml").read_text())
CADDY = (ROOT / "app" / "deploy" / "Caddyfile").read_text()
SITE = ROOT / "site"

# Caddy exclusions that have no home in config/site_access.yml. The policy
# schema classifies static FILE paths under site/; these are reverse-proxied
# ROUTES to macro-api (app/main.py), which enforces its own auth. Excluding them
# from the static matchers is what stops a ws upgrade / API call from being
# swallowed by the file gate — it is not a public-content decision.
#
# /sb/* is the same class, added by #4680 (Supabase endpoint inside the GFW
# perimeter): a `handle_path /sb/*` reverse proxy whose upstream issues its own
# 401, not a file under site/. That PR added the route to all six Caddy matchers
# but not here, which reddened this test ON MAIN — listing it in the policy's
# `public` block instead would be wrong twice over, since it names no static
# asset and would read as a serving-boundary widening it is not.
NON_POLICY_ROUTES = {"/api/*", "/ws/tape", "/sb/*"}

# Public policy entries whose target is a RUNTIME artifact, not a committed
# file. site/live/ is gitignored: the systemd lanes publish by atomic rename
# into /var/lib/macro-live/public and scripts/live_breadth_poller.py force-adds
# a snapshot, so a fresh checkout may hold none of them. The policy line is
# still the boundary of record — only the on-disk existence check is exempt.
#
# The qualifying property is the DELIVERY path, NOT "is the content generated".
# site/live/ reaches the edge out of band, so a fresh checkout legitimately lacks
# it. A tree that reaches the edge only by being COMMITTED — "the VPS serves
# committed main; there is no Pages-artifact fallback" (render.yml) — is committed
# content no matter which builder emits it, and belongs in the existence check.
#
# /research/ was added here by #3507 to clear the #3488 red and is REMOVED again:
# it is render-lane output delivered by `git add site/`, and the exemption required
# gitignoring site/research/ to satisfy the honesty guard below. A gitignored
# subtree makes `git add site/` silently skip every NEW file — edits to the pages
# already tracked keep staging, new ones never do — so the estate would have frozen
# at the 86 pages #3501 landed while the research-ingest lane kept growing
# catalog.json: the exact "shipped dark" failure #3487 had just fixed. The tree is
# committed, so the assertion below now passes on its own merits.
RUNTIME_ARTIFACT_PREFIXES = ("/live/",)

# Shown on every missing-target failure. A public entry that points at nothing is a
# REAL defect (the edge advertises a path that 404s), so this stays a hard failure --
# but the cheap exit is the wrong one and #3507 proves the bait works: when a policy
# entry lands before its content, the red reads "missing public prefix" and the
# nearest fix is RUNTIME_ARTIFACT_PREFIXES. Name the two real remedies instead.
_MISSING_TARGET_HINT = (
    "config/site_access.yml declares it public but that path does not exist under "
    "site/. Either land the content first (a CI-generated tree needs its builder's "
    "first output committed BEFORE the policy entry -- see #3487/#3488/#3501), or "
    "drop the policy entry until it does. Do NOT add it to RUNTIME_ARTIFACT_PREFIXES "
    "unless the content reaches the edge WITHOUT being committed: that exemption "
    "requires gitignoring the tree, which silently stops the render lane's "
    "`git add site/` from ever shipping a new file under it."
)


def _caddy_public_exclusions() -> set[str]:
    match = re.search(
        r"# PUBLIC-BOUNDARY-START.*?@reg_asset\s*\{\s*not path ([^\n]+)",
        CADDY,
        flags=re.S,
    )
    assert match, "Caddy public-boundary marker/matcher missing"
    return set(shlex.split(match.group(1)))


def test_caddy_public_boundary_matches_policy_exactly():
    expected = set(NON_POLICY_ROUTES) | {"*.html"}
    expected.update(POLICY["public"]["exact"])
    expected.update(prefix.rstrip("/") + "/*" for prefix in POLICY["public"]["prefixes"])
    assert _caddy_public_exclusions() == expected


def test_intl_workspace_dependencies_are_public_presentation_assets():
    """The public HTML must be able to load its reviewed CSS and local controls."""
    template = (ROOT / "templates" / "intl.html.j2").read_text()
    assets = {
        "/" + path
        for path in re.findall(r'(?:src|href)="(intl_[^"?#]+\.(?:css|js))"', template)
    }
    assert assets == {
        "/intl_workspace.css",
        "/intl_workspace_macro.css",
        "/intl_workspace_risk.css",
        "/intl_workspace_history.css",
        "/intl_workspace_surveillance.css",
        "/intl_workspace_state.js",
        "/intl_library_search.js",
        "/intl_workspace_scenario.js",
        "/intl_workspace.js",
        "/intl_workspace_entry.js",
    }
    public = POLICY["public"]
    assert assets <= set(public["exact"])
    assert assets.isdisjoint(POLICY["free_registered"]["exact"])
    policy_patterns = list(public["exact"]) + [
        prefix.rstrip("/") + "/*" for prefix in public["prefixes"]
    ]
    serving_patterns = {"policy": policy_patterns}
    for matcher in ("reg_asset", "reg_asset_err", "public_static", "public_versioned"):
        block = re.search(rf"@{matcher}\s*\{{(.*?)^\s*\}}", CADDY, flags=re.S | re.M)
        assert block, matcher
        directive = "not path" if matcher.startswith("reg_asset") else "path"
        paths = {
            token
            for line in block.group(1).splitlines()
            if line.lstrip().startswith(directive + " ")
            for token in shlex.split(line.lstrip().removeprefix(directive).strip())
        }
        # Require the reviewed filenames themselves, never a broad /intl* rule.
        assert assets <= paths, matcher
        serving_patterns[matcher] = paths
        if matcher.startswith("reg_asset"):
            # API requests bypass the static gate and retain router-owned auth.
            assert "/api/*" in paths
        else:
            for route in ("/api/regwall/check", "/api/paywall/check"):
                assert not any(fnmatchcase(route, p) for p in paths)
    for route in ("/api/regwall/check", "/api/paywall/check"):
        assert not any(fnmatchcase(route, p) for p in policy_patterns)

    # These inputs are not publication assets. Even an accidentally copied raw
    # file, or a similarly named future data script, must not inherit UI access.
    protected = {
        "/intl_macro/country_inputs.json",
        "/intl_macro/provenance.json",
        "/intl_macro/ez_depo_rate.parquet",
        "/data/intl_macro/country_inputs.json",
        "/data/intl_macro/provenance.json",
        "/data/intl_macro/ez_depo_rate.parquet",
        "/data/run_status.json",
        "/macrodata/intl_macro/country_inputs.json",
        "/intl_workspace_data.js",
        "/intl_workspace.json",
        "/intl_workspace.js.map",
        "/intl_workspace.js/extra",
        "/intl_workspace_private.css",
    }
    for boundary, patterns in serving_patterns.items():
        for path in protected:
            assert not any(fnmatchcase(path, pattern) for pattern in patterns), (boundary, path)
    assert "/macrodata/" in POLICY["free_registered"]["prefixes"]
    for asset in assets:
        assert (ROOT / "templates" / asset[1:]).read_bytes() == (SITE / asset[1:]).read_bytes()



def test_intl_deferred_presentation_is_published_public_and_never_immutable():
    """Every page descriptor resolves to coherent public presentation bytes."""
    import json

    prefix = "/assets/intl-workspace/"
    pattern = prefix + "*"
    assert prefix in POLICY["public"]["prefixes"]
    assert prefix not in RUNTIME_ARTIFACT_PREFIXES
    html = (SITE / "intl.html").read_text()
    descriptors = [
        json.loads(raw)
        for raw in re.findall(
            r'<script[^>]*data-im-deferred-manifest[^>]*>(.*?)</script>',
            html,
            flags=re.S,
        )
    ]
    assert descriptors, "The public policy must land with the real emitted page."
    referenced = set()
    for descriptor in descriptors:
        for asset in descriptor["variants"].values():
            route = "/" + asset["url"]
            assert route.startswith(prefix) and route.endswith(".json")
            raw = (SITE / asset["url"]).read_bytes()
            assert len(raw) == asset["bytes"]
            assert hashlib.sha256(raw).hexdigest() == asset["sha256"]
            assert json.loads(raw)["generation"] == descriptor["generation"]
            referenced.add(route)
    emitted = {"/" + str(path.relative_to(SITE))
               for path in (SITE / prefix.strip("/")).glob("*.json")}
    assert emitted == referenced

    for matcher in ("reg_asset", "reg_asset_err"):
        block = re.search(rf"@{matcher}\s*\{{(.*?)^\s*\}}", CADDY, re.S | re.M)
        assert block
        paths = {token for line in block.group(1).splitlines()
                 if line.lstrip().startswith("not path ")
                 for token in shlex.split(line.lstrip().removeprefix("not path "))}
        assert pattern in paths
        assert all(any(fnmatchcase(route, p) for p in paths) for route in referenced)
    for matcher in ("public_static", "public_versioned"):
        block = re.search(rf"@{matcher}\s*\{{(.*?)^\s*\}}", CADDY, re.S | re.M)
        assert block
        paths = {token for line in block.group(1).splitlines()
                 if line.lstrip().startswith("path ")
                 for token in shlex.split(line.lstrip().removeprefix("path "))}
        assert not any(fnmatchcase(route, p) for route in referenced for p in paths)
    assert re.search(r"@intl_workspace_fragments\s+path\s+/assets/intl-workspace/\*", CADDY)
    assert re.search(
        r'header\s+@intl_workspace_fragments\s+Cache-Control\s+"no-store"', CADDY
    )
    # This header has no query condition: ?v=sha requests receive no-store too.
    cache_match = re.search(r"@intl_workspace_fragments\s+path\s+([^\n]+)", CADDY)
    assert cache_match and shlex.split(cache_match.group(1)) == [pattern]
    protected = (
        "/assets/intl-workspace-private/country_inputs.json",
        "/intl_macro/country_inputs.json", "/data/intl_macro/provenance.json",
        "/macrodata/intl_macro/country_inputs.json", "/api/intl-workspace",
    )
    assert not any(fnmatchcase(route, pattern) for route in protected)
    workflow = yaml.load((ROOT / ".github/workflows/render.yml").read_text(),
                         Loader=yaml.BaseLoader)
    assert "lib/intl_workspace_fragments.py" in workflow["on"]["push"]["paths"]


def test_help_build_clock_is_one_exact_public_ui_asset():
    """Public Help must load its local clock; nearby resources stay gated."""
    asset = "/help_refresh.js"
    assert asset in POLICY["public"]["exact"]
    assert (ROOT / "templates" / asset[1:]).read_bytes() == (SITE / asset[1:]).read_bytes()
    adjacent = {"/help_refresh.json", "/help_refresh.js.map", "/help_refresh_private.js",
                "/api/help_refresh", "/help_refresh.js/private"}
    assert not adjacent.intersection(POLICY["public"]["exact"])
    for matcher in ("reg_asset", "reg_asset_err", "public_static", "public_versioned"):
        block = re.search(rf"@{matcher}\s*\{{(.*?)^\s*\}}", CADDY, flags=re.S | re.M)
        assert block, matcher
        directive = "not path" if matcher.startswith("reg_asset") else "path"
        paths = {p for line in block.group(1).splitlines()
                 if line.lstrip().startswith(directive + " ")
                 for p in shlex.split(line.lstrip().removeprefix(directive).strip())}
        assert asset in paths, matcher
        assert not adjacent.intersection(paths), matcher
        assert not any(p.startswith("/help_refresh") and p != asset for p in paths), matcher


def test_market_memory_callback_assets_load_before_session_exchange():
    """OAuth returns before its code becomes a session; UI-only assets must load."""
    assets = {"/market_memory_intent.js", "/market_memory_retained.js",
              "/market_memory_retained.css"}
    assert assets <= set(POLICY["public"]["exact"])
    assert assets <= _caddy_public_exclusions()
    for matcher in ("reg_asset_err", "public_static", "public_versioned"):
        block = re.search(rf"@{matcher}\s*\{{(.*?)^\s*\}}", CADDY, flags=re.S | re.M)
        assert block, matcher
        directive = "not path" if matcher == "reg_asset_err" else "path"
        paths = {p for line in block.group(1).splitlines()
                 if line.lstrip().startswith(directive + " ")
                 for p in shlex.split(line.lstrip().removeprefix(directive).strip())}
        assert assets <= paths, matcher
        # Never make evidence responses public or cache them as UI assets.
        assert not any(p.startswith("/api/market-memory") for p in paths)
    for asset in assets:
        assert (ROOT / "templates" / asset[1:]).read_bytes() == (SITE / asset[1:]).read_bytes()



def test_macro_risk_overlay_script_public_but_signal_payload_remains_gated():
    """The public macro shell cannot parser-block on a registration-gated JS asset."""
    asset = "/risk_envelope_live.js"
    feed = "/live/risk_envelope.json"
    public = POLICY["public"]
    assert asset in public["exact"]
    assert asset in _caddy_public_exclusions()
    assert feed not in public["exact"]
    assert not any(feed.startswith(p.rstrip("/") + "/") for p in public["prefixes"])
    for name in ("reg_asset_err", "public_static", "public_versioned"):
        block = re.search(rf"@{name}\s*\{{(.*?)^\s*\}}", CADDY, flags=re.S | re.M)
        assert block, name
        directive = "not path" if name == "reg_asset_err" else "path"
        paths = [p for line in block.group(1).splitlines()
                 if line.lstrip().startswith(directive + " ")
                 for p in shlex.split(line.lstrip().removeprefix(directive).strip())]
        assert asset in paths, name
        assert feed not in paths, name
    template = (ROOT / "templates" / "dashboard.html.j2").read_text()
    assert '<script async src="risk_envelope_live.js"></script>' in template
    assert '<script async src="release_publications_live.js"></script>' in template


def test_biocatalyst_shell_assets_are_public_but_payload_api_stays_paid():
    shell_paths = {"/biocatalyst.html", "/biocatalyst.css", "/biocatalyst.js"}
    assert shell_paths <= set(POLICY["public"]["exact"])
    assert shell_paths.isdisjoint(POLICY["free_registered"]["exact"])
    assert shell_paths <= _caddy_public_exclusions()

    error_matcher = re.search(
        r"@reg_asset_err\s*\{\s*not path ([^\n]+)", CADDY, flags=re.S
    )
    assert error_matcher, "Caddy matcher @reg_asset_err missing"
    assert shell_paths <= set(shlex.split(error_matcher.group(1)))

    for matcher in ("public_static", "public_versioned"):
        block = re.search(rf"@{matcher}\s*\{{(.*?)^\s*\}}", CADDY, flags=re.S | re.M)
        assert block, f"Caddy matcher @{matcher} missing"
        paths = {
            token
            for path_line in re.findall(r"^\s*path\s+([^\n]+)", block.group(1), flags=re.M)
            for token in shlex.split(path_line)
        }
        assert {"/biocatalyst.css", "/biocatalyst.js"} <= paths

    api_source = (ROOT / "app" / "biocatalyst.py").read_text()  # ci-trigger-closure: data - this test checks the file's text, not its imports; the job's paths: list it
    assert "def require_site_full_user(" in api_source
    assert "Depends(require_site_full_user)" in api_source
    assert "enforce_site_full" in api_source


def test_ontology_trace_assets_are_public_but_the_snapshot_api_stays_paid():
    """F04-X1: the shell's CSS/JS are reachable anonymously; every current value is not.

    The page is a public-safe shell whose only endpoint reference is the
    authenticated snapshot API, so its presentation assets must be anonymously
    reachable or the shell renders unstyled and inert for logged-out visitors.
    The asset route is default-deny and compared byte-for-byte against this
    policy, so an omission here is invisible until someone opens the page.
    """
    assets = {"/ontology.css", "/ontology.js"}
    assert assets <= set(POLICY["public"]["exact"])
    assert assets.isdisjoint(POLICY["free_registered"]["exact"])
    assert assets <= _caddy_public_exclusions()

    error_matcher = re.search(
        r"@reg_asset_err\s*\{\s*not path ([^\n]+)", CADDY, flags=re.S
    )
    assert error_matcher, "Caddy matcher @reg_asset_err missing"
    assert assets <= set(shlex.split(error_matcher.group(1)))

    for matcher in ("public_static", "public_versioned"):
        block = re.search(rf"@{matcher}\s*\{{(.*?)^\s*\}}", CADDY, flags=re.S | re.M)
        assert block, f"Caddy matcher @{matcher} missing"
        paths = {
            token
            for path_line in re.findall(r"^\s*path\s+([^\n]+)", block.group(1), flags=re.M)
            for token in shlex.split(path_line)
        }
        assert assets <= paths

    # The snapshot itself is never public: no payload path is whitelisted, and
    # the router resolves the shared authority rather than declaring a second one.
    public_exact = set(POLICY["public"]["exact"])
    assert not any(path.startswith("/api/ontology") for path in public_exact)
    api_source = (ROOT / "app" / "ontology_explorer.py").read_text()  # ci-trigger-closure: data - this test checks the file's text, not its imports; the job's paths: list it
    assert "from app.main import require_user" in api_source
    assert "enforce_site_full" in api_source
    assert "always=True" in api_source


def test_retired_movers_route_redirects_to_the_consolidated_hub_section():
    redirect_lines = [
        line.strip()
        for line in CADDY.splitlines()
        if line.strip().startswith("redir @movers_seo_redirect ")
    ]
    assert redirect_lines == [
        'redir @movers_seo_redirect "/stocks/index.html#today-movers" 301'
    ]
    # Only the trusted shell tuple is exempt; the separate matcher test and
    # real Caddy boundary cases retain every standalone/negative SEO redirect.
    assert 'path /movers.html' in CADDY
    assert not re.search(r"^\s*redir /movers\.html ", CADDY, re.M)


def test_html_documents_are_never_registration_gated():
    """The registration wall must not be reachable from any HTML serving path.

    Operator 2026-08-04 opened every page shell to anonymous visitors. The wall
    lived in two matchers -- @reg_html (success path) and @reg_html_err (the
    fail-closed path that actually emitted `302 -> /?signin=1`). Both are
    retired. This test is the tripwire: re-introducing either name, or wiring a
    regwall/paywall sub-request into an HTML handler, silently restores the
    redirect this change exists to delete.

    It deliberately asserts on ABSENCE plus the positive replacement, because an
    absence-only test would also pass if someone deleted the whole serving
    block.
    """
    # Match the SYNTAX (a matcher definition or a handler binding), not the bare
    # name -- the Caddyfile's own block comment explains why @reg_html was
    # retired, and a substring test would flag that prose as the defect.
    for pattern in (r"@reg_html(?:_err)?\s*\{", r"handle\s+@reg_html(?:_err)?\b"):
        assert not re.search(pattern, CADDY), (
            f"a live `{pattern}` construct is back in the Caddyfile. HTML "
            "documents are open (config/site_access.yml header); a page shell "
            "must never be routed through /api/regwall/check again."
        )
    # ...and the replacement must actually be serving them.
    assert re.search(r"@open_html\s*\{", CADDY), "@open_html matcher missing"
    open_body = re.search(r"handle @open_html\s*\{(.*?)^\t\}", CADDY, flags=re.S | re.M)
    assert open_body, "handle @open_html block missing"
    for wall in ("regwall/check", "paywall/check"):
        assert wall not in open_body.group(1), (
            f"handle @open_html routes through {wall}; open pages would be gated"
        )


def test_product_family_is_public_in_every_caddy_html_path():
    """Success and fail-open/error matchers must agree on the public product tree."""
    for matcher in (
        "reg_asset",
        "gate_html",
        "reg_asset_err",
        "gate_html_err",
    ):
        match = re.search(rf"@{matcher}\s*\{{(.*?)^\s*\}}", CADDY, flags=re.S | re.M)
        assert match, f"Caddy matcher @{matcher} missing"
        path_lines = re.findall(r"^\s*(?:not\s+)?path\s+([^\n]+)", match.group(1), flags=re.M)
        matcher_paths = {
            token
            for path_line in path_lines
            for token in shlex.split(path_line)
        }
        assert "/products/*" in matcher_paths, (
            f"@{matcher} does not expose /products/*; anonymous product pages "
            "would change behavior between normal and error paths"
        )


def test_confluence_lead_magnet_is_public_in_every_caddy_html_path():
    """The free screener must never regress behind the account wall.

    Its paid ticker rows are omitted server-side by the builder; the static page
    is the intentionally public acquisition shell.
    """
    page = "/confluence_screener.html"
    assert page in POLICY["public"]["exact"]
    for matcher in (
        "reg_asset",
        "gate_html",
        "reg_asset_err",
        "gate_html_err",
    ):
        match = re.search(rf"@{matcher}\s*\{{(.*?)^\s*\}}", CADDY, flags=re.S | re.M)
        assert match, f"Caddy matcher @{matcher} missing"
        matcher_paths = {
            token
            for path_line in re.findall(
                r"^\s*(?:not\s+)?path\s+([^\n]+)",
                match.group(1),
                flags=re.M,
            )
            for token in shlex.split(path_line)
        }
        assert page in matcher_paths, (
            f"@{matcher} does not expose {page}; the free screener would be "
            "registration-gated on this serving path"
        )


def test_public_policy_targets_exist():
    for path in POLICY["public"]["exact"]:
        if path == "/" or path.startswith(RUNTIME_ARTIFACT_PREFIXES):
            continue
        assert (SITE / path.lstrip("/")).is_file(), (
            f"missing public exact path: {path} -- {_MISSING_TARGET_HINT}"
        )
    for prefix in POLICY["public"]["prefixes"]:
        if prefix.startswith(RUNTIME_ARTIFACT_PREFIXES):
            continue
        assert (SITE / prefix.strip("/")).is_dir(), (
            f"missing public prefix: {prefix} -- {_MISSING_TARGET_HINT}"
        )


def test_public_theme_imports_are_declared_public():
    """A public stylesheet must not import an asset hidden behind the regwall."""
    public_exact = set(POLICY["public"]["exact"])
    theme = (SITE / "theme.css").read_text()
    imports = re.findall(r'@import\s+url\(["\']?([^"\')?]+)', theme)
    assert imports, "site/theme.css should expose its external dependencies"
    for imported in imports:
        public_path = "/" + imported.split("?", 1)[0].lstrip("/")
        assert public_path in public_exact, (
            f"public theme.css imports gated asset {public_path}; "
            "declare the UI dependency in config/site_access.yml"
        )


def test_public_product_motion_assets_are_declared_public():
    """Anonymous product stories must receive their shared choreography."""
    public_exact = set(POLICY["public"]["exact"])
    caddy_public = _caddy_public_exclusions()
    for asset in ("/scene-motion.css", "/scene-motion.js"):
        assert asset in public_exact
        assert asset in caddy_public
        assert (SITE / asset.lstrip("/")).is_file()


def test_runtime_artifact_exemption_stays_honest():
    """The existence exemption is only legitimate for genuinely gitignored
    planes. If site/live/ ever became a committed tree, the exemption would
    start hiding typo'd/dead public policy entries instead of runtime churn."""
    ignored = {line.strip() for line in (ROOT / ".gitignore").read_text().splitlines()}
    for prefix in RUNTIME_ARTIFACT_PREFIXES:
        assert f"site{prefix}" in ignored, f"exempt prefix is not gitignored: site{prefix}"


def test_exempt_prefixes_publish_out_of_band():
    """Closes the hole BOTH existing guards leave open: the exemption and the
    .gitignore added TOGETHER.

    test_runtime_artifact_exemption_stays_honest asks "is it gitignored" -- which
    an author silencing a red can simply make true. test_public_estates_stay_committable
    skips exempt prefixes by construction. So the exact #3507 change (add /research/
    to RUNTIME_ARTIFACT_PREFIXES *and* site/research/ to .gitignore) passes both:
    verified by replaying it against the post-#3504/#3522 suite -- 8 passed. Only the
    gitignore half done ALONE was ever caught.

    The property that actually separates the two planes is DELIVERY, and it leaves a
    mechanical trace. A gitignored tree is invisible to the render lane's plain
    `git add site/`, so anything legitimately shipped from one must be named by an
    explicit `git add -f`:

        site/live/     14 tracked files, every one force-added by name across
                       intraday-fastpath / earlyclose / closing-bell / btc-live /
                       daily -- a genuine out-of-band plane with committed fallbacks.
        site/research/ 87 tracked files under #3507, ZERO force-adds anywhere. They
                       could only have arrived via plain `git add site/`, which is
                       proof the prefix is commit-delivered and the exemption false.

    So: if the repo TRACKS files under an exempt prefix and nothing force-adds there,
    the exemption contradicts how the content actually reaches the edge.
    """
    workflows = ROOT / ".github" / "workflows"
    wf_text = "\n".join(
        p.read_text() for p in sorted(workflows.glob("*.yml")) if p.is_file()
    )
    for prefix in RUNTIME_ARTIFACT_PREFIXES:
        tree = f"site{prefix}"                      # e.g. "site/live/"
        proc = subprocess.run(
            ["git", "ls-files", "--", tree],
            cwd=ROOT,
            capture_output=True,
            text=True,
        )
        # Never read a broken git as "nothing tracked" -- that is the vacuous-green
        # failure this whole module keeps re-learning.
        assert proc.returncode == 0, (
            f"git ls-files unusable (rc={proc.returncode}), so this guard cannot "
            f"vouch for {tree}: {proc.stderr.strip()}"
        )
        tracked = [ln for ln in proc.stdout.splitlines() if ln.strip()]
        if not tracked:
            continue                                 # purely runtime -- nothing to explain
        assert re.search(rf"add\s+(?:-f|--force)\s+[^\n]*{re.escape(tree)}", wf_text), (
            f"{tree} is exempt as a runtime artifact and gitignored, yet the repo "
            f"tracks {len(tracked)} file(s) under it and NO workflow force-adds there "
            f"(`git add -f {tree}...`). Plain `git add site/` cannot stage an ignored "
            f"path, so those files prove the prefix is delivered by being COMMITTED -- "
            f"it is not a runtime plane. Either drop it from RUNTIME_ARTIFACT_PREFIXES "
            f"and un-ignore it (what #3522 did for /research/), or, if it really does "
            f"publish out of band, force-add its committed fallbacks by name the way "
            f"site/live/ does. See #3501/#3507/#3522."
        )


def test_public_estates_stay_committable():
    """The inverse guard: a NON-exempt public path must not be gitignored.

    Everything above is about the exemption being honest. This is about the 87%
    of the boundary that takes no exemption: those paths reach the edge only by
    being committed ("the VPS serves committed main; there is no Pages-artifact
    fallback" -- render.yml), and the render lane ships them with `git add site/`,
    which SKIPS ignored new files. So ignoring a served estate does not fail --
    it freezes. Edits to already-tracked pages keep staging, so the nightly diff
    still looks alive, while every new page silently never lands and the tracked
    index keeps linking to them.

    That is not hypothetical: #3507 ignored site/research/ hours after #3501
    committed 86 pages there, and the pair merged 32s apart. #3522 reverted it;
    this is the tripwire neither had. The existence check alone cannot catch it
    (the directory is present -- it is the NEXT file that vanishes), which is why
    it needs its own probe.
    """
    probes: dict[str, str] = {}
    for path in POLICY["public"]["exact"]:
        if path == "/" or path.startswith(RUNTIME_ARTIFACT_PREFIXES):
            continue
        probes[f"site{path}"] = path
    for prefix in POLICY["public"]["prefixes"]:
        if prefix.startswith(RUNTIME_ARTIFACT_PREFIXES):
            continue
        # A path that cannot exist, so this asks the ignore RULES rather than
        # the index -- exactly the question `git add site/` asks of a new page.
        probes[f"site{prefix}_ignore_probe.html"] = prefix

    proc = subprocess.run(
        ["git", "check-ignore", "--stdin"],
        cwd=ROOT,
        input="\n".join(probes) + "\n",
        capture_output=True,
        text=True,
    )
    # 0 = at least one path matched an ignore rule, 1 = none did. Anything else
    # (128 = not a git repo / git missing) must NOT be read as "nothing is
    # ignored" -- that is precisely how this guard would go vacuously green off
    # a checkout, reporting safety it never checked.
    assert proc.returncode in (0, 1), (
        f"git check-ignore unusable (rc={proc.returncode}), so this guard cannot "
        f"vouch for anything: {proc.stderr.strip()}"
    )
    offenders = sorted({probes[ln] for ln in proc.stdout.splitlines() if ln in probes})
    assert not offenders, (
        f"public path(s) {offenders} are gitignored. They are served from the "
        "committed tree, so the render lane's `git add site/` will silently skip "
        "every NEW file under them -- the estate freezes at whatever is tracked "
        "today while the builder keeps emitting pages that never ship. Either "
        "un-ignore them, or force-add them in render.yml the way site/stockbrief "
        "is. See #3501/#3507/#3522."
    )


def _gh_path_filter_to_re(pattern: str) -> re.Pattern:
    """GitHub filter-pattern globbing: `*` stays inside a segment, `**` crosses `/`.

    Deliberately not fnmatch, whose `*` crosses `/` — that is looser than GitHub
    and would report a path as covered when a PR touching it would trigger nothing.
    """
    out: list[str] = []
    i = 0
    while i < len(pattern):
        if pattern[i] == "*":
            if pattern[i + 1:i + 2] == "*":
                out.append(".*")
                i += 2
            else:
                out.append("[^/]*")
                i += 1
        elif pattern[i] == "?":
            out.append("[^/]")
            i += 1
        else:
            out.append(re.escape(pattern[i]))
            i += 1
    return re.compile("^" + "".join(out) + "$")


def test_tier_gate_is_reachable_from_its_own_inputs():
    """A guard the guarded change cannot trigger is not a guard.

    ci.yml is `on: pull_request` with a ~530-entry `paths:` filter, so a job whose
    inputs are unlisted still exists but fires only as a bystander — on unrelated
    PRs that happen to touch a listed path. Until 2026-07-25 that was true of ALL
    eleven of tier-gate's inputs. #3488 changed exactly config/site_access.yml +
    Caddyfile + regwall.py, triggered no workflow at all, and merged with this
    suite never executed; `missing public prefix: /research/` then sat red on main
    and surfaced on everyone else's PR. #3474 gave the test a workflow that NAMES
    it; nothing gave it a trigger that REACHES it — two separate halves.

    They are all listed today. This keeps them listed, and is derived rather than
    hand-copied: it reads the tier-gate job's own `run:` steps, so a test file
    added to the job later is required in the filter automatically.
    """
    ci = yaml.safe_load((ROOT / ".github" / "workflows" / "ci.yml").read_text())
    manifest = yaml.safe_load(
        (ROOT / ".github" / "ci" / "legacy-jobs.yml").read_text()
    )
    # PyYAML resolves the bare key `on` to True (YAML 1.1 booleans).
    triggers = ci.get("on") or ci.get(True)
    matchers = [_gh_path_filter_to_re(p) for p in triggers["pull_request"]["paths"]]

    steps = [
        step
        for job in ("tier-gate", "paywall-contracts", "site-access-boundary")
        for step in manifest["jobs"][job]["steps"]
    ]
    required = set(re.findall(
        r"tests/test_[A-Za-z0-9_]+\.py",
        "\n".join(s["run"] for s in steps if "run" in s),
    ))
    assert required, "tier-gate runs no pytest targets — did the job change shape?"
    # Subjects under test that no `run:` line names: the two halves of the boundary
    # this module diffs, plus the routers the regwall/paywall suites exercise.
    required |= {"config/site_access.yml", "app/deploy/Caddyfile",
                 "app/regwall.py", "app/paywall.py"}  # ci-trigger-closure: data - a file NAME, never opened here

    unreachable = sorted(t for t in required if not any(m.match(t) for m in matchers))
    assert unreachable == [], (
        f"tier-gate inputs missing from ci.yml's pull_request paths: {unreachable}. "
        "A PR touching only these would run no serving-boundary guard at all — the "
        "#3488 failure mode. Add each to the paths list."
    )


def test_boundary_suites_report_apart_from_the_tier_preview_step():
    """A failed step skips the rest of its job, so no shell check may run ahead of these.

    They used to follow the bake-dependent tier-preview step inside tier-gate, and
    that step's reds kept them from running at all in the main heartbeat.
    """
    suite = "tests/test_site_access_boundary.py"
    for path in (".github/ci/legacy-jobs.yml", ".github/workflows/ci-main-heartbeat.yml"):
        jobs = yaml.safe_load((ROOT / path).read_text())["jobs"]

        def owners(test_file):
            return [
                name
                for name, job in jobs.items()
                if any(test_file in step.get("run", "") for step in job["steps"])
            ]

        assert owners(suite) == ["site-access-boundary"], path
        assert [
            step["run"] for step in jobs["site-access-boundary"]["steps"]
            if " -m pytest " in step.get("run", "")
        ] == [f"python -m pytest {suite} -q"], path
        assert owners("tests/test_paywall.py") == ["paywall-contracts"], path
        assert owners("tests/test_regwall.py") == ["paywall-contracts"], path
        assert "tier-gate" in owners("tests/test_us_board_gate.py"), path


def test_boundary_suite_is_on_the_merge_gate():
    """ci.yml packs `gate: code` only. On `gate: data` a breach of the public list merges on green."""
    job = yaml.safe_load((ROOT / ".github/ci/legacy-jobs.yml").read_text())["jobs"]["site-access-boundary"]
    assert job["gate"] == "code"
    assert job["scope"] == "exclusive"
    # The closure notes above excuse these two text reads because the job lists them.
    for name in ("biocatalyst", "ontology_explorer"):
        assert f"app/{name}.py" in job["paths"]


def test_generated_data_is_not_accidentally_public():
    public = _caddy_public_exclusions()
    intentional = {
        # Reviewed machine-readable marketing metadata; contains no signal rows.
        "/brand-facts.json",
        "/live/quotes.json",
        "/live/intraday_quotes.json",
        "/live/flow_pulse.json",
        "/live/breadth.json",
        # Official agency publication lifecycle and verified factual outcomes.
        "/live/release_publications.json",
        # Freshness-sentinel staleness state (masterplan W1 dead-man switch).
        # Per-surface freshness verdicts and timestamps only — no ticker rows,
        # scores, or board membership. Public by design: it feeds the on-site
        # staleness banner, which anonymous visitors must see too.
        "/live/staleness.json",
        "/prophet/showcase.json",
        "/seasonalitydata/methodology.json",
        # Stock seasonality calendar clock. Computed calendar statistics over
        # public split/dividend-adjusted price history, shipped WITH the
        # selection accounting that prices them: no forecast, no score, no
        # cross-symbol ordering, no board membership. index.json is the covered
        # -symbol catalog plus the program-level fire rates the honesty strip
        # prints; the SPY entity is the ONE committed per-symbol panel, kept so
        # the page has an honest first paint. Every other entity file is
        # gitignored and served from R2, which is why this is two exact entries
        # and not a /seasonalitydata/ prefix.
        "/seasonalitydata/index.json",
        "/seasonalitydata/entities/SPY.json",
        "/factordata/tech_lab.json",
        # The China A-share tile map (SEO_SUPERCHARGE W2, spec §A2.4 / T-A1).
        # It is what china_heatmap.html renders and it cannot be withheld without
        # leaving that page blank for the anonymous visitors the conversion is
        # for. Contents: ticker, name, sector, market cap, per-window returns, and
        # the two market facts the hover card shows (last close, distance from the
        # 200-day average). No score, no rank, no verdict, no board membership —
        # the graded per-name read lives in <market>stockdata/<T>.json, which is
        # deliberately absent from this list and keeps its default-deny class.
        #
        # This IS a give: a clean daily-close A-share returns dataset, trivially
        # scrapable. Same class as the public quote planes above (market context,
        # daily cadence, delay disclosed) and accepted as such — registered here
        # rather than assumed, which is the whole point of this test.
        "/marketdata/china_heatmap.json",
        # Static Natural Earth geometry required by the public start-page globe.
        "/world-110m.json",
    }
    exposed_json = {p for p in public if p.endswith(".json")}
    assert exposed_json == intentional
    assert "/factordata/tech_events/*" in public
    assert "/factordata/*" not in public
    assert "/labdata/*" not in public
    assert "/neuralwebdata/*" not in public
    assert "/oracledata/*" not in public
    assert "/signals/*" not in public


def test_no_source_maps_secrets_or_server_source_in_site_tree():
    forbidden_suffixes = {".map", ".py", ".pyc", ".pem", ".key", ".env", ".sql"}
    bad = [
        p.relative_to(SITE).as_posix()
        for p in SITE.rglob("*")
        if p.is_file() and (p.suffix.lower() in forbidden_suffixes or p.name.startswith(".env"))
    ]
    assert bad == []


def test_baskets_seo_redirect_preserves_exact_trusted_shell_admission():
    # The moved stub must run its bridge.navigate before the parent commits a
    # successor generation. Query-preserving HTTP redirects still fail READY.
    match = re.search(r"@baskets_seo_redirect\s*\{(.*?)\n\t\}", CADDY, re.S)
    assert match
    assert " ".join(match.group(1).split()) == " ".join(r"""path /baskets_china.html
        not {
            query mmx_shell=1
            header_regexp Referer ^https://(beta|app)\.mastermind-x\.com/
        }""".split())
    assert "redir @baskets_seo_redirect /sector_central_china.html 301" in CADDY
    assert "redir /baskets_china.html " not in CADDY


def test_movers_seo_redirect_preserves_exact_trusted_shell_admission():
    match = re.search(r"@movers_seo_redirect\s*\{(.*?)\n\t\}", CADDY, re.S)
    assert match
    assert " ".join(match.group(1).split()) == " ".join(r"""path /movers.html
        not {
            query mmx_shell=1
            header_regexp Referer ^https://(beta|app)\.mastermind-x\.com/
        }""".split())
    assert 'redir @movers_seo_redirect "/stocks/index.html#today-movers" 301' in CADDY
    assert "redir /movers.html " not in CADDY


def test_fail_closed_and_browser_hardening_are_present():
    assert 'rewrite /api/regwall/check' in CADDY
    assert 'rewrite /api/paywall/check' in CADDY
    assert '{"error":"site_access_temporarily_unavailable"}' in CADDY
    assert "Content-Security-Policy \"base-uri 'self'; object-src 'none'; frame-ancestors 'none'\"" in CADDY
    assert 'X-Frame-Options "DENY"' in CADDY
    assert 'Permissions-Policy "camera=(), microphone=(), geolocation=(), usb=()"' in CADDY


# --- cache-policy drift (PR 3 of the 2026-08-20 performance remediation) ------
# scripts/optimize_assets.py stamps ?v=<sha256[:8]> on EVERY local .js/.css ref
# it finds in site/**/*.html — not a curated list. The Caddyfile splits cache
# policy on that stamp: @public_static carries `not query v=*`, so a stamped
# request only reaches @public_versioned. An asset reviewed public but missing
# from @public_versioned therefore matches NOTHING and is served with NO
# Cache-Control, which hands EdgeOne its long default TTL — the 2026-07-03
# white-page incident class. That silent hole is what these three tests close.

def _caddy_path_list(matcher: str) -> list[str]:
    m = re.search(r"@%s \{\s*\n\s*path ([^\n]+)\n" % re.escape(matcher), CADDY)
    assert m, f"@{matcher} matcher not found in the Caddyfile"
    return m.group(1).split()


def _matches(path: str, patterns: list[str]) -> bool:
    return any(
        path.startswith(p[:-1]) if p.endswith("*") else path == p for p in patterns
    )


def _served_stamps() -> dict[str, str]:
    """Root-relative asset path -> the ?v= stamp site/ actually serves for it."""
    ref = re.compile(r'(?:src|href)="([^"]+\.(?:js|css))\?v=([0-9a-zA-Z]+)"')
    out: dict[str, str] = {}
    for page in SITE.rglob("*.html"):
        parent = page.parent
        for url, stamp in ref.findall(page.read_text(encoding="utf-8", errors="replace")):
            if url.startswith(("http://", "https://", "//")):
                continue
            try:
                out["/" + str((parent / url).resolve().relative_to(SITE.resolve()))] = stamp
            except ValueError:
                continue
    return out


def test_immutable_cache_list_never_widens_the_access_boundary():
    """@public_versioned is a CACHE decision and must never be an access one.

    Every entry has to already be reviewed public — listed in @public_static or
    carried in the policy's `public.exact`. Without this, adding a member-only
    asset here would cache a gated body at the edge under a public key.
    """
    static = _caddy_path_list("public_static")
    exact = set(POLICY["public"]["exact"])
    unreviewed = [
        p for p in _caddy_path_list("public_versioned")
        if not _matches(p, static) and p not in exact
    ]
    assert not unreviewed, (
        "@public_versioned grants a cached-forever public response to paths with "
        f"no public review: {unreviewed}. Add them to config/site_access.yml "
        "`public.exact` deliberately, or drop them here."
    )


def test_every_stamped_public_asset_is_on_the_immutable_matcher():
    """The drift guard: a reviewed-public asset that is served ?v=-stamped must
    be on @public_versioned, or it falls through every matcher and ships with no
    Cache-Control at all."""
    if not SITE.is_dir():
        pytest.skip("site/ not checked out")
    static = _caddy_path_list("public_static")
    versioned = _caddy_path_list("public_versioned")
    handstamped = _caddy_path_list("watchlist_shell_versioned")
    missing = sorted(
        path for path in _served_stamps()
        if _matches(path, static)
        and not _matches(path, versioned)
        and not _matches(path, handstamped)
    )
    assert not missing, (
        f"{len(missing)} reviewed-public asset(s) are served ?v=-stamped but are "
        f"absent from @public_versioned, so they get NO Cache-Control: {missing}"
    )


def test_hand_stamp_carve_out_holds_only_hand_stamped_paths():
    """@watchlist_shell_versioned exists ONLY for hand-authored ?v=N integers,
    which must not be cached for a year. A path whose served stamp equals its own
    sha256[:8] is content-addressed and belongs on the immutable matcher instead
    — that is exactly how mtf.js and mm_brain.js sat at 300s after they became
    content-hashed, paying a revalidation on every navigation."""
    if not SITE.is_dir():
        pytest.skip("site/ not checked out")
    stamps = _served_stamps()
    wrong = []
    for path in _caddy_path_list("watchlist_shell_versioned"):
        served = stamps.get(path)
        if served is None:
            continue
        body = SITE / path.lstrip("/")
        if not body.is_file():
            continue
        if served == hashlib.sha256(body.read_bytes()).hexdigest()[:8]:
            wrong.append(f"{path}?v={served}")
    assert not wrong, (
        "these are content-hash stamped, so the 300s carve-out is wrong for them "
        f"— move them to @public_versioned: {wrong}"
    )


# ── R1A-M Intelligence Hub Market Pulse controller (freeze §10) ────────────
#
# The controller path is /assets/js/intelligence-hub-market-pulse.js. It does
# NOT get its own exact policy/Caddy entry: /assets/js/ is ALREADY a public
# `prefixes` entry (content-hashed page scripts, plus every other hand-
# authored file already living under site/assets/js/ — dossier-live-quote.js
# and company-intelligence-dossier.js carry no individual entry either), so
# adding one would duplicate an existing public prefix rather than opening a
# new one — exactly the "no broad /assets/ prefix may be OPENED" rule read
# backwards. These tests prove the boundary is exactly what the freeze
# requires without widening it: the path is public, it is NOT a new broad
# opening (no policy/Caddy edit landed with this route), and it is delivered
# byte-for-byte with no auth.

_IHMP_CONTROLLER_PATH = "/assets/js/intelligence-hub-market-pulse.js"


def test_ihmp_controller_is_public_via_the_existing_assets_js_prefix():
    assert "/assets/js/" in POLICY["public"]["prefixes"]
    assert _IHMP_CONTROLLER_PATH.rsplit("/", 1)[0] + "/" in POLICY["public"]["prefixes"]


def test_ihmp_controller_is_excluded_from_caddy_registration_gate():
    assert "/assets/js/*" in _caddy_public_exclusions()


def test_ihmp_controller_asset_exists_and_is_delivered_byte_for_byte():
    if not SITE.is_dir():
        pytest.skip("site/ not checked out")
    body = SITE / "assets" / "js" / "intelligence-hub-market-pulse.js"
    assert body.is_file(), _MISSING_TARGET_HINT
    text = body.read_text(encoding="utf-8")
    assert "window.IntelligenceHubMarketPulse" in text
    # a controller asset carries no server-side templating placeholder — the
    # exact bytes committed are the exact bytes served (matching the plain-
    # copy pairing convention for hand-authored site/assets/js/*.js files)
    assert "{{" not in text and "{%" not in text


def test_no_broad_assets_or_signal_data_prefix_was_opened_for_ihmp():
    """This route must not have widened the boundary to get its controller
    served — /assets/js/ already existed before R1A-M, and no new broad
    prefix (a bare /assets/ or a signal-data directory) appears in policy."""
    prefixes = set(POLICY["public"]["prefixes"])
    assert "/assets/" not in prefixes
    for p in prefixes:
        assert not p.startswith("/live/"), "a live/signal-data prefix must never be public"


def test_macro_suite_shell_assets_are_public_but_the_snapshot_payload_is_not():
    """The three presentation assets, and nothing that carries a reading.

    Production served the suite's HTML at 200 while these three answered 401,
    so every anonymous reader got an unstyled, themeless skeleton: the pages
    were public and their presentation was not. These are promoted as one unit
    for that reason -- and only these. The snapshot JSON under /macrodata/ is
    the actual product and stays gated; a prefix or wildcard promoted here
    would take it public with them.
    """
    shell_paths = {"/macro_suite.css", "/macro_suite_boot.js", "/macro_suite.js"}
    assert shell_paths <= set(POLICY["public"]["exact"])
    assert shell_paths.isdisjoint(POLICY["free_registered"]["exact"])
    assert shell_paths <= _caddy_public_exclusions()

    # The error path excludes them too, or an anonymous 401 page renders bare.
    error_matcher = re.search(r"@reg_asset_err\s*\{\s*not path ([^\n]+)", CADDY, flags=re.S)
    assert error_matcher, "@reg_asset_err matcher missing"
    assert shell_paths <= set(shlex.split(error_matcher.group(1)))

    # Cacheable as public, both plain and ?v= stamped, exactly like /markets.css.
    for block in ("@public_static", "@public_versioned"):
        matcher = re.search(rf"{block}\s*\{{\s*path ([^\n]+)", CADDY, flags=re.S)
        assert matcher, f"{block} matcher missing"
        assert shell_paths <= set(shlex.split(matcher.group(1))), block

    # No widening: the reading itself is not public by any route.
    public_prefixes = set(POLICY["public"]["prefixes"])
    assert not any(p.startswith("/macrodata") for p in public_prefixes)
    assert not any(p.startswith("/macrodata") for p in POLICY["public"]["exact"])
    assert not any(p.startswith("/macro_suite") and p.endswith("*")
                   for p in _caddy_public_exclusions()), "no wildcard may ride along"


def test_internal_document_denials_match_the_canonical_policy():
    """A Caddy-only denial must never be advertised by the route registry."""
    matcher = re.search(r"@never_site\s*\{\s*path ([^\n]+)", CADDY)
    assert matcher, "internal-document serving denial missing"
    declared = set(POLICY["deny"]["exact"])
    declared.update(prefix + "*" for prefix in POLICY["deny"].get("prefixes", []))
    assert set(shlex.split(matcher.group(1))) == declared


def test_portfolio_state_cache_migration_covers_every_served_consumer():
    """A path-wide immutable cache requires hash stamps on every consumer."""
    from lib.pages import optimize_assets_text

    asset = SITE / "portfolio_state.js"
    digest = hashlib.sha256(asset.read_bytes()).hexdigest()[:8]
    template = (ROOT / "templates/watchlist.html.j2").read_text()
    tag = '<script src="portfolio_state.js" data-sync></script>'
    assert tag in template  # Bare source joins the canonical re-stamping path.
    stamped = optimize_assets_text(tag, lambda path: digest if path == "portfolio_state.js" else None)
    served = (SITE / "watchlist.html").read_text()
    assert stamped in served and "defer" not in stamped
    for text, loading_tag in [(template, tag), (served, stamped)]:
        assert text.index(loading_tag) < text.index('<script src="watchlist.js?')
    refs = re.compile(r'<script\b[^>]*\bsrc="([^"]*portfolio_state\.js[^"]*)"[^>]*>')
    consumers = set()
    for page in SITE.rglob("*.html"):
        for url in refs.findall(page.read_text(encoding="utf-8", errors="replace")):
            if url.startswith(("http://", "https://", "//")):
                continue
            bare = url.split("?", 1)[0]
            if (page.parent / bare).resolve() != asset.resolve():
                continue
            assert url == bare + "?v=" + digest, (page.relative_to(SITE), url)
            consumers.add(str(page.relative_to(SITE)))
    assert {"watchlist.html", "ontology.html"} <= consumers
