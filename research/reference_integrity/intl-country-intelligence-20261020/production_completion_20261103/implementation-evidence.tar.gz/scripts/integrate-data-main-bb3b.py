from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018');P=Path('/tmp/intl-production-r4-20261104/proof');D=Path('/tmp/intl-resume-20261104')
old='005232fa54edbc6d271a796db6b15d5cd7443641';target='bb3b7273f1e9ccb869b6500c97871093eb22005a';head='851c6abebf01c5c8096e7822436455fd1040152a';merge='c6ac417f4a1d561f8c80a0a6b1977d5ffec6d090'
def g(*args,check=True):return subprocess.run(['git',*args],cwd=W,capture_output=True,check=check)
def txt(*args):return g(*args).stdout.decode().strip()
assert txt('rev-parse','HEAD')==head and txt('rev-parse','MERGE_HEAD')==merge and txt('rev-parse','origin/main')==target
assert not txt('ls-files','-u') and g('rev-parse','--verify','MERGE_AUTOSTASH',check=False).returncode!=0
changed=g('diff','--no-renames','--name-only',old,target).stdout.decode().splitlines();assert len(changed)==9123 and all(p.startswith('data/') for p in changed)
ours_delta=set(g('diff','--no-renames','--name-only',old).stdout.decode().splitlines());assert not set(changed)&ours_delta
pending=set(g('diff','--name-only').stdout.decode().splitlines()+g('ls-files','--others','--exclude-standard').stdout.decode().splitlines())
allowed=['site/assets/intl-workspace/','mockups/evidence/intl-design-reset-20261103/','research/reference_integrity/intl-country-intelligence-20261020/production_completion_20261103/']
exact={'site/intl.html','agentos/handoffs/PAPER-INTERNATIONAL-WAVES-2026-11-03.md','agentos/workstreams/WS-PAPER-INTERNATIONAL-WAVES.md','research/paper_international_wave1_wave2/README.md'}
assert all(p in exact or any(p.startswith(a) for a in allowed) for p in pending),sorted(pending)
idx=Path(txt('rev-parse','--git-path','index'));idx=idx if idx.is_absolute() else W/idx
backup=D/'before-bb3b-integration.index';assert not backup.exists();shutil.copy2(idx,backup)
g('add','-A','--',*sorted(exact),*allowed)
assert not txt('diff','--name-only') and not txt('ls-files','--others','--exclude-standard')
ours=txt('write-tree')
rec={'state':'PREPARED','time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'original_merge_head':merge,'old_base':old,'target_base':target,'prepared_ours_tree':ours,'protected_delta_paths':changed,'protected_delta_count':len(changed),'runtime_delta':[],'overlap':[],'prior_index_sha256':hashlib.sha256(backup.read_bytes()).hexdigest(),'method':'Original-worktree three-tree integration; sparse excluded data remain in the index, no alternate carrier or synthetic commit.'}
dest=P/'main_data_integration_bb3b.json';assert not dest.exists();dest.write_text(json.dumps(rec,indent=2)+'\n')
r=g('read-tree','-m','-u','--aggressive',old,ours,target,check=False)
rec.update(read_tree_exit=r.returncode,stderr=r.stderr.decode(),unmerged=txt('ls-files','-u'))
dest.write_text(json.dumps(rec,indent=2)+'\n')
assert r.returncode==0 and not rec['unmerged'],rec
newtree=txt('write-tree')
expected=g('diff','--no-renames','--raw',old,target).stdout;actual=g('diff','--no-renames','--raw',ours,newtree).stdout
assert expected==actual,'Integrated tree differs from the exact protected data-only delta'
assert txt('rev-parse','HEAD')==head and txt('rev-parse','MERGE_HEAD')==merge
assert not txt('diff','--name-only')
assert not txt('diff',old,target,'--','templates','site','scripts','lib','engine','config','app','.github')
rec.update(state='INTEGRATED_LOCALLY_NOT_COMMITTED',integrated_tree=newtree,raw_delta_sha256=hashlib.sha256(actual).hexdigest(),candidate_path_count=len(txt('diff','--cached','--name-only',target).splitlines()),proof_reuse='Runtime/source/access/UI paths are identical between005232 andbb3b. Existing exact-source proofs remain valid. Build receipts retain their511-input snapshot; no claim of fresh production data. The release visual guard used symbolic origin/main; both protected bases have identical templates/site content.')
dest.write_text(json.dumps(rec,indent=2)+'\n')
E=W/'research/reference_integrity/intl-country-intelligence-20261020/production_completion_20261103'
(E/'integration_20261104_bb3b.json').write_text(json.dumps({k:v for k,v in rec.items() if k!='protected_delta_paths'},indent=2)+'\n')
for rel in ['agentos/handoffs/PAPER-INTERNATIONAL-WAVES-2026-11-03.md','research/paper_international_wave1_wave2/README.md','research/reference_integrity/intl-country-intelligence-20261020/production_completion_20261103/IMPLEMENTATION.md']:
 p=W/rel;s=p.read_text();s=s.replace('005232fa54edbc6d271a796db6b15d5cd7443641','bb3b7273f1e9ccb869b6500c97871093eb22005a').replace('main005232 integrated','main bb3b727 integrated');p.write_text(s)
p=W/'agentos/workstreams/WS-PAPER-INTERNATIONAL-WAVES.md';s=p.read_text();mark='## 4 November 2026 — production candidate qualified;';i=s.index(mark);s=s[:i]+s[i:].replace('main005232fa54edbc6d271a796db6b15d5cd7443641','main bb3b7273f1e9ccb869b6500c97871093eb22005a');p.write_text(s)
for rel in ['agentos/handoffs/PAPER-INTERNATIONAL-WAVES-2026-11-03.md','agentos/workstreams/WS-PAPER-INTERNATIONAL-WAVES.md','research/paper_international_wave1_wave2/README.md','research/reference_integrity/intl-country-intelligence-20261020/production_completion_20261103/IMPLEMENTATION.md']:
 g('add','--',rel)
g('add','--',str((E/'integration_20261104_bb3b.json').relative_to(W)))
print(json.dumps({k:v for k,v in rec.items() if k!='protected_delta_paths'},indent=2),flush=True)
