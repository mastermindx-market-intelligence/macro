from pathlib import Path
import datetime,hashlib,json,tarfile
R=Path('/tmp/intl-production-r4-20261104');P=R/'proof';W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018')
source=P/'p0b_pre_refresh.tar.gz';out=P/'p0b_changed_preimages';assert not out.exists();out.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
with tarfile.open(source) as t:
 for m in t.getmembers():
  if not m.isfile():continue
  assert Path(m.name).name==m.name and not m.name.startswith('.')
  raw=t.extractfile(m).read();h=hashlib.sha256(raw).hexdigest();current=W/'mockups/evidence/prophet-p0b-zero-fouc'/m.name
  if current.is_file() and sha(current)==h:
   loc={'kind':'unchanged_repo_file','path':str(current.relative_to(W))}
  else:
   dest=out/m.name;dest.write_bytes(raw);assert sha(dest)==h
   loc={'kind':'archived_preimage','path':str(dest.relative_to(P))}
  rows.append({'name':m.name,'bytes':len(raw),'sha256':h,'retained_at':loc})
rec={'state':'PASS','time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_archive':source.name,'source_archive_sha256':sha(source),'restoration':'Each original member is byte-identical either at the unchanged committed-repository path or in the current implementation archive under proof/p0b_changed_preimages. This avoids duplicating unchanged historical images; no prior bytes are discarded. Bind repository members to the final publication tree, not a future mutable branch.','members':rows}
(P/'p0b_pre_refresh_retention.json').write_text(json.dumps(rec,indent=2)+'\n')
print(json.dumps({'state':'PASS','members':len(rows),'changed_preimages':sum(r['retained_at']['kind']=='archived_preimage' for r in rows),'changed_bytes':sum(r['bytes'] for r in rows if r['retained_at']['kind']=='archived_preimage'),'original_bytes':source.stat().st_size}),flush=True)
