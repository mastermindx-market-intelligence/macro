from pathlib import Path
import datetime,hashlib,json,re,shutil,subprocess
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018')
R=Path('/tmp/intl-production-r4-20261104');S=R/'source/site';P=R/'proof'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
receipt=P/'release_publication_seed.json';assert not receipt.exists()
build=json.loads((P/'ordinary_build.json').read_text());visual=json.loads((P/'release_research_visual.json').read_text())
assert build['state']=='PASS' and visual['status']=='PASS'
assert build['html_sha256']==visual['html_sha256']==sha(S/'intl.html')
prior=json.loads((P/'publication_asset_seed.json').read_text())
assert sha(W/'site/intl.html')==prior['ordinary_build']['html_sha256']
descriptors=[json.loads(x) for x in re.findall(r'<script[^>]*data-im-deferred-manifest[^>]*>(.*?)</script>',(S/'intl.html').read_text(),re.S)]
refs={}
for d in descriptors:
 for ref in d['variants'].values():
  p=S/ref['url'];assert p.is_file() and p.stat().st_size==ref['bytes'] and sha(p)==ref['sha256']
  assert json.loads(p.read_text())['generation']==d['generation']
  refs[ref['url']]=ref
assert len(descriptors)==30 and len(refs)==84
actual={str(p.relative_to(W/'site')) for p in (W/'site/assets/intl-workspace').rglob('*') if p.is_file()}
assert actual==set(refs),(actual-set(refs),set(refs)-actual)
assert sha(W/'templates/intl_workspace.css')==sha(W/'site/intl_workspace.css')==sha(S/'intl_workspace.css')=='1e7c73d7717d7f31d1037395924f598fa2665505d2cdaf26af205685b34341bd'
assert sha(W/'templates/intl_workspace.js')==sha(W/'site/intl_workspace.js')==sha(S/'intl_workspace.js')=='54fbe37c016257db9e257bb23ac996e8bf02cb98072bb65ad6f8f06853916437'
for rel in sorted(refs):shutil.copyfile(S/rel,W/'site'/rel)
shutil.copyfile(S/'intl.html',W/'site/intl.html')
for rel,ref in refs.items():assert sha(W/'site'/rel)==ref['sha256']
assert sha(W/'site/intl.html')==build['html_sha256']
rec={'state':'PASS','time':now(),'ordinary_build':build,'visual_receipt':'release_research_visual.json','prior_seed_receipt':'publication_asset_seed.json','descriptors':len(descriptors),'asset_count':len(refs),'assets':refs,'source_hashes':{x:sha(W/x) for x in ['site/intl.html','templates/intl_workspace.css','templates/intl_workspace.js','config/site_access.yml','app/deploy/Caddyfile','.github/workflows/render.yml']},'production_effect':'NONE; coherent generated output seeded only in the original source worktree.'}
receipt.write_text(json.dumps(rec,indent=2)+'\n')
print('RELEASE_PUBLICATION_SEED_PASS',json.dumps({'assets':84,'descriptors':30,'html_sha256':build['html_sha256']}),flush=True)
command=['/tmp/intl-country-ci-20261103/bin/python','-m','pytest','-q','tests/test_site_access_boundary.py::test_intl_deferred_presentation_is_published_public_and_never_immutable','--basetemp=/tmp/intl-release-asset-boundary-20261104']
r=subprocess.run(command,cwd=W,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
log=P/'release_generated_asset_boundary.log';log.write_text(r.stdout)
test={'state':'PASS' if r.returncode==0 else 'FAILED','command':command,'completed_at':now(),'exit_code':r.returncode,'log_sha256':sha(log),'source_hashes':rec['source_hashes']}
(P/'release_generated_asset_boundary.json').write_text(json.dumps(test,indent=2)+'\n')
print(r.stdout,flush=True);assert r.returncode==0
