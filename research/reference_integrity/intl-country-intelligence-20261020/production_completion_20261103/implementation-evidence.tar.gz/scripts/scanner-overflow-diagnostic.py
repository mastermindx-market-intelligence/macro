from pathlib import Path
from urllib.parse import urlparse
import datetime,functools,hashlib,http.server,json,threading,traceback
from playwright.sync_api import sync_playwright
R=Path('/tmp/intl-production-r4-20261104');S=R/'source/site';P=R/'proof';shots=P/'screenshots';shots.mkdir(exist_ok=True)
build=json.loads((P/'ordinary_build.json').read_text());assert build['state']=='PASS',build
class Handler(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(S)));threading.Thread(target=server.serve_forever,daemon=True).start()
origin='http://127.0.0.1:'+str(server.server_port)
rec={'schema':'intl.deferred_full_page.v1','source_tree':build['source_tree'],'html_sha256':build['html_sha256'],'input_commit':build['input_commit'],'input_count':511,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'states':[],'journeys':[],'observer_correction':'History tabs are intentionally mobile-only; desktop shows History and Scenario columns together. Interact with the visible desktop assumption fields.','status':'RUNNING'}
def save():(P/'final_research_overflow_diagnostic_setup.json').write_text(json.dumps(rec,indent=2)+'\n')
def init(theme,lang):
 return "localStorage.setItem('theme',"+json.dumps(theme)+");localStorage.setItem('lang',"+json.dumps(lang)+");localStorage.removeItem('themeAuto');window.__shifts=[];new PerformanceObserver(list=>{for(const e of list.getEntries())if(!e.hadRecentInput)__shifts.push({value:e.value,time:e.startTime,sources:(e.sources||[]).map(s=>({tag:s.node?.tagName,id:s.node?.id,class:typeof s.node?.className==='string'?s.node.className:null,previous:s.previousRect.toJSON(),current:s.currentRect.toJSON()}))})}).observe({type:'layout-shift',buffered:true});"
def handle(page):
 page.evaluate("()=>window.__handle=IntlWorkspace.mountIntlWorkspace(document.querySelector('[data-im-workspace]'),JSON.parse(document.querySelector('[data-im-config]').textContent))")
def act(page,action):
 result=page.evaluate('a=>__handle.dispatch(a)',action);assert result['ok'],result
def ready(page,view):
 page.wait_for_function("view=>!!document.querySelector('[data-im-panel][data-view=\"'+view+'\"]:not([hidden])[data-im-deferred-state=\"ready\"]')",arg=view,timeout=15000)
 return page.locator('[data-im-panel][data-view="'+view+'"]:visible')
def shot(page,name):
 target=shots/(name+'.png');page.screenshot(path=str(target));return {'path':'screenshots/'+target.name,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
save()
with sync_playwright() as pw:
 b=pw.chromium.launch(channel='chrome',headless=True);c=b.new_context(viewport={'width':390,'height':844});c.route('**/*',lambda r:r.continue_() if urlparse(r.request.url).hostname=='127.0.0.1' else r.abort());p=c.new_page();p.goto(origin+'/intl.html?view=scanner&market=JP',wait_until='load');handle(p);p.locator('#intl-analysis-tools').evaluate('(x)=>x.open=true');panel=ready(p,'scanner')
 print(json.dumps(p.evaluate("""()=>({width:innerWidth,scrollWidth:document.documentElement.scrollWidth,overflow:[...document.querySelectorAll('[data-im-panel][data-view=scanner]:not([hidden]) *')].filter(n=>n.getBoundingClientRect().width&&n.getBoundingClientRect().right>innerWidth+1&&getComputedStyle(n).visibility!=='hidden').map(n=>({tag:n.tagName,cls:n.className,rect:n.getBoundingClientRect().toJSON(),text:n.innerText?.slice(0,180),display:getComputedStyle(n).display,whiteSpace:getComputedStyle(n).whiteSpace})).slice(0,18)})""")))
 panel.evaluate('(n)=>scrollTo(0,n.getBoundingClientRect().top+scrollY-16)');p.screenshot(path=str(shots/'final-mobile-overflow-diagnostic.png'));b.close();server.shutdown()
