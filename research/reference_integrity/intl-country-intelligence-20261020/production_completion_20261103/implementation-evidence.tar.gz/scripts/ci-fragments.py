from pathlib import Path
import re,json,yaml,hashlib
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018')
p=W/'.github/ci/legacy-jobs.yml';source=p.read_text();jobs=yaml.safe_load(source)['jobs'];changed=[]
spans=list(re.finditer(r'^  ([a-zA-Z0-9_-]+):\s*$',source,re.M))
for i,match in reversed(list(enumerate(spans))):
 name=match.group(1);job=jobs.get(name,{})
 begin=match.start();end=spans[i+1].start() if i+1<len(spans) else len(source);block=source[begin:end]
 if 'scripts/build_intl.py' in job.get('paths',[]) and 'lib/intl_workspace_fragments.py' not in job.get('paths',[]):
  pattern=r'^(      - ["\x27]?scripts/build_intl\.py["\x27]?\s*)$'
  block,count=re.subn(pattern,lambda m:m.group(1)+'\n      - "lib/intl_workspace_fragments.py"',block,count=1,flags=re.M)
  assert count==1,name
 if name=='international-workspace-browser':
  anchor='      - "tests/intl_workspace_controller.test.cjs"'
  assert block.count(anchor)==1
  block=block.replace(anchor,anchor+'\n      - "tests/intl_workspace_deferred.test.cjs"\n      - "tests/test_intl_workspace_fragments.py"')
  # The source import closure is already added through its build_intl entry.
  assert 'lib/intl_workspace_fragments.py' in block
  old='tests/test_intl_gs_foundation.py -q'
  assert block.count(old)==1
  block=block.replace(old,'tests/test_intl_gs_foundation.py tests/test_intl_workspace_fragments.py -q')
  old='tests/intl_gs_foundation_browser.test.cjs\n'
  assert block.count(old)==1
  block=block.replace(old,'tests/intl_gs_foundation_browser.test.cjs tests/intl_workspace_deferred.test.cjs\n')
 if block!=source[begin:end]:
  changed.append(name);source=source[:begin]+block+source[end:]
parsed=yaml.safe_load(source);assert len(parsed['jobs'])==len(jobs)
p.write_text(source)
print(json.dumps({'changed_jobs':changed,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}),flush=True)
