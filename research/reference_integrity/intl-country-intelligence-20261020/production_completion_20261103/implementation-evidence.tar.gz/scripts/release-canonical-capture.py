from pathlib import Path
import datetime,hashlib,json,sys
from playwright.sync_api import sync_playwright
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018');sys.path.insert(0,str(W))
from scripts import capture_page_evidence as capture
R=Path('/tmp/intl-production-r4-20261104');O=R/'release-canonical';assert not O.exists();O.mkdir()
build=json.loads((R/'proof/ordinary_build.json').read_text());assert build['state']=='PASS'
rec={'state':'RUNNING','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_tree':build['source_tree'],'html_sha256':build['html_sha256'],'capture_tool_module_sha256':hashlib.sha256((W/'scripts/capture_page_evidence.py').read_bytes()).hexdigest(),'launch_adapter_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Actual ordinary build from exact retained genuine inputs; unmodified repository capture tool with installed Chrome adapter. Anonymous local browser proof, not deployed or accepted design.','runs':[]}
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save():(O/'capture_execution.json').write_text(json.dumps(rec,indent=2)+'\n')
def driver(**kwargs):
 m=sync_playwright().start()
 try:b=m.chromium.launch(channel='chrome',headless=kwargs['headless'])
 except Exception:m.stop();raise
 rec['browser_version']=b.version
 return capture._PlaywrightDriver(m,b,kwargs['user_agent'],dict(kwargs['observer_config']),kwargs['settle_ms'])
save()
try:
 for name,route,viewports,locales,extras in [
  ('country-rest','/intl.html','desktop,mobile','en,zh',[]),
  ('country-interaction','/intl.html','desktop','en',[
   '--force-state','country_hover:hover(.imc-country-rail [data-imc-country="JP"])',
   '--force-state','tools_focus:focus(.imc-nav [data-imc-section="intl-analysis-tools"])',
   '--force-state','workbench_hover:hover(#intl-analysis-tools>summary)'
  ]),
  ('tools-rest','/intl.html?view=scanner&market=JP#im-gs-scanner-1m-usd_unhedged-scanner','desktop,mobile','en,zh',[]),
  ('tools-interaction','/intl.html?view=scanner&market=JP#im-gs-scanner-1m-usd_unhedged-scanner','desktop','en',[
   '--force-state','workspace_hover:hover(.intl-workspace__view-nav [data-im-view="compare"])',
   '--force-state','workspace_focus:focus(.intl-workspace__view-nav [data-im-view="compare"])'
  ])
 ]:
  folder=O/name;folder.mkdir()
  args=['--registry',str(W/'data/product_experience/page_registry.json'),'--site-dir',str(R/'source/site'),'--routes',route,'--output-dir',str(folder/'images'),'--manifest',str(folder/'manifest.json'),'--smells',str(folder/'smells.json'),'--viewports',viewports,'--locales',locales,'--themes','light,dark','--max-pages','1','--delay-ms','0','--settle-ms','1400','--timeout-s','60',*extras]
  row={'name':name,'arguments':args,'started_at':now()};rec['runs'].append(row);save()
  code=capture.main(args,driver_factory=driver)
  row.update(exit_code=code,completed_at=now())
  if (folder/'manifest.json').exists():row['manifest_sha256']=hashlib.sha256((folder/'manifest.json').read_bytes()).hexdigest()
  save();print(name,'PASS' if code==0 else 'FAILED',flush=True)
  if code:raise RuntimeError(name+' returned '+str(code))
 rec['state']='PASS'
except Exception as e:rec.update(state='FAILED',error=str(e));raise
finally:rec['completed_at']=now();save()
print('Canonical complete',rec['state'],flush=True)
