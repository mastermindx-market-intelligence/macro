from pathlib import Path
import subprocess,json,hashlib,datetime,concurrent.futures
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018');P=Path('/tmp/intl-production-r4-20261104/proof')
def adapt(p):
 r=subprocess.run(['/opt/homebrew/bin/caddy','adapt','--config',str(p),'--adapter','caddyfile'],cwd=W,capture_output=True,text=True,timeout=60)
 assert r.returncode==0,r.stderr[:2000]
 return json.loads(r.stdout)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 a=pool.submit(adapt,P/'Caddyfile_before_fragments');b=pool.submit(adapt,W/'app/deploy/Caddyfile')
 before=a.result();after=b.result()
pattern='/assets/intl-workspace/*';removed_headers=[];removed_exclusions=[]
def prune(x,path=''):
 if isinstance(x,list):
  result=[]
  for i,v in enumerate(x):
   if isinstance(v,dict) and v.get('match')==[{'path':[pattern]}]:
    hs=v.get('handle',[])
    if hs and all(h.get('handler')=='headers' and h.get('response',{}).get('set',{}).get('Cache-Control')==['no-store'] for h in hs):
     removed_headers.append({'path':path+'/'+str(i),'route':v});continue
   result.append(prune(v,path+'/'+str(i)))
  return result
 if isinstance(x,dict):
  result={}
  for k,v in x.items():
   if k=='path' and isinstance(v,list) and pattern in v:
    removed_exclusions.append(path+'/path');result[k]=[p for p in v if p!=pattern]
   else:result[k]=prune(v,path+'/'+k)
  return result
 return x
normalized=prune(after)
diffs=[]
def compare(a,b,path=''):
 if type(a)!=type(b):diffs.append({'path':path,'type_change':True});return
 if isinstance(a,dict):
  for k in a.keys()|b.keys():
   if k not in a or k not in b:diffs.append({'path':path+'/'+k,'missing_side':True})
   else:compare(a[k],b[k],path+'/'+k)
 elif isinstance(a,list):
  if len(a)!=len(b):diffs.append({'path':path,'lengths':[len(a),len(b)]})
  for i,(x,y) in enumerate(zip(a,b)):compare(x,y,path+'/'+str(i))
 elif a!=b:
  row={'path':path,'types':type(a).__name__}
  if isinstance(a,str) and a.startswith('group') and b.startswith('group'):row.update(before=a,after=b)
  diffs.append(row)
compare(before,normalized)
print(json.dumps({'header_routes':len(removed_headers),'exclusions':len(removed_exclusions),'diff_count':len(diffs),'diffs':diffs[:35]}),flush=True)
