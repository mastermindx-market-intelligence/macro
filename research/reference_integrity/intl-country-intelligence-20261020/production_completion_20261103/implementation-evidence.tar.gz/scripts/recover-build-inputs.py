from pathlib import Path
import tarfile,hashlib,json,datetime
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018');R=Path('/tmp/intl-production-r4-20261104')
archive=W/'research/reference_integrity/intl-country-intelligence-20261020/design_reset_20261103/reproduction-inputs.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='a1ce35bc320b7ed0ab8cad673f446bae79669540acd06ca44fef55acf85a2da9'
dest=R/'recovered-inputs';dest.mkdir(exist_ok=True)
expected={'source-base-098acfb.tar':'54ac0178e91f6ae634b88c66b0f8523c8418ea1465f689dbfbad71924dd3e89e','committed-inputs-19a896b.tar':'e0ab64bc8e180d781e6d0a3705c3d93a0568df1acf8213f5abde96dbc577676a'}
with tarfile.open(archive) as bundle:
 for name,digest in expected.items():
  raw=bundle.extractfile(name).read();assert hashlib.sha256(raw).hexdigest()==digest
  p=dest/name;assert not p.exists();p.write_bytes(raw);assert hashlib.sha256(p.read_bytes()).hexdigest()==digest
rec={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reason':'Previously used temporary committed-input archive was absent. The actual cause is unproven; no provider data was reacquired.','durable_archive':str(archive.relative_to(W)),'durable_archive_sha256':'a1ce35bc320b7ed0ab8cad673f446bae79669540acd06ca44fef55acf85a2da9','restored':expected}
(R/'proof/input_recovery.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec),flush=True)
