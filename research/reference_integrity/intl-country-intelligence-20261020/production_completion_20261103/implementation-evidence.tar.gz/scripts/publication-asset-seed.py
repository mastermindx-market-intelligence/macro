from pathlib import Path
import hashlib,json,re,shutil,subprocess,datetime
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018');R=Path('/tmp/intl-production-r4-20261104');S=R/'source/site';P=R/'proof'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
build=json.loads((P/'ordinary_build.json').read_text());visual=json.loads((P/'final_research_visual_corrected.json').read_text())
assert build['state']=='PASS' and visual['status']=='PASS'
assert build['html_sha256']==visual['html_sha256']==sha(S/'intl.html')
html=(S/'intl.html').read_text();descriptors=[json.loads(x) for x in re.findall(r'<script[^>]*data-im-deferred-manifest[^>]*>(.*?)</script>',html,re.S)]
refs={}
for d in descriptors:
 for ref in d['variants'].values():
  p=S/ref['url'];assert p.is_file() and len(p.read_bytes())==ref['bytes'] and sha(p)==ref['sha256']
  bundle=json.loads(p.read_text());assert bundle['generation']==d['generation']
  if ref['url'] in refs:assert refs[ref['url']]==ref
  refs[ref['url']]=ref
assert len(refs)==84 and len(descriptors)==30
assert set(refs)=={str(p.relative_to(S)) for p in (S/'assets/intl-workspace').glob('*.json')}
dest=W/'site/assets/intl-workspace';assert not dest.exists();dest.mkdir(parents=True)
for rel in refs:shutil.copyfile(S/rel,W/'site'/rel)
prior={'site/intl.html':sha(W/'site/intl.html'),'config/site_access.yml':sha(W/'config/site_access.yml'),'app/deploy/Caddyfile':sha(W/'app/deploy/Caddyfile'),'.github/workflows/render.yml':sha(W/'.github/workflows/render.yml')}
shutil.copyfile(W/'app/deploy/Caddyfile',P/'Caddyfile_before_fragments')
shutil.copyfile(S/'intl.html',W/'site/intl.html')
p=W/'config/site_access.yml';text=p.read_text();needle='    - /assets/landing/\n';assert text.count(needle)==1
text=text.replace(needle,needle+'    # Only rendered International presentation, partitioned from public intl.html.\n    # No raw source stores, provenance, account data or API responses belong here.\n    - /assets/intl-workspace/\n');p.write_text(text)
p=W/'app/deploy/Caddyfile';text=p.read_text()
for matcher in ['reg_asset','reg_asset_err']:
 pattern=rf'(@{matcher}\\s*\\{{\\s*not path )([^\\n]+)'
 matches=list(re.finditer(pattern,text));assert len(matches)==1,(matcher,len(matches))
 text=re.sub(pattern,lambda m:m.group(1)+m.group(2)+' /assets/intl-workspace/*',text,count=1)
needle='\theader @public_versioned Cache-Control "public, max-age=31536000, immutable"\n';assert text.count(needle)==1
text=text.replace(needle,needle+'\n\t# Mutable, generation-bound fragments of the already public International page.\n\t# This must also cover the loader\'s ?v=sha request; never use immutable caching.\n\t@intl_workspace_fragments path /assets/intl-workspace/*\n\theader @intl_workspace_fragments Cache-Control "no-store"\n')
p.write_text(text)
p=W/'.github/workflows/render.yml';text=p.read_text();needle='      - "lib/shared_shell.py"\n';assert text.count(needle)==1;text=text.replace(needle,needle+'      - "lib/intl_workspace_fragments.py"\n');p.write_text(text)
rec={'state':'SEEDED_AND_ACCESS_SOURCE_UPDATED_NOT_DEPLOYED','time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ordinary_build':build,'descriptors':len(descriptors),'asset_count':len(refs),'assets':refs,'preimages':prior,'source_hashes':{x:sha(W/x) for x in prior},'policy_delta':'Only the exclusive public-presentation namespace is added; raw input/API and adjacent paths retain existing authorization. Dedicated no-store includes ?v=sha; no immutable cache enrollment.','renderer_delta':'Exact helper-only source trigger added. Existing git add site/ and recursive updater carry the files.','production_effect':'NONE'}
(P/'publication_asset_seed.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps({k:rec[k] for k in ['state','asset_count','descriptors','source_hashes','production_effect']}),flush=True)
