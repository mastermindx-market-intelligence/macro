from pathlib import Path
import os,sys,hashlib,json,subprocess
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018');T=Path('/tmp/intl-resume-20261104');S=Path('/tmp/intl-production-r4-20261104/source')
change=json.loads((T/'deferred-coverage.json').read_text())
assert hashlib.sha256((W/'templates/intl_workspace.js').read_bytes()).hexdigest()==change['before']
patch=T/'deferred-coverage.patch';patch.write_text(change['patch'])
subprocess.run(['git','apply','--check',str(patch)],cwd=W,check=True);subprocess.run(['git','apply',str(patch)],cwd=W,check=True)
(W/'tests/intl_workspace_deferred.test.cjs').write_text(change['test'])
css='\n.intl-workspace [data-gs-select-market][aria-disabled="true"]{color:var(--muted);text-decoration:none;cursor:default;opacity:.6}\n'
with (W/'templates/intl_workspace.css').open('a') as out:out.write(css)
for name in ['intl_workspace.js','intl_workspace.css']:(S/'templates'/name).write_bytes((W/'templates'/name).read_bytes())
os.chdir(S);sys.path.insert(0,str(S));from lib import site_assets
for name in ['intl_workspace.js','intl_workspace.css']:site_assets.copy_asset(name,S/'templates'/name,S/'site')
print(json.dumps({'status':'APPLIED','controller_sha256':hashlib.sha256((W/'templates/intl_workspace.js').read_bytes()).hexdigest(),'ordinary_static_asset_owner':'lib.site_assets.copy_asset'}),flush=True)
