from pathlib import Path
import subprocess,hashlib,json
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018')
p=W/'templates/intl_workspace.css';before=hashlib.sha256(p.read_bytes()).hexdigest();assert before=='becd425a8d4f6c4a87cda505ce60adc87174de776eb0eb7a276c0a304cf547ec'
p.write_text(p.read_text()+'\nbody.imc-page .intl-workspace .intl-gs__view--scanner .intl-gs__kpi__tier>.intl-gs__chip{max-inline-size:100%;white-space:normal;height:auto;min-block-size:20px;line-height:1.4;overflow-wrap:anywhere}\n')
subprocess.run(['/tmp/intl-country-ci-20261103/bin/python','-c',"from pathlib import Path; from lib.site_assets import copy_asset; copy_asset('intl_workspace.css',Path('templates/intl_workspace.css'),Path('site'))"],cwd=W,check=True)
assert p.read_bytes()==(W/'site/intl_workspace.css').read_bytes()
subprocess.run(['git','add','--','templates/intl_workspace.css','site/intl_workspace.css'],cwd=W,check=True)
print(json.dumps({'before':before,'after':hashlib.sha256(p.read_bytes()).hexdigest(),'fix':'Long source badge wraps inside narrow Scanner card; observed root overflow399px at390px fixed at its originating element.'}),flush=True)
