from pathlib import Path
from urllib.parse import urlparse
import datetime,functools,hashlib,http.server,json,threading,traceback
from playwright.sync_api import sync_playwright
R=Path('/tmp/intl-production-r4-20261104');S=R/'source/site';P=R/'proof';shots=P/'screenshots';shots.mkdir(exist_ok=True)
build=json.loads((P/'ordinary_build.json').read_text());assert build['state']=='PASS',build
class Handler(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(S)));threading.Thread(target=server.serve_forever,daemon=True).start()
origin='http://127.0.0.1:'+str(server.server_port)
rec={'schema':'intl.deferred_full_page.v1','source_tree':build['source_tree'],'html_sha256':build['html_sha256'],'input_commit':build['input_commit'],'input_count':511,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'states':[],'journeys':[],'observer_correction':'History tabs are intentionally mobile-only; desktop shows History and Scenario columns together. Interact with the visible desktop assumption fields.','status':'RUNNING'}
def save():(P/'final_research_visual_corrected.json').write_text(json.dumps(rec,indent=2)+'\n')
def init(theme,lang):
 return "localStorage.setItem('theme',"+json.dumps(theme)+");localStorage.setItem('lang',"+json.dumps(lang)+");localStorage.removeItem('themeAuto');window.__shifts=[];new PerformanceObserver(list=>{for(const e of list.getEntries())if(!e.hadRecentInput)__shifts.push({value:e.value,time:e.startTime,sources:(e.sources||[]).map(s=>({tag:s.node?.tagName,id:s.node?.id,class:typeof s.node?.className==='string'?s.node.className:null,previous:s.previousRect.toJSON(),current:s.currentRect.toJSON()}))})}).observe({type:'layout-shift',buffered:true});"
def handle(page):
 page.evaluate("()=>window.__handle=IntlWorkspace.mountIntlWorkspace(document.querySelector('[data-im-workspace]'),JSON.parse(document.querySelector('[data-im-config]').textContent))")
def act(page,action):
 result=page.evaluate('a=>__handle.dispatch(a)',action);assert result['ok'],result
def ready(page,view):
 page.wait_for_function("view=>!!document.querySelector('[data-im-panel][data-view=\"'+view+'\"]:not([hidden])[data-im-deferred-state=\"ready\"]')",arg=view,timeout=15000)
 return page.locator('[data-im-panel][data-view="'+view+'"]:visible')
def shot(page,name):
 target=shots/(name+'.png');page.screenshot(path=str(target));return {'path':'screenshots/'+target.name,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
save()
try:
 with sync_playwright() as pw:
  browser=pw.chromium.launch(channel='chrome',headless=True);rec['browser']=browser.version;rec.pop('observer_correction',None);rec['purpose']='Final ordinary-build capture: compact Dossier picker and Scanner label/value/badge flow after narrow badge correction.'
  for width,theme,lang in [(1440,'light','en'),(390,'light','en'),(1440,'dark','zh'),(320,'dark','zh')]:
   context=browser.new_context(viewport={'width':width,'height':1000 if width>700 else 844})
   context.route('**/*',lambda r:r.continue_() if urlparse(r.request.url).hostname=='127.0.0.1' else r.abort());context.add_init_script(init(theme,lang))
   page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
   if theme=='light':
    page.goto(origin+'/intl.html',wait_until='load')
    rec.setdefault('country_previews',[]).append(shot(page,f'final-{width}-{theme}-{lang}-country'))
   page.goto(origin+'/intl.html?view=dossier&market=JP',wait_until='load');handle(page);page.locator('#intl-analysis-tools').evaluate('(x)=>x.open=true')
   dossier=ready(page,'dossier')
   links=dossier.locator('.intl-gs__picklink:visible');ids=links.evaluate_all('(ns)=>ns.map(n=>n.dataset.gsSelectMarket)')
   assert set(ids)=={'JP','KR','TW','IN','AU','GB','EZ'},ids
   picker=dossier.locator('[data-gs-picker]').bounding_box();assert picker['height']<(200 if width>700 else 400),picker
   assert dossier.locator('[data-gs-market]:visible').get_attribute('data-gs-market')=='JP'
   assert page.evaluate('document.documentElement.scrollWidth')<=width+1
   dossier.evaluate('(n)=>scrollTo(0,n.getBoundingClientRect().top+scrollY-16)')
   dossier_shot=shot(page,f'final-{width}-{theme}-{lang}-dossier')
   act(page,{'type':'set_view','view':'scanner'});scanner=ready(page,'scanner')
   cards=scanner.locator('[data-kpi]')
   for card in cards.all():
    label=card.locator('.intl-gs__kpi__label').bounding_box();value=card.locator('.intl-gs__kpi__value').bounding_box();tier=card.locator('.intl-gs__kpi__tier').bounding_box()
    assert value['y']>=label['y']+label['height']-1,(label,value)
    assert tier['y']>=value['y']+value['height']-1,(value,tier)
   assert page.evaluate('document.documentElement.scrollWidth')<=width+1
   scanner.evaluate('(n)=>scrollTo(0,n.getBoundingClientRect().top+scrollY-16)')
   scanner_shot=shot(page,f'final-{width}-{theme}-{lang}-scanner')
   assert not errors,errors
   rec['states'].append({'width':width,'theme':theme,'language':lang,'status':'PASS','picker_height':picker['height'],'selectable_markets':ids,'scanner_cards':cards.count(),'no_overflow':True,'page_errors':errors,'screenshots':[dossier_shot,scanner_shot]});save();context.close()
  browser.close();rec['status']='PASS'
except Exception as exc:
 rec['status']='FAILED';rec['error']=str(exc);rec['traceback']=traceback.format_exc();raise
finally:
 rec['completed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();server.shutdown()
