from pathlib import Path
import datetime,hashlib,json,tarfile,yaml
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018');P=Path('/tmp/intl-production-r4-20261104/proof')
paths=['agentos/handoffs/PAPER-INTERNATIONAL-WAVES-2026-11-03.md','agentos/workstreams/WS-PAPER-INTERNATIONAL-WAVES.md','research/paper_international_wave1_wave2/README.md']
before=P/'agentos_prior_records.tar.gz';assert not before.exists()
hashfile=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pre={p:hashfile(W/p) for p in paths}
with tarfile.open(before,'w:gz') as t:
 for p in paths:t.add(W/p,arcname=p)
with tarfile.open(before) as t:
 for p in paths:assert hashlib.sha256(t.extractfile(p).read()).hexdigest()==pre[p]
base='research/reference_integrity/intl-country-intelligence-20261020/production_completion_20261103'
def read_doc(p):
 text=p.read_text();parts=text.split('---',2);assert len(parts)==3 and not parts[0].strip()
 return yaml.safe_load(parts[1]),parts[2]
def write_doc(p,data,body):p.write_text('---\n'+yaml.safe_dump(data,sort_keys=False,allow_unicode=True,width=108)+'---'+body)
p=W/paths[1];data,body=read_doc(p)
data['next_action']='Read production_completion_20261103/IMPLEMENTATION.md and REPORT.json. Final Paper source, deferred-view performance repair, shared-header adoption, coherent generated seed and narrow public asset policy are locally qualified. Publish through original PR9596 using exact native HEAD/base/tree fences, then exact-head hosted CI and a distinct admitted independent review. Preserve Draft/HOLD, formal blocking-review custody and held R2. Complete actual-parent/F10/W3U and ordinary served/FX/refresh acceptance. No deployment is claimed.'
for v in ['lib/intl_workspace_fragments.py','tests/test_intl_workspace_fragments.py','tests/intl_workspace_deferred.test.cjs','tests/test_intl_gs_dislocations_view.py','tests/test_intl_gs_transmission_view.py','tests/test_site_access_boundary.py','site/assets/intl-workspace/**','site/intl.html','site/intl_workspace.js','templates/_site_nav.html.j2','templates/chat.html','site/chat.html','config/site_access.yml','app/deploy/Caddyfile','.github/workflows/render.yml','.github/ci/legacy-jobs.yml',base+'/**']:
 if v not in data['owns_paths']:data['owns_paths'].append(v)
for v in [base+'/IMPLEMENTATION.md',base+'/REPORT.json',base+'/implementation-evidence.tar.gz']:
 if v not in data['artifacts']:data['artifacts'].insert(0,v)
section='''

## 4 November 2026 — production candidate qualified; original publication continues

This current section supersedes the earlier publisher-unavailable and large-DOM/header frontier. The Chairman continuation retains the original operation, branch and PR9596. Protected procedure remains pinned at Mastermind 2b12028b3910303e85d8e591fd40bb35c779ab78. Macro main005232fa54edbc6d271a796db6b15d5cd7443641 is genuinely integrated; HEAD851c6ab and original MERGE_HEADc6ac417 remain until the exactly fenced native publication. The native Macro status and two-parent capability now work; no raw publication bypass is introduced.

The final candidate keeps the Paper country hierarchy and moves only Dossier, Scanner and Coverage presentation into84 generation/hash-bound assets. Initial HTML falls from23,104,850 to3,844,803 bytes; the country rest requests no fragment. Existing view/state/data owners remain. The compact seven-market picker, readable Scanner cards and mobile two-column question/clock layout remove the recorded density and overflow defects. Bounded shared-header geometry is reused from Macro#9495 and the ordinary Chat nav synchronizer.

Current-source controller proof passes188/188; shared-header/frozen-builder/nav proof122; public serving/access54 plus final regenerated asset closure; P0B128 browser cases/16 screenshots and144 integrity tests. Actual country/deferred/eager/Inspector/Scenario/native journeys and current visual capture receipts preserve their exact scopes and all initial observer or product failures. Final build uses the same511 committed inputs, with no reacquisition. The exact generated HTML and84 assets are seeded coherently only in the source worktree. A narrow public presentation prefix/no-store rule and renderer helper trigger are validated; installed Caddy and production publication remain unproven.

IMPLEMENTATION.md and REPORT.json carry the executable next steps and evidence archive. Superseded static preview files/images were consolidated with exact member readback and no active code consumer; all JSON effect/review receipts and executable verification sources stay at their original paths. The earlier R3 archives remain immutable. Do not replay the held query worker, resurrect a publisher blocker superseded by capability evidence, or claim a local pass as design/production acceptance.

The next action is exact-tree native commit/readback, stale merge-metadata reconciliation, and same-branch typed push, then current-head CI and distinct independent review. Formal CHANGES_REQUESTED disposition, Draft/HOLD, applicable actual-parent findings, F10/W3U, normal renderer/updater/serving policy, full-history FX acceptance and a subsequent refresh remain release obligations. Current mission is incomplete, with useful authorized work continuing.
'''
assert '## 4 November 2026 — production candidate qualified;' not in body
write_doc(p,data,body+section)
p=W/paths[0];data,body=read_doc(p)
data['state_before']='Chairman rejected prior local polish; preserved pending merge and original PR9596. The former publisher refusal is historical.'
for rel,what in [
 ('lib/intl_workspace_fragments.py','Pure presentation partition into84 hash/generation-bound research assets through ordinary builder.'),
 ('templates/intl_workspace.js','Validated on-demand attachment, bounded cache and native disclosure retention, retry/focus and stale-response guards.'),
 ('templates/intl_workspace.css','Compact supported-market picker, Scanner hierarchy and responsive mobile research spacing.'),
 ('site/intl.html','Coherent final ordinary-build seed with all84 presentation bundles; source only, not deployed.'),
 ('config/site_access.yml','Exclusive public rendered-presentation namespace; adjacent raw/API boundaries retained.'),
 ('app/deploy/Caddyfile','Narrow asset exclusions and no-store response rule, including hash-query requests.'),
 ('.github/workflows/render.yml','Exact presentation helper added to existing renderer trigger.'),
 (base,'Current source, build, browser, serving and failure-history evidence plus release frontier.')]:
 existing=next((x for x in data['changed'] if x['path']==rel),None)
 if existing:existing['what']=what
 else:data['changed'].append({'path':rel,'what':what})
data['verified']=[
 {'claim':'Final controller behavior and unchanged incumbent view integration.','command':'Retained final-controller-proof.py on exact controller54fbe37; seven incumbent suites plus deferred suite.','result':'188 passed, zero skipped/cancelled; real focus/late reply/malformed payload/cache/GC/recovery cases retained.'},
 {'claim':'Ordinary build and coherent generated-publication closure.','command':'Retained build-r8-recovered-resume.py and release-publication-seed.py.','result':'511 exact committed inputs; ordinary build PASS; final HTML3,844,803 bytes and84 bundles;30 descriptor byte/hash/generation closure PASS.'},
 {'claim':'Current Paper/source visual and functional journeys.','command':'Retained full-page, corrected eager/Scenario/native and release research scripts; canonical capture tool.','result':'Exact per-receipt scopes retained; final four research visual states PASS; canonical matrix/interaction and integrity results in REPORT.json. Failed observers remain failed.'},
 {'claim':'Shared header, serving boundary and required regression gates.','command':'Retained shared-header/frozen regressions, public-asset boundary, actual Caddy adaptation and P0B proof.','result':'122 regression cases;54 access cases plus final generated closure; Caddy exact semantic delta PASS;128 P0B cases/16 screenshots and144 integrity cases; source/CI/sync guards recorded.'},
 {'claim':'Original source custody and supported publication capability.','command':'Exact HEAD/MERGE_HEAD/main/tree readback and native Macro publication status.','result':'Current main005232 integrated in original carrier; typed two-parent status is supported. Commit/push/deployment remain separate receipts.'}
]
data['unverified']=[
 {'claim':'Formal current-candidate review, hosted CI and release acceptance.','what_would_verify':'Publish exact source; qualify one distinct independent technical reviewer; resolve blocking formal review/HOLD with existing owner; pass exact-head hosted and applicable F10/W3U conditions.'},
 {'claim':'Production adoption and complete user journey.','what_would_verify':'Normal renderer/updater/serving-policy adoption, actual www/beta/app/Terminal parent, existing full-history FX acceptance and a subsequent normal refresh; user design acceptance.'}
]
data['unresolved']=['Exact-tree typed commit/readback and same-branch push','Current-head hosted CI and independent source review','Formal blocking-review disposition and Draft/HOLD release conditions','Applicable actual-parent Saved/focus findings and F10/W3U','Normal serving-policy/renderer/updater adoption and served journeys','Existing full-history FX acceptance and subsequent normal refresh','User design acceptance']
data['next_actions']=['Read '+base+'/IMPLEMENTATION.md and REPORT.json; verify original custody and final tree.','Use supported native Macro publisher with exact HEAD/base/tree fences, then verify parents/tree/index/worktree before ordinary merge --quit and typed push.','Continue current-head review/CI and ordinary release/served acceptance; preserve original held R2 and no duplicate carrier.']
data['danger_areas']=[
 'Unranked returns keep individual windows; Paper specimen values are not live facts.',
 'The public asset exception is only for rendered presentation. Raw data/API/auth boundaries and financial calculations remain unchanged.',
 'Local capture and native publisher capability are not deployment, independent review or user acceptance.',
 'Some failed R6 PNG filenames were reused before packaging; disclose that limitation and preserve failed receipts/logs. R8 release captures have unique names.'
]
body='\n\nMISSION_COMPLETE: false. The source candidate is locally qualified and the supported original publisher is available. Work continues through exact-source publication, independent/formal review, hosted checks and actual production acceptance. This recovery record preserves the same operation and held effects; it is not a new grant or a claim of background execution.\n'
write_doc(p,data,body)
p=W/paths[2];s=p.read_text();start=s.index('## Production completion resumed');end=s.index('## Design reset',start)
replacement='''## Production completion — 4 November 2026

The final Paper implementation and local source qualification are recorded in `research/reference_integrity/intl-country-intelligence-20261020/production_completion_20261103/IMPLEMENTATION.md` and `REPORT.json`. Protected procedure remains Mastermind2b12028b3910303e85d8e591fd40bb35c779ab78. The same original operation, branch and draft PR9596 remain the delivery carrier.

IM-D4 is in progress. Main005232fa54edbc6d271a796db6b15d5cd7443641 is genuinely integrated in the original pending merge. Native Macro publication status and two-parent fences are available; old capability refusals are historical. Final commit/push and actual production adoption still require their own receipts.

The country-centered Paper hierarchy is retained. Dossier, Scanner and Coverage now load as84 exact-hash/generation-bound presentation assets, reducing initial HTML by83.4%. The final research picker, KPI hierarchy, badge wrapping and mobile spacing pass local real-browser checks. Shared-header geometry is reused from its existing bounded owner. The narrow public presentation path and no-store rule are qualified against actual Caddy adaptation and access tests; no installed serving change is claimed.

The final ordinary build uses511 exact committed inputs without reacquisition. Controller188, shared-header/frozen/nav122, access54 plus final generated closure, and P0B128 browser/144 integrity results are retained with their exact source and scope. Full canonical visual captures, corrected actual-page journeys, earlier failures and all raw logs are bound in the report/archive. Test totals overlap and are not additive.

Next: exact-tree native commit/readback, preserve the integrated base and source while clearing only stale merge metadata, same-branch typed push, current-head hosted CI and distinct independent technical review. Draft/HOLD, formal CHANGES_REQUESTED disposition, applicable actual-parent/F10/W3U, normal publication/serving policy, full-history FX acceptance, subsequent refresh and user design acceptance remain open. Held R2 is not retried or replaced. MISSION_COMPLETE remains false.

Historical sections below retain prior-state evidence and are superseded by this current release frontier where explicitly stated.

'''
p.write_text(s[:start]+replacement+s[end:])
rec={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'UPDATED_LOCALLY_NOT_PUBLISHED','prior_archive':before.name,'prior_archive_sha256':hashfile(before),'before':pre,'after':{p:hashfile(W/p) for p in paths}}
(P/'agentos_current_record_update.json').write_text(json.dumps(rec,indent=2)+'\n')
print(json.dumps(rec,indent=2),flush=True)
