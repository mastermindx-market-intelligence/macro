from pathlib import Path
import subprocess, json, hashlib, shutil, datetime
r = Path("/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018")
d = Path("/tmp/intl-resume-20261104")
base = "c6ac417f4a1d561f8c80a0a6b1977d5ffec6d090"
original = "37b1ec6ce8df8e5454713db83166d2022913129a"
target = "460760a9dde15b9e41e1bb02d8ab353e28b1a089"
head = "851c6abebf01c5c8096e7822436455fd1040152a"
out = r/"research/reference_integrity/intl-country-intelligence-20261020/production_completion_20261103"
def g(*args, check=True):
    return subprocess.run(["git",*args],cwd=r,capture_output=True,check=check)
def txt(*args): return g(*args).stdout.decode().strip()
assert txt("rev-parse","HEAD") == head
assert txt("rev-parse","MERGE_HEAD") == base
assert txt("write-tree") == original
assert not txt("ls-files","-u")
assert not txt("diff","--name-only")
assert not txt("ls-files","--others","--exclude-standard")
assert g("merge-base","--is-ancestor",base,target,check=False).returncode == 0
assert g("rev-parse","--verify","MERGE_AUTOSTASH",check=False).returncode != 0
idx = Path(txt("rev-parse","--git-path","index"))
if not idx.is_absolute(): idx=r/idx
shutil.copy2(idx,d/"original-37b1ec-index")
out.mkdir(parents=True,exist_ok=True)
facts = {
 "schema":"intl.production_completion.integration.v1",
 "started_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),
 "procedure_pin":"2b12028b3910303e85d8e591fd40bb35c779ab78",
 "head":head, "original_merge_head":base, "original_tree":original, "target":target,
 "publication":"Native Macro status now works; commit/push have not been attempted.",
 "integration_method":"Three-tree integration in the original worktree: old protected base, saved candidate, newer protected descendant.",
 "direct_work_reason":"PRINCIPAL_JUDGMENT / UNIQUE_APPROVED_ACCESS; source-custody integration stays with the incumbent; prior held Fabric attempt remains held.",
 "performance_findings":{"html_bytes":23104850,"html_elements":422633,"workbench_elements":411445,"dossier_elements":300704},
 "status":"PREPARED"
}
(out/"integration.json").write_text(json.dumps(facts,indent=2)+"\n")
plan = r/"research/paper_international_wave1_wave2/README.md"
s=plan.read_text()
marker="## Production completion resumed — 3 November 2026"
assert marker not in s
section = """## Production completion resumed — 3 November 2026

The native publisher now exposes and successfully reads the original Macro operation. The prior technical refusal is superseded for status only; commit and push remain unproven. Protected procedure is pinned at Mastermind 2b12028b3910303e85d8e591fd40bb35c779ab78.

IM-D4 is in progress. Its concrete substeps are: integrate the preserved candidate with the newer protected main in the same worktree; qualify and publish through the typed two-parent publisher; reduce initial render cost while preserving existing state/data owners; obtain current-source review and hosted proof; then normal render/updater and served verification. No production acceptance is claimed.

The saved merge base c6ac417 is an ancestor of target main460760a. Original tree37b1ec6 is retained. The publisher must never record a newer parent against the old unintegrated tree. Integration uses old-base / saved-ours / exact-new-main, retains original HEAD and merge metadata until an exactly verified native commit, and only then may finish stale merge metadata with ordinary merge --quit.

Actual source diagnosis found422,633 HTML elements,411,445 in the workbench and300,704 in Dossiers. Ten dossier contexts render64 jurisdictions before any selection. The performance repair must preserve all destinations, source/generation binding, missing-data states, URL/history, inspectors, scenario draft state and native country access. Current saved Paper design/source proof is retained; no design census or rewrite is restarted.

Evidence and current integration state: research/reference_integrity/intl-country-intelligence-20261020/production_completion_20261103/integration.json. This is an in-progress save on the original carrier, not yet a GitHub publication.

"""
s=s.replace("# International Markets Paper implementation — Waves 1–3\n\n","# International Markets Paper implementation — Waves 1–3\n\n"+section,1)
plan.write_text(s)
g("add","--",str(plan.relative_to(r)),str(out.relative_to(r)))
ours=txt("write-tree");facts["prepared_ours_tree"]=ours
(out/"integration.json").write_text(json.dumps(facts,indent=2)+"\n")
g("add","--",str(out.relative_to(r)))
ours=txt("write-tree")
print(json.dumps({"phase":"BEFORE_INTEGRATION","ours":ours,"target":target}),flush=True)
result=g("read-tree","-m","-u","--aggressive",base,ours,target,check=False)
facts["read_tree_exit"]=result.returncode
facts["read_tree_stderr"]=result.stderr.decode()[:5000]
facts["integration_ours_tree"]=ours
if result.returncode:
    facts["status"]="READ_TREE_FAILED_RECONCILE"
else:
    conflict_paths=sorted(set(line.split("\t",1)[1] for line in txt("ls-files","-u").splitlines()))
    expected={".github/ci/legacy-jobs.yml","mockups/evidence/prophet-p0b-zero-fouc/manifest.json","mockups/evidence/prophet-p0b-zero-fouc/mobile-layout.json","mockups/evidence/prophet-p0b-zero-fouc/mobile-layout-canada.json","site/canada_stocks.html","site/hk_stocks.html","site/intl.html","site/research_screener.html"}
    facts["conflicts_before_resolution"]=conflict_paths
    assert set(conflict_paths)<=expected, conflict_paths
    resolutions={}
    for p in conflict_paths:
        if p==".github/ci/legacy-jobs.yml":
            paths=[]
            for label,ref in [("ours",ours),("base",base),("main",target)]:
                q=d/("ci-"+label+".yml");q.write_bytes(g("show",ref+":"+p).stdout);paths.append(q)
            merged=subprocess.run(["git","merge-file","-p",str(paths[0]),str(paths[1]),str(paths[2])],capture_output=True)
            assert merged.returncode==0, merged.stderr.decode()
            (r/p).write_bytes(merged.stdout)
            resolutions[p]="Clean three-way textual merge; retains current-main scopes and candidate's measured International import closure."
        elif p.startswith("mockups/evidence/prophet-p0b-zero-fouc/"):
            (r/p).write_bytes(g("show",ours+":"+p).stdout)
            resolutions[p]="Preserved actual candidate-era proof. Current-main stocktable change invalidates asset closure; fresh pinned-browser recapture required before release. No receipt hash is manually forged."
        else:
            (r/p).write_bytes(g("show",target+":"+p).stdout)
            resolutions[p]="Current protected generated output retained; paired HK/Canada/Screener templates have no candidate delta. International will be emitted by its ordinary builder."
        g("add","--",p)
    facts["resolutions"]=resolutions
    facts["unmerged_remaining"]=txt("ls-files","-u")
    assert not facts["unmerged_remaining"]
    assert txt("rev-parse","HEAD")==head
    assert txt("rev-parse","MERGE_HEAD")==base
    facts["status"]="INTEGRATED_LOCALLY_NOT_COMMITTED"
    facts["integrated_tree_before_receipt"]=txt("write-tree")
    facts["candidate_path_count_against_target"]=len(txt("diff","--name-only",target,"--cached").splitlines())
    facts["remaining"]=["Fresh P0B browser closure for current stocktable and page tokens","Affected integrated tests","Performance implementation","Typed fenced commit and push","Hosted CI and current-source independent review","Normal render/updater and served acceptance"]
(out/"integration.json").write_text(json.dumps(facts,indent=2)+"\n")
g("add","--",str(out.relative_to(r)))
print(json.dumps({"status":facts["status"],"conflicts":facts.get("conflicts_before_resolution"),"tree":txt("write-tree") if not txt("ls-files","-u") else None,"remaining_unmerged":facts.get("unmerged_remaining"),"path_count":facts.get("candidate_path_count_against_target"),"receipt":str(out/"integration.json")}),flush=True)
if result.returncode: raise SystemExit(result.returncode)
