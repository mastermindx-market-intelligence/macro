from pathlib import Path
import concurrent.futures,datetime,hashlib,json,os,shutil,subprocess,tarfile
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018')
O=Path('/tmp/intl-production-r4-20261104');assert not O.exists();O.mkdir();P=O/'proof';P.mkdir()
C=Path('/tmp/intl-paper-current-complete-20261103');B=Path('/tmp/intl-paper-polish-final-20261103')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
files=['lib/intl_workspace_fragments.py','tests/test_intl_workspace_fragments.py','templates/intl_workspace.js','scripts/build_intl.py','templates/intl_workspace.css']
subprocess.run(['git','add','--',*files],cwd=W,check=True)
tree=subprocess.check_output(['git','write-tree'],cwd=W,text=True).strip()
(P/'source.json').write_text(json.dumps({'tree':tree,'integrated_main':'460760a9dde15b9e41e1bb02d8ab353e28b1a089','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),'merge_head':subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=W,text=True).strip(),'changed_runtime':{f:sha(W/f) for f in files},'time':now()},indent=2)+'\n')
def run(name,cmd,cwd=W,env=None,timeout=900):
 rec={'state':'RUNNING','command':cmd,'cwd':str(cwd),'started_at':now()}
 dest=P/(name+'.json');dest.write_text(json.dumps(rec,indent=2)+'\n')
 with (P/(name+'.log')).open('w') as stream:
  try:
   result=subprocess.run(cmd,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=timeout)
   rec.update(state='PASS' if result.returncode==0 else 'FAILED',exit_code=result.returncode)
  except subprocess.TimeoutExpired:rec.update(state='TIMED_OUT')
 rec.update(completed_at=now(),log_sha256=sha(P/(name+'.log')))
 dest.write_text(json.dumps(rec,indent=2)+'\n');print(name,rec['state'],flush=True)
 return rec
def extract_current(runtime, names, label):
 archive=O/(label+'.tar')
 with archive.open('wb') as out:subprocess.run(['git','archive','--format=tar',tree,'--',*names],cwd=W,stdout=out,check=True,timeout=600)
 with tarfile.open(archive) as t:t.extractall(runtime,filter='data')
 return {'paths':names,'archive_sha256':sha(archive)}
def build():
 runtime=O/'source';runtime.mkdir()
 archive=Path('/tmp/intl-design-reset-20261103/source.tar')
 assert sha(archive)=='54ac0178e91f6ae634b88c66b0f8523c8418ea1465f689dbfbad71924dd3e89e'
 with tarfile.open(archive) as t:t.extractall(runtime,filter='data')
 # Replace every runtime top-level path with the integrated candidate's exact Git tree.
 excluded={'site','data','research','mockups','agentos'}
 tops=subprocess.check_output(['git','ls-tree','--name-only',tree],cwd=W,text=True).splitlines()
 names=[n for n in tops if n not in excluded]
 for name in names:
  target=runtime/name
  if target.is_dir() and not target.is_symlink():shutil.rmtree(target)
  elif target.exists() or target.is_symlink():target.unlink()
 overlays=[extract_current(runtime,names,'runtime-source')]
 assets=json.loads((B/'proof/shared_static_assets.json').read_text())
 for row in assets['files']:
  raw=(B/'source'/row['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['sha256']
  target=runtime/row['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
 site_paths=subprocess.check_output(['git','ls-tree','-r','--name-only',tree,'--','site'],cwd=W,text=True).splitlines()
 static=[p for p in site_paths if Path(p).suffix.lower() in {'.js','.css','.woff2','.woff','.ttf','.svg','.png','.ico'}]
 for i in range(0,len(static),150):overlays.append(extract_current(runtime,static[i:i+150],'static-'+str(i//150)))
 inputs=C/'committed-inputs.tar';assert sha(inputs)=='e0ab64bc8e180d781e6d0a3705c3d93a0568df1acf8213f5abde96dbc577676a'
 with tarfile.open(inputs) as t:t.extractall(runtime,filter='data')
 manifest=json.loads((C/'proof/input_manifest.json').read_text())
 for row in manifest['files']:assert sha(runtime/row['path'])==row['sha256'],row['path']
 shutil.copyfile(C/'proof/input_manifest.json',P/'input_manifest.json')
 (P/'source_archives.json').write_text(json.dumps(overlays,indent=2)+'\n')
 env=os.environ.copy()
 for name in ['PYTHONPATH','COLLECT_LANE','US_LANE']:env.pop(name,None)
 rec=run('ordinary_build',['/tmp/intl-country-ci-20261103/bin/python','-m','scripts.build_intl'],cwd=runtime,env=env,timeout=900)
 rec.update(source_tree=tree,input_commit=manifest['commit'],committed_inputs=511,input_archive_sha256=sha(inputs),no_reacquisition=True,no_production_mutation=True)
 if (runtime/'site/intl.html').exists():rec.update(html_sha256=sha(runtime/'site/intl.html'),html_bytes=(runtime/'site/intl.html').stat().st_size)
 (P/'ordinary_build.json').write_text(json.dumps(rec,indent=2)+'\n')
env=os.environ.copy();env['NODE_PATH']='/tmp/intl-p0b-node-20261103/node_modules'
node_files=['tests/intl_workspace_controller.test.cjs','tests/intl_workspace_generation_controller.test.cjs','tests/intl_workspace_history_controller.test.cjs','tests/intl_workspace_library_controller.test.cjs','tests/intl_workspace_compare_controller.test.cjs','tests/intl_gs_dossier_browser.test.cjs','tests/intl_gs_scanner_browser.test.cjs']
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 jobs=[pool.submit(build),
       pool.submit(run,'focused_python',['/tmp/intl-country-ci-20261103/bin/python','-m','pytest','-q','tests/test_intl_workspace_fragments.py','tests/test_intl_country_cockpit.py','tests/test_intl_workspace_overview_render.py','tests/test_intl_workspace_integration.py','tests/test_product_chrome.py','--basetemp=/tmp/intl-production-r4-pytest-20261104']),
       pool.submit(run,'controller_regressions',['/opt/homebrew/bin/node','--test','--test-concurrency=2',*node_files],env=env)]
 for job in jobs:job.result()
print('R4_BUILD_PHASE_COMPLETE',flush=True)
