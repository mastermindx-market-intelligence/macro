from pathlib import Path
import hashlib,json,subprocess
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018')
T=Path('/tmp/intl-resume-20261104')
payload=json.loads((T/'performance-payload.json').read_text())
expected={'templates/intl_workspace.js':'bf3b3d81c4a51d1771400d801450620e1e5b538333c5604bcac486080d5bd5ae','scripts/build_intl.py':'edf479bc1d6630d2eaff2a35df15c4a1e3830a0d303757a17d50670a10983b6f','templates/intl_workspace.css':'d2a73cb4d678333e15302d879ec4ab39431a59e8e10df4cf5079db92fab7759e'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()=='851c6abebf01c5c8096e7822436455fd1040152a'
for name,digest in expected.items():assert sha(W/name)==digest,name
assert not (W/'lib/intl_workspace_fragments.py').exists()
assert not (W/'tests/test_intl_workspace_fragments.py').exists()
patch=T/'performance.patch';patch.write_text(payload['patch'])
subprocess.run(['git','apply','--check',str(patch)],cwd=W,check=True)
builder=(W/'scripts/build_intl.py').read_text()
old='from lib.intl_library_mount import render_international_pages  # noqa: E402'
assert builder.count(old)==1
builder=builder.replace(old,old+'\nfrom lib.intl_workspace_fragments import publish_workspace_fragments  # noqa: E402')
old='        write_page(site / "intl.html", macro_html)'
assert builder.count(old)==1
builder=builder.replace(old,'        # All render/binding passes complete before the normal owner partitions presentation.\n        macro_html = publish_workspace_fragments(macro_html, site)\n'+old)
css='''

/* A deferred research view keeps context and a useful, accessible loading state. */
.intl-workspace__deferred{padding:calc(var(--fs-body) * 2);min-block-size:200px;background:var(--panel);border:1px solid var(--line);border-radius:var(--r-panel,14px)}
.intl-workspace__deferred-kicker{font-size:var(--fs-micro);font-weight:600;letter-spacing:.08em;color:var(--muted)}
.intl-workspace__deferred h2{font-size:var(--fs-num-lg);line-height:1.3;margin-block:var(--fs-sm)}
.intl-workspace__deferred p{font-size:var(--fs-sm);color:var(--muted);max-inline-size:60ch}
.intl-workspace__deferred a{display:inline-flex;align-items:center;min-block-size:44px;color:var(--link);font-size:var(--fs-sm)}
@media(max-width:768px){.intl-workspace__deferred{padding:calc(var(--fs-body) * 1.5)}}
'''
subprocess.run(['git','apply',str(patch)],cwd=W,check=True)
(W/'lib/intl_workspace_fragments.py').write_text(payload['helper'])
(W/'tests/test_intl_workspace_fragments.py').write_text(payload['test'])
(W/'scripts/build_intl.py').write_text(builder)
with (W/'templates/intl_workspace.css').open('a') as stream:stream.write(css)
files=[*expected,'lib/intl_workspace_fragments.py','tests/test_intl_workspace_fragments.py']
rec={'status':'SOURCE_APPLIED_NOT_PUBLISHED','files':{f:sha(W/f) for f in files},'source_parent':'a480ff350561e8484ae96a9d830ad431ae07ff37'}
(T/'source-installed.json').write_text(json.dumps(rec,indent=2)+'\n')
print(json.dumps(rec),flush=True)
