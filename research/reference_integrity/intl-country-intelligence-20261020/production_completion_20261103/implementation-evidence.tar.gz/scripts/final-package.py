from pathlib import Path
from html.parser import HTMLParser
import datetime,hashlib,io,json,shutil,subprocess,tarfile
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018');R=Path('/tmp/intl-production-r4-20261104');P=R/'proof';S=R/'source'
E=W/'research/reference_integrity/intl-country-intelligence-20261020/production_completion_20261103'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args):return subprocess.check_output(['git',*args],cwd=W,text=True).strip()
assert git('rev-parse','HEAD')=='851c6abebf01c5c8096e7822436455fd1040152a'
assert git('rev-parse','MERGE_HEAD')=='c6ac417f4a1d561f8c80a0a6b1977d5ffec6d090'
assert git('rev-parse','origin/main')=='bb3b7273f1e9ccb869b6500c97871093eb22005a'
assert not git('ls-files','-u')
build=json.loads((P/'ordinary_build.json').read_text());seed=json.loads((P/'release_publication_seed.json').read_text())
required=['ordinary_build','release_research_visual','release_generated_asset_boundary','release_canonical_package','release_visual_evidence_guard','final_controller_regressions','shared_header_and_frozen_regressions','public_asset_boundary','caddy_fragment_semantic_delta_verified','p0b_integrity','p0b_closure_final','mobile_spacing_asset_sync','mobile_spacing_design_system','final_ci_trigger_closure','scenario_native_journeys_corrected','p0b_pre_refresh_retention']
checks={}
for name in required:
 p=P/(name+'.json');j=json.loads(p.read_text());state=j.get('state',j.get('status'));assert state=='PASS',(name,state)
 checks[name]={'state':state,'receipt':'proof/'+p.name,'sha256':sha(p)}
assert sha(W/'site/intl.html')==sha(S/'site/intl.html')==build['html_sha256']==seed['ordinary_build']['html_sha256']
runtime=['scripts/build_intl.py','lib/intl_workspace_fragments.py','lib/pages.py','lib/shared_shell.py','templates/_site_nav.html.j2','templates/chat.html','templates/theme.css','templates/theme.js']
runtime+= [str(p.relative_to(W)) for p in (W/'templates').glob('intl*') if p.is_file()]
runtime+= [str(p.relative_to(W)) for p in (W/'templates/intl_workspace').rglob('*') if p.is_file()]
runtime=sorted(set(runtime))
for rel in runtime:assert (S/rel).is_file() and sha(W/rel)==sha(S/rel),rel
source_paths=runtime+['templates/shared_shell_bridge.js','site/shared_shell_bridge.js','site/intl.html','site/intl_workspace.js','site/intl_workspace.css','site/theme.css','site/chat.html','config/site_access.yml','app/deploy/Caddyfile','.github/workflows/render.yml','.github/ci/legacy-jobs.yml','scripts/sync_chat_nav.py','scripts/capture_page_evidence.py','scripts/check_ui_visual_evidence.py','tests/test_intl_workspace_fragments.py','tests/intl_workspace_deferred.test.cjs','tests/test_intl_gs_dislocations_view.py','tests/test_intl_gs_transmission_view.py','tests/test_site_access_boundary.py']
source_paths+=['tests/'+name for name in ['intl_workspace_controller.test.cjs','intl_workspace_page.test.cjs','intl_workspace_state.test.cjs','intl_workspace_library_controller.test.cjs','intl_workspace_legacy_navigation.test.cjs','intl_country_cockpit_navigation.test.cjs']]
source_paths=sorted(set(x for x in source_paths if (W/x).is_file()))
hashes={rel:sha(W/rel) for rel in source_paths}
assert hashes['templates/intl_workspace.js']=='54fbe37c016257db9e257bb23ac996e8bf02cb98072bb65ad6f8f06853916437'
assert hashes['templates/intl_workspace.css']=='1e7c73d7717d7f31d1037395924f598fa2665505d2cdaf26af205685b34341bd'
class Counter(HTMLParser):
 def __init__(self):super().__init__();self.count=0
 def handle_starttag(self,tag,attrs):self.count+=1
 def handle_startendtag(self,tag,attrs):self.count+=1
counter=Counter();counter.feed((W/'site/intl.html').read_text())
identity={'state':'PASS','time':now(),'head':git('rev-parse','HEAD'),'original_merge_head':git('rev-parse','MERGE_HEAD'),'integrated_protected_base':git('rev-parse','origin/main'),'prepackage_index_tree':git('write-tree'),'ordinary_build':build,'source_paths':hashes,'build_source_match_paths':runtime,'source_match_result':'All named build runtime files byte-identical to the qualified isolated ordinary-build source. Later protected-main delta contains only9123 nonoverlapping data paths.','html_elements':counter.count,'html_bytes':(W/'site/intl.html').stat().st_size,'asset_count':seed['asset_count'],'descriptor_count':seed['descriptors'],'assets':seed['assets'],'proofs':checks,'production_effect':'NONE','held_effect':'intl-20261022-workspace-transport-query-r2 remains terminal, execution not eligible, execution absence unproven, retry false.'}
(P/'release_source_binding.json').write_text(json.dumps(identity,indent=2)+'\n')
canonical=json.loads((P/'release_canonical_package.json').read_text());assert sum(r['state_count'] for r in canonical['records'])==26
impl=E/'IMPLEMENTATION.md';text=impl.read_text();text=text.replace('Full canonical rest/interaction recapture and its integrity guard are recorded separately in the final report; these are mechanical evidence and visual review inputs, not formal design acceptance.','Final canonical recapture:26 unique observations (16 rest cells and10 real hover/focus interactions), with the full templates/site delta integrity guard PASS. These are mechanical evidence and visual review inputs, not formal design acceptance.')
text=text.replace('Protected Macro main `bb3b7273f1e9ccb869b6500c97871093eb22005a` is genuinely integrated in the original worktree.','Protected Macro main `bb3b7273f1e9ccb869b6500c97871093eb22005a` is genuinely integrated in the original worktree. Its final increment from005232 contains9,123 data-only paths with no overlap or runtime changes; the exact raw Git delta was verified after three-tree integration.')
impl.write_text(text)
previews={}
for name,source in [('country-desktop.png','release-1440-light-en-country.png'),('country-mobile.png','release-390-light-en-country.png')]:
 dest=E/name;assert not dest.exists();shutil.copyfile(P/'screenshots'/source,dest);previews[name]=sha(dest)
archive=E/'implementation-evidence.tar.gz';assert not archive.exists()
members={}
def add(path,name):
 assert path.is_file() and not path.is_symlink(),str(path)
 assert name not in members,name
 members[name]=path
for p in P.rglob('*'):
 if p.is_file() and p.name!='p0b_pre_refresh.tar.gz':add(p,'proof/'+str(p.relative_to(P)))
for p in (R/'release-canonical').rglob('*'):
 if p.is_file():add(p,'canonical-raw/'+str(p.relative_to(R/'release-canonical')))
for p in Path('/tmp/intl-resume-20261104').iterdir():
 if p.is_file() and p.suffix in ['.py','.log'] and p.name not in ['final-package.log']:add(p,'scripts/'+p.name)
for rel in source_paths:add(W/rel,'source/'+rel)
for p in (W/'site/assets/intl-workspace').rglob('*'):
 if p.is_file():add(p,'source/'+str(p.relative_to(W)))
for p in (W/'mockups/evidence/intl-design-reset-20261103').rglob('*'):
 if p.is_file() and p.suffix in ['.json','.yml']:add(p,'source/'+str(p.relative_to(W)))
for name in ['manifest.json','mobile-layout.json','mobile-layout-canada.json','rendered-fixture.json','EVIDENCE.yml']:
 p=W/'mockups/evidence/prophet-p0b-zero-fouc'/name
 if p.is_file():add(p,'source/'+str(p.relative_to(W)))
for rel in ['agentos/handoffs/PAPER-INTERNATIONAL-WAVES-2026-11-03.md','agentos/workstreams/WS-PAPER-INTERNATIONAL-WAVES.md','research/paper_international_wave1_wave2/README.md']:
 add(W/rel,'source/'+rel)
add(impl,'IMPLEMENTATION.md')
inventory={name:{'bytes':p.stat().st_size,'sha256':sha(p)} for name,p in sorted(members.items())}
manifest={'schema':'intl.implementation_archive.v1','created_at':now(),'member_count':len(inventory),'members':inventory,'historical_p0b_retention':'Full prior p0b tar is not redundantly copied. proof/p0b_pre_refresh_retention.json verifies all127 members against unchanged repository files or archived changed preimages.','input_archive':'Immutable design_reset_20261103/reproduction-inputs.tar.gz, sha256 a1ce35bc320b7ed0ab8cad673f446bae79669540acd06ca44fef55acf85a2da9; input recovery and511-entry manifest retained.'}
raw=(json.dumps(manifest,indent=2)+'\n').encode()
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 for name,path in sorted(members.items()):t.add(path,arcname=name,recursive=False)
 info=tarfile.TarInfo('MANIFEST.json');info.size=len(raw);info.mtime=0;t.addfile(info,io.BytesIO(raw))
assert archive.stat().st_size<100_000_000,archive.stat().st_size
with tarfile.open(archive) as t:
 assert len([m for m in t.getmembers() if m.isfile()])==len(inventory)+1
 for name,row in inventory.items():
  value=t.extractfile(name).read();assert len(value)==row['bytes'] and hashlib.sha256(value).hexdigest()==row['sha256'],name
 assert t.extractfile('MANIFEST.json').read()==raw
failures={}
for p in P.glob('*.json'):
 try:j=json.loads(p.read_text())
 except Exception:continue
 state=j.get('state',j.get('status'))
 if state in ['FAILED','RUNNING','TIMED_OUT']:failures[p.name]={'state':state,'error':j.get('error'),'note':'Preserved original result; see IMPLEMENTATION.md for correction, proof scope and historical setup-only receipts.'}
report={'schema':'intl.production_implementation.v1','state':'VERIFIED_LOCAL_RELEASE_CANDIDATE','mission_complete':False,'created_at':now(),'procedure_pin':'2b12028b3910303e85d8e591fd40bb35c779ab78','operation_id':'intl-country-cockpit-20261018','repository':'mastermindx-market-intelligence/macro','branch':'sol/web-intl-country-cockpit-20261018','pr':9596,'source_identity':{k:v for k,v in identity.items() if k not in ['assets','proofs']},'verification':checks,'canonical_observations':26,'canonical_rest_cells':16,'canonical_real_interactions':10,'initial_cost':{'before_html_bytes':23104850,'after_html_bytes':identity['html_bytes'],'html_reduction_percent':round((1-identity['html_bytes']/23104850)*100,2),'before_raw_elements':422633,'after_raw_elements':counter.count,'scope':'Exact local build, not production field telemetry.'},'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(inventory)+1,'manifest_sha256':hashlib.sha256(raw).hexdigest(),'readback':'Every member byte length and SHA-256 verified after archive creation.'},'previews':previews,'preserved_failures':failures,'source_access':'Exclusive public rendered presentation prefix with no-store; Caddy source is qualified, installation unproven.','publication':{'state':'NOT_YET_COMMITTED_OR_PUSHED_BY_THIS_SLICE','production_deployed':False,'required_method':'Exact HEAD/base/tree fenced native publisher; original carrier only.'},'formal_review':{'state':'FULL_REREVIEW_REQUIRED_DRAFT_HOLD','blocking_review_id':5723137485,'older_approval_id':5725414473,'technical_verdict_is_formal_review':False},'remaining':['Exact source publication and GitHub readback','Current-head hosted CI and admitted independent technical review','Formal blocking-review disposition and applicable F10/W3U conditions','Applicable actual-parent Saved/focus findings','Normal renderer/updater and installed serving-policy adoption','Actual www/beta/app/Terminal journeys and existing full-history FX acceptance','Subsequent normal refresh and user design acceptance'],'limits':['Current source snapshots use511 committed genuine inputs, with no provider reacquisition.','Earlier R6 failed screenshots may have been overwritten under reused names; failed receipts/logs and all current release captures are retained.','No local pass is a production or formal acceptance receipt.','Historical setup-only RUNNING files do not indicate active background execution.']}
report_path=E/'REPORT.json';assert not report_path.exists();report_path.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'state':report['state'],'archive':report['archive'],'source_files':len(source_paths),'build_source_files_checked':len(runtime),'metrics':report['initial_cost'],'report':str(report_path)},indent=2),flush=True)
