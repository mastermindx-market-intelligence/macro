from pathlib import Path
import subprocess,hashlib,json,datetime,concurrent.futures
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018');P=Path('/tmp/intl-production-r4-20261104/proof')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,cmd,timeout=600):
 rec={'state':'RUNNING','command':cmd,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 rec['source_hashes']={p:sha(W/p) for p in ['app/deploy/Caddyfile','config/site_access.yml','tests/test_site_access_boundary.py','.github/workflows/render.yml','site/intl.html']}
 dest=P/(name+'.json');dest.write_text(json.dumps(rec,indent=2)+'\n')
 with (P/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=W,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
 rec.update(state='PASS' if r.returncode==0 else 'FAILED',exit_code=r.returncode,completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),log_sha256=sha(P/(name+'.log')))
 dest.write_text(json.dumps(rec,indent=2)+'\n');print(name,rec['state'],flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 jobs=[pool.submit(run,'public_asset_boundary',['/tmp/intl-country-ci-20261103/bin/python','-m','pytest','-q','tests/test_site_access_boundary.py','tests/test_regwall_json_gate.py','--basetemp=/tmp/intl-public-fragments-pytest-20261104']),pool.submit(run,'final_ci_trigger_closure',['/tmp/intl-country-ci-20261103/bin/python','scripts/check_ci_trigger_closure.py'])]
 for j in jobs:j.result()
