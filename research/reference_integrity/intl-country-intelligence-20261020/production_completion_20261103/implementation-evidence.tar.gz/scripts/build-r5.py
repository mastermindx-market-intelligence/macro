from pathlib import Path
import concurrent.futures,datetime,hashlib,json,os,shutil,subprocess,tarfile
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018');R=Path('/tmp/intl-production-r4-20261104');S=R/'source';P=R/'proof';E=W/'mockups/evidence/prophet-p0b-zero-fouc'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
tree=subprocess.check_output(['git','write-tree'],cwd=W,text=True).strip();assert tree=='aea936d5198df8bfc4d883c559360758b74a7529'
def run(name,cmd,cwd=W,env=None,timeout=900):
 rec={'state':'RUNNING','command':cmd,'cwd':str(cwd),'started_at':now(),'source_tree':tree};dest=P/(name+'.json');dest.write_text(json.dumps(rec,indent=2)+'\n')
 with (P/(name+'.log')).open('w') as log:
  try:r=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout);rec.update(state='PASS' if r.returncode==0 else 'FAILED',exit_code=r.returncode)
  except subprocess.TimeoutExpired:rec.update(state='TIMED_OUT')
 rec.update(completed_at=now(),log_sha256=sha(P/(name+'.log')));dest.write_text(json.dumps(rec,indent=2)+'\n');print(name,rec['state'],flush=True);return rec
def build():
 delta=subprocess.check_output(['git','diff','--name-only','01283998d309a35f92b0d55f956224f17bdc612a',tree],cwd=W,text=True).splitlines()
 overlay=R/'final-runtime-overlay.tar'
 with overlay.open('wb') as out:subprocess.run(['git','archive','--format=tar',tree,'--',*delta],cwd=W,stdout=out,check=True)
 with tarfile.open(overlay) as archive:archive.extractall(S,filter='data')
 shutil.rmtree(S/'data')
 with tarfile.open('/tmp/intl-design-reset-20261103/source.tar') as archive:archive.extractall(S,members=[m for m in archive.getmembers() if m.name=='data' or m.name.startswith('data/')],filter='data')
 with tarfile.open('/tmp/intl-paper-current-complete-20261103/committed-inputs.tar') as archive:archive.extractall(S,filter='data')
 inputs=json.loads((P/'input_manifest.json').read_text())
 for row in inputs['files']:assert sha(S/row['path'])==row['sha256'],row['path']
 shutil.copyfile(P/'ordinary_build.json',P/'ordinary_build_before_header.json')
 env=os.environ.copy()
 for key in ['PYTHONPATH','COLLECT_LANE','US_LANE']:env.pop(key,None)
 result=run('ordinary_build',['/tmp/intl-country-ci-20261103/bin/python','-m','scripts.build_intl'],cwd=S,env=env)
 result.update(input_commit=inputs['commit'],committed_inputs=511,no_reacquisition=True,no_production_mutation=True,html_sha256=sha(S/'site/intl.html'),html_bytes=(S/'site/intl.html').stat().st_size)
 (P/'ordinary_build.json').write_text(json.dumps(result,indent=2)+'\n')
 (P/'final_source_overlay.json').write_text(json.dumps({'tree':tree,'from_tree':'01283998d309a35f92b0d55f956224f17bdc612a','paths':{p:sha(W/p) for p in delta},'archive_sha256':sha(overlay)},indent=2)+'\n')
def p0b():
 with tarfile.open(P/'p0b_pre_refresh.tar.gz','w:gz') as t:
  for p in sorted(E.iterdir()):
   if p.is_file() and p.suffix in ['.json','.png']:t.add(p,arcname=p.name)
 fixture=R/'p0b_fixtures';fixture.mkdir()
 result=run('p0b_render',['/tmp/intl-country-ci-20261103/bin/python','scripts/render_stock_dashboard_fixture.py','--market','all','--out-dir',str(fixture),'--receipt','mockups/evidence/prophet-p0b-zero-fouc/rendered-fixture.json'])
 assert result['state']=='PASS'
 env=os.environ.copy();env['NODE_PATH']='/tmp/intl-p0b-node-20261103/node_modules'
 def verify(market,name):
  return run('p0b_'+market,['/opt/homebrew/bin/node','scripts/verify_stock_dashboard_mobile_layout.cjs','--html',str(fixture/(market+'_stocks.html')),'--site-dir','site','--fixture-receipt','mockups/evidence/prophet-p0b-zero-fouc/rendered-fixture.json','--fixture-assets-dir','mockups/evidence/prophet-p0b-zero-fouc/inputs/browser-data','--screenshot-dir','mockups/evidence/prophet-p0b-zero-fouc','--historical-head','3fb76ea810a8e9ef6a05fe808bb6eaee87eb1f86','--historical-tree','b4dd8fd9b29b4eb769239d35df2a7911e793c7ec','--out','mockups/evidence/prophet-p0b-zero-fouc/'+name],env=env)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  futures=[pool.submit(verify,'hk','mobile-layout.json'),pool.submit(verify,'canada','mobile-layout-canada.json')]
  for future in futures:assert future.result()['state']=='PASS'
diff=P/'runtime.diff';diff.write_bytes(subprocess.check_output(['git','diff','--unified=0','460760a9dde15b9e41e1bb02d8ab353e28b1a089','--','templates','lib','scripts'],cwd=W))
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 futures=[pool.submit(build),pool.submit(p0b),
  pool.submit(run,'shared_header_and_frozen_regressions',['/tmp/intl-country-ci-20261103/bin/python','-m','pytest','-q','tests/test_intl_workspace_fragments.py','tests/test_intl_gs_dislocations_view.py','tests/test_intl_gs_transmission_view.py','tests/test_navigation_refresh.py','tests/test_chat_nav_sync.py','tests/test_product_chrome.py','tests/test_public_chrome.py','tests/test_subdir_nav_prefix.py','--basetemp=/tmp/intl-production-r5-pytest-20261104']),
  pool.submit(run,'ci_trigger_closure',['/tmp/intl-country-ci-20261103/bin/python','scripts/check_ci_trigger_closure.py'])]
 for future in futures:future.result()
for name,cmd in [
 ('design_system',['/tmp/intl-country-ci-20261103/bin/python','scripts/check_design_system.py','--mode','enforce-added','--diff-file',str(diff)]),
 ('template_site_sync',['/tmp/intl-country-ci-20261103/bin/python','-m','scripts.check_template_site_sync']),
 ('runtime_style',['/tmp/intl-country-ci-20261103/bin/python','scripts/check_runtime_style_injection.py']),
 ('chat_nav_sync',['/tmp/intl-country-ci-20261103/bin/python','scripts/sync_chat_nav.py'])]:run(name,cmd,timeout=300)
print('R5_PHASE_COMPLETE',flush=True)
