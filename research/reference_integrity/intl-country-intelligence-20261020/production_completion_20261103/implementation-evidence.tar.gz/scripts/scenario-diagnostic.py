from pathlib import Path
from urllib.parse import urlparse
import datetime,functools,hashlib,http.server,json,threading,traceback
from playwright.sync_api import sync_playwright
R=Path('/tmp/intl-production-r4-20261104');S=R/'source/site';P=R/'proof';shots=P/'screenshots';shots.mkdir(exist_ok=True)
build=json.loads((P/'ordinary_build.json').read_text());assert build['state']=='PASS',build
class Handler(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(S)));threading.Thread(target=server.serve_forever,daemon=True).start()
origin='http://127.0.0.1:'+str(server.server_port)
rec={'schema':'intl.deferred_full_page.v1','source_tree':build['source_tree'],'html_sha256':build['html_sha256'],'input_commit':build['input_commit'],'input_count':511,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'states':[],'journeys':[],'status':'RUNNING'}
def save():(P/'scenario_diagnostic_setup.json').write_text(json.dumps(rec,indent=2)+'\n')
def init(theme,lang):
 return "localStorage.setItem('theme',"+json.dumps(theme)+");localStorage.setItem('lang',"+json.dumps(lang)+");localStorage.removeItem('themeAuto');window.__shifts=[];new PerformanceObserver(list=>{for(const e of list.getEntries())if(!e.hadRecentInput)__shifts.push({value:e.value,time:e.startTime,sources:(e.sources||[]).map(s=>({tag:s.node?.tagName,id:s.node?.id,class:typeof s.node?.className==='string'?s.node.className:null,previous:s.previousRect.toJSON(),current:s.currentRect.toJSON()}))})}).observe({type:'layout-shift',buffered:true});"
def handle(page):
 page.evaluate("()=>window.__handle=IntlWorkspace.mountIntlWorkspace(document.querySelector('[data-im-workspace]'),JSON.parse(document.querySelector('[data-im-config]').textContent))")
def act(page,action):
 result=page.evaluate('a=>__handle.dispatch(a)',action);assert result['ok'],result
def ready(page,view):
 page.wait_for_function("view=>!!document.querySelector('[data-im-panel][data-view=\"'+view+'\"]:not([hidden])[data-im-deferred-state=\"ready\"]')",arg=view,timeout=15000)
 return page.locator('[data-im-panel][data-view="'+view+'"]:visible')
def shot(page,name):
 target=shots/(name+'.png');page.screenshot(path=str(target));return {'path':'screenshots/'+target.name,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
save()
with sync_playwright() as pw:
 browser=pw.chromium.launch(channel='chrome',headless=True)
 ctx=browser.new_context(viewport={'width':1440,'height':1000});ctx.route('**/*',lambda r:r.continue_() if urlparse(r.request.url).hostname=='127.0.0.1' else r.abort());page=ctx.new_page()
 page.goto(origin+'/intl.html?view=history&market=JP',wait_until='load');handle(page);page.locator('#intl-analysis-tools').evaluate('(x)=>x.open=true')
 print(json.dumps(page.evaluate("""()=>({state:__handle.getState(),tabs:[...document.querySelectorAll('[data-im-scenario-tab]')].map(n=>({html:n.outerHTML,rect:n.getBoundingClientRect().toJSON(),ancestors:[...function*(n){while(n){yield {tag:n.tagName,id:n.id,hidden:n.hidden,open:n.open,display:getComputedStyle(n).display};n=n.parentElement}}(n)]})),panels:[...document.querySelectorAll('[data-im-panel]:not([hidden])')].map(n=>({view:n.dataset.view,horizon:n.dataset.horizon,basis:n.dataset.basis}))})""")))
 browser.close();server.shutdown()
