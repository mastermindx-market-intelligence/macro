from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018')
base=Path('research/reference_integrity/intl-country-intelligence-20261020')
out=W/base/'production_completion_20261103';out.mkdir(exist_ok=True)
groups=['proposed_dock2_repair','proposed_dock3_repair','proposed_dock4_repair','proposed_final_repair']
paths=sorted(p for name in groups for p in (W/base/name).rglob('*') if p.is_file())
assert len(paths)==137
receipt=[]
for p in paths:
 rel=str(p.relative_to(W));raw=p.read_bytes()
 historical=subprocess.check_output(['git','show','851c6abebf01c5c8096e7822436455fd1040152a:'+rel],cwd=W)
 assert raw==historical,rel
 receipt.append({'path':rel,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
archive=out/'superseded_preview_assets.tar.gz';assert not archive.exists()
with archive.open('wb') as rawout:
 with gzip.GzipFile(filename='',mode='wb',fileobj=rawout,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as t:
   for row,p in zip(receipt,paths):
    raw=p.read_bytes();info=tarfile.TarInfo(row['path']);info.size=len(raw);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(raw))
with tarfile.open(archive) as t:
 assert len(t.getmembers())==len(receipt)
 for row in receipt:assert hashlib.sha256(t.extractfile(row['path']).read()).hexdigest()==row['sha256'],row['path']
record={'schema':'intl.superseded_preview_archive.v1','source_commit':'851c6abebf01c5c8096e7822436455fd1040152a','reason':'Keep the existing PR below its 3,000-path review ceiling by consolidating four superseded static preview copies; all 137 original byte images are preserved and independently read back. No source runtime, operation, effect receipt, acceptance record, or original Git history is moved or replaced. No tests/scripts/lib/engine/config/CI references these preview paths.','archive':str(archive.relative_to(W)),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':receipt}
manifest=out/'archived_previews.json';manifest.write_text(json.dumps(record,indent=2)+'\n')
subprocess.run(['git','rm','--',*[row['path'] for row in receipt]],cwd=W,check=True,stdout=subprocess.DEVNULL)
for name in groups:
 folder=W/base/name;folder.mkdir(exist_ok=True)
 (folder/'README.md').write_text('# Superseded static preview\n\nThis historical proposal is preserved byte for byte in ../production_completion_20261103/superseded_preview_assets.tar.gz, with each original path and SHA-256 in ../production_completion_20261103/archived_previews.json. All members were read back before consolidation.\n\nThe original files also remain at commit 851c6abebf01c5c8096e7822436455fd1040152a. Extract the archive at repository root to reconstruct that historical preview. It is superseded by the Paper design reset and production completion; current implementation lives under templates/, lib/, and scripts/. This change does not relocate an operation or modify any source/effect/review receipt.\n')
subprocess.run(['git','add','--',str(archive.relative_to(W)),str(manifest.relative_to(W)),*[str(base/name/'README.md') for name in groups]],cwd=W,check=True)
count=len(subprocess.check_output(['git','diff','--name-only','460760a9dde15b9e41e1bb02d8ab353e28b1a089'],cwd=W,text=True).splitlines())
print(json.dumps({'status':'ARCHIVED_AND_VERIFIED','members':len(receipt),'archive_sha256':record['archive_sha256'],'archive_bytes':archive.stat().st_size,'candidate_paths':count}),flush=True)
