from pathlib import Path
import subprocess,json,hashlib,datetime,concurrent.futures
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018');P=Path('/tmp/intl-production-r4-20261104/proof')
def adapt(p):
 r=subprocess.run(['/opt/homebrew/bin/caddy','adapt','--config',str(p),'--adapter','caddyfile'],cwd=W,capture_output=True,text=True,timeout=60)
 assert r.returncode==0,r.stderr[:2000]
 return json.loads(r.stdout)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 a=pool.submit(adapt,P/'Caddyfile_before_fragments');b=pool.submit(adapt,W/'app/deploy/Caddyfile')
 before=a.result();after=b.result()
pattern='/assets/intl-workspace/*';removed_headers=[];removed_exclusions=[]
def prune(x,path=''):
 if isinstance(x,list):
  result=[]
  for i,v in enumerate(x):
   if isinstance(v,dict) and v.get('match')==[{'path':[pattern]}]:
    hs=v.get('handle',[])
    if hs and all(h.get('handler')=='headers' and h.get('response',{}).get('set',{}).get('Cache-Control')==['no-store'] for h in hs):
     removed_headers.append({'path':path+'/'+str(i),'route':v});continue
   result.append(prune(v,path+'/'+str(i)))
  return result
 if isinstance(x,dict):
  result={}
  for k,v in x.items():
   if k=='path' and isinstance(v,list) and pattern in v:
    removed_exclusions.append(path+'/path');result[k]=[p for p in v if p!=pattern]
   else:result[k]=prune(v,path+'/'+k)
  return result
 return x
normalized=prune(after)
rec={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'caddy_version':subprocess.check_output(['/opt/homebrew/bin/caddy','version'],text=True).strip(),'source_sha256':hashlib.sha256((W/'app/deploy/Caddyfile').read_bytes()).hexdigest(),'parsed_before_sha256':hashlib.sha256(json.dumps(before,sort_keys=True).encode()).hexdigest(),'parsed_after_sha256':hashlib.sha256(json.dumps(after,sort_keys=True).encode()).hexdigest(),'removed_header_routes':removed_headers,'new_exclusion_locations':removed_exclusions,'all_other_semantics_identical':normalized==before,'state':'PASS' if normalized==before and len(removed_headers)==1 and len(removed_exclusions)==2 else 'FAILED','installed_or_reloaded':False}
(P/'caddy_fragment_semantic_delta.json').write_text(json.dumps(rec,indent=2)+'\n')
print(json.dumps(rec),flush=True);assert rec['state']=='PASS'
