from pathlib import Path
import hashlib,json,subprocess,os,sys,re,yaml
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018');T=Path('/tmp/intl-resume-20261104');R=Path('/tmp/intl-production-r4-20261104')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
payload=json.loads((T/'header-adoption.json').read_text())
assert sha(W/'templates/theme.css')=='b580b1ff5ddf74130a76bc4736cc12011e095d9c58a0b161b9ca13de8adc509e'
original=(W/'templates/theme.css').read_bytes();patch=T/'header-partial.patch';patch.write_text(payload['nav_patch'])
subprocess.run(['git','apply','--check',str(patch)],cwd=W,check=True)
subprocess.run(['git','apply',str(patch)],cwd=W,check=True)
with (W/'templates/theme.css').open('a') as stream:stream.write(payload['css'])
assert (W/'templates/theme.css').read_bytes().startswith(original)
subprocess.run(['/tmp/intl-country-ci-20261103/bin/python','scripts/sync_chat_nav.py','--fix'],cwd=W,check=True)
# Complete the new test-helper import closure without reserializing the manifest.
p=W/'.github/ci/legacy-jobs.yml';s=p.read_text();jobs=yaml.safe_load(s)['jobs'];matches=list(re.finditer(r'^  ([a-zA-Z0-9_-]+):\s*$',s,re.M));changed=[]
for i,m in reversed(list(enumerate(matches))):
 paths=jobs[m.group(1)].get('paths',[])
 if not any(x in paths for x in ['tests/test_intl_gs_dislocations_view.py','tests/test_intl_gs_transmission_view.py']) or 'tests/test_intl_workspace_fragments.py' in paths:continue
 end=matches[i+1].start() if i+1<len(matches) else len(s);b=s[m.start():end];anchor='    paths:\n';assert b.count(anchor)==1
 b=b.replace(anchor,anchor+'      - "tests/test_intl_workspace_fragments.py"\n')
 s=s[:m.start()]+b+s[end:];changed.append(m.group(1))
p.write_text(s)
# Same ordinary asset owner as build_intl. This does not publish or deploy.
os.chdir(W);sys.path.insert(0,str(W));from lib import site_assets
for name in ['theme.css','intl_workspace.css','intl_workspace.js']:site_assets.copy_asset(name,W/'templates'/name,W/'site')
names=['templates/theme.css','site/theme.css','templates/_site_nav.html.j2','templates/chat.html','site/chat.html','templates/intl_workspace.js','site/intl_workspace.js','templates/intl_workspace.css','site/intl_workspace.css','.github/ci/legacy-jobs.yml','tests/test_intl_gs_dislocations_view.py','tests/test_intl_gs_transmission_view.py','tests/test_intl_workspace_fragments.py','tests/intl_workspace_deferred.test.cjs']
subprocess.run(['git','add','--',*names],cwd=W,check=True)
tree=subprocess.check_output(['git','write-tree'],cwd=W,text=True).strip()
record={'state':'ADOPTED_LOCALLY_NOT_RELEASED','source_commits':payload['source_commits'],'source_pr':9495,'decision':'Reuse only incumbent shared-header geometry and native no-JS partial. Keep existing JS navigation owner. Theme composition is append-only. No Prophet or F01 feature/release ownership transferred.','tree':tree,'files':{n:sha(W/n) for n in names},'ci_import_closure_jobs':changed}
(R/'proof/header_adoption.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
