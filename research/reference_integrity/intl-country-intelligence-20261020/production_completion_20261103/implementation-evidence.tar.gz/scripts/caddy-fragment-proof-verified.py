from pathlib import Path
import subprocess,json,hashlib,datetime,concurrent.futures
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018');P=Path('/tmp/intl-production-r4-20261104/proof')
def adapt(p):
 r=subprocess.run(['/opt/homebrew/bin/caddy','adapt','--config',str(p),'--adapter','caddyfile'],cwd=W,capture_output=True,text=True,timeout=60)
 assert r.returncode==0,r.stderr[:2000]
 return json.loads(r.stdout)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 a=pool.submit(adapt,P/'Caddyfile_before_fragments');b=pool.submit(adapt,W/'app/deploy/Caddyfile')
 before=a.result();after=b.result()
pattern='/assets/intl-workspace/*';removed_headers=[];removed_exclusions=[]
def prune(x,path=''):
 if isinstance(x,list):
  result=[]
  for i,v in enumerate(x):
   if isinstance(v,dict) and v.get('match')==[{'path':[pattern]}]:
    hs=v.get('handle',[])
    if hs and all(h.get('handler')=='headers' and h.get('response',{}).get('set',{}).get('Cache-Control')==['no-store'] for h in hs):
     removed_headers.append({'path':path+'/'+str(i),'route':v});continue
   result.append(prune(v,path+'/'+str(i)))
  return result
 if isinstance(x,dict):
  result={}
  for k,v in x.items():
   if k=='path' and isinstance(v,list) and pattern in v:
    removed_exclusions.append(path+'/path');result[k]=[p for p in v if p!=pattern]
   else:result[k]=prune(v,path+'/'+k)
  return result
 return x
normalized=prune(after)
hide_counts={'before':0,'after':0}
def normalize_input_hide(x,source,label):
 if isinstance(x,list):return [normalize_input_hide(v,source,label) for v in x]
 if isinstance(x,dict):
  result={}
  for k,v in x.items():
   if k=='hide' and isinstance(v,list):
    result[k]=[]
    for item in v:
     if item==str(source):result[k].append('<adapt-input-config>');hide_counts[label]+=1
     else:result[k].append(item)
   else:result[k]=normalize_input_hide(v,source,label)
  return result
 return x
before_comparable=normalize_input_hide(before,P/'Caddyfile_before_fragments','before')
after_comparable=normalize_input_hide(normalized,W/'app/deploy/Caddyfile','after')

rec={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'caddy_version':subprocess.check_output(['/opt/homebrew/bin/caddy','version'],text=True).strip(),'source_sha256':hashlib.sha256((W/'app/deploy/Caddyfile').read_bytes()).hexdigest(),'parsed_before_sha256':hashlib.sha256(json.dumps(before,sort_keys=True).encode()).hexdigest(),'parsed_after_sha256':hashlib.sha256(json.dumps(after,sort_keys=True).encode()).hexdigest(),'removed_header_routes':removed_headers,'new_exclusion_locations':removed_exclusions,'all_other_semantics_identical':after_comparable==before_comparable,'state':'PASS' if after_comparable==before_comparable and len(removed_headers)==2 and len(removed_exclusions)==4 and hide_counts['before']==hide_counts['after']==32 else 'FAILED','installed_or_reloaded':False,'automatic_input_config_hide_entries_normalized':hide_counts,'comparison_scope':'Only Caddy-generated hide paths for the two actual adapt input filenames are normalized; all route ordering and all other fields compare exactly.'}
(P/'caddy_fragment_semantic_delta_verified.json').write_text(json.dumps(rec,indent=2)+'\n')
print(json.dumps(rec),flush=True);assert rec['state']=='PASS'
