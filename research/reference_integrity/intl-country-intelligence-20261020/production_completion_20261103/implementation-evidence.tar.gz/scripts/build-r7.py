from pathlib import Path
import concurrent.futures,datetime,hashlib,json,os,shutil,subprocess,tarfile
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018');R=Path('/tmp/intl-production-r4-20261104');S=R/'source';P=R/'proof'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
integration=json.loads((P/'final_css_and_main_integration.json').read_text());tree=subprocess.check_output(['git','write-tree'],cwd=W,text=True).strip()
assert subprocess.check_output(['git','write-tree'],cwd=W,text=True).strip()==tree
assert not subprocess.check_output(['git','diff','--name-only'],cwd=W,text=True).strip()
def run(name,cmd,cwd=W,env=None,timeout=600):
 rec={'state':'RUNNING','command':cmd,'cwd':str(cwd),'started_at':now(),'source_tree':tree};dest=P/(name+'.json');dest.write_text(json.dumps(rec,indent=2)+'\n')
 with (P/(name+'.log')).open('w') as log:
  try:r=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout);rec.update(state='PASS' if r.returncode==0 else 'FAILED',exit_code=r.returncode)
  except subprocess.TimeoutExpired:rec.update(state='TIMED_OUT')
 rec.update(completed_at=now(),log_sha256=sha(P/(name+'.log')));dest.write_text(json.dumps(rec,indent=2)+'\n');print(name,rec['state'],flush=True);return rec
def build():
 runtime_delta=['templates/intl_workspace.css','site/intl_workspace.css']
 for path in runtime_delta:shutil.copyfile(W/path,S/path)
 shutil.rmtree(S/'data')
 with tarfile.open('/tmp/intl-design-reset-20261103/source.tar') as archive:archive.extractall(S,members=[m for m in archive.getmembers() if m.name=='data' or m.name.startswith('data/')],filter='data')
 with tarfile.open('/tmp/intl-paper-current-complete-20261103/committed-inputs.tar') as archive:archive.extractall(S,filter='data')
 inputs=json.loads((P/'input_manifest.json').read_text())
 for row in inputs['files']:assert sha(S/row['path'])==row['sha256'],row['path']
 shutil.copyfile(P/'ordinary_build.json',P/'ordinary_build_before_badge_wrap.json')
 env=os.environ.copy()
 for key in ['PYTHONPATH','COLLECT_LANE','US_LANE']:env.pop(key,None)
 result=run('ordinary_build',['/tmp/intl-country-ci-20261103/bin/python','-m','scripts.build_intl'],cwd=S,env=env)
 result.update(input_commit=inputs['commit'],committed_inputs=511,no_reacquisition=True,no_production_mutation=True,html_sha256=sha(S/'site/intl.html'),html_bytes=(S/'site/intl.html').stat().st_size)
 (P/'ordinary_build.json').write_text(json.dumps(result,indent=2)+'\n')
 (P/'badge_wrap_overlay.json').write_text(json.dumps({'tree':tree,'from_tree':'ab9a98f9f741ebaea5b3411253f300bb25e4df3e','runtime_paths':{p:sha(W/p) for p in runtime_delta},'new_main_delta':integration['protected_delta'],'new_main_runtime_delta':[]},indent=2)+'\n')
 assert result['state']=='PASS'
diff=P/'final_css.diff';diff.write_bytes(subprocess.check_output(['git','diff','--unified=0','aea936d5198df8bfc4d883c559360758b74a7529',tree,'--','templates/intl_workspace.css'],cwd=W))
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 futures=[pool.submit(build),pool.submit(run,'badge_wrap_design_system',['/tmp/intl-country-ci-20261103/bin/python','scripts/check_design_system.py','--mode','enforce-added','--diff-file',str(diff)])]
 for f in futures:f.result()
assert run('badge_wrap_asset_sync',['/tmp/intl-country-ci-20261103/bin/python','-m','scripts.check_template_site_sync'])['state']=='PASS'
print('R7_BUILD_COMPLETE',flush=True)
