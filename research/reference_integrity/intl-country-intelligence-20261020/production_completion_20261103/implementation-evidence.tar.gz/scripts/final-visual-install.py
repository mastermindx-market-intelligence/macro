from pathlib import Path
import hashlib,subprocess,json,shutil,datetime
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018');P=Path('/tmp/intl-production-r4-20261104/proof');D=Path('/tmp/intl-resume-20261104')
base='460760a9dde15b9e41e1bb02d8ab353e28b1a089';target='005232fa54edbc6d271a796db6b15d5cd7443641';head='851c6abebf01c5c8096e7822436455fd1040152a';merge='c6ac417f4a1d561f8c80a0a6b1977d5ffec6d090'
def g(*a,check=True):return subprocess.run(['git',*a],cwd=W,capture_output=True,check=check)
def t(*a):return g(*a).stdout.decode().strip()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert t('rev-parse','HEAD')==head and t('rev-parse','MERGE_HEAD')==merge
assert t('rev-parse','refs/remotes/origin/main')==target
assert not t('ls-files','-u')
style=W/'templates/intl_workspace.css';assert sha(style)=='215badbaa2498a55cbfeea0dff6ae7f4aa13645c04e70170c60da22462210bc6'
style.write_text(style.read_text()+(D/'research-visual.css').read_text())
subprocess.run(['/tmp/intl-country-ci-20261103/bin/python','-c',"from lib.site_assets import copy_asset; copy_asset('intl_workspace.css')"],cwd=W,check=True)
assert (W/'site/intl_workspace.css').read_bytes()==style.read_bytes()
owned=['templates/intl_workspace.css','site/intl_workspace.css','mockups/evidence/prophet-p0b-zero-fouc/manifest.json','mockups/evidence/prophet-p0b-zero-fouc/mobile-layout.json','mockups/evidence/prophet-p0b-zero-fouc/mobile-layout-canada.json','mockups/evidence/prophet-p0b-zero-fouc/rendered-fixture.json']
g('add','--',*owned);assert not t('diff','--name-only');assert not t('ls-files','--others','--exclude-standard')
ours=t('write-tree');idx=Path(t('rev-parse','--git-path','index'));idx=idx if idx.is_absolute() else W/idx;shutil.copy2(idx,D/'before-005232-integration-index')
delta=t('diff','--name-only',base,target).splitlines()
assert set(delta)=={'agentos/handoffs/WS-CI-MERGE-CONTROL-PLANE-2026-11-04-ACCELERATION.md','agentos/workstreams/WS-CI-MERGE-CONTROL-PLANE.md','data/marketing/outbox/activity.jsonl','data/marketing/outbox/status_ledger.jsonl'},delta
assert g('merge-base','--is-ancestor',base,target,check=False).returncode==0
g('read-tree','-m','-u','--aggressive',base,ours,target)
assert not t('ls-files','-u')
for p in delta:assert g('show',':'+p).stdout==g('show',target+':'+p).stdout,p
assert t('rev-parse','HEAD')==head and t('rev-parse','MERGE_HEAD')==merge
after=t('write-tree')
rec={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,'target':target,'ours_before':ours,'tree_after':after,'protected_delta':delta,'runtime_dependency_delta':[],'all_four_paths_match_protected_target':True,'original_head_and_merge_head_preserved':True,'workspace_css_sha256':sha(style),'scope':'Compact supported Dossier selection and readable Scanner value/source hierarchy; no data or controller change.'}
(P/'final_css_and_main_integration.json').write_text(json.dumps(rec,indent=2)+'\n')
print(json.dumps(rec))
