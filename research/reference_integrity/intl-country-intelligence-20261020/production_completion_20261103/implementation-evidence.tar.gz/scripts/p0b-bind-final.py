from pathlib import Path
import datetime,hashlib,json,subprocess
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018');P=Path('/tmp/intl-production-r4-20261104/proof');E=W/'mockups/evidence/prophet-p0b-zero-fouc'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
path=E/'manifest.json';m=json.loads(path.read_text());before={k:v for k,v in m.items() if k!='repair_extension'};ext=m['repair_extension'];changes=[]
for market,name in [('hk','mobile-layout.json'),('ca','mobile-layout-canada.json')]:
 p=E/name;j=json.loads(p.read_text());assert j['pass'] and j['owner_projection_matrix']['pass']
 result=json.loads((P/('p0b_'+('canada' if market=='ca' else market)+'.json')).read_text());assert result['state']=='PASS'
 binding=ext['browser_receipts'][market];changes.append({'path':binding['path'],'before':binding['sha256'],'after':sha(p)});binding['sha256']=sha(p)
 if isinstance(j['loaded_assets'].get('site/theme.css'),str):assert j['loaded_assets']['site/theme.css']==sha(W/'site/theme.css')
ext['fixture_receipt']['sha256']=sha(E/'rendered-fixture.json');ext['generated_at']=now()
for row in ext['screenshots']:row['sha256']=sha(W/row['path'])
assert {k:v for k,v in m.items() if k!='repair_extension'}==before
path.write_text(json.dumps(m,indent=2)+'\n')
(P/'p0b_binding_refresh.json').write_text(json.dumps({'time':now(),'changes':changes,'historical_manifest_fields_preserved':True,'actual_browser_receipts_pass':True,'manifest_sha256':sha(path),'scope':'Refresh existing mutable current-proof bindings after actual remint; immutable historical target and baseline untouched.'},indent=2)+'\n')
def run(name,cmd):
 with (P/(name+'.log')).open('w') as out:r=subprocess.run(cmd,cwd=W,stdout=out,stderr=subprocess.STDOUT,timeout=400)
 rec={'state':'PASS' if r.returncode==0 else 'FAILED','exit_code':r.returncode,'command':cmd,'completed_at':now(),'log_sha256':sha(P/(name+'.log'))};(P/(name+'.json')).write_text(json.dumps(rec,indent=2)+'\n');print(name,rec['state'],flush=True)
run('p0b_integrity',['/tmp/intl-country-ci-20261103/bin/python','-m','pytest','-q','tests/test_stock_dashboard_first_frame.py','tests/test_check_p0b_receipt_closure.py','--basetemp=/tmp/intl-production-p0b-final-pytest-20261104'])
changed=P/'closure_changed_paths.txt';changed.write_bytes(subprocess.check_output(['git','diff','--name-only','460760a9dde15b9e41e1bb02d8ab353e28b1a089'],cwd=W))
run('p0b_closure_final',['/tmp/intl-country-ci-20261103/bin/python','scripts/check_p0b_receipt_closure.py','--diff-file',str(changed)])
