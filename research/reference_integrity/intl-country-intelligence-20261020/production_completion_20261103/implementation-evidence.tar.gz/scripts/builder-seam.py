from pathlib import Path
import re,json,yaml
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018')
for name in ['tests/test_intl_gs_dislocations_view.py','tests/test_intl_gs_transmission_view.py']:
 p=W/name;s=p.read_text();anchor='import pytest';assert s.count(anchor)==1
 s=s.replace(anchor,anchor+'\n\nfrom tests.test_intl_workspace_fragments import country_builder_preserves_calculations')
 if name.endswith('dislocations_view.py'):
  old='''    assert builder_diff.returncode == 0 or (
        hashlib.sha256(BUILD_INTL_PATH.read_bytes()).hexdigest()
        == approved_country_builder_sha256
    ), f"{BUILD_INTL_PATH} differs from the immutable accepted builders"'''
  new='''    assert builder_diff.returncode == 0 or (
        hashlib.sha256(BUILD_INTL_PATH.read_bytes()).hexdigest()
        == approved_country_builder_sha256
        or country_builder_preserves_calculations(BUILD_INTL_PATH.read_bytes())
    ), f"{BUILD_INTL_PATH} changes audited calculations or the bounded post-render seam"'''
 else:
  old='''        assert (candidate == base
                or hashlib.sha256(candidate).hexdigest()
                   == ACCEPTED_COUNTRY_BUILDER_SHA256), \\
            "build_intl.py must equal W2F base or exact accepted country builder"'''
  new='''        assert (candidate == base
                or hashlib.sha256(candidate).hexdigest()
                   == ACCEPTED_COUNTRY_BUILDER_SHA256
                or country_builder_preserves_calculations(candidate)), \\
            "build_intl.py changes audited calculations or the bounded post-render seam"'''
 assert s.count(old)==1,name
 p.write_text(s.replace(old,new))
p=W/'.github/ci/legacy-jobs.yml';s=p.read_text();jobs=yaml.safe_load(s)['jobs'];matches=list(re.finditer(r'^  ([a-zA-Z0-9_-]+):\\s*$',s,re.M));changed=[]
for i,m in reversed(list(enumerate(matches))):
 job=jobs[m.group(1)];paths=job.get('paths',[])
 if not any(x in paths for x in ['tests/test_intl_gs_dislocations_view.py','tests/test_intl_gs_transmission_view.py']) or 'tests/test_intl_workspace_fragments.py' in paths:continue
 end=matches[i+1].start() if i+1<len(matches) else len(s);b=s[m.start():end]
 anchor='    paths:\n';assert b.count(anchor)==1
 b=b.replace(anchor,anchor+'      - "tests/test_intl_workspace_fragments.py"\n')
 s=s[:m.start()]+b+s[end:];changed.append(m.group(1))
p.write_text(s)
print(json.dumps({'guard_extension':'Exact reversal of two post-binding presentation additions must recover audited builder bytes. Calculation changes remain refused.','ci_jobs':changed}),flush=True)
