from pathlib import Path
import subprocess,hashlib,json,tarfile,datetime
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018')
stem='research/reference_integrity/intl-country-intelligence-20261020/main_tools_repair_20261022/transport_query_repair_20261022/'
out=W/'research/reference_integrity/intl-country-intelligence-20261020/production_completion_20261103'
archive=out/'superseded_static_and_visual_assets.tar.gz';manifest=out/'archived_static_and_visual_assets.json'
assert not archive.exists() and not manifest.exists()
groups=['proposed_scenariopop20261022_repair','candidate_parent_full_v12','candidate_parent_scenario_v13']
head='851c6abebf01c5c8096e7822436455fd1040152a';files=[]
for group in groups:
 probe=subprocess.run(['rg','-l',group,'tests','scripts','lib','engine','config','.github'],cwd=W,capture_output=True,text=True)
 assert probe.returncode==1 and not probe.stdout
 paths=subprocess.check_output(['git','ls-files',stem+group],cwd=W,text=True).splitlines()
 files.extend(p for p in paths if group.startswith('proposed_') or p.endswith('.png'))
assert len(files)==72
rows=[]
for rel in files:
 raw=(W/rel).read_bytes();original=subprocess.check_output(['git','show',head+':'+rel],cwd=W)
 assert raw==original,rel
 rows.append({'path':rel,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'original_commit':head})
with tarfile.open(archive,'w:gz') as bundle:
 for rel in files:bundle.add(W/rel,arcname=rel,recursive=False)
with tarfile.open(archive) as bundle:
 assert set(bundle.getnames())==set(files)
 for row in rows:assert hashlib.sha256(bundle.extractfile(row['path']).read()).hexdigest()==row['sha256']
record={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':str(archive.relative_to(W)),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'file_count':len(rows),'files':rows,'scope':'Only superseded static preview assets and screenshots. All operation/effect/review receipts, logs and verification scripts stay at their original paths. Every archived member is byte-identical to the original published HEAD.'}
manifest.write_text(json.dumps(record,indent=2)+'\n')
subprocess.run(['git','rm','--',*files],cwd=W,check=True,stdout=subprocess.DEVNULL)
for group in groups:
 folder=W/stem/group;folder.mkdir(exist_ok=True)
 (folder/'ARCHIVED_ASSETS.md').write_text('# Historical preview assets\n\nThe static assets or PNG captures previously at this location are preserved byte for byte in '+str(archive.relative_to(W))+'. The adjacent archived_static_and_visual_assets.json lists each original repository path, SHA-256, byte length, and original commit.\n\nAll original operation receipts, judgments, logs and verifier scripts remain here. This is evidence consolidation for a reviewable International candidate; it does not change any historical verdict or move an active operation.\n\nTo inspect the exact historical files, extract the archive into a separate directory, retaining its repository-relative paths. They also remain addressable at commit '+head+'. Do not restore over a working source checkout.\n')
subprocess.run(['git','add','--',str(archive.relative_to(W)),str(manifest.relative_to(W)),*[stem+g+'/ARCHIVED_ASSETS.md' for g in groups]],cwd=W,check=True)
print(json.dumps({k:record[k] for k in ['archive','archive_sha256','archive_bytes','file_count','scope']}),flush=True)
