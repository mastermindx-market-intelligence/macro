from pathlib import Path
from urllib.parse import urlparse
import datetime,functools,hashlib,http.server,json,threading,traceback
from playwright.sync_api import sync_playwright
R=Path('/tmp/intl-production-r4-20261104');S=R/'source/site';P=R/'proof';shots=P/'screenshots';shots.mkdir(exist_ok=True)
build=json.loads((P/'ordinary_build.json').read_text());assert build['state']=='PASS',build
class Handler(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(S)));threading.Thread(target=server.serve_forever,daemon=True).start()
origin='http://127.0.0.1:'+str(server.server_port)
rec={'schema':'intl.deferred_full_page.v1','source_tree':build['source_tree'],'html_sha256':build['html_sha256'],'input_commit':build['input_commit'],'input_count':511,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'states':[],'journeys':[],'observer_correction':'History tabs are intentionally mobile-only; desktop shows History and Scenario columns together. Interact with the visible desktop assumption fields.','status':'RUNNING'}
def save():(P/'scenario_native_journeys.json').write_text(json.dumps(rec,indent=2)+'\n')
def init(theme,lang):
 return "localStorage.setItem('theme',"+json.dumps(theme)+");localStorage.setItem('lang',"+json.dumps(lang)+");localStorage.removeItem('themeAuto');window.__shifts=[];new PerformanceObserver(list=>{for(const e of list.getEntries())if(!e.hadRecentInput)__shifts.push({value:e.value,time:e.startTime,sources:(e.sources||[]).map(s=>({tag:s.node?.tagName,id:s.node?.id,class:typeof s.node?.className==='string'?s.node.className:null,previous:s.previousRect.toJSON(),current:s.currentRect.toJSON()}))})}).observe({type:'layout-shift',buffered:true});"
def handle(page):
 page.evaluate("()=>window.__handle=IntlWorkspace.mountIntlWorkspace(document.querySelector('[data-im-workspace]'),JSON.parse(document.querySelector('[data-im-config]').textContent))")
def act(page,action):
 result=page.evaluate('a=>__handle.dispatch(a)',action);assert result['ok'],result
def ready(page,view):
 page.wait_for_function("view=>!!document.querySelector('[data-im-panel][data-view=\"'+view+'\"]:not([hidden])[data-im-deferred-state=\"ready\"]')",arg=view,timeout=15000)
 return page.locator('[data-im-panel][data-view="'+view+'"]:visible')
def shot(page,name):
 target=shots/(name+'.png');page.screenshot(path=str(target));return {'path':'screenshots/'+target.name,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
save()
try:
 with sync_playwright() as pw:
  browser=pw.chromium.launch(channel='chrome',headless=True);rec['browser']=browser.version
  context=browser.new_context(viewport={'width':1440,'height':1000});context.route('**/*',lambda r:r.continue_() if urlparse(r.request.url).hostname=='127.0.0.1' else r.abort());context.add_init_script(init('light','en'));page=context.new_page()
  page.goto(origin+'/intl.html?view=history&market=JP',wait_until='load');handle(page);page.locator('#intl-analysis-tools > summary').click()
  assert page.locator('[data-im-history-panel]:visible').count()==1
  page.locator('[data-im-scenario-field="local"]:visible').fill('5')
  page.locator('[data-im-scenario-field="fx"]:visible').fill('-2')
  act(page,{'type':'set_view','view':'dossier'});ready(page,'dossier')
  origin_link=page.locator('[data-im-panel][data-view="dossier"]:visible [data-gs-select-market="KR"]').first
  origin_link.focus();origin_link.click()
  assert page.locator('[data-im-scenario-action="cancel_context"]:visible').count()==1
  page.locator('[data-im-scenario-action="cancel_context"]:visible').click();ready(page,'dossier')
  assert page.evaluate("document.activeElement.getAttribute('data-gs-select-market')")=='KR'
  origin_link=page.locator('[data-im-panel][data-view="dossier"]:visible [data-gs-select-market="KR"]').first;origin_link.click()
  page.locator('[data-im-scenario-action="confirm_context"]:visible').click();panel=ready(page,'dossier')
  assert panel.locator('[data-gs-market]').get_attribute('data-gs-market')=='KR'
  rec['scenario_cancel_confirm']='PASS';save();context.close()
  nojs=browser.new_context(java_script_enabled=False,viewport={'width':390,'height':844});nojs.route('**/*',lambda r:r.continue_() if urlparse(r.request.url).hostname=='127.0.0.1' else r.abort());page=nojs.new_page();page.goto(origin+'/intl.html',wait_until='load')
  assert page.locator('.imc-country').count()==7
  assert page.evaluate('document.documentElement.scrollWidth')<=391
  for i in range(7):
   country=page.locator('.imc-country').nth(i)
   if country.get_attribute('open') is None:country.locator(':scope > summary').click()
   assert country.locator('.imc-outlook-panel').is_visible()
  rec['native_country_without_js']='PASS';nojs.close();browser.close();rec['status']='PASS'
except Exception as exc:
 rec['status']='FAILED';rec['error']=str(exc);rec['traceback']=traceback.format_exc();raise
finally:
 rec['completed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();server.shutdown()
