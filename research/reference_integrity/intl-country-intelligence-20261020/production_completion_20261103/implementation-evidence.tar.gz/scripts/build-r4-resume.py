from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,tarfile
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018');R=Path('/tmp/intl-production-r4-20261104');S=R/'source';P=R/'proof';C=Path('/tmp/intl-paper-current-complete-20261103')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=['templates/intl_workspace.js','tests/intl_workspace_deferred.test.cjs','.github/ci/legacy-jobs.yml']
subprocess.run(['git','add','--',*names],cwd=W,check=True)
tree=subprocess.check_output(['git','write-tree'],cwd=W,text=True).strip()
delta=subprocess.check_output(['git','diff','--name-only','8a4d97eeccc147383b66e1296c307e24be98d881',tree],cwd=W,text=True).splitlines()
assert set(delta)==set(names),delta
for name in names:
 raw=subprocess.check_output(['git','show',tree+':'+name],cwd=W);assert hashlib.sha256(raw).hexdigest()==sha(W/name);(S/name).parent.mkdir(parents=True,exist_ok=True);(S/name).write_bytes(raw)
source=json.loads((P/'source.json').read_text());source.update(final_tree=tree,final_overlay={name:sha(W/name) for name in names},preparation_correction='Unrelated stock social-preview images excluded; original partial read-only export stopped, prepared source retained.')
(P/'source.json').write_text(json.dumps(source,indent=2)+'\n')
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',tree,'--','site'],cwd=W,text=True).splitlines()
static=[p for p in paths if not p.startswith('site/og/') and Path(p).suffix.lower() in {'.js','.css','.woff2','.woff','.ttf','.svg','.png','.ico'}]
print('Required static assets',len(static),flush=True)
for i in range(0,len(static),150):
 archive=R/('required-static-'+str(i//150)+'.tar')
 with archive.open('wb') as out:subprocess.run(['git','archive','--format=tar',tree,'--',*static[i:i+150]],cwd=W,stdout=out,check=True,timeout=300)
 with tarfile.open(archive) as t:t.extractall(S,filter='data')
inputs=C/'committed-inputs.tar';assert sha(inputs)=='e0ab64bc8e180d781e6d0a3705c3d93a0568df1acf8213f5abde96dbc577676a'
with tarfile.open(inputs) as t:t.extractall(S,filter='data')
manifest=json.loads((C/'proof/input_manifest.json').read_text())
for row in manifest['files']:assert sha(S/row['path'])==row['sha256'],row['path']
shutil.copyfile(C/'proof/input_manifest.json',P/'input_manifest.json')
env=os.environ.copy()
for key in ['PYTHONPATH','COLLECT_LANE','US_LANE']:env.pop(key,None)
rec={'state':'RUNNING','source_tree':tree,'input_commit':manifest['commit'],'committed_inputs':511,'input_archive_sha256':sha(inputs),'no_reacquisition':True,'no_production_mutation':True,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(P/'ordinary_build.json').write_text(json.dumps(rec,indent=2)+'\n')
with (P/'ordinary_build.log').open('w') as out:
 result=subprocess.run(['/tmp/intl-country-ci-20261103/bin/python','-m','scripts.build_intl'],cwd=S,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=900)
rec.update(state='PASS' if result.returncode==0 else 'FAILED',exit_code=result.returncode,completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),log_sha256=sha(P/'ordinary_build.log'))
if (S/'site/intl.html').exists():rec.update(html_sha256=sha(S/'site/intl.html'),html_bytes=(S/'site/intl.html').stat().st_size)
(P/'ordinary_build.json').write_text(json.dumps(rec,indent=2)+'\n')
print(json.dumps(rec),flush=True)
