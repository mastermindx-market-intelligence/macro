from pathlib import Path
import subprocess,os,hashlib,json,datetime
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018');P=Path('/tmp/intl-production-r4-20261104/proof')
files=['tests/intl_workspace_controller.test.cjs','tests/intl_workspace_generation_controller.test.cjs','tests/intl_workspace_history_controller.test.cjs','tests/intl_workspace_library_controller.test.cjs','tests/intl_workspace_compare_controller.test.cjs','tests/intl_gs_dossier_browser.test.cjs','tests/intl_gs_scanner_browser.test.cjs','tests/intl_workspace_deferred.test.cjs']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
hashes={f:sha(W/f) for f in files+['templates/intl_workspace.js','site/intl_workspace.js']}
assert hashes['templates/intl_workspace.js']=='54fbe37c016257db9e257bb23ac996e8bf02cb98072bb65ad6f8f06853916437'
cmd=['/opt/homebrew/bin/node','--test','--test-concurrency=2',*files]
rec={'state':'RUNNING','command':cmd,'source_hashes':hashes,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reason':'Bind all controller regressions to the final coverage/exception-safe source, closing the earlier-source receipt gap.'}
dest=P/'final_controller_regressions.json';dest.write_text(json.dumps(rec,indent=2)+'\n')
env=os.environ.copy();env['NODE_PATH']='/tmp/intl-p0b-node-20261103/node_modules'
with (P/'final_controller_regressions.log').open('w') as log:r=subprocess.run(cmd,cwd=W,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
assert hashes=={f:sha(W/f) for f in hashes}
rec.update(state='PASS' if r.returncode==0 else 'FAILED',exit_code=r.returncode,completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),log_sha256=sha(P/'final_controller_regressions.log'))
dest.write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec))
