from pathlib import Path
from urllib.parse import urlparse
import datetime,functools,hashlib,http.server,json,threading
from playwright.sync_api import sync_playwright
R=Path('/tmp/intl-production-r4-20261104');S=R/'source/site';P=R/'proof'
class H(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(H,directory=str(S)));threading.Thread(target=server.serve_forever,daemon=True).start()
rec={'source_tree':json.loads((P/'source.json').read_text())['tree'],'html_sha256':hashlib.sha256((S/'intl.html').read_bytes()).hexdigest(),'scope':'Two local cold-load observations of the complete ordinary page, including shared chrome; no production/network percentile claim','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'states':[]}
init="""localStorage.setItem('theme','light');localStorage.setItem('lang','en');localStorage.removeItem('themeAuto');window.__intlLoadShifts=[];new PerformanceObserver(list=>{for(const e of list.getEntries()){if(!e.hadRecentInput)window.__intlLoadShifts.push({value:e.value,time:e.startTime,sources:(e.sources||[]).map(s=>({tag:s.node?.tagName,class:typeof s.node?.className==='string'?s.node.className:null,id:s.node?.id,previous:s.previousRect.toJSON(),current:s.currentRect.toJSON()}))});}}).observe({type:'layout-shift',buffered:true});"""
try:
 with sync_playwright() as pw:
  b=pw.chromium.launch(channel='chrome',headless=True);rec['browser']=b.version
  for width in [1440,390]:
   c=b.new_context(viewport={'width':width,'height':900 if width==1440 else 844});c.route('**/*',lambda r:r.continue_() if urlparse(r.request.url).hostname=='127.0.0.1' else r.abort());c.add_init_script(init);p=c.new_page()
   p.goto('http://127.0.0.1:'+str(server.server_port)+'/intl.html',wait_until='load',timeout=60000);p.evaluate('document.fonts.ready');p.wait_for_timeout(1400)
   row=p.evaluate("""()=>({shifts:window.__intlLoadShifts,nav:document.querySelector('nav.site-nav')?.getBoundingClientRect().toJSON(),main:document.querySelector('.imc')?.getBoundingClientRect().toJSON(),navigation:performance.getEntriesByType('navigation').map(e=>({domContentLoaded:e.domContentLoadedEventEnd,load:e.loadEventEnd,transferSize:e.transferSize})),nodes:document.querySelectorAll('*').length})""")
   row['width']=width;row['layout_shift_sum']=sum(s['value'] for s in row['shifts']);rec['states'].append(row);(P/'cold_load_before_header.json').write_text(json.dumps(rec,indent=2)+'\n');print(width,row['layout_shift_sum'],flush=True);c.close()
  b.close()
finally:rec['completed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();(P/'cold_load_before_header.json').write_text(json.dumps(rec,indent=2)+'\n');server.shutdown()
