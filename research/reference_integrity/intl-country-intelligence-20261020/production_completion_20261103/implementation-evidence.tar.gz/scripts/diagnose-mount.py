from pathlib import Path
import functools,http.server,threading,json
from playwright.sync_api import sync_playwright
S=Path('/tmp/intl-production-r4-20261104/source/site')
class H(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(H,directory=str(S)));threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 with sync_playwright() as pw:
  b=pw.chromium.launch(channel='chrome',headless=True);p=b.new_page();errors=[];bad=[];p.on('pageerror',lambda e:errors.append(str(e)));p.on('response',lambda r:bad.append({'url':r.url,'status':r.status}) if r.status>=400 else None)
  p.goto('http://127.0.0.1:'+str(server.server_port)+'/intl.html',wait_until='load',timeout=60000)
  result=p.evaluate("""()=>{const root=document.querySelector('[data-im-workspace]'),config=JSON.parse(root.querySelector('[data-im-config]').textContent);try{let h=IntlWorkspace.mountIntlWorkspace(root,config);return {state:h.getState(),config}}catch(e){return {error:e.message,stack:e.stack,config,manifests:Array.from(root.querySelectorAll('[data-im-deferred-manifest]')).map(n=>{const d=JSON.parse(n.textContent);return {view:d.view,markets:d.markets,default:d.default_market,generation:d.generation}})}}}""")
  print(json.dumps({'diagnosis':result,'errors':errors,'bad':bad}),flush=True);b.close()
finally:server.shutdown()
