from pathlib import Path
import hashlib
p=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018/templates/intl_workspace.js')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='84bd520db8b130ef8e922761808d797d22e2ecd522a933c24b18634700384f67'
s=p.read_text()
edits=[
("    var restoreKeyboardFocus = entry.fallback.contains(controller.root.ownerDocument.activeElement);","    var activeElement = controller.root.ownerDocument.activeElement;\n    var restoreKeyboardFocus = entry.fallback.contains(activeElement) ||\n      (entry.focusAfterLoad && activeElement === controller.root.ownerDocument.body);\n    entry.focusAfterLoad = false;"),
("  function releaseDeferred(controller, entry) {\n    if (entry.loadedKey)","  function releaseDeferred(controller, entry) {\n    entry.focusAfterLoad = false;\n    if (entry.loadedKey)"),
("    selection.entry.failedKey = null;\n    scheduleDeferred(controller);","    selection.entry.focusAfterLoad = selection.entry.fallback.contains(controller.root.ownerDocument.activeElement);\n    selection.entry.failedKey = null;\n    scheduleDeferred(controller);")]
for a,b in edits:
 assert s.count(a)==1
 s=s.replace(a,b)
p.write_text(s)
print(hashlib.sha256(p.read_bytes()).hexdigest(),flush=True)
