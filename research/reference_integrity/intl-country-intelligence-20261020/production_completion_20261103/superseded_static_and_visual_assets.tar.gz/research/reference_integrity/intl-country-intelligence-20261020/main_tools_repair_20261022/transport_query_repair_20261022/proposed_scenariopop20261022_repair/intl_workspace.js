(function (root, factory) {
  'use strict';
  if (typeof module === 'object' && module.exports) {
    var search;
    try { search = require('./intl_library_search.js'); } catch (error) { if (error.code !== 'MODULE_NOT_FOUND') throw error; }
    var scenario;
    try { scenario = require('./intl_workspace_scenario.js'); } catch (error) { if (error.code !== 'MODULE_NOT_FOUND') throw error; }
    module.exports = factory(require('./intl_workspace_state.js'), search, scenario);
  } else {
    root.IntlWorkspace = factory(root.IntlWorkspaceState, root.IntlLibrarySearch, root.IntlWorkspaceScenario);
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function (IntlWorkspaceState, IntlLibrarySearch, IntlWorkspaceScenario) {
  'use strict';

  var HANDLES = typeof WeakMap === 'function' ? new WeakMap() : null;
  var STATE_KEYS = ['view', 'selected_market', 'compare_markets', 'horizon', 'currency_basis', 'return_basis', 'source_reference', 'expanded', 'library_group', 'baseline', 'return_stack'];
  var ISSUE_TEXT = {
    AMBIGUOUS_PANEL: { en: 'Data is ambiguous for this selection', zh: '此选择的数据不明确' },
    DESTROYED: { en: 'Workspace is destroyed', zh: '工作区已销毁' },
    INVALID_QUERY: { en: 'Invalid URL state restored', zh: '无效 URL 状态已还原' },
    PIN_LIMIT: { en: 'Pin limit reached', zh: '已达固定上限' },
    QUERY_TOO_LONG: { en: 'URL state is too long', zh: 'URL 状态过长' },
    SCENARIO_CONFIRMATION_REQUIRED: { en: 'Review the pending scenario context first', zh: '请先检查待确认的情景范围' },
    STALE_SOURCE: { en: 'Source changed', zh: '数据源已变化' },
    NO_MATCHING_PANEL: { en: 'Data unavailable for this selection', zh: '无匹配数据' },
    UNSUPPORTED_MODE: { en: 'Unsupported workspace mode', zh: '不支持的工作区模式' },
    UNSUPPORTED_VIEW: { en: 'This view is not available yet', zh: '此视图暂不可用' },
    UNSUPPORTED_VALUE: { en: 'Unsupported value', zh: '不支持的值' }
  };

  function destroyedResult() {
    return { ok: false, state: null, issues: [{ code: 'DESTROYED', field: 'workspace' }], intent: null };
  }

  function textFor(issues, language) {
    var code = issues && issues.length > 0 && issues[0] && issues[0].code ? String(issues[0].code) : 'GENERIC';
    var localized = ISSUE_TEXT[code];
    if (!localized) return language === 'zh' ? '工作区状态不可用' : 'Workspace state unavailable';
    return language === 'zh' ? localized.zh : localized.en;
  }

  function issueCode(issues, fallback) {
    return issues && issues.length > 0 && issues[0] && issues[0].code ? String(issues[0].code) : fallback;
  }

  function normalLanguage(element) {
    var language = element.ownerDocument.documentElement.getAttribute('lang');
    return language && language.toLowerCase().indexOf('zh') === 0 ? 'zh' : 'en';
  }

  function required(root, selector) {
    var element = owned(root, selector)[0];
    if (!element) throw new Error('Missing required International workspace element: ' + selector);
    return element;
  }

  function owned(root, selector) {
    return Array.from(root.querySelectorAll(selector)).filter(function (node) {
      return node.closest('[data-im-workspace]') === root;
    });
  }

  // Library is metadata owned by this workspace. Search state is a local draft;
  // the existing reducer remains the sole owner of shareable research context.
  function prepareLibrary(root, config) {
    var panels = owned(root, '[data-view="library"][data-im-library-static]');
    if (panels.length !== 1) return null;
    var panel = panels[0];
    function all(selector) { return owned(root, selector).filter(function (node) { return panel.contains(node); }); }
    function one(selector) { var nodes = all(selector); return nodes.length === 1 ? nodes[0] : null; }
    var library = {panel:panel, all:all, input:one('[data-im-library-search]'), form:one('[data-im-library-search-form]'),
      clear:one('[data-im-library-clear]'), status:one('[data-im-library-status]'), groupsRoot:one('[data-im-library-groups]'),
      results:one('[data-im-library-results]'), empty:one('[data-im-library-empty]'), back:one('[data-im-library-back]'),
      groups:all('[data-im-library-group]'), rows:all('[data-im-library-tool]'), valid:false, query:'', composing:false};
    library.placements = library.rows.map(function (node) { return {node:node,parent:node.parentNode,next:node.nextSibling}; });
    try {
      if (!['input','form','clear','status','groupsRoot','results','empty','back'].every(function (key) { return !!library[key]; }) ||
          !IntlLibrarySearch || typeof IntlLibrarySearch.searchIntlTools !== 'function') return library;
      var script = one('script[data-im-library-catalogue]');
      if (!script) return library;
      var catalogue = JSON.parse(script.textContent);
      // The accepted helper validates the complete public catalogue schema.
      IntlLibrarySearch.searchIntlTools(catalogue, '', null);
      var groups = new Set(library.groups.map(function (group) { return group.getAttribute('data-im-library-group'); }));
      if (groups.size !== 6 || library.groups.length !== 6 || catalogue.length !== 18 || library.rows.length !== 18 ||
          groups.size !== config.library_group_ids.length || config.library_group_ids.some(function (id) { return !groups.has(id); }) ||
          library.groups.some(function (group) {
            var id=group.getAttribute('data-im-library-group');
            return !library.groupsRoot.contains(group) || catalogue.filter(function (item) { return item.group_id===id; }).length!==3 ||
              all('[data-im-library-tools]').filter(function (list) { return list.closest('[data-im-library-group]')===group; }).length!==1;
          })) return library;
      var byKey = new Map(library.rows.map(function (row) { return [row.getAttribute('data-im-library-tool'),row]; }));
      if (byKey.size !== library.rows.length || catalogue.some(function (item) {
        var row = byKey.get(item.presentation_key);
        return !row || row.getAttribute('data-im-library-order') !== String(item.order) ||
          !row.parentNode.matches('[data-im-library-tools]') || row.parentNode.getAttribute('data-im-library-tools') !== item.group_id ||
          !groups.has(item.group_id) || !row.closest('[data-im-library-group]') ||
          row.closest('[data-im-library-group]').getAttribute('data-im-library-group') !== item.group_id;
      })) return library;
      library.catalogue = catalogue; library.byKey = byKey; library.valid = true;
      library.query = library.input.value;
    } catch (_) { /* The approved static page survives failed enhancement. */ }
    return library;
  }

  function restoreLibraryRows(placements) {
    // Restore right siblings first, including whitespace/text siblings. Moving
    // original nodes preserves third-party handlers and exact pre-mount order.
    placements.slice().reverse().forEach(function (entry) {
      var next = entry.next && entry.next.parentNode === entry.parent ? entry.next : null;
      if (entry.node.parentNode !== entry.parent || entry.node.nextSibling !== next) entry.parent.insertBefore(entry.node,next);
    });
  }

  function paintLibrary(controller, state) {
    var library = controller.library;
    if (!library || library.panel.hidden) return;
    var zh = normalLanguage(controller.root) === 'zh';
    if (!library.valid) {
      library.panel.removeAttribute('data-im-library-enhanced');
      if (library.input) library.input.disabled = true;
      if (library.clear) library.clear.disabled = true;
      library.all('[data-im-library-group-open]').forEach(function (button) { button.hidden = true; });
      if (library.status) library.status.textContent = zh ? '此视图的工具目录暂不可用。' : 'The tool catalogue is unavailable for this view.';
      return;
    }
    library.panel.setAttribute('data-im-library-enhanced','true');
    library.input.disabled = false; library.clear.disabled = false;
    library.input.setAttribute('placeholder',zh ? '工具名称、问题或别名' : 'Tool name, question or alias');
    var matches, invalid = false;
    try { matches = IntlLibrarySearch.searchIntlTools(library.catalogue, library.query, state.library_group); }
    catch (_) { invalid = true; matches = []; }
    var searching = library.query.trim().length > 0;
    var resultRows = !invalid && searching ? matches.map(function (match) { return library.byKey.get(match.presentation_key); }) : [];
    var resultSet = new Set(resultRows);
    restoreLibraryRows(library.placements.filter(function (entry) { return !resultSet.has(entry.node); }));
    library.groupsRoot.hidden = invalid || searching;
    library.groups.forEach(function (group) {
      var id = group.getAttribute('data-im-library-group');
      group.hidden = !!state.library_group && id !== state.library_group;
      if (id === state.library_group) group.setAttribute('data-im-library-active','');
      else group.removeAttribute('data-im-library-active');
    });
    library.all('[data-im-library-group-open]').forEach(function (button) { button.hidden = false; });
    library.results.hidden = invalid || !searching || !matches.length;
    library.empty.hidden = invalid || !searching || !!matches.length;
    library.back.hidden = !state.library_group;
    library.status.textContent = invalid ? (zh ? '搜索内容无效。请输入不超过256个字符，且不含不支持的控制字符。' : 'Search input is invalid. Use up to 256 characters without unsupported control characters.') :
      searching && !matches.length ? (zh ? '没有匹配的工具。请尝试其他工具名称或问题。' : 'No tools match this search. Try another tool name or question.') : '';
    var nextResult = null;
    resultRows.slice().reverse().forEach(function (row) {
      if (row.parentNode !== library.results || row.nextSibling !== nextResult) {
        if (nextResult === null) library.results.appendChild(row);
        else library.results.insertBefore(row,nextResult);
      }
      nextResult = row;
    });
  }

  function libraryEvent(controller, event) {
    var library = controller.library;
    if (!controller.live || !library || !library.valid || library.panel.hidden ||
        !event.target.closest || event.target.closest('[data-im-workspace]')!==controller.root) return false;
    if (event.type === 'submit' && event.target === library.form) { event.preventDefault(); return true; }
    var clear = event.type === 'click' && event.target.closest && event.target.closest('[data-im-library-clear]') === library.clear;
    if (!clear && event.target !== library.input) return false;
    if (event.type === 'compositionstart') { library.composing = true; return true; }
    if (event.type === 'input' && library.composing) {
      // Validate the interim draft through the same helper, but keep the last
      // committed result set until composition ends (including locale changes).
      try { IntlLibrarySearch.searchIntlTools(library.catalogue, library.input.value, controller.state.library_group, {composing:true}); } catch (_) {}
      return true;
    }
    if (clear || event.type === 'compositionend' || event.type === 'input') {
      if (clear) { event.preventDefault(); library.input.value = ''; }
      var previousQuery = library.query;
      library.composing = false; library.query = library.input.value;
      var committed = stageAndCommit(controller,controller.state,controller.issues,'resize');
      if (!committed.ok) { library.query=previousQuery; library.input.value=previousQuery; }
      if (clear) library.input.focus();
      return true;
    }
    return false;
  }

  var INSPECTOR_FIELDS = ['local', 'usd', 'fx_contribution'];

  function inspectorPublic(controller) {
    if (!controller.inspector) return null;
    return { market: controller.inspector.market, mode: controller.inspector.mode, field: controller.inspector.field };
  }

  function inspectorResult(controller, ok, issues) {
    return { ok: ok, state: controller.state, issues: issues || [], intent: null, inspector: inspectorPublic(controller) };
  }

  function isPlainOwnObject(value) {
    if (typeof value !== 'object' || value === null || Array.isArray(value)) return false;
    var prototype = Object.getPrototypeOf(value);
    return prototype === Object.prototype || prototype === null;
  }

  function ownDataCopy(value, expectedKeys) {
    if (!isPlainOwnObject(value)) return null;
    if (Object.getOwnPropertySymbols(value).length !== 0) return null;
    var names = Object.getOwnPropertyNames(value);
    if (names.length !== expectedKeys.length) return null;
    var copy = {};
    for (var index = 0; index < expectedKeys.length; index += 1) {
      var key = expectedKeys[index];
      if (!Object.prototype.hasOwnProperty.call(value, key)) return null;
      var descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (!descriptor || !('value' in descriptor) || descriptor.get || descriptor.set) return null;
      var field = descriptor.value;
      var fieldType = typeof field;
      if (fieldType === 'function' || fieldType === 'symbol' || fieldType === 'undefined' || fieldType === 'bigint') return null;
      if (fieldType === 'number' && !Number.isFinite(field)) return null;
      if (fieldType === 'object' && field !== null) return null;
      copy[key] = field;
    }
    return copy;
  }

  function normalizeSource(value) {
    if (value === null || value === '') return null;
    if (typeof value !== 'string') return undefined;
    return value;
  }

  function articleSource(article) {
    if (!article.hasAttribute('data-source')) return null;
    var value = article.getAttribute('data-source');
    return value === '' ? null : value;
  }

  function validGeneration(value) {
    return typeof value === 'string' && /^im-workspace-generation:[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(value);
  }

  function workspaceBinding(root, config) {
    var marker = root.getAttribute('data-im-binding-version');
    var version = marker === null || marker === '1' ? 1 : marker === '2' ? 2 : null;
    var nodes = owned(root, '[data-im-panel], [data-im-inspector-payload], [data-im-inspector-origin], [data-im-inspector-trigger], [data-im-inspector-open]');
    if (!version || (version === 2 && !validGeneration(config.source_reference)) || nodes.some(function (node) {
      return version === 2 ? node.getAttribute('data-im-generation') !== config.source_reference : node.hasAttribute('data-im-generation');
    })) throw new TypeError('Invalid International workspace publication binding');
    return version;
  }

  function overviewMatchesArticle(controller, article, state) {
    var matches = owned(controller.root, '[data-im-panel][data-view="overview"]').filter(function (panel) {
      return panelValid(panel, controller.config, state.source_reference, controller.bindingVersion) &&
        panel.getAttribute('data-horizon') === state.horizon && panel.getAttribute('data-basis') === state.currency_basis &&
        overviewContextId(panel) === article.getAttribute('data-im-inspector-context') &&
        articleSource(panel) === articleSource(article);
    });
    return matches.length === 1;
  }

  function articleOwned(controller, node) {
    return !!(node && node.closest && node.closest('[data-im-workspace]') === controller.root);
  }

  function inspectorShell(controller) {
    var shells = owned(controller.root, 'dialog[data-im-inspector-shell]');
    return shells.length === 1 ? shells[0] : null;
  }

  function articleMatchesTuple(article, state) {
    return article.getAttribute('data-horizon') === state.horizon &&
      article.getAttribute('data-basis') === state.currency_basis &&
      article.getAttribute('data-return-basis') === state.return_basis &&
      !article.hasAttribute('data-view');
  }

  function articleMatchesRequest(controller, article, marketId, expectedSource) {
    return articleOwned(controller, article) &&
      article.getAttribute('data-market-id') === marketId &&
      articleMatchesTuple(article, controller.state) &&
      (controller.bindingVersion === 2 ?
        article.getAttribute('data-im-generation') === expectedSource &&
          overviewMatchesArticle(controller, article, controller.state) : articleSource(article) === expectedSource);
  }

  function matchingInspectorArticles(controller, marketId, expectedSource) {
    return owned(controller.root, '[data-im-inspector-payload]').filter(function (article) {
      return articleMatchesRequest(controller, article, marketId, expectedSource);
    });
  }

  function overviewContextId(panel) {
    if (!panel || typeof panel.id !== 'string') return null;
    var suffix = '-overview';
    if (panel.id.length <= suffix.length) return null;
    if (panel.id.slice(panel.id.length - suffix.length) !== suffix) return null;
    var contextId = panel.id.slice(0, panel.id.length - suffix.length);
    return contextId || null;
  }

  function activeOverviewPanels(controller) {
    if (!controller.state || controller.state.view !== 'overview') return [];
    return panelFor(controller, controller.state).filter(function (panel) {
      return panel.getAttribute('data-view') === 'overview';
    });
  }

  function inspectorFingerprint(state) {
    return JSON.stringify({
      view: state.view,
      horizon: state.horizon,
      currency_basis: state.currency_basis,
      return_basis: state.return_basis,
      selected_market: state.selected_market,
      pins: state.compare_markets,
      source: state.source_reference
    });
  }

  function appendWords(parent, en, zh) {
    var enNode = parent.ownerDocument.createElement('span');
    enNode.className = 'l-en';
    enNode.textContent = en;
    var zhNode = parent.ownerDocument.createElement('span');
    zhNode.className = 'l-zh';
    zhNode.setAttribute('lang', 'zh');
    zhNode.textContent = zh;
    parent.appendChild(enNode);
    parent.appendChild(zhNode);
  }

  function makeInspectorButton(document, action, en, zh) {
    var button = document.createElement('button');
    button.setAttribute('type', 'button');
    button.setAttribute('data-im-inspector-action', action);
    appendWords(button, en, zh);
    return button;
  }

  function captureScrollOffsets(controller, origin) {
    var win = controller.environment.window;
    var lists = [];
    var node = origin;
    while (node && node !== controller.root) {
      if (node.nodeType === 1 && (node.scrollTop || node.scrollLeft)) {
        lists.push({ node: node, top: node.scrollTop, left: node.scrollLeft });
      }
      node = node.parentNode;
    }
    return {
      windowX: win.scrollX || win.pageXOffset || 0,
      windowY: win.scrollY || win.pageYOffset || 0,
      lists: lists
    };
  }

  function restoreScrollOffsets(controller, scroll) {
    if (!scroll) return;
    var win = controller.environment.window;
    if (typeof win.scrollTo === 'function') win.scrollTo(scroll.windowX, scroll.windowY);
    scroll.lists.forEach(function (entry) {
      if (!entry.node || !entry.node.isConnected) return;
      entry.node.scrollTop = entry.top;
      entry.node.scrollLeft = entry.left;
    });
  }

  function nodeUsable(controller, node) {
    if (!node || !node.isConnected || !articleOwned(controller, node)) return false;
    if (node.closest('[hidden]')) return false;
    if (!node.getClientRects || !node.getClientRects().length) return false;
    var win = controller.environment.window;
    try {
      if (win.getComputedStyle && win.getComputedStyle(node).visibility === 'hidden') return false;
    } catch (_) {}
    return true;
  }

  function inspectorHeading(article, mode, field) {
    if (mode === 'ledger') return article.querySelector('[data-im-inspector-page="ledger"] [tabindex="-1"], [data-im-inspector-page="ledger"] h4');
    if (mode === 'field' && field) {
      var block = article.querySelector('[data-im-inspector-field="' + field + '"]');
      return block ? block.querySelector('[tabindex="-1"], h5') : null;
    }
    if (mode === 'deeper') {
      var deeper = article.querySelector('[data-im-inspector-page="deeper"]');
      return deeper ? deeper.querySelector('[tabindex="-1"], h4') : article.querySelector('[data-im-inspector-title]');
    }
    return article.querySelector('[data-im-inspector-title]');
  }

  function snapshotInspectorOwned(root) {
    var selector = '[data-im-inspector-origin],[data-im-inspector-payload],[data-im-inspector-enhancement],[data-im-inspector-page],[data-im-inspector-ledger],[data-im-inspector-field],[data-im-inspector-shell]';
    return owned(root, selector).map(function (node) {
      var attrs = ['hidden'];
      if (node.matches('details')) attrs.push('open');
      if (node.matches('[data-im-inspector-shell]')) attrs.push('aria-labelledby', 'aria-label');
      return {
        node: node,
        attrs: attrs.map(function (name) { return [name, node.getAttribute(name)]; }),
        open: 'open' in node ? !!node.open : null,
        parent: node.matches('[data-im-inspector-payload]') ? node.parentNode : null,
        next: node.nextSibling
      };
    });
  }

  function snapshotInspectorSubtree(article, shell, originDetails) {
    var nodes = [article, shell, originDetails];
    if (article) nodes = nodes.concat(Array.from(article.querySelectorAll('[data-im-inspector-enhancement],[data-im-inspector-page],[data-im-inspector-ledger],[data-im-inspector-field],[data-im-inspector-deeper-unavailable]')));
    return nodes.filter(Boolean).map(function (node) {
      return {
        node: node,
        hidden: !!node.hidden,
        open: 'open' in node ? !!node.open : null,
        labelledby: node.getAttribute ? node.getAttribute('aria-labelledby') : null,
        label: node.getAttribute ? node.getAttribute('aria-label') : null
      };
    });
  }

  function restoreOwnedPresentation(entries) {
    if (!entries) return;
    entries.forEach(function (entry) {
      if (!entry.node) return;
      entry.node.hidden = entry.hidden;
      if (entry.node.removeAttribute) {
        if (entry.labelledby == null) entry.node.removeAttribute('aria-labelledby');
        else entry.node.setAttribute('aria-labelledby', entry.labelledby);
      }
      if (entry.node.matches && entry.node.matches('dialog')) return;
      if (entry.open !== null && 'open' in entry.node) entry.node.open = entry.open;
    });
  }

  function placeNode(node, parent, next) {
    if (!node || !parent) return;
    var reference = next && next.parentNode === parent ? next : null;
    if (node.parentNode !== parent || node.nextSibling !== reference) parent.insertBefore(node, reference);
  }

  function prepareInspector(controller) {
    var prepared = { supported: false, originals: snapshotInspectorOwned(controller.root), added: [], generation: 0, modalityFailed: false, shell: null };
    var shell = inspectorShell(controller);
    if (!shell || typeof shell.showModal !== 'function' || typeof shell.close !== 'function') return prepared;
    prepared.supported = true;
    prepared.shell = shell;
    return prepared;
  }

  function paintInspectorFallbacks(controller, state) {
    if (!controller.inspectorHost) return;
    owned(controller.root, '[data-im-inspector-origin]').forEach(function (details) {
      if (controller.inspector && controller.inspector.placement.originDetails === details) {
        details.hidden = true;
        return;
      }
      var article = details.querySelector('[data-im-inspector-payload]');
      if (!article || !articleOwned(controller, article)) {
        details.hidden = false;
        return;
      }
      if (!articleMatchesTuple(article, state)) {
        details.hidden = true;
        return;
      }
      if (controller.bindingVersion === 2) {
        var trigger = details.querySelector('[data-im-inspector-trigger]');
        details.hidden = article.getAttribute('data-im-generation') !== state.source_reference ||
          details.getAttribute('data-im-generation') !== state.source_reference ||
          !trigger || trigger.getAttribute('data-im-generation') !== state.source_reference ||
          !overviewMatchesArticle(controller, article, state);
        return;
      }
      var disclosed = articleSource(article);
      if (disclosed !== null && disclosed !== state.source_reference) {
        details.hidden = true;
        return;
      }
      details.hidden = false;
    });
  }

  function applyInspectorLanguage(controller) {
    var shell = controller.inspectorHost && controller.inspectorHost.shell;
    if (!shell) return;
    var zh = normalLanguage(controller.root) === 'zh';
    var label = shell.getAttribute(zh ? 'data-im-label-zh' : 'data-im-label-en');
    if (label) shell.setAttribute('aria-label', label);
  }

  function ensureEnhancedControls(controller, article) {
    var host = controller.inspectorHost;
    var nav = article.querySelector('[data-im-inspector-enhancement]');
    if (!nav || !articleOwned(controller, nav)) return nav;
    nav.hidden = false;
    if (!nav.querySelector('[data-im-inspector-action="evidence"]')) {
      var evidence = makeInspectorButton(article.ownerDocument, 'evidence', 'Evidence', '依据');
      nav.appendChild(evidence);
      host.added.push(evidence);
    }
    if (!nav.querySelector('[data-im-inspector-action="deeper"]')) {
      var deeper = makeInspectorButton(article.ownerDocument, 'deeper', 'Go deeper', '深入研究');
      nav.appendChild(deeper);
      host.added.push(deeper);
    }
    return nav;
  }

  function applyInspectorMode(controller, mode, field, options) {
    var attachment = controller.inspector;
    if (!attachment) return false;
    var previousMode = attachment.mode;
    var previousField = attachment.field;
    var article = attachment.placement.article;
    var previousFocus = article.ownerDocument.activeElement;
    var snapshot = snapshotInspectorSubtree(article, attachment.placement.shell, attachment.placement.originDetails);
    var host = controller.inspectorHost;
    var addedCount = host && host.added ? host.added.length : 0;
    try {
      var read = article.querySelector('[data-im-inspector-page="read"]');
      var ledger = article.querySelector('[data-im-inspector-ledger]');
      var deeper = article.querySelector('[data-im-inspector-page="deeper"]');
      var unavailable = article.querySelector('[data-im-inspector-deeper-unavailable]');
      if (mode === 'deeper' && !deeper && !unavailable) {
        unavailable = article.ownerDocument.createElement('p');
        unavailable.setAttribute('data-im-inspector-deeper-unavailable', '');
        appendWords(unavailable, 'No deeper destinations are available for this market.', '此市场暂无深入研究目标。');
        article.appendChild(unavailable);
        if (host && host.added) host.added.push(unavailable);
      }
      if (read) read.hidden = mode !== 'read';
      if (ledger) {
        ledger.hidden = mode !== 'ledger' && mode !== 'field';
        ledger.open = mode === 'ledger' || mode === 'field';
      }
      Array.from(article.querySelectorAll('[data-im-inspector-field]')).forEach(function (node) {
        var id = node.getAttribute('data-im-inspector-field');
        if (mode === 'field') {
          node.hidden = id !== field;
          node.open = id === field;
        } else if (mode === 'ledger') {
          node.hidden = false;
          node.open = false;
        } else {
          node.hidden = true;
          node.open = false;
        }
      });
      if (deeper) deeper.hidden = mode !== 'deeper';
      unavailable = article.querySelector('[data-im-inspector-deeper-unavailable]');
      if (unavailable) unavailable.hidden = !(mode === 'deeper' && !deeper);
      attachment.mode = mode;
      attachment.field = mode === 'field' ? field : null;
      var heading = inspectorHeading(article, mode, field);
      var shell = attachment.placement.shell;
      if (heading && heading.id) shell.setAttribute('aria-labelledby', heading.id);
      else shell.removeAttribute('aria-labelledby');
      applyInspectorLanguage(controller);
      if (!options || options.focus !== false) {
        var focusTarget = options && options.focusNode ? options.focusNode : heading;
        if (focusTarget && typeof focusTarget.focus === 'function') focusTarget.focus();
      }
      return true;
    } catch (_) {
      attachment.mode = previousMode;
      attachment.field = previousField;
      restoreOwnedPresentation(snapshot);
      if (host && host.added) {
        while (host.added.length > addedCount) {
          var extra = host.added.pop();
          if (extra && extra.parentNode) extra.parentNode.removeChild(extra);
        }
      }
      if (previousFocus && typeof previousFocus.focus === 'function') {
        try { previousFocus.focus(); } catch (error) {}
      }
      return false;
    }
  }

  function captureLiveInspector(controller) {
    var attachment = controller.inspector;
    if (!attachment) return null;
    var article = attachment.placement.article;
    return {
      market: attachment.market,
      mode: attachment.mode,
      field: attachment.field,
      origin: attachment.origin,
      scroll: attachment.scroll,
      focus: attachment.focus,
      generation: attachment.generation,
      contextFingerprint: attachment.contextFingerprint,
      fieldTrigger: attachment.fieldTrigger,
      readControl: attachment.readControl,
      ownedSnapshot: attachment.ownedSnapshot,
      placement: {
        article: article,
        originDetails: attachment.placement.originDetails,
        originParent: attachment.placement.originParent,
        originNext: attachment.placement.originNext,
        originOpen: attachment.placement.originOpen,
        shell: attachment.placement.shell,
        dialogParent: article.parentNode,
        dialogNext: article.nextSibling
      },
      modal: dialogIsModal(attachment.placement.shell),
      focusNow: article.ownerDocument.activeElement
    };
  }

  function dialogIsModal(shell) {
    return !!(shell && (shell.open || (typeof shell.matches === 'function' && shell.matches(':modal'))));
  }

  function closeInspectorDialog(controller, shell) {
    if (!shell) return;
    controller.inspectorSilent = true;
    try {
      if (dialogIsModal(shell) && typeof shell.close === 'function') shell.close();
    } catch (_) {}
    controller.inspectorSilent = false;
  }

  function visuallyCloseInspector(controller, options) {
    var attachment = controller.inspector;
    if (!attachment) return;
    var placement = attachment.placement;
    var article = placement.article;
    closeInspectorDialog(controller, placement.shell);
    restoreOwnedPresentation(attachment.ownedSnapshot);
    var nav = article.querySelector('[data-im-inspector-enhancement]');
    if (nav) nav.hidden = true;
    placeNode(article, placement.originParent, placement.originNext);
    if (placement.originDetails) {
      placement.originDetails.open = !!placement.originOpen;
      placement.originDetails.hidden = false;
    }
    if (options && options.release) controller.inspector = null;
  }

  function releaseInspectorToOrigin(controller, snap) {
    if (!snap || !snap.placement) {
      controller.inspector = null;
      return;
    }
    if (controller.inspector) visuallyCloseInspector(controller, { release: true });
    else {
      var articleHome = snap.placement.article;
      closeInspectorDialog(controller, snap.placement.shell);
      restoreOwnedPresentation(snap.ownedSnapshot);
      if (articleHome) {
        var homeNav = articleHome.querySelector('[data-im-inspector-enhancement]');
        if (homeNav) homeNav.hidden = true;
        placeNode(articleHome, snap.placement.originParent, snap.placement.originNext);
      }
    }
    var originDetails = snap.placement.originDetails;
    if (originDetails) {
      originDetails.hidden = false;
      originDetails.open = true;
    }
    controller.inspector = null;
    if (controller.state) paintInspectorFallbacks(controller, controller.state);
    var focusNode = snap.focusNow;
    if (!nodeUsable(controller, focusNode)) {
      focusNode = originDetails && originDetails.querySelector('[data-im-inspector-trigger]');
    }
    if (!nodeUsable(controller, focusNode) && snap.placement.article) {
      focusNode = inspectorHeading(snap.placement.article, 'read', null);
    }
    if (focusNode && typeof focusNode.focus === 'function') {
      try { focusNode.focus(); } catch (_) {}
    }
  }

  function rehydrateInspector(controller, snap) {
    if (!snap) return false;
    try {
      var article = snap.placement.article;
      var shell = snap.placement.shell;
      placeNode(article, snap.placement.dialogParent, snap.placement.dialogNext);
      restoreOwnedPresentation(snap.ownedSnapshot);
      if (article) {
        var nav = article.querySelector('[data-im-inspector-enhancement]');
        if (nav) nav.hidden = false;
      }
      controller.inspector = {
        market: snap.market,
        mode: snap.mode,
        field: snap.field,
        origin: snap.origin,
        scroll: snap.scroll,
        focus: snap.focus,
        generation: snap.generation,
        contextFingerprint: snap.contextFingerprint,
        placement: {
          article: article,
          originDetails: snap.placement.originDetails,
          originParent: snap.placement.originParent,
          originNext: snap.placement.originNext,
          originOpen: snap.placement.originOpen,
          shell: snap.placement.shell
        },
        ownedSnapshot: snap.ownedSnapshot,
        fieldTrigger: snap.fieldTrigger,
        readControl: snap.readControl
      };
      var nativeOk = !snap.modal;
      if (snap.modal) {
        nativeOk = false;
        if (shell && typeof shell.showModal === 'function') {
          try {
            if (!dialogIsModal(shell)) shell.showModal();
            nativeOk = dialogIsModal(shell);
          } catch (_) {
            nativeOk = false;
          }
        }
      }
      // A native platform failure cannot restore modal; do not swallow mode false.
      if (!nativeOk || !applyInspectorMode(controller, snap.mode, snap.field, { focus: false })) {
        releaseInspectorToOrigin(controller, snap);
        return false;
      }
      if (controller.state) paintInspectorFallbacks(controller, controller.state);
      if (snap.focusNow && typeof snap.focusNow.focus === 'function' && snap.focusNow.isConnected) {
        try { snap.focusNow.focus(); } catch (_) {}
      }
      return true;
    } catch (_) {
      try { releaseInspectorToOrigin(controller, snap); } catch (error) {}
      return false;
    }
  }

  function closeInspector(controller, options) {
    if (!controller.live && !(options && options.destroying)) return destroyedResult();
    var attachment = controller.inspector;
    if (!attachment) return inspectorResult(controller, true, []);
    var restoreScroll = !options || options.restoreScroll !== false;
    var restoreFocus = !options || options.restoreFocus !== false;
    var contextUnchanged = controller.state && attachment.contextFingerprint === inspectorFingerprint(controller.state);
    var originNode = attachment.origin && attachment.origin.node;
    var originFingerprint = attachment.origin && attachment.origin.contextFingerprint;
    var scroll = attachment.scroll;
    visuallyCloseInspector(controller, { release: true });
    if (controller.state) paintInspectorFallbacks(controller, controller.state);
    if (restoreScroll && contextUnchanged) restoreScrollOffsets(controller, scroll);
    if (restoreFocus) {
      var originValid = !!(originNode && originFingerprint === inspectorFingerprint(controller.state) && nodeUsable(controller, originNode));
      var target = originValid ? originNode : owned(controller.root, '[data-im-heading]')[0];
      if (target && typeof target.focus === 'function') {
        try { target.focus(); } catch (_) {}
      }
    }
    return inspectorResult(controller, true, []);
  }

  function inspectorBack(controller) {
    if (!controller.live) return destroyedResult();
    var attachment = controller.inspector;
    if (!attachment) return inspectorResult(controller, true, []);
    var mode = attachment.mode;
    if (mode === 'field') {
      var trigger = attachment.fieldTrigger;
      if (!applyInspectorMode(controller, 'ledger', null, { focusNode: nodeUsable(controller, trigger) ? trigger : null })) {
        return inspectorResult(controller, false, [{ code: 'UI_UPDATE_FAILED', field: 'inspector' }]);
      }
      return inspectorResult(controller, true, []);
    }
    if (mode === 'ledger' || mode === 'deeper') {
      var readControl = attachment.readControl;
      var heading = inspectorHeading(attachment.placement.article, 'read', null);
      if (!applyInspectorMode(controller, 'read', null, { focusNode: nodeUsable(controller, readControl) ? readControl : heading })) {
        return inspectorResult(controller, false, [{ code: 'UI_UPDATE_FAILED', field: 'inspector' }]);
      }
      return inspectorResult(controller, true, []);
    }
    return closeInspector(controller, {});
  }

  function inspectorEvidence(controller, control) {
    var attachment = controller.inspector;
    if (!attachment) return inspectorResult(controller, false, [{ code: 'NO_MATCHING_PANEL', field: 'inspector' }]);
    if (attachment.mode !== 'read' && attachment.mode !== 'deeper') return inspectorResult(controller, true, []);
    attachment.readControl = control || attachment.readControl;
    if (!applyInspectorMode(controller, 'ledger', null, {})) {
      return inspectorResult(controller, false, [{ code: 'UI_UPDATE_FAILED', field: 'inspector' }]);
    }
    return inspectorResult(controller, true, []);
  }

  function inspectorDeeper(controller, control) {
    var attachment = controller.inspector;
    if (!attachment) return inspectorResult(controller, false, [{ code: 'NO_MATCHING_PANEL', field: 'inspector' }]);
    if (attachment.mode !== 'read' && attachment.mode !== 'ledger') return inspectorResult(controller, true, []);
    attachment.readControl = control || attachment.readControl;
    if (!applyInspectorMode(controller, 'deeper', null, {})) {
      return inspectorResult(controller, false, [{ code: 'UI_UPDATE_FAILED', field: 'inspector' }]);
    }
    return inspectorResult(controller, true, []);
  }

  function inspectorField(controller, field, control) {
    var attachment = controller.inspector;
    if (!attachment || attachment.mode !== 'ledger') {
      return inspectorResult(controller, false, [{ code: 'NO_MATCHING_PANEL', field: 'inspector' }]);
    }
    if (INSPECTOR_FIELDS.indexOf(field) === -1) return inspectorResult(controller, false, [{ code: 'INVALID_ACTION', field: 'field' }]);
    var node = attachment.placement.article.querySelector('[data-im-inspector-field="' + field + '"]');
    if (!node) return inspectorResult(controller, false, [{ code: 'NO_MATCHING_PANEL', field: 'field' }]);
    attachment.fieldTrigger = control || node.querySelector('[data-im-inspector-field-trigger]');
    if (!applyInspectorMode(controller, 'field', field, {})) {
      return inspectorResult(controller, false, [{ code: 'UI_UPDATE_FAILED', field: 'inspector' }]);
    }
    return inspectorResult(controller, true, []);
  }

  function openInspector(controller, request) {
    if (!controller.live) return destroyedResult();
    var copied = ownDataCopy(request, ['market_id', 'expected_source']);
    if (!copied) return inspectorResult(controller, false, [{ code: 'INVALID_ACTION', field: 'inspector' }]);
    if (typeof copied.market_id !== 'string' || copied.market_id.length === 0) {
      return inspectorResult(controller, false, [{ code: 'INVALID_ACTION', field: 'market_id' }]);
    }
    var expected = normalizeSource(copied.expected_source);
    if (expected === undefined && copied.expected_source !== null) {
      return inspectorResult(controller, false, [{ code: 'INVALID_ACTION', field: 'expected_source' }]);
    }
    var currentSource = normalizeSource(controller.state.source_reference);
    if (expected !== currentSource) return inspectorResult(controller, false, [{ code: 'STALE_SOURCE', field: 'expected_source' }]);
    var host = controller.inspectorHost;
    var shell = host && host.shell ? host.shell : inspectorShell(controller);
    if (!host || !host.supported || host.modalityFailed || !shell) {
      return inspectorResult(controller, false, [{ code: 'NO_MATCHING_PANEL', field: 'inspector' }]);
    }
    var overviewPanels = activeOverviewPanels(controller);
    if (overviewPanels.length > 1) return inspectorResult(controller, false, [{ code: 'AMBIGUOUS_PANEL', field: 'inspector' }]);
    if (overviewPanels.length !== 1) return inspectorResult(controller, false, [{ code: 'NO_MATCHING_PANEL', field: 'inspector' }]);
    var contextId = overviewContextId(overviewPanels[0]);
    if (!contextId) return inspectorResult(controller, false, [{ code: 'NO_MATCHING_PANEL', field: 'inspector' }]);
    var matches = matchingInspectorArticles(controller, copied.market_id, expected).filter(function (article) {
      return article.getAttribute('data-im-inspector-context') === contextId;
    });
    if (matches.length > 1) return inspectorResult(controller, false, [{ code: 'AMBIGUOUS_PANEL', field: 'inspector' }]);
    if (matches.length !== 1) return inspectorResult(controller, false, [{ code: 'NO_MATCHING_PANEL', field: 'inspector' }]);
    var article = matches[0];
    if (controller.inspector && controller.inspector.placement.article === article && dialogIsModal(shell)) {
      if (!applyInspectorMode(controller, 'read', null, {})) {
        return inspectorResult(controller, false, [{ code: 'UI_UPDATE_FAILED', field: 'inspector' }]);
      }
      return inspectorResult(controller, true, []);
    }
    if (controller.inspector) closeInspector(controller, { restoreScroll: true, restoreFocus: false });
    var originDetails = article.closest('[data-im-inspector-origin]');
    var trigger = controller.pendingInspectorTrigger ||
      (originDetails && originDetails.querySelector('[data-im-inspector-trigger]')) || article;
    var focusNow = article.ownerDocument.activeElement;
    var scroll = captureScrollOffsets(controller, originDetails || article);
    var originOpen = originDetails ? !!originDetails.open : false;
    var originParent = article.parentNode;
    var originNext = article.nextSibling;
    var fingerprint = inspectorFingerprint(controller.state);
    ensureEnhancedControls(controller, article);
    var ownedBefore = snapshotInspectorSubtree(article, shell, originDetails);
    placeNode(article, shell, null);
    if (originDetails) {
      originDetails.open = false;
      originDetails.hidden = true;
    }
    controller.inspector = {
      market: copied.market_id,
      mode: 'read',
      field: null,
      origin: { node: trigger, contextFingerprint: fingerprint },
      scroll: scroll,
      focus: focusNow,
      generation: (host.generation += 1),
      contextFingerprint: fingerprint,
      placement: {
        article: article,
        originDetails: originDetails,
        originParent: originParent,
        originNext: originNext,
        originOpen: originOpen,
        shell: shell
      },
      ownedSnapshot: ownedBefore,
      fieldTrigger: null,
      readControl: null
    };
    var shown = false;
    try {
      if (!applyInspectorMode(controller, 'read', null, { focus: false })) {
        placeNode(article, originParent, originNext);
        restoreOwnedPresentation(ownedBefore);
        if (originDetails) {
          originDetails.open = originOpen;
          originDetails.hidden = false;
        }
        var failedNav = article.querySelector('[data-im-inspector-enhancement]');
        if (failedNav) failedNav.hidden = true;
        controller.inspector = null;
        paintInspectorFallbacks(controller, controller.state);
        return inspectorResult(controller, false, [{ code: 'UI_UPDATE_FAILED', field: 'inspector' }]);
      }
      try {
        shell.showModal();
        shown = true;
      } catch (showError) {
        placeNode(article, originParent, originNext);
        restoreOwnedPresentation(ownedBefore);
        if (originDetails) {
          originDetails.open = originOpen;
          originDetails.hidden = false;
        }
        var modalNav = article.querySelector('[data-im-inspector-enhancement]');
        if (modalNav) modalNav.hidden = true;
        controller.inspector = null;
        host.modalityFailed = true;
        paintInspectorFallbacks(controller, controller.state);
        return inspectorResult(controller, false, [{ code: 'UI_UPDATE_FAILED', field: 'inspector' }]);
      }
      var heading = inspectorHeading(article, 'read', null);
      if (heading && heading.focus) heading.focus();
      paintInspectorFallbacks(controller, controller.state);
      return inspectorResult(controller, true, []);
    } catch (_) {
      if (shown) {
        closeInspector(controller, { restoreScroll: true, restoreFocus: true });
      } else {
        placeNode(article, originParent, originNext);
        restoreOwnedPresentation(ownedBefore);
        if (originDetails) {
          originDetails.open = originOpen;
          originDetails.hidden = false;
        }
        var nav = article.querySelector('[data-im-inspector-enhancement]');
        if (nav) nav.hidden = true;
        controller.inspector = null;
        paintInspectorFallbacks(controller, controller.state);
        restoreScrollOffsets(controller, scroll);
        if (focusNow && typeof focusNow.focus === 'function') {
          try { focusNow.focus(); } catch (error) {}
        }
      }
      return inspectorResult(controller, false, [{ code: 'UI_UPDATE_FAILED', field: 'inspector' }]);
    }
  }

  function teardownInspector(controller) {
    if (controller.inspector) closeInspector(controller, { restoreScroll: false, restoreFocus: false, destroying: true });
    var host = controller.inspectorHost;
    if (!host) return;
    if (host.shell && controller.onInspectorCancel) {
      host.shell.removeEventListener('cancel', controller.onInspectorCancel, false);
    }
    if (host.shell && controller.onInspectorKeydown) {
      host.shell.removeEventListener('keydown', controller.onInspectorKeydown, true);
    }
    if (host.shell && controller.onInspectorClose) {
      host.shell.removeEventListener('close', controller.onInspectorClose, false);
    }
    host.added.slice().forEach(function (node) {
      if (node && node.parentNode) node.parentNode.removeChild(node);
    });
    host.added = [];
    host.originals.forEach(function (entry) {
      var node = entry.node;
      if (!node) return;
      if (entry.parent) placeNode(node, entry.parent, entry.next);
      entry.attrs.forEach(function (attribute) {
        if (attribute[1] === null) node.removeAttribute(attribute[0]);
        else node.setAttribute(attribute[0], attribute[1]);
      });
      if (entry.open !== null && 'open' in node && !(node.matches && node.matches('dialog'))) node.open = entry.open;
    });
    controller.inspector = null;
  }

  function inspectorEvent(controller, event) {
    if (!controller.live || !controller.inspectorHost) return false;
    var target = event.target;
    if (!target || !target.closest) return false;
    if (target.closest('[data-im-workspace]') !== controller.root) return false;
    if (event.type !== 'click') return false;
    var deeperLink = target.closest('a');
    if (deeperLink && controller.inspector && articleOwned(controller, deeperLink) &&
        deeperLink.closest('[data-im-inspector-page="deeper"]')) {
      closeInspector(controller, { restoreScroll: false, restoreFocus: false });
      return false;
    }
    var openBtn = target.closest('button[data-im-inspector-open]');
    if (openBtn && articleOwned(controller, openBtn) && !openBtn.disabled) {
      event.preventDefault();
      controller.pendingInspectorTrigger = openBtn;
      var sourceAttr = controller.bindingVersion === 2 ? openBtn.getAttribute('data-im-generation') :
        openBtn.hasAttribute('data-source') ? openBtn.getAttribute('data-source') : null;
      openInspector(controller, { market_id: openBtn.getAttribute('data-market-id'), expected_source: normalizeSource(sourceAttr) });
      controller.pendingInspectorTrigger = null;
      return true;
    }
    var trigger = target.closest('[data-im-inspector-trigger]');
    if (trigger && articleOwned(controller, trigger) && controller.inspectorHost.supported && !controller.inspectorHost.modalityFailed) {
      var origin = trigger.closest('[data-im-inspector-origin]');
      var article = origin && origin.querySelector('[data-im-inspector-payload]');
      if (controller.bindingVersion === 2 && (!article ||
          trigger.getAttribute('data-im-generation') !== controller.state.source_reference ||
          origin.getAttribute('data-im-generation') !== controller.state.source_reference ||
          !articleMatchesRequest(controller, article, article.getAttribute('data-market-id'), controller.state.source_reference))) {
        event.preventDefault();
        return true;
      }
      if (article && (controller.bindingVersion !== 2 ||
          (controller.state.view === 'overview' && trigger.getAttribute('data-im-generation') === controller.state.source_reference &&
           origin.getAttribute('data-im-generation') === controller.state.source_reference)) &&
          articleMatchesRequest(controller, article, article.getAttribute('data-market-id'), normalizeSource(controller.state.source_reference))) {
        event.preventDefault();
        controller.pendingInspectorTrigger = trigger;
        openInspector(controller, { market_id: article.getAttribute('data-market-id'), expected_source: controller.bindingVersion === 2 ? trigger.getAttribute('data-im-generation') : articleSource(article) });
        controller.pendingInspectorTrigger = null;
        return true;
      }
    }
    if (!controller.inspector) return false;
    var actionBtn = target.closest('[data-im-inspector-action]');
    if (actionBtn && articleOwned(controller, actionBtn)) {
      var action = actionBtn.getAttribute('data-im-inspector-action');
      event.preventDefault();
      if (action === 'close') closeInspector(controller, {});
      else if (action === 'back') inspectorBack(controller);
      else if (action === 'evidence') inspectorEvidence(controller, actionBtn);
      else if (action === 'deeper') inspectorDeeper(controller, actionBtn);
      return true;
    }
    var ledgerTrigger = target.closest('[data-im-inspector-ledger-trigger]');
    if (ledgerTrigger && articleOwned(controller, ledgerTrigger)) {
      event.preventDefault();
      if (controller.inspector.mode === 'read' || controller.inspector.mode === 'deeper') inspectorEvidence(controller, ledgerTrigger);
      return true;
    }
    var fieldTrigger = target.closest('[data-im-inspector-field-trigger]');
    if (fieldTrigger && articleOwned(controller, fieldTrigger)) {
      event.preventDefault();
      if (controller.inspector.mode === 'ledger') {
        var fieldNode = fieldTrigger.closest('[data-im-inspector-field]');
        inspectorField(controller, fieldNode && fieldNode.getAttribute('data-im-inspector-field'), fieldTrigger);
      }
      return true;
    }
    return false;
  }

  function inspectorCancel(controller, event) {
    if (controller.inspectorSilent) return;
    if (event && typeof event.preventDefault === 'function') event.preventDefault();
    if (!controller.live || !controller.inspector) return;
    inspectorBack(controller);
  }

  function inspectorNativeClose(controller, event) {
    if (controller.inspectorSilent) return;
    if (!controller.live) return;
    var host = controller.inspectorHost;
    var shell = host && host.shell;
    if (!shell) return;
    if (event && event.target && event.target !== shell) return;
    if (dialogIsModal(shell)) return;
    var attachment = controller.inspector;
    if (!attachment || attachment.placement.shell !== shell) return;
    closeInspector(controller, {});
  }

  function inspectorEscapeKey(controller, event) {
    if (controller.inspectorSilent || !controller.inspector) return;
    if (!event || (event.key !== 'Escape' && event.key !== 'Esc')) return;
    if (typeof event.preventDefault === 'function') event.preventDefault();
    inspectorBack(controller);
  }

  // Compare consumes only a server-ordered, identity-free slot catalogue.
  // Financial text and endpoint windows stay on their original DOM nodes.
  function comparePlan(controller, panel, state) {
    if (!panel || !panel.hasAttribute('data-im-compare-panel') || panel.getAttribute('data-return-basis') !== 'price') return null;
    var all = function (selector) { return owned(controller.root, selector).filter(function (node) { return node.closest('[data-im-panel]') === panel; }); };
    var one = function (selector) { var nodes = all(selector); return nodes.length === 1 ? nodes[0] : null; };
    var script = one('script[data-im-compare-catalogue]'), body = one('tbody[data-im-compare-rows]');
    var status = one('[data-im-compare-status]'), controls = one('[data-im-compare-controls]'), picker = one('select[data-im-compare-pin]');
    if (!script || script.type !== 'application/json' || script.textContent.length > 65536 || !body || !status || !controls || !picker || !controls.contains(picker)) return null;
    var data;
    try { data = JSON.parse(script.textContent); } catch (_) { return null; }
    var keys = function (value, expected) { return value && typeof value === 'object' && !Array.isArray(value) && Object.keys(value).length === expected.length && expected.every(function (k) { return Object.prototype.hasOwnProperty.call(value,k); }); };
    var count = controller.config.markets.length;
    if (!keys(data,['schema','slot_order','cohorts']) || data.schema !== 'intl-compare-catalogue.v1' ||
        !Array.isArray(data.slot_order) || data.slot_order.length !== count || data.slot_order.some(function (slot,i) { return slot !== i; }) || !Array.isArray(data.cohorts)) return null;
    var slotNumber = function (text) { return typeof text === 'string' && /^(0|[1-9][0-9]*)$/.test(text) && Number(text) < count ? Number(text) : null; };
    var rows = new Map(), membership = new Map(), groups = new Map();
    var rowNodes = all('tr[data-im-compare-slot]');
    if (rowNodes.length !== count) return null;
    for (var row of rowNodes) {
      var slot = slotNumber(row.getAttribute('data-im-compare-slot'));
      if (slot === null || rows.has(slot) || row.parentNode !== body) return null;
      rows.set(slot,row);
    }
    for (var cohort of data.cohorts) {
      if (!keys(cohort,['id','order_slots']) || typeof cohort.id !== 'string' || !/^c(0|[1-9][0-9]*)$/.test(cohort.id) || groups.has(cohort.id) || !Array.isArray(cohort.order_slots) || !cohort.order_slots.length) return null;
      for (var member of cohort.order_slots) {
        if (!Number.isInteger(member) || !rows.has(member) || membership.has(member)) return null;
        membership.set(member,cohort.id);
      }
      groups.set(cohort.id,cohort.order_slots);
    }
    if (data.cohorts.length && !panel.getAttribute('data-source')) return null;
    for (var pair of rows) {
      if ((pair[1].getAttribute('data-im-compare-cohort-id') || null) !== (membership.get(pair[0]) || null)) return null;
    }
    var windows = all('[data-im-compare-cohort]'), windowIds = new Set();
    for (var windowNode of windows) {
      var id = windowNode.getAttribute('data-im-compare-cohort');
      if (!groups.has(id) || windowIds.has(id)) return null;
      windowIds.add(id);
    }
    if (windows.length !== groups.size) return null;
    var removes = all('button[data-im-compare-remove]'), removeSlots = new Set();
    for (var button of removes) {
      var removeSlot = slotNumber(button.getAttribute('data-im-compare-remove'));
      if (removeSlot === null || removeSlots.has(removeSlot) || button.closest('tr[data-im-compare-slot]') !== rows.get(removeSlot)) return null;
      removeSlots.add(removeSlot);
    }
    if (removes.length !== count) return null;
    var options = Array.from(picker.options), optionSlots = new Set(), empty = 0;
    for (var option of options) {
      if (option.parentNode !== picker || !option.hasAttribute('data-im-label-en') || !option.hasAttribute('data-im-label-zh')) return null;
      if (option.value === '') { empty++; continue; }
      var optionSlot = slotNumber(option.value);
      if (optionSlot === null || optionSlots.has(optionSlot) || !rows.get(optionSlot).hasAttribute('data-im-compare-cohort-id')) return null;
      optionSlots.add(optionSlot);
    }
    if (empty !== 1 || optionSlots.size !== rowNodes.filter(function (node) { return node.hasAttribute('data-im-compare-cohort-id'); }).length) return null;
    var selected = state.compare_markets.map(function (market) { return controller.config.markets.indexOf(market); });
    if (selected.some(function (slot) { return !rows.has(slot); })) return null;
    var verdict = 'incomplete', reason = 'selection_incomplete', order = selected.length ? selected.slice() : data.slot_order.slice();
    if (selected.length >= 2) {
      var groupId = membership.get(selected[0]);
      if (selected.some(function (slot) { return !membership.has(slot); })) reason = 'selection_unqualified';
      else if (selected.some(function (slot) { return membership.get(slot) !== groupId; })) reason = 'unequal_windows';
      else { verdict = 'comparable'; reason = ''; order = groups.get(groupId).filter(function (slot) { return selected.includes(slot); }); }
      if (reason) verdict = 'incomparable';
    }
    return {panel:panel,body:body,rows:rows,status:status,controls:controls,picker:picker,options:options,removes:removes,windows:windows,membership:membership,selected:selected,order:order,verdict:verdict,reason:reason};
  }

  function compareFocus(root) {
    var node = root.ownerDocument.activeElement;
    return node && node.closest && node.closest('[data-im-workspace]') === root &&
      node.closest('[data-im-compare-slot]') ? node : null;
  }

  function restoreCompareFocus(root, node) {
    if (node && node.isConnected && node.closest('[data-im-workspace]') === root &&
        !node.closest('[hidden]') && !node.matches(':disabled') && node.getClientRects().length &&
        root.ownerDocument.activeElement !== node) node.focus({preventScroll:true});
  }

  function paintSourceBoundCompareCharts(controller, plan) {
    // This is an extension of the *existing* Compare reducer paint pass,
    // not another subscription, selector, rights decision or state manager.
    // The publisher alone decides which source-bound geometry exists.
    var widgets = Array.from(plan.panel.querySelectorAll('[data-im-chart-model="intl-chart-geometry.v1"]'));
    if (!widgets.length) return;
    var selected = plan.selected.map(function (slot) { return controller.config.markets[slot]; });
    var cohortId = plan.verdict === 'comparable' && plan.selected.length >= 2 ?
      plan.membership.get(plan.selected[0]) : null;
    widgets.forEach(function (widget) {
      var groups = Array.from(widget.querySelectorAll('[data-im-chart-cohort]'));
      var seen = new Set(), available = false;
      for (var group of groups) {
        var id = group.getAttribute('data-im-chart-cohort');
        var duplicate = seen.has(id);
        seen.add(id);
        var lines = Array.from(group.querySelectorAll('[data-im-chart-series]'));
        var tableRows = Array.from(group.querySelectorAll('[data-im-chart-table-market]'));
        var lineIds = new Set(lines.map(function (node) { return node.getAttribute('data-im-chart-series'); }));
        var tableIds = new Set(tableRows.map(function (node) { return node.getAttribute('data-im-chart-table-market'); }));
        var show = !duplicate && cohortId === id && selected.length >= 2 &&
          selected.every(function (market) { return lineIds.has(market) && tableIds.has(market); });
        group.hidden = !show;
        lines.forEach(function (node) {
          // SVGGeometryElement.hidden may be only a JS expando; the actual
          // attribute is required for browser [hidden] CSS and rollback.
          node.toggleAttribute('hidden', !show || !selected.includes(node.getAttribute('data-im-chart-series')));
        });
        tableRows.forEach(function (node) { node.hidden = !show || !selected.includes(node.getAttribute('data-im-chart-table-market')); });
        if (show) available = true;
      }
      var notice = widget.querySelector('[data-im-chart-selection-unavailable]');
      if (notice) notice.hidden = plan.verdict !== 'comparable' || available;
    });
  }

  function paintCompare(controller, plan) {
    if (!plan) return;
    var focused = compareFocus(controller.root);
    var zh = normalLanguage(controller.root) === 'zh';
    var messages = {
      selection_incomplete: ['Select two to four markets to compare matching windows.', '选择两到四个市场，以比较相同的计算区间。'],
      selection_unqualified: ['Some selected markets lack qualified evidence. All selections are retained.', '部分所选市场缺少符合条件的依据。全部选择已保留。'],
      unequal_windows: ['Selected markets have different calculation windows. All selections are retained.', '所选市场的计算区间不同。全部选择已保留。'],
      comparable: ['Matching calculation windows · ordered by return.', '相同计算区间 · 按回报排序。']
    };
    plan.panel.setAttribute('data-im-compare-state',plan.verdict);
    plan.panel.setAttribute('data-im-compare-reason',plan.reason);
    plan.status.textContent = messages[plan.reason || 'comparable'][zh ? 1 : 0];
    var desired = plan.order.concat(Array.from(plan.rows.keys()).sort(function (a,b) { return a-b; }).filter(function (slot) { return !plan.order.includes(slot); }));
    var current = Array.from(plan.body.children).filter(function (node) { return Array.from(plan.rows.values()).includes(node); });
    if (desired.some(function (slot,i) { return current[i] !== plan.rows.get(slot); })) desired.forEach(function (slot) { plan.body.appendChild(plan.rows.get(slot)); });
    plan.rows.forEach(function (row,slot) { row.hidden = !plan.order.includes(slot); });
    plan.removes.forEach(function (button) { button.hidden = !plan.selected.includes(Number(button.getAttribute('data-im-compare-remove'))); });
    plan.windows.forEach(function (node) { node.hidden = !!plan.selected.length && !plan.selected.some(function (slot) { return plan.membership.get(slot) === node.getAttribute('data-im-compare-cohort'); }); });
    plan.options.forEach(function (option) { option.textContent = option.getAttribute(zh ? 'data-im-label-zh' : 'data-im-label-en'); option.disabled = option.value !== '' && plan.selected.includes(Number(option.value)); });
    plan.picker.value = '';
    plan.controls.hidden = false;
    paintSourceBoundCompareCharts(controller,plan);
    restoreCompareFocus(controller.root,focused);
  }

  function compareEvent(controller, event) {
    var target = event.target;
    if (!target || !target.closest || target.closest('[data-im-workspace]') !== controller.root) return false;
    var button = event.type === 'click' ? target.closest('button[data-im-compare-remove]') : null;
    var picker = event.type === 'change' && target.matches('select[data-im-compare-pin]') ? target : null;
    if (!button && !picker) return false;
    var matches = panelFor(controller,controller.state), panel = matches.length === 1 ? matches[0] : null;
    var control = button || picker;
    if (!panel || panel.hidden || !panel.contains(control) || control.disabled || control.closest('[hidden]')) return true;
    var plan = comparePlan(controller,panel,controller.state);
    if (!plan || (picker && picker !== plan.picker) || (button && !plan.removes.includes(button))) return true;
    var value = button ? button.getAttribute('data-im-compare-remove') : picker.value;
    if (value === '' || !/^(0|[1-9][0-9]*)$/.test(value)) return true;
    var slot = Number(value);
    if (!plan.rows.has(slot) || (button ? !plan.selected.includes(slot) : !plan.options.some(function (o) { return o.value === value && !o.disabled; }))) return true;
    event.preventDefault();
    var result = dispatch(controller,{type:button ? 'unpin' : 'pin',market_id:controller.config.markets[slot]});
    if (result.ok && button) plan.picker.focus();
    return true;
  }

  function snapshotRoot(root) {
    var selector = '[data-im-heading],[data-im-issues],[data-im-unavailable],[data-im-panel],'+
      '[data-im-action],[data-im-expanded-region],[data-im-expansion-trigger] .l-en,[data-im-expansion-trigger] .l-zh,'+
      '[data-im-library-static],[data-im-library-search],[data-im-library-clear],[data-im-library-status],'+
      '[data-im-library-groups],[data-im-library-group],[data-im-library-results],[data-im-library-empty],[data-im-library-tool],'+
      '[data-im-inspector-origin],[data-im-inspector-payload],[data-im-inspector-enhancement],[data-im-inspector-page],'+
      '[data-im-inspector-ledger],[data-im-inspector-field],[data-im-inspector-shell],[data-im-inspector-deeper-unavailable],'+
      '[data-im-macro-market],[data-im-risk-channel],[data-im-risk-row],[data-im-risk-prompt],[data-im-compare-panel],[data-im-compare-slot],[data-im-compare-status],[data-im-compare-cohort],[data-im-compare-controls],[data-im-compare-remove],[data-im-compare-pin],[data-im-compare-pin] option,'+
      '[data-im-chart-cohort],[data-im-chart-series],[data-im-chart-table-market],[data-im-chart-selection-unavailable]';
    selector += ',[data-im-history-panel],[data-im-history-slot],[data-im-history-prompt],[data-im-history-tabs],[data-im-scenario-field],[data-im-scenario-fields],[data-im-scenario-tab],[data-im-scenario-context],[data-im-scenario-candidate-context],[data-im-scenario-confirm-context],[data-im-scenario-confirm-reset],[data-im-scenario-result],[data-im-scenario-empty],[data-im-scenario-usd],[data-im-scenario-contribution],[data-im-scenario-rows],[data-im-scenario-announcement],[data-im-scenario-error],[data-im-scenario-action]';
    return [root].concat(owned(root, selector)).map(function (node) {
      var attrs = [], text = false, value = false;
      if (node === root) attrs.push('data-im-enhanced');
      if (node.closest('[data-im-history-panel]')) {
        attrs.push('hidden','disabled');
        if (node.matches('[data-im-history-panel]')) attrs.push('data-horizon','data-basis','data-im-history-enhanced','data-im-history-tab');
        if (node.matches('[data-im-scenario-field]')) { value=true;attrs.push('aria-invalid'); }
        if (node.matches('[data-im-scenario-tab]')) attrs.push('aria-pressed');
        if (node.matches('[data-im-scenario-context],[data-im-scenario-candidate-context],[data-im-scenario-usd],[data-im-scenario-contribution],[data-im-scenario-rows],[data-im-scenario-announcement],[data-im-scenario-error]')) text=true;
      }
      if (node.matches('[data-im-heading]')) attrs.push('tabindex');
      if (node.matches('[data-im-library-static]')) attrs.push('data-horizon','data-basis','data-im-library-enhanced');
      if (node.matches('[data-im-library-group]')) attrs.push('data-im-library-active');
      if (node.matches('[data-im-library-groups],[data-im-library-group],[data-im-library-results],[data-im-library-empty],[data-im-library-group-open],[data-im-library-back]')) attrs.push('hidden');
      if (node.matches('[data-im-library-search],[data-im-library-clear]')) attrs.push('disabled');
      if (node.matches('[data-im-library-search]')) { attrs.push('placeholder'); value = true; }
      if (node.matches('[data-im-library-status]')) text = true;
      if (node.matches('[data-im-issues]')) { attrs.push('role'); text = true; }
      if (node.matches('[data-im-unavailable],[data-im-panel],[data-im-expanded-region]')) attrs.push('hidden');
      if (node.matches('button[data-im-action="set_view"]')) attrs.push('disabled','aria-pressed');
      if (node.matches('select[data-im-action]')) value = ['select_market','set_library_group','set_view','set_horizon','set_basis'].includes(node.getAttribute('data-im-action'));
      if (node.matches('[data-im-expansion-trigger]')) attrs.push('hidden','aria-expanded','data-im-expanded');
      if (node.matches('[data-im-expansion-trigger] .l-en,[data-im-expansion-trigger] .l-zh')) text = true;
      if (node.matches('[data-im-inspector-origin],[data-im-inspector-enhancement],[data-im-inspector-page],[data-im-inspector-ledger],[data-im-inspector-field],[data-im-inspector-deeper-unavailable]')) attrs.push('hidden');
      if (node.matches('details[data-im-inspector-origin],details[data-im-inspector-ledger],details[data-im-inspector-field]')) attrs.push('open');
      if (node.matches('[data-im-inspector-shell]')) attrs.push('aria-labelledby','aria-label');
      if (node.matches('[data-im-panel][data-view="macro"]')) attrs.push('data-im-macro-has-selection');
      if (node.matches('[data-im-macro-market]')) attrs.push('data-im-macro-selected');
      if (node.matches('[data-im-panel][data-view="risk"]')) attrs.push('data-im-risk-has-selection');
      if (node.matches('[data-im-risk-row]')) attrs.push('data-im-risk-selected');
      if (node.matches('[data-im-risk-channel],[data-im-risk-prompt]')) attrs.push('hidden');
      if (node.matches('[data-im-risk-prompt]')) text = true;
      if (node.matches('[data-im-compare-panel]')) attrs.push('data-im-compare-state','data-im-compare-reason');
      if (node.matches('[data-im-compare-slot],[data-im-compare-cohort],[data-im-compare-controls],[data-im-compare-remove]')) attrs.push('hidden');
      if (node.matches('[data-im-chart-cohort],[data-im-chart-series],[data-im-chart-table-market],[data-im-chart-selection-unavailable]')) attrs.push('hidden');
      if (node.matches('[data-im-compare-status],[data-im-compare-pin] option')) text = true;
      if (node.matches('[data-im-compare-pin] option')) attrs.push('disabled');
      if (node.matches('[data-im-compare-pin]')) value = true;
      return {node:node, attrs:Array.from(new Set(attrs)).map(function (name) {return [name,node.getAttribute(name)];}),
        value:value ? node.value : null, children:text ? Array.from(node.childNodes) : null,
        compareFocus:node === root ? compareFocus(root) : null,
        parent:node.matches('[data-im-library-tool],[data-im-inspector-payload],[data-im-compare-slot]') ? node.parentNode : null, next:node.nextSibling};
    });
  }

  function rememberNodes(controller, snapshot) {
    snapshot.forEach(function (entry) {
      if (!controller.original.some(function (old) { return old.node === entry.node; })) controller.original.push(entry);
    });
  }

  function restoreRoot(root, snapshot) {
    restoreLibraryRows(snapshot.filter(function (entry) { return !!entry.parent; }));
    snapshot.forEach(function (entry) {
      var node = entry.node;
      if (node !== root && node.closest('[data-im-workspace]') !== root) return;
      entry.attrs.forEach(function (attribute) {
        if (attribute[1] === null) node.removeAttribute(attribute[0]);
        else node.setAttribute(attribute[0], attribute[1]);
      });
      if (entry.value !== null) node.value = entry.value;
      if (entry.children !== null) node.replaceChildren.apply(node, entry.children);
    });
    restoreCompareFocus(root,snapshot[0] && snapshot[0].compareFocus);
  }

  function panelValid(panel, config, source, version) {
    if (!['overview', 'compare', 'macro', 'risk', 'history', 'library',
          'scanner', 'dislocations', 'transmission', 'dossier', 'scenario', 'replay', 'coverage'].includes(panel.getAttribute('data-view')) ||
        !config.horizons.includes(panel.getAttribute('data-horizon')) ||
        !config.bases.includes(panel.getAttribute('data-basis')) ||
        !panel.hasAttribute('data-source') || (version === 2 ?
          !validGeneration(source) || panel.getAttribute('data-im-generation') !== source ||
            (['overview','compare','macro','risk','history'].includes(panel.getAttribute('data-view')) && panel.getAttribute('data-return-basis') !== 'price') :
          panel.getAttribute('data-source') !== (source === null ? '' : source))) return false;
    if (panel.hasAttribute('data-market') && panel.getAttribute('data-market') !== '' &&
        !config.markets.includes(panel.getAttribute('data-market'))) return false;
    if (panel.hasAttribute('data-pins')) {
      try {
        var pins = JSON.parse(panel.getAttribute('data-pins'));
        if (!Array.isArray(pins) || pins.length > 4 || new Set(pins).size !== pins.length ||
            pins.some(function (id) { return !config.markets.includes(id); })) return false;
      } catch (_) { return false; }
    }
    return true;
  }

  function panelFor(controller, state) {
    return owned(controller.root, '[data-im-panel]').filter(function (panel) {
      if (!panelValid(panel, controller.config, state.source_reference, controller.bindingVersion) ||
          panel.getAttribute('data-view') !== state.view ||
          panel.getAttribute('data-horizon') !== state.horizon ||
          panel.getAttribute('data-basis') !== state.currency_basis) return false;
      if (panel.hasAttribute('data-market') && (panel.getAttribute('data-market') || null) !== state.selected_market) return false;
      if (panel.hasAttribute('data-pins') && JSON.stringify(JSON.parse(panel.getAttribute('data-pins'))) !== JSON.stringify(state.compare_markets)) return false;
      return true;
    });
  }

  function structuralPanels(controller, source) {
    return new Set(owned(controller.root, '[data-im-panel]').filter(function (panel) {
      return panelValid(panel, controller.config, source, controller.bindingVersion);
    }).map(function (panel) { return panel.getAttribute('data-view'); }));
  }

  function paint(controller, state, issues) {
    var root = controller.root;
    var library = controller.library;
    if (library && panelValid(library.panel,controller.config,state.source_reference,controller.bindingVersion)) {
      library.panel.setAttribute('data-horizon',state.horizon); library.panel.setAttribute('data-basis',state.currency_basis);
    }
    paintHistory(controller,state);
    var panels = panelFor(controller, state);
    var panel = panels.length === 1 ? panels[0] : null;
    var compare = null;
    if (panel && panel.hasAttribute('data-im-history-panel') && !historyPlan(controller,state)) panel=null;
    if (panel && panel.getAttribute('data-view') === 'compare') {
      compare = comparePlan(controller,panel,state);
      if (!compare) panel = null;
    }
    var supported = structuralPanels(controller, state.source_reference);
    owned(root, '[data-im-action]').forEach(function (control) {
      var action = control.getAttribute('data-im-action');
      if (action === 'set_view' && control.tagName === 'BUTTON') {
        control.setAttribute('aria-pressed', String(control.getAttribute('data-im-view') === state.view));
        control.disabled = !supported.has(control.getAttribute('data-im-view'));
      } else if (control.tagName === 'SELECT') {
        var fields = {select_market:'selected_market', set_library_group:'library_group',
          set_view:'view', set_horizon:'horizon', set_basis:'currency_basis'};
        if (fields[action]) control.value = state[fields[action]] === null ? '' : state[fields[action]];
      }
    });
    owned(root, '[data-im-panel]').forEach(function (node) { node.hidden = node !== panel; });
    required(root, '[data-im-unavailable]').hidden = !!panel;
    var reported = issues.slice();
    if (panels.length > 1) reported.unshift({code:'AMBIGUOUS_PANEL', field:'panel'});
    else if (!panel && !reported.length) reported.push({code:supported.has(state.view) ? 'NO_MATCHING_PANEL' : 'UNSUPPORTED_VIEW', field:'panel'});
    required(root, '[data-im-issues]').textContent = reported.length ? textFor(reported, normalLanguage(root)) : '';
    if (panel) {
      owned(root, '[data-im-expanded-region]').filter(function (node) { return panel.contains(node); }).forEach(function (node) { node.hidden = !state.expanded; });
      owned(root, '[data-im-expansion-trigger]').filter(function (node) { return panel.contains(node); }).forEach(function (node) {
        node.hidden = false;
        node.setAttribute('aria-expanded', String(state.expanded));
        node.setAttribute('data-im-expanded', String(!state.expanded));
        var en = node.querySelector('.l-en'), zh = node.querySelector('.l-zh');
        if (en) en.textContent = state.expanded ? 'Collapse all markets' : 'Expand all markets';
        if (zh) zh.textContent = state.expanded ? '收起全部市场' : '展开全部市场';
      });
    }
    owned(root, '[data-im-panel][data-view="macro"]').forEach(function (macroPanel) {
      macroPanel.setAttribute('data-im-macro-has-selection', String(state.selected_market !== null));
      owned(root, '[data-im-macro-market]').filter(function (row) { return macroPanel.contains(row); }).forEach(function (row) {
        row.setAttribute('data-im-macro-selected', String(row.getAttribute('data-im-macro-market') === state.selected_market));
      });
    });
    paintRisk(controller, state);
    paintLibrary(controller,state);
    paintCompare(controller,compare);
    paintInspectorFallbacks(controller,state);
    paintGsMarket(controller, state);
    return reported;
  }

  function scenarioContext(state) {
    return {selected_market:state.selected_market,horizon:state.horizon,currency_basis:state.currency_basis};
  }

  function historyPlan(controller,state) {
    if (!IntlWorkspaceScenario || !controller.scenarioDraft) return null;
    var candidates=owned(controller.root,'[data-im-history-panel]').filter(function (p) {
      return panelValid(p,controller.config,state.source_reference,controller.bindingVersion);
    });
    if (candidates.length!==1) return null;
    var panel=candidates[0];
    function all(selector) { return owned(controller.root,selector).filter(function(n){return n.closest('[data-im-panel]')===panel;}); }
    function one(selector) { var nodes=all(selector);return nodes.length===1?nodes[0]:null; }
    var fields={};
    ['local','fx'].forEach(function(field){fields[field]=one('[data-im-scenario-field="'+field+'"]');});
    var slots=all('[data-im-history-slot]');
    if (slots.length!==controller.config.markets.length || slots.some(function(n,i){return n.getAttribute('data-im-history-slot')!==String(i)||n.getAttribute('data-im-history-market')!==controller.config.markets[i];})) return null;
    var selectors={form:'[data-im-scenario-form]',fieldset:'[data-im-scenario-fields]',tabs:'[data-im-history-tabs]',prompt:'[data-im-history-prompt]',context:'[data-im-scenario-context]',candidate:'[data-im-scenario-candidate-context]',confirm:'[data-im-scenario-confirm-context]',reset:'[data-im-scenario-confirm-reset]',result:'[data-im-scenario-result]',empty:'[data-im-scenario-empty]',usd:'[data-im-scenario-usd]',contribution:'[data-im-scenario-contribution]',rows:'[data-im-scenario-rows]',announcement:'[data-im-scenario-announcement]'};
    var plan={panel:panel,fields:fields,slots:slots,all:all};
    Object.keys(selectors).forEach(function(k){plan[k]=one(selectors[k]);});
    if (Object.keys(selectors).some(function(k){return !plan[k];})||!fields.local||!fields.fx||all('[data-im-scenario-error]').length!==2) return null;
    return plan;
  }

  function scenarioContextText(controller,context) {
    var zh=normalLanguage(controller.root)==='zh';
    var select=owned(controller.root,'[data-im-history-panel] select[data-im-action="select_market"]')[0];
    var option=select&&Array.from(select.options).find(function(o){return o.value===context.selected_market;});
    var market=option?option.getAttribute(zh?'data-im-label-zh':'data-im-label-en'):(context.selected_market||(zh?'未选择市场':'No market selected'));
    var basis=context.currency_basis==='local'?(zh?'研究口径：本币':'Research basis: Local currency'):(zh?'研究口径：美元 · 未对冲':'Research basis: USD · Unhedged');
    return market+' · '+context.horizon+' · '+basis+' · '+(zh?'汇率假设：每单位本币兑美元':'FX assumption: USD per local unit');
  }

  function scenarioNumber(value) {
    // Round only this display; tiny nonzero values must not look like exact zero.
    if (value!==0 && (Math.abs(value)<0.005||Math.abs(value)>=1e9)) return value.toExponential(3);
    return new Intl.NumberFormat('en-US',{maximumFractionDigits:2,minimumFractionDigits:0}).format(value);
  }

  function paintHistory(controller,state,announcement) {
    var plan=historyPlan(controller,state);if(!plan)return;
    var d=controller.scenarioDraft,raw=d.pending?d.pending.raw:d.raw,zh=normalLanguage(controller.root)==='zh';
    plan.all('select[data-im-action="select_market"] option').forEach(function(option){option.textContent=option.getAttribute(zh?'data-im-label-zh':'data-im-label-en');});
    plan.panel.setAttribute('data-horizon',state.horizon);plan.panel.setAttribute('data-basis',state.currency_basis);
    plan.panel.setAttribute('data-im-history-enhanced','true');plan.panel.setAttribute('data-im-history-tab',d.tab);
    plan.tabs.hidden=false;
    plan.all('[data-im-scenario-tab]').forEach(function(n){n.setAttribute('aria-pressed',String(n.getAttribute('data-im-scenario-tab')===d.tab));});
    var selected=controller.config.markets.indexOf(state.selected_market);
    plan.slots.forEach(function(n,i){n.hidden=i!==selected;});plan.prompt.hidden=selected!==-1;
    plan.fieldset.disabled=d.reset_pending;
    plan.context.textContent=scenarioContextText(controller,d.context);
    plan.candidate.textContent=d.pending?scenarioContextText(controller,d.pending.context):'';
    plan.confirm.hidden=!d.pending;plan.reset.hidden=!d.reset_pending;
    var messages={input_required:['Enter a complete percentage.','请输入完整的百分比。'],local_below_total_loss:['Local return must be at least −100%.','本币回报不得低于 −100%。'],fx_nonpositive_endpoint:['Currency return must be greater than −100%.','汇率回报必须大于 −100%。'],overflow:['These assumptions cannot be represented as a finite result.','这些假设无法得出有限数值结果。']};
    ['local','fx'].forEach(function(field){
      var input=plan.fields[field],error=plan.all('[data-im-scenario-error="'+field+'"]')[0];
      if(input.value!==raw[field])input.value=raw[field];
      var message=messages[d.errors[field]]||['Use a decimal point, optional sign and percentage sign; at most 128 characters.','请使用小数点，可带正负号和百分号，最多 128 个字符。'];
      input.setAttribute('aria-invalid',String(!!d.errors[field]));error.hidden=!d.errors[field];error.textContent=d.errors[field]?message[zh?1:0]:'';
    });
    var result=d.pending?null:d.result;
    plan.result.hidden=!result;plan.empty.hidden=!!result||!!d.pending;
    plan.usd.textContent=result?scenarioNumber(result.usdPercent)+'%':'';
    plan.contribution.textContent=result?scenarioNumber(result.fxContributionPp)+(zh?' 个百分点':' pp'):'';
    plan.rows.replaceChildren();
    if(result)d.rows.forEach(function(row){
      var li=controller.root.ownerDocument.createElement('li'),label=controller.root.ownerDocument.createElement('span'),value=controller.root.ownerDocument.createElement('strong');
      var labels={current:['Your FX input','您的汇率输入'],unchanged:['FX unchanged','汇率不变'],illustrative_plus3:['Illustrative FX +3%','示例汇率 +3%']};
      label.textContent=labels[row.kind][zh?1:0]+' ('+scenarioNumber(row.fxPercent)+'%)';value.textContent=scenarioNumber(row.usdPercent)+'%';li.append(label,value);plan.rows.appendChild(li);
    });
    if(announcement&&result)plan.announcement.textContent=(zh?'条件美元回报 ':'Conditional USD return ')+scenarioNumber(result.usdPercent)+'%; '+(zh?'汇率贡献 ':'FX contribution ')+scenarioNumber(result.fxContributionPp)+(zh?' 个百分点':' pp');
    else if(!result)plan.announcement.textContent='';
    plan.all('[data-im-scenario-action="calculate"],[data-im-scenario-action="request_reset"]').forEach(function(n){n.disabled=!!d.pending||d.reset_pending;});
  }

  function commitResearch(controller,result,actionType) {
    if (!controller.scenarioDraft) return stageAndCommit(controller,result.state,result.issues,actionType);
    if (!result.ok) {
      controller.issues=result.issues;repaintIssues(controller);
      return {ok:false,state:controller.state,issues:result.issues,intent:null};
    }
    var prior=controller.scenarioDraft,oldPending=controller.pendingScenario;
    if(oldPending&&actionType!=='resize') {
      paint(controller,controller.state,controller.issues);
      return {ok:false,state:controller.state,issues:[{code:'SCENARIO_CONFIRMATION_REQUIRED',field:'scenario'}],intent:null};
    }
    var current=scenarioContext(controller.state||result.state),next=scenarioContext(result.state);
    if(JSON.stringify(current)!==JSON.stringify(next)) {
      var proposal=IntlWorkspaceScenario.reduceDraft(prior,{type:'propose_context',context:next},normalLanguage(controller.root));
      if(!proposal.ok)return {ok:false,state:controller.state,issues:[{code:'INVALID_ACTION',field:'scenario'}],intent:null};
      controller.scenarioDraft=proposal.draft;
      if(proposal.draft.pending) {
        if(!historyPlan(controller,controller.state)){controller.scenarioDraft=prior;return {ok:false,state:controller.state,issues:[{code:'NO_MATCHING_PANEL',field:'history'}],intent:null};}
        controller.pendingScenario={origin:controller.state,target:result.state,intent:result.intent,originFocus:controller.scenarioOrigin||controller.root.ownerDocument.activeElement};
        controller.scenarioDraft=IntlWorkspaceScenario.reduceDraft(controller.scenarioDraft,{type:'set_tab',tab:'scenario'},normalLanguage(controller.root)).draft;
        var preview=controller.reducer.reduce(controller.state,{type:'set_view',view:'history'});
        var staged=stageAndCommit(controller,preview.state,[],actionType);
        if(!staged.ok){controller.scenarioDraft=prior;controller.pendingScenario=oldPending;return staged;}
        var plan=historyPlan(controller,controller.state);if(plan)plan.fields.local.focus({preventScroll:true});
        return {ok:false,state:controller.state,issues:[{code:'SCENARIO_CONFIRMATION_REQUIRED',field:'scenario'}],intent:null};
      }
    }
    var committed=stageAndCommit(controller,result.state,result.issues,actionType);
    if(!committed.ok){controller.scenarioDraft=prior;controller.pendingScenario=oldPending;}
    return committed;
  }

  function scenarioKeydown(controller,event) {
    if (event.defaultPrevented || !['Escape','Esc'].includes(event.key) ||
        !event.target || event.target.closest('[data-im-workspace]')!==controller.root) return;
    var plan=controller.state&&historyPlan(controller,controller.state);
    if(!plan||plan.panel.hidden||!controller.scenarioDraft)return;
    var action=controller.pendingScenario?'cancel_context':controller.scenarioDraft.reset_pending?'cancel_reset':null;
    if(!action)return;
    event.preventDefault();
    plan.all('[data-im-scenario-action="'+action+'"]')[0].click();
  }

  function scenarioEvent(controller,event) {
    var plan=controller.state&&historyPlan(controller,controller.state);
    if(!plan||plan.panel.hidden||!event.target||!plan.panel.contains(event.target)||event.target.closest('[data-im-workspace]')!==controller.root)return false;
    var command=null;
    if(event.type==='input'&&event.target.hasAttribute('data-im-scenario-field'))command={type:'edit',field:event.target.getAttribute('data-im-scenario-field'),raw:event.target.value};
    else if(event.type==='submit'&&event.target===plan.form)command={type:'calculate'};
    else if(event.type==='click'&&event.target.closest){
      var button=event.target.closest('button[data-im-scenario-action]');
      if(!button||button.disabled||button.closest('[data-im-panel]')!==plan.panel)return false;
      var type=button.getAttribute('data-im-scenario-action');
      // Calculate is handled once by the native form submit event.
      if(type==='calculate')return false;
      command=type==='set_tab'?{type:type,tab:button.getAttribute('data-im-scenario-tab')}:{type:type};
    }
    if(!command)return false;
    event.preventDefault();
    var prior=controller.scenarioDraft,oldPending=controller.pendingScenario,snapshot=snapshotRoot(controller.root);
    try {
      var reduced=IntlWorkspaceScenario.reduceDraft(prior,command,normalLanguage(controller.root));
      controller.scenarioDraft=reduced.draft;
      if(reduced.ok&&['confirm_context','cancel_context'].includes(command.type)) {
        if(!oldPending)throw new Error('Missing pending context');
        var target=command.type==='confirm_context'?oldPending.target:oldPending.origin;
        var committed=stageAndCommit(controller,target,[],'scenario_'+command.type);
        if(!committed.ok){controller.scenarioDraft=prior;restoreRoot(controller.root,snapshot);return true;}
        controller.pendingScenario=null;
        if(command.type==='confirm_context'&&oldPending.intent&&oldPending.intent.type==='restore_focus')restoreFocus(controller,oldPending.intent.anchor_id);
      }
      paintHistory(controller,controller.state,reduced.announce);
      if(reduced.focus)plan.fields[reduced.focus].focus({preventScroll:true});
      else if(command.type==='request_reset'&&reduced.ok)plan.all('[data-im-scenario-action="confirm_reset"]')[0].focus({preventScroll:true});
      else if(['confirm_reset','cancel_reset'].includes(command.type)&&reduced.ok)plan.fields.local.focus({preventScroll:true});
      else if(['confirm_context','cancel_context'].includes(command.type)&&reduced.ok) {
        var origin=command.type==='cancel_context'&&oldPending&&oldPending.originFocus;
        var target=origin&&nodeUsable(controller,origin)?origin:(!plan.panel.hidden?plan.fields.local:required(controller.root,'[data-im-heading]'));
        target.focus({preventScroll:true});
      }
    } catch(_) {
      controller.scenarioDraft=prior;controller.pendingScenario=oldPending;restoreRoot(controller.root,snapshot);
    }
    return true;
  }

  function paintRisk(controller, state) {
    var root = controller.root, markets = controller.config.markets;
    owned(root, '[data-im-panel][data-view="risk"]').forEach(function (panel) {
      var channels = owned(root, '[data-im-risk-channel]').filter(function (node) { return panel.contains(node); });
      var slots = new Set();
      var valid = channels.length === markets.length && channels.every(function (node) {
        var value = node.getAttribute('data-im-risk-channel'), slot = Number(value);
        if (value !== String(slot) || !Number.isInteger(slot) || slot < 0 || slot >= markets.length || slots.has(slot)) return false;
        slots.add(slot);
        return !node.hasAttribute('data-im-risk-market') || node.getAttribute('data-im-risk-market') === markets[slot];
      });
      var selectedSlot = markets.indexOf(state.selected_market);
      panel.setAttribute('data-im-risk-has-selection', String(selectedSlot !== -1));
      channels.forEach(function (node) {
        node.hidden = !valid || selectedSlot === -1 || node.getAttribute('data-im-risk-channel') !== String(selectedSlot);
      });
      owned(root, '[data-im-risk-row]').filter(function (node) { return panel.contains(node); }).forEach(function (node) {
        node.setAttribute('data-im-risk-selected', String(node.getAttribute('data-im-risk-row') === state.selected_market));
      });
      owned(root, '[data-im-risk-prompt]').filter(function (node) { return panel.contains(node); }).forEach(function (node) {
        node.hidden = valid && selectedSlot !== -1;
        var en = root.ownerDocument.createElement('span'), zh = root.ownerDocument.createElement('span');
        en.className = 'l-en'; zh.className = 'l-zh'; zh.lang = 'zh';
        en.textContent = valid ? 'Select a market to examine the currency channel' : 'Currency details are unavailable for this selection.';
        zh.textContent = valid ? '选择市场以查看汇率传导' : '此选择暂无可用的汇率详情。';
        node.replaceChildren(en, zh);
      });
    });
  }

  function riskEvent(controller, event) {
    if (event.type !== 'click' || !event.target || !event.target.closest) return false;
    var button = event.target.closest('button[data-im-risk-close-context]');
    if (!button || button.disabled || button.closest('[data-im-workspace]') !== controller.root) return false;
    var panel = button.closest('[data-im-panel][data-view="risk"]');
    if (!panel || panel.hidden || panelFor(controller, controller.state)[0] !== panel) return false;
    var detail = button.closest('details');
    if (!detail || !panel.contains(detail)) return false;
    var summary = Array.from(detail.children).find(function (node) { return node.tagName === 'SUMMARY'; });
    if (!summary) return false;
    event.preventDefault();
    detail.open = false;
    summary.focus({preventScroll: true});
    return true;
  }

  function repaintIssues(controller) {
    required(controller.root, '[data-im-issues]').textContent = controller.issues.length ? textFor(controller.issues, normalLanguage(controller.root)) : '';
  }

  function urlPath(pathname) {
    return typeof pathname === 'string' && pathname.charAt(0) === '/' && pathname.indexOf('\\') === -1 && pathname.slice(0, 2) !== '//' && !/[\u0000-\u001f\u007f-\u009f]/.test(pathname) ? pathname : '/';
  }

  function anchorHash(location, anchorIds) {
    var raw = location.hash;
    if (!raw) return '';
    var decoded;
    try {
      decoded = decodeURIComponent(raw.charAt(0) === '#' ? raw.slice(1) : raw);
    } catch (error) { return ''; }
    if (decodeURIComponent(encodeURIComponent(decoded)) !== decoded || anchorIds.indexOf(decoded) === -1) return '';
    return '#' + encodeURIComponent(decoded);
  }

  function nextUrl(controller, query) {
    var location = controller.environment.window.location;
    return urlPath(location.pathname) + '?' + query + anchorHash(location, controller.config.anchor_ids);
  }

  /* ---- external query ownership ----
   * Inside a shared-shell frame the child URL carries two transport pairs the page's
   * own strict query vocabulary does not contain. Handing location.search straight to
   * the parser therefore refuses a perfectly good transport-only URL as an invalid
   * business query: it reports "Invalid URL state restored" and silently discards the
   * requested nondefault state. The shell bridge already owns the byte-preserving
   * removal of exactly those two pairs, so the page asks it for a projection of its
   * own current query rather than reproducing - or loosening - that filter here.
   *
   * The provider is BOUND once, at mount, and is never re-acquired. A later
   * replacement, a swapped API object or a cleanup is the loss of a capability, not
   * an invitation to fall back to raw standalone parsing, which would silently accept
   * a query this frame is no longer entitled to project. Identity is re-checked on
   * every read, so a cached method whose instance was retired refuses.
   *
   * "Unavailable" is never an empty query. An empty query is a genuine answer and is
   * returned as "". A bridge that is installed but older, refusing, throwing or
   * returning a non-string is unavailable, not empty; only a page with no bridge at
   * all keeps the ordinary standalone raw validation.
   */
  function bindQuerySource(win) {
    try {
      // Only a genuinely absent namespace without an installation marker is
      // standalone. Cleanup retains the marker; an occupied unusable namespace
      // must not silently grant the page ownership of the shell's raw query.
      if (!('MMXSharedShell' in win) && !win.__MMX_SHARED_BRIDGE_INSTALLED__) {
        return { standalone: true, shell: null, reader: null };
      }
      var shell = win.MMXSharedShell;
      if (!shell || shell.__mmxBridge !== 'mmx.shared-shell.v1') return null;
      var reader = shell.readPageSearch;
      return { standalone: false, shell: shell, reader: typeof reader === 'function' ? reader : null };
    } catch (_) { return null; }
  }

  function externalQuery(controller) {
    try {
      var source = controller.querySource;
      if (!source) return { available: false, query: null };
      var win = controller.environment.window;
      var value;
      if (source.standalone) {
        value = win.location.search;
      } else {
        if (!source.reader || win.MMXSharedShell !== source.shell ||
            source.shell.readPageSearch !== source.reader) {
          return { available: false, query: null };
        }
        value = source.reader.call(source.shell);
      }
      return typeof value === 'string' ? { available: true, query: value } : { available: false, query: null };
    } catch (_) {
      // Property access can throw as well as invocation. Keep the whole read
      // inside this boundary so live popstate can report a status-only refusal.
      return { available: false, query: null };
    }
  }

  function stageAndCommit(controller, state, issues, actionType) {
    var previous = controller.state;
    var snapshot = snapshotRoot(controller.root);
    rememberNodes(controller, snapshot);
    var inspectorSnap = captureLiveInspector(controller);
    var serialized = controller.reducer.serializeQuery(state);
    if (!serialized.ok) return {ok:false, state:previous, issues:serialized.issues, intent:null};
    var shouldPush = !['mount', 'popstate', 'resize'].includes(actionType) && serialized.query !== controller.serializedQuery;
    try {
      var fingerprintChanged = !!(controller.inspector && controller.inspector.contextFingerprint !== inspectorFingerprint(state));
      if (fingerprintChanged) visuallyCloseInspector(controller, { release: true });
      var reported = paint(controller, state, issues);
      if (controller.inspector) applyInspectorMode(controller, controller.inspector.mode, controller.inspector.field, { focus: false });
      if (shouldPush) controller.environment.window.history.pushState(null, '', nextUrl(controller, serialized.query));
      controller.state = state;
      controller.issues = reported;
      controller.serializedQuery = serialized.query;
      return {ok:true, state:state, issues:reported, intent:null};
    } catch (error) {
      restoreRoot(controller.root, snapshot);
      if (inspectorSnap) rehydrateInspector(controller, inspectorSnap);
      if (actionType === 'mount') throw error;
      return {ok:false, state:previous, issues:[{code:'UI_UPDATE_FAILED', field:'workspace'}], intent:null};
    }
  }

  function dispatch(controller, action) {
    if (!controller.live) return destroyedResult();
    var result = controller.reducer.reduce(controller.state, action);
    if (!result.ok) { controller.issues = result.issues; repaintIssues(controller); return result; }
    if (action && action.type === 'replace_source') return { ok: false, state: controller.state, issues: [{ code: 'USE_REPLACE_SOURCE', field: 'source_reference' }], intent: null };
    if (action && action.type === 'set_view' && !structuralPanels(controller, controller.state.source_reference).has(action.view)) {
      controller.issues = [{code:'UNSUPPORTED_VIEW', field:'view'}]; repaintIssues(controller);
      return {ok:false, state:controller.state, issues:controller.issues, intent:null};
    }
    var committed = commitResearch(controller, result, action && action.type);
    if (committed.ok) { committed.intent = result.intent; if (result.intent && result.intent.type === 'restore_focus') restoreFocus(controller, result.intent.anchor_id); }
    return committed;
  }

  function restoreFocus(controller, anchorId) {
    var root = controller.root, win = controller.environment.window;
    var candidate = controller.config.anchor_ids.includes(anchorId) ? owned(root, '[id]').find(function (node) { return node.id === anchorId; }) : null;
    var visible = candidate && !candidate.closest('[hidden]') && candidate.getClientRects().length && win.getComputedStyle(candidate).visibility !== 'hidden';
    var target = visible ? candidate : required(root, '[data-im-heading]');
    target.focus();
  }

  function popstate(controller) {
    if (!controller.live) return;
    // The external read is obtained and its capability verified BEFORE any state,
    // history, inspector, scenario or focus mutation. A refused capability reports
    // the refusal and stops: committed state, serializedQuery, inspector attachment
    // and mode, the scenario draft and pending proposal, the return stack, the
    // baseline and the current focus are all left exactly as they were. The browser
    // has already moved its own location and that location stays as received - this
    // path never sanitizes the URL, commits a history entry or focuses a heading.
    var external = externalQuery(controller);
    if (!external.available) {
      controller.issues = [{ code: 'UI_UPDATE_FAILED', field: 'url' }];
      repaintIssues(controller);
      return;
    }
    var hadInspector = !!controller.inspector;
    if (hadInspector) visuallyCloseInspector(controller, { release: true });
    var parsed = controller.reducer.parseQuery(external.query);
    parsed = clampGsMarket(controller, parsed);
    var committed = commitResearch(controller, parsed, 'popstate');
    // A valid refused Scenario traversal owns its one serialized restoration.
    // Invalid queries stay untouched; GS alignment follows final acceptance.
    if (parsed.ok && controller.pendingScenario) {
      try { controller.environment.window.history.replaceState(null,'',nextUrl(controller,controller.serializedQuery)); }
      catch (_) { committed.issues=[{code:'UI_UPDATE_FAILED',field:'url'}]; }
    } else if (parsed.ok && committed.ok) {
      alignGsMarketUrl(controller, committed, external.query);
    }
    controller.issues = committed.issues;
    if (hadInspector) {
      var heading = owned(controller.root, '[data-im-heading]')[0];
      if (heading && typeof heading.focus === 'function') {
        try { heading.focus(); } catch (_) {}
      }
    }
  }

  function gsMarketSeamPresent(controller) {
    // The X6 element-existence rule governs the surveillance market seam; a
    // page that carries no [data-gs-market] surface at all keeps the incumbent
    // legacy market semantics (history/macro selection never had gs elements).
    return !!controller.root.querySelector('[data-gs-market], [data-gs-market-scope]');
  }

  function gsMarketPresent(controller, marketId) {
    return marketId !== null && /^[A-Z]{2}$/.test(marketId)
      && controller.config.markets.indexOf(marketId) !== -1
      && !!controller.root.querySelector('[data-gs-market="' + marketId + '"]');
  }

  // W2F-X X6: a configured market without document content is not a selection.
  // Clamp state only; the single alignment path below owns any URL correction.
  function clampGsMarket(controller, parsed) {
    if (!parsed.ok || !gsMarketSeamPresent(controller) || parsed.state.selected_market === null) return parsed;
    if (gsMarketPresent(controller, parsed.state.selected_market)) return parsed;
    var cleared = controller.reducer.reduce(parsed.state, { type: 'select_market', market_id: null });
    return cleared.ok ? cleared : parsed;
  }

  function alignGsMarketUrl(controller, parsed, query) {
    try {
      if (!parsed.ok || !gsMarketSeamPresent(controller)) return parsed;
      // This is the already-verified business query. Transport pairs, omitted
      // defaults and alternate encodings of unchanged values are not edits.
      var parts = query.replace(/^\?/, '').split('&');
      for (var index = 0; index < parts.length; index += 1) {
        var separator = parts[index].indexOf('=');
        if (separator < 0) continue;
        var key = parts[index].slice(0, separator);
        if (decodeURIComponent(key.replace(/\+/g, ' ')) !== 'market') continue;
        var value = decodeURIComponent(parts[index].slice(separator + 1).replace(/\+/g, ' '));
        var selected = parsed.state.selected_market || '';
        if (value !== selected) {
          // Preserve every other raw pair and the supplied key encoding. The
          // bridge retains ownership of transport, admission and parent ACKs.
          parts[index] = key + '=' + encodeURIComponent(selected);
          controller.environment.window.history.replaceState(null, '', nextUrl(controller, parts.join('&')));
        }
        break;
      }
    } catch (_) { /* cosmetic URL alignment only; the accepted state stands */ }
    return parsed;
  }

  // W2F-X X6 scope: show only the selected market's child (or the marked
  // default when nothing is selected) and own the selected-market marking.
  function paintGsMarket(controller, state) {
    var root = controller.root;
    var selected = state.selected_market;
    owned(root, '[data-gs-market-scope]').forEach(function (node) {
      var children = Array.from(node.children).filter(function (child) {
        return child.hasAttribute('data-gs-market');
      });
      if (!children.length) return;
      var match = children.find(function (child) { return child.getAttribute('data-gs-market') === selected; }) || null;
      var fallback = children.find(function (child) { return child.hasAttribute('data-gs-market-default'); }) || null;
      var shown = match || fallback || children[0];
      children.forEach(function (child) { child.hidden = child !== shown; });
    });
    owned(root, '[data-gs-market-row]').forEach(function (row) {
      if (selected !== null && row.getAttribute('data-gs-market-row') === selected) row.setAttribute('data-gs-selected', '');
      else row.removeAttribute('data-gs-selected');
    });
    owned(root, '[data-gs-select-market]').forEach(function (link) {
      if (selected !== null && link.getAttribute('data-gs-select-market') === selected) link.setAttribute('aria-current', 'true');
      else link.removeAttribute('aria-current');
    });
  }

  // W2F-X X6 behaviour: one delegated click handler for the market select
  // links. A real <a href="?view=…&market=…">, so middle-click and no-JS still
  // navigate; enhanced clicks set the market and, when the link names a
  // registered view, switch through the existing view-switch path.
  function gsMarketEvent(controller, event) {
    if (event.type !== 'click') return false;
    var link = event.target && event.target.closest ? event.target.closest('a[data-gs-select-market]') : null;
    if (!link || link.disabled || link.closest('[data-im-workspace]') !== controller.root) return false;
    event.preventDefault();
    var marketId = link.getAttribute('data-gs-select-market') || null;
    if (gsMarketPresent(controller, marketId) && marketId !== controller.state.selected_market) {
      dispatch(controller, { type: 'select_market', market_id: marketId });
    }
    var openView = link.getAttribute('data-gs-open');
    if (openView && structuralPanels(controller, controller.state.source_reference).has(openView)
        && openView !== controller.state.view) {
      dispatch(controller, { type: 'set_view', view: openView });
    }
    return true;
  }

  function actionFromEvent(controller, event) {
    if (event.type === 'click') {
      var button = event.target && event.target.closest ? event.target.closest('button[data-im-action]') : null;
      if (!button || button.disabled || button.closest('[data-im-workspace]') !== controller.root || event.target.closest('a,input,textarea,select,[contenteditable]')) return null;
      var type = button.getAttribute('data-im-action');
      if (type === 'set_view') return { type: type, view: button.getAttribute('data-im-view') };
      if (type === 'select_market' || type === 'pin' || type === 'unpin') return { type: type, market_id: button.getAttribute('data-im-market') || null };
      if (type === 'set_horizon') return { type: type, horizon: button.getAttribute('data-im-horizon') };
      if (type === 'set_basis') return { type: type, currency_basis: button.getAttribute('data-im-basis') };
      if (type === 'set_library_group') return { type: type, group_id: button.getAttribute('data-im-group') || null };
      if (type === 'push_return') return { type: type, anchor_id: button.getAttribute('data-im-anchor') || null };
      if (type === 'set_expanded') {
        var expanded = button.getAttribute('data-im-expanded');
        if (expanded !== 'true' && expanded !== 'false') return null;
        return { type: type, expanded: expanded === 'true' };
      }
      if (type === 'capture_baseline' || type === 'back' || type === 'resize') return { type: type };
      return null;
    }
    var select = event.target && event.target.tagName === 'SELECT' && event.target.hasAttribute('data-im-action') ? event.target : null;
    if (!select || select.disabled || select.closest('[data-im-workspace]') !== controller.root) return null;
    var selectAction = select.getAttribute('data-im-action');
    if (selectAction === 'select_market') return { type: selectAction, market_id: select.value === '' ? null : select.value };
    if (selectAction === 'set_library_group') return { type: selectAction, group_id: select.value === '' ? null : select.value };
    var fields = {set_view:'view', set_horizon:'horizon', set_basis:'currency_basis', pin:'market_id', unpin:'market_id', push_return:'anchor_id'};
    if (fields[selectAction]) { var selected = {type:selectAction}; selected[fields[selectAction]] = select.value === '' ? null : select.value; return selected; }
    if (selectAction === 'set_expanded' && ['true','false'].includes(select.value)) return {type:selectAction, expanded:select.value === 'true'};
    return null;
  }

  function clickOrChange(controller, event) {
    if (gsMarketEvent(controller,event)) return;
    if (scenarioEvent(controller,event)) return;
    if (riskEvent(controller,event)) return;
    if (compareEvent(controller,event)) return;
    if (inspectorEvent(controller,event)) return;
    if (libraryEvent(controller,event)) return;
    var action = actionFromEvent(controller, event);
    if (!action) return;
    event.preventDefault();
    var previousGroup=controller.state.library_group;
    controller.scenarioOrigin=event.target;
    var committed;
    try { committed=dispatch(controller, action); } finally { controller.scenarioOrigin=null; }
    if (committed.ok && action.type==='set_library_group' && event.type==='click' && controller.library && controller.library.valid) {
      var library=controller.library, target;
      if (action.group_id) {
        var group=library.groups.find(function (node) { return node.getAttribute('data-im-library-group')===action.group_id; });
        target=group && group.querySelector('h3');
      } else target=library.all('[data-im-library-group-open]').find(function (node) { return node.getAttribute('data-im-group')===previousGroup; });
      if (!target || target.closest('[hidden]') || !target.getClientRects().length) target=library.input;
      target.focus();
    }
  }

  function replaceSource(controller, newSource, expectedSource) {
    if (!controller.live) return destroyedResult();
    if (arguments.length < 3 || expectedSource === undefined) return { ok: false, state: controller.state, issues: [{ code: 'EXPECTED_SOURCE_REQUIRED', field: 'expectedSource' }], intent: null };
    if (!controller.live || expectedSource !== controller.state.source_reference) return { ok: false, state: controller.state, issues: [{ code: 'STALE_SOURCE', field: 'expectedSource' }], intent: null };
    if (controller.bindingVersion === 2 && !validGeneration(newSource)) return { ok: false, state: controller.state, issues: [{ code: 'INVALID_ACTION', field: 'source_reference' }], intent: null };
    var replacement = IntlWorkspaceState.createIntlWorkspaceState(controller.configWithSource(newSource));
    var parsed = replacement.parseQuery(controller.reducer.serializeQuery(controller.state).query);
    if (!parsed.ok) return { ok: false, state: controller.state, issues: parsed.issues, intent: null };
    var expanded = replacement.reduce(parsed.state, { type: 'set_expanded', expanded: controller.state.expanded });
    if (!expanded.ok) return expanded;
    var previousNodes = snapshotRoot(controller.root);
    rememberNodes(controller, previousNodes);
    var inspectorSnap = captureLiveInspector(controller);
    var previousState = controller.state;
    var previousReducer = controller.reducer;
    var previousSerialized = controller.serializedQuery;
    var previousIssues = controller.issues;
    var previousPending = controller.pendingScenario;
    var failed = true;
    try {
      if (controller.inspector) visuallyCloseInspector(controller, { release: true });
      var reported = paint(controller, expanded.state, []);
      controller.reducer = replacement;
      controller.state = expanded.state;
      controller.issues = reported;
      controller.serializedQuery = replacement.serializeQuery(expanded.state).query;
      if (previousPending) {
        var rebound={intent:null,originFocus:previousPending.originFocus};
        ['origin','target'].forEach(function(key) {
          var query=previousReducer.serializeQuery(previousPending[key]);
          var parsedPending=replacement.parseQuery(query.query);
          if (!query.ok||!parsedPending.ok) throw new Error('Pending source rebind failed');
          rebound[key]=parsedPending.state;
        });
        controller.pendingScenario=rebound;
      }
      failed = false;
      return { ok: true, state: expanded.state, issues: reported, intent: { type: 'invalidate_source_bound_context' } };
    } catch (_) {
      return { ok: false, state: previousState, issues: [{ code: 'UI_UPDATE_FAILED', field: 'source_reference' }], intent: null };
    } finally {
      if (failed) {
        controller.reducer = previousReducer;
        controller.state = previousState;
        controller.issues = previousIssues;
        controller.pendingScenario = previousPending;
        controller.serializedQuery = previousSerialized;
        restoreRoot(controller.root, previousNodes);
        if (inspectorSnap) rehydrateInspector(controller, inspectorSnap);
      }
    }
  }

  function mountIntlWorkspace(root, config, environment) {
    if (!environment || typeof environment !== 'object') environment = arguments.length >= 3 ? environment : { window: root.ownerDocument.defaultView };
    if (arguments.length === 2) environment = { window: root.ownerDocument.defaultView };
    if (HANDLES && HANDLES.has(root)) {
      var existing = HANDLES.get(root);
      if (existing) return existing;
    }
    if (!root || root.nodeType !== 1 || !root.hasAttribute('data-im-workspace') || !root.hasAttribute('data-im-mode')) throw new TypeError('IntlWorkspace root must be an Element');
    if (root.getAttribute('data-im-mode') !== 'macro') {
      var refusal = new TypeError('Unsupported International workspace mode');
      refusal.code = 'UNSUPPORTED_MODE';
      throw refusal;
    }
    if (!IntlWorkspaceState || typeof IntlWorkspaceState.createIntlWorkspaceState !== 'function') throw new Error('IntlWorkspaceState API is unavailable');
    var window = environment.window;
    if (!window || !window.history || !window.location || !window.MutationObserver) throw new Error('Workspace environment API is unavailable');
    var reducer = IntlWorkspaceState.createIntlWorkspaceState(config);
    config = JSON.parse(JSON.stringify(config));
    var bindingVersion = workspaceBinding(root, config);
    var sourceConfig = config;
    var configWithSource = function (source) {
      var copy = {};
      var fields = ['markets', 'horizons', 'bases', 'default_horizon', 'default_basis', 'source_reference', 'anchor_ids', 'library_group_ids'];
      for (var index = 0; index < fields.length; index += 1) copy[fields[index]] = fields[index] === 'source_reference' ? source : sourceConfig[fields[index]];
      return copy;
    };
    var controller = {
      root: root, config: config, bindingVersion: bindingVersion, configWithSource: configWithSource, reducer: reducer, environment: { window: window },
      state: null, issues: [], serializedQuery: '', live: false, original: [], inspector: null, scenarioDraft:null, pendingScenario:null, querySource:null
    };
    controller.library = prepareLibrary(root,config);
    controller.inspectorHost = prepareInspector(controller);
    var snapshot = snapshotRoot(root);
    controller.original = snapshot.slice();
    var installed = { listeners: false, popstate: false, observer: null };
    try {
      required(root, '[data-im-heading]').setAttribute('tabindex', '-1');
      required(root, '[data-im-issues]').setAttribute('role', 'status');
      required(root, '[data-im-unavailable]');
      // The shell query provider is bound here, once, and the initial read runs
      // inside the existing mount rollback boundary: an unavailable capability
      // throws into the catch below, which tears the half-installed controller down,
      // restores the pristine snapshot and lets the entry script present its readable
      // fallback. A returned business query is NOT re-interpreted here - the strict
      // parser still owns genuine invalid queries, length bounds and vocabulary.
      controller.querySource = bindQuerySource(window);
      var external = externalQuery(controller);
      if (!external.available) {
        var refusal = new TypeError('International workspace query source is unavailable');
        refusal.code = 'UNAVAILABLE_QUERY_SOURCE';
        throw refusal;
      }
      var parsed = reducer.parseQuery(external.query);
      parsed = alignGsMarketUrl(controller, clampGsMarket(controller, parsed), external.query);
      if (IntlWorkspaceScenario && owned(root,'[data-im-history-panel]').length) controller.scenarioDraft=IntlWorkspaceScenario.createDraft(scenarioContext(parsed.state));
      stageAndCommit(controller, parsed.state, parsed.issues, 'mount', false);
      controller.live = true;
      controller.onClick = function (event) { clickOrChange(controller, event); };
      controller.onChange = function (event) { clickOrChange(controller, event); };
      controller.onScenarioKeydown = function(event) { scenarioKeydown(controller,event); };
      root.addEventListener('keydown',controller.onScenarioKeydown,false);
      controller.onLibraryEvent = function (event) { if (!scenarioEvent(controller,event)) libraryEvent(controller,event); };
      controller.onPopstate = function () { popstate(controller); };
      controller.onResize = function () { dispatch(controller, {type:'resize'}); };
      controller.onInspectorCancel = function (event) { inspectorCancel(controller, event); };
      controller.onInspectorKeydown = function (event) { inspectorEscapeKey(controller, event); };
      controller.onInspectorClose = function (event) { inspectorNativeClose(controller, event); };
      if (controller.inspectorHost && controller.inspectorHost.shell) {
        controller.inspectorHost.shell.addEventListener('cancel', controller.onInspectorCancel, false);
        controller.inspectorHost.shell.addEventListener('keydown', controller.onInspectorKeydown, true);
        controller.inspectorHost.shell.addEventListener('close', controller.onInspectorClose, false);
      }
      root.addEventListener('click', controller.onClick, false);
      root.addEventListener('change', controller.onChange, false);
      ['input','compositionstart','compositionend','submit'].forEach(function (type) { root.addEventListener(type,controller.onLibraryEvent,false); });
      window.addEventListener('popstate', controller.onPopstate, false);
      window.addEventListener('resize', controller.onResize, false);
      controller.observer = new window.MutationObserver(function () {
        repaintIssues(controller);
        paintHistory(controller,controller.state);
        paintLibrary(controller,controller.state);
        var panels = panelFor(controller,controller.state);
        if (panels.length === 1 && !panels[0].hidden) paintCompare(controller,comparePlan(controller,panels[0],controller.state));
        applyInspectorLanguage(controller);
        if (controller.inspector) applyInspectorMode(controller, controller.inspector.mode, controller.inspector.field, { focus: false });
        paintInspectorFallbacks(controller, controller.state);
      });
      controller.observer.observe(window.document.documentElement, { attributes: true, attributeFilter: ['lang'] });
      root.setAttribute('data-im-enhanced', 'true');
      var handle = {
        dispatch: function (action) { return JSON.parse(JSON.stringify(dispatch(controller, action))); },
        getState: function () { return controller.state === null ? null : JSON.parse(JSON.stringify(controller.state)); },
        replaceSource: function (newSource, expectedSource) { return JSON.parse(JSON.stringify(replaceSource(controller, newSource, expectedSource))); },
        openInspector: function (request) { return JSON.parse(JSON.stringify(openInspector(controller, request))); },
        inspectorBack: function () { return JSON.parse(JSON.stringify(inspectorBack(controller))); },
        closeInspector: function () { return JSON.parse(JSON.stringify(closeInspector(controller, {}))); },
        destroy: function () { return destroy(controller); }
      };
      if (!HANDLES) throw new Error('WeakMap is unavailable');
      HANDLES.set(root, handle);
      return handle;
    } catch (error) {
      teardownInspector(controller);
      if (controller.observer) controller.observer.disconnect();
      if (controller.onClick) root.removeEventListener('click', controller.onClick, false);
      if (controller.onChange) root.removeEventListener('change', controller.onChange, false);
      if (controller.onScenarioKeydown) root.removeEventListener('keydown',controller.onScenarioKeydown,false);
      if (controller.onLibraryEvent) ['input','compositionstart','compositionend','submit'].forEach(function (type) { root.removeEventListener(type,controller.onLibraryEvent,false); });
      if (controller.onPopstate) window.removeEventListener('popstate', controller.onPopstate, false);
      if (controller.onResize) window.removeEventListener('resize', controller.onResize, false);
      restoreRoot(root, controller.original);
      throw error;
    }
  }

  function destroy(controller) {
    if (!controller.live) return false;
    controller.live = false;
    teardownInspector(controller);
    controller.state = null;
    controller.scenarioDraft = null;
    controller.pendingScenario = null;
    controller.reducer = null;
    if (controller.observer) controller.observer.disconnect();
    controller.root.removeEventListener('click', controller.onClick, false);
    controller.root.removeEventListener('change', controller.onChange, false);
    controller.root.removeEventListener('keydown',controller.onScenarioKeydown,false);
    ['input','compositionstart','compositionend','submit'].forEach(function (type) { controller.root.removeEventListener(type,controller.onLibraryEvent,false); });
    controller.environment.window.removeEventListener('popstate', controller.onPopstate, false);
    controller.environment.window.removeEventListener('resize', controller.onResize, false);
    HANDLES.delete(controller.root);
    restoreRoot(controller.root, controller.original);
    return true;
  }

  return { mountIntlWorkspace: mountIntlWorkspace };
});
