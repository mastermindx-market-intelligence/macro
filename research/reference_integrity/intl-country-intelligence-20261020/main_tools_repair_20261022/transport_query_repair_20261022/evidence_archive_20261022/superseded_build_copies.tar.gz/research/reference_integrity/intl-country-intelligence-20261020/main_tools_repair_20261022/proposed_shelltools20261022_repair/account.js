/* account.js — the Mastermind user profile / account panel.

   ONE self-contained component shared verbatim by both properties, in two modes:
   • STANDALONE (app.mastermind-x.com) — mounts a 👤 avatar button into the nav
     controls (.mm-nav-ctrls) that opens a frosted-glass pop-up. Identity via the
     same-origin shared SSO cookie.
   • EMBED (macro.mastermind-x.com) — renders INTO the existing settings-gear (⚙)
     Account section (.settings-acct, built by theme.js), replacing its "coming
     soon" placeholder. Identity via the user's Supabase JS bearer token; the app
     API is called cross-origin. theme.js hands us the container via
     window.MMAccount.embed(el); we also self-detect it.

   It injects its own CSS (matched to the design tokens --panel/--line/--link/
   --popover-shadow, with vector-palette fallbacks) and talks ONLY to the
   privileged broker at <MM_API>/api/account/*. No secrets ever live here.

   Config (all optional — the rest is self-discovered from the API):
     window.MM_API        base URL of the app API ('' => same origin). macro sets this.
     window.SUPABASE_CFG  {url, anonKey} for Supabase JS. macro/app both learn it
                          from the API too, so no HTML hardcoding is required.

   Preference sync: when signed in, theme + language changes are saved to the
   account (Supabase user_metadata) and re-applied on load, so a user's look
   follows them to any device/site. Hooks the EXISTING theme.js toggles via the
   `themechange` / `langchange` document events.

   Single owner (site-20 S1 follow-up): once this panel is mounted and holds a
   loaded, signed-in account it is the ONLY writer of the shared `theme` and
   `lang` atomics. theme.js asks `MMAccount.claimsPref(key)` before its own
   `updateUser` save and skips a claimed key; it keeps the browser-only
   `theme_auto` flag, which this panel never writes. One writer per key means an
   acked POST here IS the server copy, and a failed save stays visible as
   `failed` instead of being masked by a second, silent writer. */
(function () {
  'use strict';

  // Same-origin on every mastermind-x.com host — theme.js's /api/me idiom. The app. host
  // has no /api/account routes and sends no CORS headers, so resolving MM_API there left
  // every control on this panel calling a 404 from another origin.
  var API = /(^|\.)mastermind-x\.com$/i.test(location.hostname || '') ? '' : (window.MM_API || '').replace(/\/+$/, '');
  var SUPA = normSupa(window.SUPABASE_CFG);              // may be filled in from the API
  var SDK_URL = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.js';

  var state = { acct: null, loaded: false };
  var _sb = null, _sbLoad = null, _hydrating = false, _prefTimer = null, _mounted = false, _macro = false;
  // Continuity fences (site-20 S1). _loadGen orders account reads; _wgen invalidates every
  // queued/in-flight preference write when the signed-in account changes.
  var _loadGen = 0, _wgen = 0, _soAllBusy = false;
  var _prefPending = {}, _prefOwner = '', _prefFlight = null, _prefState = {};
  var _alertQueued = {}, _alertInflight = {};
  // theme.js applies the signed-in account's saved theme/lang on SIGNED_IN (setTheme/setLang
  // inside the 'mdx-auth' dispatch). Those are not user edits, so they must not echo a save.
  var _authApplying = false;
  // Shared Shell bridge: consulted at call time inside the synchronous event
  // dispatch, never mirrored into a locally-lifted async fence (unlike
  // _authApplying above, which keeps its original SIGNED_IN scope). There is no
  // presented-state prerequisite: the bridge applies the parent's initial
  // context synchronously BEFORE it marks itself presenting, so gating on that
  // flag would leak legacy preference writes during the first apply.
  // Candidate EXISTENCE is the qualified-embed signal — the bridge installs
  // window.MMXSharedShell only behind its parent/frame-generation/referrer
  // guards and deletes it on teardown — and the frozen `applyingContext` getter
  // is true exactly while a bridge invocation of setTheme/setLang is running.
  // No candidate => both helpers falsy => this file behaves exactly as before.
  function _mmShellPresent() {
    try {
      var s = window.MMXSharedShell;
      return !!(s && typeof s.openAuth === 'function');
    } catch (e) { return false; }
  }
  function _mmShellApplying() {
    if (!_mmShellPresent()) return false;
    try { return !!window.MMXSharedShell.applyingContext; } catch (e) { return false; }
  }
  // Pending-pref owner key. /api/account carries the stable Supabase user id, so the
  // fence keys on it; the email is the fallback only when the id is absent.
  function _acctKey(a) {
    if (!(a && a.authenticated)) return '';
    if (a.id) return 'id:' + String(a.id);
    return 'u:' + String(a.email || '').toLowerCase();
  }
  // The key a SIGNED_IN session user resolves to, in the same basis as the loaded
  // account: by id when the account read carried one, else by email.
  function _sessionKey(user, acct) {
    if (!user) return '';
    if (acct && acct.id) return user.id ? 'id:' + String(user.id) : '';
    return user.email ? 'u:' + String(user.email).toLowerCase() : '';
  }
  // The server answers ok:true when only the email_prefs mirror stored a lang
  // (metadata:false). /api/account reads user_metadata back, so that is not a saved pref.
  function _saveOk(res) {
    return !!(res && res.ok && res.data && res.data.ok === true && res.data.metadata !== false);
  }
  function _dropPendingWrites() {
    _wgen++; _prefPending = {}; _prefOwner = ''; _prefFlight = null;
    clearTimeout(_prefTimer); _prefTimer = null;
    for (var k in _alertPrefTimers) clearTimeout(_alertPrefTimers[k]);
    _alertPrefTimers = {}; _alertQueued = {}; _alertInflight = {};
  }
  function _onAuthTransition(user, evt) {
    if (evt !== 'SIGNED_IN' && evt !== 'SIGNED_OUT') return;
    if (evt === 'SIGNED_IN' && !(user && (user.id || user.email))) return;
    var next = (evt === 'SIGNED_IN') ? _sessionKey(user, state.acct) : '';
    if (state.loaded && !state.unavail && _acctKey(state.acct) === next) return;
    _dropPendingWrites(); _loadGen++;
    state.acct = null; state.loaded = false; state.unavail = false;
    if (panel && panel.classList.contains('open')) { render(); load(); } else render();
  }
  function _wireAuthTransitions() {
    if (window.MDXAuth && typeof window.MDXAuth.onChange === 'function') {
      try { window.MDXAuth.onChange(_onAuthTransition); } catch (e) {}
    }
  }
  var _mode = null;                 // 'standalone' | 'embed'
  var _root = null;                 // the element whose innerHTML we render into
  var trigger = null, scrim = null, panel = null;

  // -------------------------------------------------------------- helpers ----
  // `ref` MUST survive this normalisation. It is the project id that pins the session
  // storage key (see sbClient); dropping it here silently re-enables supabase-js's
  // url-derived default, which is the whole bug the pin exists to prevent — and it
  // fails INVISIBLY, because the pin is still there in the source, just fed undefined.
  function normSupa(c) {
    if (!c) return null;
    var url = c.url, key = c.anonKey || c.anon_key;
    return (url && key) ? { url: url, anonKey: key, ref: c.ref || '' } : null;
  }
  function lang() { return document.documentElement.getAttribute('data-lang') || 'en'; }
  function curTheme() { return document.documentElement.getAttribute('data-theme') || 'dark'; }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function E(id) { return document.getElementById(id); }
  function initials(a) {
    var s = (a.name || a.email || '').trim();
    if (!s) return '';
    if (s.indexOf('@') > -1) s = s.split('@')[0];
    var p = s.replace(/[._+-]+/g, ' ').split(/\s+/).filter(Boolean);
    var r = (p[0] || '').charAt(0) + (p.length > 1 ? (p[p.length - 1] || '').charAt(0) : '');
    return (r || s.charAt(0)).toUpperCase();
  }
  function fmtDate(s) {
    if (!s) return '—';
    try { return new Date(s).toLocaleDateString(lang() === 'zh' ? 'zh-CN' : undefined,
      { year: 'numeric', month: 'short', day: 'numeric' }); } catch (e) { return '—'; }
  }
  var PERSON = '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" ' +
    'stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">' +
    '<circle cx="12" cy="8" r="4"/><path d="M4 20c0-3.6 3.6-6 8-6s8 2.4 8 6"/></svg>';

  // -------------------------------------------------------------- i18n -------
  var STR = {
    account: ['Account', '账户'], signed_in: ['Signed in', '已登录'],
    upgrade: ['Upgrade to Pro', '升级到 Pro'], soon: ['Coming soon', '即将推出'],
    pro_blurb: ['The whole desk, the research hub & the Mastermind chat.',
      '完整桌面、研究中心与操盘大脑对话。'],
    see_plans: ['See plans', '查看方案'],
    manage_plan: ['Manage plan', '管理方案'],
    on_plan: ['You’re on ', '当前方案：'],
    on_trial: ['Trial', '试用中'],
    plan_perk: ['Your full desk is unlocked. Manage billing any time.',
      '完整桌面已解锁。可随时管理订阅。'],
    email: ['Email', '邮箱'], no_email: ['No email on file', '尚未绑定邮箱'],
    add_email: ['Add email', '添加邮箱'], change: ['Change', '修改'],
    save: ['Save', '保存'], cancel: ['Cancel', '取消'], saving: ['Saving…', '保存中…'],
    unverified: ['unverified', '未验证'],
    password: ['Password', '密码'], set_pw: ['Set / change password', '设置 / 修改密码'],
    new_pw: ['New password', '新密码'], confirm_pw: ['Confirm password', '确认密码'],
    prefs_synced: ['Theme & language are saved to your account — they follow you wherever you sign in.',
      '主题与语言已保存到账户，登录任意设备都会自动同步。'],
    al_group: ['Alert emails', '提醒邮件'],
    al_master: ['Email me when something I hold changes materially',
      '我持有的资产出现重要变化时，发邮件通知我'],
    al_off: ['Alert emails are off. Nothing will be sent.', '提醒邮件已关闭，不会发送任何邮件。'],
    al_unknown: ["We can't reach your settings right now, so we can't show what's saved. Nothing has changed.",
      '暂时无法读取你的设置，因此无法显示已保存的内容。当前没有任何改动。'],
    al_what: ['What to send', '发送哪些提醒'],
    al_cat_hold: ['A position I hold moves on real news', '我持有的仓位因真实消息出现变动'],
    al_cat_thes: ['A market view I’m watching starts or ends', '我关注的市场观点开始或结束'],
    al_none: ["No alert types chosen yet — you won't get any alert emails.",
      '尚未选择提醒类型 — 你不会收到提醒邮件。'],
    al_tz: ['Your time zone', '你的时区'],
    al_tz_placeholder: ['Not set yet', '尚未设置'],
    al_tz_unset: ['Not saved yet — we are using your browser’s time zone until you pick one.',
      '尚未保存 — 在你选择之前，暂时使用你浏览器的时区。'],
    al_qh: ['Quiet hours', '免打扰时段'],
    al_qh_hint: ['Nothing is sent between these times. Alerts wait and are sent when the window ends.',
      '此时段内不发送。提醒会等待，时段结束后再发送。'],
    al_qh_s: ['Quiet hours start', '免打扰开始时间'],
    al_qh_e: ['Quiet hours end', '免打扰结束时间'],
    al_clear: ['Clear', '清除'],
    al_saved: ['Saved', '已保存'],
    security: ['Security', '安全'], login_method: ['Login method', '登录方式'],
    member_since: ['Member since', '注册于'], last_signin: ['Last sign-in', '上次登录'],
    user_id: ['User ID', '用户 ID'], copy: ['Copy', '复制'], copied: ['Copied', '已复制'],
    sign_out: ['Sign out', '退出登录'], sign_out_all: ['Sign out everywhere', '退出所有设备'],
    danger: ['Danger zone', '危险区域'], delete_acct: ['Request account deletion', '申请删除账户'],
    delete_warn: ['This files a request. Our team then removes your account and its data; nothing is removed the moment you send it.',
      '这会提交一个删除申请。之后由我们的团队删除你的账户及数据；发送申请的当下不会立即删除。'],
    delete_type: ['Type your email to confirm', '输入邮箱以确认'],
    delete_go: ['Send request', '发送申请'],
    del_ok: ['Your request is recorded. Reference {code}. Nothing is removed yet; our team completes it and you keep access until then.',
      '你的请求已记录，参考编号 {code}。目前尚未删除任何内容；之后由我们的团队处理，处理完成前你仍可正常使用。'],
    del_open: ['You already have a deletion request open. Reference {code}.',
      '你已有一个进行中的删除申请，参考编号 {code}。'],
    signin_title: ['Sign in to Mastermind', '登录 Mastermind'],
    signin_sub: ['Sync your watchlist, preferences & account across every Mastermind site.',
      '在所有 Mastermind 站点同步你的自选、偏好与账户。'],
    email_ph: ['you@email.com', 'you@email.com'],
    send_link: ['Email me a sign-in link', '把登录链接发到邮箱'],
    sending: ['Sending…', '发送中…'],
    link_sent: ['📧 Check your email and click the link to finish signing in.',
      '📧 请查收邮件并点击链接完成登录。'],
    pw_ok: ['Password updated.', '密码已更新。'],
    email_ok: ['Email updated.', '邮箱已更新。'],
    email_confirm: ['Confirmation link sent to your new email.', '确认链接已发送到你的新邮箱。'],
    pw_mismatch: ['Passwords don’t match.', '两次输入的密码不一致。'],
    pw_short: ['Use at least 8 characters.', '至少 8 个字符。'],
    err: ['Something went wrong — try again.', '出错了，请重试。'],
    guest_title: ['Access session', '访问会话'],
    guest_sub: ['You’re in with the site access password. Sign in with an account to manage email, password & preferences.',
      '你正通过站点访问密码登录。使用账户登录以管理邮箱、密码与偏好。'],
    acct_unavail_t: ['Can’t load your account right now', '暂时无法加载你的账户'],
    acct_unavail: ['This is a connection problem, not a sign-out. Nothing has changed — try again in a moment.',
      '这是连接问题，并非已退出登录。没有任何改动，请稍后重试。'],
    retry: ['Try again', '重试'],
    so_all_unknown: ['We couldn’t confirm that your other devices were signed out. You’re still signed in here — try again later.',
      '无法确认其他设备已退出登录。你在此设备上仍处于登录状态，请稍后重试。'],
    close: ['Close', '关闭'], loading: ['Loading…', '加载中…']
  };
  function T(k) { var v = STR[k] || ['', '']; return v[lang() === 'zh' ? 1 : 0]; }
  function errText(r) { var d = r.data || {}; return (lang() === 'zh' && d.error_zh) ? d.error_zh : (d.error || T('err')); }

  // ---------------------------------------------------- Supabase JS ----------
  function hasPersisted() {
    try {
      for (var i = 0; i < localStorage.length; i++) {
        var k = localStorage.key(i);
        if (k && /^sb-.*-auth-token$/.test(k)) return true;
      }
    } catch (e) {}
    return false;
  }
  function loadSDK() {
    if (window.supabase && window.supabase.createClient) return Promise.resolve();
    if (_sbLoad) return _sbLoad;
    _sbLoad = new Promise(function (res, rej) {
      var s = document.createElement('script');
      s.src = SDK_URL; s.async = true;
      s.onload = res; s.onerror = function () { rej(new Error('sdk')); };
      document.head.appendChild(s);
    });
    return _sbLoad;
  }
  function sbClient() {
    if (_sb) return Promise.resolve(_sb);
    if (!SUPA) return Promise.resolve(null);
    return loadSDK().then(function () {
      // FLOW NOTE — implicit, NOT pkce (deliberately inconsistent with theme.js,
      // which is pkce). This client is created ONLY on the standalone app
      // (mode 'standalone'); in _macro mode the SDK never loads (see getToken).
      // The only auth this file initiates is a magic-link OTP (onSendLink ->
      // signInWithOtp) — it never calls signInWithOAuth; the OTP return is
      // consumed here via detectSessionInUrl. Implicit is kept ON PURPOSE: under
      // pkce the code_verifier is stored in the requesting browser's localStorage
      // before the email is sent, so a link opened on a DIFFERENT device (the
      // common case for email links) has no verifier and the ?code= exchange
      // fails — switching to pkce would break cross-device magic-link sign-in.
      // theme.js can use pkce because its OAuth return is same-browser.
      //
      // Blast radius of staying implicit: on the standalone app a crafted
      // #access_token= hash IS consumed by detectSessionInUrl, so that property
      // does not get the anti-login-CSRF/fixation guarantee theme.js's pkce
      // client has. The macro dashboard is unaffected (no SDK loads here). The
      // proper fix — pkce + a 6-digit OTP-code fallback for cross-device — must be
      // built and VERIFIED in the standalone app (Terminal) repo, not here. See
      // ACCOUNTS_SETUP.md "Security model".
      // storageKey is PINNED to the project ref, not left to supabase-js's default
      // (which derives it from the url it was handed). Once SUPA.url is a proxy
      // origin (GFW — config.yml watchlist.supabase.browser_url) the default would
      // become `sb-www-auth-token` and this client would stop sharing the session
      // that theme.js COOKIE_STORAGE and app.main both key as `sb-<ref>-auth-token`.
      var _opts = { persistSession: true, autoRefreshToken: true,
        detectSessionInUrl: true, flowType: 'implicit' };
      if (SUPA.ref) _opts.storageKey = 'sb-' + SUPA.ref + '-auth-token';
      _sb = window.supabase.createClient(SUPA.url, SUPA.anonKey, { auth: _opts });
      return _sb;
    });
  }
  async function getToken() {
    // macro: MDXAuth.client is getSupabaseClient (theme.js:1902), which ALWAYS
    // returns a Promise (theme.js:1819-1837). Calling .getSession() on that
    // Promise throws. Await the client, then getSession — the same path
    // theme.js:3709-3711 uses: getSupabaseClient().then(sb => sb.auth.getSession()).
    if (_macro) {
      try {
        if (!(window.MDXAuth && window.MDXAuth.client)) return null;
        const sb = await window.MDXAuth.client();
        const { data } = await sb.auth.getSession();
        return data?.session?.access_token ?? null;
      } catch (e) {
        return null;
      }
    }
    // standalone: use the SDK-backed client.
    if (!SUPA || !hasPersisted()) return null;
    try {
      var standalone = await sbClient();
      if (!standalone) return null;
      var result = await standalone.auth.getSession();
      var session = result && result.data && result.data.session;
      return session ? session.access_token : null;
    } catch (e) {
      return null;
    }
  }

  // ------------------------------------------------------------- API ---------
  // Every panel request is bounded. 30 s is deliberately conservative: a pref save can
  // make up to three sequential Supabase admin calls server-side (6 s each, see
  // app/account_prefs.py) and the browser's own default is far longer. A request that
  // outlives it is aborted and takes the SAME path as a transport failure
  // ({ok:false, status:0}): the account read shows the unavailable state (S1-03), a
  // pending pref/alert write is marked failed and reverted (S1-01/S1-02), and sign-out
  // everywhere reports "not confirmed" (S1-04). Without AbortController the request
  // stays unbounded, exactly as before.
  var API_TIMEOUT_MS = 30000;
  function api(path, opts) {
    opts = opts || {};
    var ctl = (typeof AbortController === 'function') ? new AbortController() : null;
    var timer = null;
    return getToken().then(function (token) {
      var headers = {};
      if (opts.body) headers['Content-Type'] = 'application/json';
      // A null token is lawful on www (cookie carries identity): still send the
      // request with credentials:'include' and no Authorization header.
      if (token) headers['Authorization'] = 'Bearer ' + token;
      if (ctl) timer = setTimeout(function () { ctl.abort(); }, API_TIMEOUT_MS);
      return fetch(API + path, {
        method: opts.method || 'GET', headers: headers, credentials: 'include',
        body: opts.body ? JSON.stringify(opts.body) : undefined,
        signal: ctl ? ctl.signal : undefined
      });
    }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        return { ok: r.ok, status: r.status, data: j };
      });
    }).catch(function () { return { ok: false, status: 0, data: {} }; })
      .then(function (res) { clearTimeout(timer); return res; });
  }
  // An account read is authoritative only as a 2xx JSON object carrying a boolean
  // `authenticated`, or as a 401 (a real anonymous answer). 5xx, network failure and
  // malformed envelopes are UNAVAILABLE — never a guest or account snapshot (S1-03).
  function _classifyAccount(res) {
    if (!res) return null;
    var d = res.data;
    if (res.ok && d && typeof d === 'object' && typeof d.authenticated === 'boolean') return d;
    if (res.status === 401) { var g = (d && typeof d === 'object') ? d : {}; g.authenticated = false; return g; }
    return null;
  }
  function load() {
    var gen = ++_loadGen;
    return api('/api/account').then(function (res) {
      if (gen !== _loadGen) return;
      var a = _classifyAccount(res);
      if (a && !SUPA && a.supabase) SUPA = normSupa(a.supabase);
      if (a && !a.authenticated && SUPA && hasPersisted()) {
        return api('/api/account').then(function (r2) {
          if (gen !== _loadGen) return;
          _settleLoad(_classifyAccount(r2));
        });
      }
      _settleLoad(a);
    });
  }
  function _settleLoad(a) {
    if (!a) { state.acct = null; state.loaded = true; state.unavail = true; render(); return; }
    state.unavail = false;
    if (_prefOwner && _prefOwner !== _acctKey(a)) _dropPendingWrites();
    finishLoad(a);
  }
  function finishLoad(a) {
    state.acct = a; state.loaded = true;
    applyPrefs(a);
    if (a && a.authenticated) {
      api('/api/account/prefs').then(function (res) {
        if (state.acct !== a) return;
        if (res && res.ok && res.data) {
          a.alert_prefs = res.data.prefs || {};
          a.alert_prefs_unset = res.data.unset || [];
        } else {
          a.alert_prefs = {}; a.alert_prefs_unset = ['alert_email_optin'];
        }
        if (_mode === 'standalone') paintTrigger();
        render();
      });
      return;
    }
    if (_mode === 'standalone') paintTrigger();
    render();
  }

  // --------------------------------------------------- preference sync -------
  function applyPrefs(a) {
    if (!a || !a.authenticated || !a.prefs) return;
    // Shared Shell candidate exists: late /api/account prefs must not override
    // the theme or locale the native identity/Settings surface owns — before
    // and after the first parent apply alike; the parent context is
    // authoritative the moment the frame is qualified.
    if (_mmShellPresent()) return;
    _hydrating = true;
    try {
      if (a.prefs.theme && (a.prefs.theme === 'light' || a.prefs.theme === 'dark') &&
          a.prefs.theme !== curTheme() && window.setTheme) window.setTheme(a.prefs.theme);
      var lg = document.documentElement.getAttribute('data-lang') || 'en';
      if (a.prefs.lang && (a.prefs.lang === 'en' || a.prefs.lang === 'zh') &&
          a.prefs.lang !== lg && window.setLang) {
        if (window.MarketMemoryIntent && typeof window.MarketMemoryIntent.applyProfileLanguage === 'function') {
          window.MarketMemoryIntent.applyProfileLanguage(a.prefs.lang, window.setLang);
        } else window.setLang(a.prefs.lang);
      }
    } catch (e) {}
    _hydrating = false;
  }
  // S1-01: theme/lang edits coalesce into ONE pending body owned by the signed-in account,
  // sent single-flight; each field is marked queued -> sent -> acked|failed on the root.
  function _setPrefState(key, s) { _prefState[key] = s; if (_root) _root.setAttribute('data-pref-' + key, s); }
  function persistPref(key, val) {
    if (_hydrating || _authApplying || _mmShellApplying() || !state.acct || !state.acct.authenticated) return;
    var owner = _acctKey(state.acct);
    if (_prefOwner !== owner) { _prefPending = {}; _prefOwner = owner; }
    _prefPending[key] = val; _setPrefState(key, 'queued');
    clearTimeout(_prefTimer);
    _prefTimer = setTimeout(function () { _prefTimer = null; _flushPrefs(); }, 500);
  }
  function _flushPrefs() {
    if (_prefFlight) return;
    var keys = Object.keys(_prefPending); if (!keys.length) return;
    if (_prefOwner !== _acctKey(state.acct)) { _prefPending = {}; return; }
    var body = _prefPending; _prefPending = {};
    var flight = { wg: _wgen, body: body }; _prefFlight = flight;
    keys.forEach(function (k) { _setPrefState(k, 'sent'); });
    api('/api/account/prefs', { method: 'POST', body: body }).then(function (res) {
      if (_prefFlight === flight) _prefFlight = null;
      if (flight.wg !== _wgen) return;
      var ok = _saveOk(res);
      keys.forEach(function (k) { if (!(k in _prefPending)) _setPrefState(k, ok ? 'acked' : 'failed'); });
      if (Object.keys(_prefPending).length && !_prefTimer) _flushPrefs();
    });
  }
  var _alertPrefTimers = {};
  // S1-02: each alert field keeps an immutable submitted value, one request in flight per
  // field, and a write generation. Only the newest intent may drive the UI callbacks; an
  // ack commits its OWN value to the account state; an account change makes old work inert.
  function persistAlertPref(key, val, onOk, onErr) {
    if (_hydrating || !state.acct || !state.acct.authenticated) return;
    _alertQueued[key] = { val: JSON.parse(JSON.stringify(val)), owner: _acctKey(state.acct), wgen: _wgen, onOk: onOk, onErr: onErr };
    clearTimeout(_alertPrefTimers[key]);
    _alertPrefTimers[key] = setTimeout(function () { delete _alertPrefTimers[key]; _sendAlertPref(key); }, 500);
  }
  function _sendAlertPref(key) {
    var job = _alertQueued[key];
    if (!job || _alertInflight[key]) return;
    delete _alertQueued[key];
    if (job.wgen !== _wgen || job.owner !== _acctKey(state.acct)) return;
    _alertInflight[key] = job;
    var body = {}; body[key] = job.val;
    api('/api/account/prefs', { method: 'POST', body: body }).then(function (res) {
      if (_alertInflight[key] === job) delete _alertInflight[key];
      if (job.wgen !== _wgen) return;
      var newer = !!_alertQueued[key];
      if (_saveOk(res)) {
        _ackAlertPref(key, job.val);
        if (!newer) { _syncAlertControl(key, job.val); if (job.onOk) job.onOk(res); }
      }
      else if (!newer && job.onErr) job.onErr(res);
      if (_alertQueued[key] && !_alertPrefTimers[key]) _sendAlertPref(key);
    });
  }
  function _ackAlertPref(key, val) {
    var a = state.acct; if (!a) return;
    var p = a.alert_prefs = a.alert_prefs || {};
    p[key] = (key === 'quiet_hours' && val === 'off') ? null : val;
    var u = a.alert_prefs_unset || []; var i = u.indexOf(key); if (i > -1) u.splice(i, 1);
    a.alert_prefs_unset = u;
    if (key === 'tz') { var sel = E('mmacc-tz'); if (sel) sel.setAttribute('data-prev', val); }
    if (key === 'quiet_hours') {
      var qh = p.quiet_hours, s = E('mmacc-qh-start'), e2 = E('mmacc-qh-end');
      if (s) s.setAttribute('data-prev', (qh && qh.start) || '');
      if (e2) e2.setAttribute('data-prev', (qh && qh.end) || '');
      var g = document.querySelector('.mmacc-alerts'); if (g) g.setAttribute('data-quiet', qh ? 'true' : 'false');
    }
  }
  function _ackedAlerts() { return (state.acct && state.acct.alert_prefs) || {}; }
  // Point the CURRENT control (a close/reopen re-renders it) at a value: the newest acked
  // intent after a save, or the last acked value after a failed one.
  function _syncAlertControl(key, val) {
    if (key === 'tz') { var sel = E('mmacc-tz'); if (sel && val) sel.value = val; return; }
    if (key === 'quiet_hours') {
      var on = !!(val && val !== 'off'), s = E('mmacc-qh-start'), e2 = E('mmacc-qh-end');
      if (s) s.value = on ? val.start : '';
      if (e2) e2.value = on ? val.end : '';
      return;
    }
    if (key === 'alert_email_optin') {
      var b = document.querySelector('[data-act="alert-optin"]');
      if (b) b.setAttribute('aria-checked', val ? 'true' : 'false');
      var g = document.querySelector('.mmacc-alerts');
      if (g) g.setAttribute('data-on', val ? 'true' : 'false');
      var d = E('mmacc-alert-detail');
      if (d) d.classList.toggle('open', !!val);
      return;
    }
    if (key === 'alert_categories') {
      document.querySelectorAll('[data-act="alert-cat"]').forEach(function (c) {
        c.setAttribute('aria-checked', (val || []).indexOf(c.getAttribute('data-cat')) !== -1 ? 'true' : 'false');
      });
    }
  }

  // -------------------------------------------------- section builders -------
  function planCardHTML(a) {
    a = a || {};
    var plansUrl = a.plans_url || '/plans.html';
    var tier = a.tier || 'free';
    var paid = tier !== 'free';            // insider / pro / unlimited => already subscribed
    var trialing = a.status === 'trialing';
    if (paid) {
      // Signed-in on a paid tier: reflect the current plan + a quiet "manage" link.
      var label = a.plan_label || (tier.charAt(0).toUpperCase() + tier.slice(1));
      var badge = trialing
        ? '<span class="mmacc-plan-tag mmacc-plan-trial">' + esc(T('on_trial')) + '</span>'
        : '<span class="mmacc-plan-tag">' + esc(label) + '</span>';
      return '<div class="mmacc-pro-card mmacc-plan-live">' +
          '<div class="mmacc-pro-top"><span class="mmacc-pro-name">✨ ' + esc(label) + '</span>' +
            badge + '</div>' +
          '<div class="mmacc-pro-blurb">' + esc(T('plan_perk')) + '</div>' +
          '<a class="mmacc-btn mmacc-pro-btn" href="' + esc(plansUrl) + '">' + esc(T('manage_plan')) + '</a>' +
        '</div>';
    }
    // Free tier: a live upgrade card that links to the plans page.
    return '<div class="mmacc-pro-card">' +
        '<div class="mmacc-pro-top"><span class="mmacc-pro-name">✨ Pro</span></div>' +
        '<div class="mmacc-pro-blurb">' + esc(T('pro_blurb')) + '</div>' +
        '<a class="mmacc-btn mmacc-pro-btn" href="' + esc(plansUrl) + '">' + esc(T('upgrade')) + '</a>' +
      '</div>';
  }
  function emailGroupHTML(a) {
    var line = a.email
      ? esc(a.email) + (a.email_confirmed ? '' : ' <span class="mmacc-warn">· ' + esc(T('unverified')) + '</span>')
      : '<span class="mmacc-muted">' + esc(T('no_email')) + '</span>';
    return '<div class="mmacc-group">' +
        '<div class="mmacc-glabel">' + esc(T('email')) + '</div>' +
        '<div class="mmacc-line">' +
          '<span class="mmacc-line-v">' + line + '</span>' +
          '<button class="mmacc-mini" data-act="edit-email">' + esc(a.email ? T('change') : T('add_email')) + '</button>' +
        '</div>' +
        '<div class="mmacc-field" id="mmacc-email-field">' +
          '<input type="email" id="mmacc-email-in" class="mmacc-input" autocomplete="email" ' +
            'placeholder="' + esc(T('email_ph')) + '" value="' + esc(a.email || '') + '">' +
          '<div class="mmacc-msg" id="mmacc-email-msg"></div>' +
          '<div class="mmacc-btnrow">' +
            '<button class="mmacc-btn mmacc-ghost" data-act="cancel-email">' + esc(T('cancel')) + '</button>' +
            '<button class="mmacc-btn mmacc-primary" data-act="save-email">' + esc(T('save')) + '</button>' +
          '</div>' +
        '</div>' +
      '</div>';
  }
  function pwGroupHTML() {
    return '<div class="mmacc-group">' +
        '<div class="mmacc-glabel">' + esc(T('password')) + '</div>' +
        '<div class="mmacc-line">' +
          '<span class="mmacc-line-v mmacc-muted">••••••••</span>' +
          '<button class="mmacc-mini" data-act="edit-pw">' + esc(T('set_pw')) + '</button>' +
        '</div>' +
        '<div class="mmacc-field" id="mmacc-pw-field">' +
          '<input type="password" id="mmacc-pw-in" class="mmacc-input" autocomplete="new-password" ' +
            'placeholder="' + esc(T('new_pw')) + '">' +
          '<input type="password" id="mmacc-pw2-in" class="mmacc-input" autocomplete="new-password" ' +
            'placeholder="' + esc(T('confirm_pw')) + '">' +
          '<div class="mmacc-msg" id="mmacc-pw-msg"></div>' +
          '<div class="mmacc-btnrow">' +
            '<button class="mmacc-btn mmacc-ghost" data-act="cancel-pw">' + esc(T('cancel')) + '</button>' +
            '<button class="mmacc-btn mmacc-primary" data-act="save-pw">' + esc(T('save')) + '</button>' +
          '</div>' +
        '</div>' +
        '<div class="mmacc-hint">' + esc(T('prefs_synced')) + '</div>' +
      '</div>';
  }
  var TZ_SHORTLIST = [
    'Asia/Hong_Kong',
    'Asia/Shanghai',
    'Asia/Singapore',
    'Asia/Tokyo',
    'Asia/Seoul',
    'Asia/Kolkata',
    'Asia/Dubai',
    'Europe/London',
    'Europe/Paris',
    'Europe/Berlin',
    'Europe/Zurich',
    'Europe/Moscow',
    'America/New_York',
    'America/Chicago',
    'America/Denver',
    'America/Los_Angeles',
    'America/Sao_Paulo',
    'America/Toronto',
    'Australia/Sydney',
    'Australia/Perth',
    'Pacific/Auckland',
    'Africa/Johannesburg',
    'Asia/Taipei',
    'UTC'
  ];
  function _tzLabel(z) {
    if (!z) return '';
    if (z === 'UTC') return 'UTC';
    var parts = String(z).split('/');
    return parts[parts.length - 1].replace(/_/g, ' ');
  }
  function _tzOptions(current) {
    var zones = (window.Intl && Intl.supportedValuesOf) ? Intl.supportedValuesOf('timeZone') : TZ_SHORTLIST.slice();
    var browserTz = 'UTC';
    try { browserTz = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'; } catch (e) {}
    if (zones.indexOf(browserTz) === -1) zones = [browserTz].concat(zones);
    var sel = current || browserTz;
    return zones.map(function (z) {
      return '<option value="' + esc(z) + '"' + (z === sel ? ' selected' : '') + '>' + esc(_tzLabel(z)) + '</option>';
    }).join('');
  }
  function _applySavedTz(tz) {
    if (!tz) return;
    var sel = E('mmacc-tz');
    if (sel) {
      var found = false;
      for (var i = 0; i < sel.options.length; i++) {
        if (sel.options[i].value === tz) { found = true; break; }
      }
      if (!found) {
        var opt = document.createElement('option');
        opt.value = tz;
        opt.textContent = _tzLabel(tz);
        sel.appendChild(opt);
      }
      sel.value = tz;
      sel.setAttribute('data-prev', tz);
    }
    var hint = document.querySelector('.mmacc-hint-tz');
    if (hint) hint.remove();
  }
  function alertCatRow(cat, label, checked) {
    return '<div class="mmacc-row mmacc-row-toggle"><span class="mmacc-k">' + esc(label) + '</span>' +
      '<button type="button" class="mmacc-switch mmacc-switch-sm" role="switch" ' +
        'aria-checked="' + (checked ? 'true' : 'false') + '" aria-label="' + esc(label) + '" ' +
        'data-act="alert-cat" data-cat="' + cat + '"></button></div>';
  }
  function alertPrefsGroupHTML(p, unset) {
    p = p || {}; unset = unset || [];
    var known = unset.indexOf('alert_email_optin') === -1;
    var on = !!p.alert_email_optin;
    var cats = p.alert_categories || [];
    var qh = p.quiet_hours || null;
    var tzKnown = unset.indexOf('tz') === -1;
    var tz = tzKnown ? p.tz : null;
    var state = known ? 'known' : 'unknown';
    return '<div class="mmacc-group mmacc-alerts" data-on="' + (on ? 'true' : 'false') + '" ' +
        'data-state="' + state + '" data-quiet="' + (qh ? 'true' : 'false') + '">' +
        '<div class="mmacc-glabel">' + esc(T('al_group')) + '</div>' +
        '<div class="mmacc-row mmacc-row-toggle">' +
          '<span class="mmacc-k mmacc-k-lead">' + esc(T('al_master')) + '</span>' +
          '<button type="button" class="mmacc-switch" role="switch" aria-checked="' + (on ? 'true' : 'false') + '" ' +
            'aria-label="' + esc(T('al_master')) + '" data-act="alert-optin"></button>' +
        '</div>' +
        (!known ? '<div class="mmacc-hint mmacc-hint-unknown">' + esc(T('al_unknown')) + '</div>' :
          (!on ? '<div class="mmacc-hint mmacc-hint-off">' + esc(T('al_off')) + '</div>' : '')) +
        '<div class="mmacc-field mmacc-alert-detail' + (on ? ' open' : '') + '" id="mmacc-alert-detail">' +
          '<div class="mmacc-sublabel">' + esc(T('al_what')) + '</div>' +
          alertCatRow('holdings_material_change', T('al_cat_hold'), cats.indexOf('holdings_material_change') !== -1) +
          alertCatRow('thesis_window', T('al_cat_thes'), cats.indexOf('thesis_window') !== -1) +
          (cats.length === 0 ? '<div class="mmacc-hint mmacc-hint-none">' + esc(T('al_none')) + '</div>' : '') +
          '<div class="mmacc-sublabel">' + esc(T('al_tz')) + '</div>' +
          '<select class="mmacc-input mmacc-select" id="mmacc-tz" data-act="alert-tz" data-prev="' + esc(tz || '') + '" aria-label="' + esc(T('al_tz')) + '">' + _tzOptions(tz) + '</select>' +
          (!tzKnown ? '<div class="mmacc-hint mmacc-hint-tz">' + esc(T('al_tz_unset')) + '</div>' : '') +
          '<div class="mmacc-sublabel">' + esc(T('al_qh')) + '</div>' +
          '<div class="mmacc-timepair">' +
            '<input type="time" class="mmacc-input mmacc-time" id="mmacc-qh-start" aria-label="' + esc(T('al_qh_s')) + '" ' +
              'data-act="alert-qh" data-prev="' + esc((qh && qh.start) || '') + '" value="' + esc((qh && qh.start) || '') + '">' +
            '<span class="mmacc-timesep">\u2192</span>' +
            '<input type="time" class="mmacc-input mmacc-time" id="mmacc-qh-end" aria-label="' + esc(T('al_qh_e')) + '" ' +
              'data-act="alert-qh" data-prev="' + esc((qh && qh.end) || '') + '" value="' + esc((qh && qh.end) || '') + '">' +
            '<button type="button" class="mmacc-mini" data-act="alert-qh-clear">' + esc(T('al_clear')) + '</button>' +
          '</div>' +
          '<div class="mmacc-hint">' + esc(T('al_qh_hint')) + '</div>' +
          '<div class="mmacc-msg" id="mmacc-alert-msg"></div>' +
        '</div>' +
      '</div>';
  }
  function infoRow(k, v) {
    return '<div class="mmacc-row"><span class="mmacc-k">' + esc(k) + '</span>' +
      '<span class="mmacc-v">' + v + '</span></div>';
  }
  function securityGroupHTML(a) {
    var chips = (a.providers || []).map(function (p) {
      return '<span class="mmacc-chip">' + esc(p) + '</span>'; }).join('');
    return '<div class="mmacc-group">' +
        '<div class="mmacc-glabel">' + esc(T('security')) + '</div>' +
        infoRow(T('login_method'), '<span class="mmacc-chips">' + chips + '</span>') +
        infoRow(T('member_since'), esc(fmtDate(a.created_at))) +
        infoRow(T('last_signin'), esc(fmtDate(a.last_sign_in_at))) +
        '<div class="mmacc-row"><span class="mmacc-k">' + esc(T('user_id')) + '</span>' +
          '<button class="mmacc-mini" data-act="copy-id">' + esc(T('copy')) + '</button></div>' +
        '<div class="mmacc-msg" id="mmacc-signout-msg" role="status"></div>' +
        '<div class="mmacc-btnrow mmacc-btnrow-wide">' +
          '<button class="mmacc-btn mmacc-ghost" data-act="signout">' + esc(T('sign_out')) + '</button>' +
          '<button class="mmacc-btn mmacc-ghost" data-act="signout-all">' + esc(T('sign_out_all')) + '</button>' +
        '</div>' +
      '</div>';
  }
  function dangerGroupHTML() {
    return '<div class="mmacc-group mmacc-danger">' +
        '<div class="mmacc-glabel mmacc-glabel-danger">' + esc(T('danger')) + '</div>' +
        '<div class="mmacc-line">' +
          '<span class="mmacc-line-v mmacc-muted">' + esc(T('delete_warn')) + '</span>' +
          '<button class="mmacc-mini mmacc-mini-danger" data-act="show-delete">' + esc(T('delete_acct')) + '</button>' +
        '</div>' +
        '<div class="mmacc-field" id="mmacc-del-field">' +
          '<input type="email" id="mmacc-del-in" class="mmacc-input" placeholder="' + esc(T('delete_type')) + '">' +
          '<div class="mmacc-msg" id="mmacc-del-msg"></div>' +
          '<div class="mmacc-btnrow">' +
            '<button class="mmacc-btn mmacc-ghost" data-act="cancel-delete">' + esc(T('cancel')) + '</button>' +
            '<button class="mmacc-btn mmacc-danger-btn" data-act="do-delete">' + esc(T('delete_go')) + '</button>' +
          '</div>' +
        '</div>' +
      '</div>';
  }
  function signinFormHTML() {
    return '<div class="mmacc-group mmacc-signin">' +
        '<div class="mmacc-signin-title">' + esc(T('signin_title')) + '</div>' +
        '<div class="mmacc-signin-sub">' + esc(T('signin_sub')) + '</div>' +
        '<input type="email" id="mmacc-signin-in" class="mmacc-input" autocomplete="email" ' +
          'placeholder="' + esc(T('email_ph')) + '">' +
        '<div class="mmacc-msg" id="mmacc-signin-msg"></div>' +
        '<button class="mmacc-btn mmacc-primary mmacc-block" data-act="send-link">' + esc(T('send_link')) + '</button>' +
      '</div>';
  }
  function guestNoteHTML() {
    return '<div class="mmacc-group">' +
        '<div class="mmacc-signin-title">' + esc(T('guest_title')) + '</div>' +
        '<div class="mmacc-signin-sub">' + esc(T('guest_sub')) + '</div>' +
      '</div>';
  }
  function bodySignedIn(a) {
    var ap = (a && a.alert_prefs) || {}; var unset = (a && a.alert_prefs_unset) || [];
    return planCardHTML(a) + emailGroupHTML(a) + pwGroupHTML() + alertPrefsGroupHTML(ap, unset) +
      securityGroupHTML(a) + dangerGroupHTML();
  }
  function bodySignedOut(a) {
    if (_macro) return guestNoteHTML();   // macro: sign-in lives in the ⚙ gear, not here
    return (SUPA || (a && a.supabase)) ? signinFormHTML() : guestNoteHTML();
  }

  // ------------------------------------------------- mode-specific shells ----
  function profileStripHTML(a, withClose) {
    var provLabel = a.provider_label || (a.providers || []).join(' · ') || 'Email';
    return '<div class="mmacc-head">' +
        '<div class="mmacc-ava">' + (initials(a) ? esc(initials(a)) : PERSON) + '</div>' +
        '<div class="mmacc-idbox">' +
          '<div class="mmacc-name">' + esc(a.name || a.email || T('account')) + '</div>' +
          '<div class="mmacc-sub">' + esc(T('signed_in')) + ' · ' + esc(provLabel) + '</div>' +
        '</div>' +
        '<span class="mmacc-plan-pill">' + esc(a.plan_label || 'Free') + '</span>' +
        (withClose ? '<button class="mmacc-x" data-act="close" aria-label="' + esc(T('close')) + '">✕</button>' : '') +
      '</div>';
  }
  function panelHTML(a) {
    a = a || {};
    if (!state.loaded) return '<div class="mmacc-body"><div class="mmacc-loading">' + esc(T('loading')) + '</div></div>';
    if (a.authenticated) {
      return profileStripHTML(a, true) + '<div class="mmacc-body">' + bodySignedIn(a) + '</div>';
    }
    return '<div class="mmacc-head mmacc-head-out">' +
        '<div class="mmacc-idbox"><div class="mmacc-name">' + esc(T('account')) + '</div></div>' +
        '<button class="mmacc-x" data-act="close" aria-label="' + esc(T('close')) + '">✕</button>' +
      '</div><div class="mmacc-body">' + (state.unavail ? unavailHTML() : bodySignedOut(a)) + '</div>';
  }
  // S1-03: the account could not be read. Not a sign-out; offer one explicit retry.
  function unavailHTML() {
    return '<div class="mmacc-group" data-acct-state="unavailable" role="status">' +
        '<div class="mmacc-signin-title">' + esc(T('acct_unavail_t')) + '</div>' +
        '<div class="mmacc-signin-sub">' + esc(T('acct_unavail')) + '</div>' +
        '<div class="mmacc-btnrow"><button type="button" class="mmacc-btn mmacc-ghost" data-act="retry-load">' +
          esc(T('retry')) + '</button></div>' +
      '</div>';
  }
  function onRetryLoad() { state.loaded = false; state.unavail = false; render(); load(); }
  function embedHTML(a) {
    a = a || {};
    if (!state.loaded) return '<div class="mmacc-loading">' + esc(T('loading')) + '</div>';
    if (state.unavail) return '<div class="mmacc-embed">' + unavailHTML() + '</div>';
    if (a.authenticated) return '<div class="mmacc-embed">' + profileStripHTML(a, false) + bodySignedIn(a) + '</div>';
    return '<div class="mmacc-embed">' + bodySignedOut(a) + '</div>';
  }
  function render() {
    if (!_root) return;
    _root.innerHTML = (_mode === 'embed') ? embedHTML(state.acct) : panelHTML(state.acct);
  }

  // ------------------------------------------------------------- actions -----
  function showField(id, show) { var f = E(id); if (f) f.classList.toggle('open', show !== false); }
  function setMsg(id, text, kind) {
    var m = E(id); if (!m) return;
    m.textContent = text || '';
    m.className = 'mmacc-msg' + (text ? ' show' : '') + (kind ? ' ' + kind : '');
  }
  function busy(btn, on, label) {
    if (!btn) return;
    if (on) { btn._t = btn.textContent; btn.disabled = true; if (label) btn.textContent = label; }
    else { btn.disabled = false; if (btn._t != null) btn.textContent = btn._t; }
  }
  function onSaveEmail(btn) {
    var v = (E('mmacc-email-in').value || '').trim();
    setMsg('mmacc-email-msg', ''); busy(btn, true, T('saving'));
    api('/api/account/email', { method: 'POST', body: { email: v } }).then(function (r) {
      busy(btn, false);
      if (r.ok && r.data.ok) {
        setMsg('mmacc-email-msg', r.data.confirmation_required ? T('email_confirm') : T('email_ok'), 'ok');
        setTimeout(load, 500);
      } else setMsg('mmacc-email-msg', errText(r), 'bad');
    });
  }
  function onSavePw(btn) {
    var p1 = E('mmacc-pw-in').value || '', p2 = E('mmacc-pw2-in').value || '';
    if (p1.length < 8) { setMsg('mmacc-pw-msg', T('pw_short'), 'bad'); return; }
    if (p1 !== p2) { setMsg('mmacc-pw-msg', T('pw_mismatch'), 'bad'); return; }
    setMsg('mmacc-pw-msg', ''); busy(btn, true, T('saving'));
    api('/api/account/password', { method: 'POST', body: { password: p1 } }).then(function (r) {
      busy(btn, false);
      if (r.ok && r.data.ok) {
        setMsg('mmacc-pw-msg', T('pw_ok'), 'ok');
        E('mmacc-pw-in').value = ''; E('mmacc-pw2-in').value = '';
        setTimeout(function () { showField('mmacc-pw-field', false); }, 1100);
      } else setMsg('mmacc-pw-msg', errText(r), 'bad');
    });
  }
  function onDelete(btn) {
    var v = (E('mmacc-del-in').value || '').trim();
    setMsg('mmacc-del-msg', ''); busy(btn, true, T('saving'));
    api('/api/account/delete', { method: 'POST', body: { confirm: v } }).then(function (r) {
      busy(btn, false);
      if (r.ok && r.data.ok) {
        // The control FILES a request; it deletes nothing, so it must not sign the reader
        // out. Report the reference they will quote to support, then fold the field away
        // exactly the way onSavePw does.
        var key = r.data.already_open ? 'del_open' : 'del_ok';
        var code = (r.data.receipt && r.data.receipt.receipt_code) || '';
        setMsg('mmacc-del-msg', T(key).replace('{code}', code), 'ok');
        var ci = E('mmacc-del-in'); if (ci) ci.value = '';
        setTimeout(function () { showField('mmacc-del-field', false); }, 1100);
      } else setMsg('mmacc-del-msg', errText(r), 'bad');
    });
  }
  function onSendLink(btn) {
    var v = (E('mmacc-signin-in').value || '').trim();
    if (!v) return;
    setMsg('mmacc-signin-msg', ''); busy(btn, true, T('sending'));
    sbClient().then(function (sb) {
      if (!sb) throw new Error('no-supabase');
      return sb.auth.signInWithOtp({ email: v,
        options: { shouldCreateUser: true, emailRedirectTo: location.href.split('#')[0] } });
    }).then(function (res) {
      busy(btn, false);
      if (res && res.error) setMsg('mmacc-signin-msg', res.error.message || T('err'), 'bad');
      else setMsg('mmacc-signin-msg', T('link_sent'), 'ok');
    }).catch(function () { busy(btn, false); setMsg('mmacc-signin-msg', T('err'), 'bad'); });
  }
  function copyId() {
    var id = state.acct && state.acct.id; if (!id) return;
    var done = function () {
      var b = _root && _root.querySelector('[data-act="copy-id"]'); if (!b) return;
      var t = b.textContent; b.textContent = T('copied');
      setTimeout(function () { b.textContent = t; }, 1400);
    };
    if (navigator.clipboard) navigator.clipboard.writeText(id).then(done, done); else done();
  }
  function clearSharedCookie() {
    try {
      var parts = location.hostname.split('.');
      var base = parts.length >= 2 ? parts.slice(-2).join('.') : location.hostname;
      document.cookie.split(';').forEach(function (c) {
        var name = c.split('=')[0].trim();
        if (/^sb-.*-auth-token(\.\d+)?$/.test(name)) {
          document.cookie = name + '=; Max-Age=0; path=/; domain=.' + base;
          document.cookie = name + '=; Max-Age=0; path=/';
        }
      });
    } catch (e) {}
  }
  function doSignOut() {
    _dropPendingWrites();
    if (_macro && window.MDXAuth && window.MDXAuth.signOut) {
      try { window.MDXAuth.signOut(); } catch (e) {}   // let the gear's auth own sign-out
      close(); return;
    }
    var fin = function () {
      clearSharedCookie();
      if (API === '') location.href = '/logout';   // app: also clears mm_session
      else location.reload();                        // macro: back to signed-out
    };
    if (SUPA && hasPersisted()) sbClient().then(function (sb) { return sb.auth.signOut(); }).then(fin, fin);
    else fin();
  }
  // S1-04: only an authoritative {ok:true} reply is a global sign-out. A server error, a
  // transport failure or an unreadable reply leaves this device signed in and says the
  // other devices are unconfirmed; there is no automatic retry.
  function doSignOutAll() {
    if (_soAllBusy) return;
    _soAllBusy = true;
    api('/api/account/signout-everywhere', { method: 'POST' }).then(function (r) {
      _soAllBusy = false;
      if (r.ok && r.data && r.data.ok === true) { doSignOut(); return; }
      if (r.data && r.data.error) { setMsg('mmacc-signout-msg', errText(r), 'bad'); return; }
      setMsg('mmacc-signout-msg', T('so_all_unknown'), 'bad');
    }, function () { _soAllBusy = false; setMsg('mmacc-signout-msg', T('so_all_unknown'), 'bad'); });
  }
  function _alertErr(res) {
    if (res && res.status === 0) { _alertGroupState(false); setMsg('mmacc-alert-msg', T('al_unknown'), 'bad'); return; }
    var detail = res && res.data && res.data.detail;
    if (detail && typeof detail === 'object') {
      setMsg('mmacc-alert-msg', (lang() === 'zh' ? detail.zh : detail.en) || T('err'), 'bad');
    } else {
      setMsg('mmacc-alert-msg', T('err'), 'bad');
    }
  }
  function _alertGroupState(known) {
    var g = document.querySelector('.mmacc-alerts'); if (!g) return;
    g.setAttribute('data-state', known ? 'known' : 'unknown');
  }
  function onAlertOptin(btn) {
    var was = btn.getAttribute('aria-checked') === 'true';
    var next = !was;
    btn.setAttribute('aria-checked', next ? 'true' : 'false');
    var g = btn.closest('.mmacc-alerts');
    if (g) g.setAttribute('data-on', next ? 'true' : 'false');
    var detail = E('mmacc-alert-detail');
    if (detail) detail.classList.toggle('open', next);
    persistAlertPref('alert_email_optin', next, function (res) {
      var prefs = (res && res.data && res.data.prefs) || {};
      if (next && prefs.tz && !_alertQueued.tz && !_alertInflight.tz) { _ackAlertPref('tz', prefs.tz); _applySavedTz(prefs.tz); }
      setMsg('mmacc-alert-msg', T('al_saved'), 'ok');
    }, function (res) {
      _syncAlertControl('alert_email_optin', !!_ackedAlerts().alert_email_optin);
      _alertErr(res);
    });
  }
  function onAlertCat(btn) {
    var was = btn.getAttribute('aria-checked') === 'true';
    var next = !was;
    btn.setAttribute('aria-checked', next ? 'true' : 'false');
    var cats = [];
    document.querySelectorAll('[data-act="alert-cat"]').forEach(function (b) {
      if (b.getAttribute('aria-checked') === 'true') cats.push(b.getAttribute('data-cat'));
    });
    persistAlertPref('alert_categories', cats, function () {
      setMsg('mmacc-alert-msg', T('al_saved'), 'ok');
    }, function (res) {
      _syncAlertControl('alert_categories', _ackedAlerts().alert_categories || []);
      _alertErr(res);
    });
  }
  function onAlertTz(sel) {
    persistAlertPref('tz', sel.value, function () {
      setMsg('mmacc-alert-msg', T('al_saved'), 'ok');
    }, function (res) {
      var cur = E('mmacc-tz'), pv = cur && cur.getAttribute('data-prev');
      if (cur && pv) cur.value = pv;
      _alertErr(res);
    });
  }
  function _sendQuietHours() {
    var s = E('mmacc-qh-start'), e2 = E('mmacc-qh-end');
    var sv = (s && s.value) || '', ev = (e2 && e2.value) || '';
    var payload = (!sv || !ev || sv === ev) ? 'off' : { start: sv, end: ev };
    persistAlertPref('quiet_hours', payload, function () {
      setMsg('mmacc-alert-msg', T('al_saved'), 'ok');
    }, function (res) {
      var s1 = E('mmacc-qh-start'), e1 = E('mmacc-qh-end');
      if (s1) s1.value = s1.getAttribute('data-prev') || '';
      if (e1) e1.value = e1.getAttribute('data-prev') || '';
      _alertErr(res);
    });
  }
  function onAlertQhClear() {
    var s = E('mmacc-qh-start'), e2 = E('mmacc-qh-end');
    if (s) s.value = ''; if (e2) e2.value = '';
    _sendQuietHours();
  }
  function onChange(e) {
    var t = e.target; var act = t.getAttribute && t.getAttribute('data-act'); if (!act) return;
    if (act === 'alert-tz') return onAlertTz(t);
    if (act === 'alert-qh') return _sendQuietHours();
  }
  function onClick(e) {
    var b = e.target.closest('[data-act]'); if (!b) return;
    switch (b.getAttribute('data-act')) {
      case 'close': return close();
      case 'retry-load': return onRetryLoad();
      case 'alert-optin': return onAlertOptin(b);
      case 'alert-cat': return onAlertCat(b);
      case 'alert-qh-clear': return onAlertQhClear();
      case 'edit-email': showField('mmacc-email-field'); var ei = E('mmacc-email-in'); if (ei) ei.focus(); return;
      case 'cancel-email': showField('mmacc-email-field', false); setMsg('mmacc-email-msg', ''); return;
      case 'save-email': return onSaveEmail(b);
      case 'edit-pw': showField('mmacc-pw-field'); var pi = E('mmacc-pw-in'); if (pi) pi.focus(); return;
      case 'cancel-pw': showField('mmacc-pw-field', false); setMsg('mmacc-pw-msg', ''); return;
      case 'save-pw': return onSavePw(b);
      case 'copy-id': return copyId();
      case 'signout': return doSignOut();
      case 'signout-all': return doSignOutAll();
      case 'show-delete': showField('mmacc-del-field'); var di = E('mmacc-del-in'); if (di) di.focus(); return;
      case 'cancel-delete': showField('mmacc-del-field', false); setMsg('mmacc-del-msg', ''); return;
      case 'do-delete': return onDelete(b);
      case 'send-link': return onSendLink(b);
    }
  }

  // ----------------------------------------------------- standalone panel ----
  function paintTrigger() {
    if (!trigger) return;
    var a = state.acct || {};
    if (a.authenticated) {
      var ini = initials(a);
      trigger.innerHTML = ini ? esc(ini) : PERSON;
      trigger.classList.toggle('mmacc-trigger-ini', !!ini);
      trigger.classList.add('mmacc-trigger-on');
      trigger.setAttribute('aria-label', a.name || a.email || T('account'));
    } else {
      trigger.innerHTML = PERSON;
      trigger.classList.remove('mmacc-trigger-ini', 'mmacc-trigger-on');
      trigger.setAttribute('aria-label', T('account'));
    }
  }
  function open() {
    if (!state.loaded || state.unavail) { state.loaded = false; state.unavail = false; render(); load(); } else render();
    scrim.classList.add('open'); panel.classList.add('open');
    document.addEventListener('keydown', onEsc);
  }
  function close() {
    if (_mode !== 'standalone') return;
    scrim.classList.remove('open'); panel.classList.remove('open');
    document.removeEventListener('keydown', onEsc);
  }
  function onEsc(e) { if (e.key === 'Escape') close(); }

  // ----------------------------------------------------------- mounting ------
  function injectCSS() {
    if (document.getElementById('mmacc-css')) return;
    var st = document.createElement('style'); st.id = 'mmacc-css'; st.textContent = CSS;
    document.head.appendChild(st);
  }
  function wirePrefSync() {
    // window is the target of 'mdx-auth', so this capture listener runs before every bubble
    // listener there, theme.js's server-pref apply included, whatever the load order. The
    // apply is synchronous inside the dispatch; a microtask lifts the fence after it.
    if (window.addEventListener) {
      window.addEventListener('mdx-auth', function (e) {
        var d = e && e.detail;
        if (!(d && d.event === 'SIGNED_IN' && d.user)) return;
        _authApplying = true;
        Promise.resolve().then(function () { _authApplying = false; });
      }, true);
    }
    document.addEventListener('themechange', function (e) { persistPref('theme', e.detail || curTheme()); });
    document.addEventListener('langchange', function (e) {
      persistPref('lang', e.detail || lang());
      render();
    });
  }
  function mountStandalone() {
    if (_mounted) return;
    var host = document.querySelector('.mm-nav-ctrls, .nav-ctrls');
    if (!host) return;
    _mounted = true; _mode = 'standalone';
    injectCSS();
    trigger = document.createElement('button');
    trigger.type = 'button'; trigger.id = 'mmacc-trigger'; trigger.className = 'mmacc-trigger';
    trigger.setAttribute('aria-label', T('account')); trigger.innerHTML = PERSON;
    trigger.addEventListener('click', function (e) { e.stopPropagation(); panel.classList.contains('open') ? close() : open(); });
    host.appendChild(trigger);
    scrim = document.createElement('div'); scrim.className = 'mmacc-scrim';
    scrim.addEventListener('click', close);
    panel = document.createElement('div'); panel.className = 'mmacc';
    panel.setAttribute('role', 'dialog'); panel.setAttribute('aria-label', T('account'));
    panel.addEventListener('click', onClick);
    panel.addEventListener('change', onChange, true);
    document.body.appendChild(scrim); document.body.appendChild(panel);
    _root = panel;
    wirePrefSync();
    var warm = function () { load(); };
    if (window.requestIdleCallback) requestIdleCallback(warm, { timeout: 1500 }); else setTimeout(warm, 400);
  }
  function mountEmbed(el) {
    if (_mounted || !el) return;
    _mounted = true; _mode = 'embed'; _root = el;
    injectCSS();
    el.className = (el.className || '') + ' mmacc-embed-host';
    el.removeAttribute('style');
    el.addEventListener('click', onClick);
    el.addEventListener('change', onChange, true);
    // this section is live now — drop the "coming soon" badge theme.js rendered
    var soon = document.querySelector('#settings-modal .settings-sec-t .settings-soon');
    if (soon) soon.style.display = 'none';
    // widen the settings card into a scrollable sheet for the fuller account content
    if (!document.getElementById('mmacc-embed-css')) {
      var st = document.createElement('style'); st.id = 'mmacc-embed-css';
      st.textContent = '.settings-overlay .settings-card{max-height:90vh;overflow-y:auto;overscroll-behavior:contain}';
      document.head.appendChild(st);
    }
    render();
    wirePrefSync();
    // defer the (cross-origin) profile fetch until the gear is first opened
    var gear = document.getElementById('settings-open');
    var warm = function () { if (!state.loaded) load(); };
    if (gear) gear.addEventListener('click', warm);
    if (window.requestIdleCallback) requestIdleCallback(warm, { timeout: 4000 }); else setTimeout(warm, 1200);
  }
  // MACRO (macro.mastermind-x.com): the settings gear owns sign-in/out; we add a hidden
  // management panel opened from its signed-in row. Identity rides the shared cookie —
  // credentials:include on the cross-origin call to the app broker — so NO Supabase SDK
  // (jsdelivr) is ever loaded here (it's GFW-blocked). theme.js calls window.MMAccount.open().
  function mountMacro() {
    if (_mounted) return;
    _mounted = true; _mode = 'standalone'; _macro = true;
    injectCSS();
    scrim = document.createElement('div'); scrim.className = 'mmacc-scrim';
    scrim.addEventListener('click', close);
    panel = document.createElement('div'); panel.className = 'mmacc';
    panel.setAttribute('role', 'dialog'); panel.setAttribute('aria-label', T('account'));
    panel.addEventListener('click', onClick);
    panel.addEventListener('change', onChange, true);
    document.body.appendChild(scrim); document.body.appendChild(panel);
    _root = panel;
    wirePrefSync();
    _wireAuthTransitions();
  }
  // Single-owner handshake for the shared theme/lang atomics (see the header). True
  // exactly when persistPref would queue a write for `key`: the panel is mounted, the
  // account read settled as signed-in, no hydration or auth-apply fence is up, and no
  // Shared Shell bridge apply is in flight.
  // theme.js consults this before its own updateUser save and leaves those keys here.
  function claimsPref(key) {
    if (!_mounted) return false;
    if (key !== 'theme' && key !== 'lang') return false;
    if (_hydrating || _authApplying || _mmShellApplying()) return false;
    return !!(state.loaded && !state.unavail && state.acct && state.acct.authenticated);
  }
  window.MMAccount = {
    embed: function (el) { try { mountEmbed(el); } catch (e) {} },   // legacy (old settings modal)
    open: function () { try { if (!_mounted) mountMacro(); open(); } catch (e) {} },
    claimsPref: function (key) { try { return claimsPref(key); } catch (e) { return false; } }
  };

  function boot() {
    if (_mounted) return;
    // MACRO: theme.js defines window.MDXAuth + the .nav-settings gear. Hook management there.
    if (window.MDXAuth || document.querySelector('.nav-settings, .settings-pop')) { mountMacro(); return; }
    // APP: standalone avatar in the nav controls.
    if (document.querySelector('.mm-nav-ctrls, .nav-ctrls')) { mountStandalone(); return; }
    setTimeout(function () {
      if (!_mounted && document.querySelector('.nav-ctrls, .mm-nav-ctrls')) mountStandalone();
    }, 3000);
  }

  // --------------------------------------------------------------- CSS -------
  var CSS =
  '.mmacc-trigger{display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;padding:0;border-radius:50%;' +
    'border:1px solid var(--line,var(--grid));background:var(--panel2,var(--card));color:var(--muted,var(--ink-3));cursor:pointer;' +
    'font:600 12px/1 var(--font-ui,Inter,system-ui,sans-serif);flex:none;transition:border-color .16s,color .16s,transform .16s,box-shadow .16s;-webkit-tap-highlight-color:transparent}' +
  '.mmacc-trigger:hover{color:var(--text,var(--ink));border-color:var(--link,var(--blue));transform:translateY(-1px)}' +
  '.mmacc-trigger-on{color:#fff;border-color:transparent;background:linear-gradient(135deg,#3b82f6,#7c5cff);box-shadow:0 2px 10px -3px rgba(90,80,255,.6)}' +
  '.mmacc-trigger-ini{letter-spacing:.3px}' +
  '.mmacc-scrim{position:fixed;inset:0;z-index:100050;background:transparent;opacity:0;visibility:hidden;pointer-events:none;transition:opacity .22s ease,visibility 0s linear .22s}' +
  '.mmacc-scrim.open{opacity:1;visibility:visible;pointer-events:auto;background:color-mix(in srgb,var(--bg,#0f1115) 34%,transparent);-webkit-backdrop-filter:blur(3px);backdrop-filter:blur(3px);transition:opacity .22s ease}' +
  '.mmacc{position:fixed;top:58px;right:14px;z-index:100060;width:min(374px,calc(100vw - 20px));max-height:min(84vh,720px);display:flex;flex-direction:column;overflow:hidden;color:var(--text,var(--ink));' +
    'background:var(--panel,var(--card));border:1px solid var(--line,var(--grid));border-radius:18px;box-shadow:var(--popover-shadow,0 18px 50px rgba(0,0,0,.5));' +
    'transform-origin:top right;transform:translateY(-8px) scale(.965);opacity:0;visibility:hidden;pointer-events:none;transition:opacity .19s ease,transform .24s cubic-bezier(.18,.9,.32,1.12),visibility 0s linear .24s}' +
  '.mmacc.open{opacity:1;transform:none;visibility:visible;pointer-events:auto;transition:opacity .19s ease,transform .24s cubic-bezier(.18,.9,.32,1.12)}' +
  '@supports ((backdrop-filter:blur(1px)) or (-webkit-backdrop-filter:blur(1px))){.mmacc{background:color-mix(in srgb,var(--panel,var(--card)) 80%,transparent);-webkit-backdrop-filter:blur(26px) saturate(1.5);backdrop-filter:blur(26px) saturate(1.5)}}' +
  '.mmacc-head{display:flex;align-items:center;gap:11px;padding:15px 15px 13px;border-bottom:1px solid var(--line,var(--grid));flex:none}' +
  '.mmacc-head-out{align-items:flex-start}' +
  '.mmacc-ava{width:40px;height:40px;border-radius:50%;flex:none;display:flex;align-items:center;justify-content:center;font:700 15px/1 var(--font-ui,Inter,system-ui,sans-serif);color:#fff;letter-spacing:.3px;background:linear-gradient(135deg,#3b82f6,#7c5cff);box-shadow:0 3px 12px -4px rgba(90,80,255,.7)}' +
  '.mmacc-idbox{flex:1;min-width:0}' +
  '.mmacc-name{font-size:14px;font-weight:700;color:var(--text,var(--ink));white-space:nowrap;overflow:hidden;text-overflow:ellipsis}' +
  '.mmacc-sub{font-size:11.5px;color:var(--muted,var(--ink-3));margin-top:2px;line-height:1.35}' +
  '.mmacc-plan-pill{flex:none;font-size:10.5px;font-weight:700;color:var(--muted,var(--ink-3));background:var(--panel2,var(--card));border:1px solid var(--line,var(--grid));border-radius:999px;padding:3px 9px;text-transform:uppercase;letter-spacing:.4px}' +
  '.mmacc-x{flex:none;width:26px;height:26px;border-radius:8px;border:1px solid var(--line,var(--grid));background:var(--panel2,var(--card));color:var(--muted,var(--ink-3));font-size:12px;cursor:pointer;line-height:1;transition:color .15s,border-color .15s}' +
  '.mmacc-x:hover{color:var(--text,var(--ink));border-color:var(--link,var(--blue))}' +
  '.mmacc-body{padding:13px 15px 16px;overflow-y:auto;overscroll-behavior:contain}' +
  '.mmacc-embed-host{background:transparent!important;border:0!important;padding:0!important;display:block!important}' +
  '.mmacc-embed .mmacc-head{padding:2px 0 12px}' +
  '.mmacc-group{padding:13px 0;border-top:1px solid color-mix(in srgb,var(--line,var(--grid)) 60%,transparent)}' +
  '.mmacc-body>.mmacc-group:first-child,.mmacc-embed>.mmacc-pro-card:first-child+.mmacc-group,.mmacc-embed>.mmacc-group:first-child{border-top:0}' +
  '.mmacc-body>.mmacc-pro-card:first-child,.mmacc-embed>.mmacc-pro-card:first-child{margin-top:4px}' +
  '.mmacc-glabel{font-size:10.5px;font-weight:800;text-transform:uppercase;letter-spacing:.7px;color:var(--muted,var(--ink-3));margin-bottom:9px;display:flex;align-items:center;gap:7px}' +
  '.mmacc-glabel-danger{color:color-mix(in srgb,var(--down,#e06464) 78%,var(--muted,#888))}' +
  '.mmacc-line{display:flex;align-items:center;gap:10px}' +
  '.mmacc-line-v{flex:1;min-width:0;font-size:13px;color:var(--text,var(--ink));word-break:break-word}' +
  '.mmacc-muted{color:var(--muted,var(--ink-3))}' +
  '.mmacc-warn{color:var(--ink-warn, var(--warn,#e0a030));font-size:11px;font-weight:600}' +
  '.mmacc-mini{flex:none;font-size:12px;font-weight:600;color:var(--ink-link, var(--link,var(--blue)));background:transparent;border:1px solid var(--line,var(--grid));border-radius:8px;padding:5px 11px;cursor:pointer;transition:border-color .15s,background .15s;font-family:inherit}' +
  '.mmacc-mini:hover{border-color:var(--link,var(--blue));background:color-mix(in srgb,var(--link,var(--blue)) 10%,transparent)}' +
  '.mmacc-mini-danger{color:var(--ink-down, var(--down,#e06464))}' +
  '.mmacc-mini-danger:hover{border-color:var(--down,#e06464);background:color-mix(in srgb,var(--down,#e06464) 10%,transparent)}' +
  '.mmacc-field{max-height:0;overflow:hidden;opacity:0;transition:max-height .28s ease,opacity .2s ease,margin .2s ease}' +
  '.mmacc-field.open{max-height:280px;opacity:1;margin-top:10px}' +
  '.mmacc-input{width:100%;box-sizing:border-box;padding:9px 12px;margin-bottom:8px;border-radius:10px;border:1px solid var(--line,var(--grid));background:var(--panel2,var(--card));color:var(--text,var(--ink));font-size:13.5px;outline:none;font-family:inherit;transition:border-color .15s,box-shadow .15s}' +
  '.mmacc-input:focus{border-color:var(--link,var(--blue));box-shadow:0 0 0 3px color-mix(in srgb,var(--link,var(--blue)) 22%,transparent)}' +
  '.mmacc-btnrow{display:flex;gap:8px;justify-content:flex-end}' +
  '.mmacc-btnrow-wide{margin-top:12px}' +
  '.mmacc-btn{font:600 12.5px/1 var(--font-ui,Inter,system-ui,sans-serif);padding:8px 14px;border-radius:9px;cursor:pointer;border:1px solid var(--line,var(--grid));transition:all .15s;flex:none}' +
  '.mmacc-btn:disabled{opacity:.55;cursor:default}' +
  '.mmacc-primary{background:var(--link,var(--blue));border-color:var(--link,var(--blue));color:#fff}' +
  '.mmacc-primary:hover:not(:disabled){filter:brightness(1.08);transform:translateY(-1px)}' +
  '.mmacc-ghost{background:var(--panel2,var(--card));color:var(--text,var(--ink))}' +
  '.mmacc-ghost:hover:not(:disabled){border-color:var(--link,var(--blue))}' +
  '.mmacc-block{width:100%;text-align:center;margin-top:4px}' +
  '.mmacc-danger-btn{background:var(--down,#e06464);border-color:var(--down,#e06464);color:#fff}' +
  '.mmacc-danger-btn:hover:not(:disabled){filter:brightness(1.06)}' +
  '.mmacc-row{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:5px 0;font-size:12.5px}' +
  '.mmacc-k{color:var(--muted,var(--ink-3))}' +
  '.mmacc-v{color:var(--text,var(--ink));text-align:right;word-break:break-word}' +
  '.mmacc-chips{display:inline-flex;flex-wrap:wrap;gap:5px;justify-content:flex-end}' +
  '.mmacc-chip{font-size:10.5px;font-weight:600;color:var(--text,var(--ink));background:var(--panel2,var(--card));border:1px solid var(--line,var(--grid));border-radius:6px;padding:2px 7px;text-transform:capitalize}' +
  '.mmacc-row-toggle{padding:7px 0}' +
  '.mmacc-switch{width:34px;height:20px;border-radius:999px;background:var(--panel2,var(--card));border:1px solid var(--line,var(--grid));position:relative;flex:none;opacity:.6}' +
  '.mmacc-switch::after{content:"";position:absolute;top:2px;left:2px;width:14px;height:14px;border-radius:50%;background:var(--muted,var(--ink-3))}' +
  '.mmacc-soon{font-size:9.5px;font-weight:800;text-transform:uppercase;letter-spacing:.5px;color:var(--ink-warn, var(--warn,#e0a030));background:color-mix(in srgb,var(--warn,#e0a030) 14%,transparent);border-radius:999px;padding:2px 7px}' +
  '.mmacc-soon-sm{padding:1px 6px;font-size:9px}' +
  '.mmacc-pro-card{background:linear-gradient(135deg,color-mix(in srgb,#7c5cff 12%,var(--panel2,var(--card))),color-mix(in srgb,#3b82f6 10%,var(--panel2,var(--card))));border:1px solid color-mix(in srgb,#7c5cff 30%,var(--line,var(--grid)));border-radius:13px;padding:12px 13px;margin-bottom:4px}' +
  '.mmacc-pro-top{display:flex;align-items:center;justify-content:space-between;gap:8px}' +
  '.mmacc-pro-name{font-size:14px;font-weight:800;color:var(--text,var(--ink))}' +
  '.mmacc-pro-blurb{font-size:11.5px;color:var(--muted,var(--ink-3));margin:6px 0 10px}' +
  '.mmacc-pro-btn{width:100%;box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;text-align:center;text-decoration:none;background:linear-gradient(135deg,#3b82f6,#7c5cff);border:0;color:#fff}' +
  '.mmacc-pro-btn:hover{filter:brightness(1.06);color:#fff}' +
  '.mmacc-pro-btn:disabled{opacity:.9;cursor:default;filter:saturate(.65) brightness(.94)}' +
  '.mmacc-plan-live{background:linear-gradient(135deg,color-mix(in srgb,#7c5cff 9%,var(--panel2,var(--card))),color-mix(in srgb,#3b82f6 7%,var(--panel2,var(--card))))}' +
  '.mmacc-plan-tag{font-size:9.5px;font-weight:800;text-transform:uppercase;letter-spacing:.5px;color:#fff;background:linear-gradient(135deg,#3b82f6,#7c5cff);border-radius:999px;padding:2px 8px}' +
  '.mmacc-plan-trial{background:linear-gradient(135deg,var(--warn,#e0a030),#e0764a)}' +
  '.mmacc-hint{font-size:11px;color:var(--muted,var(--ink-3));line-height:1.5;margin-top:9px}' +
  '.mmacc-msg{font-size:11.5px;line-height:1.4;max-height:0;overflow:hidden;transition:max-height .2s ease;margin:0}' +
  '.mmacc-msg.show{max-height:60px;margin:0 0 8px}' +
  '.mmacc-msg.ok{color:var(--ink-ok, var(--ok,#3da564))}' +
  '.mmacc-msg.bad{color:var(--ink-act, var(--act))}' +
  '.mmacc-signin-title{font-size:15px;font-weight:800;color:var(--text,var(--ink))}' +
  '.mmacc-signin-sub{font-size:12px;color:var(--muted,var(--ink-3));line-height:1.5;margin:5px 0 12px}' +
  '.mmacc-loading{padding:26px;text-align:center;color:var(--muted,var(--ink-3))}' +
  '@media (max-width:560px){.mmacc-group[data-acct-state="unavailable"] .mmacc-btnrow{justify-content:flex-start}}' +
  '@media (max-width:560px){.mmacc{top:auto;bottom:0;left:0;right:0;width:100%;max-width:none;max-height:88vh;border-radius:18px 18px 0 0;transform-origin:bottom center;transform:translateY(16px)}.mmacc.open{transform:none}.mmacc-scrim.open{background:color-mix(in srgb,var(--bg,#0f1115) 52%,transparent)}}' +
  '@media (prefers-reduced-motion:reduce){.mmacc{transition:opacity .15s ease,visibility 0s linear .15s;transform:none}.mmacc.open{transform:none;transition:opacity .15s ease}.mmacc-field{transition:none}}';

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();

  /* ---- market-aware nav ----------------------------------------------------
     Pull in nav_market.js, which folds the non-home country menus into the
     International dropdown for a signed-in user (masterplan R1). It rides along
     here because account.js is already loaded on EVERY page by theme.js, so the
     fold reaches the whole estate without adding a <script> to _navlinks.html.j2
     — which would mean re-rendering 3,000+ pages to ship a per-user behaviour
     that never belonged in the baked html in the first place.
     Path-depth aware (pages under /sectors/ etc. need the '../' prefix) and
     idempotent; no-ops for anonymous visitors. */
  (function loadNavMarket() {
    if (window.__mmNavMarketLoading) return;
    window.__mmNavMarketLoading = true;
    var self = document.querySelector('script[src$="account.js"],script[src*="account.js?"]');
    var pfx = self ? (self.getAttribute('src') || '').replace(/account\.js(\?.*)?$/, '') : '';
    var s = document.createElement('script');
    // nav_market.js owns the runtime menu composition, so it must never inherit
    // a stale year-cached response after a navigation release.
    s.src = pfx + 'nav_market.js?v=20261018-shared-shell-source-join';
    s.async = true;
    (document.head || document.documentElement).appendChild(s);
  })();
})();
