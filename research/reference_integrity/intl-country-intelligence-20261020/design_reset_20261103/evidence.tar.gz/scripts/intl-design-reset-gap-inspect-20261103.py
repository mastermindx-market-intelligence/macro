from pathlib import Path
from urllib.parse import urlparse
import functools,http.server,threading,json
from playwright.sync_api import sync_playwright
S=Path('/tmp/intl-design-reset-r2-20261103/source/site')
class H(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(H,directory=str(S)))
threading.Thread(target=server.serve_forever,daemon=True).start()
with sync_playwright() as pw:
 b=pw.chromium.launch(channel='chrome',headless=True);c=b.new_context(viewport={'width':1440,'height':1000})
 c.route('**/*',lambda r:r.continue_() if urlparse(r.request.url).hostname=='127.0.0.1' else r.abort())
 p=c.new_page();p.goto('http://127.0.0.1:'+str(server.server_port)+'/intl.html?view=overview#im-overview-0-overview',wait_until='domcontentloaded',timeout=60000)
 p.locator('.intl-overview:not([hidden])').wait_for(state='visible')
 print(json.dumps(p.locator('.intl-workspace').evaluate("""e=>[...e.children].filter(x=>x.getBoundingClientRect().height).map(x=>{const r=x.getBoundingClientRect(),s=getComputedStyle(x);return{tag:x.tagName,class:x.className,y:r.y,h:r.height,marginTop:s.marginTop,marginBottom:s.marginBottom,paddingTop:s.paddingTop,paddingBottom:s.paddingBottom,text:x.innerText.slice(0,180)}})"""),indent=2))
 print(json.dumps(p.locator('.intl-gs').evaluate("""e=>[...e.children].filter(x=>x.getBoundingClientRect().height).map(x=>({tag:x.tagName,class:x.className,html:x.outerHTML.slice(0,1200),height:x.getBoundingClientRect().height}))"""),indent=2))
 b.close()
server.shutdown()
