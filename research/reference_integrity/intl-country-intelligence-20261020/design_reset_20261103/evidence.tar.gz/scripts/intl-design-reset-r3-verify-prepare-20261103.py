from pathlib import Path
import json
R=Path('/tmp/intl-design-reset-r3-20261103')
s=Path('/tmp/intl-design-reset-r2-browser-20261103.py').read_text().replace('intl-design-reset-r2-20261103','intl-design-reset-r3-20261103')
Path('/tmp/intl-design-reset-r3-browser-20261103.py').write_text(s)
s=Path('/tmp/intl-design-reset-r2-tools-browser-20261103.py').read_text().replace('intl-design-reset-r2-20261103','intl-design-reset-r3-20261103')
s=s.replace("    row['round_trip_restores_values']=True","""    row['round_trip_restores_values']=True
    # The inactive surveillance wrapper must leave no blank band in Overview.
    gs=p.locator('.intl-workspace>.intl-gs')
    assert gs.evaluate('e=>e.getBoundingClientRect().height')==0
    if width>=1024:
     p.locator('button[data-im-action="set_view"][data-im-view="scanner"]').click()
    else:
     p.locator('select[data-im-action="set_view"]:visible').select_option('scanner')
    active=p.locator('[data-im-panel][data-view="scanner"]:visible')
    assert active.count()==1 and gs.evaluate('e=>e.getBoundingClientRect().height')>0
    assert p.evaluate('document.documentElement.scrollWidth')<=width+1
    if width>=1024:
     p.locator('button[data-im-action="set_view"][data-im-view="overview"]').click()
    else:
     p.locator('select[data-im-action="set_view"]:visible').select_option('overview')
    assert read(p)['rows']==row['selections'][0]['overview']['rows']
    row['scanner_route_and_overview_spacing']=True""")
Path('/tmp/intl-design-reset-r3-tools-browser-20261103.py').write_text(s)
model=json.loads(Path('/tmp/intl-design-reset-r2-20261103/proof/overview_expected.json').read_text())
model['source_tree']=json.loads((R/'proof/source.json').read_text())['tree']
model['reuse_reason']='Same genuine 511 input archive, build date and unchanged calculation-owner files; presentation only changed.'
(R/'proof/overview_expected.json').write_text(json.dumps(model,indent=2)+'\n')
print('Prepared two current-build browser scripts and exact unchanged-owner model.')
