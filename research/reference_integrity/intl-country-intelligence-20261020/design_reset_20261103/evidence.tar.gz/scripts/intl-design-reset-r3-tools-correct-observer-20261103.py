from pathlib import Path
s=Path('/tmp/intl-design-reset-r3-tools-browser-20261103.py').read_text()
s=s.replace("p.locator('button[data-im-action=", "p.locator('.intl-workspace__view-nav button[data-im-action=")
s=s.replace('overview_batched_browser.json','overview_batched_browser_corrected.json').replace("'final-'+name","'verified-'+name")
Path('/tmp/intl-design-reset-r3-tools-browser-corrected-20261103.py').write_text(s)
print('Corrected the observer selector to the visible workspace navigation; source unchanged.')
