from pathlib import Path
import hashlib,json,datetime,subprocess,shutil
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018'); O=Path('/tmp/intl-design-reset-20261103')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
T=W/'templates/intl_country_cockpit.html.j2'; C=W/'templates/intl_country_cockpit.css'
assert sha(T)=='77f44939e7b429ac023dce00d226de32ff571e395915fccbe849d88a80113d2d'
assert sha(C)=='7fe1197daebe727ffd3e1b02461c3ecfa6ccef3eb4f74606e94e26a38c45bad9'
backup=O/'pre-source'; assert not backup.exists();backup.mkdir()
for p in [T,C]:shutil.copyfile(p,backup/p.name)
t=T.read_text()
t=t.replace('<h1 id="imc-title">{{ pair(\'International markets\', \'国际市场\') }}</h1></div>',
'''<h1 id="imc-title">{{ pair('International markets', '国际市场') }}</h1>
      <p class="imc-intro">{{ pair('Country outlooks, policy decisions and the forces moving markets.', '国家展望、政策决定与市场背后的驱动力。') }}</p></div>''',1)
t=t.replace("{{ pair('COUNTRY INTELLIGENCE', '国家与地区研判') }}","{{ a.count }} {{ pair('ECONOMIES · COUNTRY RESEARCH', '个经济体 · 国家研究') }}",1)
world_start=t.index('  <article class="imc-world"')
world_end=t.index('  </article>',world_start)+len('  </article>')
t=t[:world_start]+'''  <article class="imc-world" id="imc-world">
    <div class="imc-world-copy">
      <p class="imc-kicker">{{ pair('THE GLOBAL BACKDROP', '全球背景') }}</p>
      <h2>{{ pair(w.title_en,w.title_zh) }}</h2>
      <p>{% if w.mechanism_en %}{{ pair(w.mechanism_en,w.mechanism_zh) }}{% else %}{{ pair(w.read_en,w.read_zh) }}{% endif %}</p>
      <div class="imc-world-source"><a href="{{ w.source_url|e }}" target="_blank" rel="noopener noreferrer">{{ w.source|e }} ↗</a><span>{{ pair('Published ', '发布于 ') }}{{ w.published|e }}{% if w.information_cutoff %} · {{ pair('Information through ', '信息截至 ') }}{{ w.information_cutoff|e }}{% endif %}</span></div>
    </div>
    <div class="imc-world-outlook" aria-label="{{ '全球实际GDP增长预测' if lang|default('en') == 'zh' else 'World real GDP growth forecast' }}">
      <div><small>{{ w.year }}</small><strong>{{ '%.1f'|format(w.current) }}<span>%</span></strong><small>{{ pair('World GDP forecast', '全球GDP预测') }}</small></div>
      {% if w.next is not none %}<span class="imc-world-arrow" aria-hidden="true">→</span><div><small>{{ w.next_year }}</small><strong>{{ '%.1f'|format(w.next) }}<span>%</span></strong><small>{{ pair('World GDP forecast', '全球GDP预测') }}</small></div>{% endif %}
    </div>
  </article>'''+t[world_end:]
old='''<a href="#imc-country-{{ c.cc|e }}" data-imc-country="{{ c.cc|e }}"><span>{{ c.cc|e }}</span>{{ pair(c.name_en, c.name_zh) }}</a>'''
new='''<a href="#imc-country-{{ c.cc|e }}" data-imc-country="{{ c.cc|e }}">
        <span class="imc-rail-code">{{ c.cc|e }}</span><span class="imc-rail-name">{{ pair(c.name_en, c.name_zh) }}</span>
        <span class="imc-rail-outlook">{% if c.forecast %}<small>{{ c.forecast.next_label if c.forecast.next is not none else c.forecast.year_label }} {{ pair('GDP', 'GDP') }}</small><b>{{ '%.1f'|format(c.forecast.next if c.forecast.next is not none else c.forecast.current) }}%</b>{% else %}<small>{{ pair('Outlook unavailable', '暂无增长展望') }}</small>{% endif %}</span>
      </a>'''
assert old in t;t=t.replace(old,new,1)
a=t.index('              {% if c.policy_decision %}{% set pd = c.policy_decision %}')
b=t.index('              {% if c.outlook.balances %}',a)
policy=t[a:b];t=t[:a]+t[b:]
a=t.index('              <div class="imc-observations-label">')
b=t.index('              <section class="imc-market-read">',a)
vitals=t[a:b];t=t[:a]+t[b:]
a=t.index('              <section class="imc-market-read">')
b=t.index('              <section class="imc-driver">',a)
market=t[a:b];t=t[:a]+t[b:]
a=t.index('              <section class="imc-driver">')
b=t.index('\n            </div>\n            <aside class="imc-paths">',a)
driver=t[a:b];t=t[:a]+t[b:]
marker='          <div class="imc-country-grid">'
strip='''          <div class="imc-reading-strip">
            <section class="imc-economic-read" aria-labelledby="imc-economic-{{ c.cc }}">
'''+vitals.replace('<div class="imc-observations-label">','<h3 class="imc-observations-label" id="imc-economic-{{ c.cc }}">',1).replace("{{ pair('ECONOMIC OBSERVATIONS', '经济观测') }}</div>","{{ pair('ECONOMIC OBSERVATIONS', '经济观测') }}</h3>",1)+'''            </section>
'''+market+'''          </div>
'''
assert marker in t;t=t.replace(marker,strip+marker,1)
t=t.replace('            <aside class="imc-paths">','            <div class="imc-side-column">\n'+policy+'            <aside class="imc-paths">',1)
t=t.replace('            </aside>\n          </div>','            </aside>\n            </div>\n          </div>\n'+driver,1)
old='<div class="imc-assessment-heading"><div><p>{{ pair(c.outlook.summary_en or c.read_en, c.outlook.summary_zh or c.read_zh) }}</p>'
assert old in t;t=t.replace(old,'<div class="imc-assessment-heading"><div>',1)
marker='''                {% if c.forecast %}{% set f = c.forecast %}'''
assert marker in t
t=t.replace(marker,'''                <p class="imc-outlook-summary">{{ pair(c.outlook.summary_en or c.read_en, c.outlook.summary_zh or c.read_zh) }}</p>
'''+marker,1)
T.write_text(t);C.write_bytes((O/'country.css').read_bytes())
record={'changed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'paths':{str(p.relative_to(W)):sha(p) for p in [T,C]},'prior_source_tree':'c9dcd331bb3a59d029604a09273751eaca1bbeee','scope':'Country presentation only; all financial, qualification and routing owners unchanged','prior_archives_preserved':True}
(O/'mutation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
