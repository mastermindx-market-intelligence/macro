from pathlib import Path
import hashlib,json
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018')
C=W/'templates/intl_country_cockpit.css'
s=C.read_text().replace('border-radius:4px','border-radius:var(--r-ctl,8px)').replace('border-radius:6px','border-radius:var(--r-ctl,8px)').replace('border-radius:50%','border-radius:var(--r-pill,999px)')
C.write_text(s)
T=W/'templates/intl.html.j2';s=T.read_text()
old="<summary>{{ t('Data & research tools', '数据与研究工具') }} <span aria-hidden=\"true\">+</span></summary>"
new="""<summary><span class="imc-tools-heading">{{ t('Research workbench', '研究工作台') }}<small>{{ t('Returns & FX · Global scanner · Scenarios · Source coverage', '回报与汇率 · 全球扫描 · 情景分析 · 来源覆盖') }}</small></span> <span aria-hidden="true">+</span></summary>"""
assert old in s;s=s.replace(old,new,1);T.write_text(s)
T=W/'templates/intl_workspace/shell.html.j2';s=T.read_text()
old="""    <h1 id="intl-workspace-title" data-im-heading>{{ t('International markets', '国际市场') }}</h1>
    <p>{{ t('Compare covered markets, understand currency effects and inspect the evidence.', '比较覆盖市场，了解汇率影响，并查看相关依据。') }}</p>"""
new="""    {% if has_country_analysis|default(false) %}<h2 id="intl-workspace-title" data-im-heading>{{ t('Market research', '市场研究') }}</h2>{% else %}<h1 id="intl-workspace-title" data-im-heading>{{ t('International markets', '国际市场') }}</h1>{% endif %}
    <p>{{ t('Compare covered markets, understand currency effects and inspect the evidence.', '比较覆盖市场，了解汇率影响，并查看相关依据。') }}</p>"""
assert old in s;s=s.replace(old,new,1);T.write_text(s)
C=W/'templates/intl_workspace.css';s=C.read_text()
assert 'Paper research workbench' not in s
s+="""

/* Paper research workbench: one clear tool rail and compact, persistent context.
   The existing controller retains every view, selection and availability gate. */
body.imc-page #intl-analysis-tools>.imc-tools-heading,
body.imc-page #intl-analysis-tools .imc-tools-heading{display:grid;gap:3px;padding-block:14px}
body.imc-page #intl-analysis-tools .imc-tools-heading small{font-size:var(--fs-label);font-weight:400;color:var(--muted);line-height:1.6}
body.imc-page .intl-workspace>header{margin-bottom:16px}
body.imc-page .intl-workspace [data-im-heading]{font-size:var(--fs-num-lg);font-weight:650;letter-spacing:-.025em;margin:0 0 5px}
body.imc-page .intl-workspace>header>p{font-size:var(--fs-sm);color:var(--muted);margin:0}
body.imc-page .intl-workspace [data-im-eod-disclosure]{font-size:var(--fs-label);line-height:1.7;color:var(--muted);background:var(--panel2);border:1px solid var(--line-quiet,var(--line));border-radius:var(--r-ctl,8px);padding:12px 16px;margin:0 0 16px}
body.imc-page .intl-workspace__toolbar{display:flex;gap:12px 20px;align-items:center;padding:0;margin:0 0 20px}
body.imc-page .intl-workspace__toolbar legend{font-size:var(--fs-label);font-weight:500;color:var(--muted);margin-bottom:8px}
body.imc-page .intl-workspace__view-nav{flex:1 0 100%;display:flex;flex-wrap:nowrap;gap:3px;overflow-x:auto;overscroll-behavior-x:contain;scrollbar-width:thin;padding:4px;border:1px solid var(--line-quiet,var(--line));border-radius:var(--r-btn,10px);background:var(--panel2)}
body.imc-page .intl-workspace__view-nav button{flex:1 0 auto;white-space:nowrap;min-height:44px;padding:8px 12px;background:transparent;box-shadow:none;border:1px solid transparent;border-radius:var(--r-ctl,8px);font-size:var(--fs-sm);font-weight:500;color:var(--muted)}
body.imc-page .intl-workspace__view-nav button:not(:disabled):hover{background:var(--panel);color:var(--text)}
body.imc-page .intl-workspace__view-nav button[aria-pressed="true"]{background:var(--panel);border-color:var(--line);color:var(--text);font-weight:600}
body.imc-page .intl-workspace__view-nav button:disabled{opacity:.55}
body.imc-page .intl-workspace__toolbar>label{display:flex;flex-direction:row;align-items:center;gap:10px;font-size:var(--fs-label)}
body.imc-page .intl-workspace__toolbar>label.intl-workspace__view-select{display:none}
body.imc-page .intl-workspace__toolbar select{min-height:40px;width:auto;min-width:100px;padding:8px 30px 8px 12px;background:var(--panel);box-shadow:none;font-size:var(--fs-sm)}
body.imc-page .intl-overview__context{font-size:var(--fs-label)}
body.imc-page .intl-overview__summary,
body.imc-page .intl-overview__focus,
body.imc-page .intl-overview__market{border-radius:var(--r-btn,10px);box-shadow:none}
body.imc-page .intl-inspectors{margin-top:28px}
body.imc-page .intl-inspector__fallback>summary{font-size:var(--fs-sm)}
@media(max-width:768px){
 body.imc-page .intl-workspace__view-nav{display:none}
 body.imc-page .intl-workspace__toolbar{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
 body.imc-page .intl-workspace__toolbar>label{display:flex;flex-direction:column;align-items:stretch;gap:5px}
 body.imc-page .intl-workspace__toolbar>label.intl-workspace__view-select{display:flex;grid-column:1/-1}
 body.imc-page .intl-workspace__toolbar select{width:100%;min-width:0;min-height:44px;padding-right:25px}
 body.imc-page .intl-workspace [data-im-eod-disclosure]{padding:12px;font-size:var(--fs-micro)}
 body.imc-page .intl-workspace [data-im-heading]{font-size:var(--fs-h2)}
}
"""
C.write_text(s)
print(json.dumps({str(p.relative_to(W)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [W/'templates/intl_country_cockpit.css',W/'templates/intl.html.j2',W/'templates/intl_workspace/shell.html.j2',C]}))
