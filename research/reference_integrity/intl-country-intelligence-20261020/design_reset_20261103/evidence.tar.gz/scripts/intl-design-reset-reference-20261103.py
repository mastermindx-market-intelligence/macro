from pathlib import Path
import base64,json,hashlib,datetime
O=Path('/tmp/intl-design-reset-20261103');R=O/'references';R.mkdir(exist_ok=True)
rows=[]
for f in O.glob('R*.b64'):
 raw=base64.b64decode(f.read_text(),validate=True);p=R/(f.stem+'.jpg');assert not p.exists();p.write_bytes(raw);rows.append({'name':p.name,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)});f.unlink()
(R/'manifest.json').write_text(json.dumps({'file_id':'01M3P1TW5Y3XWQC37ADDS8K5AG','nodes':{'R12-light':'DW7-0','R12-dark':'DMX-0','R14-light':'GWG-0','R14-dark':'G9J-0','R14-mobile':'IRV-0'},'observed_at':'2026-11-03','images':rows,'scope':'Unmodified native MCP screenshot bytes; specimen values are design references only.'},indent=2)+'\n')
print(json.dumps({'retained':len(rows)}))
