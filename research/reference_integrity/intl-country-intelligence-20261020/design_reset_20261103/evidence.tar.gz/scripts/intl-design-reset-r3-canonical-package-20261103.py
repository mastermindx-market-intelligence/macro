from pathlib import Path
import copy,datetime,hashlib,json,subprocess,yaml
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018');R=Path('/tmp/intl-design-reset-r3-20261103');C=R/'canonical';P=R/'proof'
D=W/'mockups/evidence/intl-design-reset-20261103';assert not D.exists();D.mkdir()
execution=json.loads((C/'capture_execution.json').read_text());assert execution['state']=='PASS'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
page_blob=subprocess.check_output(['git','hash-object',str(R/'source/site/intl.html')],cwd=W,text=True).strip()
records=[]
for name,paths in [
 ('country',['templates/intl_country_cockpit.css','templates/intl_country_cockpit.html.j2','templates/intl.html.j2','templates/theme.css','site/theme.css']),
 ('tools',['templates/intl_workspace.css','site/intl_workspace.css','templates/intl_workspace/shell.html.j2','templates/intl.html.j2'])
]:
 dest=D/name;dest.mkdir();(dest/'images').mkdir()
 rest=C/(name+'-rest');interaction=C/(name+'-interaction')
 m=json.loads((rest/'manifest.json').read_text());extra=json.loads((interaction/'manifest.json').read_text())
 assert m['schema']=='mastermind.p0_evidence.v2' and m['tool']==extra['tool']
 page=m['pages'][0];p2=extra['pages'][0]
 assert page['console_errors']==[] and page['failed_responses']==[] and p2['console_errors']==[] and p2['failed_responses']==[]
 selected=[(rest,s) for s in page['states']]+[(interaction,s) for s in p2['states'] if s.get('force_state')]
 assert sum(not s.get('force_state') for _,s in selected)==8
 images=[]
 for source,state in selected:
  assert state['captured'] and state['applied_theme']==state['theme'] and state['applied_locale']==state['locale']
  original=source/state['file'];raw=original.read_bytes();assert sha(original)==state['sha256'] and len(raw)==state['bytes']
  target=dest/state['file'];target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists();target.write_bytes(raw)
  state['capture_tool_module_sha256']=m['tool']['module_sha256'];images.append({'file':state['file'],'sha256':state['sha256'],'bytes':state['bytes']})
 page['states']=[s for _,s in selected];page['page_tree_sha']=page_blob
 m['selection']['note']+='; Bound actual design reset build. Rest and genuine interaction observations combined from the same unmodified capture tool and exact page bytes; no unobserved state added.'
 (dest/'manifest.json').write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n')
 receipt={'schema':'mastermind.page_evidence_receipt.v1','changed_paths':paths,'manifest':str((dest/'manifest.json').relative_to(W))}
 (dest/'EVIDENCE.yml').write_text(yaml.safe_dump(receipt,sort_keys=False))
 records.append({'section':name,'state_count':len(selected),'receipt':str((dest/'EVIDENCE.yml').relative_to(W)),'original_rest_manifest_sha256':sha(rest/'manifest.json'),'original_interaction_manifest_sha256':sha(interaction/'manifest.json'),'images':images})
(P/'canonical_package.json').write_text(json.dumps({'source_tree':execution['source_tree'],'html_sha256':execution['html_sha256'],'capture_tool_module_sha256':execution['capture_tool_module_sha256'],'launch_adapter_sha256':execution['launch_adapter_sha256'],'records':records},indent=2)+'\n')
files=['templates/intl_country_cockpit.html.j2','templates/intl_country_cockpit.css','templates/intl.html.j2','templates/intl_workspace.css','templates/intl_workspace/shell.html.j2','templates/theme.css','site/theme.css','site/intl_workspace.css']
diff=P/'final_ui.diff';diff.write_bytes(subprocess.check_output(['git','diff','--unified=0','6a695db8fb1b789b27760de261e472387784cb9a','--',*files],cwd=W))
cmd=['/tmp/intl-country-ci-20261103/bin/python','scripts/check_ui_visual_evidence.py','--diff-file',str(diff)]
rec={'state':'RUNNING','command':cmd,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Mechanical evidence integrity and interaction coverage for the design reset; not visual acceptance.'}
with (P/'visual_evidence_guard.log').open('w') as f:r=subprocess.run(cmd,cwd=W,stdout=f,stderr=subprocess.STDOUT,timeout=240)
rec.update(state='PASS' if r.returncode==0 else 'FAILED',exit_code=r.returncode,completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),log_sha256=sha(P/'visual_evidence_guard.log'))
(P/'visual_evidence_guard.json').write_text(json.dumps(rec,indent=2)+'\n')
print(json.dumps({'state':rec['state'],'observations':sum(r['state_count'] for r in records),'receipts':[r['receipt'] for r in records]},indent=2),flush=True)
