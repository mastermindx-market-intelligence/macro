from pathlib import Path
import json,hashlib
O=Path('/tmp/intl-design-reset-r2-20261103')
old=Path('/tmp/intl-overview-refined-browser-20261103.py').read_text()
new=old.replace("/tmp/intl-paper-overview-refined-20261103","/tmp/intl-design-reset-r2-20261103")
new=new.replace("p.locator('#intl-analysis-tools').inner_text()","p.locator('[data-im-eod-disclosure]').inner_text()")
new=new.replace("Eight normal one-month UI selections, exact owner-model checks using a single scoped DOM observation per state; actual local build, not production or long-session stability acceptance. Original dense-observer crash and successful diagnostic sequences remain retained; this fresh build additionally verifies the compact notice and daily date display.","Eight ordinary one-month UI selections through the redesigned tool rail and responsive context controls. Exact returns, windows and dates are checked against the unchanged owner model and identical 511 inputs. Not production or long-session stability acceptance.")
Path('/tmp/intl-design-reset-r2-tools-browser-20261103.py').write_text(new)
model=json.loads(Path('/tmp/intl-paper-overview-refined-20261103/proof/overview_expected.json').read_text())
model['reuse_reason']='All numerical/source/qualification files are unchanged; same 511 input bytes, build date and delayed snapshot. Only six presentation source files changed.'
model['source_tree']=json.loads((O/'proof/source.json').read_text())['tree']
(O/'proof/overview_expected.json').write_text(json.dumps(model,indent=2)+'\n')
print('Prepared ordinary UI return/window verification for current source.')
