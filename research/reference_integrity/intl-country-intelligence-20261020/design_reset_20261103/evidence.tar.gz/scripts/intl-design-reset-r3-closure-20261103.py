from pathlib import Path
import concurrent.futures,datetime,hashlib,json,os,shutil,subprocess,tarfile
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018')
R=Path('/tmp/intl-design-reset-r3-20261103');P=R/'proof';E=W/'mockups/evidence/prophet-p0b-zero-fouc'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
assert json.loads((P/'ordinary_build.json').read_text())['state']=='PASS'
# Copy only the ordinary builder's owned changed plain-copy asset.
src=R/'source/site/intl_workspace.css';assert src.read_bytes()==(W/'templates/intl_workspace.css').read_bytes()
(W/'site/intl_workspace.css').write_bytes(src.read_bytes())
subprocess.run(['git','add','--','site/intl_workspace.css'],cwd=W,check=True)
sync={'source_tree':json.loads((P/'source.json').read_text())['tree'],'after_generated_sync_tree':subprocess.check_output(['git','write-tree'],cwd=W,text=True).strip(),'path':'site/intl_workspace.css','sha256':sha(src),'provenance':'Actual ordinary builder output, byte-equal to template; no source or generated HTML edit','time':now()}
(P/'generated_sync.json').write_text(json.dumps(sync,indent=2)+'\n')
def run(name,cmd,env=None,timeout=1200):
 rec={'state':'RUNNING','command':cmd,'started_at':now()};dst=P/(name+'.json');dst.write_text(json.dumps(rec,indent=2)+'\n')
 with (P/(name+'.log')).open('w') as out:
  try:r=subprocess.run(cmd,cwd=W,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=timeout);rec.update(state='PASS' if r.returncode==0 else 'FAILED',exit_code=r.returncode)
  except subprocess.TimeoutExpired:rec.update(state='TIMED_OUT')
 rec.update(completed_at=now(),log_sha256=sha(P/(name+'.log')));dst.write_text(json.dumps(rec,indent=2)+'\n');print(name,rec['state'],flush=True);return rec
run('template_site_sync_final',['/tmp/intl-country-ci-20261103/bin/python','-m','scripts.check_template_site_sync'])
run('runtime_style_final',['/tmp/intl-country-ci-20261103/bin/python','scripts/check_runtime_style_injection.py'])
with tarfile.open(P/'p0b_prior_receipts.tar.gz','w:gz') as t:
 for p in sorted(E.iterdir()):
  if p.is_file() and p.suffix in ['.json','.png']:t.add(p,arcname=p.name)
fixture=R/'p0b_fixtures';fixture.mkdir()
r=run('p0b_render',['/tmp/intl-country-ci-20261103/bin/python','scripts/render_stock_dashboard_fixture.py','--market','all','--out-dir',str(fixture),'--receipt','mockups/evidence/prophet-p0b-zero-fouc/rendered-fixture.json'])
assert r['state']=='PASS',r
env=os.environ.copy();env['NODE_PATH']='/tmp/intl-p0b-node-20261103/node_modules'
def verify(market,out):
 return run('p0b_'+market,['/opt/homebrew/bin/node','scripts/verify_stock_dashboard_mobile_layout.cjs','--html',str(fixture/(market+'_stocks.html')),'--site-dir','site','--fixture-receipt','mockups/evidence/prophet-p0b-zero-fouc/rendered-fixture.json','--fixture-assets-dir','mockups/evidence/prophet-p0b-zero-fouc/inputs/browser-data','--screenshot-dir','mockups/evidence/prophet-p0b-zero-fouc','--historical-head','3fb76ea810a8e9ef6a05fe808bb6eaee87eb1f86','--historical-tree','b4dd8fd9b29b4eb769239d35df2a7911e793c7ec','--out','mockups/evidence/prophet-p0b-zero-fouc/'+out],env=env)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 jobs=[pool.submit(verify,'hk','mobile-layout.json'),pool.submit(verify,'canada','mobile-layout-canada.json')]
 results=[j.result() for j in jobs]
if all(r['state']=='PASS' for r in results):
 run('p0b_receipt_tests',['/tmp/intl-country-ci-20261103/bin/python','-m','pytest','-q','tests/test_stock_dashboard_first_frame.py','tests/test_check_p0b_receipt_closure.py','--basetemp=/tmp/intl-design-reset-r3-p0b-pytest-20261103'],timeout=300)
print('P0B completed; review actual receipts before staging.',flush=True)
