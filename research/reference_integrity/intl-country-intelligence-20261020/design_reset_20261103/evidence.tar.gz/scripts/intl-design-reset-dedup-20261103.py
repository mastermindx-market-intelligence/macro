from pathlib import Path
import hashlib,io,json,shutil,tarfile
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018')
D=W/'research/reference_integrity/intl-country-intelligence-20261020/design_reset_20261103';R=Path('/tmp/intl-design-reset-r3-20261103')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=D/'evidence.tar.gz';prior_full=R/'evidence-full-before-dedup.tar.gz';assert not prior_full.exists();shutil.move(old,prior_full)
record={'scope':'Remove duplicated untouched historical P0B screenshots; retain all changed prior/current receipt bytes and the current fixture recipe. The existing repository retains historical screenshot objects. No observation or verdict changed.','original_full_archive_sha256':sha(prior_full),'original_full_archive_bytes':prior_full.stat().st_size,'omitted_duplicate_member':'final/proof/p0b_prior_receipts.tar.gz','prior_backup_sha256':sha(R/'proof/p0b_prior_receipts.tar.gz'),'added_receipts':[]}
extras=[]
with tarfile.open(R/'proof/p0b_prior_receipts.tar.gz') as t:
 for name in ['manifest.json','mobile-layout.json','mobile-layout-canada.json','rendered-fixture.json']:
  raw=t.extractfile(name).read();extras.append(('shared-theme/prior/'+name,raw));record['added_receipts'].append({'path':'shared-theme/prior/'+name,'sha256':hashlib.sha256(raw).hexdigest()})
for name in ['manifest.json','mobile-layout.json','mobile-layout-canada.json','rendered-fixture.json']:
 raw=(W/'mockups/evidence/prophet-p0b-zero-fouc'/name).read_bytes();extras.append(('shared-theme/current/'+name,raw));record['added_receipts'].append({'path':'shared-theme/current/'+name,'sha256':hashlib.sha256(raw).hexdigest()})
extras.append(('scripts/'+Path(__file__).name,Path(__file__).read_bytes()))
extras.append(('archive_layout.json',(json.dumps(record,indent=2)+'\n').encode()))
members=[]
with tarfile.open(prior_full) as source,tarfile.open(old,'w:gz',compresslevel=6) as dest:
 for m in source.getmembers():
  if m.name==record['omitted_duplicate_member']:continue
  raw=source.extractfile(m).read();dest.addfile(m,io.BytesIO(raw));members.append((m.name,hashlib.sha256(raw).hexdigest(),len(raw)))
 for name,raw in extras:
  m=tarfile.TarInfo(name);m.size=len(raw);m.mode=0o644;dest.addfile(m,io.BytesIO(raw));members.append((name,hashlib.sha256(raw).hexdigest(),len(raw)))
with tarfile.open(old) as t:
 assert len(t.getmembers())==len(members)
 for m,(name,digest,size) in zip(t.getmembers(),members):
  raw=t.extractfile(m).read();assert m.name==name and m.size==size and hashlib.sha256(raw).hexdigest()==digest
record['archive_sha256']=sha(old);record['archive_bytes']=old.stat().st_size;record['member_count']=len(members)
(D/'ARCHIVE_LAYOUT.json').write_text(json.dumps(record,indent=2)+'\n')
p=D/'REPORT.json';j=json.loads(p.read_text());a=next(a for a in j['archives'] if a['path']=='evidence.tar.gz');a.update(sha256=sha(old),bytes=old.stat().st_size,member_count=len(members));j['archive_layout']='ARCHIVE_LAYOUT.json';p.write_text(json.dumps(j,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:record[k] for k in ['archive_sha256','archive_bytes','member_count']},indent=2),flush=True)
