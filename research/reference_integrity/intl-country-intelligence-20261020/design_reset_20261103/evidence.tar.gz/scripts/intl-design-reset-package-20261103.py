from pathlib import Path
import datetime,gzip,hashlib,json,re,shutil,subprocess,tarfile,yaml
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018')
R=Path('/tmp/intl-design-reset-r3-20261103');P=R/'proof';A=Path('/tmp/intl-design-reset-20261103');B=Path('/tmp/intl-design-reset-r2-20261103')
D=W/'research/reference_integrity/intl-country-intelligence-20261020/design_reset_20261103'
assert not D.exists();D.mkdir();(D/'source').mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
read=lambda n:json.loads((P/n).read_text())
build=read('ordinary_build.json');browser=read('browser.json');tools=read('overview_batched_browser_corrected.json');visual=read('canonical_package.json')
assert build['state']=='PASS' and browser['state']=='PASS' and len(browser['states'])==20 and tools['passed'] and tools['selection_count']==8
for f in ['focused_tests.json','design_added.json','template_site_sync_final.json','runtime_style_final.json','p0b_hk.json','p0b_canada.json','p0b_binding_recheck.json','p0b_closure_final.json','visual_evidence_guard.json']:assert read(f)['state']=='PASS',f
files=['templates/intl_country_cockpit.html.j2','templates/intl_country_cockpit.css','templates/intl.html.j2','templates/intl_workspace.css','templates/intl_workspace/shell.html.j2','templates/theme.css','site/theme.css','site/intl_workspace.css']
for f in files:
 src=W/f;dest=D/'source'/f;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest)
 if f in build['exact_source_overlay']:assert sha(src)==build['exact_source_overlay'][f],f
assert (W/'site/intl_workspace.css').read_bytes()==(R/'source/site/intl_workspace.css').read_bytes()
diff=subprocess.check_output(['git','diff','--binary','6a695db8fb1b789b27760de261e472387784cb9a','--',*files],cwd=W);(D/'runtime.patch').write_bytes(diff)
with (R/'source/site/intl.html').open('rb') as src,gzip.open(D/'rendered-intl.html.gz','wb',compresslevel=6) as dest:shutil.copyfileobj(src,dest)
with gzip.open(D/'rendered-intl.html.gz','rb') as f:assert hashlib.sha256(f.read()).hexdigest()==build['html_sha256']
for name,source in [('country-desktop.png',P/'screenshots/1440-light-en-full.png'),('country-mobile.png',P/'screenshots/390-light-en-full.png'),('country-dark.png',P/'screenshots/1440-dark-en.png'),('research-tools.png',P/'screenshots/verified-1440-light-en-overview-usd_unhedged.png')]:shutil.copyfile(source,D/name)
cold=read('cold_load.json');pr=read('pr_readback.json')
report={
 'schema':'intl.design_reset_checkpoint.v1','created_at':now(),'operation_id':'intl-country-cockpit-20261018','branch':'sol/web-intl-country-cockpit-20261018','pr':9596,
 'mission_complete':False,'disposition':'Local design and implementation advanced; publication and production acceptance blocked.',
 'prior_visual_result':'User rejected the earlier local polish as 4/10; previous proof is not accepted design.',
 'protected_procedure_pin':'e39a617b6771cb6b07323a533b4cf9db7e78900a',
 'head':'851c6abebf01c5c8096e7822436455fd1040152a','merge_head':'c6ac417f4a1d561f8c80a0a6b1977d5ffec6d090',
 'tested_source_tree':build['source_tree'],'runtime_hashes':{f:sha(W/f) for f in files},'generated_html_sha256':build['html_sha256'],'generated_html_bytes':build['html_bytes'],
 'inputs':{'count':511,'commit':build['input_commit'],'archive_sha256':build['input_archive_sha256'],'snapshot':'2026-10-30','provider_reacquisition':False},
 'paper':{'file_id':'01M3P1TW5Y3XWQC37ADDS8K5AG','R12':['DW7-0','DMX-0'],'R14':['G9J-0','GWG-0','IRV-0'],'role':'Native reference reads/JSX; R14 specimen facts were not admitted. No Paper mutation in this reset.'},
 'changes':['Exact Paper canvas/surface tokens survive shared soft-contrast overrides; ambient aurora removed from country page','Seven-country next-year growth strip with complete fiscal-year labels','Selected country becomes the main dossier; native no-JS disclosures remain available','Economic observations and market conditions in one coherent band','Full-width historical/projected growth chart with native exact-value table; duplicate forecast tiles removed','Balanced policy, conditions, fiscal and transmission sections with stronger explanatory text','Explicit Research tools entry, bordered workbench and compact responsive context controls','Unranked returns align identity, index, exact windows and return; inactive surveillance wrapper reserves no space'],
 'verification':{'focused_render_tests':158,'responsive_states':20,'widths':[1440,1024,768,390,320],'themes':['light','dark'],'locales':['en','zh'],'countries_per_state':7,'additional_journey_groups':5,'tools_currency_selections':8,'canonical_unique_states':sum(x['state_count'] for x in visual['records']),'canonical_raw_captures':30,'p0b_primary_and_degraded_cases':128,'p0b_screenshots':16,'guards':['design_added','template_site_sync_final','runtime_style_final','p0b_closure_final','visual_evidence_guard'],'console_and_local_resource_errors':0},
 'failed_attempts_preserved':['R1 literal-radius design guard; replaced with shared radius tokens','R1 palette inherited late blue-grey soft-contrast values; isolated Paper aliases now consumed','R2 mobile chart had 4px negative-margin overflow; corrected in R3','Initial R3 runtime-style command used unsupported diff flag; corrected invocation passed','Initial R3 plain-copy guard found workspace CSS not recopied; actual builder output copied and final guard passed','Initial P0B closure required fresh browser receipts; actual exact-runtime 128-case remint passed','P0B suite 143 passed and one parent-binding assertion failed after remint; genuine current receipt hashes refreshed and targeted assertion passed','First R3 tools observer matched hidden overview buttons; observer scoped to navigation and all eight selections plus scanner round trips passed'],
 'advisory':read('advisory_visual_judgment.json'),
 'cold_load':{'scope':cold['scope'],'states':[{'width':x['width'],'layout_shift_sum':x['layout_shift_sum'],'dom_nodes':x['nodes']} for x in cold['states']],'status':'OPEN shared-header initialization/performance dependency; no production-ready performance claim.'},
 'publication':read('publication_readback.json'),'latest_pr_read':pr,
 'remaining':['Supported native Macro pending-merge publication capability','Reconcile current main after original pending merge is safely published','Exact-current-source independent review and hosted full-data CI','Shared-header cold-load movement, large DOM/long-session performance, and applicable actual-parent Saved/focus findings','Normal renderer/updater adoption, actual served journeys and subsequent normal publication','User design acceptance'],
 'authority':'No commit, push, merge, deployment, Vercel, alternate source publisher, new workspace, remote message or held-Fabric retry. Principal child supplied advisory design judgment only.'
}
(P/'checkpoint_before_archives.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
# Preserve the complete reproducible inputs rather than relying on temporary files.
archives=[]
inputs=[(A/'source.tar','source-base-098acfb.tar'),(Path('/tmp/intl-paper-current-complete-20261103/committed-inputs.tar'),'committed-inputs-19a896b.tar'),(P/'input_manifest.json','input_manifest.json'),(P/'source.json','source_overlay.json')]
for archive_name,members in [('reproduction-inputs.tar.gz',inputs)]:
 target=D/archive_name
 with tarfile.open(target,'w:gz',compresslevel=6) as t:
  for source,name in members:t.add(source,arcname=name)
 with tarfile.open(target) as t:assert len(t.getmembers())==len(members)
 archives.append({'path':archive_name,'sha256':sha(target),'bytes':target.stat().st_size,'members':[{'path':n,'sha256':sha(p),'bytes':p.stat().st_size} for p,n in members]})
 print(archive_name,target.stat().st_size,flush=True)
members=[]
for source,prefix in [(P,'final/proof'),(R/'canonical','final/canonical'),(A/'proof','iteration1/proof'),(A/'preview','iteration1/preview'),(A/'references','paper-references'),(B/'proof','iteration2/proof')]:
 if source.exists():
  for p in sorted(source.rglob('*')):
   if p.is_file():members.append((p,prefix+'/'+str(p.relative_to(source))))
for p in sorted(Path('/tmp').glob('intl-design-reset*-20261103.py')):members.append((p,'scripts/'+p.name))
for p in sorted(Path('/tmp').glob('intl-design-reset*-20261103.log')):members.append((p,'scripts/'+p.name))
for p in sorted(Path('/tmp').glob('intl-design-reset*-20261103.json')):members.append((p,'scripts/'+p.name))
target=D/'evidence.tar.gz'
with tarfile.open(target,'w:gz',compresslevel=6) as t:
 for source,name in members:t.add(source,arcname=name)
with tarfile.open(target) as t:
 seen=t.getmembers();assert len(seen)==len(members)
 for member,(source,name) in zip(seen,members):
  assert member.name==name and member.size==source.stat().st_size
  stream=t.extractfile(member);h=hashlib.sha256()
  while True:
   block=stream.read(1024*1024)
   if not block:break
   h.update(block)
  assert h.hexdigest()==sha(source),name
archives.append({'path':'evidence.tar.gz','sha256':sha(target),'bytes':target.stat().st_size,'member_count':len(members)})
report['archives']=archives
(D/'REPORT.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
text=f"""# International — Paper design reset, 3 November 2026

## Outcome and scope

The country experience and its research workbench have been substantially rebuilt after the user rejected the preceding local version as 4/10. The revised source is built and browser-verified in the original registered worktree. It is **not deployed**, and the user has not accepted the revised design. Mission completion remains false.

Operation: `intl-country-cockpit-20261018`. Branch: `sol/web-intl-country-cockpit-20261018`. Carrier: Macro draft PR #9596. HEAD remains `{report['head']}`; MERGE_HEAD remains `{report['merge_head']}`. The pending two-parent merge is retained without reset, abort, replacement checkout or source-publication bypass.

## What went wrong

The earlier completion evidence established portions of behavior while the user-facing composition remained incomplete. The actual Paper references required a stronger hierarchy, quieter surfaces, readable analysis and a coherent relationship between the country overview and deeper research.

Three concrete source/layout defects compounded that problem. Shared `theme.js` reapplied its older soft-contrast palette, overriding the intended page colors. The site-wide body pseudo-element still painted the ambient background after the page's own aurora was removed. In the workbench, an inactive surveillance wrapper retained 68 pixels of padding, while a two-column unranked list left an incomplete row. A compact notice alone did not repair those composition defects.

The reset reads the actual R12 Country Intelligence and R14 Global Surveillance boards in Paper file `01M3P1TW5Y3XWQC37ADDS8K5AG`. R12 remains the country-research reference. R14 informs surface treatment, density and alignment; its specimen population, market counts and numbers are not product data. The existing country-centered workstream contract remains authoritative.

## Implemented design and UX

- The page consumes dedicated Paper aliases from the shared palette owner, so the light canvas is neutral and the dark version has deliberate surface levels.
- Seven country cards provide a useful next-year forecast scan. India's full fiscal-year label is retained.
- Selecting a country opens one primary dossier. Closing it restores the native summary list, and JavaScript-disabled readers retain the full native disclosures.
- Current economic observations, market trend, drawdown and currency availability share one compact reading band.
- The growth chart occupies the full analysis panel. Historical and projected segments, labels, units, dates and a keyboard-operable values table remain intact. Repeated large forecast tiles were removed.
- Policy, conditional paths, fiscal position and transmission content now have a coherent grid. Substantive explanations have stronger size/contrast than metadata.
- The top entry explicitly names Research tools, and the lower workbench has a clear disclosure affordance. Existing horizon, currency and 13-view destinations retain their controller and URL semantics.
- Unranked market returns appear as aligned rows with each exact calculation window. Missing or unsupported states remain explicit. Scanner is visible when selected; its inactive wrapper leaves no empty band in Overview.

The eight changed runtime/derived paths and exact hashes are in `REPORT.json`. `runtime.patch` is the complete runtime delta from prior checkpoint `6a695db8fb1b789b27760de261e472387784cb9a`. The ordinary builder's emitted theme and workspace CSS were synchronized to their plain-copy site assets. Financial calculation and qualification owners were not changed.

## Actual build and verification

Tested runtime source tree: `{build['source_tree']}`.

Ordinary generated page SHA-256: `{build['html_sha256']}`; {build['html_bytes']:,} bytes. The build used all 511 hash-verified inputs retained from main `{build['input_commit']}`, including its genuine collector receipt. The delayed index/FX snapshot is 2026-10-30. This is an isolated ordinary build; no provider data was reacquired and no production file was written.

| Proof | Result | Boundary |
| --- | --- | --- |
| Focused country, overview, integration and chrome tests | 158 passed | Source/render behavior |
| Country browser matrix | 20 states; seven countries checked in each | 1440, 1024, 768, 390, 320px × EN/ZH × light/dark |
| Additional native journeys | Five groups passed | Country history, native close/restore, reading order and no-JavaScript country/value access |
| Workbench | Eight currency selections passed; Scanner round trip passed in four contexts | Exact return values, machine/display dates, expansion and restoration |
| Canonical visual capture | 30 raw captures; 26 unique rest/interaction observations packaged | Unmodified repository capture tool, actual built page |
| Shared-theme fixture proof | 128 primary/degraded cases and 16 screenshots passed | Exact pinned Chromium 149 / Playwright 1.61.1; fixture proof only |
| Source gates | Design, template/site sync, runtime-style and P0B closure passed | Mechanical/source integrity |
| Visual evidence gate | Passed | Completeness and integrity, not design acceptance |

The principal advisory reviewer inspected the revised desktop, mobile and returns captures and found no concrete remaining visual blocker in those images. That judgment is not formal source/release review or the user's acceptance. The parent additionally inspected the dark English and Chinese desktop/mobile captures.

Failures remain in the archive: the first iteration's literal radii and palette, the second iteration's 4px mobile chart overflow, an unsupported observer CLI flag, the generated workspace CSS synchronization omission, the first tools observer's ambiguous selector, and the P0B parent-receipt binding mismatch. Each has its correction and actual recheck. The P0B unit run passed 143 cases and failed one stale binding assertion; after updating the existing mutable extension to the genuinely reminted receipt hashes, that exact assertion passed. Historical evidence fields were preserved.

## Remaining production issues and publication block

The fresh read-only native publication status returned `REFUSED / NOT_APPLIED / TYPED_GIT_PRECHECK_REFUSED`. The configured publisher's previously established Mastermind/single-parent boundary still has no proved Macro pending-merge path. No commit, push, merge or deployment was attempted. Fresh GitHub metadata confirms PR9596 remains open and draft at the original HEAD. Main has advanced; the latest PR read reports base `{pr['base']}`. This is not current-main reconciliation.

A fresh cold-load observation still reproduces shared-header movement: the desktop main content moves from y126 to y77 as the search/layout initializes. Observed layout-shift sums were {cold['states'][0]['layout_shift_sum']:.3f} at 1440px and {cold['states'][1]['layout_shift_sum']:.3f} at 390px. These are two local observations, not field Core Web Vitals. The actual page has {cold['states'][0]['nodes']:,} DOM nodes and about 23.1 MB of uncompressed HTML. Long-session stability and production performance are not accepted. The source trace leads to the shared navigation's JavaScript-owned layout/settings/search initialization; this reset does not install a parallel navigation controller.

Required continuation is concrete: restore supported native Macro pending-merge publication; publish the preserved source through the original carrier; reconcile current main; obtain current-source independent review and hosted full-data CI; resolve the applicable shared-header/performance and actual-parent Saved/focus findings; run the normal renderer/updater; verify actual served country and tools journeys and a subsequent normal refresh. The prior held Fabric attempt remains held. No alternate publisher, raw-Git commit/push, deployment channel or new worker root is authorized by these records.

## Recoverable deliverables

`REPORT.json` binds runtime bytes, proof scopes, observed release status and archive hashes. `source/` preserves the eight runtime/derived files. `rendered-intl.html.gz` is the exact ordinary generated page. The four PNGs are actual browser captures, not mockups.

`reproduction-inputs.tar.gz` retains the exact source-base archive and genuine 511-input archive plus their manifests, allowing the final ordinary build to be reproduced with the recorded overlay. `evidence.tar.gz` retains final browser/source/canonical proofs, earlier failed iterations, Paper reference images/JSX, and all bounded reset scripts. Both archives were read back and checked. Canonical receipts are also staged under `mockups/evidence/intl-design-reset-20261103/`.

This checkpoint is saved in the incumbent local carrier and remains NOT_CANONICALLY_PERSISTED to GitHub. Local source, fixture proof, canonical screenshot integrity, deployment and user acceptance are separate states.
"""
(D/'DESIGN_RESET.md').write_text(text)
# Update the existing task ledger instead of creating a second programme.
p=W/'research/paper_international_wave1_wave2/README.md';s=p.read_text()
s=s.replace('| IM-D2 · in_progress |','| IM-D2 · complete_in_source |',1).replace('| IM-D3 · proposed |','| IM-D3 · verified_locally |',1)
anchor='This plan is saved in the incumbent local source carrier, NOT_CANONICALLY_PERSISTED to GitHub because the supported Macro publisher remains unavailable.'
assert s.count(anchor)==1
s=s.replace(anchor,'The final design reset is bound in `research/reference_integrity/intl-country-intelligence-20261020/design_reset_20261103/DESIGN_RESET.md` and `REPORT.json`: 158 focused tests, 20 responsive states across all seven countries, eight workbench selections, 26 unique canonical observations and fresh 128-case shared-theme fixture proof. Initial failures and corrections are retained. Principal image review found no remaining concrete visual blocker in the inspected captures; formal review, production performance/publication and user acceptance remain open.\n\n'+anchor,1);p.write_text(s)
p=W/'agentos/workstreams/WS-PAPER-INTERNATIONAL-WAVES.md';s=p.read_text()
next_action='The user rejected the earlier local polish. The subsequent Paper design reset is complete in source and locally verified; read design_reset_20261103/DESIGN_RESET.md and REPORT.json. Preserve original operation, pending merge and held effects. Restore supported native Macro pending-merge publication, reconcile current main, obtain current-source independent review and hosted full-data CI, resolve shared-header/performance and applicable actual-parent findings, then normal publication and served acceptance. No commit, push, merge or deployment occurred.'
replacement=yaml.safe_dump({'next_action':next_action},sort_keys=False,width=105).rstrip()
s,n=re.subn(r'(?m)^next_action:.*(?:\n[ \t]+[^\n]*)*',lambda m:replacement,s,count=1);assert n==1
new_owned=['mockups/evidence/intl-design-reset-20261103/**','research/reference_integrity/intl-country-intelligence-20261020/design_reset_20261103/**','templates/theme.css','site/theme.css','site/intl_workspace.css']
front=yaml.safe_load(s.split('---',2)[1])
missing=[f for f in new_owned if f not in front['owns_paths']]
s=s.replace('\nwaves:\n','\n'+''.join('- '+f+'\n' for f in missing)+'waves:\n',1)
new_artifacts=[str((D/'DESIGN_RESET.md').relative_to(W)),str((D/'REPORT.json').relative_to(W)),'mockups/evidence/intl-design-reset-20261103/country/EVIDENCE.yml','mockups/evidence/intl-design-reset-20261103/tools/EVIDENCE.yml']
s=s.replace('artifacts:\n','artifacts:\n'+''.join('- '+f+'\n' for f in new_artifacts),1)
s+='\n## 3 November 2026 — design reset after explicit visual rejection\n\nThe preceding local polish was rejected by the Chairman as 4/10 and is not design acceptance. The new reset reads actual Paper R12 and R14 references and recomposes the country research workflow: neutral Paper surfaces, seven-country forecast selection, combined economic/market observations, a full-width growth chart, readable policy/conditions/fiscal content and a discoverable research workbench. Qualified unequal-window returns now align in rows, and an inactive surveillance wrapper no longer leaves a blank band. No specimen facts or new financial owner were introduced.\n\nTested source '+build['source_tree']+' passes 158 focused tests, 20 responsive EN/ZH/theme/width states with all seven countries, five additional native journey groups, eight exact workbench selections and 26 unique canonical observations. Required shared-theme proof was genuinely reminted at the pinned runtime: 128 browser cases/16 screenshots. Source/design/evidence gates pass within their recorded scope. All first failures are retained alongside the corrections.\n\nThe current original-carrier checkpoint is design_reset_20261103/DESIGN_RESET.md and REPORT.json, with complete reproduction inputs and evidence archives. Fresh publication status still refuses NOT_APPLIED; PR9596 remains draft at 851c6ab. The current main, independent review, hosted full-data CI, shared-header cold-load movement/large-DOM performance, actual-parent findings, normal publication and actual served acceptance remain open. No new commit, push, merge, deployment, worker dispatch or Paper mutation occurred. This local checkpoint is not canonical GitHub/AgentOS adoption.\n'
p.write_text(s)
# Put the current recovery instruction at the top of the incumbent checkpoint.
p=W/'research/reference_integrity/intl-country-intelligence-20261020/OWNER_CHECKPOINT.md';s=p.read_text();a=s.find('\n')
block='\n\n## Current recovery — Paper design reset, 3 November 2026\n\nThe user rejected the preceding polish as 4/10. The subsequent reset is implemented and locally verified; use `design_reset_20261103/DESIGN_RESET.md` and `REPORT.json`, plus the 26-observation canonical receipts under `mockups/evidence/intl-design-reset-20261103/`. Tested runtime source tree: `'+build['source_tree']+'`. Ordinary HTML SHA-256: `'+build['html_sha256']+'`. Source hashes match the original worktree; actual emitted theme/workspace CSS copies are synchronized.\n\nIM-D1 reviewed; IM-D2 complete in source; IM-D3 locally verified; IM-D4 blocked. Fresh proof: 158 focused tests, 20 country states/7 countries, 5 native journey groups, 8 exact workbench selections, and 128 pinned shared-theme fixture cases. Prior failures are preserved, including the corrected observer and current-receipt binding. Captured visual quality has principal advisory review; the user has not accepted it.\n\nPreserve operation `intl-country-cockpit-20261018`, branch `sol/web-intl-country-cockpit-20261018`, HEAD `851c6abebf01c5c8096e7822436455fd1040152a` and MERGE_HEAD `c6ac417f4a1d561f8c80a0a6b1977d5ffec6d090`. Fresh read-only publisher status remains REFUSED/NOT_APPLIED/TYPED_GIT_PRECHECK_REFUSED. No source-publication write was attempted. Restore supported Macro pending-merge publication and continue the existing carrier through current-main reconciliation, current-source independent review, hosted full-data CI, shared-header/performance and applicable actual-parent repairs, normal renderer/updater and served acceptance. Held Fabric state remains held; do not retry on NOT_FOUND alone.\n\nThe cold-load issue remains measured: the shared header repositions the initial search/layout, with observed local shift sums about0.738 desktop/0.281 mobile; the page contains428,715 DOM nodes. The record does not claim production-ready performance or completed deployment. This checkpoint is locally saved, NOT_CANONICALLY_PERSISTED to GitHub.\n'
s=s[:a]+block+s[a:];p.write_text(s)
handoff={
 'workstream':'WS:PAPER-INTERNATIONAL-WAVES','session':'sol/web-intl-country-cockpit-20261018','model':'codex','ended_because':'blocked',
 'mission':'Complete the International page to the actual Paper design standard and install through its existing production owner.',
 'state_before':'User rejected the previous local implementation as 4/10; original pending merge and publisher capability block retained.',
 'changed':[{'path':f,'what':'Paper design reset presentation/ordinary generated-asset synchronization; exact bytes in design_reset_20261103/REPORT.json.'} for f in files]+[{'path':str(D.relative_to(W)),'what':'Complete source patch, source files, normal generated page, screenshots, reproducible inputs, proof and failure history.'},{'path':'mockups/evidence/intl-design-reset-20261103/','what':'Canonical rest/interaction receipts from the actual ordinary build.'}],
 'verified':[{'claim':'Source/render behavior of the final presentation.','command':'python -m pytest -q tests/test_intl_country_cockpit.py tests/test_intl_workspace_overview_render.py tests/test_intl_workspace_integration.py tests/test_product_chrome.py','result':'158 passed; actual command/runtime/logs retained.'},{'claim':'Responsive country and research tools journeys on actual generated page.','command':'Run retained intl-design-reset-r3-browser-20261103.py and intl-design-reset-r3-tools-browser-corrected-20261103.py.','result':'20 states across seven countries, five additional journey groups and eight exact value/date/currency selections passed.'},{'claim':'Canonical visual evidence integrity and required shared-theme fixture closure.','command':'Retained canonical capture/package scripts; check_ui_visual_evidence.py; exact-runtime P0B remint, binding recheck and closure guard.','result':'26 unique canonical observations and 128 P0B browser cases/16 screenshots; final source/evidence guards pass. Initial143/144 P0B unit run and targeted corrected binding are disclosed.'},{'claim':'Source custody and publication status remain explicit.','command':'git rev-parse HEAD MERGE_HEAD; git diff --name-only --diff-filter=U; read-only native publication status and GitHub PR/ref GETs.','result':'Original parents retained, no conflicts; publisher REFUSED/NOT_APPLIED; PR9596 open draft at851c6ab; no commit/push/merge/deployment.'}],
 'unverified':[{'claim':'Production-ready performance and full implementation acceptance.','what_would_verify':'Resolve recorded shared-header/large-DOM and applicable actual-parent findings; fresh independent review, hosted CI, actual served journeys and user design acceptance.'},{'claim':'Current main integration, release and durable GitHub adoption.','what_would_verify':'Supported native Macro pending-merge publisher, original-carrier publication, current-main reconciliation, normal renderer/updater and subsequent normal refresh.'}],
 'unresolved':report['remaining'],
 'next_actions':['Recover from design_reset_20261103/DESIGN_RESET.md and REPORT.json in the original registered worktree; inspect current custody before acting.','Restore already authorized native Macro pending-merge publication capability through its existing owner. Do not substitute raw Git or another deployment channel.','Publish the preserved source through PR9596, reconcile current main, obtain exact-candidate review and hosted CI, address recorded performance/actual-parent findings, and verify normal production adoption.'],
 'do_not_redo':['Do not repeat the Paper census or reconstruct the rejected polish; actual R12/R14 references and exact final source are retained.','Do not reset or abort the original pending merge, create another carrier, or overwrite prior proof archives.','Do not retry the held prior Fabric operation on a NOT_FOUND response or count principal advisory image review as formal independent acceptance.'],
 'danger_areas':['Unranked returns use individual calculation windows; specimen R14 values and populations are not live data.','Preserve forecast fiscal-year labels, source dates, missing-data qualification, native disclosures and existing state/Saved owners.','Local successful build and screenshots are not deployment. The native publisher precheck still refuses, and shared-header cold-load performance remains open.'],
 'prs':[9596]}
hp=W/'agentos/handoffs/PAPER-INTERNATIONAL-WAVES-2026-11-03.md';assert not hp.exists();hp.write_text('---\n'+yaml.safe_dump(handoff,sort_keys=False,allow_unicode=True,width=110)+'---\n\nMISSION_COMPLETE: false. The revised implementation is reviewable in the preserved local carrier; publication and production acceptance are blocked. The next assigned receiver inherits the existing operation and custody, not a new execution grant.\n')
# Stage only the owned runtime, proof, required reminted receipts and continuity records.
p0b_changes=subprocess.check_output(['git','diff','--name-only','6a695db8fb1b789b27760de261e472387784cb9a','--','mockups/evidence/prophet-p0b-zero-fouc'],cwd=W,text=True).splitlines()
paths=files+[str(D.relative_to(W)),'mockups/evidence/intl-design-reset-20261103','research/paper_international_wave1_wave2/README.md','research/reference_integrity/intl-country-intelligence-20261020/OWNER_CHECKPOINT.md','agentos/workstreams/WS-PAPER-INTERNATIONAL-WAVES.md',str(hp.relative_to(W))]+p0b_changes
subprocess.run(['git','add','--',*paths],cwd=W,check=True)
summary={'state':'SAVED_AND_STAGED','time':now(),'index_tree':subprocess.check_output(['git','write-tree'],cwd=W,text=True).strip(),'report':str((D/'DESIGN_RESET.md').relative_to(W)),'archives':[{k:v for k,v in a.items() if k!='members'} for a in archives],'runtime_paths':files,'p0b_changed_paths':p0b_changes,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),'merge_head':subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=W,text=True).strip()}
Path('/tmp/intl-design-reset-final-package-20261103.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2),flush=True)
