from pathlib import Path
import hashlib,json,datetime,subprocess
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018')
R=Path('/tmp/intl-design-reset-r2-20261103')
manifest=json.loads((R/'proof/source.json').read_text())
for f,digest in manifest['runtime_hashes'].items():
 assert hashlib.sha256((W/f).read_bytes()).hexdigest()==digest,f
def change(s,a,b):
 assert s.count(a)==1,(a[:160],s.count(a))
 return s.replace(a,b,1)
p=W/'templates/intl_country_cockpit.html.j2';s=p.read_text()
s=change(s,"{{ pair('Data & tools', '数据与工具') }} <span aria-hidden=\"true\">↗</span>","<span class=\"imc-tools-label-full\">{{ pair('Research tools', '研究工具') }}</span><span class=\"imc-tools-label-short\">{{ pair('Tools', '工具') }}</span> <span aria-hidden=\"true\">⌄</span>")
s=change(s,'<p class="imc-outlook-summary">{{ pair(c.outlook.summary_en or c.read_en, c.outlook.summary_zh or c.read_zh) }}</p>','<p class="imc-outlook-summary">{% if c.forecast and c.outlook.chart %}{{ pair(\'Real GDP growth\', \'实际GDP增长\') }} · {{ pair(c.forecast.path_en,c.forecast.path_zh) }}{% else %}{{ pair(c.outlook.summary_en or c.read_en, c.outlook.summary_zh or c.read_zh) }}{% endif %}</p>')
s=change(s,'<div class="imc-outlook-visual">\n                <div class="imc-forecast-path">','<div class="imc-outlook-visual">\n                {% if not c.outlook.chart %}<div class="imc-forecast-path">')
s=change(s,'<p>{{ pair(f.path_en,f.path_zh) }}</p>\n                </div>','<p>{{ pair(f.path_en,f.path_zh) }}</p>\n                </div>{% endif %}')
s=change(s,'              <p class="imc-path-type">{{ pair(\'How the outlook could change\', \'前景可能如何变化\') }}</p>\n','')
p.write_text(s)
p=W/'templates/intl_country_cockpit.css';s=p.read_text()
s=change(s,'.imc-country-rail a:hover{background:var(--panel2);border-color:var(--line)}','.imc-country-rail a:hover{background:var(--panel2);border-color:var(--line);text-decoration:none}')
s=change(s,'.imc-nav .imc-tools-link{margin-left:auto}','.imc-nav .imc-tools-link{margin-left:auto;color:var(--text)}\n.imc-tools-label-short{display:none}')
s=change(s,'.imc-outlook-visual{display:grid;grid-template-columns:minmax(0,.95fr) minmax(0,1.6fr);align-items:center;gap:20px;margin-top:12px}','.imc-outlook-visual{margin-top:12px}')
s=change(s,'.imc-growth-chart{margin:8px 0 12px;max-width:600px}','.imc-growth-chart{margin:16px 0 12px}')
s=change(s,' .imc-outlook-visual{grid-template-columns:minmax(0,.95fr) minmax(0,1.6fr)}\n','')
s=change(s,' .imc-growth-chart{max-width:620px}\n','')
s=change(s,' .imc-growth-chart{margin-inline:-4px}',' .imc-growth-chart{margin-inline:0}')
s=change(s,'.imc-path-type{font-size:var(--fs-label);color:var(--muted);margin-top:4px!important}\n','')
for a,b in [
 ('.imc-world p:not(.imc-kicker){font-size:var(--fs-sm);line-height:1.6;color:var(--muted);','.imc-world p:not(.imc-kicker){font-size:var(--fs-body);line-height:1.6;color:var(--text);'),
 ('.imc-outlook-summary{font-size:var(--fs-sm);color:var(--muted);','.imc-outlook-summary{font-size:var(--fs-body);color:var(--text);'),
 ('.imc-policy-rationale,.imc-policy-decision>p:not(.imc-source-line){color:var(--muted);font-size:var(--fs-sm);','.imc-policy-rationale,.imc-policy-decision>p:not(.imc-source-line){color:var(--text);font-size:var(--fs-body);'),
 ('.imc-balance-row p{font-size:var(--fs-label);color:var(--muted);','.imc-balance-row p{font-size:var(--fs-sm);color:var(--text);'),
 ('.imc-paths section p,.imc-next-test>p:last-child{font-size:var(--fs-sm);line-height:1.65;color:var(--muted);','.imc-paths section p,.imc-next-test>p:last-child{font-size:var(--fs-body);line-height:1.65;color:var(--text);'),
 ('.imc-policy-assessment>p:nth-child(2){font-size:var(--fs-sm);color:var(--muted);','.imc-policy-assessment>p:nth-child(2){font-size:var(--fs-body);color:var(--text);'),
 (' .imc-world p:not(.imc-kicker){font-size:var(--fs-label);line-height:1.65}',' .imc-world p:not(.imc-kicker){font-size:var(--fs-sm);line-height:1.65}'),
 (' .imc-outlook-summary{font-size:var(--fs-label)}',' .imc-outlook-summary{font-size:var(--fs-sm)}')
]:s=change(s,a,b)
s=change(s,'#intl-analysis-tools{max-width:1376px;margin:0 auto 32px;padding:0;border-top:1px solid var(--line);scroll-margin-top:70px}','#intl-analysis-tools{box-sizing:border-box;max-width:1376px;margin:0 auto 32px;padding:0 20px;border:1px solid var(--line);border-radius:var(--r-btn,10px);background:var(--panel);scroll-margin-top:70px}\n#intl-analysis-tools[open]{padding-bottom:20px}\n#intl-analysis-tools>summary:hover{background:var(--panel2)}\n#intl-analysis-tools>summary:focus-visible{outline:2px solid var(--ink-info,var(--info));outline-offset:4px}')
s=change(s,'#intl-analysis-tools>summary{display:flex;justify-content:space-between;align-items:center;min-height:64px;gap:16px;cursor:pointer;font-size:var(--fs-body);font-weight:600;color:var(--text)}','#intl-analysis-tools>summary{display:flex;justify-content:space-between;align-items:center;min-height:64px;gap:16px;cursor:pointer;font-size:var(--fs-body);font-weight:600;color:var(--text);margin-inline:-20px;padding-inline:20px;border-radius:inherit}')
s=change(s,' .imc-nav .imc-tools-link{gap:4px}',' .imc-nav .imc-tools-link{gap:4px}\n .imc-tools-label-full{display:none}.imc-tools-label-short{display:inline}')
p.write_text(s)
p=W/'templates/intl_workspace.css';s=p.read_text()
start=s.index('.intl-overview__first-read--unranked .intl-overview__focus-list { display:grid;')
end=s.index('@media (max-width:390px)',start)
s=s[:start]+'''/* Unranked rows align identity, index, calculation dates and return. */
.intl-overview__first-read--unranked .intl-overview__focus-list { display:block; }
.intl-overview__first-read--unranked .intl-overview__focus-list > li { grid-template-columns:minmax(130px,1fr) minmax(110px,1fr) minmax(220px,1.4fr) minmax(90px,.5fr); align-items:center; gap:var(--fs-body); padding:var(--fs-body) calc(var(--fs-body) * 1.5); }
.intl-overview__first-read--unranked .intl-overview__market-name { grid-column:1; grid-row:1; }
.intl-overview__first-read--unranked .intl-overview__index:not([data-im-return-window]) { grid-column:2; grid-row:1; }
.intl-overview__first-read--unranked .intl-overview__return { grid-column:4; grid-row:1; text-align:end; font-size:var(--fs-md); }
.intl-overview__first-read--unranked [data-im-return-window] { grid-column:3; grid-row:1; font-variant-numeric:tabular-nums; }
@media (max-width:768px) {
  .intl-overview__first-read--unranked .intl-overview__focus-list > li { grid-template-columns:minmax(0,1fr) auto; gap:calc(var(--fs-body) / 2) var(--fs-body); }
  .intl-overview__first-read--unranked .intl-overview__index:not([data-im-return-window]) { grid-column:1; grid-row:2; }
  .intl-overview__first-read--unranked .intl-overview__return { grid-column:2; grid-row:1 / span 2; font-size:var(--fs-h2); }
  .intl-overview__first-read--unranked [data-im-return-window] { grid-column:1 / -1; grid-row:3; }
}
'''+s[end:]
s=change(s,'body.imc-page .intl-inspectors{margin-top:28px}','body.imc-page .intl-workspace>.intl-gs:has(>[data-im-panel]):not(:has(>[data-im-panel]:not([hidden]))){display:none}\nbody.imc-page .intl-inspectors{margin-top:20px}')
p.write_text(s)
# Keep the plain-copy shared asset in sync with the actual ordinary builder output.
theme=R/'source/site/theme.css';assert theme.read_bytes()==(W/'templates/theme.css').read_bytes()
(W/'site/theme.css').write_bytes(theme.read_bytes())
files=list(manifest['runtime_hashes'])+['site/theme.css']
subprocess.run(['git','add','--',*files],cwd=W,check=True)
tree=subprocess.check_output(['git','write-tree'],cwd=W,text=True).strip()
out={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'previous_tree':manifest['tree'],'tree':tree,'files':{f:hashlib.sha256((W/f).read_bytes()).hexdigest() for f in files},'changes':['full_width_primary_chart_with_dated_header_forecast_and_native_values','reading_contrast_and_type_hierarchy','research_tools_discovery','unranked_market_rows','inactive_surveillance_whitespace','mobile_chart_bounds','country_hover','generated_theme_sync']}
Path('/tmp/intl-design-reset-r3-mutation-20261103.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2),flush=True)
