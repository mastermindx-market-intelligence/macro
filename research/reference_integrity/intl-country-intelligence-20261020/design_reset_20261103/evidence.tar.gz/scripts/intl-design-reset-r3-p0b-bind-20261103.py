from pathlib import Path
import datetime,hashlib,json,subprocess
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018');P=Path('/tmp/intl-design-reset-r3-20261103/proof');E=W/'mockups/evidence/prophet-p0b-zero-fouc'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
path=E/'manifest.json';m=json.loads(path.read_text());before={k:v for k,v in m.items() if k!='repair_extension'}
extension=m['repair_extension'];changes=[]
for market,name in [('hk','mobile-layout.json'),('ca','mobile-layout-canada.json')]:
 p=E/name;j=json.loads(p.read_text());assert j['pass'] is True and j['owner_projection_matrix']['pass'] is True
 proof=json.loads((P/('p0b_'+('canada' if market=='ca' else market)+'.json')).read_text());assert proof['state']=='PASS'
 binding=extension['browser_receipts'][market];changes.append({'path':binding['path'],'before':binding['sha256'],'after':sha(p)});binding['sha256']=sha(p)
 assert j['loaded_assets']['site/theme.css']==sha(W/'site/theme.css') if isinstance(j['loaded_assets'].get('site/theme.css'),str) else True
extension['fixture_receipt']['sha256']=sha(E/'rendered-fixture.json')
extension['generated_at']=now()
for row in extension['screenshots']:row['sha256']=sha(W/row['path'])
assert {k:v for k,v in m.items() if k!='repair_extension'}==before
path.write_text(json.dumps(m,indent=2)+'\n')
(P/'p0b_binding_refresh.json').write_text(json.dumps({'time':now(),'changes':changes,'historical_manifest_fields_preserved':True,'actual_browser_receipts_pass':True,'manifest_sha256':sha(path),'scope':'Refresh existing mutable current-proof bindings after genuine remint; immutable historical target and baseline untouched.'},indent=2)+'\n')
def run(name,cmd):
 rec={'state':'RUNNING','command':cmd,'started_at':now()};dst=P/(name+'.json');dst.write_text(json.dumps(rec,indent=2)+'\n')
 with (P/(name+'.log')).open('w') as out:r=subprocess.run(cmd,cwd=W,stdout=out,stderr=subprocess.STDOUT,timeout=240)
 rec.update(state='PASS' if r.returncode==0 else 'FAILED',exit_code=r.returncode,completed_at=now(),log_sha256=sha(P/(name+'.log')));dst.write_text(json.dumps(rec,indent=2)+'\n');print(name,rec['state'],flush=True)
run('p0b_binding_recheck',['/tmp/intl-country-ci-20261103/bin/python','-m','pytest','-q','tests/test_stock_dashboard_first_frame.py::test_visual_manifest_preserves_history_and_appends_bounded_repair','--basetemp=/tmp/intl-design-reset-r3-p0b-binding-pytest-20261103'])
d=P/'closure_changed_paths.txt';d.write_bytes(subprocess.check_output(['git','diff','--name-only','6a695db8fb1b789b27760de261e472387784cb9a'],cwd=W))
run('p0b_closure_final',['/tmp/intl-country-ci-20261103/bin/python','scripts/check_p0b_receipt_closure.py','--diff-file',str(d)])
