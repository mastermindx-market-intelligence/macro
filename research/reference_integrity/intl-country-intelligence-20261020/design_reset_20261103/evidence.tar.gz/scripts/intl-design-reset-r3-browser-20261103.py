from pathlib import Path
from urllib.parse import urlparse
import datetime,functools,hashlib,http.server,json,threading,time,traceback
from playwright.sync_api import sync_playwright
O=Path('/tmp/intl-design-reset-r3-20261103'); SITE=O/'source/site';P=O/'proof';S=P/'screenshots';S.mkdir(exist_ok=True)
class Handler(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(SITE)))
threading.Thread(target=server.serve_forever,daemon=True).start()
url='http://127.0.0.1:'+str(server.server_port)+'/intl.html'
record={'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_tree':json.loads((P/'source.json').read_text())['tree'],'html_sha256':hashlib.sha256((SITE/'intl.html').read_bytes()).hexdigest(),'scope':'Actual ordinary build, genuine retained inputs, local anonymous Chrome; no production claim','states':[],'journeys':[],'screenshots':[]}
def save():(P/'browser.json').write_text(json.dumps(record,indent=2)+'\n')
def frame(page):page.evaluate('new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))')
def shot(page,name,full=False):
 p=S/(name+'.png');page.screenshot(path=str(p),full_page=full);d={'path':'screenshots/'+p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()};record['screenshots'].append(d);return d
def ctx_for(browser,width,theme,lang,js=True):
 c=browser.new_context(viewport={'width':width,'height':1000 if width>=1024 else 844},device_scale_factor=1,java_script_enabled=js)
 c.route('**/*',lambda r:r.continue_() if urlparse(r.request.url).hostname=='127.0.0.1' else r.abort())
 if js:c.add_init_script("localStorage.setItem('theme',"+json.dumps(theme)+");localStorage.setItem('lang',"+json.dumps(lang)+");localStorage.removeItem('themeAuto');")
 return c
def metrics(page):
 return page.evaluate("""()=>{const b=s=>{const e=document.querySelector(s);if(!e)return null;const r=e.getBoundingClientRect();return{x:r.x,y:r.y,width:r.width,height:r.height,right:r.right,bottom:r.bottom}};const root=document.querySelector('.imc-country[open]');return{width:innerWidth,scrollWidth:document.documentElement.scrollWidth,theme:document.documentElement.dataset.theme,lang:document.documentElement.dataset.lang,bg:getComputedStyle(document.body).backgroundColor,text:getComputedStyle(document.body).color,before:getComputedStyle(document.body,'::before').content,visibleCountries:[...document.querySelectorAll('.imc-country')].filter(e=>e.getBoundingClientRect().height>0).length,toolbar:b('.imc-toolbar'),slot:b('.imc-assistant-slot'),world:b('.imc-world'),country:b('.imc-country[open]'),outlook:b('.imc-country[open] .imc-outlook-panel'),chart:b('.imc-country[open] .imc-growth-chart'),policy:b('.imc-country[open] .imc-policy-decision'),paths:b('.imc-country[open] .imc-paths'),balance:b('.imc-country[open] .imc-balances'),links:[...document.querySelectorAll('.imc-nav a')].map(e=>{const r=e.getBoundingClientRect();return{x:r.x,y:r.y,right:r.right,height:r.height,width:r.width,scrollWidth:e.scrollWidth,clientWidth:e.clientWidth}}),rails:[...document.querySelectorAll('.imc-country-rail a')].map(e=>({cc:e.dataset.imcCountry,width:e.clientWidth,scrollWidth:e.scrollWidth})),panelOverflow:root?[...root.querySelectorAll('.imc-outlook-visual,.imc-forecast-path,.imc-policy-value,.imc-market-grid,.imc-vitals')].map(e=>({name:e.className,width:e.clientWidth,scrollWidth:e.scrollWidth})):[]}}""")
save()
try:
 with sync_playwright() as pw:
  browser=pw.chromium.launch(channel='chrome',headless=True);record['browser']=browser.version
  for theme,lang in [('light','en'),('dark','en'),('light','zh'),('dark','zh')]:
   ctx=ctx_for(browser,1440,theme,lang);page=ctx.new_page();errors=[];failed=[]
   page.on('pageerror',lambda e:errors.append(str(e)))
   page.on('response',lambda r:failed.append({'url':r.url,'status':r.status}) if r.status>=400 else None)
   page.goto(url,wait_until='domcontentloaded',timeout=60000);page.locator('.imc-country[open] .imc-outlook-panel').wait_for(state='visible');page.evaluate('document.fonts.ready');frame(page)
   for width in [1440,1024,768,390,320]:
    name=f'{width}-{theme}-{lang}';row={'name':name,'checks':[]};record['states'].append(row)
    try:
     page.set_viewport_size({'width':width,'height':1000 if width>=1024 else 844});frame(page)
     page.locator('.imc-country-rail [data-imc-country="KR"]').click();frame(page);page.evaluate('scrollTo(0,0)');frame(page)
     m=metrics(page);row['metrics']=m
     assert m['scrollWidth']<=width+1,m
     assert m['bg']==('rgb(247, 248, 250)' if theme=='light' else 'rgb(15, 17, 21)'),m
     assert m['before']=='none',m
     assert m['theme']==theme and m['lang']==lang,m
     assert m['visibleCountries']==1,m
     assert len(m['links'])==3 and all(l['height']>=44 for l in m['links']),m
     assert max(l['y'] for l in m['links'])-min(l['y'] for l in m['links'])<2,m
     assert max(l['right'] for l in m['links'])<=m['slot']['x']-3,m
     assert all(r['scrollWidth']<=r['width']+1 for r in m['rails']),m['rails']
     assert all(r['scrollWidth']<=r['width']+2 for r in m['panelOverflow']),m['panelOverflow']
     row['checks'].append('Paper_palette_single_country_no_overflow_compact_nav_all_forecast_labels')
     shot(page,name)
     if width in [1440,390]:shot(page,name+'-full',True)
     for cc in ['JP','TW','IN','AU','GB','EZ','KR']:
      page.locator('.imc-country-rail [data-imc-country="'+cc+'"]').click();frame(page)
      target=page.locator('#imc-country-'+cc)
      assert target.get_attribute('open') is not None,cc
      assert page.locator('.imc-country[open]').count()==1,cc
      assert target.locator(':scope > summary').evaluate('e=>e===document.activeElement'),cc
      q=page.evaluate("""cc=>{const r=document.querySelector('.imc-country-rail'),a=r.querySelector('[data-imc-country="'+cc+'"]'),rb=r.getBoundingClientRect(),ab=a.getBoundingClientRect();return{current:a.getAttribute('aria-current'),left:ab.left,right:ab.right,railLeft:rb.left,railRight:rb.right,doc:document.documentElement.scrollWidth}}""",cc)
      assert q['current']=='location' and q['left']>=q['railLeft']-1 and q['right']<=q['railRight']+1,q
      assert q['doc']<=width+1,q
      t=target.locator('.imc-chart-values');summary=t.locator(':scope>summary')
      summary.focus();summary.press('Enter');frame(page)
      assert t.get_attribute('open') is not None and summary.evaluate('e=>e===document.activeElement')
      observed=t.locator('tbody tr').evaluate_all('rows=>rows.map(r=>[r.children[0].innerText,r.children[1].innerText,r.children[2].innerText])')
      years=target.locator('.imc-chart-year').all_text_contents();values=target.locator('.imc-chart-value').all_text_contents()
      assert [r[0] for r in observed]==years,(cc,observed,years)
      assert [r[1] for r in observed]==[x+'%' for x in values],(cc,observed,values)
      assert any(r[2] in ['Projection','预测'] for r in observed) and any(r[2] in ['Published history','机构历史数据'] for r in observed),observed
      summary.press('Enter');frame(page);assert t.get_attribute('open') is None
      if width==1440 and theme=='light' and lang=='en' and cc in ['GB','TW']:
       target.scroll_into_view_if_needed();shot(page,'1440-light-en-'+cc)
      row['checks'].append('country_'+cc+'_selection_focus_chart_source_values')
     row.update(state='PASS',errors=list(errors),failed_resources=list(failed));assert not errors and not failed,(errors,failed)
    except Exception as e:
     row.update(state='FAILED',error=str(e),trace=traceback.format_exc());shot(page,name+'-failure');print(name,'FAILED',str(e)[:1000],flush=True);save();raise
    print(name,row['state'],flush=True);save()
   # Closing the selected native disclosure restores the complete country list.
   page.locator('.imc-country[open]>summary').click();frame(page)
   assert page.locator('.imc-country[open]').count()==0
   visible=page.locator('.imc-country').evaluate_all('es=>es.filter(e=>e.getBoundingClientRect().height>0).length')
   assert visible==7,visible
   page.locator('#imc-country-JP>summary').click();frame(page)
   assert page.locator('#imc-country-JP').get_attribute('open') is not None
   # Native history restores selected-country context.
   page.locator('.imc-country-rail [data-imc-country="TW"]').click()
   page.locator('.imc-country-rail [data-imc-country="GB"]').click()
   page.go_back(wait_until='domcontentloaded');frame(page)
   assert page.locator('#imc-country-TW').get_attribute('open') is not None
   # Responsive reading order matches DOM and keyboard order.
   order=page.locator('#imc-country-TW .imc-country-grid').evaluate('e=>[...e.children].map(x=>x.className)')
   assert order==['imc-outlook-panel','imc-policy-decision','imc-paths','imc-balances'],order
   record['journeys'].append({'theme':theme,'lang':lang,'state':'PASS','checks':['close_restores_native_country_list','country_history_restore','mobile_DOM_reading_order']});save()
   ctx.close()
  # No JavaScript still exposes every native country, forecast and evidence table.
  ctx=ctx_for(browser,390,'dark','en',False);page=ctx.new_page();page.goto(url,wait_until='load');page.evaluate('document.fonts.ready')
  for cc in ['JP','KR','TW','IN','AU','GB','EZ']:
   d=page.locator('#imc-country-'+cc)
   if d.get_attribute('open') is None:d.locator(':scope>summary').click()
   assert d.locator('.imc-outlook-panel').is_visible()
   d.locator('.imc-chart-values>summary').click();assert d.locator('.imc-chart-values tbody').is_visible()
  assert page.evaluate('document.documentElement.scrollWidth')<=391
  record['journeys'].append({'state':'PASS','checks':['no_javascript_seven_native_countries_and_exact_chart_tables']});save();ctx.close()
  browser.close()
 record['state']='PASS'
except Exception as e:record.update(state='FAILED',error=str(e))
finally:
 record['completed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();server.shutdown()
 print('FINAL',record['state'],flush=True)
