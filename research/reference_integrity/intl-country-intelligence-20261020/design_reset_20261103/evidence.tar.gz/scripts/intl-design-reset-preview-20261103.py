from pathlib import Path
from urllib.parse import urlparse
import datetime,functools,hashlib,http.server,json,threading,time,traceback
from playwright.sync_api import sync_playwright
O=Path('/tmp/intl-design-reset-20261103'); SITE=O/'source/site'; P=O/'preview';P.mkdir(exist_ok=True)
class Handler(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(SITE)))
threading.Thread(target=server.serve_forever,daemon=True).start()
url='http://127.0.0.1:'+str(server.server_port)+'/intl.html'
record={'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'html_sha256':hashlib.sha256((SITE/'intl.html').read_bytes()).hexdigest(),'states':[]}
with sync_playwright() as pw:
 browser=pw.chromium.launch(channel='chrome',headless=True)
 for width,theme,lang in [(1440,'light','en'),(1440,'dark','en'),(390,'light','en'),(390,'dark','zh')]:
  row={'width':width,'theme':theme,'lang':lang,'errors':[]};name=f'{width}-{theme}-{lang}'
  ctx=browser.new_context(viewport={'width':width,'height':1000 if width==1440 else 844},device_scale_factor=1)
  ctx.route('**/*',lambda r:r.continue_() if urlparse(r.request.url).hostname=='127.0.0.1' else r.abort())
  ctx.add_init_script("localStorage.setItem('theme',"+json.dumps(theme)+");localStorage.setItem('lang',"+json.dumps(lang)+");localStorage.removeItem('themeAuto');")
  page=ctx.new_page();page.on('pageerror',lambda e:row['errors'].append(str(e)))
  try:
   start=time.monotonic();page.goto(url,wait_until='domcontentloaded',timeout=60000)
   page.locator('.imc-country[open] .imc-outlook-panel').wait_for(state='visible');page.evaluate('document.fonts.ready');page.wait_for_timeout(250)
   row['load_seconds']=round(time.monotonic()-start,2)
   row['metrics']=page.evaluate("""()=>{const b=s=>{const e=document.querySelector(s),r=e.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,bottom:r.bottom,right:r.right};};const c=getComputedStyle(document.body);return {scrollWidth:document.documentElement.scrollWidth,width:innerWidth,bodyBg:c.background,bodyBgToken:c.getPropertyValue('--bg'),bodyBefore:getComputedStyle(document.body,'::before').content,main:b('.imc'),country:b('.imc-country[open]'),outlook:b('.imc-country[open] .imc-outlook-panel'),policy:b('.imc-country[open] .imc-policy-decision'),path:b('.imc-country[open] .imc-paths'),strip:b('.imc-reading-strip'),visibleCountries:[...document.querySelectorAll('.imc-country')].filter(e=>e.getBoundingClientRect().height).length,theme:document.documentElement.dataset.theme,lang:document.documentElement.dataset.lang}}""")
   page.screenshot(path=str(P/(name+'.png')))
   page.screenshot(path=str(P/(name+'-full.png')),full_page=True)
   row['state']='PASS'
  except Exception as e:row.update(state='FAILED',error=str(e))
  record['states'].append(row);(P/'preview.json').write_text(json.dumps(record,indent=2)+'\n');print(name,row['state'],row.get('metrics',{}),flush=True);ctx.close()
 browser.close()
server.shutdown()
