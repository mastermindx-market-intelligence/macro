from pathlib import Path
import hashlib,json,subprocess,datetime
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018')
O=Path('/tmp/intl-design-reset-20261103'); O.mkdir(exist_ok=True)
run=lambda args:subprocess.check_output(args,cwd=W,text=True).strip()
assert run(['git','rev-parse','HEAD'])=='851c6abebf01c5c8096e7822436455fd1040152a'
assert run(['git','rev-parse','MERGE_HEAD'])=='c6ac417f4a1d561f8c80a0a6b1977d5ffec6d090'
assert run(['git','write-tree'])=='6a695db8fb1b789b27760de261e472387784cb9a'
plan=W/'research/paper_international_wave1_wave2/README.md'
s=plan.read_text()
marker='## Design reset — 3 November 2026'
assert marker not in s
block="""## Design reset — 3 November 2026

The current Chairman explicitly rejected the previous local design as 4/10. Prior green tests establish recorded behavior only; the visual/product result is REJECTED_BY_DESIGN. No previous local preview was deployed. This continues the original country-cockpit operation, branch and PR9596, preserving the pending two-parent merge.

Protected procedure is pinned at Mastermind e39a617b6771cb6b07323a533b4cf9db7e78900a. The required procedure paths have no Git delta from the verified b4a5a89 pin. Paper file 01M3P1TW5Y3XWQC37ADDS8K5AG was freshly read: R12 Country Intelligence p-G-0 (DW7-0/DMX-0), and R14 Global Surveillance p-I-0 (G9J-0/GWG-0/IRV-0). R14 supplies visual composition guidance, not permission to publish its specimen data or replace the country-centered product job.

| Task | Dependency | Work and DONE_WHEN | Evidence/review |
| --- | --- | --- | --- |
| IM-D1 · reviewed | Current source and design identity | Reassess actual Paper screenshots against the rejected implementation; identify hierarchy, palette, density and workflow defects | Fresh native screenshots/JSX, exact source baseline; principal advisory design judgment |
| IM-D2 · in_progress | IM-D1 | Recompose the country workflow using a compact seven-country outlook strip, visible observation band, balanced forecast/policy/conditions columns, restrained shared tokens, responsive tools discovery | Actual ordinary build, reviewed desktop/mobile images; no invented financial outputs |
| IM-D3 · proposed | IM-D2 | Verify country selection, real dates/values, evidence, deep links, keyboard, no-JS, resize, EN/ZH and dark/light; fix material findings | Focused source tests and real browser captures, preserving initial failures |
| IM-D4 · blocked | IM-D3 plus publication capability | Independent source review, supported Macro pending-merge publisher, current-main reconciliation, hosted CI and real served adoption | Original publisher gate is unchanged; no raw-Git or alternate-writer bypass |

The same principal retains source/design integration for PRINCIPAL_JUDGMENT and UNIQUE_APPROVED_ACCESS. The native advisory child supplies architectural critique only, not paid-provider labor or formal approval. WHY NOT FABLE: this is a bounded visual/product decision and existing-carrier implementation; no separate scarce-principal continuity is required. The held prior Fabric attempt is not retried.

This plan is saved in the incumbent local source carrier, NOT_CANONICALLY_PERSISTED to GitHub because the supported Macro publisher remains unavailable. That release dependency does not block permitted design/source work. Prior proof archives remain immutable. Current recovery remains on WS:PAPER-INTERNATIONAL-WAVES and OWNER_CHECKPOINT.md.

"""
s=s.replace('\n## Acceptance is the user journey','\n'+block+'## Acceptance is the user journey',1);plan.write_text(s)
owner=W/'research/reference_integrity/intl-country-intelligence-20261020/OWNER_CHECKPOINT.md'
owner.write_text("""# Active design reset — 3 November 2026

The Chairman rejects the previous design as 4/10. Resume the IM-D1 through IM-D4 task tree in research/paper_international_wave1_wave2/README.md. The previous POLISH evidence is historical behavior proof, not visual acceptance. Fresh Paper R12 and R14 screenshots were inspected. Substantially recompose the country page, then judge actual browser images before release claims. Original operation/branch/HEAD/MERGE_HEAD and publisher/worker fences remain intact. No new source publication or deployment has occurred.

---

"""+owner.read_text())
print(json.dumps({'plan_path':str(plan),'plan_sha256':hashlib.sha256(plan.read_bytes()).hexdigest(),'owner_sha256':hashlib.sha256(owner.read_bytes()).hexdigest(),'readback':marker in plan.read_text(),'publication':'NOT_CANONICALLY_PERSISTED','time':datetime.datetime.now(datetime.timezone.utc).isoformat()}))
