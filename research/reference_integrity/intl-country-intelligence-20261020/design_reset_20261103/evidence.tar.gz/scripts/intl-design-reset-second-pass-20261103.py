from pathlib import Path
import json,hashlib
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018')
T=W/'templates/intl_country_cockpit.html.j2';s=T.read_text()
intro='''      <p class="imc-intro">{{ pair('Country outlooks, policy decisions and the forces moving markets.', '国家展望、政策决定与市场背后的驱动力。') }}</p></div>'''
assert intro in s;s=s.replace(intro,'</div>',1)
s=s.replace("{{ pair('Economy · Policy · Markets', '经济 · 政策 · 市场') }}","{{ pair('GDP growth forecasts · Select an economy', 'GDP增长预测 · 选择经济体') }}",1)
# Put forecast figures and their exact source chart on one visual row.
needle='''                <div class="imc-forecast-path">'''
assert needle in s;s=s.replace(needle,'''                <div class="imc-outlook-visual">
'''+needle,1)
needle='''                </figure>
                <details class="imc-chart-values">'''
assert needle in s;s=s.replace(needle,'''                </figure>
                {% endif %}
                </div>
                {% if c.outlook.chart %}{% set chart = c.outlook.chart %}
                <details class="imc-chart-values">''',1)
# Country body grid follows the same reading order on mobile and keyboard.
a=s.index('              {% if c.outlook.balances %}')
b=s.index('\n            </div>\n            <div class="imc-side-column">',a)
balances=s[a:b]
s=s[:a]+s[b:]
s=s.replace('            <div class="imc-main-column">\n','',1)
s=s.replace('\n            </div>\n            <div class="imc-side-column">\n','\n',1)
s=s.replace('            </aside>\n            </div>\n          </div>','            </aside>\n'+balances+'\n          </div>',1)
# Keep the concise market interpretation across the full observation band.
a=s.index('                {% if c.outlook.market_divergence_en %}')
b=s.index('              </section>',a)
notes=s[a:b];s=s[:a]+s[b:]
needle='''          </div>
          <div class="imc-country-grid">'''
assert needle in s;s=s.replace(needle,'''            <div class="imc-market-notes">
'''+notes+'''            </div>
          </div>
          <div class="imc-country-grid">''',1)
T.write_text(s)
C=W/'templates/intl_country_cockpit.css';s=C.read_text()
s=s.replace('--bg:inherit;--panel:inherit;--panel2:inherit;--text:inherit;--muted:inherit;', '--bg:var(--imc-canvas);--panel:var(--imc-surface);--panel2:var(--imc-raised);--text:var(--imc-text);--muted:var(--imc-muted);--line:var(--imc-rule);')
s=s.replace('.imc-page .site-nav{background:var(--panel);border-bottom:1px solid var(--line-quiet,var(--line));margin:0;padding-block:12px;box-shadow:none}', 'body.imc-page nav.site-nav{background:var(--panel);border-bottom:1px solid var(--line-quiet,var(--line));margin:0;padding:12px 32px;box-shadow:none}')
s=s.replace('padding:24px 32px 32px','padding:20px 32px 32px',1)
s=s.replace('margin-bottom:20px}\n.imc-masthead h1','margin-bottom:16px}\n.imc-masthead h1',1)
s=s.replace('margin-bottom:18px}\n.imc-toolbar','margin-bottom:14px}\n.imc-toolbar',1)
s=s.replace('gap:32px;padding:20px 24px;border:','gap:32px;padding:16px 20px;border:',1)
s=s.replace('padding:12px;border:1px solid var(--line-quiet,var(--line));border-radius:var(--r-ctl,8px);background:var(--panel);color:var(--text);','padding:10px 12px;border:1px solid var(--line-quiet,var(--line));border-radius:var(--r-ctl,8px);background:var(--panel);color:var(--text);',1)
s=s.replace('gap:24px;padding:18px 20px;background:var(--bg);','gap:12px 24px;padding:16px 20px;background:var(--bg);',1)
s=s.replace('.imc-country-grid{display:grid;grid-template-columns:minmax(0,1.6fr) minmax(0,1fr);gap:20px;align-items:start}\n.imc-main-column,.imc-side-column{display:grid;gap:20px;min-width:0}', '''.imc-country-grid{display:grid;grid-template-columns:minmax(0,1.6fr) minmax(0,1fr);gap:20px;align-items:start}
.imc-country-grid>.imc-outlook-panel{grid-column:1;grid-row:1/3}
.imc-country-grid>.imc-policy-decision{grid-column:2;grid-row:1}
.imc-country-grid>.imc-paths{grid-column:2;grid-row:2/4}
.imc-country-grid>.imc-balances{grid-column:1;grid-row:3}
.imc-country-grid:not(:has(>.imc-policy-decision))>.imc-paths{grid-row:1/4}
.imc-market-notes{grid-column:1/-1;padding-top:10px;border-top:1px solid var(--line-quiet,var(--line))}
.imc-market-notes .imc-market-divergence{margin-top:0!important}
.imc-market-notes .imc-market-explanation{margin-top:3px!important}
.imc-outlook-visual{display:grid;grid-template-columns:minmax(0,.95fr) minmax(0,1.6fr);align-items:center;gap:20px;margin-top:12px}''')
s=s.replace('grid-template-columns:1fr 60px 1fr minmax(110px,1fr);align-items:center;gap:16px;margin:20px 0 12px','grid-template-columns:1fr 32px 1fr;align-items:center;gap:12px;margin:12px 0',1)
s=s.replace('line-height:1.6;border-left:1px solid var(--line);padding-left:16px}\n.imc-growth-chart','line-height:1.6;grid-column:1/-1;border-top:1px solid var(--line-quiet,var(--line));padding-top:10px}\n.imc-growth-chart',1)
s=s.replace('font:500 12px var(--font-ui)','font:500 14px var(--font-ui)',1)
s=s.replace('font:11px var(--font-ui)','font:12px var(--font-ui)',1)
s=s.replace(' .imc-country-grid{grid-template-columns:1fr}\n .imc-side-column{grid-template-columns:minmax(0,1fr) minmax(0,1fr);align-items:start}', ''' .imc-country-grid{grid-template-columns:repeat(2,minmax(0,1fr))}
 .imc-country-grid>.imc-outlook-panel{grid-column:1/-1;grid-row:1}
 .imc-country-grid>.imc-policy-decision{grid-column:1;grid-row:2}
 .imc-country-grid>.imc-paths{grid-column:2;grid-row:2/4}
 .imc-country-grid>.imc-balances{grid-column:1;grid-row:3}
 .imc-country-grid:not(:has(>.imc-policy-decision))>.imc-paths{grid-column:2;grid-row:2/4}
 .imc-outlook-visual{grid-template-columns:minmax(0,.95fr) minmax(0,1.6fr)}''')
s=s.replace(' .imc-forecast-path{grid-template-columns:1fr 60px 1fr minmax(110px,1fr)}\n .imc-forecast-path>p{grid-column:auto;border-left:1px solid var(--line);padding-left:16px}', ' .imc-forecast-path{grid-template-columns:1fr 32px 1fr}\n .imc-forecast-path>p{grid-column:1/-1;border-left:0;padding:10px 0 0}',1)
s=s.replace(' .imc-page .site-nav{padding-block:8px}',' body.imc-page nav.site-nav{padding:8px 16px}',1)
s=s.replace(' .imc-country-grid,.imc-main-column,.imc-side-column{gap:16px}\n .imc-side-column{grid-template-columns:1fr}', ''' .imc-country-grid{display:flex;flex-direction:column;gap:16px}
 .imc-country-grid>section,.imc-country-grid>aside{width:100%}
 .imc-outlook-visual{display:block;margin-top:0}''')
s=s.replace(' .imc-reading-strip{grid-template-columns:1fr;gap:16px;',' .imc-reading-strip{grid-template-columns:1fr;gap:12px;',1)
s=s.replace(' .imc-market-divergence{font-size:var(--fs-label);line-height:1.6}',' .imc-market-divergence{font-size:var(--fs-label);line-height:1.6}\n .imc-market-notes{padding-top:12px}',1)
C.write_text(s)
theme=W/'templates/theme.css';s=theme.read_text()
assert '--imc-canvas:' not in s
s+="""

/* International research surfaces from Paper R12/R14.
   Dedicated aliases preserve this page's approved paper/ink palette when the
   shared soft-contrast preference rebinds the estate's generic --bg/--text.
   Other pages do not consume these tokens. */
:root{
  --imc-canvas:#0f1115;--imc-surface:#181b21;--imc-raised:#1e222a;
  --imc-text:#d7dce3;--imc-muted:#8b93a1;--imc-rule:#3a4150;
}
html[data-theme="light"]{
  --imc-canvas:#f7f8fa;--imc-surface:#ffffff;--imc-raised:#eef1f6;
  --imc-text:#1c2430;--imc-muted:#5d6b7e;--imc-rule:#c9ccd1;
}
"""
theme.write_text(s)
print(json.dumps({str(p.relative_to(W)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [T,C,theme]}))
