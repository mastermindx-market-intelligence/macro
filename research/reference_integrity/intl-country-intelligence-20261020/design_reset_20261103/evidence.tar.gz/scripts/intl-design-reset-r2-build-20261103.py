from pathlib import Path
import concurrent.futures,datetime,hashlib,json,os,shutil,subprocess,tarfile
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018')
B=Path('/tmp/intl-paper-polish-final-20261103');C=Path('/tmp/intl-paper-current-complete-20261103');A=Path('/tmp/intl-design-reset-20261103')
O=Path('/tmp/intl-design-reset-r2-20261103');assert not O.exists();O.mkdir();P=O/'proof';P.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
css=W/'templates/intl_country_cockpit.css';s=css.read_text().replace(' .imc-forecast-path{grid-template-columns:1fr 48px 1fr;gap:12px}',' .imc-forecast-path{grid-template-columns:1fr 48px 1fr;gap:12px}\n .imc-forecast-path strong{font-size:var(--fs-h1)}',1);css.write_text(s)
files=['templates/intl_country_cockpit.html.j2','templates/intl_country_cockpit.css','templates/intl.html.j2','templates/intl_workspace.css','templates/intl_workspace/shell.html.j2','templates/theme.css']
subprocess.run(['git','add','--',*files],cwd=W,check=True)
tree=subprocess.check_output(['git','write-tree'],cwd=W,text=True).strip()
base='098acfbf132af6e2b9c836cca3596e3ef9a4e1dc'
delta=subprocess.check_output(['git','diff','--name-only',base,tree],cwd=W,text=True).splitlines();assert set(delta)==set(files),delta
source={'tree':tree,'base_tree':base,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),'merge_head':subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=W,text=True).strip(),'runtime_hashes':{f:sha(W/f) for f in files},'delta':delta,'time':now()}
(P/'source.json').write_text(json.dumps(source,indent=2)+'\n')
diff=P/'source.diff';diff.write_bytes(subprocess.check_output(['git','diff','--unified=0','6a695db8fb1b789b27760de261e472387784cb9a',tree,'--',*files],cwd=W))
def run(name,cmd,cwd=W,env=None,timeout=240):
 rec={'state':'RUNNING','command':cmd,'cwd':str(cwd),'started_at':now()};path=P/(name+'.json');path.write_text(json.dumps(rec,indent=2)+'\n')
 with (P/(name+'.log')).open('w') as log:
  try:
   r=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout);rec.update(state='PASS' if r.returncode==0 else 'FAILED',exit_code=r.returncode)
  except subprocess.TimeoutExpired:rec.update(state='TIMED_OUT')
 rec.update(completed_at=now(),log_sha256=sha(P/(name+'.log')));path.write_text(json.dumps(rec,indent=2)+'\n');print(name,rec['state'],flush=True);return rec
def build():
 archive=A/'source.tar';assert sha(archive)=='54ac0178e91f6ae634b88c66b0f8523c8418ea1465f689dbfbad71924dd3e89e'
 runtime=O/'source';runtime.mkdir()
 with tarfile.open(archive) as t:t.extractall(runtime,filter='data')
 for f in files:
  raw=subprocess.check_output(['git','show',tree+':'+f],cwd=W);assert hashlib.sha256(raw).hexdigest()==source['runtime_hashes'][f];(runtime/f).write_bytes(raw)
 inputs=C/'committed-inputs.tar';assert sha(inputs)=='e0ab64bc8e180d781e6d0a3705c3d93a0568df1acf8213f5abde96dbc577676a'
 with tarfile.open(inputs) as t:t.extractall(runtime,filter='data')
 manifest=json.loads((C/'proof/input_manifest.json').read_text())
 for row in manifest['files']:assert sha(runtime/row['path'])==row['sha256'],row['path']
 shutil.copyfile(C/'proof/input_manifest.json',P/'input_manifest.json')
 assets=json.loads((B/'proof/shared_static_assets.json').read_text())
 for row in assets['files']:
  raw=(B/'source'/row['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['sha256'];target=runtime/row['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
 env=os.environ.copy()
 for k in ['PYTHONPATH','COLLECT_LANE','US_LANE']:env.pop(k,None)
 r=run('ordinary_build',['/tmp/intl-country-ci-20261103/bin/python','-m','scripts.build_intl'],cwd=runtime,env=env,timeout=600)
 r.update(source_tree=tree,base_tree=base,base_archive_sha256=sha(archive),exact_source_overlay=source['runtime_hashes'],input_commit=manifest['commit'],committed_inputs=511,input_archive_sha256=sha(inputs),no_reacquisition=True,no_production_mutation=True)
 if (runtime/'site/intl.html').exists():r.update(html_sha256=sha(runtime/'site/intl.html'),html_bytes=(runtime/'site/intl.html').stat().st_size)
 (P/'ordinary_build.json').write_text(json.dumps(r,indent=2)+'\n')
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 jobs=[pool.submit(build),pool.submit(run,'focused_tests',['/tmp/intl-country-ci-20261103/bin/python','-m','pytest','-q','tests/test_intl_country_cockpit.py','tests/test_intl_workspace_overview_render.py','tests/test_intl_workspace_integration.py','tests/test_product_chrome.py','--basetemp=/tmp/intl-design-reset-r2-pytest-20261103']),pool.submit(run,'design_added',['/tmp/intl-country-ci-20261103/bin/python','scripts/check_design_system.py','--mode','enforce-added','--diff-file',str(diff)])]
 for job in jobs:job.result()
