"""Verify the actual refined ordinary build, including presentation and native fallbacks."""
from pathlib import Path
from urllib.parse import urlparse
import datetime, functools, hashlib, http.server, json, threading, time, traceback
from playwright.sync_api import sync_playwright

ROOT=Path("/tmp/intl-paper-polish-r2-20261103")
OUT=ROOT/"proof"
SHOTS=OUT/"screenshots"
SHOTS.mkdir(exist_ok=True)
SITE=ROOT/"source/site"
BASE=Path("/tmp/intl-paper-build-20261103/source/site")
class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*args): pass
servers=[]
def serve(path):
    s=http.server.ThreadingHTTPServer(("127.0.0.1",0),functools.partial(QuietHandler,directory=str(path)))
    threading.Thread(target=s.serve_forever,daemon=True).start()
    servers.append(s)
    return "http://127.0.0.1:"+str(s.server_port)+"/intl.html"
url=serve(SITE)
baseurl=serve(BASE)
record={"schema":"intl.polish_browser.v1","started_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "source_tree":json.loads((OUT/"source.json").read_text())["tree"],
        "html_sha256":hashlib.sha256((SITE/"intl.html").read_bytes()).hexdigest(),
        "scope":"Actual ordinary build, same 510 committed production inputs; anonymous local Chrome; not production or a real Terminal parent",
        "states":[],"journeys":[],"baseline":[],"screenshots":[]}
def save(): (OUT/"polish_browser.json").write_text(json.dumps(record,indent=2)+"\n")
def route(r):
    if urlparse(r.request.url).hostname=="127.0.0.1": r.continue_()
    else: r.abort()
def context_for(browser,width,theme,lang,javascript=True,reduced=None):
    opts={"viewport":{"width":width,"height":1000 if width==1440 else 844},"device_scale_factor":1,"java_script_enabled":javascript}
    if reduced: opts["reduced_motion"]=reduced
    ctx=browser.new_context(**opts);ctx.route("**/*",route)
    if javascript:
        ctx.add_init_script("localStorage.setItem('theme',"+json.dumps(theme)+");localStorage.setItem('lang',"+json.dumps(lang)+");localStorage.removeItem('themeAuto');")
    return ctx
def ready(page,target=url):
    start=time.monotonic()
    page.goto(target,wait_until="domcontentloaded",timeout=60000)
    page.locator(".imc-country[open] .imc-outlook-panel").wait_for(state="visible",timeout=20000)
    page.evaluate("document.fonts.ready")
    page.wait_for_timeout(220)
    return round(time.monotonic()-start,3)
def frame(page):
    page.evaluate("new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))")
def metrics(page):
    return page.evaluate("""() => {
      const b=s=>{const x=document.querySelector(s);if(!x)return null;const r=x.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,bottom:r.bottom,right:r.right};};
      return {width:innerWidth,scrollWidth:document.documentElement.scrollWidth,theme:document.documentElement.dataset.theme,lang:document.documentElement.dataset.lang,
       toolbar:b('.imc-toolbar'),nav:b('.imc-nav'),slot:b('.imc-assistant-slot'),country:b('.imc-country[open]'),forecast:b('.imc-country[open] .imc-row-forecast'),outlook:b('.imc-country[open] .imc-outlook-panel'),
       links:Array.from(document.querySelectorAll('.imc-nav a')).map(x=>{const r=x.getBoundingClientRect();return {text:x.innerText,x:r.x,y:r.y,right:r.right,height:r.height,width:r.width,scrollWidth:x.scrollWidth,clientWidth:x.clientWidth,current:x.getAttribute('aria-current')};})};
    }""")
def shot(page,name,full=False):
    p=SHOTS/(name+".png");page.screenshot(path=str(p),full_page=full)
    item={"name":name,"path":"screenshots/"+p.name,"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}
    record["screenshots"].append(item);return item
def rail(page,cc):
    return page.evaluate("""cc=>{
      const r=document.querySelector('.imc-country-rail'), a=r.querySelector('[data-imc-country="'+cc+'"]'), rb=r.getBoundingClientRect(),ab=a.getBoundingClientRect();
      return {current:a.getAttribute('aria-current'),left:ab.left,right:ab.right,railLeft:rb.left,railRight:rb.right,scrollLeft:r.scrollLeft};
    }""",cc)
def assert_rail(v):
    assert v["current"]=="location",v
    assert v["left"]>=v["railLeft"]-1 and v["right"]<=v["railRight"]+1,v
save()
try:
 with sync_playwright() as pw:
  browser=pw.chromium.launch(channel="chrome",headless=True)
  record["browser"]=browser.version
  record["baseline"]=json.loads(Path("/tmp/intl-paper-polish-20261103/proof/polish_browser.json").read_text())["baseline"]
  record["baseline_reference"]="Preserved first-iteration measurements of the unchanged completion build; not rerun."
  for width in [1440,768,390,320]:
   for theme in ["light","dark"]:
    for lang in ["en","zh"]:
     name=f"{width}-{theme}-{lang}"
     row={"state":name,"checks":[],"errors":[]}
     ctx=context_for(browser,width,theme,lang);page=ctx.new_page()
     page.on("pageerror",lambda e,row=row:row["errors"].append(str(e)))
     try:
      row["load_seconds"]=ready(page)
      row["layout"]=m=metrics(page)
      assert page.locator(".imc-country").count()==7
      assert m["scrollWidth"]<=width+1,m
      assert m["theme"]==theme and m["lang"]==lang,m
      assert len(m["links"])==3,m
      assert max(l["y"] for l in m["links"])-min(l["y"] for l in m["links"])<2,m
      assert all(l["height"]>=44 and l["scrollWidth"]<=l["clientWidth"]+1 for l in m["links"]),m
      assert max(l["right"] for l in m["links"])<=m["slot"]["x"]-3,m
      assert m["toolbar"]["height"]<=56,m
      assert page.locator('.imc-nav a[aria-current="location"]').count()==1
      row["checks"].append("compact_three_link_nav_without_clipping_or_assistant_overlap")
      row["card_surface"]=page.locator(".imc-country:not([open])").first.evaluate("e=>({shadow:getComputedStyle(e).boxShadow,radius:getComputedStyle(e).borderRadius})")
      assert row["card_surface"]["shadow"]=="none",row["card_surface"]
      row["initial_screenshot"]=shot(page,name)
      for cc in ["JP","KR","TW","IN","AU","GB","EZ"]:
       page.locator('.imc-country-rail [data-imc-country="'+cc+'"]').click()
       frame(page)
       target=page.locator("#imc-country-"+cc)
       assert target.get_attribute("open") is not None,cc
       assert page.locator(".imc-country[open]").count()==1,cc
       assert target.locator(".imc-country-body").is_visible()
       assert_rail(rail(page,cc))
       assert page.evaluate("document.documentElement.scrollWidth")<=width+1,cc
       table=target.locator(".imc-chart-values")
       assert table.count()==1,cc
       summary=table.locator(":scope > summary")
       summary.focus();summary.press("Enter");frame(page)
       assert table.get_attribute("open") is not None,cc
       assert summary.evaluate("e=>e===document.activeElement"),cc
       observed=table.locator("tbody tr").evaluate_all("rows=>rows.map(r=>[r.children[0].innerText,r.children[1].innerText,r.children[2].innerText])")
       years=target.locator(".imc-growth-chart .imc-chart-year").all_text_contents()
       values=target.locator(".imc-growth-chart .imc-chart-value").all_text_contents()
       assert [r[0] for r in observed]==years,(cc,observed,years)
       assert [r[1] for r in observed]==[v+"%" for v in values],(cc,observed,values)
       assert any(r[2] in ["Projection","预测"] for r in observed),observed
       assert any(r[2] in ["Published history","机构历史数据"] for r in observed),observed
       assert page.evaluate("document.documentElement.scrollWidth")<=width+1,cc
       if cc=="KR" and width in [390,320] and theme=="light":
        summary.scroll_into_view_if_needed();frame(page);shot(page,name+"-chart-values")
       summary.press("Enter");frame(page)
       assert table.get_attribute("open") is None,cc
       row["checks"].append("country_"+cc+"_rail_native_values_keyboard_exact_points")
      page.locator('.imc-country-rail [data-imc-country="TW"]').click()
      page.locator('.imc-country-rail [data-imc-country="GB"]').click()
      page.go_back(wait_until="domcontentloaded");frame(page)
      assert page.locator("#imc-country-TW").get_attribute("open") is not None
      assert_rail(rail(page,"TW"))
      row["checks"].append("country_browser_back_and_selected_rail_visibility")
      page.locator('.imc-nav a[href="#imc-connections"]').click();frame(page)
      assert page.locator('.imc-nav [data-imc-section="imc-connections"]').get_attribute("aria-current")=="location"
      page.locator(".imc-tools-link").click();frame(page)
      assert page.locator("#intl-analysis-tools").get_attribute("open") is not None
      assert page.locator('.imc-nav [data-imc-section="intl-analysis-tools"]').get_attribute("aria-current")=="location"
      before=page.evaluate("({hash:location.hash,length:history.length,focus:document.activeElement.tagName})")
      page.evaluate("window.scrollTo(0,0)");frame(page)
      after=page.evaluate("({hash:location.hash,length:history.length,focus:document.activeElement.tagName})")
      assert before==after,(before,after)
      assert page.locator('.imc-nav [data-imc-section="imc-countries"]').get_attribute("aria-current")=="location"
      row["checks"].append("section_tracking_without_history_or_focus_mutation")
      assert not row["errors"],row["errors"]
      row["pass"]=True
     except Exception as e:
      row["pass"]=False;row["failure"]=str(e);row["failure_type"]=type(e).__name__;row["traceback"]=traceback.format_exc(limit=4)
      try: shot(page,name+"-failed")
      except Exception: pass
     finally:
      record["states"].append(row);save();ctx.close()
      print(json.dumps({"state":name,"pass":row["pass"],"failure":row.get("failure"),"checks":len(row["checks"])}),flush=True)
  # Horizontal visibility must also survive changing from a wide layout to a phone.
  ctx=context_for(browser,1440,"light","en");page=ctx.new_page()
  journey={"name":"selected_rail_after_resizing"}
  try:
   ready(page)
   page.locator('.imc-country-rail [data-imc-country="GB"]').click();frame(page)
   page.set_viewport_size({"width":320,"height":844});frame(page)
   journey["rail"]=rail(page,"GB");assert_rail(journey["rail"])
   journey["pass"]=True
  except Exception as e:journey.update({"pass":False,"failure":str(e)})
  finally:record["journeys"].append(journey);save();ctx.close()
  # Native controls remain usable with all enhancement disabled.
  ctx=context_for(browser,390,"light","en",javascript=False);page=ctx.new_page()
  journey={"name":"native_country_and_chart_values_without_javascript"}
  try:
   page.goto(url,wait_until="domcontentloaded",timeout=60000)
   c=page.locator("#imc-country-JP");c.locator(":scope > summary").click()
   assert c.get_attribute("open") is not None and c.locator(".imc-country-body").is_visible()
   d=c.locator(".imc-chart-values");d.locator(":scope > summary").click()
   assert d.get_attribute("open") is not None and d.locator("table").is_visible()
   assert d.locator("tbody tr").count()>=2
   journey["pass"]=True
  except Exception as e:journey.update({"pass":False,"failure":str(e)})
  finally:record["journeys"].append(journey);save();ctx.close()
  ctx=context_for(browser,390,"dark","en",reduced="reduce");page=ctx.new_page()
  journey={"name":"reduced_motion"}
  try:
   ready(page)
   page.locator('.imc-country-rail [data-imc-country="GB"]').click();frame(page)
   a=page.locator("#imc-country-GB .imc-country-body").evaluate("e=>getComputedStyle(e).animationName")
   transition=page.locator(".imc-nav a").first.evaluate("e=>getComputedStyle(e).transitionDuration")
   assert a=="none" and transition=="0s",(a,transition)
   journey.update({"pass":True,"animation":a,"transition":transition})
  except Exception as e:journey.update({"pass":False,"failure":str(e)})
  finally:record["journeys"].append(journey);save();ctx.close()
  browser.close()
finally:
 for s in servers:s.shutdown();s.server_close()
 record["completed_at"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
 record["pass"]=len(record["states"])==16 and all(r["pass"] for r in record["states"]) and all(r["pass"] for r in record["journeys"])
 save()
print(json.dumps({"pass":record["pass"],"states":len(record["states"]),"journeys":record["journeys"],"shots":len(record["screenshots"])}),flush=True)
raise SystemExit(0 if record["pass"] else 1)
