from pathlib import Path
import concurrent.futures,datetime,hashlib,json,subprocess
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018')
OUT=Path('/tmp/intl-paper-polish-r2-20261103/proof')
PY='/tmp/intl-country-ci-20261103/bin/python'
paths=['templates/intl_country_cockpit.html.j2','templates/intl_country_cockpit.css','templates/intl_country_cockpit.js','tests/test_intl_country_cockpit.py','tests/intl_country_cockpit_navigation.test.cjs']
diff=OUT/'polish_source.diff'
diff.write_bytes(subprocess.check_output(['git','diff','--unified=0','27aba2b875a00096c69841d926f48cca232a7a90','--',*paths],cwd=W))
def run(name,args,timeout=180):
 p=OUT/(name+'.json');assert not p.exists()
 rec={'state':'RUNNING','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':args,'cwd':str(W),'scope':'current working source; no publication'}
 p.write_text(json.dumps(rec,indent=2)+'\n')
 with (OUT/(name+'.log')).open('w') as log:
  try:
   result=subprocess.run(args,cwd=W,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
   rec.update(state='PASS' if result.returncode==0 else 'FAILED',exit_code=result.returncode)
  except subprocess.TimeoutExpired:rec.update(state='TIMED_OUT')
 rec.update(completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),log_sha256=hashlib.sha256((OUT/(name+'.log')).read_bytes()).hexdigest())
 p.write_text(json.dumps(rec,indent=2)+'\n')
 print(json.dumps({'guard':name,'state':rec['state'],'exit_code':rec.get('exit_code')}),flush=True)
 return rec
jobs=[
 ('design_added',[PY,'scripts/check_design_system.py','--mode','enforce-added','--diff-file',str(diff)]),
 ('runtime_styles',[PY,'scripts/check_runtime_style_injection.py']),
 ('template_site_sync',[PY,'scripts/check_template_site_sync.py']),
 ('reference_integrity',[PY,'scripts/check_reference_integrity.py']),
 ('polish_whitespace',['git','diff','--check','27aba2b875a00096c69841d926f48cca232a7a90','--',*paths])
]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for f in [pool.submit(run,*job) for job in jobs]:f.result()
