"""Run the repository's canonical visual capture against the refined build.
The injected factory selects the same installed Chrome used by the journey proof;
all observation, state application, PNG capture and manifest emission remain in
the unmodified repository capture tool.
"""
from pathlib import Path
import datetime,hashlib,json,sys
from playwright.sync_api import sync_playwright
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018')
sys.path.insert(0,str(W))
from scripts import capture_page_evidence as capture
ROOT=Path('/tmp/intl-paper-polish-r2-20261103')
OUT=ROOT/'canonical'
assert not OUT.exists()
OUT.mkdir()
record={'state':'RUNNING','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_tree':'6f88b1d6b2cc6e7764439b339741584c3b6eeba6',
        'html_sha256':hashlib.sha256((ROOT/'source/site/intl.html').read_bytes()).hexdigest(),
        'capture_tool_module_sha256':hashlib.sha256((W/'scripts/capture_page_evidence.py').read_bytes()).hexdigest(),
        'launch_adapter_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'browser_channel':'chrome','runs':[],'scope':'anonymous local build; no production or authenticated access'}
def save(): (OUT/'capture_execution.json').write_text(json.dumps(record,indent=2)+'\n')
def chrome_driver(**kwargs):
    manager=sync_playwright().start()
    try: browser=manager.chromium.launch(channel='chrome',headless=kwargs['headless'])
    except Exception:
        manager.stop();raise
    record['browser_version']=browser.version
    return capture._PlaywrightDriver(manager,browser,kwargs['user_agent'],dict(kwargs['observer_config']),kwargs['settle_ms'])
save()
try:
 for name,viewports,locales,extra in [
     ('rest','desktop,mobile','en,zh',[]),
     ('interaction','desktop','en',['--force-state','nav_hover:hover(.imc-nav [data-imc-section="imc-connections"])','--force-state','nav_focus:focus(.imc-nav [data-imc-section="imc-connections"])'])
 ]:
    folder=OUT/name;folder.mkdir()
    args=['--registry',str(W/'data/product_experience/page_registry.json'),
          '--site-dir',str(ROOT/'source/site'),'--routes','/intl.html',
          '--output-dir',str(folder/'images'),'--manifest',str(folder/'manifest.json'),
          '--smells',str(folder/'smells.json'),'--viewports',viewports,'--locales',locales,
          '--themes','light,dark','--max-pages','1','--delay-ms','0','--settle-ms','1400',
          '--timeout-s','60',*extra]
    row={'name':name,'arguments':args,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    record['runs'].append(row);save()
    code=capture.main(args,driver_factory=chrome_driver)
    row.update(exit_code=code,completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if (folder/'manifest.json').exists():
        row['manifest_sha256']=hashlib.sha256((folder/'manifest.json').read_bytes()).hexdigest()
    save()
    if code:raise RuntimeError(name+' returned '+str(code))
 record['state']='PASS'
except Exception as error:
 record.update(state='FAILED',failure=str(error));raise
finally:
 record['completed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps(record),flush=True)
