# International Paper refinement evidence
This archive preserves original failed attempts and later corrections, complete actual browser receipts, all screenshots, canonical tool manifests, exact source patches/files, input object manifests and ordinary generated HTML.
It does not claim deployment, formal independent approval, complete-data hosted CI, authenticated access or actual Terminal-parent acceptance.
Country verification: 445 tests; 20 navigation cases; 16 actual browser states/112 country openings; 14 canonical observations.
Final overview: 73 tests; 8 actual current-input selections; 8 fresh canonical observations.
The first current-data extraction timed out. The 510-file bundle omitted the genuine collector receipt; the final 511-input build includes its exact protected-main bytes.
The dense-observer browser matrix encountered a renderer crash and was interrupted. A normal-action sequence with batched observations and eight static dense-read repetitions subsequently passed; the original cause remains unproven. No long-session performance conclusion is substituted.
Cold-load shared-header layout shift remains open. The complete page is large; captured lab timings are retained without production-performance certification.
Some saved helper scripts are recipes or unused alternatives; only execution receipts establish that a command ran. The overview edit recipe was not executed after transport errors; reconciled structured file writes produced the exact staged source.
See the adjacent POLISH.md/POLISH.json for release boundaries and continuation.
