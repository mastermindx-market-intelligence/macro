from pathlib import Path
import datetime,functools,hashlib,http.server,json,subprocess,threading
from playwright.sync_api import sync_playwright
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018')
ROOT=Path('/tmp/intl-paper-polish-final-20261103');SITE=ROOT/'source/site';P=ROOT/'proof'
TREE='3907981072bff63d87848603b496c4098bccfb68'
sha=lambda b:hashlib.sha256(b).hexdigest()
assets=['logo_config.js','stock-logos.js','live.js','account.js','favicon.ico']
receipt={'state':'PASS','source_tree':TREE,'purpose':'Complete the isolated site with the same existing shared static assets used by normal deployment; no authored or generated page bytes altered.','files':[]}
before=sha((SITE/'intl.html').read_bytes())
for name in assets:
 rel='site/'+name
 blob=subprocess.check_output(['git','rev-parse',TREE+':'+rel],cwd=W,text=True).strip()
 data=subprocess.check_output(['git','cat-file','blob',blob],cwd=W)
 dest=SITE/name
 assert not dest.exists(),name
 dest.write_bytes(data)
 row={'path':rel,'git_blob':blob,'bytes':len(data),'sha256':sha(data)}
 if name.endswith('.js'):
  template=subprocess.check_output(['git','rev-parse',TREE+':templates/'+name],cwd=W,text=True).strip()
  assert template==blob,(name,template,blob)
  row['template_site_identical']=True
 receipt['files'].append(row)
assert before==sha((SITE/'intl.html').read_bytes())
receipt.update(html_sha256=before,completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
(P/'shared_static_assets.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'assets_added':len(assets),'html_unchanged':True}),flush=True)
class Handler(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(SITE)))
threading.Thread(target=server.serve_forever,daemon=True).start()
rows=[]
try:
 with sync_playwright() as pw:
  browser=pw.chromium.launch(channel='chrome',headless=True)
  for width in [1440,390]:
   ctx=browser.new_context(viewport={'width':width,'height':900 if width==1440 else 844})
   ctx.add_init_script("""localStorage.setItem('theme','light');localStorage.setItem('lang','en');localStorage.removeItem('themeAuto');
   window.__shiftPhase='load';window.__shifts=[];
   new PerformanceObserver(list=>{for(const e of list.getEntries())if(!e.hadRecentInput)window.__shifts.push({
     phase:window.__shiftPhase,value:e.value,time:e.startTime,sources:e.sources.map(s=>({node:s.node?(s.node.id||s.node.className||s.node.nodeName):null,previous:s.previousRect.toJSON(),current:s.currentRect.toJSON()}))
   });}).observe({type:'layout-shift',buffered:true});""")
   page=ctx.new_page();errors=[];responses=[]
   page.on('pageerror',lambda e:errors.append(str(e)))
   page.on('response',lambda r:responses.append({'url':r.url,'status':r.status}) if r.status>=400 else None)
   page.goto('http://127.0.0.1:'+str(server.server_port)+'/intl.html',wait_until='domcontentloaded',timeout=60000)
   page.evaluate('document.fonts.ready');page.wait_for_timeout(1600)
   page.evaluate("""()=>{window.__shiftPhase='same_state_reapply';if(window.setTheme)window.setTheme('light');if(window.setLang)window.setLang('en');}""")
   page.wait_for_timeout(1600)
   row=page.evaluate("""()=>({shifts:window.__shifts,width:innerWidth,scrollWidth:document.documentElement.scrollWidth,countryY:document.querySelector('.imc-country[open]').getBoundingClientRect().y,toolbarHeight:document.querySelector('.imc-toolbar').getBoundingClientRect().height})""")
   row.update(errors=errors,failed_responses=responses)
   rows.append(row);ctx.close()
  browser.close()
finally:server.shutdown();server.server_close()
(P/'layout_shift_probe.json').write_text(json.dumps({'scope':'Local synthetic diagnostic, not field Core Web Vitals','html_sha256':before,'states':rows},indent=2)+'\n')
print(json.dumps({'states':[{'width':r['width'],'countryY':r['countryY'],'toolbarHeight':r['toolbarHeight'],'cls_load':sum(x['value'] for x in r['shifts'] if x['phase']=='load'),'cls_reapply':sum(x['value'] for x in r['shifts'] if x['phase']=='same_state_reapply'),'errors':r['errors'],'failed_responses':r['failed_responses']} for r in rows]}),flush=True)
