from pathlib import Path
import copy,datetime,hashlib,json,shutil,subprocess
import yaml
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018')
ROOT=Path('/tmp/intl-paper-polish-final-20261103')
P=ROOT/'proof'; C=ROOT/'canonical'
DEST=W/'mockups/evidence/intl-country-polish-20261103'
assert not DEST.exists()
execution=json.loads((C/'capture_execution.json').read_text())
assert execution['state']=='PASS'
manifests=[json.loads((C/n/'manifest.json').read_text()) for n in ['rest','interaction']]
rest,interaction=manifests
assert rest['schema']==interaction['schema']=='mastermind.p0_evidence.v2'
assert rest['target']==interaction['target']
assert rest['tool']==interaction['tool']
assert len(rest['pages'])==len(interaction['pages'])==1
a,b=rest['pages'][0],interaction['pages'][0]
assert a['page_id']==b['page_id']
assert len(a['states'])==8 and len(b['states'])==6
for page in [a,b]:
 assert page['console_errors']==[] and page['failed_responses']==[]
 assert all(s['captured'] and s['applied_theme']==s['theme'] and s['applied_locale']==s['locale'] for s in page['states'])
DEST.mkdir();(DEST/'images').mkdir()
images={}
for name,m in zip(['rest','interaction'],manifests):
 for state in m['pages'][0]['states']:
  raw=(C/name/state['file']).read_bytes()
  digest=hashlib.sha256(raw).hexdigest()
  assert digest==state['sha256'] and len(raw)==state['bytes']
  target=DEST/state['file']
  if target.exists():assert target.read_bytes()==raw
  else:target.write_bytes(raw)
  images[state['file']]={'sha256':digest,'bytes':len(raw)}
combined=copy.deepcopy(rest)
combined['generated_at']=interaction['generated_at']
combined['axes']['force_states']=interaction['axes']['force_states']
combined['honesty']['force_states']=interaction['honesty']['force_states']
combined['selection']['note']+='; Incremental capture union: eight rest states, plus a six-state desktop/en run containing two repeated rest observations and four real hover/focus observations. All 14 observations are retained. Page metrics are from the original complete eight-state rest run. Original manifests and PNGs remain in the completion archive.'
combined['pages'][0]['states'].extend(copy.deepcopy(b['states']))
combined['pages'][0]['page_tree_sha']=subprocess.check_output(['git','hash-object',str(ROOT/'source/site/intl.html')],cwd=W,text=True).strip()
combined['totals']={'pages':1,'states_attempted':14,'states_captured':14}
for state in combined['pages'][0]['states']:state['capture_tool_module_sha256']=combined['tool']['module_sha256']
manifest=DEST/'manifest.json'
manifest.write_text(json.dumps(combined,indent=2,ensure_ascii=False)+'\n')
receipt={'schema':'mastermind.page_evidence_receipt.v1','changed_paths':['templates/intl_country_cockpit.css','templates/intl_country_cockpit.html.j2','templates/intl_country_cockpit.js'],'manifest':str(manifest.relative_to(W))}
(DEST/'EVIDENCE.yml').write_text(yaml.safe_dump(receipt,sort_keys=False))
provenance={'source_tree':execution['source_tree'],'html_sha256':execution['html_sha256'],'capture_tool_module_sha256':execution['capture_tool_module_sha256'],'launch_adapter_sha256':execution['launch_adapter_sha256'],'original_manifests':{n:hashlib.sha256((C/n/'manifest.json').read_bytes()).hexdigest() for n in ['rest','interaction']},'selection':'All observations from both actual canonical captures; no invented states or changed image bytes. Duplicate rest observations retained explicitly.','captured_observations':14,'distinct_rest_cells':8,'real_interaction_cells':4,'unique_images':len(images),'images':images,'receipt':str((DEST/'EVIDENCE.yml').relative_to(W)),'manifest':str(manifest.relative_to(W)),'manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest()}
(P/'canonical_package.json').write_text(json.dumps(provenance,indent=2)+'\n')
cmd=['/tmp/intl-country-ci-20261103/bin/python','scripts/check_ui_visual_evidence.py','--diff-file',str(P/'polish_source.diff')]
rec={'command':cmd,'cwd':str(W),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Current polish delta with fresh canonical evidence; mechanical evidence gate, not independent design approval.'}
with (P/'visual_evidence_guard.log').open('w') as log:r=subprocess.run(cmd,cwd=W,stdout=log,stderr=subprocess.STDOUT,timeout=180)
rec.update(state='PASS' if r.returncode==0 else 'FAILED',exit_code=r.returncode,completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),log_sha256=hashlib.sha256((P/'visual_evidence_guard.log').read_bytes()).hexdigest())
(P/'visual_evidence_guard.json').write_text(json.dumps(rec,indent=2)+'\n')
print(json.dumps({'state':rec['state'],'observations':14,'unique_images':len(images),'manifest':str(manifest.relative_to(W)),'manifest_sha256':provenance['manifest_sha256']}),flush=True)
