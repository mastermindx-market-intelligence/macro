"""Verify the actual refined ordinary build, including presentation and native fallbacks."""
from pathlib import Path
from urllib.parse import urlparse
import datetime, functools, hashlib, http.server, json, threading, time, traceback
from playwright.sync_api import sync_playwright

ROOT=Path("/tmp/intl-paper-polish-final-20261103")
OUT=ROOT/"proof"
SHOTS=OUT/"screenshots"
SHOTS.mkdir(exist_ok=True)
SITE=ROOT/"source/site"
BASE=Path("/tmp/intl-paper-build-20261103/source/site")
class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*args): pass
servers=[]
def serve(path):
    s=http.server.ThreadingHTTPServer(("127.0.0.1",0),functools.partial(QuietHandler,directory=str(path)))
    threading.Thread(target=s.serve_forever,daemon=True).start()
    servers.append(s)
    return "http://127.0.0.1:"+str(s.server_port)+"/intl.html"
url=serve(SITE)
baseurl=serve(BASE)
record={"schema":"intl.polish_final_visual.v1","started_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "source_tree":json.loads((OUT/"source.json").read_text())["tree"],
        "html_sha256":hashlib.sha256((SITE/"intl.html").read_bytes()).hexdigest(),
        "scope":"Actual ordinary build, same 510 committed production inputs; anonymous local Chrome; not production or a real Terminal parent",
        "states":[],"journeys":[],"baseline":[],"screenshots":[]}
def save(): (OUT/"final_visuals.json").write_text(json.dumps(record,indent=2)+"\n")
def route(r):
    if urlparse(r.request.url).hostname=="127.0.0.1": r.continue_()
    else: r.abort()
def context_for(browser,width,theme,lang,javascript=True,reduced=None):
    opts={"viewport":{"width":width,"height":1000 if width==1440 else 844},"device_scale_factor":1,"java_script_enabled":javascript}
    if reduced: opts["reduced_motion"]=reduced
    ctx=browser.new_context(**opts);ctx.route("**/*",route)
    if javascript:
        ctx.add_init_script("localStorage.setItem('theme',"+json.dumps(theme)+");localStorage.setItem('lang',"+json.dumps(lang)+");localStorage.removeItem('themeAuto');")
    return ctx
def ready(page,target=url):
    start=time.monotonic()
    page.goto(target,wait_until="domcontentloaded",timeout=60000)
    page.locator(".imc-country[open] .imc-outlook-panel").wait_for(state="visible",timeout=20000)
    page.evaluate("document.fonts.ready")
    page.wait_for_timeout(220)
    return round(time.monotonic()-start,3)
def frame(page):
    page.evaluate("new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))")
def metrics(page):
    return page.evaluate("""() => {
      const b=s=>{const x=document.querySelector(s);if(!x)return null;const r=x.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,bottom:r.bottom,right:r.right};};
      return {width:innerWidth,scrollWidth:document.documentElement.scrollWidth,theme:document.documentElement.dataset.theme,lang:document.documentElement.dataset.lang,
       toolbar:b('.imc-toolbar'),nav:b('.imc-nav'),slot:b('.imc-assistant-slot'),country:b('.imc-country[open]'),forecast:b('.imc-country[open] .imc-row-forecast'),outlook:b('.imc-country[open] .imc-outlook-panel'),
       links:Array.from(document.querySelectorAll('.imc-nav a')).map(x=>{const r=x.getBoundingClientRect();return {text:x.innerText,x:r.x,y:r.y,right:r.right,height:r.height,width:r.width,scrollWidth:x.scrollWidth,clientWidth:x.clientWidth,current:x.getAttribute('aria-current')};})};
    }""")
def shot(page,name,full=False):
    p=SHOTS/(name+".png");page.screenshot(path=str(p),full_page=full)
    item={"name":name,"path":"screenshots/"+p.name,"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}
    record["screenshots"].append(item);return item
def rail(page,cc):
    return page.evaluate("""cc=>{
      const r=document.querySelector('.imc-country-rail'), a=r.querySelector('[data-imc-country="'+cc+'"]'), rb=r.getBoundingClientRect(),ab=a.getBoundingClientRect();
      return {current:a.getAttribute('aria-current'),left:ab.left,right:ab.right,railLeft:rb.left,railRight:rb.right,scrollLeft:r.scrollLeft};
    }""",cc)
def assert_rail(v):
    assert v["current"]=="location",v
    assert v["left"]>=v["railLeft"]-1 and v["right"]<=v["railRight"]+1,v
save()
try:
 with sync_playwright() as pw:
  browser=pw.chromium.launch(channel="chrome",headless=True)
  record["browser"]=browser.version
  previous=json.loads(Path("/tmp/intl-paper-polish-r2-20261103/proof/polish_browser.json").read_text())
  assert previous["pass"]
  record["baseline"]=previous["baseline"]
  record["behavior_reference"]={"path":"/tmp/intl-paper-polish-r2-20261103/proof/polish_browser.json","sha256":hashlib.sha256(Path("/tmp/intl-paper-polish-r2-20261103/proof/polish_browser.json").read_bytes()).hexdigest(),"scope":"Prior 16-state/112-country behavior proof; final delta changes only two color tokens."}
  prior={r["state"]:r for r in previous["states"]}
  for width in [1440,768,390,320]:
   for theme in ["light","dark"]:
    for lang in ["en","zh"]:
     name=f"{width}-{theme}-{lang}"
     row={"state":name,"checks":[],"errors":[]}
     ctx=context_for(browser,width,theme,lang);page=ctx.new_page()
     page.on("pageerror",lambda e,row=row:row["errors"].append(str(e)))
     try:
      row["load_seconds"]=ready(page)
      row["layout"]=m=metrics(page)
      assert page.locator(".imc-country").count()==7
      assert m["scrollWidth"]<=width+1,m
      assert m["theme"]==theme and m["lang"]==lang,m
      assert len(m["links"])==3 and max(l["y"] for l in m["links"])-min(l["y"] for l in m["links"])<2,m
      assert all(l["height"]>=44 and l["scrollWidth"]<=l["clientWidth"]+1 for l in m["links"]),m
      assert max(l["right"] for l in m["links"])<=m["slot"]["x"]-3,m
      assert m["toolbar"]["height"]<=56,m
      row["checks"].append("three_link_navigation_and_reserved_assistant")
      for key in ["toolbar","country","forecast","outlook"]:
       for dimension in ["x","y","width","height"]:
        assert abs(m[key][dimension]-prior[name]["layout"][key][dimension])<=1,(key,dimension,m[key],prior[name]["layout"][key])
      row["checks"].append("geometry_matches_verified_r2")
      row["colors"]=page.evaluate("""() => {
        const c=e=>({background:getComputedStyle(e).backgroundColor,border:getComputedStyle(e).borderColor,shadow:getComputedStyle(e).boxShadow});
        return {canvas:c(document.body),open:c(document.querySelector('.imc-country[open]')),closed:c(document.querySelector('.imc-country:not([open])'))};
      }""")
      assert row["colors"]["closed"]["shadow"]=="none",row["colors"]
      row["checks"].append("quiet_closed_cards_and_shared_palette")
      row["initial_screenshot"]=shot(page,name)
      if width in [390,320] and theme=="light":
       panel=page.locator(".imc-country[open] .imc-chart-values")
       control=panel.locator(":scope > summary");control.focus();control.press("Enter");frame(page)
       assert panel.get_attribute("open") is not None and panel.locator("table").is_visible()
       assert page.evaluate("document.documentElement.scrollWidth")<=width+1
       control.scroll_into_view_if_needed();frame(page)
       shot(page,name+"-chart-values")
       row["checks"].append("final_native_values_surface")
      assert not row["errors"],row["errors"]
      row["pass"]=True
     except Exception as e:
      row.update({"pass":False,"failure":str(e),"traceback":traceback.format_exc(limit=4)})
      try:shot(page,name+"-failed")
      except Exception:pass
     finally:
      record["states"].append(row);save();ctx.close()
      print(json.dumps({"state":name,"pass":row["pass"],"failure":row.get("failure"),"checks":len(row["checks"])}),flush=True)
  browser.close()
finally:
 for s in servers:s.shutdown();s.server_close()
 record["completed_at"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
 record["pass"]=len(record["states"])==16 and all(r["pass"] for r in record["states"]) and all(r["pass"] for r in record["journeys"])
 save()
print(json.dumps({"pass":record["pass"],"states":len(record["states"]),"journeys":record["journeys"],"shots":len(record["screenshots"])}),flush=True)
raise SystemExit(0 if record["pass"] else 1)
