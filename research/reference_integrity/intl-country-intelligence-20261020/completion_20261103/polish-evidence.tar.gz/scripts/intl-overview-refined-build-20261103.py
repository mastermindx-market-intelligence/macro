from pathlib import Path
import concurrent.futures,datetime,hashlib,json,os,shutil,subprocess,tarfile
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018')
B=Path('/tmp/intl-paper-polish-final-20261103');C=Path('/tmp/intl-paper-current-complete-20261103')
O=Path('/tmp/intl-paper-overview-refined-20261103');assert not O.exists();O.mkdir();P=O/'proof';P.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()=='851c6abebf01c5c8096e7822436455fd1040152a'
assert subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=W,text=True).strip()=='c6ac417f4a1d561f8c80a0a6b1977d5ffec6d090'
assert subprocess.check_output(['git','write-tree'],cwd=W,text=True).strip()=='3907981072bff63d87848603b496c4098bccfb68'
files=['templates/intl_workspace/overview.html.j2','templates/intl_workspace.css','tests/test_intl_workspace_overview_render.py']
assert 'macro window_date' in (W/files[0]).read_text() and 'Compact, unranked' in (W/files[1]).read_text()
subprocess.run(['git','add','--',*files],cwd=W,check=True)
tree=subprocess.check_output(['git','write-tree'],cwd=W,text=True).strip()
delta=subprocess.check_output(['git','diff','--name-only','3907981072bff63d87848603b496c4098bccfb68',tree],cwd=W,text=True).splitlines();assert set(delta)==set(files),delta
prior=json.loads((B/'proof/source.json').read_text())
for path,digest in prior['runtime_hashes'].items():assert sha(W/path)==digest
source={'tree':tree,'prior_tree':prior['tree'],'baseline_tree':'27aba2b875a00096c69841d926f48cca232a7a90','head':prior['head'],'merge_head':prior['merge_head'],'runtime_hashes':{**prior['runtime_hashes'],**{f:sha(W/f) for f in files[:2]}},'delta':delta,'scope':'Uncommitted source; compact unequal-window presentation only. All three country runtime files byte-identical to prior verified build; no calculations, windows or qualifications change.'}
(P/'source.json').write_text(json.dumps(source,indent=2)+'\n')
diff=P/'overview_source.diff';diff.write_bytes(subprocess.check_output(['git','diff','--unified=0',prior['tree'],'--',*files],cwd=W))
def run(name,cmd,cwd=W,env=None,timeout=240):
 rec={'state':'RUNNING','command':cmd,'cwd':str(cwd),'started_at':now()}
 path=P/(name+'.json');path.write_text(json.dumps(rec,indent=2)+'\n')
 with (P/(name+'.log')).open('w') as log:
  try:
   r=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout);rec.update(state='PASS' if r.returncode==0 else 'FAILED',exit_code=r.returncode)
  except subprocess.TimeoutExpired:rec.update(state='TIMED_OUT')
 rec.update(completed_at=now(),log_sha256=sha(P/(name+'.log')));path.write_text(json.dumps(rec,indent=2)+'\n');print(name,rec['state'],flush=True);return rec
def build():
 archive=O/'source.tar';subset=['config.yml','config','collectors','engine','lib','scripts','templates','requirements.txt','site/fonts','site/favicon.svg']
 subprocess.run(['git','archive','--format=tar','--output='+str(archive),tree,*subset],cwd=W,check=True,timeout=120)
 runtime=O/'source';runtime.mkdir()
 with tarfile.open(archive) as t:t.extractall(runtime,filter='data')
 inputs=C/'committed-inputs.tar';assert sha(inputs)=='e0ab64bc8e180d781e6d0a3705c3d93a0568df1acf8213f5abde96dbc577676a'
 with tarfile.open(inputs) as t:t.extractall(runtime,filter='data')
 manifest=json.loads((C/'proof/input_manifest.json').read_text())
 for row in manifest['files']:assert sha(runtime/row['path'])==row['sha256'],row['path']
 shutil.copyfile(C/'proof/input_manifest.json',P/'input_manifest.json')
 assets=json.loads((B/'proof/shared_static_assets.json').read_text())
 for row in assets['files']:
  raw=(B/'source'/row['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['sha256']
  target=runtime/row['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
 env=os.environ.copy()
 for k in ['PYTHONPATH','COLLECT_LANE','US_LANE']:env.pop(k,None)
 r=run('ordinary_build',['/tmp/intl-country-ci-20261103/bin/python','-m','scripts.build_intl'],cwd=runtime,env=env,timeout=600)
 r.update(source_tree=tree,runtime_hashes=source['runtime_hashes'],source_archive_sha256=sha(archive),input_commit=manifest['commit'],committed_inputs=511,input_archive_sha256=sha(inputs),shared_assets=assets['files'],no_reacquisition=True,no_production_mutation=True)
 if (runtime/'site/intl.html').exists():r.update(html_sha256=sha(runtime/'site/intl.html'),html_bytes=(runtime/'site/intl.html').stat().st_size)
 (P/'ordinary_build.json').write_text(json.dumps(r,indent=2)+'\n')
 expected=json.loads((C/'proof/overview_expected.json').read_text());expected.update(source_tree=tree,reused_from=str(C/'proof/overview_expected.json'),reuse_reason='Only display template/CSS changed; exact 511 inputs and all calculation/qualification owners are identical, same delayed snapshot date.');(P/'overview_expected.json').write_text(json.dumps(expected,indent=2)+'\n')
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 jobs=[
  pool.submit(build),
  pool.submit(run,'overview_tests',['/tmp/intl-country-ci-20261103/bin/python','-m','pytest','-q','tests/test_intl_workspace_overview.py','tests/test_intl_workspace_overview_render.py','--basetemp=/tmp/intl-overview-refined-pytest-20261103']),
  pool.submit(run,'design_added',['/tmp/intl-country-ci-20261103/bin/python','scripts/check_design_system.py','--mode','enforce-added','--diff-file',str(diff)])]
 for job in jobs:job.result()
