from pathlib import Path
import datetime,hashlib,io,json,os,shutil,subprocess,tarfile,traceback
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018')
BASE=Path('/tmp/intl-paper-polish-final-20261103')
PRE=Path('/tmp/intl-paper-current-data-20261103')
OUT=Path('/tmp/intl-paper-current-complete-20261103');assert not OUT.exists();OUT.mkdir();P=OUT/'proof';P.mkdir()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((BASE/'proof/source.json').read_text());prior=json.loads((PRE/'proof/ordinary_build.json').read_text())
record={'state':'PREPARING','started_at':now(),'source_tree':source['tree'],'runtime_hashes':source['runtime_hashes'],'input_commit':prior['input_commit'],'committed_inputs':511,'scope':'Same refined source with 510 exact main data files plus the genuine required collector receipt data/run_status.json from the same commit. No source merge, reacquisition, invented evidence or deployment.','prior_partial_input_build':{'html_sha256':prior['html_sha256'],'state':'BUILD_PASSED_RETURNS_WITHHELD','reason':'Original 510-path isolated input set omitted data/run_status.json; corrected with exact protected-main bytes, no gate relaxation.'}}
def save():(P/'ordinary_build.json').write_text(json.dumps(record,indent=2)+'\n')
save()
try:
 raw=(PRE/'proof/current_main_run_status.json').read_bytes()
 oid=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
 actual=subprocess.check_output(['git','rev-parse',prior['input_commit']+':data/run_status.json'],cwd=W,text=True).strip();assert oid==actual
 manifest=json.loads((PRE/'proof/input_manifest.json').read_text())
 assert not any(x['path']=='data/run_status.json' for x in manifest['files'])
 manifest['files'].append({'path':'data/run_status.json','git_blob':oid,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 manifest['files'].sort(key=lambda r:r['path'])
 (P/'input_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 archive=OUT/'committed-inputs.tar';shutil.copyfile(PRE/'committed-inputs-v2.tar',archive)
 with tarfile.open(archive,'a') as t:
  info=tarfile.TarInfo('data/run_status.json');info.size=len(raw);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(raw))
 runtime=OUT/'source';runtime.mkdir()
 with tarfile.open(BASE/'source.tar') as t:t.extractall(runtime,filter='data')
 with tarfile.open(archive) as t:
  assert len([x for x in t.getmembers() if x.isfile()])==511;t.extractall(runtime,filter='data')
 for row in manifest['files']:assert sha(runtime/row['path'])==row['sha256'],row['path']
 assets=json.loads((BASE/'proof/shared_static_assets.json').read_text())
 for row in assets['files']:
  original=BASE/'source'/row['path'];assert sha(original)==row['sha256']
  dest=runtime/row['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(original.read_bytes())
 cmd=['/tmp/intl-country-ci-20261103/bin/python','-m','scripts.build_intl']
 record.update(state='BUILDING',input_archive_sha256=sha(archive),input_archive_bytes=archive.stat().st_size,input_manifest_sha256=sha(P/'input_manifest.json'),source_archive_sha256=sha(BASE/'source.tar'),collector_receipt=json.loads(raw)['sources']['intl_prices'],shared_assets=assets['files'],command=cmd,cwd=str(runtime));save()
 env=os.environ.copy()
 for k in ['PYTHONPATH','COLLECT_LANE','US_LANE']:env.pop(k,None)
 with (P/'ordinary_build.log').open('w') as log:r=subprocess.run(cmd,cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
 record.update(state='PASS' if r.returncode==0 else 'FAILED',exit_code=r.returncode,completed_at=now(),log_sha256=sha(P/'ordinary_build.log'))
 if (runtime/'site/intl.html').exists():record.update(html_sha256=sha(runtime/'site/intl.html'),html_bytes=(runtime/'site/intl.html').stat().st_size)
 save();print(json.dumps(record),flush=True)
except Exception as e:record.update(state='FAILED',error=repr(e),traceback=traceback.format_exc(),completed_at=now());save();raise
