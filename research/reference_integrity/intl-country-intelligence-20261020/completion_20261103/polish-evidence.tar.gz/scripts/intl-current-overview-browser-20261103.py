"""Read the actual complete-input build through normal controls; compare qualified owner projections."""
from pathlib import Path
from urllib.parse import urlparse
import datetime,functools,hashlib,http.server,json,threading,traceback
from playwright.sync_api import sync_playwright
ROOT=Path('/tmp/intl-paper-current-complete-20261103');OUT=ROOT/'proof';SHOTS=OUT/'screenshots';SHOTS.mkdir(exist_ok=True)
build=json.loads((OUT/'ordinary_build.json').read_text());assert build['state']=='PASS',build
expected=json.loads((OUT/'overview_expected.json').read_text())
panels={(x['overview']['context']['horizon'],x['overview']['context']['currency_basis']):x['overview'] for x in expected['panels']}
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(ROOT/'source/site')))
threading.Thread(target=server.serve_forever,daemon=True).start()
url='http://127.0.0.1:'+str(server.server_port)+'/intl.html'
record={'schema':'intl.current_input_overview.v1','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_tree':build['source_tree'],'html_sha256':build['html_sha256'],'input_commit':build['input_commit'],'input_count':511,'snapshot_date':expected['snapshot_date'],'scope':'Anonymous local actual ordinary HTML, normal UI controls, no invented data or forced state. Not deployed or a real Terminal parent.','states':[],'screenshots':[]}
def save():(OUT/'overview_browser.json').write_text(json.dumps(record,indent=2)+'\n')
def shot(page,name):
 path=SHOTS/(name+'.png');page.screenshot(path=str(path));record['screenshots'].append({'path':'screenshots/'+path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
def formatted(value):return (f'{value:+.2f}' if value>0 else f'{value:.2f}')+'%'
def dates(metric):
 w=metric.get('window');return [w['start'],w['end']] if w else []
save()
try:
 with sync_playwright() as pw:
  browser=pw.chromium.launch(channel='chrome',headless=True);record['browser']=browser.version
  for width,theme,lang in [(1440,'light','en'),(1440,'dark','zh'),(390,'light','en'),(320,'dark','zh')]:
   name=f'{width}-{theme}-{lang}';row={'name':name,'selections':[],'errors':[],'failed_responses':[]}
   ctx=browser.new_context(viewport={'width':width,'height':1000 if width==1440 else 844},device_scale_factor=1)
   ctx.route('**/*',lambda r:r.continue_() if urlparse(r.request.url).hostname=='127.0.0.1' else r.abort())
   ctx.add_init_script("localStorage.setItem('theme',"+json.dumps(theme)+");localStorage.setItem('lang',"+json.dumps(lang)+");localStorage.removeItem('themeAuto')")
   page=ctx.new_page();page.on('pageerror',lambda e,row=row:row['errors'].append(str(e)))
   page.on('response',lambda r,row=row:row['failed_responses'].append({'url':r.url,'status':r.status}) if r.status>=400 else None)
   try:
    page.goto(url,wait_until='domcontentloaded',timeout=60000);page.evaluate('document.fonts.ready')
    page.locator('.imc-country[open] .imc-outlook-panel').wait_for(state='visible',timeout=20000)
    page.wait_for_timeout(200)
    if width in [1440,390] and lang=='en':shot(page,name+'-country')
    page.locator('.imc-nav [data-imc-section="intl-analysis-tools"]').click()
    assert page.locator('#intl-analysis-tools').get_attribute('open') is not None
    row['snapshot_visible']=expected['snapshot_date'] in page.locator('#intl-analysis-tools').inner_text()
    assert row['snapshot_visible'],'Delayed snapshot date is missing'
    for horizon in ['1m','3m','6m','12m','ytd']:
     page.locator('select[data-im-action="set_horizon"]:visible').select_option(horizon)
     for basis in ['usd_unhedged','local']:
      page.locator('select[data-im-action="set_basis"]:visible').select_option(basis)
      panel=page.locator('[data-im-panel][data-view="overview"]:visible')
      assert panel.count()==1
      assert panel.get_attribute('data-horizon')==horizon and panel.get_attribute('data-basis')==basis
      model=panels[(horizon,basis)];trigger=panel.locator('[data-im-expansion-trigger]')
      assert trigger.get_attribute('aria-expanded')=='false','Returns must be available before expansion'
      eligible=[r for r in model['rows'] if r.get('quality') not in ['denied','unknown'] and r.get('market_id') and r['metric']['quality']=='qualified' and r['metric']['value'] is not None]
      assert len(eligible)==model['eligible_count']
      cell={'horizon':horizon,'basis':basis,'eligible_count':model['eligible_count'],'ranking_status':model['ranking_status'],'ranking_reason':model['ranking_reason'],'before_expand':True,'rows':[]}
      context=panel.locator('.intl-overview__context').inner_text()
      assert str(model['eligible_count']) in context
      if model['ranking_reason']=='unequal_windows':
       li=panel.locator('[data-im-unranked-item]');assert li.count()==len(eligible)>0
       assert panel.locator('[data-im-unranked-list]').evaluate('(x)=>x.tagName')=='UL'
       assert panel.locator('[data-im-focus-list]').count()==0
       for i,want in enumerate(eligible):
        item=li.nth(i);assert item.is_visible()
        value=item.locator('[data-im-return]').inner_text().strip()
        win=item.locator('time').evaluate_all('(xs)=>xs.map(x=>x.dateTime)')
        assert item.get_attribute('data-market-id')==want['market_id']
        assert value==formatted(want['metric']['value']),(name,horizon,basis,want['market_id'],value,want['metric'])
        assert win==dates(want['metric'])
        cell['rows'].append({'market':want['market_id'],'value':value,'window':win})
       summary=panel.locator('[data-im-summary]').inner_text()
       assert ('ranking is unavailable' in summary if lang=='en' else '暂不提供跨市场排名' in summary)
      elif model['ranking_status']=='available':
       focus=panel.locator('[data-im-focus-item]');assert focus.count()==len(model['focus_ids'])
       for i,market in enumerate(model['focus_ids']):
        want=next(r for r in model['rows'] if r.get('market_id')==market);item=focus.nth(i)
        assert item.is_visible() and item.get_attribute('data-market-id')==market
        assert item.locator('[data-im-return]').inner_text().strip()==formatted(want['metric']['value'])
      else:
       assert model['eligible_count']==0 and panel.locator('[data-im-unranked-item],[data-im-focus-item]').count()==0
      assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
      if horizon=='1m':
       panel.evaluate("(x)=>window.scrollTo({top:scrollY+x.getBoundingClientRect().top-64,behavior:'instant'})")
       page.wait_for_timeout(100);shot(page,name+'-overview-'+basis)
      trigger.click();assert trigger.get_attribute('aria-expanded')=='true'
      visible=panel.locator('[data-im-market]')
      for want in model['rows']:
       if want.get('quality') in ['denied','unknown']:continue
       actual=visible.filter(has=page.locator('[data-im-market-id]',has_text=want['market_id']))
       assert actual.count()==1
       value=actual.locator('[data-im-selected]').inner_text().strip()
       if want['metric']['value'] is None:assert '%' not in value
       else:assert value==formatted(want['metric']['value'])
       assert actual.locator('[data-im-window] time').evaluate_all('(xs)=>xs.map(x=>x.dateTime)')==dates(want['metric'])
      trigger.click();assert trigger.get_attribute('aria-expanded')=='false'
      cell['expanded_values_and_windows_match']=True;cell['pass']=True;row['selections'].append(cell);save()
    assert not row['errors'],row['errors']
    assert not row['failed_responses'],row['failed_responses']
    row['pass']=True
   except Exception as e:row.update({'pass':False,'error':str(e),'traceback':traceback.format_exc()})
   finally:
    record['states'].append(row);save();ctx.close();print(name,'PASS' if row.get('pass') else 'FAIL',flush=True)
  browser.close()
 record.update(completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),passed=all(x.get('pass') for x in record['states']),selection_count=sum(len(x['selections']) for x in record['states']))
 save()
finally:server.shutdown()
raise SystemExit(0 if record.get('passed') else 1)
