from pathlib import Path
from urllib.parse import urlparse
import datetime,functools,http.server,json,threading,traceback
from playwright.sync_api import sync_playwright
R=Path('/tmp/intl-paper-current-complete-20261103');P=R/'proof'
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
s=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(R/'source/site')));threading.Thread(target=s.serve_forever,daemon=True).start()
out={'schema':'intl.static_observer_diagnostic.v1','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'One unchanged expanded 3m-local state, eight bounded repetitions of earlier dense locator reads. No app navigation during repetitions, no GC or heap overrides. Diagnostic only.','cycles':[],'events':[]}
def save():(P/'static_observer_diagnostic.json').write_text(json.dumps(out,indent=2)+'\n')
save()
try:
 with sync_playwright() as pw:
  b=pw.chromium.launch(channel='chrome',headless=True);c=b.new_context(viewport={'width':1440,'height':1000})
  c.route('**/*',lambda r:r.continue_() if urlparse(r.request.url).hostname=='127.0.0.1' else r.abort())
  c.add_init_script("localStorage.setItem('theme','light');localStorage.setItem('lang','en');localStorage.removeItem('themeAuto')")
  p=c.new_page();cdp=c.new_cdp_session(p)
  def crash():out['events'].append('renderer_crash');save()
  p.on('crash',crash)
  p.goto('http://127.0.0.1:'+str(s.server_port)+'/intl.html',wait_until='domcontentloaded',timeout=60000);p.locator('.imc-country[open] .imc-outlook-panel').wait_for(state='visible')
  p.locator('.imc-nav [data-imc-section="intl-analysis-tools"]').click()
  p.locator('select[data-im-action="set_horizon"]:visible').select_option('3m');p.locator('select[data-im-action="set_basis"]:visible').select_option('local')
  panel=p.locator('[data-im-panel][data-view="overview"]:visible');panel.locator('[data-im-expansion-trigger]').click()
  li=panel.locator('[data-im-unranked-item]');assert li.count()==7
  for cycle in range(8):
   rows=[]
   for i in range(7):
    item=li.nth(i)
    market=item.get_attribute('data-market-id');value=item.locator('[data-im-return]').inner_text().strip();dates=item.locator('time').evaluate_all('(xs)=>xs.map(x=>x.dateTime)')
    assert item.is_visible()
    actual=panel.locator('[data-im-market]').filter(has=p.locator('[data-im-market-id]',has_text=market))
    assert actual.count()==1
    assert actual.locator('[data-im-selected]').inner_text().strip()==value
    assert actual.locator('[data-im-window] time').evaluate_all('(xs)=>xs.map(x=>x.dateTime)')==dates
    rows.append({'market':market,'value':value,'dates':dates})
   out['cycles'].append({'cycle':cycle,'rows':rows,'heap':cdp.send('Runtime.getHeapUsage'),'dom':cdp.send('Memory.getDOMCounters')});save();print('cycle',cycle,'PASS',flush=True)
  out.update(passed=True,completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save();c.close();b.close()
except Exception as e:out.update(passed=False,error=str(e),traceback=traceback.format_exc(),completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save();raise
finally:s.shutdown()
