from pathlib import Path
import datetime,hashlib,io,json,os,subprocess,tarfile,traceback
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018')
BASE=Path('/tmp/intl-paper-polish-final-20261103')
OUT=Path('/tmp/intl-paper-current-data-20261103');P=OUT/'proof'
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((BASE/'proof/source.json').read_text())
obj=json.loads((P/'input_git_objects.json').read_text());assert len(obj['files'])==510
record={'state':'PREPARING','started_at':now(),'source_tree':source['tree'],'runtime_hashes':source['runtime_hashes'],'input_commit':obj['commit'],'committed_inputs':510,'scope':'Same refined source rendered with exact protected-main data objects; not a source merge, reacquisition or deployment. Frozen design build unchanged.','prior_attempt':{'state':'TIMED_OUT_BEFORE_BUILD','step':'git archive input extraction','timeout_seconds':120,'archive_bytes':(OUT/'committed-inputs.tar').stat().st_size,'log_sha256':sha(Path('/tmp/intl-current-data-build-20261103.log'))}}
(P/'input_archive_timeout.log').write_bytes(Path('/tmp/intl-current-data-build-20261103.log').read_bytes())
def save(): (P/'ordinary_build.json').write_text(json.dumps(record,indent=2)+'\n')
save()
try:
 env=os.environ.copy();env['GIT_NO_LAZY_FETCH']='1';env['GIT_TERMINAL_PROMPT']='0'
 archive=OUT/'committed-inputs-v2.tar';assert not archive.exists()
 proc=subprocess.Popen(['git','cat-file','--batch'],cwd=W,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 rows=[]
 with tarfile.open(archive,'w') as t:
  for name,info in sorted(obj['files'].items()):
   proc.stdin.write((info['blob']+'\n').encode());proc.stdin.flush()
   fields=proc.stdout.readline().decode().strip().split();assert len(fields)==3 and fields[1]=='blob',fields
   size=int(fields[2]);content=proc.stdout.read(size);assert len(content)==size and proc.stdout.read(1)==b'\n'
   assert hashlib.sha1(b'blob '+str(size).encode()+b'\0'+content).hexdigest()==info['blob']
   m=tarfile.TarInfo(name);m.size=size;m.mode=int(info['mode'][-3:],8);m.mtime=0
   t.addfile(m,io.BytesIO(content))
   rows.append({'path':name,'git_blob':info['blob'],'bytes':size,'sha256':hashlib.sha256(content).hexdigest()})
 proc.stdin.close();assert proc.wait(timeout=10)==0
 (P/'input_manifest.json').write_text(json.dumps({'commit':obj['commit'],'files':rows},indent=2)+'\n')
 record.update(input_archive_sha256=sha(archive),input_archive_bytes=archive.stat().st_size,input_manifest_sha256=sha(P/'input_manifest.json'),state='EXTRACTING_SOURCE');save()
 print(json.dumps({'phase':record['state'],'input_files':len(rows),'input_bytes':sum(r['bytes'] for r in rows)}),flush=True)
 runtime=OUT/'source';assert not runtime.exists();runtime.mkdir()
 with tarfile.open(BASE/'source.tar') as t:t.extractall(runtime,filter='data')
 with tarfile.open(archive) as t:t.extractall(runtime,filter='data')
 assets=json.loads((BASE/'proof/shared_static_assets.json').read_text())
 for row in assets['files']:
  original=BASE/'source'/row['path'];assert sha(original)==row['sha256']
  dest=runtime/row['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(original.read_bytes())
 record.update(state='BUILDING',source_archive_sha256=sha(BASE/'source.tar'),shared_assets=assets['files'])
 cmd=['/tmp/intl-country-ci-20261103/bin/python','-m','scripts.build_intl'];record.update(command=cmd,cwd=str(runtime));save()
 env=os.environ.copy()
 for k in ['PYTHONPATH','COLLECT_LANE','US_LANE']:env.pop(k,None)
 with (P/'ordinary_build.log').open('w') as log:r=subprocess.run(cmd,cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
 record.update(state='PASS' if r.returncode==0 else 'FAILED',exit_code=r.returncode,completed_at=now(),log_sha256=sha(P/'ordinary_build.log'))
 if (runtime/'site/intl.html').exists():record.update(html_sha256=sha(runtime/'site/intl.html'),html_bytes=(runtime/'site/intl.html').stat().st_size)
 save();print(json.dumps(record),flush=True)
except Exception as e:
 record.update(state='FAILED',error=repr(e),traceback=traceback.format_exc(),completed_at=now());save();raise
