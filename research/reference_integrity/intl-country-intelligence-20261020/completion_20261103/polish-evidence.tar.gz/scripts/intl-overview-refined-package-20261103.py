from pathlib import Path
import datetime,hashlib,json,subprocess,yaml
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018')
R=Path('/tmp/intl-paper-overview-refined-20261103');P=R/'proof';C=R/'canonical'
D=W/'mockups/evidence/intl-overview-polish-20261103';assert not D.exists()
execution=json.loads((C/'capture_execution.json').read_text());assert execution['state']=='PASS'
m=json.loads((C/'manifest.json').read_text());assert m['schema']=='mastermind.p0_evidence.v2' and len(m['pages'])==1
page=m['pages'][0];assert len(page['states'])==8 and page['console_errors']==[] and page['failed_responses']==[]
assert all(s['captured'] and s['applied_theme']==s['theme'] and s['applied_locale']==s['locale'] for s in page['states'])
D.mkdir();(D/'images').mkdir();images=[]
for state in page['states']:
 raw=(C/state['file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==state['sha256'] and len(raw)==state['bytes']
 (D/state['file']).write_bytes(raw);images.append({'file':state['file'],'sha256':state['sha256'],'bytes':state['bytes']})
 state['capture_tool_module_sha256']=m['tool']['module_sha256']
page['page_tree_sha']=subprocess.check_output(['git','hash-object',str(R/'source/site/intl.html')],cwd=W,text=True).strip()
m['selection']['note']+='; Explicit ordinary overview deep link; page controller opens the retained Tools disclosure. Current protected-main inputs include the genuine collector receipt. No forced presentation or data fixture.'
(D/'manifest.json').write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n')
receipt={'schema':'mastermind.page_evidence_receipt.v1','changed_paths':['templates/intl_workspace.css','templates/intl_workspace/overview.html.j2'],'manifest':str((D/'manifest.json').relative_to(W))}
(D/'EVIDENCE.yml').write_text(yaml.safe_dump(receipt,sort_keys=False))
(P/'canonical_package.json').write_text(json.dumps({'source_tree':execution['source_tree'],'html_sha256':execution['html_sha256'],'capture_tool_module_sha256':execution['capture_tool_module_sha256'],'launch_adapter_sha256':execution['launch_adapter_sha256'],'observations':8,'images':images,'receipt':str((D/'EVIDENCE.yml').relative_to(W)),'manifest':str((D/'manifest.json').relative_to(W)),'original_manifest_sha256':hashlib.sha256((C/'manifest.json').read_bytes()).hexdigest()},indent=2)+'\n')
paths=['templates/intl_country_cockpit.html.j2','templates/intl_country_cockpit.css','templates/intl_country_cockpit.js','templates/intl_workspace.css','templates/intl_workspace/overview.html.j2']
diff=P/'all_polish_ui.diff';diff.write_bytes(subprocess.check_output(['git','diff','--unified=0','27aba2b875a00096c69841d926f48cca232a7a90','--',*paths],cwd=W))
cmd=['/tmp/intl-country-ci-20261103/bin/python','scripts/check_ui_visual_evidence.py','--diff-file',str(diff)]
rec={'state':'RUNNING','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'scope':'Combined polish UI delta covered by 14 genuine country observations and eight fresh actual overview observations; mechanical gate only.'}
with (P/'visual_evidence_guard.log').open('w') as log:r=subprocess.run(cmd,cwd=W,stdout=log,stderr=subprocess.STDOUT,timeout=180)
rec.update(state='PASS' if r.returncode==0 else 'FAILED',exit_code=r.returncode,completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),log_sha256=hashlib.sha256((P/'visual_evidence_guard.log').read_bytes()).hexdigest())
(P/'visual_evidence_guard.json').write_text(json.dumps(rec,indent=2)+'\n')
print(json.dumps({'state':rec['state'],'observations':8,'receipt':receipt}),flush=True)
