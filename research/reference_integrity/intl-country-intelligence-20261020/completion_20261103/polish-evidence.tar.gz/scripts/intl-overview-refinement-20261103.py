from pathlib import Path
import subprocess
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()=='851c6abebf01c5c8096e7822436455fd1040152a'
assert subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=W,text=True).strip()=='c6ac417f4a1d561f8c80a0a6b1977d5ffec6d090'
html=W/'templates/intl_workspace/overview.html.j2';css=W/'templates/intl_workspace.css';test=W/'tests/test_intl_workspace_overview_render.py'
assert 'macro window_date' not in html.read_text()
assert 'Compact, unranked' not in css.read_text()
assert 'test_window_display_preserves_exact_endpoints' not in test.read_text()
s=html.read_text();needle='{% macro quality_notice(metric) %}'
macro="""{# Daily midnight endpoints display as dates; machine-readable precision remains intact. #}
{% macro window_date(value) -%}
  {{ (value[:-9] if value.endswith('T00:00:00') else value)|e }}
{%- endmacro %}
"""
assert s.count(needle)==1;s=s.replace(needle,macro+needle)
old='<div class="intl-overview__first-read">'
new='<div class="intl-overview__first-read{% if overview.ranking_reason == \'unequal_windows\' and projection_context.eligible_count > 0 %} intl-overview__first-read--unranked{% endif %}">'
assert s.count(old)==1;s=s.replace(old,new)
for end in ['start','end']:
 old='>{{ row.metric.window.'+end+'|e }}</time>';new='>{{ window_date(row.metric.window.'+end+') }}</time>'
 assert s.count(old)==2;s=s.replace(old,new)
html.write_text(s)
addition="""
/* Compact, unranked evidence: qualification stays adjacent to readable market rows. */
.intl-overview__first-read--unranked { grid-template-columns:minmax(0,1fr); gap:var(--fs-body); }
.intl-overview__first-read--unranked .intl-overview__summary { display:flex; flex-wrap:wrap; align-items:baseline; gap:calc(var(--fs-body) / 2) calc(var(--fs-body) * 1.5); padding:var(--fs-body) calc(var(--fs-body) * 1.5); background:var(--panel2); box-shadow:none; }
.intl-overview__first-read--unranked .intl-overview__summary h3 { font-size:var(--fs-body); margin:0; }
.intl-overview__first-read--unranked .intl-overview__summary p { margin:0; font-size:var(--fs-sm); color:var(--muted); }
.intl-overview__first-read--unranked .intl-overview__focus > h3 { padding:var(--fs-body) * 1; padding:var(--fs-body) calc(var(--fs-body) * 1.5); font-size:var(--fs-body); }
.intl-overview__first-read--unranked .intl-overview__focus-list { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); }
.intl-overview__first-read--unranked .intl-overview__focus-list > li { grid-template-columns:minmax(0,1fr) minmax(0,auto); padding:var(--fs-body) calc(var(--fs-body) * 1.5); }
.intl-overview__first-read--unranked .intl-overview__focus-list > li + li { border-block-start:0; }
.intl-overview__first-read--unranked .intl-overview__focus-list > li:nth-child(n+3) { border-block-start:1px solid var(--line); }
.intl-overview__first-read--unranked .intl-overview__focus-list > li:nth-child(even) { border-inline-start:1px solid var(--line); }
.intl-overview__first-read--unranked .intl-overview__return { grid-column:2; grid-row:1 / span 2; text-align:end; }
.intl-overview__first-read--unranked [data-im-return-window] { grid-column:1 / -1; font-variant-numeric:tabular-nums; }
@media (max-width:768px) {
  .intl-overview__first-read--unranked .intl-overview__focus-list { grid-template-columns:minmax(0,1fr); }
  .intl-overview__first-read--unranked .intl-overview__focus-list > li:nth-child(even) { border-inline-start:0; }
  .intl-overview__first-read--unranked .intl-overview__focus-list > li + li { border-block-start:1px solid var(--line); }
}
@media (max-width:390px) {
  .intl-overview__first-read--unranked .intl-overview__summary,
  .intl-overview__first-read--unranked .intl-overview__focus > h3,
  .intl-overview__first-read--unranked .intl-overview__focus-list > li { padding:var(--fs-body); }
}
"""
addition=addition.replace('padding:var(--fs-body) * 1; ','')
css.write_text(css.read_text().rstrip()+'\n'+addition)
extra="""

@pytest.mark.parametrize(
    "start,end,visible",
    [
        ("2026-10-01T00:00:00", "2026-10-30T00:00:00", ["2026-10-01", "2026-10-30"]),
        ("2026-10-01T16:30:00", "2026-10-30T16:30:00", ["2026-10-01T16:30:00", "2026-10-30T16:30:00"]),
        ("2026-10-01", "2026-10-30", ["2026-10-01", "2026-10-30"]),
    ],
)
def test_window_display_preserves_exact_endpoints(start, end, visible):
    fixture = projection([metric_row(0, "JP", 0.0, window={"start": start, "end": end})], available=False)
    fixture["ranking_reason"] = fixture["summary"]["reason"] = "unequal_windows"
    _, root = rendered(fixture, "daily-window")
    for container in [one(root, "data-im-return-window"), one(root, "data-im-window")]:
        times = [node for node in walk(container) if node.tag == "time"]
        assert [node.attrs["datetime"] for node in times] == [start, end]
        assert [node.text.strip() for node in times] == visible
    assert visible_text(one(root, "data-im-return")).strip() == "0.00%"
"""
test.write_text(test.read_text()+extra)
print('Applied compact mixed-window layout and date display with preserved exact datetime attributes.')
