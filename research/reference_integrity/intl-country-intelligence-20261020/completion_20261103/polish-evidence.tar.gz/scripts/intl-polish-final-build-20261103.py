from pathlib import Path
import concurrent.futures,datetime,hashlib,json,os,subprocess,tarfile
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018')
OUT=Path('/tmp/intl-paper-polish-final-20261103')
PREV=Path('/tmp/intl-paper-polish-r2-20261103')
assert not OUT.exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()=='851c6abebf01c5c8096e7822436455fd1040152a'
assert subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=W,text=True).strip()=='c6ac417f4a1d561f8c80a0a6b1977d5ffec6d090'
assert subprocess.check_output(['git','write-tree'],cwd=W,text=True).strip()=='6f88b1d6b2cc6e7764439b339741584c3b6eeba6'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
prior=json.loads((PREV/'proof/source.json').read_text())
for p in ['templates/intl_country_cockpit.html.j2','templates/intl_country_cockpit.js']:
 assert sha(W/p)==prior['runtime_hashes'][p],p
expected=(PREV/'source/templates/intl_country_cockpit.css').read_text().replace('background: color-mix(in srgb, var(--panel) 72%, var(--bg));','background: var(--bg);').replace('border-color: color-mix(in srgb, var(--link) 22%, var(--line));','border-color: var(--imc-country-line, var(--line));')
assert (W/'templates/intl_country_cockpit.css').read_text()==expected
nav=json.loads((PREV/'proof/country_navigation_focus_identity.json').read_text())
assert nav['state']=='PASS'
assert sha(W/'tests/intl_country_cockpit_navigation.test.cjs')==nav['test_sha256']
OUT.mkdir();P=OUT/'proof';P.mkdir()
subprocess.run(['git','add','--','templates/intl_country_cockpit.css','tests/intl_country_cockpit_navigation.test.cjs'],cwd=W,check=True)
tree=subprocess.check_output(['git','write-tree'],cwd=W,text=True).strip()
delta=subprocess.check_output(['git','diff','--name-only',prior['tree'],tree],cwd=W,text=True).splitlines()
assert set(delta)=={'templates/intl_country_cockpit.css','tests/intl_country_cockpit_navigation.test.cjs'},delta
runtime={p:sha(W/p) for p in prior['runtime_hashes']}
(P/'source.json').write_text(json.dumps({'tree':tree,'baseline_tree':'27aba2b875a00096c69841d926f48cca232a7a90','prior_tree':prior['tree'],'head':'851c6abebf01c5c8096e7822436455fd1040152a','merge_head':'c6ac417f4a1d561f8c80a0a6b1977d5ffec6d090','runtime_hashes':runtime,'delta_from_r2':delta,'runtime_change_from_r2':'Two existing shared color tokens replace the rejected color-mix expressions; geometry, markup, data and controller are unchanged.','navigation_test_sha256':nav['test_sha256'],'scope':'local prepared source; not committed or deployed'},indent=2)+'\n')
paths=['templates/intl_country_cockpit.html.j2','templates/intl_country_cockpit.css','templates/intl_country_cockpit.js','tests/test_intl_country_cockpit.py','tests/intl_country_cockpit_navigation.test.cjs']
diff=P/'polish_source.diff'
diff.write_bytes(subprocess.check_output(['git','diff','--unified=0','27aba2b875a00096c69841d926f48cca232a7a90','--',*paths],cwd=W))
def run(name,cmd,cwd=W,env=None,timeout=240):
 rec={'state':'RUNNING','name':name,'command':cmd,'cwd':str(cwd),'started_at':now()}
 f=P/(name+'.json');f.write_text(json.dumps(rec,indent=2)+'\n')
 with (P/(name+'.log')).open('w') as log:
  try:
   r=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
   rec.update(state='PASS' if r.returncode==0 else 'FAILED',exit_code=r.returncode)
  except subprocess.TimeoutExpired:rec.update(state='TIMED_OUT')
 rec.update(completed_at=now(),log_sha256=sha(P/(name+'.log')))
 f.write_text(json.dumps(rec,indent=2)+'\n')
 print(json.dumps({'name':name,'state':rec['state']}),flush=True)
 return rec
def build():
 archive=OUT/'source.tar'
 subset=['config.yml','config','collectors','engine','lib','scripts','templates','requirements.txt','site/fonts','site/favicon.svg']
 subprocess.run(['git','archive','--format=tar','--output='+str(archive),tree,*subset],cwd=W,check=True,timeout=120)
 source=OUT/'source';source.mkdir()
 with tarfile.open(archive) as t:t.extractall(source,filter='data')
 inputs=Path('/tmp/intl-paper-build-20261103/committed-inputs.tar')
 assert sha(inputs)=='0e982fa2581d2b63b3a803f69b9bbcdb883fbba61695b05b1ff7f7101d854104'
 with tarfile.open(inputs) as t:t.extractall(source,filter='data')
 env=os.environ.copy()
 for k in ['PYTHONPATH','COLLECT_LANE','US_LANE']:env.pop(k,None)
 rec=run('ordinary_build',['/tmp/intl-country-ci-20261103/bin/python','-m','scripts.build_intl'],cwd=source,env=env,timeout=600)
 rec.update(source_tree=tree,source_archive_sha256=sha(archive),input_commit='c6ac417f4a1d561f8c80a0a6b1977d5ffec6d090',committed_inputs=510,input_archive_sha256=sha(inputs),no_reacquisition=True,no_production_mutation=True)
 if (source/'site/intl.html').exists():rec.update(html_sha256=sha(source/'site/intl.html'),html_bytes=(source/'site/intl.html').stat().st_size)
 (P/'ordinary_build.json').write_text(json.dumps(rec,indent=2)+'\n')
 print(json.dumps(rec),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 tasks=[pool.submit(build),pool.submit(run,'design_added',['/tmp/intl-country-ci-20261103/bin/python','scripts/check_design_system.py','--mode','enforce-added','--diff-file',str(diff)])]
 for task in tasks:task.result()
