from pathlib import Path
import os,sys,json,hashlib,uuid
R=Path('/tmp/intl-paper-current-complete-20261103');os.chdir(R/'source');sys.path.insert(0,str(R/'source'))
from lib import config
from engine import intl_inputs
from lib.intl_eod_publication import build_eod_inputs
from engine.intl_workspace_overview import build_workspace_overviews
b=json.loads((R/'proof/ordinary_build.json').read_text())
pair=build_eod_inputs(intl_inputs._intl_closes(),data_root=config.data_dir(),evaluated_at=b['started_at'],rights=config.load()['intl']['eod_publication'])
assert pair is not None
closes,inputs=pair
ws=build_workspace_overviews(closes,production_inputs=inputs,workspace_generation='im-workspace-generation:'+str(uuid.uuid4()))
out={'source_tree':b['source_tree'],'input_commit':b['input_commit'],'evaluated_at':b['started_at'],'snapshot_date':closes.index[-1].date().isoformat(),'note':'Expected projection independently invoked through ordinary source and qualification owners with exact same stored inputs; no invented rights or values. Generation nonce omitted from numerical comparisons.','panels':ws['panels']}
(R/'proof/overview_expected.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'snapshot_date':out['snapshot_date'],'panels':[{'horizon':p['overview']['context']['horizon'],'basis':p['overview']['context']['currency_basis'],'eligible':p['overview']['eligible_count'],'ranking':p['overview']['ranking_status'],'reason':p['overview']['ranking_reason']} for p in ws['panels']]},indent=2))
