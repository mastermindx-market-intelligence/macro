from pathlib import Path
import datetime,hashlib,json,os,subprocess,tarfile
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018')
BASE=Path('/tmp/intl-paper-polish-final-20261103')
OUT=Path('/tmp/intl-paper-current-data-20261103')
INPUT='19a896b97ae20f2c12475a0207678f92dc4f335b'
assert not OUT.exists();OUT.mkdir();P=OUT/'proof';P.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
source=json.loads((BASE/'proof/source.json').read_text())
with tarfile.open('/tmp/intl-paper-build-20261103/committed-inputs.tar') as t:paths=[x.name for x in t.getmembers() if x.isfile()]
assert len(paths)==510
archive=OUT/'committed-inputs.tar'
subprocess.run(['git','archive','--format=tar','--output='+str(archive),INPUT,'--',*paths],cwd=W,check=True,timeout=120)
runtime=OUT/'source';runtime.mkdir()
with tarfile.open(BASE/'source.tar') as t:t.extractall(runtime,filter='data')
with tarfile.open(archive) as t:
 files=[x for x in t.getmembers() if x.isfile()]
 assert {x.name for x in files}==set(paths)
 t.extractall(runtime,filter='data')
assets=json.loads((BASE/'proof/shared_static_assets.json').read_text())
for row in assets['files']:
 original=BASE/'source'/row['path'];assert sha(original)==row['sha256']
 dest=runtime/row['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(original.read_bytes())
record={'state':'RUNNING','started_at':now(),'source_tree':source['tree'],'runtime_hashes':source['runtime_hashes'],'source_archive_sha256':sha(BASE/'source.tar'),'input_commit':INPUT,'committed_inputs':510,'input_archive_sha256':sha(archive),'scope':'Separate compatibility render with current committed production inputs; not a source merge, provider reacquisition or deployment. Frozen design build is unchanged.','shared_assets':assets['files']}
cmd=['/tmp/intl-country-ci-20261103/bin/python','-m','scripts.build_intl']
record.update(command=cmd,cwd=str(runtime))
(P/'ordinary_build.json').write_text(json.dumps(record,indent=2)+'\n')
env=os.environ.copy()
for k in ['PYTHONPATH','COLLECT_LANE','US_LANE']:env.pop(k,None)
with (P/'ordinary_build.log').open('w') as log:
 try:
  r=subprocess.run(cmd,cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
  record.update(state='PASS' if r.returncode==0 else 'FAILED',exit_code=r.returncode)
 except subprocess.TimeoutExpired:record.update(state='TIMED_OUT')
record.update(completed_at=now(),log_sha256=sha(P/'ordinary_build.log'))
if (runtime/'site/intl.html').exists():record.update(html_sha256=sha(runtime/'site/intl.html'),html_bytes=(runtime/'site/intl.html').stat().st_size)
(P/'ordinary_build.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
