from pathlib import Path
from urllib.parse import urlparse
import datetime,functools,hashlib,http.server,json,threading,traceback
from playwright.sync_api import sync_playwright
R=Path('/tmp/intl-paper-overview-refined-20261103');P=R/'proof';S=P/'screenshots';S.mkdir(exist_ok=True)
build=json.loads((P/'ordinary_build.json').read_text());assert build['state']=='PASS'
expected=json.loads((P/'overview_expected.json').read_text())
models={p['overview']['context']['currency_basis']:p['overview'] for p in expected['panels'] if p['overview']['context']['horizon']=='1m'}
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(R/'source/site')))
threading.Thread(target=server.serve_forever,daemon=True).start()
rec={'schema':'intl.current_overview_batched.v1','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_tree':build['source_tree'],'html_sha256':build['html_sha256'],'input_commit':build['input_commit'],'input_count':511,'snapshot_date':expected['snapshot_date'],'scope':'Eight normal one-month UI selections, exact owner-model checks using a single scoped DOM observation per state; actual local build, not production or long-session stability acceptance. Original dense-observer crash and successful diagnostic sequences remain retained; this fresh build additionally verifies the compact notice and daily date display.','states':[],'screenshots':[]}
def save():(P/'overview_batched_browser.json').write_text(json.dumps(rec,indent=2)+'\n')
def fmt(v):return (f'{v:+.2f}' if v>0 else f'{v:.2f}')+'%'
def dates(row):
 w=row['metric'].get('window');return [w['start'],w['end']] if w else []
def read(page):
 return page.evaluate("""()=>{const p=Array.from(document.querySelectorAll('[data-im-panel][data-view="overview"]')).find(x=>x.getBoundingClientRect().width);const dates=x=>Array.from(x.querySelectorAll('time')).map(t=>t.dateTime);return {horizon:p.dataset.horizon,basis:p.dataset.basis,expanded:p.querySelector('[data-im-expansion-trigger]').getAttribute('aria-expanded'),context:p.querySelector('.intl-overview__context').innerText,summary:p.querySelector('[data-im-summary]').innerText,listTag:p.querySelector('[data-im-unranked-list]')?.tagName,orderedFocus:p.querySelectorAll('[data-im-focus-list]').length,rows:Array.from(p.querySelectorAll('[data-im-unranked-item]')).map(x=>({market:x.dataset.marketId,value:x.querySelector('[data-im-return]').innerText.trim(),dates:dates(x),displayDates:Array.from(x.querySelectorAll('time')).map(t=>t.textContent.trim()),visible:!!x.getBoundingClientRect().width})),allRows:Array.from(p.querySelectorAll('[data-im-market]')).map(x=>({market:x.querySelector('[data-im-market-id]').innerText.trim(),value:x.querySelector('[data-im-selected]').innerText.trim(),dates:dates(x.querySelector('[data-im-metrics]'))})),viewport:innerWidth,documentWidth:document.documentElement.scrollWidth,noticeHeight:p.querySelector('[data-im-summary]').getBoundingClientRect().height,compact:p.querySelector('.intl-overview__first-read--unranked')!==null}}""")
def shot(page,name):
 p=S/(name+'.png');page.screenshot(path=str(p));rec['screenshots'].append({'path':'screenshots/'+p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
save()
try:
 with sync_playwright() as pw:
  b=pw.chromium.launch(channel='chrome',headless=True);rec['browser']=b.version
  for width,theme,lang in [(1440,'light','en'),(1440,'dark','zh'),(390,'light','en'),(320,'dark','zh')]:
   name=f'{width}-{theme}-{lang}';row={'name':name,'selections':[],'errors':[],'failed_responses':[]};rec['states'].append(row);save()
   c=b.new_context(viewport={'width':width,'height':1000 if width==1440 else 844},device_scale_factor=1)
   c.route('**/*',lambda r:r.continue_() if urlparse(r.request.url).hostname=='127.0.0.1' else r.abort())
   c.add_init_script("localStorage.setItem('theme',"+json.dumps(theme)+");localStorage.setItem('lang',"+json.dumps(lang)+");localStorage.removeItem('themeAuto')")
   p=c.new_page();p.on('pageerror',lambda e,row=row:row['errors'].append(str(e)));p.on('response',lambda r,row=row:row['failed_responses'].append({'url':r.url,'status':r.status}) if r.status>=400 else None)
   try:
    p.goto('http://127.0.0.1:'+str(server.server_port)+'/intl.html',wait_until='domcontentloaded',timeout=60000);p.evaluate('document.fonts.ready');p.locator('.imc-country[open] .imc-outlook-panel').wait_for(state='visible',timeout=20000);p.wait_for_timeout(180)
    if lang=='en':shot(p,'final-'+name+'-country')
    p.locator('.imc-nav [data-imc-section="intl-analysis-tools"]').click()
    assert expected['snapshot_date'] in p.locator('#intl-analysis-tools').inner_text()
    for basis in ['usd_unhedged','local']:
     p.locator('select[data-im-action="set_basis"]:visible').select_option(basis)
     data=read(p);model=models[basis]
     assert data['horizon']=='1m' and data['basis']==basis and data['expanded']=='false'
     want=[r for r in model['rows'] if r.get('quality') not in ['denied','unknown'] and r.get('market_id') and r['metric']['quality']=='qualified' and r['metric']['value'] is not None]
     assert len(want)==model['eligible_count']==len(data['rows'])==5
     assert data['listTag']=='UL' and data['orderedFocus']==0
     assert data['documentWidth']<=data['viewport']+1
     assert data['compact'] and data['noticeHeight']<(100 if width==1440 else 200)
     for actual,target in zip(data['rows'],want):
      assert actual['visible'] and actual['market']==target['market_id']
      assert actual['value']==fmt(target['metric']['value']) and actual['dates']==dates(target),(actual,target)
      assert actual['displayDates']==[v[:-9] if v.endswith('T00:00:00') else v for v in dates(target)]
     assert ('ranking is unavailable' in data['summary'] if lang=='en' else '暂不提供跨市场排名' in data['summary'])
     panel=p.locator('[data-im-panel][data-view="overview"]:visible');panel.evaluate("(x)=>window.scrollTo({top:scrollY+x.getBoundingClientRect().top-64,behavior:'instant'})");p.wait_for_timeout(100)
     shot(p,'final-'+name+'-overview-'+basis)
     trigger=panel.locator('[data-im-expansion-trigger]');trigger.click();expanded=read(p);assert expanded['expanded']=='true'
     for target in model['rows']:
      if target.get('quality') in ['denied','unknown']:continue
      actual=next(r for r in expanded['allRows'] if r['market']==target['market_id'])
      if target['metric']['value'] is None:assert '%' not in actual['value']
      else:assert actual['value']==fmt(target['metric']['value'])
      assert actual['dates']==dates(target),(actual,target)
     trigger.click();assert read(p)['expanded']=='false'
     row['selections'].append({'basis':basis,'overview':data,'expanded_exact':True,'pass':True});save()
    p.locator('select[data-im-action="set_basis"]:visible').select_option('usd_unhedged');returned=read(p)
    assert returned['rows']==row['selections'][0]['overview']['rows']
    row['round_trip_restores_values']=True
    assert not row['errors'] and not row['failed_responses'],(row['errors'],row['failed_responses'])
    row['pass']=True
   except Exception as e:row.update(pass_=False,error=str(e),traceback=traceback.format_exc())
   finally:save();c.close();print(name,'PASS' if row.get('pass') else 'FAIL',flush=True)
  b.close()
 rec.update(passed=all(x.get('pass') for x in rec['states']),selection_count=sum(len(x['selections']) for x in rec['states']),completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
finally:server.shutdown()
raise SystemExit(0 if rec.get('passed') else 1)