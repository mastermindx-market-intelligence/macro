from pathlib import Path
import functools,http.server,threading,json,datetime
from urllib.parse import urlparse
from playwright.sync_api import sync_playwright
R=Path('/tmp/intl-paper-current-data-20261103');P=R/'proof'
build=json.loads((P/'ordinary_build.json').read_text());assert build['state']=='PASS',build
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
s=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(R/'source/site')))
threading.Thread(target=s.serve_forever,daemon=True).start()
try:
 with sync_playwright() as pw:
  b=pw.chromium.launch(channel='chrome',headless=True);c=b.new_context(viewport={'width':1440,'height':1000})
  c.route('**/*',lambda r:r.continue_() if urlparse(r.request.url).hostname=='127.0.0.1' else r.abort())
  c.add_init_script("localStorage.setItem('theme','light');localStorage.setItem('lang','en');localStorage.removeItem('themeAuto')")
  p=c.new_page();p.goto('http://127.0.0.1:'+str(s.server_port)+'/intl.html',wait_until='domcontentloaded',timeout=60000)
  p.locator('.imc-nav [data-imc-section="intl-analysis-tools"]').click();p.wait_for_timeout(300)
  data=p.evaluate("""() => ({
   title:document.title,
   toolsOpen:document.querySelector('#intl-analysis-tools').open,
   controls:Array.from(document.querySelectorAll('[data-im-action]')).filter(x=>x.getBoundingClientRect().width).map(x=>({tag:x.tagName,action:x.dataset.imAction,id:x.id,value:x.value,text:x.innerText.slice(0,120),options:x.tagName==='SELECT'?Array.from(x.options).map(o=>({value:o.value,text:o.text})):undefined})),
   activePanels:Array.from(document.querySelectorAll('[data-im-panel]')).filter(x=>x.getBoundingClientRect().width).map(x=>({id:x.id,view:x.dataset.view,horizon:x.dataset.horizon,basis:x.dataset.basis,text:x.innerText.slice(0,4000)})),
   oneMonthPanels:Array.from(document.querySelectorAll('[data-im-panel][data-view="overview"][data-horizon="1m"]')).map(x=>({id:x.id,basis:x.dataset.basis,qualified:x.querySelector('.intl-overview__context').innerText,summary:x.querySelector('[data-im-summary]').innerText,rows:Array.from(x.querySelectorAll('[data-im-unranked-item]')).map(r=>({market:r.dataset.marketId,text:r.innerText,dates:Array.from(r.querySelectorAll('time')).map(t=>t.dateTime)}))})),
   scripts:Array.from(document.querySelectorAll('script[type="application/json"]')).map(x=>({id:x.id,keys:(()=>{try{return Object.keys(JSON.parse(x.textContent))}catch{return []}})()})),
   headings:Array.from(document.querySelectorAll('#intl-analysis-tools>summary,#intl-analysis-tools p')).slice(0,6).map(x=>x.innerText)
  })""")
  data.update(html_sha256=build['html_sha256'],input_commit=build['input_commit'])
  (P/'overview_dom_inspection.json').write_text(json.dumps(data,indent=2)+'\n')
  print(json.dumps(data,indent=2)[:16000])
  c.close();b.close()
finally:s.shutdown()
