from pathlib import Path
import datetime,hashlib,json,sys
from playwright.sync_api import sync_playwright
W=Path('/Volumes/Mastermind 2/agent-workspaces/macro/web/intl-country-cockpit-20261018');sys.path.insert(0,str(W))
from scripts import capture_page_evidence as capture
R=Path('/tmp/intl-paper-overview-refined-20261103');O=R/'canonical';assert not O.exists();O.mkdir()
rec={'state':'RUNNING','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_tree':json.loads((R/'proof/source.json').read_text())['tree'],'html_sha256':hashlib.sha256((R/'source/site/intl.html').read_bytes()).hexdigest(),'capture_tool_module_sha256':hashlib.sha256((W/'scripts/capture_page_evidence.py').read_bytes()).hexdigest(),'launch_adapter_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Actual ordinary current-input build, anonymous public overview deep link; native controller opens Tools and the requested anchor. No forced classes, DOM mutations or fabricated observations.'}
def save():(O/'capture_execution.json').write_text(json.dumps(rec,indent=2)+'\n')
def driver(**kwargs):
 m=sync_playwright().start()
 try:b=m.chromium.launch(channel='chrome',headless=kwargs['headless'])
 except Exception:m.stop();raise
 rec['browser_version']=b.version
 return capture._PlaywrightDriver(m,b,kwargs['user_agent'],dict(kwargs['observer_config']),kwargs['settle_ms'])
args=['--registry',str(W/'data/product_experience/page_registry.json'),'--site-dir',str(R/'source/site'),'--routes','/intl.html?view=overview#im-overview-0-overview','--output-dir',str(O/'images'),'--manifest',str(O/'manifest.json'),'--smells',str(O/'smells.json'),'--viewports','desktop,mobile','--locales','en,zh','--themes','light,dark','--max-pages','1','--delay-ms','0','--settle-ms','1400','--timeout-s','60']
rec['arguments']=args;save()
try:
 code=capture.main(args,driver_factory=driver);rec.update(state='PASS' if code==0 else 'FAILED',exit_code=code)
 if (O/'manifest.json').exists():rec['manifest_sha256']=hashlib.sha256((O/'manifest.json').read_bytes()).hexdigest()
except Exception as e:rec.update(state='FAILED',error=str(e));raise
finally:rec['completed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps(rec),flush=True)
