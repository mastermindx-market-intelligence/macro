from pathlib import Path
from urllib.parse import urlparse
import datetime,functools,http.server,json,threading,traceback,time
from playwright.sync_api import sync_playwright
R=Path('/tmp/intl-paper-current-complete-20261103');P=R/'proof'
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
s=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(R/'source/site')))
threading.Thread(target=s.serve_forever,daemon=True).start()
out={'schema':'intl.overview_minimal_probe.v1','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'html_sha256':json.loads((P/'ordinary_build.json').read_text())['html_sha256'],'scope':'Same ordinary UI action sequence with batched scoped DOM observations and passive CDP memory metrics; no GC, browser heap flags or application changes.','steps':[],'events':[]}
def save():(P/'overview_minimal_probe.json').write_text(json.dumps(out,indent=2)+'\n')
save()
try:
 with sync_playwright() as pw:
  b=pw.chromium.launch(channel='chrome',headless=True);c=b.new_context(viewport={'width':1440,'height':1000})
  c.route('**/*',lambda r:r.continue_() if urlparse(r.request.url).hostname=='127.0.0.1' else r.abort())
  c.add_init_script("localStorage.setItem('theme','light');localStorage.setItem('lang','en');localStorage.removeItem('themeAuto')")
  page=c.new_page();cdp=c.new_cdp_session(page)
  def ev(t,v=None):out['events'].append({'at':time.monotonic(),'type':t,'value':v});save()
  page.on('crash',lambda:ev('renderer_crash'));page.on('pageerror',lambda e:ev('pageerror',str(e)))
  def observe(label):
   start=time.monotonic()
   data=page.evaluate("""() => {const p=Array.from(document.querySelectorAll('[data-im-panel][data-view="overview"]')).find(x=>x.getBoundingClientRect().width);return {panel:p?{horizon:p.dataset.horizon,basis:p.dataset.basis,summary:p.querySelector('[data-im-summary]').innerText,expanded:p.querySelector('[data-im-expansion-trigger]').getAttribute('aria-expanded'),returns:Array.from(p.querySelectorAll('[data-im-unranked-item]')).map(x=>({market:x.dataset.marketId,value:x.querySelector('[data-im-return]').innerText,dates:Array.from(x.querySelectorAll('time')).map(t=>t.dateTime)}))}:null,viewport:innerWidth,documentWidth:document.documentElement.scrollWidth}}""")
   row={'label':label,'seconds':round(time.monotonic()-start,3),'dom':data,'heap':cdp.send('Runtime.getHeapUsage'),'dom_counters':cdp.send('Memory.getDOMCounters')}
   out['steps'].append(row);save();print(label,round(row['heap']['usedSize']/1024**2,1),row['dom_counters'],flush=True)
  page.goto('http://127.0.0.1:'+str(s.server_port)+'/intl.html',wait_until='domcontentloaded',timeout=60000)
  page.locator('.imc-country[open] .imc-outlook-panel').wait_for(state='visible',timeout=20000);page.evaluate('document.fonts.ready')
  observe('country_entry')
  page.locator('.imc-nav [data-imc-section="intl-analysis-tools"]').click();observe('overview_entry')
  for horizon in ['1m','3m','6m','12m','ytd']:
   page.locator('select[data-im-action="set_horizon"]:visible').select_option(horizon)
   for basis in ['usd_unhedged','local']:
    page.locator('select[data-im-action="set_basis"]:visible').select_option(basis);observe(horizon+'-'+basis)
    trigger=page.locator('[data-im-panel][data-view="overview"]:visible [data-im-expansion-trigger]')
    trigger.click();observe(horizon+'-'+basis+'-expanded');trigger.click()
  out.update(pass_=True,completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save();c.close();b.close()
except Exception as e:out.update(pass_=False,error=str(e),traceback=traceback.format_exc(),completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save();raise
finally:s.shutdown()
