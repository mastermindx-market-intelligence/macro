"""Exercise the actual ordinary-build output in anonymous Chrome contexts."""
from pathlib import Path
from urllib.parse import urlparse
import datetime, functools, hashlib, http.server, json, threading, time
from playwright.sync_api import sync_playwright
OUT=Path(__file__).resolve().parent
SITE=Path("/tmp/intl-paper-build-20261103/source/site")
SHOTS=Path("/tmp/intl-paper-build-20261103/evidence")
SHOTS.mkdir(exist_ok=True)
class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*args): pass
server=http.server.ThreadingHTTPServer(("127.0.0.1",0),functools.partial(QuietHandler,directory=str(SITE)))
threading.Thread(target=server.serve_forever,daemon=True).start()
url="http://127.0.0.1:"+str(server.server_port)+"/intl.html"
record={"schema":"intl.completion_browser.v1","started_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"html_sha256":hashlib.sha256((SITE/"intl.html").read_bytes()).hexdigest(),"kind":"ordinary build; committed production inputs; anonymous local browser; no deployment","states":[],"journeys":[]}
def save(): (OUT/"browser.json").write_text(json.dumps(record,indent=2)+"\n")
def route(request):
    if urlparse(request.request.url).hostname=="127.0.0.1":request.continue_()
    else:request.abort()
def context_for(browser,width,theme,lang,javascript=True):
    context=browser.new_context(viewport={"width":width,"height":1000 if width==1440 else 844},device_scale_factor=1,java_script_enabled=javascript)
    context.route("**/*",route)
    if javascript:context.add_init_script("localStorage.setItem('theme',"+json.dumps(theme)+");localStorage.setItem('lang',"+json.dumps(lang)+");localStorage.removeItem('themeAuto');")
    return context
save()
try:
 with sync_playwright() as pw:
  browser=pw.chromium.launch(channel="chrome",headless=True)
  for width in [1440,390,320]:
   for theme in ["dark","light"]:
    for lang in ["en","zh"]:
     name=f"{width}-{theme}-{lang}"
     row={"state":name,"checks":[],"errors":[]}
     ctx=context_for(browser,width,theme,lang);page=ctx.new_page();page.on("pageerror",lambda e,row=row:row["errors"].append(str(e)))
     try:
      start=time.monotonic();page.goto(url,wait_until="domcontentloaded",timeout=60000)
      page.locator(".imc-country[open] .imc-outlook-panel").wait_for(state="visible",timeout=20000)
      page.evaluate("document.fonts.ready");page.wait_for_timeout(250)
      row["load_seconds"]=round(time.monotonic()-start,3)
      row["country_count"]=page.locator(".imc-country").count()
      assert row["country_count"]==7
      row["layout"]=page.evaluate("({width:innerWidth,scrollWidth:document.documentElement.scrollWidth,theme:document.documentElement.dataset.theme,lang:document.documentElement.dataset.lang})")
      assert row["layout"]["scrollWidth"]<=width+1,row["layout"]
      assert row["layout"]["theme"]==theme and row["layout"]["lang"]==lang,row["layout"]
      shot=SHOTS/(name+".png");page.screenshot(path=str(shot))
      row["screenshot"]={"path":str(shot),"sha256":hashlib.sha256(shot.read_bytes()).hexdigest()}
      row["checks"].append("default_country_outlook_visible")
      for cc in ["JP","KR","TW","IN","AU","GB","EZ"]:
       page.locator('.imc-country-rail [data-imc-country="'+cc+'"]').click()
       target=page.locator("#imc-country-"+cc)
       assert target.get_attribute("open") is not None,cc
       assert target.locator(".imc-country-body").is_visible(),cc
       assert target.locator(".imc-main-column").inner_text().strip(),cc
       assert page.evaluate("document.documentElement.scrollWidth")<=width+1,cc
       row["checks"].append("country_"+cc)
      if width==1440 and theme=="light" and lang=="en":
       page.locator('.imc-country-rail [data-imc-country="TW"]').click()
       page.locator('.imc-country-rail [data-imc-country="GB"]').click()
       page.go_back(wait_until="domcontentloaded")
       assert page.locator("#imc-country-TW").get_attribute("open") is not None
       record["journeys"].append({"name":"country_browser_back","pass":True})
       page.locator(".imc-tools-link").click()
       overview=page.locator('[data-im-panel][data-view="overview"]:visible')
       overview.wait_for(state="visible")
       returns=overview.locator("[data-im-unranked-item]")
       record["overview"]={"context":overview.locator(".intl-overview__context").inner_text(),"unranked_count":returns.count(),"ranked_count":overview.locator("[data-im-focus-item]").count()}
       if returns.count():
        assert all(returns.nth(i).is_visible() for i in range(returns.count()))
        assert all(returns.nth(i).locator("[data-im-return-window] time").count()==2 for i in range(returns.count()))
        assert overview.locator("[data-im-expanded-region]").is_hidden()
        record["journeys"].append({"name":"unequal_returns_visible_before_expand","pass":True})
       shot=SHOTS/"overview-before-expand.png";page.screenshot(path=str(shot));record["overview"]["screenshot"]=str(shot)
       controls=page.locator('[data-im-action="set_view"][data-im-view]')
       enabled=[]
       for i in range(controls.count()):
        control=controls.nth(i)
        if control.is_visible() and control.is_enabled():enabled.append(control.get_attribute("data-im-view"))
       for view in enabled:
        page.locator('[data-im-action="set_view"][data-im-view="'+view+'"]:visible').click()
        panel=page.locator('[data-im-panel][data-view="'+view+'"]:visible')
        assert panel.count()==1,(view,panel.count())
        text=panel.inner_text().strip();assert len(text)>40,(view,text)
        record["journeys"].append({"name":"tool_"+view,"pass":True,"visible_text_characters":len(text)})
      assert not row["errors"],row["errors"]
      row["pass"]=True
     except Exception as e:
      row["pass"]=False;row["failure"]=str(e)
      try:page.screenshot(path=str(SHOTS/(name+"-failed.png")))
      except Exception:pass
     finally:
      record["states"].append(row);save();ctx.close()
      print(json.dumps({"state":name,"pass":row["pass"],"failure":row.get("failure"),"checks":len(row["checks"])}),flush=True)
  ctx=context_for(browser,390,"light","en",javascript=False);page=ctx.new_page()
  try:
   page.goto(url,wait_until="domcontentloaded",timeout=60000)
   target=page.locator("#imc-country-JP");target.locator(":scope > summary").click()
   assert target.get_attribute("open") is not None and target.locator(".imc-country-body").is_visible()
   record["journeys"].append({"name":"native_country_disclosure_without_javascript","pass":True})
  except Exception as e:record["journeys"].append({"name":"native_country_disclosure_without_javascript","pass":False,"failure":str(e)})
  finally:ctx.close()
  browser.close()
finally:
 server.shutdown();server.server_close()
 record["completed_at"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
 record["pass"]=len(record["states"])==12 and all(r["pass"] for r in record["states"]) and all(r["pass"] for r in record["journeys"])
 save()
print(json.dumps({"pass":record["pass"],"states":len(record["states"]),"journeys":len(record["journeys"]),"overview":record.get("overview")}),flush=True)
raise SystemExit(0 if record["pass"] else 1)
