from pathlib import Path
from dataclasses import replace
import json
from scripts.run_ci_pack import load_legacy_jobs, infer_job_scopes, _matches_any
p=Path(".github/ci/legacy-jobs.yml")
ids={"ci-control-plane-contracts","gmi-explorer","site-access-boundary"}
jobs=[j for j in load_legacy_jobs(p) if j.job_id in ids]
assert len(jobs)==len(ids)
inferred,_=infer_job_scopes([replace(j,exclusive=False) for j in jobs])
by_id={j.job_id:j for j in jobs}
misses={j.job_id:[x for x in j.paths if "*" not in x and not _matches_any(by_id[j.job_id].paths,x)] for j in inferred}
misses={k:v for k,v in misses.items() if v}
out=Path(__file__).with_name("scoped_closure_findings.json")
out.write_text(json.dumps(misses,indent=2)+"\n")
print(json.dumps({k:len(v) for k,v in misses.items()}),flush=True)
raise SystemExit(bool(misses))
