"""Bounded validation of the pending International/current-main integration."""
from pathlib import Path
import concurrent.futures, datetime, hashlib, json, subprocess, sys
ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def run(name, command, timeout):
    receipt = OUT / (name + ".json")
    if receipt.exists(): raise RuntimeError("Existing attempt must be inspected: " + name)
    log = OUT / (name + ".log")
    row = {"name":name, "command":command, "started_at":now(), "state":"RUNNING",
           "head":subprocess.check_output(["git","rev-parse","HEAD"],cwd=ROOT,text=True).strip(),
           "merge_head":subprocess.check_output(["git","rev-parse","MERGE_HEAD"],cwd=ROOT,text=True).strip()}
    receipt.write_text(json.dumps(row,indent=2)+"\n")
    try:
        with log.open("w") as stream:
            process = subprocess.run(command,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,timeout=timeout)
        row.update(state="PASS" if process.returncode == 0 else "FAILED", exit_code=process.returncode)
    except subprocess.TimeoutExpired:
        row.update(state="TIMED_OUT", exit_code=None)
    row.update(completed_at=now(),log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
    receipt.write_text(json.dumps(row,indent=2)+"\n")
    print(json.dumps({"name":name,"state":row["state"],"tail":log.read_text(errors="replace")[-1800:]}),flush=True)
    return row
closure = "from pathlib import Path; import json; from scripts.run_ci_pack import curated_exclusive_closure_findings; p=Path('research/reference_integrity/intl-country-intelligence-20261020/completion_20261103/closure_findings.json'); d=curated_exclusive_closure_findings(Path('.github/ci/legacy-jobs.yml')); p.write_text(json.dumps(d,indent=2)+'\\n'); print(json.dumps({k:len(v) for k,v in d.items()})); raise SystemExit(bool(d))"
jobs = [
 ("overview", [sys.executable,"-m","pytest","-q","tests/test_intl_workspace_overview.py","tests/test_intl_workspace_overview_render.py"],180),
 ("closure", [sys.executable,"-c",closure],240),
 ("country", [sys.executable,"-m","pytest","-q","tests/test_intl_country_cockpit.py","tests/test_intl_outlook_interpretation.py","tests/test_intl_currency_observation.py","tests/test_intl_forecast_vintages.py","tests/test_intl_policy_evidence.py","tests/test_intl_build.py","tests/test_intl_gs_foundation.py","tests/test_asset_stamp_refresh.py"],300),
]
if __name__ == "__main__":
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        rows=list(pool.map(lambda args:run(*args),jobs))
    (OUT/"validation_summary.json").write_text(json.dumps(rows,indent=2)+"\n")
    raise SystemExit(any(r["state"]!="PASS" for r in rows))
