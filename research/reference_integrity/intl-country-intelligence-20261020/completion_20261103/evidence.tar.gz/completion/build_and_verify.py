"""Build exact integrated source with committed production inputs; no collection or deployment."""
from pathlib import Path
import concurrent.futures, datetime, hashlib, importlib.util, json, os, subprocess, sys, tarfile
ROOT=Path(__file__).resolve().parents[4]
OUT=Path(__file__).resolve().parent
BUILD=Path("/tmp/intl-paper-build-20261103")
MAIN="c6ac417f4a1d561f8c80a0a6b1977d5ffec6d090"
s=importlib.util.spec_from_file_location("validation",OUT/"run_validation.py")
v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def build():
    if BUILD.exists():raise RuntimeError("Existing build attempt must be reconciled")
    BUILD.mkdir()
    subprocess.run(["git","add","--","templates/intl_workspace/overview.html.j2","tests/test_intl_workspace_overview_render.py"],cwd=ROOT,check=True)
    tree=subprocess.check_output(["git","write-tree"],cwd=ROOT,text=True).strip()
    source_archive=BUILD/"source.tar"
    source_paths=["config.yml","config","collectors","engine","lib","scripts","templates","requirements.txt","site/fonts","site/favicon.svg"]
    subprocess.run(["git","archive","--format=tar","--output="+str(source_archive),tree,*source_paths],cwd=ROOT,check=True,timeout=120)
    source=BUILD/"source";source.mkdir()
    with tarfile.open(source_archive) as tf:tf.extractall(source,filter="data")
    snapshot=json.loads((ROOT/"research/reference_integrity/intl-country-intelligence-20261020/production_input_snapshot.json").read_text())
    candidates=[row["path"] for row in snapshot["files"]]
    inventory=set(subprocess.check_output(["git","ls-tree","-r","--name-only",MAIN,"data","site/live_config.js","site/macrodata/global_regime_fragment.json"],cwd=ROOT,text=True).splitlines())
    selected=sorted(set(candidates)&inventory)
    if not selected:raise RuntimeError("No qualified committed inputs")
    archive=BUILD/"committed-inputs.tar"
    subprocess.run(["git","archive","--format=tar","--output="+str(archive),MAIN,*selected],cwd=ROOT,check=True,timeout=180)
    with tarfile.open(archive) as tf:tf.extractall(source,filter="data")
    receipt={"schema":"intl.completion_build.v1","started_at":v.now(),"source_tree":tree,"source_parents":["851c6abebf01c5c8096e7822436455fd1040152a",MAIN],"input_commit":MAIN,
             "input_paths":selected,"inputs_omitted_from_old_snapshot":sorted(set(candidates)-inventory),
             "input_archive_sha256":sha(archive),"source_archive_sha256":sha(source_archive),
             "source_reacquisition":False,"production_mutation":False,"build_path":str(source),"state":"RUNNING"}
    (OUT/"build.json").write_text(json.dumps(receipt,indent=2)+"\n")
    env=os.environ.copy()
    for name in ["PYTHONPATH","COLLECT_LANE","US_LANE"]:env.pop(name,None)
    with (OUT/"build.log").open("w") as log:
        result=subprocess.run([sys.executable,"-m","scripts.build_intl"],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
    receipt.update(state="PASS" if result.returncode==0 else "FAILED",exit_code=result.returncode,completed_at=v.now(),log_sha256=sha(OUT/"build.log"))
    html=source/"site/intl.html"
    if html.exists():receipt.update(html_sha256=sha(html),html_bytes=html.stat().st_size)
    (OUT/"build.json").write_text(json.dumps(receipt,indent=2)+"\n")
    print(json.dumps({k:value for k,value in receipt.items() if k not in ["input_paths","inputs_omitted_from_old_snapshot"]}),flush=True)
def p0b():
    os.environ["NODE_PATH"]="/tmp/intl-browser-node-20261103/node_modules"
    evidence="mockups/evidence/prophet-p0b-zero-fouc"
    fixture="/tmp/intl-p0b-completion-20261103"
    if Path(fixture).exists():raise RuntimeError("Existing P0B attempt must be reconciled")
    row=v.run("p0b_render",[sys.executable,"scripts/render_stock_dashboard_fixture.py","--market","all","--out-dir",fixture,"--receipt",evidence+"/rendered-fixture.json"],180)
    if row["state"]!="PASS":return
    jobs=[]
    for market,html,out in [("hk","hk_stocks.html","mobile-layout.json"),("ca","canada_stocks.html","mobile-layout-canada.json")]:
        command=["/opt/homebrew/bin/node","scripts/verify_stock_dashboard_mobile_layout.cjs","--html",fixture+"/"+html,"--site-dir","site","--fixture-receipt",evidence+"/rendered-fixture.json","--fixture-assets-dir",evidence+"/inputs/browser-data","--screenshot-dir",evidence,"--historical-head","3fb76ea810a8e9ef6a05fe808bb6eaee87eb1f86","--historical-tree","b4dd8fd9b29b4eb769239d35df2a7911e793c7ec","--browser","/Applications/Google Chrome.app/Contents/MacOS/Google Chrome","--out",evidence+"/"+out]
        jobs.append(("p0b_"+market,command,300))
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(lambda args:v.run(*args),jobs))
if __name__=="__main__":
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        futures=[pool.submit(build),pool.submit(p0b)]
        for f in concurrent.futures.as_completed(futures):f.result()
