"""V33 same-W+2W-watch pairing and nonoverlap invariants."""
import unittest,sys
from pathlib import Path
import pandas as pd,numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import v33_paired as m
class V33(unittest.TestCase):
 def sample(self):
  rows=[]
  for sym in ['MCD','WM']:
   for ep,arm in [(1,0),(2,42),(3,126)]:
    for policy,val in [('FIRST_2D_MACDRSI',.1),('FIRST_DAILY_STOCH',.12),('DAILY_STOCH_THEN_2D',0.)]:
     rows.append({'symbol':sym,'panel':'CORE5','episode':ep,'arm_i':arm,'arm_date':str(pd.Timestamp('2020-01-02')+pd.Timedelta(days=ep*90)),'policy':policy,'status':'SKIPPED' if val==0 else 'FILLED','net':val})
  return pd.DataFrame(rows)
 def test_paired_same_episode_retains_all(self):
  x=m.pair(self.sample(),'FIRST_DAILY_STOCH','FIRST_2D_MACDRSI')
  self.assertEqual(len(x),6);self.assertTrue((abs(x.delta-.02)<1e-12).all())
 def test_skipped_is_zero_not_dropped(self):
  x=m.pair(self.sample(),'DAILY_STOCH_THEN_2D','FIRST_2D_MACDRSI')
  self.assertEqual(len(x),6);self.assertTrue((abs(x.delta+.1)<1e-12).all())
 def test_incomplete_excluded_but_not_failure(self):
  d=self.sample();d.loc[(d.symbol=='MCD')&(d.episode==2)&(d.policy=='FIRST_DAILY_STOCH'),'status']='INCOMPLETE'
  x=m.pair(d,'FIRST_DAILY_STOCH','FIRST_2D_MACDRSI')
  self.assertEqual(len(x),5)
 def test_126_anchored_first_watches(self):
  d=self.sample();x=m.embargo(d,126)
  self.assertEqual(sorted(x.episode.unique()),[1,3])
 def test_embargo_never_looks_at_returns(self):
  d=self.sample();a=m.embargo(d,126)
  d.loc[:,'net']=1000.
  b=m.embargo(d,126)
  self.assertEqual(a[['symbol','episode','policy']].to_dict('records'),b[['symbol','episode','policy']].to_dict('records'))
 def test_no_duplicate_policy_within_watch(self):
  d=pd.concat([self.sample(),self.sample().iloc[:1]])
  with self.assertRaises(ValueError):m.pair(d,'FIRST_DAILY_STOCH','FIRST_2D_MACDRSI')
 def test_too_thin_quarters_no_interval(self):
  d=pd.DataFrame({'arm_date':['2020-01-02','2020-01-03'],'delta':[.1,-.1]})
  self.assertIsNone(m.quarter_ci(d)['interval'])
 def test_zero_diff_interval_zero(self):
  dates=pd.bdate_range('2018-01-02',periods=1500)[::15]
  d=pd.DataFrame({'arm_date':dates.astype(str),'delta':np.zeros(len(dates))})
  x=m.quarter_ci(d,rep=200)
  self.assertAlmostEqual(x['low'],0.);self.assertAlmostEqual(x['high'],0.)
if __name__=='__main__':unittest.main(verbosity=2)