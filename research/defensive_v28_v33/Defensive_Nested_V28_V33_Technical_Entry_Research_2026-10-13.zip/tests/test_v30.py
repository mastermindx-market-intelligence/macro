"""V30 causal fixed-watch entry policy regressions."""
import unittest,sys
from pathlib import Path
import numpy as np,pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import v30_master_watches as m
class MasterWatches(unittest.TestCase):
 def test_first_signal_after_arm_only(self):
  x=np.array([False,True,False,True,False,True])
  self.assertEqual(m.first_signal(x,arm=2,end=5),3)
 def test_expired_cross_is_not_signal(self):
  x=np.array([False,False,False,False,True])
  self.assertIsNone(m.first_signal(x,0,4))
 def test_pending_without_future_fill_is_rejected(self):
  d=self.fixture()
  with self.assertRaises(ValueError):m.fixed_event(d,arm=1,signal=4,horizon=3)
 def fixture(self):
  ix=pd.bdate_range('2020-01-02',periods=180)
  c=np.arange(180,dtype=float)+100
  return pd.DataFrame({'open':c+.1,'high':c+1,'low':c-1,'close':c+.5},index=ix)
 def test_common_endpoint_is_arm_126_not_entry_126(self):
  d=self.fixture()
  a=m.fixed_event(d,arm=3,signal=20,horizon=126)
  self.assertEqual(a['entry_date'],str(d.index[21].date()))
  self.assertEqual(a['exit_date'],str(d.index[129].date()))
 def test_missing_signal_remains_zero_cash(self):
  x=m.fixed_event(self.fixture(),arm=3,signal=None,horizon=126)
  self.assertEqual(x['status'],'SKIPPED');self.assertEqual(x['net'],0.)
 def test_future_endpoint_is_unknown_not_loss(self):
  x=m.fixed_event(self.fixture(),arm=80,signal=85,horizon=126)
  self.assertEqual(x['status'],'INCOMPLETE');self.assertNotIn('net',x)
 def test_stoch_prior_to_watch_not_sequential(self):
  bull=np.array([False,True,False,False,False,False,True])
  stoch=np.array([False,True,False,False,False,False,False])
  k=np.array([50.]*7);d=np.array([40.]*7)
  floor=np.array([True]*7)
  self.assertIsNone(m.sequential(bull,stoch,floor,k,d,arm=3,end=7,window=5))
 def test_stoch_then_later_two_day_confirm(self):
  bull=np.array([False,False,False,True,False,False,True])
  stoch=np.array([False,False,True,False,False,False,False])
  k=np.array([10.,10.,10.,30.,35.,36.,40.]);d=np.array([20.,20.,20.,20.,20.,20.,20.])
  bottom=np.array([True]*7)
  self.assertEqual(m.sequential(bull,stoch,bottom,k,d,arm=2,end=7,window=5),3)
 def test_no_late_cross_condition_if_stoch_no_longer_inforce(self):
  bull=np.array([False,False,False,False,False,False,True])
  stoch=np.array([False,True,False,False,False,False,False])
  k=np.array([10.,12.,20.,28.,35.,40.,50.]);d=np.array([20.,20.,20.,20.,20.,20.,20.])
  bottom=np.array([True]*7)
  self.assertIsNone(m.sequential(bull,stoch,bottom,k,d,arm=0,end=7,window=5))
 def test_source_episode_arms_independent_of_trigger(self):
  context=np.array([False,True,True,True,False,False,False,False,False,False,False,False,False,True,True,True])
  k=np.where(context,20.,65.)
  t1=np.zeros(len(k),bool);t2=np.zeros(len(k),bool);t1[2]=True;t2[14]=True
  a=m.master_episodes(context,k,t1,window=4,clear_n=4)
  b=m.master_episodes(context,k,t2,window=4,clear_n=4)
  self.assertEqual([x['arm_i'] for x in a],[x['arm_i'] for x in b])
if __name__=='__main__':unittest.main(verbosity=2)