"""V29 mechanical tests: fixed 2D signal, short washout, path, costs."""
import unittest,sys
from pathlib import Path
import pandas as pd,numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import v29_execution as m
class V29(unittest.TestCase):
 def bars(self):
  ix=pd.bdate_range('2020-01-02',periods=30)
  return pd.DataFrame({'open':[100.]*30,'high':[103.]*30,'low':[99.]*30,'close':[101.]*30},index=ix)
 def test_next_open_entry_fixed_horizon(self):
  d=self.bars();d.loc[d.index[4],'open']=102.
  a=m.path(d,4,20)
  self.assertAlmostEqual(a['net'],101/102*.9995/1.0005-1)
  self.assertEqual(a['end_date'],str(d.index[23].date()))
 def test_stop_first_ambiguity(self):
  d=self.bars();d.loc[d.index[5],['open','high','low','close']]=[100,130,80,110]
  self.assertEqual(m.barrier(d,4,20,.08,.05),'STOP')
 def test_open_gap_before_target(self):
  d=self.bars();d.loc[d.index[5],['open','high','low','close']]=[110,112,105,108]
  self.assertEqual(m.barrier(d,4,20,.08,.05),'TARGET')
 def test_future_changes_dont_change_earlier_horizon(self):
  d=self.bars();a=m.path(d,4,10)
  d.loc[d.index[20]:,['high','close']]=999.
  self.assertEqual(a,m.path(d,4,10))
 def test_nonoverlap_first_no_outcome(self):
  dates=[2,15,61,65,100,128]
  self.assertEqual(m.first_spaced(dates,63),[2,65,128])
 def test_126_immutable(self):
  d=pd.DataFrame({'net':[.1,-.2,.3],'daily_bottom':[True,False,True]})
  a=m.gate_as_cash(d,'daily_bottom')
  self.assertEqual(len(a),3)
  self.assertAlmostEqual(a.cash_net.mean(),(.1+0+.3)/3)
  self.assertEqual(a.status.tolist(),['ACCEPTED','REJECTED','ACCEPTED'])
 def test_short_horizon_missing_is_unknown(self):
  self.assertEqual(m.path(self.bars(),25,20)['status'],'INCOMPLETE')
 def test_invalid_negative_entry(self):
  with self.assertRaises(ValueError):m.path(self.bars(),-1,20)
 def test_early_loss_does_not_become_future_loss(self):
  d=self.bars();d.loc[d.index[4:6],'low']=90.;d.loc[d.index[25],'close']=150.
  self.assertLess(m.path(d,4,20)['mae'],-.05)
  self.assertGreater(m.path(d,4,25)['net'],0.)
if __name__=='__main__':unittest.main(verbosity=2)