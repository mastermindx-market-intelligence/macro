"""V31 account schedule and cross-check tests; no broker."""
import unittest,sys
from pathlib import Path
import pandas as pd,numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import v31_account as q
class Account(unittest.TestCase):
 def source(self):
  return pd.DataFrame({'symbol':['MCD']*5,'policy':['FIRST_2D_MACDRSI']*5,'episode':[1,2,3,4,5],'arm_i':[10,25,40,55,70],'signal_i':[12.,np.nan,43.,89.,74.],'status':['FILLED','SKIPPED','FILLED','INCOMPLETE','INCOMPLETE']})
 def test_only_observable_next_open_signals(self):
  x=q.schedule(self.source(),'MCD','FIRST_2D_MACDRSI',n=80)
  self.assertEqual([r['episode'] for r in x],[1,3,5])
 def test_signal_from_incomplete_episode_retained_if_open_seen(self):
  x=q.schedule(self.source(),'MCD','FIRST_2D_MACDRSI',n=80)
  self.assertIn(5,[r['episode'] for r in x])
 def test_skip_nonexistent_following_open(self):
  a=self.source();a.loc[a.episode==5,'signal_i']=79.
  self.assertEqual([x['episode'] for x in q.schedule(a,'MCD','FIRST_2D_MACDRSI',80)],[1,3])
 def test_no_late_entry_before_arm(self):
  x=self.source();x.loc[x.episode==3,'signal_i']=39.
  with self.assertRaises(ValueError):q.schedule(x,'MCD','FIRST_2D_MACDRSI',80)
 def test_duplicate_episodes_refused(self):
  a=self.source();a=pd.concat([a,a.iloc[:1]])
  with self.assertRaises(ValueError):q.schedule(a,'MCD','FIRST_2D_MACDRSI',80)
 def test_wrong_stock_no_entries(self):
  self.assertEqual(q.schedule(self.source(),'WMT','FIRST_2D_MACDRSI',80),[])
if __name__=='__main__':unittest.main(verbosity=2)