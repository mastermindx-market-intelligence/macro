"""V28 first 2D RSI-MACD confirmation + 1D StochRSI washout mechanical tests."""
import unittest,sys
from pathlib import Path
import pandas as pd,numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import v28_daily_stoch as m
class DailyStoch(unittest.TestCase):
 def test_recent_bottom_allowed_without_current_bottom(self):
  k=pd.Series([50.,12.,26.,36.,45.,65.]);d=pd.Series([55.,18.,29.,31.,40.,51.])
  x=m.flags(k,d,5)
  self.assertTrue(x.recent_washout.iloc[5])
  self.assertFalse(k.iloc[5]<=20)
 def test_true_cross_inforce(self):
  k=pd.Series([50.,12.,10.,25.,35.,40.]);d=pd.Series([55.,19.,20.,21.,24.,31.])
  x=m.flags(k,d,5)
  self.assertTrue(x.kd_cross_recent_inforce.iloc[5])
 def test_no_false_cross_when_already_above_from_start(self):
  k=pd.Series([30.,35.,40.,45.,50.,55.]);d=pd.Series([20.,20.,20.,20.,20.,20.])
  x=m.flags(k,d,5)
  self.assertFalse(x.kd_cross_recent_inforce.any())
 def test_future_changes_no_past_relabel(self):
  k=pd.Series([40.,10.,30.,50.,60.,35.,20.,25.]);d=pd.Series([50.,25.,20.,40.,55.,45.,25.,20.])
  a=m.flags(k,d,5);k.iloc[7]=1000.
  pd.testing.assert_frame_equal(a.iloc[:7],m.flags(k,d,5).iloc[:7])
 def test_required_five_known_before_washout(self):
  k=pd.Series([10.,10.,10.,10.,10.,40.]);d=pd.Series([20.,20.,20.,20.,20.,30.])
  a=m.flags(k,d,5);self.assertFalse(a.recent_washout.iloc[3]);self.assertTrue(a.recent_washout.iloc[5])
 def test_filter_rejection_does_not_delete_event(self):
  a=pd.DataFrame({'net':[.12,-.20,.08],'daily_bottom':[True,False,False]})
  out=m.gate(a,'daily_bottom')
  self.assertEqual(len(out),3);self.assertEqual(out.status.tolist(),['ACCEPTED','REJECTED','REJECTED'])
  self.assertAlmostEqual(out.cash_or_trade_return.sum(),.12)
 def test_all_rejected_results_zero_cash_not_failure(self):
  a=pd.DataFrame({'net':[.12,-.20],'daily_bottom':[False,False]})
  out=m.gate(a,'daily_bottom')
  self.assertEqual(out.cash_or_trade_return.sum(),0.);self.assertTrue((out.status=='REJECTED').all())
 def test_invalid_missing_flag_refused(self):
  a=pd.DataFrame({'net':[.05],'daily_bottom':[np.nan]})
  with self.assertRaises(ValueError):m.gate(a,'daily_bottom')
if __name__=='__main__':unittest.main(verbosity=2)