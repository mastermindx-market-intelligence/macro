"""V32 portfolio overlay assembly and time/identity checks."""
import unittest,sys
from pathlib import Path
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import v32_reserve as q
class V32(unittest.TestCase):
 def fixture(self):
  ix=pd.bdate_range('2020-01-02',periods=4)
  return pd.DataFrame({'date':list(ix.strftime('%Y-%m-%d')),'symbol':['MCD']*4,'entry_policy':['FIRST_2D_MACDRSI']*4,'exit_policy':['HOLD']*4,'equity':[1.,1.05,1.02,1.10],'exposure':[0.,1.,1.,0.]})
 def test_extract_exact_one_case(self):
  s=self.fixture();got=q.source_case(s,'MCD','FIRST_2D_MACDRSI','HOLD')
  self.assertEqual(len(got),4);self.assertAlmostEqual(got.equity.iloc[-1],1.1)
 def test_missing_case_refused(self):
  s=self.fixture()
  with self.assertRaises(ValueError):q.source_case(s,'WMT','FIRST_2D_MACDRSI','HOLD')
 def test_duplicate_date_refused(self):
  s=self.fixture();s=pd.concat([s,s.iloc[:1]])
  with self.assertRaises(ValueError):q.source_case(s,'MCD','FIRST_2D_MACDRSI','HOLD')
 def test_partial_fraction_refused(self):
  s=self.fixture();s.loc[1,'exposure']=.5
  with self.assertRaises(ValueError):q.source_case(s,'MCD','FIRST_2D_MACDRSI','HOLD')
 def test_can_read_zeros_without_fabricating_fill(self):
  s=self.fixture();s.loc[:,'exposure']=0.
  got=q.source_case(s,'MCD','FIRST_2D_MACDRSI','HOLD')
  self.assertEqual(got.exposure.sum(),0.)
if __name__=='__main__':unittest.main(verbosity=2)