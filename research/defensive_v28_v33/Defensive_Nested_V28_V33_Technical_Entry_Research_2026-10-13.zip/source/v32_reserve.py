"""V32 SPY reserve overlay for exact V31 account entry/exit paths.
One source of price/execution rules: previously repaired V14 overlay().
No new signal, no broker, no future backfill, historical only.
"""
from pathlib import Path
import json,sys,hashlib
import pandas as pd,numpy as np
ROOT=Path(__file__).resolve().parents[2]
THIS=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source'))
import overlay_v14 as v14
import portfolio_v13 as p
import v12_engine as inp
ENTRIES=['WATCH_IMMEDIATE','FIRST_2D_MACDRSI','FIRST_DAILY_STOCH','DAILY_STOCH_THEN_2D']
EXITS=['HOLD','ATR3','ATR6']
def source_case(data,symbol,entry,exit):
    x=data[(data.symbol==symbol)&(data.entry_policy==entry)&(data.exit_policy==exit)].copy()
    if x.empty:raise ValueError('Missing original account')
    try:x.date=pd.to_datetime(x.date,format='%Y-%m-%d',errors='raise')
    except Exception as e:raise ValueError('Malformed market date') from e
    if x.date.duplicated().any():raise ValueError('Repeated date in account')
    x=x.set_index('date').sort_index()
    if not x.exposure.isin([0.,1.]).all() or x[['equity','exposure']].isna().any().any() or (x.equity<=0).any():raise ValueError('Only fully invested/flat valid account supported')
    return x[['equity','exposure']]
def run():
    src=ROOT/'v31/results/V31_ACCOUNT_DAILY.csv.gz'
    assert hashlib.sha256(src.read_bytes()).hexdigest()==json.loads((THIS/'SPEC.json').read_text())['original_v31_sha256']
    data=pd.read_csv(src)
    core=p.CORE;peers=p.PEERS;allsyms=core+peers
    idx=pd.DatetimeIndex(sorted(pd.to_datetime(data.date.unique())))
    spy_full=inp.load_daily('SPY')
    spy=spy_full.loc[idx]
    refspy=p.buyhold_for_account(spy_full,idx)
    allcurves=[];bysym=[]
    for sym in allsyms:
        for en in ENTRIES:
            for ex in EXITS:
                base=source_case(data,sym,en,ex)
                if not idx.equals(base.index):raise RuntimeError('Expected same exact stock price-date range')
                overlay=v14.overlay(spy,base,fee=.0005)
                assert len(overlay)==len(base) and (overlay.equity>0).all()
                q=p.metrics(overlay);m=p.metrics(base)
                bysym.append({'symbol':sym,'entry_policy':en,'exit_policy':ex,'spy_reserve_cagr':q['cagr'],'spy_reserve_dd':q['max_dd'],'original_cash_cagr':m['cagr'],'original_cash_dd':m['max_dd'],'spy_switches':int(overlay.spy_switches.sum()),'stock_exposure':q['time_avg_marked_exposure']})
                output=overlay[['equity','exposure']].reset_index(names='date');output['symbol']=sym;output['entry_policy']=en;output['exit_policy']=ex
                allcurves.append(output)
        print('V32_STOCK',sym,flush=True)
    curves=pd.concat(allcurves,ignore_index=True)
    curves.to_csv(THIS/'results/V32_SPY_RESERVE_DAILY.csv.gz',index=False,compression='gzip')
    pd.DataFrame(bysym).to_csv(THIS/'results/V32_BY_STOCK.csv',index=False)
    details=[];periods=[];leave=[]
    baseport=pd.read_csv(ROOT/'v31/results/V31_EQUAL_SLEEVE_PORTFOLIOS.csv')
    for panel,syms in [('CORE5',core),('PEERS13',peers),('ALL18',allsyms)]:
        hold=pd.concat([p.buyhold_for_account(inp.load_daily(s),idx) for s in syms],axis=1).mean(axis=1)
        ownhold=p.metrics(hold);sp=p.metrics(refspy)
        for en in ENTRIES:
            for ex in EXITS:
                t=curves[(curves.symbol.isin(syms))&(curves.entry_policy==en)&(curves.exit_policy==ex)]
                res=p.combine(t[['date','symbol','equity','exposure']],syms)
                z=p.metrics(res);original=baseport[(baseport.panel==panel)&(baseport.entry_policy==en)&(baseport.exit_policy==ex)]
                assert len(original)==1
                details.append({'panel':panel,'entry_policy':en,'exit_policy':ex,
                  'ending_equity':z['ending_equity'],'cagr':z['cagr'],'max_dd':z['max_dd'],
                  'annualized_daily_vol':z['annualized_daily_vol'],'average_stock_exposure':z['time_avg_marked_exposure'],
                  'incremental_cagr_vs_cash_pp':(z['cagr']-float(original.iloc[0].cagr))*100,
                  'incremental_cagr_vs_spy_pp':(z['cagr']-sp['cagr'])*100,
                  'incremental_cagr_vs_same_stock_hold_pp':(z['cagr']-ownhold['cagr'])*100})
                if panel=='CORE5':
                    def rel(y0,y1):
                        a=int(idx.get_loc(pd.Timestamp(y0)));b=int(idx.get_loc(pd.Timestamp(y1)))
                        return float(np.log(res.equity.iloc[b]/res.equity.iloc[a])-np.log(refspy.iloc[b]/refspy.iloc[a]))
                    cut=idx[idx.year<=2022][-1]
                    periods.append({'entry_policy':en,'exit_policy':ex,'period':'2018_2022','relative_wealth_spy':float(np.exp(rel(idx[0],cut))-1)})
                    periods.append({'entry_policy':en,'exit_policy':ex,'period':'2023_2026','relative_wealth_spy':float(np.exp(rel(cut,idx[-1]))-1)})
                    for removed in core:
                        other=[s for s in core if s!=removed]
                        q=p.combine(t[t.symbol.isin(other)][['date','symbol','equity','exposure']],other)
                        leave.append({'entry_policy':en,'exit_policy':ex,'removed':removed,'cagr_spy_delta_pp':(p.metrics(q)['cagr']-sp['cagr'])*100})
    pd.DataFrame(details).to_csv(THIS/'results/V32_PORTFOLIO_SUMMARY.csv',index=False)
    pd.DataFrame(periods).to_csv(THIS/'results/V32_CORE_PERIODS.csv',index=False)
    pd.DataFrame(leave).to_csv(THIS/'results/V32_LEAVE_ONE_CORE.csv',index=False)
    proof={'original_stock_accounts':len(bysym),'portfolio_scenarios':len(details),
      'daily_account_rows':len(curves),'source_accepted_v14_overlay_unchanged':True,
      'original_v31_path_sha':hashlib.sha256(src.read_bytes()).hexdigest(),
      'source_date_cutoff':'2026-10-08','new_market_vendor_requests':0,
      'zero_broker_or_production_orders':True,'not_selection_adjusted_or_blind':True}
    (THIS/'results/VERIFICATION.json').write_text(json.dumps(proof,indent=2))
    q=pd.DataFrame(details)
    print('V32_CORE_SPY_RESERVE',q[(q.panel=='CORE5')][['entry_policy','exit_policy','cagr','max_dd','average_stock_exposure','incremental_cagr_vs_spy_pp']].round(6).to_json(orient='records'),flush=True)
    print('V32_PEER_HOLD',q[(q.panel=='PEERS13')&(q.exit_policy=='HOLD')].round(6).to_json(orient='records'),flush=True)
    print('V32_PROOF',json.dumps(proof))
if __name__=='__main__':run()
