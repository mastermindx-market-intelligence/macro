"""V29 adversarial execution-path test of original V28 two-day RSI-MACD
plus recent daily StochRSI washout with W+2W nested context.
All source events fixed before analysis. Research, not live strategy/sizing.
"""
from pathlib import Path
import sys,json,hashlib
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[2]
THIS=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source'))
sys.path.insert(0,str(ROOT/'v11_published/source'))
sys.path.insert(0,str(ROOT/'v28/source'))
import v12_engine as native
import empirical as e
from v28_daily_stoch import gate as gated
CORE=['MCD','WMT','WM','COST','PG']
PEERS=[s for s in e.STOCKS if s not in CORE]
def path(d,entry_i,window,fee=.0005):
    if entry_i<0 or window<1 or entry_i>=len(d):raise ValueError('Invalid entry/window')
    end=entry_i+window-1
    if end>=len(d):return {'status':'INCOMPLETE'}
    entry=float(d.open.iloc[entry_i]);rows=d.iloc[entry_i:end+1]
    if entry<=0:return {'status':'UNKNOWN_ENTRY'}
    return {'status':'COMPLETE','net':float(d.close.iloc[end]/entry*(1-fee)/(1+fee)-1),
        'mae':float(rows.low.min()/entry-1),'mfe':float(rows.high.max()/entry-1),
        'end_date':str(d.index[end].date()),'entry_price':entry,'end_i':end}
def barrier(d,entry_i,window,target,stop):
    if target<=0 or stop<=0:raise ValueError('Barrier sizes')
    m=path(d,entry_i,window)
    if m['status']!='COMPLETE':return 'UNKNOWN'
    entry=float(d.open.iloc[entry_i]);hi=entry*(1+target);lo=entry*(1-stop)
    for q in d.iloc[entry_i:entry_i+window].itertuples():
        # Conservative OHLC ambiguity: stop first if BOTH touched in same bar.
        if q.open<=lo:return 'STOP'
        if q.open>=hi:return 'TARGET'
        if q.low<=lo:return 'STOP'
        if q.high>=hi:return 'TARGET'
    return 'TIMEOUT'
def first_spaced(seq,minimum_gap):
    if minimum_gap<1:raise ValueError('Gap')
    seq=[int(x) for x in seq]
    if seq!=sorted(seq) or len(seq)!=len(set(seq)):raise ValueError('Indices not monotonically unique')
    out=[];last=-10**10
    for i in seq:
        if i-last>=minimum_gap:out.append(i);last=i
    return out
def gate_as_cash(df,col):
    out=gated(df,col)
    return out.rename(columns={'cash_or_trade_return':'cash_net'})
def summarize(g,label):
    if len(g)==0:return {'name':label,'events':0,'net_mean':None,'positive_rate':None}
    a=g[g.daily_bottom];b=g[~g.daily_bottom]
    return {'name':label,'events':len(g),'accepted_n':len(a),'rejected_n':len(b),
      'accepted_mean126':float(a.net.mean()) if len(a) else None,
      'rejected_mean126':float(b.net.mean()) if len(b) else None,
      'accepted_win126':float(a.net.gt(0).mean()) if len(a) else None,
      'rejected_win126':float(b.net.gt(0).mean()) if len(b) else None,
      'accepted_target8_first':float(a.target8.eq('TARGET').mean()) if len(a) else None,
      'rejected_target8_first':float(b.target8.eq('TARGET').mean()) if len(b) else None,
      'accepted_stop_first':float(a.target8.eq('STOP').mean()) if len(a) else None,
      'accepted_cash_or_trade_all126_mean':float(gate_as_cash(g,'daily_bottom').cash_net.mean()),
      'missed_winners126':int((b.net>0).sum()),
      'mean63_accepted':float(a.net63.mean()) if len(a) else None,
      'mean63_rejected':float(b.net63.mean()) if len(b) else None,
      'relative_four63_accepted':float(a.relative_four63.mean()) if len(a) else None,
      'relative_four63_rejected':float(b.relative_four63.mean()) if len(b) else None,
      'relative_spy63_accepted':float(a.relative_spy63.mean()) if len(a) else None,
      'relative_spy63_rejected':float(b.relative_spy63.mean()) if len(b) else None,
      'accepted_under5_first20':float((a.mae20<=-.05).mean()) if len(a) else None,
      'accepted_under5_then_win63':int(((a.mae20<=-.05)&(a.net63>0)).sum()) if len(a) else 0,
      'accepted_stock_count':int(a.symbol.nunique()) if len(a) else 0,
      'accepted_active_quarters':int(pd.to_datetime(a.signal_date).dt.to_period('Q').nunique()) if len(a) else 0}
def bootstrap_comparison(g,metric,rep=4000,block=4):
    if not len(g):return {'interval':None,'reason':'EMPTY'}
    d=g.copy();d['q']=pd.to_datetime(d.signal_date).dt.to_period('Q')
    groups={}
    q=pd.period_range(d.q.min(),d.q.max(),freq='Q')
    for k in [True,False]:
        x=d[d.daily_bottom.eq(k)].groupby('q')[metric].agg(['sum','count']).reindex(q,fill_value=0)
        groups[k]=(x['sum'].to_numpy(float),x['count'].to_numpy(float))
    act={str(k):int((ct>0).sum()) for k,(_,ct) in groups.items()}
    if min(act.values())<8:return {'interval':None,'active_quarters':act,'reason':'THIN_QUARTERS'}
    rng=np.random.default_rng(291013);n=len(q)
    starts=rng.integers(0,n,size=(rep,int(np.ceil(n/block))))
    sel=((starts[:,:,None]+np.arange(block))%n).reshape(rep,-1)[:,:n]
    a,an=groups[True];b,bn=groups[False]
    leftn=an[sel].sum(axis=1);rightn=bn[sel].sum(axis=1)
    valid=(leftn>0)&(rightn>0)
    diff=a[sel].sum(axis=1)[valid]/leftn[valid]-b[sel].sum(axis=1)[valid]/rightn[valid]
    return {'interval':'exploratory_unadjusted','low':float(np.quantile(diff,.025)),
            'high':float(np.quantile(diff,.975)),'active_quarters':act,'valid':len(diff)}
def run():
    src=ROOT/'v28/results/V28_FIXED_2D_CROSS_EVENTS.csv'
    data=pd.read_csv(src)
    assert len(data)==899 and data.frame.eq('2D').all()
    expected=hashlib.sha256(src.read_bytes()).hexdigest()
    assert expected==json.loads((THIS/'SPEC.json').read_text())['source_v28_sha256']
    px={sym:native.load_daily(sym) for sym in e.STOCKS+['SPY']}
    ix=px['SPY'].index
    assert all(frame.index.equals(ix) for frame in px.values())
    # Enumerate all fresh lower crossovers before using their observed outcomes.
    data=data.sort_values(['symbol','signal_date']).copy()
    data['signal_i']=pd.to_datetime(data.signal_date).map(pd.Series(np.arange(len(ix)),index=ix)).astype(int)
    spaced63=set();spaced126=set()
    for symbol,group in data.groupby('symbol'):
        ordered=sorted(group.signal_i.to_list())
        spaced63 |= {(symbol,i) for i in first_spaced(ordered,63)}
        spaced126 |= {(symbol,i) for i in first_spaced(ordered,126)}
    rows=[];baseline_mismatch=0
    for t in data.itertuples():
        selected=px[t.symbol];entry_i=int(ix.get_loc(pd.Timestamp(t.entry_date)))
        assert entry_i==t.signal_i+1
        n20=path(selected,entry_i,20);n63=path(selected,entry_i,63);n126=path(selected,entry_i,126)
        assert all(q['status']=='COMPLETE' for q in [n20,n63,n126])
        if abs(n126['net']-float(t.net))>=1e-5:raise ValueError('Prior return reconciliation failed '+t.symbol+str(t.signal_date))
        b=barrier(selected,entry_i,126,.08,.05)
        if b!=t.target8:baseline_mismatch+=1
        others=[s for s in (CORE if t.panel=='CORE5' else PEERS) if s!=t.symbol]
        peer63=float(np.mean([path(px[s],entry_i,63)['net'] for s in others]))
        spy63=path(px['SPY'],entry_i,63)['net']
        rows.append({'symbol':t.symbol,'panel':t.panel,'signal_date':t.signal_date,'entry_date':t.entry_date,'cell':t.cell,
         'daily_bottom':bool(t.daily_bottom),'daily_kd_bull_inforce':bool(t.daily_kd_bull_inforce),
         'daily_k':float(t.daily_k_at_signal),'daily_d':float(t.daily_d_at_signal),
         'net':float(t.net),'net20':n20['net'],'net63':n63['net'],
         'relative_four63':n63['net']-peer63,'relative_spy63':n63['net']-spy63,
         'mae20':n20['mae'],'mae63':n63['mae'],'mae126':n126['mae'],
         'target8':b,'target15':t.target15,'beta_spread20_63':float(t.beta_spread),
         'spaced63':(t.symbol,t.signal_i) in spaced63,
         'spaced126':(t.symbol,t.signal_i) in spaced126,
         'v11_spaced126':bool(t.spaced_before_outcomes),
         'original_126_net_error':n126['net']-float(t.net)})
    d=pd.DataFrame(rows)
    assert len(d)==len(data) and baseline_mismatch==0
    if (d.spaced126!=d.v11_spaced126).any():raise RuntimeError('Historical precommitted non-overlap diverged')
    d.to_csv(THIS/'results/V29_EXECUTION_PATH_EVENTS.csv',index=False)
    out=[];controls=[]
    for panel,g in d.groupby('panel'):
        for cell in ['JOINT','WEEKLY_ONLY','TWO_WEEK_ONLY','NEITHER','ALL']:
            cohort=g if cell=='ALL' else g[g.cell==cell]
            for mode,h in [('ALL',cohort),('SPACED63',cohort[cohort.spaced63]),('SPACED126',cohort[cohort.spaced126])]:
                out.append({'panel':panel,'cell':cell,'sample':mode,**summarize(h,panel+'_'+cell+'_'+mode)})
            if cell=='JOINT':
                k=bootstrap_comparison(cohort,'net')
                x=bootstrap_comparison(cohort,'relative_four63')
                controls.append({'panel':panel,'cell':cell,'quantity':'net126_accepted_minus_rejected',**k})
                controls.append({'panel':panel,'cell':cell,'quantity':'relative_four63_accepted_minus_rejected',**x})
    pd.DataFrame(out).to_csv(THIS/'results/V29_EXECUTION_SUMMARY.csv',index=False)
    pd.DataFrame(controls).to_csv(THIS/'results/V29_CONFLUENCE_INTERVALS.csv',index=False)
    v={'total_2D_events':len(d),'core_joint_n':len(d.query("panel=='CORE5' and cell=='JOINT'")),
       'core_joint_daily_bottom_n':int(d.query("panel=='CORE5' and cell=='JOINT'").daily_bottom.sum()),
       'target8_first_equivalence_mismatch':baseline_mismatch,
       'spaced126_vs_original_V11_identical':True,
       'first_spaced_selected_without_outcome':True,'data_end':'2026-10-08',
       'original_126_net_max_discrepancy':float(d.original_126_net_error.abs().max()),
       'new_market_acquisition':False,'previous_user_chart_parity':'UNVERIFIED','live_orders':False}
    (THIS/'results/VERIFICATION.json').write_text(json.dumps(v,indent=2))
    z=pd.DataFrame(out)
    print('CORE_JOINT',z.query("panel=='CORE5' and cell=='JOINT'")[['sample','events','accepted_n','rejected_n','accepted_mean126','rejected_mean126','accepted_target8_first','accepted_under5_first20','mean63_accepted','mean63_rejected','relative_four63_accepted','relative_four63_rejected','accepted_active_quarters']].round(6).to_json(orient='records'),flush=True)
    print('PEERS_JOINT',z.query("panel=='PEERS13' and cell=='JOINT'")[['sample','events','accepted_n','rejected_n','accepted_mean126','rejected_mean126','accepted_target8_first','mean63_accepted','mean63_rejected']].round(6).to_json(orient='records'),flush=True)
    print('INTERVALS',pd.DataFrame(controls).to_json(orient='records'),flush=True)
    print('PROOF',json.dumps(v))
if __name__=='__main__':run()
