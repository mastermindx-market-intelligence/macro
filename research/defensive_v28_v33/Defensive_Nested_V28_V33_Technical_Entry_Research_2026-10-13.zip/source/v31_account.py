"""V31 single-stock, non-pyramiding portfolio-account comparison of the four
V30 fixed master-watch entry methods, using EXISTING accepted V12 execution.
No model fitting, new price acquisitions, real trades or position sizing.
"""
from pathlib import Path
import sys,json,hashlib
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[2]
THIS=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source'))
import v12_engine as accepted
import portfolio_v13 as p
ENTRY=['WATCH_IMMEDIATE','FIRST_2D_MACDRSI','FIRST_DAILY_STOCH','DAILY_STOCH_THEN_2D']
EXIT=['HOLD','ATR3','ATR6']
def schedule(events,symbol,entry_style,n):
    if entry_style not in ENTRY:raise ValueError('Unknown entry style')
    g=events[(events.symbol==symbol)&events.policy.eq(entry_style)].copy()
    if len(g)==0:return []
    if g.episode.duplicated().any():raise ValueError('Duplicate episode')
    order=[]
    for row in g.itertuples():
        if pd.isna(row.signal_i):continue
        sig=int(row.signal_i);arm=int(row.arm_i)
        if not 0<=arm<=sig:raise ValueError('Causal signal earlier than watch')
        if sig+1>=n:continue
        endpoint=arm+126
        if sig>=endpoint:raise ValueError('Next signal at/after fixed event endpoint')
        order.append({'symbol':symbol,'episode':int(row.episode),'signal_i':sig,'arm_i':arm,'endpoint_i':endpoint})
    return sorted(order,key=lambda x:(x['signal_i'],x['episode']))
def run():
    src=ROOT/'v30/results/V30_FIXED_WATCH_EVENTS.csv'
    expected=json.loads((THIS/'SPEC.json').read_text())
    assert hashlib.sha256(src.read_bytes()).hexdigest()==expected['prior_v30_event_sha']
    events=pd.read_csv(src)
    assert len(events)==792
    a=pd.read_csv(ROOT/'results/account_summary.csv')
    out=[];curves=[];ledger=[];reconciliations=[]
    for sym in accepted.e.STOCKS if hasattr(accepted,'e') else p.CORE+p.PEERS:
        cache=pd.read_pickle(ROOT/'derived_cache'/f'{sym}_2D.pkl')
        d=cache['daily'];feature=cache['features'];n=len(d)
        assert d.index.equals(feature.index) and n==4217
        for entry in ENTRY:
            sched=schedule(events,sym,entry,n)
            for exit_policy in EXIT:
                obj=accepted.account(d,feature,sched,exit_policy,start_i=int(d.index.searchsorted('2018-01-01')),risk_budget=None,fee=.0005)
                ident={'symbol':sym,'panel':'CORE5' if sym in p.CORE else 'PEERS13',
                       'entry_policy':entry,'exit_policy':exit_policy,
                       'normalization':'FULL_CAPITAL','cost_bps':10}
                out.append(ident|obj['summary'])
                curves.append(obj['curve'].reset_index(names='date').assign(**ident))
                if len(obj['trades']):ledger.append(obj['trades'].assign(**ident))
                if entry=='FIRST_2D_MACDRSI':
                    ref=a[(a.symbol==sym)&(a.frame=='2D')&(a.policy==exit_policy)&(a.normalization=='FULL_CAPITAL')&(a.cost_bps==10)]
                    if len(ref)!=1:raise RuntimeError('V12 reference missing '+sym+exit_policy)
                    x=ref.iloc[0]
                    reconcile=max(abs(obj['summary']['cagr']-x.cagr),abs(obj['summary']['ending_equity']-x.ending_equity),abs(obj['summary']['max_dd']-x.max_dd))
                    if reconcile>=5e-6:raise RuntimeError('V12 accepted account no longer reconciles '+sym+exit_policy+': '+str(reconcile))
                    reconciliations.append(reconcile)
        print('V31_ACCOUNT',sym,flush=True)
    tbl=pd.DataFrame(out);tbl.to_csv(THIS/'results/V31_ACCOUNT_PER_STOCK.csv',index=False)
    daily=pd.concat(curves,ignore_index=True);daily.to_csv(THIS/'results/V31_ACCOUNT_DAILY.csv.gz',index=False,compression='gzip')
    pd.concat(ledger,ignore_index=True).to_csv(THIS/'results/V31_ACCOUNT_TRADE_LOG.csv',index=False)
    comps=[];ix=pd.DatetimeIndex(sorted(pd.to_datetime(daily.date.unique())))
    for panel,syms in [('CORE5',p.CORE),('PEERS13',p.PEERS),('ALL18',p.CORE+p.PEERS)]:
        holdpx=[]
        for sym in syms:
            market=pd.read_pickle(ROOT/'derived_cache'/f'{sym}_2D.pkl')['daily']
            holdpx.append(p.buyhold_for_account(market,ix))
        stock_hold=pd.concat(holdpx,axis=1).mean(axis=1)
        market=accepted.load_daily('SPY')
        spy_hold=p.buyhold_for_account(market,ix)
        for item,series in [('SAME_STOCK_BUYHOLD',stock_hold),('SPY_BUYHOLD',spy_hold),('CASH_0',p.cash_curve(ix))]:
            stats=p.metrics(series)
            comps.append({'panel':panel,'entry_policy':item,'exit_policy':'NA',**stats,'avg_equity_exposure':1. if item!='CASH_0' else 0.})
        for ent in ENTRY:
            for ext in EXIT:
                selected=daily[(daily.symbol.isin(syms))&(daily.entry_policy==ent)&(daily.exit_policy==ext)]
                q=p.combine(selected[['date','symbol','equity','exposure']],syms)
                assert q.index.equals(ix)
                perf=p.metrics(q)
                comps.append({'panel':panel,'entry_policy':ent,'exit_policy':ext,**perf,
                              'avg_equity_exposure':perf['time_avg_marked_exposure'],
                              'cagr_vs_same_stocks_pp':(perf['cagr']-p.metrics(stock_hold)['cagr'])*100,
                              'cagr_vs_spy_pp':(perf['cagr']-p.metrics(spy_hold)['cagr'])*100})
    pd.DataFrame(comps).to_csv(THIS/'results/V31_EQUAL_SLEEVE_PORTFOLIOS.csv',index=False)
    proof={'total_original_master_watches':198,'entry_styles':ENTRY,'exit_methods':EXIT,
        'individual_accounts':len(tbl),'account_equity_curve_rows':len(daily),
        'holdings_reconcile_V12_cases':len(reconciliations),
        'max_accepted_V12_account_discrepancy':max(reconciliations),
        'preserves_missing_or_incomplete_future_events_in_schedule_if_entry_observed':True,
        'no_optimization_after_outcomes':True,'no_new_vendor_data':True,'raw_prices_not_distributed':True,'no_broker_orders':True}
    (THIS/'results/VERIFICATION.json').write_text(json.dumps(proof,indent=2))
    x=pd.DataFrame(comps)
    print('V31_CORE_PORTFOLIOS',x[(x.panel=='CORE5')].round(6).to_json(orient='records'))
    print('V31_PEER',x[x.panel=='PEERS13'].round(6).to_json(orient='records'))
    print('V31_PROOF',json.dumps(proof))
if __name__=='__main__':run()
