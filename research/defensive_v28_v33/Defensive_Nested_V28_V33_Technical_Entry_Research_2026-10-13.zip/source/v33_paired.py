"""V33 paired common-long-watch comparisons of fixed V30 entries.
No outcome-selected rearming, no raw vendor fetch, no portfolio deployment.
"""
from pathlib import Path
import hashlib,json
import pandas as pd,numpy as np
ROOT=Path(__file__).resolve().parents[2]
THIS=Path(__file__).resolve().parents[1]
CANDIDATES=['WATCH_IMMEDIATE','FIRST_DAILY_STOCH','DAILY_STOCH_THEN_2D']
CONTROL='FIRST_2D_MACDRSI'
def pair(d,left,right=CONTROL):
    if d.duplicated(['symbol','episode','policy']).any():raise ValueError('Duplicate policy/episode')
    l=d[d.policy==left];r=d[d.policy==right]
    if l.empty or r.empty:raise ValueError('Policy missing')
    x=l[['symbol','episode','panel','arm_date','arm_i','status','net']].merge(
        r[['symbol','episode','arm_date','status','net']],on=['symbol','episode','arm_date'],
        how='outer',validate='one_to_one',indicator=True,suffixes=('_alt','_2D'))
    if not x._merge.eq('both').all():raise ValueError('Not same master opportunities')
    # Missing outcome cannot be classified as loss or a zero-return skipped watch.
    x=x[(x.status_alt!='INCOMPLETE')&(x.status_2D!='INCOMPLETE')].copy()
    if x.net_alt.isna().any() or x.net_2D.isna().any():raise ValueError('Complete opportunity has no result')
    x['delta']=x.net_alt-x.net_2D
    return x.drop(columns=['_merge'])
def embargo(d,gap):
    if gap<1:raise ValueError('Embargo')
    t=d[['symbol','episode','arm_i']].drop_duplicates().sort_values(['symbol','arm_i'])
    allowed=set()
    for sym,g in t.groupby('symbol'):
        prev=-10**8
        for a in g.itertuples():
            if a.arm_i-prev>=gap:
                allowed.add((sym,int(a.episode)));prev=int(a.arm_i)
    m=pd.Series([(s,int(ep)) in allowed for s,ep in zip(d.symbol,d.episode)],index=d.index)
    return d.loc[m].copy()
def quarter_ci(d,rep=4000,block=4):
    if len(d)==0:return {'interval':None,'reason':'NO_EVENTS'}
    q=pd.to_datetime(d.arm_date).dt.to_period('Q')
    period=pd.period_range(q.min(),q.max(),freq='Q')
    sums=d.assign(q=q).groupby('q').delta.agg(['sum','count']).reindex(period,fill_value=0)
    active=int((sums['count']>0).sum())
    if active<8:return {'interval':None,'active_quarters':active,'reason':'FEWER_THAN_8_ACTIVE_QUARTERS'}
    rng=np.random.default_rng(331013);n=len(period)
    starts=rng.integers(0,n,size=(rep,int(np.ceil(n/block))))
    indices=((starts[:,:,None]+np.arange(block))%n).reshape(rep,-1)[:,:n]
    counts=sums['count'].to_numpy()[indices].sum(axis=1)
    diff=sums['sum'].to_numpy()[indices].sum(axis=1)
    good=counts>0
    out=diff[good]/counts[good]
    return {'interval':'exploratory_not_selection_adjusted','low':float(np.quantile(out,.025)),
            'high':float(np.quantile(out,.975)),'active_quarters':active,'bootstrap_valid':len(out)}
def run():
    path=ROOT/'v30/results/V30_FIXED_WATCH_EVENTS.csv'
    q=json.loads((THIS/'SPEC.json').read_text())
    assert hashlib.sha256(path.read_bytes()).hexdigest()==q['input_sha256']
    d=pd.read_csv(path)
    assert len(d)==792
    out=[];eventframes=[]
    for left in CANDIDATES:
        for panel in ['CORE5','PEERS13']:
            g=d[d.panel==panel]
            for sample,subset in [('ALL_MASTER_WATCHES',g),('FIRST_126_SESSION_WATCH',embargo(g,126))]:
                exact=pair(subset,left)
                exact['left_policy']=left;exact['base_policy']=CONTROL;exact['sample']=sample
                eventframes.append(exact)
                eff=quarter_ci(exact)
                years=pd.to_datetime(exact.arm_date).dt.year
                yr=[float(exact[years!=y].delta.mean()) for y in years.unique()]
                names=[float(exact[exact.symbol!=s].delta.mean()) for s in exact.symbol.unique()]
                out.append({'entry_alternative':left,'base_entry':CONTROL,'panel':panel,
                    'sample':sample,'n':len(exact),
                    'mean_alternative':float(exact.net_alt.mean()),
                    'mean_2D':float(exact.net_2D.mean()),
                    'mean_difference':float(exact.delta.mean()),
                    'median_difference':float(exact.delta.median()),
                    'positive_delta_fraction':float((exact.delta>0).mean()),
                    'alternative_traded':int(exact.status_alt.eq('FILLED').sum()),
                    '2D_traded':int(exact.status_2D.eq('FILLED').sum()),
                    'alternative_skipped':int(exact.status_alt.eq('SKIPPED').sum()),
                    '2D_skipped':int(exact.status_2D.eq('SKIPPED').sum()),
                    'leave_year_min':min(yr) if yr else None,'leave_year_max':max(yr) if yr else None,
                    'leave_name_min':min(names) if names else None,'leave_name_max':max(names) if names else None,
                    'interval_low':eff.get('low'),'interval_high':eff.get('high'),
                    'quarter_count':eff.get('active_quarters'),'interval_status':eff.get('interval')})
    main=pd.DataFrame(out);main.to_csv(THIS/'results/V33_PAIRED_WATCH_SUMMARY.csv',index=False)
    events=pd.concat(eventframes,ignore_index=True)
    events.to_csv(THIS/'results/V33_PAIRED_MASTER_EVENTS.csv',index=False)
    original_status=d.groupby(['panel','policy','status']).size().reset_index(name='n')
    original_status.to_csv(THIS/'results/V33_ALL_WATCH_COVERAGE.csv',index=False)
    receipt={'source_master_opportunities':len(d)//4,'source_entry_policy_variants':4,
             'total_paired_event_scenarios':len(events),'comparison_rows':len(main),
             'same_master_watch_entry_comparison':True,'unfilled_event_zero_cash':True,
             'incomplete_outcomes_removed_from_return_but_accounted_in_V30':True,
             '126_session_stock_embargo_set_from_arm_dates_only':True,
             'raw_price_data_acquisition':False,'broker_order_or_deployment':False,
             'main_law':'not selection-adjusted across prior research V1–V32'}
    (THIS/'results/VERIFICATION.json').write_text(json.dumps(receipt,indent=2))
    print('V33_CORE',main.query("panel=='CORE5'")[['entry_alternative','sample','n','mean_alternative','mean_2D','mean_difference','positive_delta_fraction','alternative_traded','2D_traded','interval_low','interval_high','quarter_count']].round(6).to_json(orient='records'))
    print('V33_PEERS',main.query("panel=='PEERS13'")[['entry_alternative','sample','n','mean_difference','alternative_traded','2D_traded','interval_low','interval_high']].round(6).to_json(orient='records'))
    print('PROOF',json.dumps(receipt))
if __name__=='__main__':run()
