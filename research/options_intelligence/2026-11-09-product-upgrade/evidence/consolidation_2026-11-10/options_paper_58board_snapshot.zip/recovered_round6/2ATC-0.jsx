(
    <div id="2ATC-0" style={{ backgroundColor: 'var(--mx-light-bg)', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', fontSynthesis: 'none', gap: '24px', height: 'fit-content', MozOsxFontSmoothing: 'grayscale', overflowWrap: 'anywhere', padding: '32px', WebkitFontSmoothing: 'antialiased', width: '1440px' }}>
      <div id="2ATE-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '8px' }}>
        <div id="2ATF-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
          OPTIONS R3 · DESIGN CONTRACT
        </div>
        <div id="2ATG-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '28px', fontWeight: 600, lineHeight: '145%' }}>
          Evidence &amp; selection
        </div>
        <div id="2ATH-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
          Distinct causes keep distinct messages, available values and recovery actions.
        </div>
      </div>
      <div id="2ATJ-0" style={{ boxSizing: 'border-box', display: 'flex', gap: '24px', width: '1376px' }}>
        <div id="2ATL-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', justifyContent: 'space-between', minHeight: '286px', padding: '20px', width: '326px' }}>
          <div id="2ATM-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div id="2ATN-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
              E01
            </div>
            <div id="2ATO-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
              Source prints unavailable
            </div>
            <div id="2ATP-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
              The aggregate is available. Individual print times and per-print quotes were not supplied.
            </div>
            <div id="2B81-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
              Build note · Preserve qualified aggregate NBBO measures. Omit fabricated child records; measured source batch and displayed events have different populations.
            </div>
          </div>
          <div id="2ATR-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
            <div id="2ATS-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
              Open available aggregate
            </div>
          </div>
        </div>
        <div id="2ATU-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', justifyContent: 'space-between', minHeight: '286px', padding: '20px', width: '326px' }}>
          <div id="2ATV-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div id="2ATW-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
              E02
            </div>
            <div id="2ATX-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
              Selected event changed
            </div>
            <div id="2ATY-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
              The published aggregate differs from your selection. Inspect the change before replacing it.
            </div>
            <div id="2B83-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
              Build note · Current aggregates do not prove a correction reason. Use qualified correction lineage only when supplied; retain original selection and return.
            </div>
          </div>
          <div id="2AU0-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
            <div id="2AU1-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
              Inspect source change
            </div>
          </div>
        </div>
        <div id="2AU3-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', justifyContent: 'space-between', minHeight: '286px', padding: '20px', width: '326px' }}>
          <div id="2AU4-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div id="2AU5-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
              E03
            </div>
            <div id="2AU6-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
              Event absent from latest feed
            </div>
            <div id="2AU7-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
              This event is not present in the latest loaded publication.
            </div>
            <div id="2B85-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
              Build note · A capped-feed absence is not proof of cancellation or withdrawal. Preserve identity; never select a neighboring event automatically.
            </div>
          </div>
          <div id="2AU9-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
            <div id="2AUA-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
              Return to Tape
            </div>
          </div>
        </div>
        <div id="2AUC-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', justifyContent: 'space-between', minHeight: '286px', padding: '20px', width: '326px' }}>
          <div id="2AUD-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div id="2AUE-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
              E04
            </div>
            <div id="2AUF-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
              No matching activity
            </div>
            <div id="2AUG-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
              The source is available. No activity meets these filters.
            </div>
            <div id="2B87-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
              Build note · Scope: SPY · 20 Nov · premium ≥ $15k.
            </div>
          </div>
          <div id="2AUI-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
            <div id="2AUJ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
              Edit filters
            </div>
          </div>
        </div>
      </div>
      <div id="2AUL-0" style={{ boxSizing: 'border-box', display: 'flex', gap: '24px', width: '1376px' }}>
        <div id="2AUN-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', justifyContent: 'space-between', minHeight: '286px', padding: '20px', width: '326px' }}>
          <div id="2AUO-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div id="2AUP-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
              E05
            </div>
            <div id="2AUQ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
              Not published yet
            </div>
            <div id="2AUR-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
              No book is available for the selected session.
            </div>
            <div id="2B89-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
              Build note · A missing publication is not a zero-exposure book.
            </div>
          </div>
          <div id="2AUT-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
            <div id="2AUU-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
              Choose an available session
            </div>
          </div>
        </div>
        <div id="2AUW-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', justifyContent: 'space-between', minHeight: '286px', padding: '20px', width: '326px' }}>
          <div id="2AUX-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div id="2AUY-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
              E06
            </div>
            <div id="2AUZ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
              Refresh failed
            </div>
            <div id="2AV0-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
              The Nov 6 book remains visible. A newer read could not be completed.
            </div>
            <div id="2B8B-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
              Build note · Preserve the selected contract and visible source date.
            </div>
          </div>
          <div id="2AV2-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
            <div id="2AV3-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
              Retry source read
            </div>
          </div>
        </div>
        <div id="2AV5-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', justifyContent: 'space-between', minHeight: '286px', padding: '20px', width: '326px' }}>
          <div id="2AV6-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div id="2AV7-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
              E07
            </div>
            <div id="2AV8-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
              Access unavailable
            </div>
            <div id="2AV9-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
              This source is not available for the current account.
            </div>
            <div id="2B8D-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
              Build note · Do not replace denied data with a different source silently.
            </div>
          </div>
          <div id="2AVB-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
            <div id="2AVC-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
              View access details
            </div>
          </div>
        </div>
        <div id="2AVE-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', justifyContent: 'space-between', minHeight: '286px', padding: '20px', width: '326px' }}>
          <div id="2AVF-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div id="2AVG-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
              E08
            </div>
            <div id="2AVH-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
              Independent SPY book
            </div>
            <div id="2AVI-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
              Continue with root context in the Nov 6 Exposure book.
            </div>
            <div id="2B8F-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
              Build note · The selected Flow group remains the origin for Back.
            </div>
          </div>
          <div id="2AVK-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-text)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
            <div id="2AVL-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-bg)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
              Continue with SPY context
            </div>
          </div>
        </div>
      </div>
      <div id="2AVN-0" style={{ boxSizing: 'border-box', display: 'flex', gap: '24px', width: '1376px' }}>
        <div id="2AVP-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', justifyContent: 'space-between', minHeight: '286px', padding: '20px', width: '326px' }}>
          <div id="2AVQ-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div id="2AVR-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
              E09
            </div>
            <div id="2AVS-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
              Saved source unavailable
            </div>
            <div id="2AVT-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
              The saved reference is intact, but its exact source cannot be loaded.
            </div>
            <div id="2B8H-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
              Build note · Keep the fingerprint and identity; do not show invented original values.
            </div>
          </div>
          <div id="2AVV-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
            <div id="2AVW-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
              View saved reference
            </div>
          </div>
        </div>
        <div id="2AVY-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', justifyContent: 'space-between', minHeight: '286px', padding: '20px', width: '326px' }}>
          <div id="2AVZ-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div id="2AW0-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
              E10
            </div>
            <div id="2AW1-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
              Wing data missing
            </div>
            <div id="2AW2-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
              Available volatility observations remain visible. The missing wing has no curve.
            </div>
            <div id="2B8J-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
              Build note · No fit or interpolation is implied by the empty region.
            </div>
          </div>
          <div id="2AW4-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
            <div id="2AW5-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
              Open exact table
            </div>
          </div>
        </div>
        <div id="2AW7-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', justifyContent: 'space-between', minHeight: '286px', padding: '20px', width: '326px' }}>
          <div id="2AW8-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div id="2AW9-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
              E11
            </div>
            <div id="2AWA-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
              Research only
            </div>
            <div id="2AWB-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
              Evidence is still accruing for this claim.
            </div>
            <div id="2B8L-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
              Build note · Candidate formation does not establish calibration or live authority.
            </div>
          </div>
          <div id="2AWD-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
            <div id="2AWE-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
              Inspect evidence maturity
            </div>
          </div>
        </div>
        <div id="2AWG-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', justifyContent: 'space-between', minHeight: '286px', padding: '20px', width: '326px' }}>
          <div id="2AWH-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div id="2AWI-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
              E12
            </div>
            <div id="2AWJ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
              Terms unresolved
            </div>
            <div id="2AWK-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
              The exact contract terms could not be qualified. Payoff is unavailable.
            </div>
            <div id="2B8N-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
              Build note · One refused leg blocks the complete expression.
            </div>
          </div>
          <div id="2AWM-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
            <div id="2AWN-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
              Check contract terms
            </div>
          </div>
        </div>
      </div>
    </div>
  )
