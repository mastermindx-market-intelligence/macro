(
    <div id="2BII-0" style={{ backgroundColor: 'var(--mx-dark-bg)', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', fontSize: '12px', fontSynthesis: 'none', height: 'fit-content', lineHeight: '16px', MozOsxFontSmoothing: 'grayscale', overflowWrap: 'anywhere', WebkitFontSmoothing: 'antialiased', width: '390px' }}>
      <div id="2BIK-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '154px', paddingBottom: '19px', paddingInline: '24px', paddingTop: '21px' }}>
        <div id="2BIL-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', flexBasis: '0%', flexDirection: 'column', flexGrow: '1', justifyContent: 'center' }}>
          <div id="2BIM-0" style={{ boxSizing: 'border-box', color: '#FFFFFF', fontFamily: 'system-ui, sans-serif', fontSize: '17px', fontWeight: 600, lineHeight: '22px', textAlign: 'center', width: 'fit-content' }}>
            9:41
          </div>
        </div>
        <div id="2BIN-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', flexBasis: '0%', flexDirection: 'column', flexGrow: '1', justifyContent: 'center' }}>
          <svg width="82" height="22" viewBox="0 0 82 22" xmlns="http://www.w3.org/2000/svg" id="2BIO-0" style={{ flexShrink: '0', display: 'inline-block' }}>
            <path d="M3.7 13H2.5a1 1 0 0 0-1 1v2.5a1 1 0 0 0 1 1h1.2a1 1 0 0 0 1-1V14a1 1 0 0 0-1-1m5.2-2.5H7.7a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1h1.2a1 1 0 0 0 1-1v-5a1 1 0 0 0-1-1M14.1 8h-1.2a1 1 0 0 0-1 1v7.5a1 1 0 0 0 1 1h1.2a1 1 0 0 0 1-1V9a1 1 0 0 0-1-1m5.2-2.5h-1.2a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h1.2a1 1 0 0 0 1-1v-10a1 1 0 0 0-1-1" fill="#FFFFFF" />
            <path fillRule="evenodd" d="M36.57 7.8c2.49 0 4.88.92 6.68 2.58.14.13.36.12.49 0l1.3-1.27a.34.34 0 0 0 0-.5 12.55 12.55 0 0 0-16.93 0 .34.34 0 0 0 0 .5l1.3 1.26c.13.13.34.14.48 0a10 10 0 0 1 6.68-2.57m0 4.22a5.4 5.4 0 0 1 3.67 1.44c.14.13.35.13.48 0l1.3-1.33a.37.37 0 0 0-.01-.52 7.9 7.9 0 0 0-10.88 0 .37.37 0 0 0 0 .52l1.29 1.32c.13.14.34.14.48 0 1-.92 2.31-1.43 3.67-1.43m2.52 2.8q0 .15-.1.28l-2.18 2.45a.3.3 0 0 1-.24.11.3.3 0 0 1-.24-.1l-2.18-2.46a.43.43 0 0 1 .01-.56 3.44 3.44 0 0 1 4.82 0 .4.4 0 0 1 .11.28" clipRule="evenodd" fill="#FFFFFF" />
            <path fillRule="evenodd" d="M70.5 5c2.05 0 3.08 0 3.88.34a4.3 4.3 0 0 1 2.28 2.28c.34.8.34 1.83.34 3.88s0 3.08-.34 3.88a4.3 4.3 0 0 1-2.28 2.28c-.8.34-1.83.34-3.88.34h-12c-2.05 0-3.08 0-3.88-.34a4.3 4.3 0 0 1-2.28-2.28c-.34-.8-.34-1.83-.34-3.88s0-3.08.34-3.88a4.3 4.3 0 0 1 2.28-2.28C55.42 5 56.45 5 58.5 5zM58.28 6c-1.85 0-2.77 0-3.48.36a3.3 3.3 0 0 0-1.44 1.44C53 8.5 53 9.43 53 11.28v.44c0 1.85 0 2.77.36 3.48a3.3 3.3 0 0 0 1.44 1.44c.7.36 1.63.36 3.48.36h12.44c1.85 0 2.77 0 3.48-.36a3.3 3.3 0 0 0 1.44-1.44c.36-.7.36-1.63.36-3.48v-.44c0-1.85 0-2.77-.36-3.48a3.3 3.3 0 0 0-1.44-1.44C73.5 6 72.57 6 70.72 6z" clipRule="evenodd" fill="#FFFFFF" style={{ opacity: '0.35' }} />
            <path d="M54 11c0-1.4 0-2.1.27-2.63a2.5 2.5 0 0 1 1.1-1.1C55.9 7 56.6 7 58 7h13c1.4 0 2.1 0 2.64.27q.72.37 1.09 1.1C75 8.9 75 9.6 75 11v1c0 1.4 0 2.1-.27 2.64a2.5 2.5 0 0 1-1.1 1.09C73.1 16 72.4 16 71 16H58c-1.4 0-2.1 0-2.63-.27a2.5 2.5 0 0 1-1.1-1.1C54 14.1 54 13.4 54 12z" fill="#FFFFFF" />
            <path d="M78 9.5v4.08a2.2 2.2 0 0 0 1.33-2.04A2.2 2.2 0 0 0 78 9.5" fill="#FFFFFF" style={{ opacity: '0.35' }} />
          </svg>
        </div>
      </div>
      <div id="2BIV-0" style={{ alignItems: 'center', borderBottomColor: 'var(--mx-dark-line)', borderBottomStyle: 'solid', borderBottomWidth: '1px', boxSizing: 'border-box', display: 'flex', flexShrink: 0, height: '56px', justifyContent: 'space-between', paddingInline: '16px' }}>
        <div id="2BTF-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', flexShrink: '0', justifyContent: 'center', minHeight: '44px', width: '44px' }}>
          <svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" id="2BTG-0" style={{ display: 'inline-block', flexShrink: 0 }}>
            <path d="M3 5h14M3 10h14M3 15h14" fill="none" stroke="#D7DCE3" strokeWidth="1.8" strokeLinecap="round" />
          </svg>
        </div>
        <div id="2BIY-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-Bold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 700, lineHeight: '145%' }}>
          M / X
        </div>
        <div id="2BIZ-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
          <div id="2BJ0-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
            期权 ▾
          </div>
        </div>
      </div>
      <div id="2BJ2-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', justifyContent: 'space-between', paddingBlock: '12px', paddingInline: '16px' }}>
        <div id="2BJ3-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-warn)', fontFamily: '"PingFangSC-Medium", "PingFang SC", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, lineHeight: '145%' }}>
          设计示例 · 合成数据
        </div>
        <div id="2BJ4-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '11px', lineHeight: '145%' }}>
          ZH
        </div>
      </div>
      <div id="2DIV-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '16px', padding: '16px', width: '390px' }}>
        <div id="2DIW-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '6px' }}>
          <div id="2DIX-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '28px', fontWeight: 600, lineHeight: '145%' }}>
            SPY · 600看涨
          </div>
          <div id="2DIY-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
            11月20日到期 · 汇总事件
          </div>
        </div>
        <div id="2DIZ-0" style={{ backgroundColor: 'var(--mx-dark-panel)', borderColor: 'var(--mx-dark-line)', borderRadius: '14px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '16px', padding: '16px', width: '358px' }}>
          <div id="2DJ0-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '11px', fontWeight: 600, lineHeight: '145%' }}>
            报告权利金
          </div>
          <div id="2DJ1-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '28px', fontWeight: 600, lineHeight: '145%' }}>
            $224,000
          </div>
          <div id="2DJ2-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
            400份合约 · 来源报告6笔成交
          </div>
          <div id="2DJ3-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
            逐笔记录与组合关系未提供。
          </div>
          <div id="2DJ4-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingBlock: '8px', paddingInline: '14px' }}>
            <div id="2DJ5-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px' }}>
              来源与时间
            </div>
          </div>
        </div>
        <div id="2DJ7-0" style={{ backgroundColor: 'var(--mx-dark-panel)', borderColor: 'var(--mx-dark-line)', borderRadius: '14px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '16px', padding: '16px', width: '358px' }}>
          <div id="2DJ8-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '17px', fontWeight: 600, lineHeight: '145%' }}>
            报价覆盖
          </div>
          <div id="2DJ9-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '28px', fontWeight: 600, lineHeight: '145%' }}>
            93.3%
          </div>
          <div id="2DJA-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
            源权利金金额有报价信息
          </div>
          <div id="2DJB-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
            覆盖 $280k / 源金额 $300k；10笔源成交中覆盖8笔。
          </div>
          <div id="2DJC-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
            按覆盖金额：卖价75% · 买价10% · 价差内10% · 价差外5%。
          </div>
          <div id="2DJD-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
            覆盖率不代表报价新鲜度或可执行质量。
          </div>
        </div>
        <div id="2DJF-0" style={{ backgroundColor: 'var(--mx-dark-panel)', borderColor: 'var(--mx-dark-line)', borderRadius: '14px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '16px', padding: '16px', width: '358px' }}>
          <div id="2DJG-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '17px', fontWeight: 600, lineHeight: '145%' }}>
            独立的 SPY 敞口
          </div>
          <div id="2DJH-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
            打开11月6日期权簿；返回时保留原事件、筛选与位置。
          </div>
          <div id="2DJI-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-text)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingBlock: '8px', paddingInline: '14px' }}>
            <div id="2DJJ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-bg)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px' }}>
              打开敞口 →
            </div>
          </div>
          <div id="2DJK-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingBlock: '8px', paddingInline: '14px' }}>
            <div id="2DJL-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px' }}>
              返回资金流
            </div>
          </div>
        </div>
      </div>
    </div>
  )
