(
    <div id="2BGP-0" style={{ backgroundColor: 'var(--mx-light-bg)', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', fontSize: '12px', fontSynthesis: 'none', height: 'fit-content', lineHeight: '16px', MozOsxFontSmoothing: 'grayscale', overflowWrap: 'anywhere', WebkitFontSmoothing: 'antialiased', width: '390px' }}>
      <div id="2BGR-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '154px', paddingBottom: '19px', paddingInline: '24px', paddingTop: '21px' }}>
        <div id="2BGS-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', flexBasis: '0%', flexDirection: 'column', flexGrow: '1', justifyContent: 'center' }}>
          <div id="2BGT-0" style={{ boxSizing: 'border-box', color: '#000000', fontFamily: 'system-ui, sans-serif', fontSize: '17px', fontWeight: 600, lineHeight: '22px', textAlign: 'center', width: 'fit-content' }}>
            9:41
          </div>
        </div>
        <div id="2BGU-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', flexBasis: '0%', flexDirection: 'column', flexGrow: '1', justifyContent: 'center' }}>
          <svg width="82" height="22" viewBox="0 0 82 22" xmlns="http://www.w3.org/2000/svg" id="2BGV-0" style={{ flexShrink: '0', display: 'inline-block' }}>
            <path d="M3.7 13H2.5a1 1 0 0 0-1 1v2.5a1 1 0 0 0 1 1h1.2a1 1 0 0 0 1-1V14a1 1 0 0 0-1-1m5.2-2.5H7.7a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1h1.2a1 1 0 0 0 1-1v-5a1 1 0 0 0-1-1M14.1 8h-1.2a1 1 0 0 0-1 1v7.5a1 1 0 0 0 1 1h1.2a1 1 0 0 0 1-1V9a1 1 0 0 0-1-1m5.2-2.5h-1.2a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h1.2a1 1 0 0 0 1-1v-10a1 1 0 0 0-1-1" fill="#000000" />
            <path fillRule="evenodd" d="M36.57 7.8c2.49 0 4.88.92 6.68 2.58.14.13.36.12.49 0l1.3-1.27a.34.34 0 0 0 0-.5 12.55 12.55 0 0 0-16.93 0 .34.34 0 0 0 0 .5l1.3 1.26c.13.13.34.14.48 0a10 10 0 0 1 6.68-2.57m0 4.22a5.4 5.4 0 0 1 3.67 1.44c.14.13.35.13.48 0l1.3-1.33a.37.37 0 0 0-.01-.52 7.9 7.9 0 0 0-10.88 0 .37.37 0 0 0 0 .52l1.29 1.32c.13.14.34.14.48 0 1-.92 2.31-1.43 3.67-1.43m2.52 2.8q0 .15-.1.28l-2.18 2.45a.3.3 0 0 1-.24.11.3.3 0 0 1-.24-.1l-2.18-2.46a.43.43 0 0 1 .01-.56 3.44 3.44 0 0 1 4.82 0 .4.4 0 0 1 .11.28" clipRule="evenodd" fill="#000000" />
            <path fillRule="evenodd" d="M70.5 5c2.05 0 3.08 0 3.88.34a4.3 4.3 0 0 1 2.28 2.28c.34.8.34 1.83.34 3.88s0 3.08-.34 3.88a4.3 4.3 0 0 1-2.28 2.28c-.8.34-1.83.34-3.88.34h-12c-2.05 0-3.08 0-3.88-.34a4.3 4.3 0 0 1-2.28-2.28c-.34-.8-.34-1.83-.34-3.88s0-3.08.34-3.88a4.3 4.3 0 0 1 2.28-2.28C55.42 5 56.45 5 58.5 5zM58.28 6c-1.85 0-2.77 0-3.48.36a3.3 3.3 0 0 0-1.44 1.44C53 8.5 53 9.43 53 11.28v.44c0 1.85 0 2.77.36 3.48a3.3 3.3 0 0 0 1.44 1.44c.7.36 1.63.36 3.48.36h12.44c1.85 0 2.77 0 3.48-.36a3.3 3.3 0 0 0 1.44-1.44c.36-.7.36-1.63.36-3.48v-.44c0-1.85 0-2.77-.36-3.48a3.3 3.3 0 0 0-1.44-1.44C73.5 6 72.57 6 70.72 6z" clipRule="evenodd" fill="#000000" style={{ opacity: '0.35' }} />
            <path d="M54 11c0-1.4 0-2.1.27-2.63a2.5 2.5 0 0 1 1.1-1.1C55.9 7 56.6 7 58 7h13c1.4 0 2.1 0 2.64.27q.72.37 1.09 1.1C75 8.9 75 9.6 75 11v1c0 1.4 0 2.1-.27 2.64a2.5 2.5 0 0 1-1.1 1.09C73.1 16 72.4 16 71 16H58c-1.4 0-2.1 0-2.63-.27a2.5 2.5 0 0 1-1.1-1.1C54 14.1 54 13.4 54 12z" fill="#000000" />
            <path d="M78 9.5v4.08a2.2 2.2 0 0 0 1.33-2.04A2.2 2.2 0 0 0 78 9.5" fill="#000000" style={{ opacity: '0.35' }} />
          </svg>
        </div>
      </div>
      <div id="2BH2-0" style={{ alignItems: 'center', borderBottomColor: 'var(--mx-light-line)', borderBottomStyle: 'solid', borderBottomWidth: '1px', boxSizing: 'border-box', display: 'flex', flexShrink: 0, height: '56px', justifyContent: 'space-between', paddingInline: '16px' }}>
        <div id="2BTB-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', flexShrink: '0', justifyContent: 'center', minHeight: '44px', width: '44px' }}>
          <svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" id="2BTC-0" style={{ display: 'inline-block', flexShrink: 0 }}>
            <path d="M3 5h14M3 10h14M3 15h14" fill="none" stroke="#1C2430" strokeWidth="1.8" strokeLinecap="round" />
          </svg>
        </div>
        <div id="2BH5-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-Bold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 700, lineHeight: '145%' }}>
          M / X
        </div>
        <div id="2BH6-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
          <div id="2BH7-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
            期权 ▾
          </div>
        </div>
      </div>
      <div id="2BH9-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', justifyContent: 'space-between', paddingBlock: '12px', paddingInline: '16px' }}>
        <div id="2BHA-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-warn)', fontFamily: '"PingFangSC-Medium", "PingFang SC", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, lineHeight: '145%' }}>
          设计示例 · 合成数据
        </div>
        <div id="2BHB-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '11px', lineHeight: '145%' }}>
          ZH
        </div>
      </div>
      <div id="2BHD-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '16px', paddingBottom: '24px', paddingInline: '16px', paddingTop: '8px', width: '390px' }}>
        <div id="2BHE-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '6px' }}>
          <div id="2BHF-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '28px', fontWeight: 600, lineHeight: '145%' }}>
            期权概览
          </div>
          <div id="2BHG-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
            SPY · 11月9日 10:35 ET
          </div>
        </div>
        <div id="2BHI-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px', padding: '16px' }}>
          <div id="2BHJ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '17px', fontWeight: 600, lineHeight: '145%' }}>
            值得检查的 SPY 看涨期权
          </div>
          <div id="2BHK-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
            600 看涨 · 11月20日到期
          </div>
          <div id="2BHL-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '32px', fontWeight: 600, lineHeight: '145%' }}>
            $224,000
          </div>
          <div id="2BHM-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
            400 份合约 · 报告笔数 6
          </div>
          <div id="2BHN-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
            可查看来源批次的报价覆盖。逐笔明细与交易意图尚不明确。
          </div>
          <div id="2BHO-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '44px', paddingInline: '14px' }}>
            <div id="2BHP-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
              检查成交活动 →
            </div>
          </div>
        </div>
        <div id="2BHR-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px', padding: '16px' }}>
          <div id="2BS5-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '17px', fontWeight: 600, lineHeight: '145%' }}>
            继续深入调查
          </div>
          <div id="2BHT-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <div id="2BHU-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '16px', fontWeight: 600, lineHeight: '145%' }}>
              敞口 · 同口径变化 +$50m / 1%
            </div>
            <div id="2BHV-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
              11月6日期权簿 · 六项中五项可用
            </div>
            <div id="2BHW-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '44px', paddingInline: '14px' }}>
              <div id="2BHX-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                比较期权簿
              </div>
            </div>
          </div>
          <div id="2BHY-0" style={{ backgroundColor: 'var(--mx-light-line)', boxSizing: 'border-box', flexShrink: 0, height: '1px', width: '100%' }} />
          <div id="2BHZ-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <div id="2BI0-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '16px', fontWeight: 600, lineHeight: '145%' }}>
              波动率 · 近到期 ATM IV 23.5%
            </div>
            <div id="2BI1-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
              11月6日收盘 · 11月13日到期
            </div>
            <div id="2BI2-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '44px', paddingInline: '14px' }}>
              <div id="2BI3-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                研究波动率
              </div>
            </div>
          </div>
        </div>
        <div id="2BI5-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px', padding: '16px' }}>
          <div id="2BI6-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '17px', fontWeight: 600, lineHeight: '145%' }}>
            继续已保存的研究
          </div>
          <div id="2BI7-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '18px', fontWeight: 600, lineHeight: '145%' }}>
            SPY 能否突破 $605？
          </div>
          <div id="2BI8-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
            修订 1 · 已保存敞口证据 · 价格观察条件已启用
          </div>
          <div id="2BI9-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '44px', paddingInline: '14px' }}>
            <div id="2BIA-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
              打开研究案例
            </div>
          </div>
        </div>
        <div id="2BIC-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px', padding: '16px' }}>
          <div id="2BID-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '17px', fontWeight: 600, lineHeight: '145%' }}>
            来源时间不同
          </div>
          <div id="2BIE-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
            资金流截至 11月9日 10:20 ET；敞口与波动率来自 11月6日。它们不是同一时刻的快照。
          </div>
          <div id="2BIF-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '44px', paddingInline: '14px' }}>
            <div id="2BIG-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
              查看来源与覆盖
            </div>
          </div>
        </div>
      </div>
    </div>
  )
