(
    <div id="2BCJ-0" style={{ backgroundColor: 'var(--mx-light-bg)', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', fontSynthesis: 'none', gap: '24px', height: 'fit-content', MozOsxFontSmoothing: 'grayscale', overflowWrap: 'anywhere', padding: '32px', WebkitFontSmoothing: 'antialiased', width: '1440px' }}>
      <div id="2BCL-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '8px' }}>
        <div id="2BCM-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
          OPTIONS R6 · BUILD CONTRACT
        </div>
        <div id="2BCN-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '28px', fontWeight: 600, lineHeight: '145%' }}>
          An action must preserve its context
        </div>
        <div id="2BCO-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
          Selection, source time, authored assumptions and return focus are part of the interaction—not hidden implementation detail.
        </div>
      </div>
      <div id="2BCQ-0" style={{ boxSizing: 'border-box', display: 'flex', gap: '24px', paddingInline: '20px' }}>
        <div id="2BCR-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', flexShrink: 0, fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
          Action
        </div>
        <div id="2BCS-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', flexShrink: 0, fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12px', fontWeight: 600, lineHeight: '145%', width: '340px' }}>
          Context carried
        </div>
        <div id="2BCT-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', flexShrink: 0, fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12px', fontWeight: 600, lineHeight: '145%', width: '580px' }}>
          Required result
        </div>
        <div id="2BCU-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', flexShrink: 0, fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12px', fontWeight: 600, lineHeight: '145%', width: '164px' }}>
          Design coverage
        </div>
      </div>
      <div id="2BCW-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '24px', padding: '20px' }}>
        <div id="2BCX-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '16px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
          Inspect activity
        </div>
        <div id="2BCY-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '340px' }}>
          Exact group, filters, sort, 10:20 snapshot and originating focus.
        </div>
        <div id="2BCZ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '580px' }}>
          Desktop: one shared inspector. Phone: focused aggregate view. Escape / Back restores selected event, filters, sort, focus and scroll. A changed publication is not called a correction without source lineage.
        </div>
        <div id="2BD0-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', whiteSpace: 'pre-wrap', width: '164px' }}>
          O02 · M01–02<br />E01–E04 · A03
        </div>
      </div>
      <div id="2BD2-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '24px', padding: '20px' }}>
        <div id="2BD3-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '16px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
          Open Exposure
        </div>
        <div id="2BD4-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '340px' }}>
          Explicit root-only SPY handoff from an independently qualified source.
        </div>
        <div id="2BD5-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '580px' }}>
          Receive /options?tab=gex&amp;symbol=SPY&amp;view=chart. The dated book has independent clocks and qualification. Explicit Return restores the original Flow event and view. Sector and Equity/Futures origins keep their own grammar.
        </div>
        <div id="2BD6-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', whiteSpace: 'pre-wrap', width: '164px' }}>
          O03 · M03–04<br />E05–E09
        </div>
      </div>
      <div id="2BD8-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '24px', padding: '20px' }}>
        <div id="2BD9-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '16px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
          Compare books
        </div>
        <div id="2BDA-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '340px' }}>
          Baseline Nov 5, current Nov 6; exact units and contract population.
        </div>
        <div id="2BDB-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '580px' }}>
          All 6 / Matched 5 / Unknown 1 remain different filters. Five known rows sum from +150m to +200m; unknown is never zero. Keep selected 600 Call.
        </div>
        <div id="2BDC-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', whiteSpace: 'pre-wrap', width: '164px' }}>
          O10<br />E06 · E09
        </div>
      </div>
      <div id="2BDE-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '24px', padding: '20px' }}>
        <div id="2BDF-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '16px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
          Compare Plan
        </div>
        <div id="2BDG-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '340px' }}>
          Exact two legs, authored side / quantity / premiums, USD, expiry and sample axis.
        </div>
        <div id="2BDH-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '580px' }}>
          Only the stated assumption changes. $606 is an actual response sample: +$280 vs +$230. Breakeven is analytic, not an inserted grid point. Dirty inputs invalidate the current result.
        </div>
        <div id="2BDI-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', whiteSpace: 'pre-wrap', width: '164px' }}>
          O07 · O09 · M05<br />P01–P02 · E12
        </div>
      </div>
      <div id="2BDK-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '24px', padding: '20px' }}>
        <div id="2BDL-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '16px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
          Save / reopen case
        </div>
        <div id="2BDM-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '340px' }}>
          Existing Investigation identity, expected revision and exact evidence refs.
        </div>
        <div id="2BDN-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '580px' }}>
          Preview included content. Preserve authored text on failure. Known commit retries only read; unknown result reconciles original operation. No latest-revision substitution or duplicate write.
        </div>
        <div id="2BDO-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', whiteSpace: 'pre-wrap', width: '164px' }}>
          O06 · B04<br />P03–P09 · P12
        </div>
      </div>
      <div id="2BDQ-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '24px', padding: '20px' }}>
        <div id="2BDR-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '16px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
          Arm / fire watch
        </div>
        <div id="2BDS-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '340px' }}>
          Saved case, exact strict comparator, threshold and one-shot mode. No unsupported ordinary watch expiry.
        </div>
        <div id="2BDT-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '580px' }}>
          Preview before arming. Owner confirmation before Armed. Condition firing, receipt delivery and research assessment remain distinct. Do not substitute an unsupported exposure evaluator.
        </div>
        <div id="2BDU-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', whiteSpace: 'pre-wrap', width: '164px' }}>
          M08 · O08<br />W01–W08 · W10
        </div>
      </div>
      <div id="2BDW-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '24px', padding: '20px' }}>
        <div id="2BDX-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '16px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
          Record assessment
        </div>
        <div id="2BDY-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '340px' }}>
          Explicit selected firing, latest case revision and authored assessment.
        </div>
        <div id="2BDZ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '580px' }}>
          No default assessment. Save a new immutable revision. A newer fire cannot silently replace the selected event. Preserve source-as-of unknown and pending delivery as separate facts.
        </div>
        <div id="2BE0-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', whiteSpace: 'pre-wrap', width: '164px' }}>
          O08 · M06<br />P10–P12 · W09
        </div>
      </div>
      <div id="2BE2-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '24px', padding: '20px' }}>
        <div id="2BE3-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '16px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
          Change view / scope
        </div>
        <div id="2BE4-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '340px' }}>
          Account, root, expiry, temporal mode, comparison basis and source epoch.
        </div>
        <div id="2BE5-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '580px' }}>
          Requalify or clear dependent work atomically; late results cannot cross identities. Lab 2D / 3D uses the same dataset, missing values and selection. Return remains deterministic.
        </div>
        <div id="2BE6-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', whiteSpace: 'pre-wrap', width: '164px' }}>
          T01–T02<br />A01–A08 · W12
        </div>
      </div>
      <div id="2BE8-0" style={{ boxSizing: 'border-box', display: 'flex', gap: '24px' }}>
        <div id="2BE9-0" style={{ borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '10px', padding: '20px', width: '442px' }}>
          <div id="2BEA-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '17px', fontWeight: 600, lineHeight: '145%' }}>
            Readable at every size
          </div>
          <div id="2BEB-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
            1920: bounded reading width. 1440: one 320px pane. 1280: focused case/source panel. 820: readable stacked comparison. 390 EN/ZH: task-first detail. Retain 320px components. Actual 200% zoom and keyboard/touch application proof remain required.
          </div>
        </div>
        <div id="2BEC-0" style={{ borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '10px', padding: '20px', width: '442px' }}>
          <div id="2BED-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '17px', fontWeight: 600, lineHeight: '145%' }}>
            Locale and access
          </div>
          <div id="2BEE-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
            Inter / PingFang SC, shared light/dark tokens, explicit EN/ZH copy, full focus outline and 44px touch actions. Reduced motion and exact-table fallback remain usable.
          </div>
        </div>
        <div id="2BEF-0" style={{ borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '10px', padding: '20px', width: '442px' }}>
          <div id="2BEG-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '17px', fontWeight: 600, lineHeight: '145%' }}>
            Implementation acceptance
          </div>
          <div id="2BEH-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
            Paper screenshots and JSX prove design appearance only. Source/model qualification, authentic actions and receipts, persistence, 200% browser zoom, focus restoration, screen-reader semantics, performance and production acceptance remain owed. Current Round-6 manifest and action crosswalk supersede affected historical mappings.
          </div>
        </div>
      </div>
    </div>
  )
