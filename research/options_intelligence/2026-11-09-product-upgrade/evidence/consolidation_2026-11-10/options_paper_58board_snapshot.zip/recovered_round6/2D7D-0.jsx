(
    <div id="2D7D-0" style={{ backgroundColor: 'var(--mx-dark-bg)', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', fontSize: '12px', fontSynthesis: 'none', height: 'fit-content', lineHeight: '16px', MozOsxFontSmoothing: 'grayscale', overflowWrap: 'anywhere', WebkitFontSmoothing: 'antialiased', width: '390px' }}>
      <div id="2D8G-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '154px', paddingBottom: '19px', paddingInline: '24px', paddingTop: '21px' }}>
        <div id="2D8O-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', flexBasis: '0%', flexDirection: 'column', flexGrow: '1', justifyContent: 'center' }}>
          <div id="2D8P-0" style={{ boxSizing: 'border-box', color: '#FFFFFF', fontFamily: 'system-ui, sans-serif', fontSize: '17px', fontWeight: 600, lineHeight: '22px', textAlign: 'center', width: 'fit-content' }}>
            9:41
          </div>
        </div>
        <div id="2D8H-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', flexBasis: '0%', flexDirection: 'column', flexGrow: '1', justifyContent: 'center' }}>
          <svg width="82" height="22" viewBox="0 0 82 22" xmlns="http://www.w3.org/2000/svg" id="2D8I-0" style={{ flexShrink: '0', display: 'inline-block' }}>
            <path d="M3.7 13H2.5a1 1 0 0 0-1 1v2.5a1 1 0 0 0 1 1h1.2a1 1 0 0 0 1-1V14a1 1 0 0 0-1-1m5.2-2.5H7.7a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1h1.2a1 1 0 0 0 1-1v-5a1 1 0 0 0-1-1M14.1 8h-1.2a1 1 0 0 0-1 1v7.5a1 1 0 0 0 1 1h1.2a1 1 0 0 0 1-1V9a1 1 0 0 0-1-1m5.2-2.5h-1.2a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h1.2a1 1 0 0 0 1-1v-10a1 1 0 0 0-1-1" fill="#FFFFFF" />
            <path fillRule="evenodd" d="M36.57 7.8c2.49 0 4.88.92 6.68 2.58.14.13.36.12.49 0l1.3-1.27a.34.34 0 0 0 0-.5 12.55 12.55 0 0 0-16.93 0 .34.34 0 0 0 0 .5l1.3 1.26c.13.13.34.14.48 0a10 10 0 0 1 6.68-2.57m0 4.22a5.4 5.4 0 0 1 3.67 1.44c.14.13.35.13.48 0l1.3-1.33a.37.37 0 0 0-.01-.52 7.9 7.9 0 0 0-10.88 0 .37.37 0 0 0 0 .52l1.29 1.32c.13.14.34.14.48 0 1-.92 2.31-1.43 3.67-1.43m2.52 2.8q0 .15-.1.28l-2.18 2.45a.3.3 0 0 1-.24.11.3.3 0 0 1-.24-.1l-2.18-2.46a.43.43 0 0 1 .01-.56 3.44 3.44 0 0 1 4.82 0 .4.4 0 0 1 .11.28" clipRule="evenodd" fill="#FFFFFF" />
            <path fillRule="evenodd" d="M70.5 5c2.05 0 3.08 0 3.88.34a4.3 4.3 0 0 1 2.28 2.28c.34.8.34 1.83.34 3.88s0 3.08-.34 3.88a4.3 4.3 0 0 1-2.28 2.28c-.8.34-1.83.34-3.88.34h-12c-2.05 0-3.08 0-3.88-.34a4.3 4.3 0 0 1-2.28-2.28c-.34-.8-.34-1.83-.34-3.88s0-3.08.34-3.88a4.3 4.3 0 0 1 2.28-2.28C55.42 5 56.45 5 58.5 5zM58.28 6c-1.85 0-2.77 0-3.48.36a3.3 3.3 0 0 0-1.44 1.44C53 8.5 53 9.43 53 11.28v.44c0 1.85 0 2.77.36 3.48a3.3 3.3 0 0 0 1.44 1.44c.7.36 1.63.36 3.48.36h12.44c1.85 0 2.77 0 3.48-.36a3.3 3.3 0 0 0 1.44-1.44c.36-.7.36-1.63.36-3.48v-.44c0-1.85 0-2.77-.36-3.48a3.3 3.3 0 0 0-1.44-1.44C73.5 6 72.57 6 70.72 6z" clipRule="evenodd" fill="#FFFFFF" style={{ opacity: '0.35' }} />
            <path d="M54 11c0-1.4 0-2.1.27-2.63a2.5 2.5 0 0 1 1.1-1.1C55.9 7 56.6 7 58 7h13c1.4 0 2.1 0 2.64.27q.72.37 1.09 1.1C75 8.9 75 9.6 75 11v1c0 1.4 0 2.1-.27 2.64a2.5 2.5 0 0 1-1.1 1.09C73.1 16 72.4 16 71 16H58c-1.4 0-2.1 0-2.63-.27a2.5 2.5 0 0 1-1.1-1.1C54 14.1 54 13.4 54 12z" fill="#FFFFFF" />
            <path d="M78 9.5v4.08a2.2 2.2 0 0 0 1.33-2.04A2.2 2.2 0 0 0 78 9.5" fill="#FFFFFF" style={{ opacity: '0.35' }} />
          </svg>
        </div>
      </div>
      <div id="2D89-0" style={{ alignItems: 'center', borderBottomColor: 'var(--mx-dark-line)', borderBottomStyle: 'solid', borderBottomWidth: '1px', boxSizing: 'border-box', display: 'flex', flexShrink: 0, height: '56px', justifyContent: 'space-between', paddingInline: '16px' }}>
        <div id="2D8D-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', flexShrink: '0', justifyContent: 'center', minHeight: '44px', width: '44px' }}>
          <svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" id="2D8E-0" style={{ display: 'inline-block', flexShrink: 0 }}>
            <path d="M3 5h14M3 10h14M3 15h14" fill="none" stroke="#D7DCE3" strokeWidth="1.8" strokeLinecap="round" />
          </svg>
        </div>
        <div id="2D8C-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-Bold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 700, lineHeight: '145%' }}>
          M / X
        </div>
        <div id="2D8A-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
          <div id="2D8B-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
            Options ▾
          </div>
        </div>
      </div>
      <div id="2D86-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', justifyContent: 'space-between', paddingBlock: '12px', paddingInline: '16px' }}>
        <div id="2D88-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-warn)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, lineHeight: '145%' }}>
          Design example · synthetic data
        </div>
        <div id="2D87-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '11px', lineHeight: '145%' }}>
          EN
        </div>
      </div>
      <div id="2DG5-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '16px', padding: '16px', width: '390px' }}>
        <div id="2DG6-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '6px' }}>
          <div id="2DG7-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-Bold", "Inter", system-ui, sans-serif', fontSize: '28px', fontWeight: 700, lineHeight: '145%' }}>
            Monitor
          </div>
          <div id="2DG8-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
            10 Nov · 10:15 ET · 1 case
          </div>
        </div>
        <div id="2DG9-0" style={{ backgroundColor: 'var(--mx-dark-panel)', borderColor: 'var(--mx-dark-line)', borderRadius: '14px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '16px', padding: '16px', width: '358px' }}>
          <div id="2DGA-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-Bold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 700, lineHeight: '145%' }}>
            SPY above $605
          </div>
          <div id="2DGB-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '13px', fontWeight: 600, lineHeight: '145%' }}>
            One shot · fired and disarmed
          </div>
          <div id="2DGC-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-Bold", "Inter", system-ui, sans-serif', fontSize: '28px', fontWeight: 700, lineHeight: '145%' }}>
            $605.10
          </div>
          <div id="2DGD-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
            Recorded 10:06:02 ET; source price time unavailable.
          </div>
          <div id="2DGE-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
            Delivery pending. Reassess the research question.
          </div>
          <div id="2DGF-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-text)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingBlock: '8px', paddingInline: '14px' }}>
            <div id="2DGG-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-bg)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px' }}>
              Review selected firing →
            </div>
          </div>
          <div id="2DGH-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingBlock: '8px', paddingInline: '14px' }}>
            <div id="2DGI-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px' }}>
              Original evidence
            </div>
          </div>
        </div>
        <div id="2DGK-0" style={{ backgroundColor: 'var(--mx-dark-panel)', borderColor: 'var(--mx-dark-line)', borderRadius: '14px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '16px', padding: '16px', width: '358px' }}>
          <div id="2DGL-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-Bold", "Inter", system-ui, sans-serif', fontSize: '17px', fontWeight: 700, lineHeight: '145%' }}>
            Original case
          </div>
          <div id="2DGM-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%' }}>
            SPY through $605 · revision 1
          </div>
          <div id="2DGN-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
            Nov 6 Exposure book. Review by 13 Nov.
          </div>
          <div id="2DGO-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%' }}>
            No Plan is saved in this revision.
          </div>
          <div id="2DGP-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingBlock: '8px', paddingInline: '14px' }}>
            <div id="2DGQ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px' }}>
              Start separate comparison
            </div>
          </div>
        </div>
        <div id="2DGS-0" style={{ backgroundColor: 'var(--mx-dark-panel)', borderColor: 'var(--mx-dark-line)', borderRadius: '14px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '16px', padding: '16px', width: '358px' }}>
          <div id="2DGT-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-Bold", "Inter", system-ui, sans-serif', fontSize: '17px', fontWeight: 700, lineHeight: '145%' }}>
            Keep outcomes separate
          </div>
          <div id="2DGU-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
            A sampled price event is not an option return or thesis confirmation.
          </div>
          <div id="2DGV-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
            Equal to $605 does not fire. Sampled checks may miss intervening moves.
          </div>
          <div id="2DGW-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingBlock: '8px', paddingInline: '14px' }}>
            <div id="2DGX-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px' }}>
              Outcome evidence
            </div>
          </div>
        </div>
        <div id="2DGY-0" style={{ backgroundColor: 'var(--mx-dark-panel)', borderColor: 'var(--mx-dark-line)', borderRadius: '14px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '16px', padding: '16px', width: '358px' }}>
          <div id="2DGZ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-Bold", "Inter", system-ui, sans-serif', fontSize: '17px', fontWeight: 700, lineHeight: '145%' }}>
            Firing &amp; delivery history
          </div>
          <div id="2DH0-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
            Recent window only. Missing from this window does not prove absence.
          </div>
          <div id="2DH1-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingBlock: '8px', paddingInline: '14px' }}>
            <div id="2DH2-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px' }}>
              Open recent history
            </div>
          </div>
        </div>
      </div>
    </div>
  )
