(
    <div id="2BTZ-0" style={{ backgroundColor: 'var(--mx-dark-bg)', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', fontSize: '12px', fontSynthesis: 'none', lineHeight: '16px', MozOsxFontSmoothing: 'grayscale', overflowWrap: 'anywhere', WebkitFontSmoothing: 'antialiased' }}>
      <div id="2BYX-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-bg)', borderBottomColor: 'var(--mx-dark-line)', borderBottomStyle: 'solid', borderBottomWidth: '1px', boxSizing: 'border-box', display: 'flex', flexShrink: 0, height: '64px', justifyContent: 'space-between', paddingInline: '24px', width: '1440px' }}>
        <div id="2BZ7-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', flexShrink: 0, gap: '12px', width: '176px' }}>
          <div id="2BZ9-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-Bold", "Inter", system-ui, sans-serif', fontSize: '15px', fontWeight: 700, lineHeight: '145%' }}>
            M / X
          </div>
          <div id="2BZ8-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '10px', fontWeight: 600, lineHeight: '145%' }}>
            MASTERMIND
          </div>
        </div>
        <div id="2BZ4-0" style={{ alignItems: 'center', borderColor: 'var(--mx-dark-line)', borderRadius: '8px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexShrink: 0, height: '36px', justifyContent: 'space-between', paddingInline: '14px', width: '380px' }}>
          <div id="2BZ6-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
            Search companies and tools
          </div>
          <div id="2BZ5-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12px', lineHeight: '145%' }}>
            ⌘ K
          </div>
        </div>
        <div id="2BYY-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', flexBasis: '0%', flexGrow: '1', gap: '24px', justifyContent: 'end', paddingLeft: '24px' }}>
          <div id="2BZ3-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-warn)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 500, lineHeight: '145%' }}>
            Design target · independent child fixture
          </div>
          <div id="2BZ2-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
            All tools
          </div>
          <div id="2BZ1-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
            EN · Dark
          </div>
          <div id="2BYZ-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '999px', boxSizing: 'border-box', display: 'flex', flexShrink: 0, height: '32px', justifyContent: 'center', width: '32px' }}>
            <div id="2BZ0-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12px', lineHeight: '145%' }}>
              R
            </div>
          </div>
        </div>
      </div>
      <div id="2BU0-0" style={{ boxSizing: 'border-box', display: 'flex', minHeight: '896px', width: '1440px' }}>
        <div id="2BYD-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, width: '224px' }}>
          <div id="2BYE-0" style={{ backgroundColor: 'var(--mx-dark-bg)', borderRightColor: 'var(--mx-dark-line)', borderRightStyle: 'solid', borderRightWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '8px', minHeight: '896px', paddingBlock: '24px', paddingInline: '16px', width: '224px' }}>
            <div id="2BYV-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '12px' }}>
              <div id="2BYW-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '18px' }}>
                Today
              </div>
            </div>
            <div id="2BYT-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '12px' }}>
              <div id="2BYU-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '18px' }}>
                Discover
              </div>
            </div>
            <div id="2BYR-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '12px' }}>
              <div id="2BYS-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '18px' }}>
                Analysis
              </div>
            </div>
            <div id="2BYP-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '12px' }}>
              <div id="2BYQ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '18px' }}>
                Monitor
              </div>
            </div>
            <div id="2BYN-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '12px' }}>
              <div id="2BYO-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '18px' }}>
                Research
              </div>
            </div>
            <div id="2BYL-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '12px' }}>
              <div id="2BYM-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '18px' }}>
                Portfolio
              </div>
            </div>
            <div id="2BYJ-0" style={{ boxSizing: 'border-box', paddingBottom: '8px', paddingInline: '12px', paddingTop: '28px' }}>
              <div id="2BYK-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '11px', letterSpacing: '0.08em', lineHeight: '14px' }}>
                WORKSPACES
              </div>
            </div>
            <div id="2BYH-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '12px' }}>
              <div id="2BYI-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '18px' }}>
                Options
              </div>
            </div>
            <div id="2BYF-0" style={{ boxSizing: 'border-box', paddingInline: '12px' }}>
              <div id="2BYG-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                United States · USD
              </div>
            </div>
          </div>
        </div>
        <div id="2BU1-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', padding: '24px', width: '1216px' }}>
          <div id="2BXX-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', justifyContent: 'space-between', minHeight: '40px', width: '100%' }}>
            <div id="2BY0-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '4px' }}>
              <div id="2BYB-0" style={{ alignItems: 'center', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
                <div id="2BYC-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '16px', whiteSpace: 'pre' }}>
                  Overview
                </div>
              </div>
              <div id="2BY9-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
                <div id="2BYA-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                  Flow
                </div>
              </div>
              <div id="2BY7-0" style={{ alignItems: 'center', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
                <div id="2BY8-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '16px', whiteSpace: 'pre' }}>
                  Exposure
                </div>
              </div>
              <div id="2BY5-0" style={{ alignItems: 'center', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
                <div id="2BY6-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '16px', whiteSpace: 'pre' }}>
                  Volatility
                </div>
              </div>
              <div id="2BY3-0" style={{ alignItems: 'center', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
                <div id="2BY4-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '16px', whiteSpace: 'pre' }}>
                  Research
                </div>
              </div>
              <div id="2BY1-0" style={{ alignItems: 'center', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
                <div id="2BY2-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '16px', whiteSpace: 'pre' }}>
                  Plans &amp; review
                </div>
              </div>
            </div>
            <div id="2BXY-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="2BXZ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                SPY · Change
              </div>
            </div>
          </div>
          <div id="2BXQ-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', justifyContent: 'space-between', minHeight: '76px', width: '100%' }}>
            <div id="2BXU-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '6px' }}>
              <div id="2BXW-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '28px', fontWeight: 600, lineHeight: '145%' }}>
                Print investigation
              </div>
              <div id="2BXV-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
                Individual records, where the source supplies them.
              </div>
            </div>
            <div id="2BXR-0" style={{ alignItems: 'end', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '6px' }}>
              <div id="2BXT-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 500, lineHeight: '145%' }}>
                Historical snapshot · 09 Nov
              </div>
              <div id="2BXS-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                10:20 ET · SPY $598.40 at 10:19:58
              </div>
            </div>
          </div>
          <div id="2BX7-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', justifyContent: 'space-between', width: '100%' }}>
            <div id="2BXD-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '4px' }}>
              <div id="2BXO-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-text)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
                <div id="2BXP-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-bg)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                  Tape
                </div>
              </div>
              <div id="2BXM-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
                <div id="2BXN-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                  Largest
                </div>
              </div>
              <div id="2BXK-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
                <div id="2BXL-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                  Unusual
                </div>
              </div>
              <div id="2BXI-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
                <div id="2BXJ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                  0DTE
                </div>
              </div>
              <div id="2BXG-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
                <div id="2BXH-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                  OI changes
                </div>
              </div>
              <div id="2BXE-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
                <div id="2BXF-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                  More views
                </div>
              </div>
            </div>
            <div id="2BX8-0" style={{ boxSizing: 'border-box', display: 'flex', gap: '8px' }}>
              <div id="2BXB-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
                <div id="2BXC-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                  Filters · 3
                </div>
              </div>
              <div id="2BX9-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
                <div id="2BXA-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                  Premium ↓
                </div>
              </div>
            </div>
          </div>
          <div id="2BU2-0" style={{ alignItems: 'start', boxSizing: 'border-box', display: 'flex', gap: '24px', width: '1168px' }}>
            <div id="2BUY-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', width: '824px' }}>
              <div id="2BVS-0" style={{ backgroundColor: 'var(--mx-dark-panel)', borderColor: 'var(--mx-dark-line)', borderRadius: '14px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', minHeight: '0px', overflow: 'clip', width: '824px' }}>
                <div id="2BX1-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', justifyContent: 'space-between', padding: '20px' }}>
                  <div id="2BX4-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '4px' }}>
                    <div id="2BX6-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '17px', fontWeight: 600, lineHeight: '145%' }}>
                      Observed activity
                    </div>
                    <div id="2BX5-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                      SPY · 20 Nov · ≥$15k · 3 groups / 8 source prints
                    </div>
                  </div>
                  <div id="2BX2-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '14px' }}>
                    <div id="2BX3-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '16px' }}>
                      Pinned · 10:20 ET
                    </div>
                  </div>
                </div>
                <div id="2BWT-0" style={{ alignItems: 'center', borderBottomColor: 'var(--mx-dark-line)', borderBottomStyle: 'solid', borderBottomWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '4px', paddingBlock: '10px', paddingInline: '20px' }}>
                  <div id="2BX0-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: 0, fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '10px', fontWeight: 500, letterSpacing: '0.05em', lineHeight: '145%', width: '246px' }}>
                    CONTRACT
                  </div>
                  <div id="2BWZ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: 0, fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '10px', fontWeight: 500, letterSpacing: '0.05em', lineHeight: '145%', width: '108px' }}>
                    PREMIUM
                  </div>
                  <div id="2BWY-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: 0, fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '10px', fontWeight: 500, letterSpacing: '0.05em', lineHeight: '145%', width: '80px' }}>
                    CONTRACTS
                  </div>
                  <div id="2BWX-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: 0, fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '10px', fontWeight: 500, letterSpacing: '0.05em', lineHeight: '145%', width: '64px' }}>
                    PRINTS
                  </div>
                  <div id="2BWW-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: 0, fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '10px', fontWeight: 500, letterSpacing: '0.05em', lineHeight: '145%', width: '112px' }}>
                    QUOTE
                  </div>
                  <div id="2BWV-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: 0, fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '10px', fontWeight: 500, letterSpacing: '0.05em', lineHeight: '145%', width: '76px' }}>
                    LAST · ET
                  </div>
                  <div id="2BWU-0" style={{ boxSizing: 'border-box', flexShrink: 0, width: '70px' }} />
                </div>
                <div id="2BWI-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderBottomColor: 'var(--mx-dark-line)', borderBottomStyle: 'solid', borderBottomWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '4px', minHeight: '76px', paddingBlock: '14px', paddingInline: '20px' }}>
                  <div id="2BWQ-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '3px', width: '246px' }}>
                    <div id="2BWS-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%' }}>
                      SPY · 600 Call
                    </div>
                    <div id="2BWR-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                      20 Nov 2026
                    </div>
                  </div>
                  <div id="2BWP-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: 0, fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%', width: '108px' }}>
                    $224,000
                  </div>
                  <div id="2BWO-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: 0, fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%', width: '80px' }}>
                    400
                  </div>
                  <div id="2BWN-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: 0, fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%', width: '64px' }}>
                    6
                  </div>
                  <div id="2BWM-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: 0, fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%', width: '112px' }}>
                    Ask / unknown
                  </div>
                  <div id="2BWL-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: 0, fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%', width: '76px' }}>
                    10:18:42
                  </div>
                  <div id="2BWJ-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', flexShrink: 0, justifyContent: 'center', minHeight: '40px', paddingInline: '6px', width: '70px' }}>
                    <div id="2BWK-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                      Selected
                    </div>
                  </div>
                </div>
                <div id="2BW7-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel)', borderBottomColor: 'var(--mx-dark-line)', borderBottomStyle: 'solid', borderBottomWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '4px', minHeight: '76px', paddingBlock: '14px', paddingInline: '20px' }}>
                  <div id="2BWF-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '3px', width: '246px' }}>
                    <div id="2BWH-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%' }}>
                      SPY · 610 Call
                    </div>
                    <div id="2BWG-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                      20 Nov 2026
                    </div>
                  </div>
                  <div id="2BWE-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: 0, fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%', width: '108px' }}>
                    $16,800
                  </div>
                  <div id="2BWD-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: 0, fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%', width: '80px' }}>
                    70
                  </div>
                  <div id="2BWC-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: 0, fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%', width: '64px' }}>
                    1
                  </div>
                  <div id="2BWB-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: 0, fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%', width: '112px' }}>
                    Unclassified
                  </div>
                  <div id="2BWA-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: 0, fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%', width: '76px' }}>
                    10:16:33
                  </div>
                  <div id="2BW8-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', flexShrink: 0, justifyContent: 'center', minHeight: '40px', paddingInline: '6px', width: '70px' }}>
                    <div id="2BW9-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                      Inspect
                    </div>
                  </div>
                </div>
                <div id="2BVW-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel)', borderBottomColor: 'var(--mx-dark-line)', borderBottomStyle: 'solid', borderBottomWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '4px', minHeight: '76px', paddingBlock: '14px', paddingInline: '20px' }}>
                  <div id="2BW4-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '3px', width: '246px' }}>
                    <div id="2BW6-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%' }}>
                      SPY · 590 Put
                    </div>
                    <div id="2BW5-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                      20 Nov 2026
                    </div>
                  </div>
                  <div id="2BW3-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: 0, fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%', width: '108px' }}>
                    $15,000
                  </div>
                  <div id="2BW2-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: 0, fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%', width: '80px' }}>
                    50
                  </div>
                  <div id="2BW1-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: 0, fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%', width: '64px' }}>
                    1
                  </div>
                  <div id="2BW0-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: 0, fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%', width: '112px' }}>
                    At bid
                  </div>
                  <div id="2BVZ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: 0, fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%', width: '76px' }}>
                    10:12:09
                  </div>
                  <div id="2BVX-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', flexShrink: 0, justifyContent: 'center', minHeight: '40px', paddingInline: '6px', width: '70px' }}>
                    <div id="2BVY-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                      Inspect
                    </div>
                  </div>
                </div>
                <div id="2BVT-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', justifyContent: 'space-between', paddingBlock: '14px', paddingInline: '20px' }}>
                  <div id="2BVV-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    Shown separately · package relationship unknown
                  </div>
                  <div id="2BVU-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-link)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    See all observations →
                  </div>
                </div>
              </div>
              <div id="2BUZ-0" style={{ backgroundColor: 'var(--mx-dark-panel)', borderColor: 'var(--mx-dark-line)', borderRadius: '14px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px', padding: '20px' }}>
                <div id="2BVP-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', justifyContent: 'space-between' }}>
                  <div id="2BVR-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '17px', fontWeight: 600, lineHeight: '145%' }}>
                    Six prints in 52 seconds
                  </div>
                  <div id="2BVQ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    Contracts · selected observation
                  </div>
                </div>
                <svg width="780" height="135" viewBox="0 0 780 135" xmlns="http://www.w3.org/2000/svg" id="2BV9-0" style={{ display: 'inline-block', flexShrink: 0 }}>
                  <line x1="20" y1="105" x2="758" y2="105" stroke="#3A4150" />
                  <rect x="30" y="35" width="24" height="70" rx="4" fill="#5B9BF0" />
                  <text x="42" y="28" fontSize="12" textAnchor="middle" fontFamily="Inter" fill="#D7DCE3">{"100"}</text>
                  <rect x="192" y="49" width="24" height="56" rx="4" fill="#5B9BF0" />
                  <text x="204" y="42" fontSize="12" textAnchor="middle" fontFamily="Inter" fill="#D7DCE3">{"80"}</text>
                  <rect x="292" y="56" width="24" height="49" rx="4" fill="#5B9BF0" />
                  <text x="304" y="49" fontSize="12" textAnchor="middle" fontFamily="Inter" fill="#D7DCE3">{"70"}</text>
                  <rect x="405" y="70" width="24" height="35" rx="4" fill="#5B9BF0" />
                  <text x="417" y="63" fontSize="12" textAnchor="middle" fontFamily="Inter" fill="#D7DCE3">{"50"}</text>
                  <rect x="542" y="63" width="24" height="42" rx="4" fill="#3A4150" />
                  <text x="554" y="56" fontSize="12" textAnchor="middle" fontFamily="Inter" fill="#D7DCE3">{"60"}</text>
                  <rect x="680" y="77" width="24" height="28" rx="4" fill="#3A4150" />
                  <text x="692" y="70" fontSize="12" textAnchor="middle" fontFamily="Inter" fill="#D7DCE3">{"40"}</text>
                  <text x="20" y="130" fontSize="11" fontFamily="Inter" fill="#8B93A1">{"10:17:50"}</text>
                  <text x="680" y="130" fontSize="11" fontFamily="Inter" fill="#8B93A1">{"10:18:42 ET"}</text>
                </svg>
                <div id="2BV0-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', justifyContent: 'space-between' }}>
                  <div id="2BV2-0" style={{ boxSizing: 'border-box', display: 'flex', gap: '16px' }}>
                    <div id="2BV6-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '6px' }}>
                      <div id="2BV8-0" style={{ backgroundColor: 'var(--mx-dark-ser-1)', borderRadius: '2px', boxSizing: 'border-box', flexShrink: 0, height: '10px', width: '10px' }} />
                      <div id="2BV7-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                        At ask
                      </div>
                    </div>
                    <div id="2BV3-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '6px' }}>
                      <div id="2BV5-0" style={{ backgroundColor: 'var(--mx-dark-line)', borderRadius: '2px', boxSizing: 'border-box', flexShrink: 0, height: '10px', width: '10px' }} />
                      <div id="2BV4-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                        Quote-unclassified
                      </div>
                    </div>
                  </div>
                  <div id="2BV1-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    Timing alone does not establish intent.
                  </div>
                </div>
              </div>
            </div>
            <div id="2BU3-0" style={{ backgroundColor: 'var(--mx-dark-panel)', borderColor: 'var(--mx-dark-line)', borderRadius: '14px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, minWidth: '0px', overflow: 'clip', width: '320px' }}>
              <div id="2BUT-0" style={{ alignItems: 'center', borderBottomColor: 'var(--mx-dark-line)', borderBottomStyle: 'solid', borderBottomWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '4px', padding: '12px' }}>
                <div id="2BUW-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-text)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', flexBasis: '0%', flexGrow: '1', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
                  <div id="2BUX-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-bg)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                    Inspect
                  </div>
                </div>
                <div id="2BUU-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', flexBasis: '0%', flexGrow: '1', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
                  <div id="2BUV-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                    Case
                  </div>
                </div>
              </div>
              <div id="2BU9-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px', padding: '20px' }}>
                <div id="2BUS-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
                  SELECTED OBSERVATION
                </div>
                <div id="2BUR-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
                  SPY · 600 Call
                </div>
                <div id="2BUQ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                  20 Nov 2026 · 6 coalesced prints
                </div>
                <div id="2BUM-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '4px' }}>
                  <div id="2BUP-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
                    Reported premium
                  </div>
                  <div id="2BUO-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '28px', fontWeight: 600, lineHeight: '145%' }}>
                    $224,000
                  </div>
                  <div id="2BUN-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    400 contracts · 10:17:50–10:18:42 ET
                  </div>
                </div>
                <div id="2BUL-0" style={{ backgroundColor: 'var(--mx-dark-line)', boxSizing: 'border-box', flexShrink: 0, height: '1px', width: '100%' }} />
                <div id="2BUE-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  <div id="2BUK-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '13px', fontWeight: 600, lineHeight: '145%' }}>
                    At ask
                  </div>
                  <div id="2BUH-0" style={{ boxSizing: 'border-box', display: 'flex', flexShrink: 0, gap: '3px', height: '8px' }}>
                    <div id="2BUJ-0" style={{ backgroundColor: 'var(--mx-dark-ser-1)', borderRadius: '4px', boxSizing: 'border-box', height: '8px', width: 'round(75%, 1px)' }} />
                    <div id="2BUI-0" style={{ backgroundColor: 'var(--mx-dark-line)', borderRadius: '4px', boxSizing: 'border-box', flexBasis: '0%', flexGrow: '1', height: '8px' }} />
                  </div>
                  <div id="2BUG-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    300 contracts at ask · 100 unclassified
                  </div>
                  <div id="2BUF-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    Trade intent and package are unknown.
                  </div>
                </div>
                <div id="2BUC-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
                  <div id="2BUD-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                    Inspect 6 source prints
                  </div>
                </div>
                <div id="2BUA-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
                  <div id="2BUB-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                    Source &amp; corrections
                  </div>
                </div>
              </div>
              <div id="2BU4-0" style={{ borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '10px', padding: '20px' }}>
                <div id="2BU7-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-text)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
                  <div id="2BU8-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-bg)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                    Open exposure →
                  </div>
                </div>
                <div id="2BU6-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%' }}>
                  Independent SPY book · Nov 6
                </div>
                <div id="2BU5-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                  Root context carries forward. Original print selection is kept for your return.
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
