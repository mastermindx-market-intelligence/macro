(
    <div id="2AQC-0" style={{ backgroundColor: 'var(--mx-dark-bg)', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', fontSize: '12px', fontSynthesis: 'none', height: 'fit-content', lineHeight: '16px', MozOsxFontSmoothing: 'grayscale', overflowWrap: 'anywhere', WebkitFontSmoothing: 'antialiased', width: '820px' }}>
      <div id="2AQE-0" style={{ alignItems: 'center', borderBottomColor: 'var(--mx-dark-line)', borderBottomStyle: 'solid', borderBottomWidth: '1px', boxSizing: 'border-box', display: 'flex', flexShrink: 0, height: '64px', justifyContent: 'space-between', paddingInline: '24px' }}>
        <div id="2BT7-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', flexShrink: '0', justifyContent: 'center', minHeight: '44px', width: '44px' }}>
          <svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" id="2BT8-0" style={{ display: 'inline-block', flexShrink: 0 }}>
            <path d="M3 5h14M3 10h14M3 15h14" fill="none" stroke="#D7DCE3" strokeWidth="1.8" strokeLinecap="round" />
          </svg>
        </div>
        <div id="2AQH-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-Bold", "Inter", system-ui, sans-serif', fontSize: '15px', fontWeight: 700, lineHeight: '145%' }}>
          M / X
        </div>
        <div id="2AQI-0" style={{ alignItems: 'center', borderColor: 'var(--mx-dark-line)', borderRadius: '8px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexShrink: 0, minHeight: '36px', paddingInline: '12px', width: '280px' }}>
          <div id="2AQJ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
            搜索公司与工具
          </div>
        </div>
        <div id="2AQK-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
          ZH · 深色
        </div>
      </div>
      <div id="2AQM-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '20px', padding: '24px', width: '820px' }}>
        <div id="2AQO-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', justifyContent: 'space-between', minHeight: '40px', width: '100%' }}>
          <div id="2AQP-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '4px' }}>
            <div id="2AQQ-0" style={{ alignItems: 'center', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
              <div id="2AQR-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '16px', whiteSpace: 'pre' }}>
                概览
              </div>
            </div>
            <div id="2AQS-0" style={{ alignItems: 'center', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
              <div id="2AQT-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '16px', whiteSpace: 'pre' }}>
                资金流
              </div>
            </div>
            <div id="2AQU-0" style={{ alignItems: 'center', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
              <div id="2AQV-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '16px', whiteSpace: 'pre' }}>
                敞口
              </div>
            </div>
            <div id="2AQW-0" style={{ alignItems: 'center', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
              <div id="2AQX-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '16px', whiteSpace: 'pre' }}>
                波动率
              </div>
            </div>
            <div id="2AQY-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
              <div id="2AQZ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                研究
              </div>
            </div>
            <div id="2AR0-0" style={{ alignItems: 'center', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
              <div id="2AR1-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '16px', whiteSpace: 'pre' }}>
                计划与复盘
              </div>
            </div>
          </div>
          <div id="2AR2-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
            <div id="2AR3-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
              SPY · 更换标的
            </div>
          </div>
        </div>
        <div id="2AR5-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '8px' }}>
          <div id="2AR6-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-warn)', fontFamily: '"PingFangSC-Medium", "PingFang SC", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, lineHeight: '145%' }}>
            设计示例 · 合成数据
          </div>
          <div id="2AR7-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '28px', fontWeight: 600, lineHeight: '145%' }}>
            研究实验室
          </div>
          <div id="2AR8-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
            同一数据，多种视图；精确表格始终可用。
          </div>
        </div>
        <div id="2ARA-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', justifyContent: 'space-between' }}>
          <div id="2ARB-0" style={{ boxSizing: 'border-box', display: 'flex', gap: '8px' }}>
            <div id="2ARC-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="2ARD-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                SPY · 11月6日期权簿
              </div>
            </div>
            <div id="2ARE-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="2ARF-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                11月20日到期
              </div>
            </div>
          </div>
          <div id="2ARG-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
            <div id="2ARH-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
              来源与单位
            </div>
          </div>
        </div>
        <div id="2ARJ-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', justifyContent: 'space-between' }}>
          <div id="2ARK-0" style={{ boxSizing: 'border-box', display: 'flex', gap: '4px' }}>
            <div id="2ARL-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-text)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="2ARM-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-bg)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                精确表格
              </div>
            </div>
            <div id="2ARN-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="2ARO-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                二维矩阵
              </div>
            </div>
            <div id="2ARP-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="2ARQ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                三维视图
              </div>
            </div>
          </div>
          <div id="2ARR-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
            6项中有5项可用
          </div>
        </div>
        <div id="2ART-0" style={{ backgroundColor: 'var(--mx-dark-panel)', borderColor: 'var(--mx-dark-line)', borderRadius: '14px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', minHeight: '0px', overflow: 'clip' }}>
          <div id="2ARV-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel)', boxSizing: 'border-box', display: 'flex', minHeight: '52px', paddingBlock: '12px', paddingInline: '20px' }}>
            <div id="2ARW-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: 0, fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%', width: '280px' }}>
              合约
            </div>
            <div id="2ARX-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: 0, fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%', width: '225px' }}>
              敞口 / 1%
            </div>
            <div id="2ARY-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: 0, fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%', width: '225px' }}>
              数据状态
            </div>
          </div>
          <div id="2AS0-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel)', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', minHeight: '52px', paddingBlock: '12px', paddingInline: '20px' }}>
            <div id="2AS1-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: 0, fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '15px', lineHeight: '145%', width: '280px' }}>
              590 看涨
            </div>
            <div id="2AS2-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: 0, fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '15px', lineHeight: '145%', width: '225px' }}>
              +40m
            </div>
            <div id="2AS3-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: 0, fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '15px', lineHeight: '145%', width: '225px' }}>
              可用
            </div>
          </div>
          <div id="2AS5-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel)', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', minHeight: '52px', paddingBlock: '12px', paddingInline: '20px' }}>
            <div id="2AS6-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: 0, fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '15px', lineHeight: '145%', width: '280px' }}>
              590 看跌
            </div>
            <div id="2AS7-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: 0, fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '15px', lineHeight: '145%', width: '225px' }}>
              −30m
            </div>
            <div id="2AS8-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: 0, fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '15px', lineHeight: '145%', width: '225px' }}>
              可用
            </div>
          </div>
          <div id="2ASA-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', minHeight: '52px', paddingBlock: '12px', paddingInline: '20px' }}>
            <div id="2ASB-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: 0, fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '15px', fontWeight: 600, lineHeight: '145%', width: '280px' }}>
              600 看涨
            </div>
            <div id="2ASC-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: 0, fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '15px', fontWeight: 600, lineHeight: '145%', width: '225px' }}>
              +180m
            </div>
            <div id="2ASD-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: 0, fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '15px', fontWeight: 600, lineHeight: '145%', width: '225px' }}>
              已选 · 可用
            </div>
          </div>
          <div id="2ASF-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel)', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', minHeight: '52px', paddingBlock: '12px', paddingInline: '20px' }}>
            <div id="2ASG-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: 0, fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '15px', lineHeight: '145%', width: '280px' }}>
              600 看跌
            </div>
            <div id="2ASH-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: 0, fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '15px', lineHeight: '145%', width: '225px' }}>
              −70m
            </div>
            <div id="2ASI-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: 0, fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '15px', lineHeight: '145%', width: '225px' }}>
              可用
            </div>
          </div>
          <div id="2ASK-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel)', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', minHeight: '52px', paddingBlock: '12px', paddingInline: '20px' }}>
            <div id="2ASL-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: 0, fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '15px', lineHeight: '145%', width: '280px' }}>
              610 看涨
            </div>
            <div id="2ASM-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: 0, fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '15px', lineHeight: '145%', width: '225px' }}>
              +80m
            </div>
            <div id="2ASN-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: 0, fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '15px', lineHeight: '145%', width: '225px' }}>
              可用
            </div>
          </div>
          <div id="2ASP-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel)', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', minHeight: '52px', paddingBlock: '12px', paddingInline: '20px' }}>
            <div id="2ASQ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: 0, fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '15px', lineHeight: '145%', width: '280px' }}>
              610 看跌
            </div>
            <div id="2ASR-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: 0, fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '15px', lineHeight: '145%', width: '225px' }}>
              未知
            </div>
            <div id="2ASS-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: 0, fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '15px', lineHeight: '145%', width: '225px' }}>
              不计入已知小计
            </div>
          </div>
        </div>
        <div id="2ASU-0" style={{ backgroundColor: 'var(--mx-dark-panel)', borderColor: 'var(--mx-dark-line)', borderRadius: '14px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '14px', padding: '20px' }}>
          <div id="2ASV-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', justifyContent: 'space-between' }}>
            <div id="2ASW-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
              600 看涨 · 11月20日
            </div>
            <div id="2ASX-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '28px', fontWeight: 600, lineHeight: '145%' }}>
              +$180m / 1%
            </div>
          </div>
          <div id="2ASY-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
            模型 Gamma 敞口，单位为美元 / 标的价格上涨 1%。
          </div>
          <div id="2ASZ-0" style={{ backgroundColor: 'var(--mx-dark-line)', boxSizing: 'border-box', flexShrink: 0, height: '1px', width: '100%' }} />
          <div id="2AT0-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"PingFangSC-Medium", "PingFang SC", system-ui, sans-serif', fontSize: '14px', fontWeight: 500, lineHeight: '145%' }}>
            切换视图会保留所选合约、来源时间、单位与缺失值。
          </div>
          <div id="2AT1-0" style={{ boxSizing: 'border-box', display: 'flex', gap: '8px' }}>
            <div id="2AT2-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-text)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="2AT3-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-bg)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                查看合约证据
              </div>
            </div>
            <div id="2AT4-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="2AT5-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                比较同口径数据
              </div>
            </div>
            <div id="2AT6-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="2AT7-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"PingFangSC-Semibold", "PingFang SC", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                打开敞口工作区
              </div>
            </div>
          </div>
        </div>
        <div id="2AT9-0" style={{ backgroundColor: 'var(--mx-dark-panel2)', borderColor: 'var(--mx-dark-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', paddingBlock: '16px', paddingInline: '20px' }}>
          <div id="2ATA-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"PingFangSC-Regular", "PingFang SC", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
            基于持仓符号假设，不能视为做市商实际库存。缺失值不会变为零。
          </div>
        </div>
      </div>
    </div>
  )
