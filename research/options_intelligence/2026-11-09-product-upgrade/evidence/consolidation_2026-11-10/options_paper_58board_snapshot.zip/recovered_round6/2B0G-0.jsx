(
    <div id="2B0G-0" style={{ backgroundColor: 'var(--mx-light-bg)', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', fontSynthesis: 'none', gap: '24px', height: 'fit-content', MozOsxFontSmoothing: 'grayscale', overflowWrap: 'anywhere', padding: '32px', WebkitFontSmoothing: 'antialiased', width: '1440px' }}>
      <div id="2B0I-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '8px' }}>
        <div id="2B0J-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
          OPTIONS R3 · DESIGN CONTRACT
        </div>
        <div id="2B0K-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '28px', fontWeight: 600, lineHeight: '145%' }}>
          Watch, delivery &amp; return
        </div>
        <div id="2B0L-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
          Condition, delivery, assessment and source availability remain separate.
        </div>
      </div>
      <div id="2B0N-0" style={{ boxSizing: 'border-box', display: 'flex', gap: '24px', width: '1376px' }}>
        <div id="2B0P-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', justifyContent: 'space-between', minHeight: '286px', padding: '20px', width: '326px' }}>
          <div id="2B0Q-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div id="2B0R-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
              W01
            </div>
            <div id="2B0S-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
              Watch not armed
            </div>
            <div id="2B0T-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
              Review the exact sampled price condition before arming.
            </div>
            <div id="2B0U-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
              Build note · Save and arm are separate existing commands.
            </div>
          </div>
          <div id="2B0V-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <div id="2B0W-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="2B0X-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                Review condition
              </div>
            </div>
          </div>
        </div>
        <div id="2B0Z-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', justifyContent: 'space-between', minHeight: '286px', padding: '20px', width: '326px' }}>
          <div id="2B10-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div id="2B11-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
              W02
            </div>
            <div id="2B12-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
              Arming watch
            </div>
            <div id="2B13-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
              The arm request is being processed.
            </div>
            <div id="2B14-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
              Build note · Do not show Armed before the owner confirms it.
            </div>
          </div>
          <div id="2B15-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <div id="2B16-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px' }}>
              <div id="2B17-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                Arming…
              </div>
            </div>
          </div>
        </div>
        <div id="2B19-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', justifyContent: 'space-between', minHeight: '286px', padding: '20px', width: '326px' }}>
          <div id="2B1A-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div id="2B1B-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
              W03
            </div>
            <div id="2B1C-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
              Watch armed
            </div>
            <div id="2BGE-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
              SPY above $605 · one shot. Equality does not fire. Sampling can miss moves between checks.
            </div>
            <div id="2B1E-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
              Build note · Current ordinary condition has no end-date field here. Configured cadence is not a runtime SLA; preserve the incumbent evaluator.
            </div>
          </div>
          <div id="2B1F-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <div id="2B1G-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="2B1H-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                Manage watch
              </div>
            </div>
          </div>
        </div>
        <div id="2B1J-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', justifyContent: 'space-between', minHeight: '286px', padding: '20px', width: '326px' }}>
          <div id="2B1K-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div id="2B1L-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
              W04
            </div>
            <div id="2B1M-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
              Price condition met
            </div>
            <div id="2B1N-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
              Firing value $605.10. The research assessment is still open.
            </div>
            <div id="2B1O-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
              Build note · Bind the exact selected firing when an event ID exists.
            </div>
          </div>
          <div id="2B1P-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <div id="2B1Q-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-text)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="2B1R-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-bg)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                Review case
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="2B1T-0" style={{ boxSizing: 'border-box', display: 'flex', gap: '24px', width: '1376px' }}>
        <div id="2B1V-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', justifyContent: 'space-between', minHeight: '286px', padding: '20px', width: '326px' }}>
          <div id="2B1W-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div id="2B1X-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
              W05
            </div>
            <div id="2B1Y-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
              Delivery pending
            </div>
            <div id="2B1Z-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
              A firing is recorded. Notification delivery is pending.
            </div>
            <div id="2B20-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
              Build note · Matching outbox row: pending; delivered_at is null.
            </div>
          </div>
          <div id="2B21-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <div id="2B22-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="2B23-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                Delivery receipt history
              </div>
            </div>
          </div>
        </div>
        <div id="2B25-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', justifyContent: 'space-between', minHeight: '286px', padding: '20px', width: '326px' }}>
          <div id="2B26-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div id="2B27-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
              W06
            </div>
            <div id="2BGG-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
              Firing history unavailable
            </div>
            <div id="2BGI-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
              The trigger stamp is visible, but the firing receipt history cannot be read.
            </div>
            <div id="2B2A-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
              Build note · Fallback fire_event_id is null; do not claim exact-event binding.
            </div>
          </div>
          <div id="2B2B-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <div id="2BGK-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="2BGL-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                View available firing details
              </div>
            </div>
          </div>
        </div>
        <div id="2B2F-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', justifyContent: 'space-between', minHeight: '286px', padding: '20px', width: '326px' }}>
          <div id="2B2G-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div id="2B2H-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
              W07
            </div>
            <div id="2B2I-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
              No firing recorded
            </div>
            <div id="2B2J-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
              No firing appears in this readable recent window.
            </div>
            <div id="2B2K-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
              Build note · An empty result differs from an unreadable history.
            </div>
          </div>
          <div id="2B2L-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <div id="2B2M-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="2B2N-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                Open watch condition
              </div>
            </div>
          </div>
        </div>
        <div id="2B2P-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', justifyContent: 'space-between', minHeight: '286px', padding: '20px', width: '326px' }}>
          <div id="2B2Q-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div id="2B2R-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
              W08
            </div>
            <div id="2B2S-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
              Watch disarmed
            </div>
            <div id="2B2T-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
              The one-shot condition fired and is no longer armed.
            </div>
            <div id="2B2U-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
              Build note · Ordinary watch does not inherit an authored case deadline. Do not promise an unsupported expiry or consent field.
            </div>
          </div>
          <div id="2B2V-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <div id="2B2W-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="2B2X-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                Review watch condition
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="2B2Z-0" style={{ boxSizing: 'border-box', display: 'flex', gap: '24px', width: '1376px' }}>
        <div id="2B31-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', justifyContent: 'space-between', minHeight: '286px', padding: '20px', width: '326px' }}>
          <div id="2B32-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div id="2B33-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
              W09
            </div>
            <div id="2B34-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
              A later firing exists
            </div>
            <div id="2B35-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
              You are reviewing an earlier firing. Keep it selected or switch explicitly.
            </div>
            <div id="2B36-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
              Build note · Freeze selected event identity for the assessment revision.
            </div>
          </div>
          <div id="2B37-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <div id="2B38-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="2B39-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                View later firing
              </div>
            </div>
            <div id="2B3A-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="2B3B-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                Keep this firing
              </div>
            </div>
          </div>
        </div>
        <div id="2B3D-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', justifyContent: 'space-between', minHeight: '286px', padding: '20px', width: '326px' }}>
          <div id="2B3E-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div id="2B3F-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
              W10
            </div>
            <div id="2B3G-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
              Evaluation unavailable
            </div>
            <div id="2B3H-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
              The saved condition is visible. Evaluation cannot currently be confirmed.
            </div>
            <div id="2B3I-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
              Build note · Never infer a working evaluator from a saved condition alone.
            </div>
          </div>
          <div id="2B3J-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <div id="2B3K-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="2B3L-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                View watch status
              </div>
            </div>
          </div>
        </div>
        <div id="2B3N-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', justifyContent: 'space-between', minHeight: '286px', padding: '20px', width: '326px' }}>
          <div id="2B3O-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div id="2B3P-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
              W11
            </div>
            <div id="2B3Q-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
              No active saved case
            </div>
            <div id="2B3R-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
              This Flow group is not part of a saved investigation.
            </div>
            <div id="2B3S-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
              Build note · Do not imply unsupported print or Volatility capture.
            </div>
          </div>
          <div id="2B3T-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <div id="2B3U-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="2B3V-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                Open Exposure investigation
              </div>
            </div>
          </div>
        </div>
        <div id="2B3X-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', justifyContent: 'space-between', minHeight: '286px', padding: '20px', width: '326px' }}>
          <div id="2B3Y-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div id="2B3Z-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
              W12
            </div>
            <div id="2B40-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
              Later observations available
            </div>
            <div id="2B41-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
              Keep the 10:20 snapshot, or explicitly open the latest activity.
            </div>
            <div id="2B42-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
              Build note · Changing temporal mode preserves the original return context.
            </div>
          </div>
          <div id="2B43-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <div id="2B44-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="2B45-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                View latest
              </div>
            </div>
            <div id="2B46-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="2B47-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                Keep snapshot
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
