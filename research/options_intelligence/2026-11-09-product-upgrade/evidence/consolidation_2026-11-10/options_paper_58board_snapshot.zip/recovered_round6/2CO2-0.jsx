(
    <div id="2CO2-0" style={{ backgroundColor: 'var(--mx-dark-bg)', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', fontSynthesis: 'none', MozOsxFontSmoothing: 'grayscale', overflowWrap: 'anywhere', WebkitFontSmoothing: 'antialiased' }}>
      <div id="2CR9-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-bg)', borderBottomColor: 'var(--mx-dark-line)', borderBottomStyle: 'solid', borderBottomWidth: '1px', boxSizing: 'border-box', display: 'flex', flexShrink: 0, height: '64px', justifyContent: 'space-between', paddingInline: '24px', width: '1440px' }}>
        <div id="2CRJ-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', flexShrink: 0, gap: '12px', width: '176px' }}>
          <div id="2CRL-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-Bold", "Inter", system-ui, sans-serif', fontSize: '15px', fontWeight: 700, lineHeight: '145%' }}>
            M / X
          </div>
          <div id="2CRK-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '10px', fontWeight: 600, lineHeight: '145%' }}>
            MASTERMIND
          </div>
        </div>
        <div id="2CRG-0" style={{ alignItems: 'center', borderColor: 'var(--mx-dark-line)', borderRadius: '8px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexShrink: 0, height: '36px', justifyContent: 'space-between', paddingInline: '14px', width: '380px' }}>
          <div id="2CRI-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
            Search companies and tools
          </div>
          <div id="2CRH-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12px', lineHeight: '145%' }}>
            ⌘ K
          </div>
        </div>
        <div id="2CRA-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', flexBasis: '0%', flexGrow: '1', gap: '24px', justifyContent: 'end', paddingLeft: '24px' }}>
          <div id="2CRF-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-warn)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 500, lineHeight: '145%' }}>
            Design example · synthetic data
          </div>
          <div id="2CRE-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
            All tools
          </div>
          <div id="2CRD-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
            EN · Dark
          </div>
          <div id="2CRB-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '999px', boxSizing: 'border-box', display: 'flex', flexShrink: 0, height: '32px', justifyContent: 'center', width: '32px' }}>
            <div id="2CRC-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12px', lineHeight: '16px' }}>
              R
            </div>
          </div>
        </div>
      </div>
      <div id="2CO3-0" style={{ boxSizing: 'border-box', display: 'flex', minHeight: '896px', width: '1440px' }}>
        <div id="2CQQ-0" style={{ backgroundColor: 'var(--mx-dark-bg)', borderRightColor: 'var(--mx-dark-line)', borderRightStyle: 'solid', borderRightWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '8px', minHeight: '896px', paddingBlock: '24px', paddingInline: '16px', width: '224px' }}>
          <div id="2CR7-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '12px' }}>
            <div id="2CR8-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '18px' }}>
              Today
            </div>
          </div>
          <div id="2CR5-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '12px' }}>
            <div id="2CR6-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '18px' }}>
              Discover
            </div>
          </div>
          <div id="2CR3-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '12px' }}>
            <div id="2CR4-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '18px' }}>
              Analysis
            </div>
          </div>
          <div id="2CR1-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '12px' }}>
            <div id="2CR2-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '18px' }}>
              Monitor
            </div>
          </div>
          <div id="2CQZ-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '12px' }}>
            <div id="2CR0-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '18px' }}>
              Research
            </div>
          </div>
          <div id="2CQX-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '12px' }}>
            <div id="2CQY-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '18px' }}>
              Portfolio
            </div>
          </div>
          <div id="2CQV-0" style={{ boxSizing: 'border-box', paddingBottom: '8px', paddingInline: '12px', paddingTop: '28px' }}>
            <div id="2CQW-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '11px', letterSpacing: '0.08em', lineHeight: '14px' }}>
              WORKSPACES
            </div>
          </div>
          <div id="2CQT-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '12px' }}>
            <div id="2CQU-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '18px' }}>
              Options
            </div>
          </div>
          <div id="2CQR-0" style={{ boxSizing: 'border-box', paddingInline: '12px' }}>
            <div id="2CQS-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
              United States · USD
            </div>
          </div>
        </div>
        <div id="2CO4-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', padding: '24px', width: '1216px' }}>
          <div id="2CQA-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', justifyContent: 'space-between', minHeight: '40px', width: '100%' }}>
            <div id="2CQD-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '4px' }}>
              <div id="2CQO-0" style={{ alignItems: 'center', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
                <div id="2CQP-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '16px', whiteSpace: 'pre' }}>
                  Overview
                </div>
              </div>
              <div id="2CQM-0" style={{ alignItems: 'center', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
                <div id="2CQN-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '16px', whiteSpace: 'pre' }}>
                  Flow
                </div>
              </div>
              <div id="2CQK-0" style={{ alignItems: 'center', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
                <div id="2CQL-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '16px', whiteSpace: 'pre' }}>
                  Exposure
                </div>
              </div>
              <div id="2CQI-0" style={{ alignItems: 'center', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
                <div id="2CQJ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '16px', whiteSpace: 'pre' }}>
                  Volatility
                </div>
              </div>
              <div id="2CQG-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
                <div id="2CQH-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                  Research
                </div>
              </div>
              <div id="2CQE-0" style={{ alignItems: 'center', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
                <div id="2CQF-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '16px', whiteSpace: 'pre' }}>
                  Plans &amp; review
                </div>
              </div>
            </div>
            <div id="2CQB-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="2CQC-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                SPY · Change
              </div>
            </div>
          </div>
          <div id="2CQ3-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', justifyContent: 'space-between', minHeight: '76px', width: '100%' }}>
            <div id="2CQ7-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '6px' }}>
              <div id="2CQ9-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '28px', fontWeight: 600, lineHeight: '145%' }}>
                Specialist tools
              </div>
              <div id="2CQ8-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
                Choose a task and keep your investigation context.
              </div>
            </div>
            <div id="2CQ4-0" style={{ alignItems: 'end', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '6px' }}>
              <div id="2CQ6-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 500, lineHeight: '145%' }}>
                Research session · 09 Nov 2026
              </div>
              <div id="2CQ5-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                Research status · source-specific cutoffs
              </div>
            </div>
          </div>
          <div id="2CPS-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '4px' }}>
            <div id="2CQ1-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-text)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="2CQ2-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-bg)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                All tools
              </div>
            </div>
            <div id="2CPZ-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="2CQ0-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                Flow
              </div>
            </div>
            <div id="2CPX-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="2CPY-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                Exposure
              </div>
            </div>
            <div id="2CPV-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="2CPW-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                Lab
              </div>
            </div>
            <div id="2CPT-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="2CPU-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                Research
              </div>
            </div>
          </div>
          <div id="2CO5-0" style={{ alignItems: 'start', boxSizing: 'border-box', display: 'flex', gap: '24px' }}>
            <div id="2CON-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', width: '824px' }}>
              <div id="2CUI-0" style={{ backgroundColor: 'var(--mx-dark-panel)', borderColor: 'var(--mx-dark-line)', borderRadius: '14px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '16px', padding: '20px', width: '824px' }}>
                <div id="2CUJ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-Bold", "Inter", system-ui, sans-serif', fontSize: '17px', fontWeight: 700, lineHeight: '145%' }}>
                  Flow investigations
                </div>
                <div id="2CUK-0" style={{ alignItems: 'center', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '16px', paddingBlock: '12px' }}>
                  <div id="2CUL-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
                    Tape
                  </div>
                  <div id="2CUM-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexBasis: '0%', flexGrow: '1', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    Inspect reported aggregate events
                  </div>
                  <div id="2CUN-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-link)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    Open →
                  </div>
                </div>
                <div id="2CUO-0" style={{ alignItems: 'center', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '16px', paddingBlock: '12px' }}>
                  <div id="2CUP-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
                    Largest
                  </div>
                  <div id="2CUQ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexBasis: '0%', flexGrow: '1', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    Find the largest reported premiums
                  </div>
                  <div id="2CUR-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-link)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    Open →
                  </div>
                </div>
                <div id="2CUS-0" style={{ alignItems: 'center', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '16px', paddingBlock: '12px' }}>
                  <div id="2CUT-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
                    Unusual
                  </div>
                  <div id="2CUU-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexBasis: '0%', flexGrow: '1', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    Inspect unusual activity and its baseline
                  </div>
                  <div id="2CUV-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-link)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    Open →
                  </div>
                </div>
                <div id="2CUW-0" style={{ alignItems: 'center', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '16px', paddingBlock: '12px' }}>
                  <div id="2CUX-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
                    0DTE
                  </div>
                  <div id="2CUY-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexBasis: '0%', flexGrow: '1', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    Focus on contracts expiring today
                  </div>
                  <div id="2CUZ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-link)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    Open →
                  </div>
                </div>
                <div id="2CV0-0" style={{ alignItems: 'center', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '16px', paddingBlock: '12px' }}>
                  <div id="2CV1-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
                    OI changes
                  </div>
                  <div id="2CV2-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexBasis: '0%', flexGrow: '1', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    Compare open interest across publication dates
                  </div>
                  <div id="2CV3-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-link)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    Open →
                  </div>
                </div>
                <div id="2CV4-0" style={{ alignItems: 'center', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '16px', paddingBlock: '12px' }}>
                  <div id="2CV5-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
                    Tide
                  </div>
                  <div id="2CV6-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexBasis: '0%', flexGrow: '1', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    Inspect an intraday series and its population
                  </div>
                  <div id="2CV7-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-link)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    Open →
                  </div>
                </div>
                <div id="2CV8-0" style={{ alignItems: 'center', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '16px', paddingBlock: '12px' }}>
                  <div id="2CV9-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
                    Flow Surface
                  </div>
                  <div id="2CVA-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexBasis: '0%', flexGrow: '1', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    Explore flow over strike and session time
                  </div>
                  <div id="2CVB-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-link)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    Open →
                  </div>
                </div>
                <div id="2CVC-0" style={{ alignItems: 'center', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '16px', paddingBlock: '12px' }}>
                  <div id="2CVD-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
                    Screener
                  </div>
                  <div id="2CVE-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexBasis: '0%', flexGrow: '1', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    Filter eligible contracts and build a shortlist
                  </div>
                  <div id="2CVF-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-link)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    Open →
                  </div>
                </div>
                <div id="2CVG-0" style={{ alignItems: 'center', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '16px', paddingBlock: '12px' }}>
                  <div id="2CVH-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
                    Ticker scan
                  </div>
                  <div id="2CVI-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexBasis: '0%', flexGrow: '1', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    Compare activity across a defined universe
                  </div>
                  <div id="2CVJ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-link)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    Open →
                  </div>
                </div>
              </div>
              <div id="2CVL-0" style={{ backgroundColor: 'var(--mx-dark-panel)', borderColor: 'var(--mx-dark-line)', borderRadius: '14px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '16px', padding: '20px', width: '824px' }}>
                <div id="2CVM-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-Bold", "Inter", system-ui, sans-serif', fontSize: '17px', fontWeight: 700, lineHeight: '145%' }}>
                  Exposure &amp; sessions
                </div>
                <div id="2CVN-0" style={{ alignItems: 'center', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '16px', paddingBlock: '12px' }}>
                  <div id="2CVO-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
                    Discover
                  </div>
                  <div id="2CVP-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexBasis: '0%', flexGrow: '1', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    Find a contract or source-supported concentration
                  </div>
                  <div id="2CVQ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-link)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    Open →
                  </div>
                </div>
                <div id="2CVR-0" style={{ alignItems: 'center', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '16px', paddingBlock: '12px' }}>
                  <div id="2CVS-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
                    Compare
                  </div>
                  <div id="2CVT-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexBasis: '0%', flexGrow: '1', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    Inspect two qualified, dated books
                  </div>
                  <div id="2CVU-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-link)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    Open →
                  </div>
                </div>
                <div id="2CVV-0" style={{ alignItems: 'center', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '16px', paddingBlock: '12px' }}>
                  <div id="2CVW-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
                    Replay
                  </div>
                  <div id="2CVX-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexBasis: '0%', flexGrow: '1', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    Return to a retained source interval
                  </div>
                  <div id="2CVY-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-link)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    Open →
                  </div>
                </div>
                <div id="2CVZ-0" style={{ alignItems: 'center', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '16px', paddingBlock: '12px' }}>
                  <div id="2CW0-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
                    Session review
                  </div>
                  <div id="2CW1-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexBasis: '0%', flexGrow: '1', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    Review what changed across a complete session
                  </div>
                  <div id="2CW2-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-link)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    Open →
                  </div>
                </div>
                <div id="2EKQ-0" style={{ alignItems: 'center', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '16px', paddingBlock: '12px' }}>
                  <div id="2EKR-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
                    Quad
                  </div>
                  <div id="2EKS-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexBasis: '0%', flexGrow: '1', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    Inspect several roots without combining incompatible books
                  </div>
                  <div id="2EKT-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-link)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    Open →
                  </div>
                </div>
                <div id="2EKU-0" style={{ alignItems: 'center', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '16px', paddingBlock: '12px' }}>
                  <div id="2EKV-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
                    Positioning
                  </div>
                  <div id="2EKW-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexBasis: '0%', flexGrow: '1', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    Inspect the qualified positioning context
                  </div>
                  <div id="2EKX-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-link)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    Open →
                  </div>
                </div>
                <div id="2EKY-0" style={{ alignItems: 'center', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '16px', paddingBlock: '12px' }}>
                  <div id="2EKZ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
                    Levels
                  </div>
                  <div id="2EL0-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexBasis: '0%', flexGrow: '1', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    Study source-supported levels and their basis
                  </div>
                  <div id="2EL1-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-link)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    Open →
                  </div>
                </div>
                <div id="2EL2-0" style={{ alignItems: 'center', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '16px', paddingBlock: '12px' }}>
                  <div id="2EL3-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
                    Structure
                  </div>
                  <div id="2EL4-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexBasis: '0%', flexGrow: '1', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    Inspect exact contract structure and source limits
                  </div>
                  <div id="2EL5-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-link)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    Open →
                  </div>
                </div>
              </div>
              <div id="2CW4-0" style={{ backgroundColor: 'var(--mx-dark-panel)', borderColor: 'var(--mx-dark-line)', borderRadius: '14px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '16px', padding: '20px', width: '824px' }}>
                <div id="2CW5-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-Bold", "Inter", system-ui, sans-serif', fontSize: '17px', fontWeight: 700, lineHeight: '145%' }}>
                  Research Lab
                </div>
                <div id="2CW6-0" style={{ alignItems: 'center', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '16px', paddingBlock: '12px' }}>
                  <div id="2CW7-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
                    Chain Observatory
                  </div>
                  <div id="2CW8-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexBasis: '0%', flexGrow: '1', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    Inspect exact rows, units and missing values
                  </div>
                  <div id="2CW9-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-link)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    Open →
                  </div>
                </div>
                <div id="2CWA-0" style={{ alignItems: 'center', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '16px', paddingBlock: '12px' }}>
                  <div id="2CWB-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
                    Volatility Terrain
                  </div>
                  <div id="2CWC-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexBasis: '0%', flexGrow: '1', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    Study raw IV support and qualified surfaces
                  </div>
                  <div id="2CWD-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-link)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    Open →
                  </div>
                </div>
                <div id="2CWE-0" style={{ alignItems: 'center', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '16px', paddingBlock: '12px' }}>
                  <div id="2CWF-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
                    Replay and Change
                  </div>
                  <div id="2CWG-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexBasis: '0%', flexGrow: '1', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    Compare retained snapshots and corrections
                  </div>
                  <div id="2CWH-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-link)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    Open →
                  </div>
                </div>
                <div id="2CWI-0" style={{ alignItems: 'center', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '16px', paddingBlock: '12px' }}>
                  <div id="2CWJ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
                    Flow and Packages
                  </div>
                  <div id="2CWK-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexBasis: '0%', flexGrow: '1', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    Inspect available prints and actual package evidence
                  </div>
                  <div id="2CWL-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-link)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    Open →
                  </div>
                </div>
                <div id="2CWM-0" style={{ alignItems: 'center', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '16px', paddingBlock: '12px' }}>
                  <div id="2CWN-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%', width: '180px' }}>
                    Scenario Lab
                  </div>
                  <div id="2CWO-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexBasis: '0%', flexGrow: '1', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    Explore supported price, IV and time assumptions
                  </div>
                  <div id="2CWP-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-link)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    Open →
                  </div>
                </div>
                <div id="2CWQ-0" style={{ backgroundColor: 'var(--mx-dark-line)', boxSizing: 'border-box', flexShrink: 0, height: '1px', width: '100%' }} />
                <div id="2CWR-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '24px' }}>
                  <div id="2CWS-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-link)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    Macro Plans →
                  </div>
                  <div id="2CWT-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-link)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    Options Alpha →
                  </div>
                  <div id="2CWU-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-link)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    Issue Desk →
                  </div>
                  <div id="2CWV-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-link)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    Statistics →
                  </div>
                </div>
              </div>
            </div>
            <div id="2CWX-0" style={{ backgroundColor: 'var(--mx-dark-panel)', borderColor: 'var(--mx-dark-line)', borderRadius: '14px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: '0', gap: '16px', padding: '20px', width: '320px' }}>
              <div id="2CWY-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-Bold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 700, lineHeight: '145%' }}>
                Tool context
              </div>
              <div id="2CWZ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '17px', fontWeight: 600, lineHeight: '145%' }}>
                Chain Observatory
              </div>
              <div id="2CX0-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
                Inspect the source rows behind your selected view.
              </div>
              <div id="2CX1-0" style={{ backgroundColor: 'var(--mx-dark-line)', boxSizing: 'border-box', flexShrink: 0, height: '1px', width: '100%' }} />
              <div id="2CX2-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
                <div id="2CX3-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%' }}>
                  Keep my place
                </div>
                <div id="2CX4-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
                  SPY · 20 Nov · 600 Call
                </div>
                <div id="2CX5-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                  Return restores the selected row, filters and view.
                </div>
              </div>
              <div id="2CX6-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-text)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingBlock: '8px', paddingInline: '14px' }}>
                <div id="2CX7-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-bg)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px' }}>
                  Open selected lens →
                </div>
              </div>
              <div id="2CX8-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingBlock: '8px', paddingInline: '14px' }}>
                <div id="2CX9-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px' }}>
                  Back to Opportunities
                </div>
              </div>
              <div id="2CXA-0" style={{ backgroundColor: 'var(--mx-dark-line)', boxSizing: 'border-box', flexShrink: 0, height: '1px', width: '100%' }} />
              <div id="2CXB-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-Bold", "Inter", system-ui, sans-serif', fontSize: '17px', fontWeight: 700, lineHeight: '145%' }}>
                Source status
              </div>
              <div id="2CXC-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
                No source is loaded for this selection yet. Open the lens to inspect availability.
              </div>
              <div id="2CXD-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                Raw observations, fitted surfaces and scenario values each keep their own source basis.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
