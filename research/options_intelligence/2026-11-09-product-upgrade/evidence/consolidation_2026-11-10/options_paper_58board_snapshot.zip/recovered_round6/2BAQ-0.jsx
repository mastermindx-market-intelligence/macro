(
    <div id="2BAQ-0" style={{ backgroundColor: 'var(--mx-dark-bg)', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', fontSynthesis: 'none', gap: '24px', height: 'fit-content', MozOsxFontSmoothing: 'grayscale', overflowWrap: 'anywhere', padding: '32px', WebkitFontSmoothing: 'antialiased', width: '1440px' }}>
      <div id="2BAS-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '8px' }}>
        <div id="2BAT-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
          OPTIONS R6 · BUILD CONTRACT
        </div>
        <div id="2BAU-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '28px', fontWeight: 600, lineHeight: '145%' }}>
          Every visible claim has an owner
        </div>
        <div id="2BAV-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
          Round-5 source baseline: Terminal d15741d45240; Macro e1e4552be495. Round-6 design law: Macro b78a9e44a1fe. Design is not installed-source proof.
        </div>
      </div>
      <div id="2BAX-0" style={{ boxSizing: 'border-box', display: 'flex', gap: '24px', paddingInline: '20px' }}>
        <div id="2BAY-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: 0, fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12px', fontWeight: 600, lineHeight: '145%', width: '252px' }}>
          Capability / status
        </div>
        <div id="2BAZ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: 0, fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12px', fontWeight: 600, lineHeight: '145%', width: '340px' }}>
          Existing owner
        </div>
        <div id="2BB0-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: 0, fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12px', fontWeight: 600, lineHeight: '145%', width: '696px' }}>
          Build contract / necessary delta
        </div>
      </div>
      <div id="2BB2-0" style={{ backgroundColor: 'var(--mx-dark-panel)', borderColor: 'var(--mx-dark-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '24px', padding: '20px' }}>
        <div id="2BB3-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: '0', gap: '8px', width: '252px' }}>
          <div id="2BB4-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '18px', fontWeight: 600, lineHeight: '145%' }}>
            Flow detail
          </div>
          <div id="2BB5-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
            CURRENT · contract aggregate
          </div>
        </div>
        <div id="2BB6-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '340px' }}>
          FeedPane.FlowEvent; projectFlowPrint; existing useFlowStream / flowClientCache.
        </div>
        <div id="2BB7-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '696px' }}>
          O02 defaults to the aggregate. normalizeOptionsAlphaMeasuredFeed supplies qualified aggregate NBBO measures with pre-sign source and covered-premium denominators. Loaded/capped events are a third population. O02X’s older six-child specimen is an independent target fixture; do not join it to R6’s new aggregate-only coverage numbers. Per-print custody, package and correction lineage remain unavailable unless actually supplied.
        </div>
      </div>
      <div id="2BB9-0" style={{ backgroundColor: 'var(--mx-dark-panel)', borderColor: 'var(--mx-dark-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '24px', padding: '20px' }}>
        <div id="2BBA-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: '0', gap: '8px', width: '252px' }}>
          <div id="2BBB-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '18px', fontWeight: 600, lineHeight: '145%' }}>
            Exposure &amp; comparison
          </div>
          <div id="2BBC-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
            CURRENT · dated source books
          </div>
        </div>
        <div id="2BBD-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '340px' }}>
          Existing Exposure source and selection / comparison projectors.
        </div>
        <div id="2BBE-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '696px' }}>
          Dated provider Gamma only. Preserve nullable source spot and unavailable Vanna/Charm/joint scenarios. Matched change uses strictly increasing sessions and qualified rows. Qualification changes are separate from additions/removals. Full total stays unknown; root-only entry uses view=chart and explicit origin return.
        </div>
      </div>
      <div id="2BBG-0" style={{ backgroundColor: 'var(--mx-dark-panel)', borderColor: 'var(--mx-dark-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '24px', padding: '20px' }}>
        <div id="2BBH-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: '0', gap: '8px', width: '252px' }}>
          <div id="2BBI-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '18px', fontWeight: 600, lineHeight: '145%' }}>
            Volatility &amp; Lab
          </div>
          <div id="2BBJ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
            CURRENT · source-bound lenses
          </div>
        </div>
        <div id="2BBK-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '340px' }}>
          Existing Volatility / Research Lab owners and exact table alternatives.
        </div>
        <div id="2BBL-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '696px' }}>
          Expose actual tenor/method; strict-less empirical percentile is not range rank. Recent extrema use supplied observations, not an assumed 52 weeks. Published IV−RV +4.0 has unverified input alignment. Preserve exact expiry on absence. Lab wire v1 needs lossless schema-specific admission through the sole adapter; no blanket numeric cast or invented side rows.
        </div>
      </div>
      <div id="2BBN-0" style={{ backgroundColor: 'var(--mx-dark-panel)', borderColor: 'var(--mx-dark-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '24px', padding: '20px' }}>
        <div id="2BBO-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: '0', gap: '8px', width: '252px' }}>
          <div id="2BBP-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '18px', fontWeight: 600, lineHeight: '145%' }}>
            Research &amp; sleeves
          </div>
          <div id="2BBQ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
            CURRENT · claim-specific maturity
          </div>
        </div>
        <div id="2BBR-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '340px' }}>
          Strategy catalogue, Options Alpha formation, campaign and evaluation owners.
        </div>
        <div id="2BBS-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '696px' }}>
          Two Flow books are accruing with zero observed fires in this fixture; Options Alpha v2 remains inactive. Eight broader Prophet families are not eight live Options sleeves. Promotion requires the original research gates; no frontend confidence score.
        </div>
      </div>
      <div id="2BBU-0" style={{ backgroundColor: 'var(--mx-dark-panel)', borderColor: 'var(--mx-dark-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '24px', padding: '20px' }}>
        <div id="2BBV-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: '0', gap: '8px', width: '252px' }}>
          <div id="2BBW-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '18px', fontWeight: 600, lineHeight: '145%' }}>
            Exact Plan save
          </div>
          <div id="2BBX-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
            CURRENT · held integration
          </div>
        </div>
        <div id="2BBY-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '340px' }}>
          OptionsPlanInvestigationHost is preparation-only pending native admission and embedded history.
        </div>
        <div id="2BBZ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '696px' }}>
          B04: New research → Add detached whole Plan → native Save → new case revision 1. No existing Exposure-case Plan append is promised by #804. Preserve original #804/T03k/0030 holds and forward-compose 0047/0043. Scenario-v2 reference and whole-Plan-v3 are separate inputs. Unknown saves reconcile original operations; capture may precede case commit.
        </div>
      </div>
      <div id="2BC1-0" style={{ backgroundColor: 'var(--mx-dark-panel)', borderColor: 'var(--mx-dark-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '24px', padding: '20px' }}>
        <div id="2BC2-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: '0', gap: '8px', width: '252px' }}>
          <div id="2BC3-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '18px', fontWeight: 600, lineHeight: '145%' }}>
            Assessment revision
          </div>
          <div id="2BC4-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
            CURRENT · existing revision path
          </div>
        </div>
        <div id="2BC5-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '340px' }}>
          InvestigationReviewPanel → assessmentRevision → existing revise command.
        </div>
        <div id="2BC6-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '696px' }}>
          Explicit firing selection must be frozen before authoring. No default assessment; latest case revision and native expected-revision check apply. Note ≤2,000 code points. A later fire offers a separate switch. User assessment is not a canonical scored outcome; O12 keeps model, expiry, quote-rule and actual-fill results distinct.
        </div>
      </div>
      <div id="2BC8-0" style={{ backgroundColor: 'var(--mx-dark-panel)', borderColor: 'var(--mx-dark-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '24px', padding: '20px' }}>
        <div id="2BC9-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: '0', gap: '8px', width: '252px' }}>
          <div id="2BCA-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '18px', fontWeight: 600, lineHeight: '145%' }}>
            Watch &amp; delivery
          </div>
          <div id="2BCB-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
            CURRENT · evaluator and outbox
          </div>
        </div>
        <div id="2BCC-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '340px' }}>
          Existing price_touch / wall-proximity evaluator, alerts API and receipt owner. Creation-operation reconciliation is an owner extension.
        </div>
        <div id="2BCD-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', flexShrink: '0', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%', width: '696px' }}>
          Strict sampled above/below; equality does not fire. Wall proximity establishes prior then detects outside→inside. No ordinary expiry/quiet-hours/cooldown promise. Selected-node monitoring remains separately held. Pending delivery is distinct from firing. History is latest 200 user rows; absence from that window is inconclusive.
        </div>
      </div>
      <div id="2BCF-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '8px', padding: '20px' }}>
        <div id="2BCG-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '18px', fontWeight: 600, lineHeight: '145%' }}>
          Extend existing contracts; preserve existing owners.
        </div>
        <div id="2BCH-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
          No new collector, cache plane, case store, identity system, model-authority registry, watcher service or retry queue. Missing evidence stays missing. Production and scientific qualification remain separate acceptance decisions.
        </div>
      </div>
    </div>
  )
