(
    <div id="29BT-0" style={{ backgroundColor: 'var(--mx-light-bg)', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', fontSize: '12px', fontSynthesis: 'none', lineHeight: '16px', MozOsxFontSmoothing: 'grayscale', overflowWrap: 'anywhere', WebkitFontSmoothing: 'antialiased' }}>
      <div id="29BV-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-bg)', borderBottomColor: 'var(--mx-light-line)', borderBottomStyle: 'solid', borderBottomWidth: '1px', boxSizing: 'border-box', display: 'flex', flexShrink: 0, height: '64px', justifyContent: 'space-between', paddingInline: '24px', width: '1440px' }}>
        <div id="29BW-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', flexShrink: 0, gap: '12px', width: '176px' }}>
          <div id="29BX-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-Bold", "Inter", system-ui, sans-serif', fontSize: '15px', fontWeight: 700, lineHeight: '145%' }}>
            M / X
          </div>
          <div id="29BY-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '10px', fontWeight: 600, lineHeight: '145%' }}>
            MASTERMIND
          </div>
        </div>
        <div id="29BZ-0" style={{ alignItems: 'center', borderColor: 'var(--mx-light-line)', borderRadius: '8px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexShrink: 0, height: '36px', justifyContent: 'space-between', paddingInline: '14px', width: '380px' }}>
          <div id="29C0-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
            Search companies and tools
          </div>
          <div id="29C1-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12px', lineHeight: '145%' }}>
            ⌘ K
          </div>
        </div>
        <div id="29C2-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', flexBasis: '0%', flexGrow: '1', gap: '24px', justifyContent: 'end', paddingLeft: '24px' }}>
          <div id="29C3-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-warn)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 500, lineHeight: '145%' }}>
            Design example · synthetic data
          </div>
          <div id="29C4-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
            All tools
          </div>
          <div id="29C5-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
            EN · Light
          </div>
          <div id="29C6-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '999px', boxSizing: 'border-box', display: 'flex', flexShrink: 0, height: '32px', justifyContent: 'center', width: '32px' }}>
            <div id="29C7-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12px', lineHeight: '16px' }}>
              R
            </div>
          </div>
        </div>
      </div>
      <div id="29C9-0" style={{ boxSizing: 'border-box', display: 'flex', minHeight: '896px', width: '1440px' }}>
        <div id="29CA-0" style={{ backgroundColor: 'var(--mx-light-bg)', borderRightColor: 'var(--mx-light-line)', borderRightStyle: 'solid', borderRightWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '8px', minHeight: '896px', paddingBlock: '24px', paddingInline: '16px', width: '224px' }}>
          <div id="29CB-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '12px' }}>
            <div id="29CC-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '18px' }}>
              Today
            </div>
          </div>
          <div id="29CD-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '12px' }}>
            <div id="29CE-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '18px' }}>
              Discover
            </div>
          </div>
          <div id="29CF-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '12px' }}>
            <div id="29CG-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '18px' }}>
              Analysis
            </div>
          </div>
          <div id="29CH-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '12px' }}>
            <div id="29CI-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '18px' }}>
              Monitor
            </div>
          </div>
          <div id="29CJ-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '12px' }}>
            <div id="29CK-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '18px' }}>
              Research
            </div>
          </div>
          <div id="29CL-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '12px' }}>
            <div id="29CM-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '18px' }}>
              Portfolio
            </div>
          </div>
          <div id="29CN-0" style={{ boxSizing: 'border-box', paddingBottom: '8px', paddingInline: '12px', paddingTop: '28px' }}>
            <div id="29CO-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '11px', letterSpacing: '0.08em', lineHeight: '14px' }}>
              WORKSPACES
            </div>
          </div>
          <div id="29CP-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '12px' }}>
            <div id="29CQ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '18px' }}>
              Options
            </div>
          </div>
          <div id="29CR-0" style={{ boxSizing: 'border-box', paddingInline: '12px' }}>
            <div id="29CS-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
              United States · USD
            </div>
          </div>
        </div>
        <div id="29CT-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', padding: '24px', width: '1216px' }}>
          <div id="29CV-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', justifyContent: 'space-between', minHeight: '40px', width: '100%' }}>
            <div id="29CW-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '4px' }}>
              <div id="29CX-0" style={{ alignItems: 'center', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
                <div id="29CY-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '16px', whiteSpace: 'pre' }}>
                  Overview
                </div>
              </div>
              <div id="29CZ-0" style={{ alignItems: 'center', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
                <div id="29D0-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '16px', whiteSpace: 'pre' }}>
                  Flow
                </div>
              </div>
              <div id="29D1-0" style={{ alignItems: 'center', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
                <div id="29D2-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '16px', whiteSpace: 'pre' }}>
                  Exposure
                </div>
              </div>
              <div id="29D3-0" style={{ alignItems: 'center', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
                <div id="29D4-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '16px', whiteSpace: 'pre' }}>
                  Volatility
                </div>
              </div>
              <div id="29D5-0" style={{ alignItems: 'center', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
                <div id="29D6-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '16px', whiteSpace: 'pre' }}>
                  Research
                </div>
              </div>
              <div id="29D7-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
                <div id="29D8-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                  Plans &amp; review
                </div>
              </div>
            </div>
            <div id="29D9-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
              <div id="29DA-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                SPY · Change
              </div>
            </div>
          </div>
          <div id="29DC-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', justifyContent: 'space-between', minHeight: '76px', width: '100%' }}>
            <div id="29DD-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '6px' }}>
              <div id="29DE-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '28px', fontWeight: 600, lineHeight: '145%' }}>
                Plan
              </div>
              <div id="29DF-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
                Explore an expiry payoff from your authored assumptions.
              </div>
            </div>
            <div id="29DG-0" style={{ alignItems: 'end', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '6px' }}>
              <div id="29DH-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 500, lineHeight: '145%' }}>
                Research session · 09 Nov 2026
              </div>
              <div id="29DI-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                Draft · authored 09 Nov 10:25 ET
              </div>
            </div>
          </div>
          <div id="29DK-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', justifyContent: 'space-between' }}>
            <div id="29DL-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '12px' }}>
              <div id="29DM-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '17px', fontWeight: 600, lineHeight: '145%' }}>
                SPY · 600 / 610 call spread
              </div>
              <div id="29DN-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '999px', boxSizing: 'border-box', display: 'flex', paddingBlock: '6px', paddingInline: '10px' }}>
                <div id="29DO-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12px', lineHeight: '16px' }}>
                  Draft · authored assumptions
                </div>
              </div>
            </div>
            <div id="29DP-0" style={{ boxSizing: 'border-box', display: 'flex', gap: '8px' }}>
              <div id="29DQ-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
                <div id="29DR-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                  Compare
                </div>
              </div>
              <div id="29DS-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-text)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
                <div id="29DT-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-bg)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                  Recalculate
                </div>
              </div>
            </div>
          </div>
          <div id="29DV-0" style={{ alignItems: 'start', boxSizing: 'border-box', display: 'flex', gap: '24px' }}>
            <div id="29DW-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '20px', width: '824px' }}>
              <div id="29DZ-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '14px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '16px', padding: '20px' }}>
                <div id="29E1-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', justifyContent: 'space-between' }}>
                  <div id="29E2-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '17px', fontWeight: 600, lineHeight: '145%' }}>
                    Illustrative expiry payoff
                  </div>
                  <div id="2AC0-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    At expiry · before fees &amp; slippage
                  </div>
                </div>
                <div id="29E5-0" style={{ boxSizing: 'border-box', display: 'flex', justifyContent: 'space-between' }}>
                  <div id="29E6-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '4px' }}>
                    <div id="29E7-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
                      NET DEBIT
                    </div>
                    <div id="29E8-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '28px', fontWeight: 600, lineHeight: '145%' }}>
                      $320
                    </div>
                    <div id="29E9-0" style={{ boxSizing: 'border-box' }} />
                  </div>
                  <div id="29EA-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '4px' }}>
                    <div id="29EB-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
                      WORST EXPIRY P/L
                    </div>
                    <div id="29EC-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '28px', fontWeight: 600, lineHeight: '145%' }}>
                      −$320
                    </div>
                    <div id="29ED-0" style={{ boxSizing: 'border-box' }} />
                  </div>
                  <div id="29EE-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '4px' }}>
                    <div id="29EF-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
                      BEST EXPIRY P/L
                    </div>
                    <div id="29EG-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '28px', fontWeight: 600, lineHeight: '145%' }}>
                      +$680
                    </div>
                    <div id="29EH-0" style={{ boxSizing: 'border-box' }} />
                  </div>
                  <div id="29EI-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '4px' }}>
                    <div id="29EJ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
                      BREAKEVEN
                    </div>
                    <div id="29EK-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '28px', fontWeight: 600, lineHeight: '145%' }}>
                      $603.20
                    </div>
                    <div id="29EL-0" style={{ boxSizing: 'border-box' }} />
                  </div>
                </div>
                <div id="29FE-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  <svg width="780" height="245" viewBox="0 0 780 245" xmlns="http://www.w3.org/2000/svg" id="29FF-0" style={{ display: 'inline-block', flexShrink: 0 }}>
                    <g>
                      <line x1="55" y1="35" x2="745" y2="35" stroke="#C9CCD1" />
                      <line x1="55" y1="137" x2="745" y2="137" stroke="#C9CCD1" strokeDasharray="4 4" />
                      <line x1="55" y1="185" x2="745" y2="185" stroke="#C9CCD1" />
                    </g>
                    <g fontSize="11" fontFamily="Inter">
                      <text x="0" y="39" fill="#5D6B7E">{"+$680"}</text>
                      <text x="25" y="141" fill="#5D6B7E">{"$0"}</text>
                      <text x="0" y="189" fill="#5D6B7E">{"−$320"}</text>
                      <text x="55" y="225" fill="#5D6B7E">{"$580"}</text>
                      <text x="346" y="225" fill="#5D6B7E">{"$600"}</text>
                      <text x="510" y="225" fill="#5D6B7E">{"$610"}</text>
                      <text x="710" y="225" fill="#5D6B7E">{"$625"}</text>
                    </g>
                    <path d="M67.27,185.00 L105.91,185.00 L144.55,185.00 L183.19,185.00 L221.83,185.00 L260.47,185.00 L299.11,185.00 L337.75,185.00 L361.67,185.00 L376.39,170.60 L415.03,132.80 L453.67,95.00 L492.31,57.20 L515.00,35.00 L530.95,35.00 L569.59,35.00 L608.23,35.00 L646.87,35.00 L685.51,35.00 L724.15,35.00" fill="none" stroke="#2F63C4" strokeWidth="2.5" />
                    <circle cx="67.27" cy="185.00" r="3" fill="#2F63C4" />
                    <circle cx="105.91" cy="185.00" r="3" fill="#2F63C4" />
                    <circle cx="144.55" cy="185.00" r="3" fill="#2F63C4" />
                    <circle cx="183.19" cy="185.00" r="3" fill="#2F63C4" />
                    <circle cx="221.83" cy="185.00" r="3" fill="#2F63C4" />
                    <circle cx="260.47" cy="185.00" r="3" fill="#2F63C4" />
                    <circle cx="299.11" cy="185.00" r="3" fill="#2F63C4" />
                    <circle cx="337.75" cy="185.00" r="3" fill="#2F63C4" />
                    <circle cx="361.67" cy="185.00" r="3" fill="#2F63C4" />
                    <circle cx="376.39" cy="170.60" r="3" fill="#2F63C4" />
                    <circle cx="415.03" cy="132.80" r="3" fill="#2F63C4" />
                    <circle cx="453.67" cy="95.00" r="3" fill="#2F63C4" />
                    <circle cx="492.31" cy="57.20" r="3" fill="#2F63C4" />
                    <circle cx="515.00" cy="35.00" r="3" fill="#2F63C4" />
                    <circle cx="530.95" cy="35.00" r="3" fill="#2F63C4" />
                    <circle cx="569.59" cy="35.00" r="3" fill="#2F63C4" />
                    <circle cx="608.23" cy="35.00" r="3" fill="#2F63C4" />
                    <circle cx="646.87" cy="35.00" r="3" fill="#2F63C4" />
                    <circle cx="685.51" cy="35.00" r="3" fill="#2F63C4" />
                    <circle cx="724.15" cy="35.00" r="3" fill="#2F63C4" />
                    <line x1="453.667" y1="25" x2="453.667" y2="200" stroke="#5D6B7E" strokeDasharray="3 5" />
                    <circle cx="453.667" cy="95" r="7" fill="#2F63C4" stroke="#FFFFFF" strokeWidth="3" />
                  </svg>
                  <div id="29GF-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', justifyContent: 'space-between' }}>
                    <div id="29GG-0" style={{ boxSizing: 'border-box', display: 'flex', gap: '4px' }}>
                      <div id="29GH-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-text)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
                        <div id="29GI-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-bg)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                          Focus strikes
                        </div>
                      </div>
                      <div id="29GJ-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
                        <div id="29GK-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                          Full range
                        </div>
                      </div>
                    </div>
                    <div id="29GL-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                      Existing samples only · $606 selected
                    </div>
                  </div>
                </div>
              </div>
              <div id="29GN-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '14px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', minHeight: '0px', overflow: 'clip' }}>
                <div id="29GP-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', justifyContent: 'space-between', paddingBlock: '16px', paddingInline: '20px' }}>
                  <div id="29GQ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '17px', fontWeight: 600, lineHeight: '145%' }}>
                    Exact legs
                  </div>
                  <div id="29GR-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                    Side, quantity and premium are authored
                  </div>
                </div>
                <div id="29GT-0" style={{ alignItems: 'center', borderTopColor: 'var(--mx-light-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '12px', justifyContent: 'space-between', paddingBlock: '14px', paddingInline: '20px' }}>
                  <div id="29GU-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '3px', width: '250px' }}>
                    <div id="29GV-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%' }}>
                      SPY · 600 Call
                    </div>
                    <div id="29GW-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                      20 Nov 2026 · ordinary contract
                    </div>
                  </div>
                  <div id="29GX-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '4px', width: '100px' }}>
                    <div id="29GY-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
                      SIDE
                    </div>
                    <div id="29GZ-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
                      <div id="29H0-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                        Buy ▾
                      </div>
                    </div>
                  </div>
                  <div id="29H1-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '4px', width: '100px' }}>
                    <div id="29H2-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
                      CONTRACTS
                    </div>
                    <div id="29H3-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
                      <div id="29H4-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                        1
                      </div>
                    </div>
                  </div>
                  <div id="29H5-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '4px', width: '160px' }}>
                    <div id="29H6-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
                      PREMIUM / UNIT
                    </div>
                    <div id="29H7-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
                      <div id="29H8-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                        $5.60
                      </div>
                    </div>
                  </div>
                </div>
                <div id="29HA-0" style={{ alignItems: 'center', borderTopColor: 'var(--mx-light-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '12px', justifyContent: 'space-between', paddingBlock: '14px', paddingInline: '20px' }}>
                  <div id="29HB-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '3px', width: '250px' }}>
                    <div id="29HC-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '145%' }}>
                      SPY · 610 Call
                    </div>
                    <div id="29HD-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                      20 Nov 2026 · ordinary contract
                    </div>
                  </div>
                  <div id="29HE-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '4px', width: '100px' }}>
                    <div id="29HF-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
                      SIDE
                    </div>
                    <div id="29HG-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
                      <div id="29HH-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                        Sell ▾
                      </div>
                    </div>
                  </div>
                  <div id="29HI-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '4px', width: '100px' }}>
                    <div id="29HJ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
                      CONTRACTS
                    </div>
                    <div id="29HK-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
                      <div id="29HL-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                        1
                      </div>
                    </div>
                  </div>
                  <div id="29HM-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '4px', width: '160px' }}>
                    <div id="29HN-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
                      PREMIUM / UNIT
                    </div>
                    <div id="29HO-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
                      <div id="29HP-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                        $2.40
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div id="29DX-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '14px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, minWidth: '0px', overflow: 'clip', width: '320px' }}>
              <div id="29EN-0" style={{ borderBottomColor: 'var(--mx-light-line)', borderBottomStyle: 'solid', borderBottomWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '4px', padding: '12px' }}>
                <div id="29EO-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-text)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', flexBasis: '0%', flexGrow: '1', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
                  <div id="2AC2-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-bg)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    Scenario
                  </div>
                </div>
                <div id="29EQ-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', flexBasis: '0%', flexGrow: '1', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
                  <div id="29ER-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                    Case
                  </div>
                </div>
              </div>
              <div id="29ET-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '10px', padding: '20px' }}>
                <div id="29EU-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
                  PAYOFF BASIS
                </div>
                <div id="29EV-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
                  At expiry only
                </div>
                <div id="29EW-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%', whiteSpace: 'pre-wrap' }}>
                  Ordinary SPY · common expiry<br />100 shares per contract · USD
                </div>
                <div id="29EX-0" style={{ backgroundColor: 'var(--mx-light-line)', boxSizing: 'border-box', flexShrink: 0, height: '1px', width: '100%' }} />
                <div id="2AC4-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                  Selected expiry-price sample
                </div>
                <div id="29EZ-0" style={{ alignItems: 'center', borderColor: 'var(--mx-light-line)', borderRadius: '8px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', justifyContent: 'space-between', padding: '12px' }}>
                  <div id="29F0-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
                    $606.00
                  </div>
                  <div id="2AC6-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '11px', lineHeight: '145%' }}>
                    Select ▾
                  </div>
                </div>
                <div id="29F2-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
                  +$280 expiry P/L
                </div>
                <div id="29F3-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                  A scenario value, not a current option valuation or realized return.
                </div>
                <div id="29F4-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
                  <div id="29F5-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '16px', whiteSpace: 'pre' }}>
                    Terms &amp; calculation scope
                  </div>
                </div>
              </div>
              <div id="29F7-0" style={{ borderTopColor: 'var(--mx-light-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '10px', padding: '20px' }}>
                <div id="2AC8-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '17px', fontWeight: 600, lineHeight: '145%' }}>
                  Plan saving unavailable
                </div>
                <div id="2ACA-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
                  This exact Plan cannot yet be saved. Leaving may discard the draft.
                </div>
                <div id="29FA-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '40px', paddingInline: '14px' }}>
                  <div id="2ACC-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                    Open saved Exposure case
                  </div>
                </div>
                <div id="29FC-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                  Fees, slippage, exercise and assignment are excluded.
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
