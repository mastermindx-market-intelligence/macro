(
    <div id="2FNY-0" style={{ backgroundColor: 'var(--mx-light-bg)', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', fontSynthesis: 'none', gap: '24px', height: 'fit-content', MozOsxFontSmoothing: 'grayscale', overflowWrap: 'anywhere', padding: '32px', WebkitFontSmoothing: 'antialiased', width: '1440px' }}>
      <div id="2FPP-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '8px' }}>
        <div id="2FPS-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
          OPTIONS CONSOLIDATION · BUILD CONTRACT
        </div>
        <div id="2FPR-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '28px', fontWeight: 600, lineHeight: '145%' }}>
          One suite, existing owners
        </div>
        <div id="2FPQ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
          49 recovered boards + 9 consolidation boards · six workspace destinations · direct Shared Shell entry.
        </div>
      </div>
      <div id="2FPC-0" style={{ boxSizing: 'border-box', display: 'flex', gap: '16px' }}>
        <div id="2FPM-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '8px', padding: '20px', width: '332px' }}>
          <div id="2FPO-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '16px', fontWeight: 600, lineHeight: '145%' }}>
            01 · Source semantics
          </div>
          <div id="2FPN-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
            Version observations, clocks, claims and populations.
          </div>
        </div>
        <div id="2FPJ-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '8px', padding: '20px', width: '332px' }}>
          <div id="2FPL-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '16px', fontWeight: 600, lineHeight: '145%' }}>
            02 · Shared contracts
          </div>
          <div id="2FPK-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
            Amend Options/F01 IA and route admission together.
          </div>
        </div>
        <div id="2FPG-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '8px', padding: '20px', width: '332px' }}>
          <div id="2FPI-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '16px', fontWeight: 600, lineHeight: '145%' }}>
            03 · Complete workflows
          </div>
          <div id="2FPH-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
            Inspect, compare, Save, watch and review exact evidence.
          </div>
        </div>
        <div id="2FPD-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '8px', padding: '20px', width: '332px' }}>
          <div id="2FPF-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '16px', fontWeight: 600, lineHeight: '145%' }}>
            04 · Retirement proof
          </div>
          <div id="2FPE-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
            Parity, legacy links, rights, canary and rollback.
          </div>
        </div>
      </div>
      <div id="2FOQ-0" style={{ boxSizing: 'border-box', display: 'flex', gap: '24px' }}>
        <div id="2FP5-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '12px', minHeight: '260px', padding: '24px', width: '442px' }}>
          <div id="2FPB-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
            Options observations
          </div>
          <div id="2FPA-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
            Preserve the full specialist workbench.
          </div>
          <div id="2FP9-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
            Canonical owner
          </div>
          <div id="2FP8-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
            Existing Flow, Exposure, Volatility, Lab and terms owners
          </div>
          <div id="2FP7-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '12px', fontWeight: 500, lineHeight: '145%' }}>
            C01 + original O01–O13 / responsive boards
          </div>
          <div id="2FP6-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
            Keep all 15 view keys and aliases under the six destination groups.
          </div>
        </div>
        <div id="2FOY-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '12px', minHeight: '260px', padding: '24px', width: '442px' }}>
          <div id="2FP4-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
            Off-Exchange equities
          </div>
          <div id="2FP3-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
            Daily participation, venue reports and qualified live prints.
          </div>
          <div id="2FP2-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
            Canonical owner
          </div>
          <div id="2FP1-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
            Existing daily FINRA producers + TP5 / TP2 source owners
          </div>
          <div id="2FP0-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '12px', fontWeight: 500, lineHeight: '145%' }}>
            C02 / C04 / C05 · direct /off-exchange proposal
          </div>
          <div id="2FOZ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
            Replace the retired directional lean. Weekly attribution never becomes print identity.
          </div>
        </div>
        <div id="2FOR-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '12px', minHeight: '260px', padding: '24px', width: '442px' }}>
          <div id="2FOX-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
            Market structure
          </div>
          <div id="2FOW-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
            Market-wide modeled context with dated assumptions.
          </div>
          <div id="2FOV-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
            Canonical owner
          </div>
          <div id="2FOU-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
            Existing gamma, systematic, volatility and weekly-range owners
          </div>
          <div id="2FOT-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '12px', fontWeight: 500, lineHeight: '145%' }}>
            C03 / C06 / C07 · direct /market-structure proposal
          </div>
          <div id="2FOS-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
            Keep missing sessions, exact values, method, valid intervals and old revisions.
          </div>
        </div>
      </div>
      <div id="2FO4-0" style={{ boxSizing: 'border-box', display: 'flex', gap: '24px' }}>
        <div id="2FOJ-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '12px', minHeight: '260px', padding: '24px', width: '442px' }}>
          <div id="2FOP-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
            Research and persistence
          </div>
          <div id="2FOO-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
            Two supported opportunities, comparison and exact return.
          </div>
          <div id="2FON-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
            Canonical owner
          </div>
          <div id="2FOM-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
            Investigation / Plan #804 / alerts / outcome owners
          </div>
          <div id="2FOL-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '12px', fontWeight: 500, lineHeight: '145%' }}>
            Original OPT-100 · 15 direct + 36 transitive prerequisites
          </div>
          <div id="2FOK-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
            Core price–IV–time comparison and exact publication integrity remain required.
          </div>
        </div>
        <div id="2FOC-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '12px', minHeight: '260px', padding: '24px', width: '442px' }}>
          <div id="2FOI-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
            Shared Shell
          </div>
          <div id="2FOH-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
            Global jobs, directory, account and geometry.
          </div>
          <div id="2FOG-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
            Canonical owner
          </div>
          <div id="2FOF-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
            F01 candidate.4 + current registry exporter and route decoders
          </div>
          <div id="2FOE-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '12px', fontWeight: 500, lineHeight: '145%' }}>
            C07 direct Analysis entry · S06 access / arrival
          </div>
          <div id="2FOD-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
            Preserve site_full and terminal_live_options policies separately; no new login or universal cursor.
          </div>
        </div>
        <div id="2FO5-0" style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '12px', minHeight: '260px', padding: '24px', width: '442px' }}>
          <div id="2FOB-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '22px', fontWeight: 600, lineHeight: '145%' }}>
            Migration and operations
          </div>
          <div id="2FOA-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
            Retire duplicate pages after their replacements work.
          </div>
          <div id="2FO9-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '11px', fontWeight: 500, letterSpacing: '0.06em', lineHeight: '145%' }}>
            Canonical owner
          </div>
          <div id="2FO8-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
            Registry / site access / consumers / release owners
          </div>
          <div id="2FO7-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '12px', fontWeight: 500, lineHeight: '145%' }}>
            Old aliases → admitted native receivers → exact origin
          </div>
          <div id="2FO6-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
            Archive pages and designs; keep shared producers until every consumer is migrated.
          </div>
        </div>
      </div>
      <div id="2FNZ-0" style={{ borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '10px', padding: '24px' }}>
        <div id="2FO3-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '18px', fontWeight: 600, lineHeight: '145%' }}>
          Preserve original 245-board census, recovered 49-board suite and 528 overlapping requirement references.
        </div>
        <div id="2FO2-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
          Product p-1S-0 · Contracts p-1T-0 · Original Product p-1O-0 / Responsive p-1P-0 / States p-1Q-0 / Build p-1R-0
        </div>
        <div id="2FO1-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
          Retain Terminal #599 parent, #603 workbench, #655 TP5, #804 Plan and Macro #10866 holds. F01 candidate.5 and original uncertain Paper effects stay scoped; no release is authorized by these screens.
        </div>
        <div id="2FO0-0" style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
          Build packets, source contracts, conditional bindings and retirement acceptance live in the existing masterplan PR #10898. Native pixels and exports are design evidence, not deployed behavior.
        </div>
      </div>
    </div>
  )
