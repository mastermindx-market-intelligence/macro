(
    <div id="2EXR-0" style={{ backgroundColor: 'var(--mx-dark-bg)', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', fontSynthesis: 'none', MozOsxFontSmoothing: 'grayscale', overflowWrap: 'anywhere', WebkitFontSmoothing: 'antialiased' }}>
      <div id="2F1P-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-bg)', borderBottomColor: 'var(--mx-dark-line)', borderBottomStyle: 'solid', borderBottomWidth: '1px', boxSizing: 'border-box', display: 'flex', flexShrink: 0, height: '64px', justifyContent: 'space-between', paddingInline: '24px', width: '1440px' }}>
        <div id="2F1Z-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', flexShrink: 0, gap: '12px', width: '176px' }}>
          <div id="2F21-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-Bold", "Inter", system-ui, sans-serif', fontSize: '15px', fontWeight: 700, lineHeight: '145%' }}>
            M / X
          </div>
          <div id="2F20-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '10px', fontWeight: 600, lineHeight: '145%' }}>
            MASTERMIND
          </div>
        </div>
        <div id="2F1W-0" style={{ alignItems: 'center', borderColor: 'var(--mx-dark-line)', borderRadius: '8px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexShrink: 0, height: '36px', justifyContent: 'space-between', paddingInline: '14px', width: '380px' }}>
          <div id="2F1Y-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
            Search companies and tools
          </div>
          <div id="2F1X-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12px', lineHeight: '145%' }}>
            ⌘ K
          </div>
        </div>
        <div id="2F1Q-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', flexBasis: '0%', flexGrow: '1', gap: '24px', justifyContent: 'end', paddingLeft: '24px' }}>
          <div id="2F1V-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-warn)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 500, lineHeight: '145%' }}>
            Design example · synthetic data
          </div>
          <div id="2F1U-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
            All tools
          </div>
          <div id="2F1T-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
            EN · Dark
          </div>
          <div id="2F1R-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '999px', boxSizing: 'border-box', display: 'flex', flexShrink: 0, height: '32px', justifyContent: 'center', width: '32px' }}>
            <div id="2F1S-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12px', lineHeight: '16px' }}>
              R
            </div>
          </div>
        </div>
      </div>
      <div id="2EXS-0" style={{ boxSizing: 'border-box', display: 'flex', minHeight: '896px', width: '1440px' }}>
        <div id="2F16-0" style={{ backgroundColor: 'var(--mx-dark-bg)', borderRightColor: 'var(--mx-dark-line)', borderRightStyle: 'solid', borderRightWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: 0, gap: '8px', minHeight: '896px', paddingBlock: '24px', paddingInline: '16px', width: '224px' }}>
          <div id="2F1N-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '12px' }}>
            <div id="2F1O-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '18px' }}>
              Today
            </div>
          </div>
          <div id="2F1L-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '12px' }}>
            <div id="2F1M-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '18px' }}>
              Discover
            </div>
          </div>
          <div id="2F1J-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '12px' }}>
            <div id="2F1K-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '18px' }}>
              Analysis
            </div>
          </div>
          <div id="2F1H-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '12px' }}>
            <div id="2F1I-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '18px' }}>
              Monitor
            </div>
          </div>
          <div id="2F1F-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '12px' }}>
            <div id="2F1G-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '18px' }}>
              Research
            </div>
          </div>
          <div id="2F1D-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '12px' }}>
            <div id="2F1E-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '18px' }}>
              Portfolio
            </div>
          </div>
          <div id="2F1B-0" style={{ boxSizing: 'border-box', paddingBottom: '8px', paddingInline: '12px', paddingTop: '28px' }}>
            <div id="2F1C-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '11px', letterSpacing: '0.08em', lineHeight: '14px' }}>
              WORKSPACES
            </div>
          </div>
          <div id="2F19-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '12px' }}>
            <div id="2F1A-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '14px', fontWeight: 600, lineHeight: '18px' }}>
              Options
            </div>
          </div>
          <div id="2F17-0" style={{ boxSizing: 'border-box', paddingInline: '12px' }}>
            <div id="2F18-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
              United States · USD
            </div>
          </div>
        </div>
        <div id="2FFL-0" style={{ backgroundColor: 'var(--mx-dark-bg)', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: '0', gap: '20px', padding: '24px', width: '1216px' }}>
          <div id="2FFN-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '16px', justifyContent: 'space-between', width: '100%' }}>
            <div id="2FFO-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '2px' }}>
              <div id="2FFP-0" style={{ alignItems: 'center', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
                <div id="2FFQ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                  Overview
                </div>
              </div>
              <div id="2FFR-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
                <div id="2FFS-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 600, lineHeight: '145%' }}>
                  Flow
                </div>
              </div>
              <div id="2FFT-0" style={{ alignItems: 'center', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
                <div id="2FFU-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                  Exposure
                </div>
              </div>
              <div id="2FFV-0" style={{ alignItems: 'center', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
                <div id="2FFW-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                  Volatility
                </div>
              </div>
              <div id="2FFX-0" style={{ alignItems: 'center', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
                <div id="2FFY-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                  Research
                </div>
              </div>
              <div id="2FFZ-0" style={{ alignItems: 'center', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', minHeight: '40px', paddingInline: '12px' }}>
                <div id="2FG0-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                  Plans &amp; review
                </div>
              </div>
            </div>
            <div id="2FG1-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '44px', paddingInline: '14px' }}>
              <div id="2FG2-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '13px', fontWeight: 600, lineHeight: '16px' }}>
                SPY · Equity
              </div>
            </div>
          </div>
          <div id="2FG4-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '16px', justifyContent: 'space-between', minHeight: '72px' }}>
            <div id="2FG5-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <div id="2FG6-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '28px', fontWeight: 600, lineHeight: '145%' }}>
                Venue reports
              </div>
              <div id="2FG7-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '14px', lineHeight: '145%' }}>
                Weekly attribution from reported ATS and non-ATS volume.
              </div>
            </div>
            <div id="2FG8-0" style={{ alignItems: 'end', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <div id="2FG9-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-Medium", "Inter", system-ui, sans-serif', fontSize: '12.5px', fontWeight: 500, lineHeight: '145%' }}>
                Reporting week · 26–30 Oct 2026
              </div>
              <div id="2FGA-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                Available · 9 Nov 2026
              </div>
            </div>
          </div>
          <div id="2FKS-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '8px' }}>
            <div id="2FKT-0" style={{ alignItems: 'center', borderColor: '#00000000', borderRadius: '8px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '14px' }}>
              <div id="2FKU-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
                Daily participation
              </div>
            </div>
            <div id="2FKV-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderColor: 'var(--mx-dark-line)', borderRadius: '8px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '14px' }}>
              <div id="2FKW-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '13px', fontWeight: 600, lineHeight: '145%' }}>
                Venue reports
              </div>
            </div>
            <div id="2FKX-0" style={{ alignItems: 'center', borderColor: '#00000000', borderRadius: '8px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '14px' }}>
              <div id="2FKY-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
                Live prints · unavailable
              </div>
            </div>
            <div id="2FKZ-0" style={{ alignItems: 'center', borderColor: '#00000000', borderRadius: '8px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', minHeight: '44px', paddingInline: '14px' }}>
              <div id="2FL0-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
                History
              </div>
            </div>
          </div>
          <div id="2FGM-0" style={{ alignItems: 'start', boxSizing: 'border-box', display: 'flex', gap: '24px', width: '1168px' }}>
            <div id="2FGO-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: '0', gap: '20px', width: '824px' }}>
              <div id="2FGS-0" style={{ backgroundColor: 'var(--mx-dark-panel)', borderColor: 'var(--mx-dark-line)', borderRadius: '14px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px', padding: '20px' }}>
                <div id="2FGT-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '18px', fontWeight: 600, lineHeight: '145%' }}>
                  Reported weekly volume
                </div>
                <div id="2FGU-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
                  SPY · reporting week 26–30 Oct · 24.0m shares in this report
                </div>
                <div id="2FHK-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  <div id="2FHL-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', width: '784px' }}>
                    <div id="2FHM-0" style={{ backgroundColor: 'var(--mx-dark-link)', borderRadius: '4px', boxSizing: 'border-box', display: 'flex', flexShrink: 0, height: '32px', width: '202.67px' }} />
                    <div id="2FHN-0" style={{ backgroundColor: 'var(--mx-dark-line)', borderRadius: '4px', boxSizing: 'border-box', display: 'flex', flexShrink: 0, height: '32px', width: '581.33px' }} />
                  </div>
                  <div id="2FHO-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '16px', justifyContent: 'space-between' }}>
                    <div id="2FHP-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '13px', fontWeight: 600, lineHeight: '145%' }}>
                      ATS · 25.8%
                    </div>
                    <div id="2FHQ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '13px', fontWeight: 600, lineHeight: '145%' }}>
                      Non-ATS · 74.2%
                    </div>
                  </div>
                </div>
                <div id="2FHS-0" style={{ alignItems: 'center', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '16px', justifyContent: 'space-between', minHeight: '80px', paddingTop: '12px' }}>
                  <div id="2FHT-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
                    <div id="2FHU-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '16px', fontWeight: 600, lineHeight: '145%' }}>
                      ATS reports
                    </div>
                    <div id="2FHV-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                      Same reporting week and eligible report universe
                    </div>
                  </div>
                  <div id="2FHW-0" style={{ alignItems: 'end', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
                    <div id="2FHX-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '20px', fontWeight: 600, lineHeight: '145%' }}>
                      6.2m shares
                    </div>
                    <div id="2FHY-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                      25.8% of report total
                    </div>
                  </div>
                </div>
                <div id="2FI0-0" style={{ alignItems: 'center', borderTopColor: 'var(--mx-dark-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '16px', justifyContent: 'space-between', minHeight: '80px', paddingTop: '12px' }}>
                  <div id="2FI1-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
                    <div id="2FI2-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '16px', fontWeight: 600, lineHeight: '145%' }}>
                      Non-ATS reports
                    </div>
                    <div id="2FI3-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                      Same reporting week and eligible report universe
                    </div>
                  </div>
                  <div id="2FI4-0" style={{ alignItems: 'end', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
                    <div id="2FI5-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '20px', fontWeight: 600, lineHeight: '145%' }}>
                      17.8m shares
                    </div>
                    <div id="2FI6-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '12.5px', lineHeight: '145%' }}>
                      74.2% of report total
                    </div>
                  </div>
                </div>
                <div id="2FI8-0" style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '8px' }}>
                  <div id="2FI9-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-text)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '44px', paddingInline: '14px' }}>
                    <div id="2FIA-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-bg)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '13px', fontWeight: 600, lineHeight: '16px' }}>
                      Browse venue rows
                    </div>
                  </div>
                  <div id="2FIB-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '44px', paddingInline: '14px' }}>
                    <div id="2FIC-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '13px', fontWeight: 600, lineHeight: '16px' }}>
                      Export exact report
                    </div>
                  </div>
                  <div id="2FID-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '44px', paddingInline: '14px' }}>
                    <div id="2FIE-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '13px', fontWeight: 600, lineHeight: '16px' }}>
                      New research
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div id="2FGQ-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', flexShrink: '0', gap: '20px', width: '320px' }}>
              <div id="2FGW-0" style={{ backgroundColor: 'var(--mx-dark-panel)', borderColor: 'var(--mx-dark-line)', borderRadius: '14px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px', padding: '20px' }}>
                <div id="2FGX-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '18px', fontWeight: 600, lineHeight: '145%' }}>
                  Reporting basis
                </div>
                <div id="2FGY-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
                  Weekly data becomes available after the reporting period.
                </div>
                <div id="2FIG-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  <div id="2FIH-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '15px', fontWeight: 600, lineHeight: '145%' }}>
                    26–30 Oct · reporting period
                  </div>
                  <div id="2FII-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '15px', fontWeight: 600, lineHeight: '145%' }}>
                    9 Nov · first available
                  </div>
                  <div id="2FIJ-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
                    Compare reports with the same venue population. Daily participation has a different period and denominator.
                  </div>
                  <div id="2FIK-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '44px', paddingInline: '14px' }}>
                    <div id="2FIL-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '13px', fontWeight: 600, lineHeight: '16px' }}>
                      Inspect report source →
                    </div>
                  </div>
                </div>
              </div>
              <div id="2FH0-0" style={{ backgroundColor: 'var(--mx-dark-panel)', borderColor: 'var(--mx-dark-line)', borderRadius: '14px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px', padding: '20px' }}>
                <div id="2FH1-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '18px', fontWeight: 600, lineHeight: '145%' }}>
                  Live print availability
                </div>
                <div id="2FH2-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
                  This report contains venue aggregates.
                </div>
                <div id="2FIN-0" style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  <div id="2FIO-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '18px', fontWeight: 600, lineHeight: '145%' }}>
                    Print-level detail unavailable
                  </div>
                  <div id="2FIP-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-muted)', fontFamily: '"Inter-Regular", "Inter", system-ui, sans-serif', fontSize: '13px', lineHeight: '145%' }}>
                    This source cannot identify a venue for an individual trade or build a live price shelf.
                  </div>
                  <div id="2FIQ-0" style={{ alignItems: 'center', backgroundColor: 'var(--mx-dark-panel2)', borderRadius: '8px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '44px', paddingInline: '14px' }}>
                    <div id="2FIR-0" style={{ boxSizing: 'border-box', color: 'var(--mx-dark-text)', fontFamily: '"Inter-SemiBold", "Inter", system-ui, sans-serif', fontSize: '13px', fontWeight: 600, lineHeight: '16px' }}>
                      View source availability
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
