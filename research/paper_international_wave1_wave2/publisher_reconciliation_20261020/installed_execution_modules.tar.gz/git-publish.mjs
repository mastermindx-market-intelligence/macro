import { createHash } from 'node:crypto';
import { execFile as execFileCallback } from 'node:child_process';
import { promisify } from 'node:util';
import path from 'node:path';
import { mkdtemp, open, readFile, realpath as realpathDefault, rename, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';

const execFileDefault = promisify(execFileCallback);

const OPERATION_RE = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,255}$/;
const SHA_RE = /^[0-9a-f]{40}$/;
const SHA256_RE = /^[0-9a-f]{64}$/;
const COMMISSION_PATH = 'research/executive_commissions/COMMISSION.md';
const COMMISSION_COMMIT_MESSAGE = 'chore: prepare Executive commission';
const MAX_COMMISSION_BYTES = 512 * 1024;
const BRANCH_RE = /^sol\/web-[A-Za-z0-9._-]+$/;
const ALLOWED_LANE = 'web';
const CLOSED_REPOSITORY_ALIASES = Object.freeze(['mastermind', 'macro', 'terminal']);
const NOT_REGISTERED = 'workspace is not registered to the source repository';
const MAX_STDIO_BYTES = 1024 * 1024;
const DEFAULT_COMMAND_TIMEOUT_MS = 15_000;
const DEFAULT_PUSH_TIMEOUT_MS = 60_000;
const RESOLVED_CONFIGS = new WeakSet();

export const STUDIO_GIT_PUBLISH_STATUS_TOOL = Object.freeze({
  name: 'studio_git_publish_status',
  title: 'Studio Git Publish Status',
  description:
    'Read-only publication status for one existing Mastermind attended Web workspace. ' +
    'The host resolves the workspace, repository, branch and origin from the canonical mmx-workspace ' +
    'registration. The caller supplies only the operation id. Reports the current local HEAD, remote ' +
    'branch HEAD and whether the workspace is clean. This read-only schema has no capability to create ' +
    'a workspace, commit, push, change a ref, or accept a repository, path, branch, remote, credential, shell command or force option.',
  inputSchema: {
    type: 'object',
    properties: {
      operation_id: {
        type: 'string',
        minLength: 1,
        maxLength: 256,
        pattern: '^[A-Za-z0-9][A-Za-z0-9._:-]{0,255}$',
      },
    },
    required: ['operation_id'],
    additionalProperties: false,
  },
  annotations: {
    title: 'Studio Git Publish Status',
    readOnlyHint: true,
    destructiveHint: false,
    idempotentHint: true,
    openWorldHint: true,
  },
  _meta: { 'private-studio-mcp/gateway': true, 'private-studio-mcp/typed-git': true },
});

export const STUDIO_GIT_COMMIT_CURRENT_CHANGES_TOOL = Object.freeze({
  name: 'studio_git_commit_current_changes',
  title: 'Studio Git Commit Current Changes',
  description:
    'Create exactly one local commit from all current committable changes in one existing Mastermind ' +
    'attended Web workspace. The host resolves the workspace and branch from canonical mmx-workspace ' +
    'registration. The caller supplies only the operation id, exact expected current HEAD and a bounded ' +
    'single-line commit message. Ignored files stay uncommitted. A private temporary index prevents ' +
    'pre-commit staging side effects; after the fenced ref update is known applied, the real index is ' +
    'synchronized to that exact commit. Compare-and-swap ref update prevents stale-head publication. ' +
    'This operation is local-only; its schema has no capability to contact origin, push, accept paths, change remotes, or accept shell commands.',
  inputSchema: {
    type: 'object',
    properties: {
      operation_id: {
        type: 'string',
        minLength: 1,
        maxLength: 256,
        pattern: '^[A-Za-z0-9][A-Za-z0-9._:-]{0,255}$',
      },
      expected_head_sha: {
        type: 'string',
        pattern: '^[0-9a-f]{40}$',
      },
      message: {
        type: 'string',
        minLength: 1,
        maxLength: 240,
      },
    },
    required: ['operation_id', 'expected_head_sha', 'message'],
    additionalProperties: false,
  },
  annotations: {
    title: 'Studio Git Commit Current Changes',
    readOnlyHint: false,
    destructiveHint: true,
    idempotentHint: true,
    openWorldHint: false,
  },
  _meta: { 'private-studio-mcp/gateway': true, 'private-studio-mcp/typed-git': true },
});

export const STUDIO_GIT_PUSH_CURRENT_BRANCH_TOOL = Object.freeze({
  name: 'studio_git_push_current_branch',
  title: 'Studio Git Push Current Branch',
  description:
    'Push exactly the current HEAD of one existing clean Mastermind attended Web workspace to its ' +
    'same host-resolved sol/web-* origin branch without force, tags, branch selection or credential input. ' +
    'Requires the caller to fence the action with the exact expected local HEAD. If the remote already ' +
    'equals that HEAD, no push is issued. A failure after push starts is EFFECT_UNKNOWN unless remote ' +
    'readback proves the exact HEAD is applied. EFFECT_UNKNOWN remains unresolved and carries no retry authority; ' +
    'studio_git_publish_status exposes read-only reconciliation state for any later decision.',
  inputSchema: {
    type: 'object',
    properties: {
      operation_id: {
        type: 'string',
        minLength: 1,
        maxLength: 256,
        pattern: '^[A-Za-z0-9][A-Za-z0-9._:-]{0,255}$',
      },
      expected_head_sha: {
        type: 'string',
        pattern: '^[0-9a-f]{40}$',
      },
    },
    required: ['operation_id', 'expected_head_sha'],
    additionalProperties: false,
  },
  annotations: {
    title: 'Studio Git Push Current Branch',
    readOnlyHint: false,
    destructiveHint: true,
    idempotentHint: true,
    openWorldHint: true,
  },
  _meta: { 'private-studio-mcp/gateway': true, 'private-studio-mcp/typed-git': true },
});

export const STUDIO_GIT_PUBLISH_TOOLS = Object.freeze([
  STUDIO_GIT_PUBLISH_STATUS_TOOL,
  STUDIO_GIT_COMMIT_CURRENT_CHANGES_TOOL,
  STUDIO_GIT_PUSH_CURRENT_BRANCH_TOOL,
]);

function assertExactKeys(value, allowed, label) {
  for (const key of Object.keys(value)) {
    if (!allowed.has(key)) throw new TypeError(`${label}.${key} is not supported`);
  }
}

function requireAbsoluteString(value, label) {
  if (typeof value !== 'string' || !value || !path.isAbsolute(value) || value.includes('\0')) {
    throw new TypeError(`${label} must be a non-empty absolute path`);
  }
  return value;
}

function clampTimeout(value, fallback, label) {
  if (value === undefined) return fallback;
  if (!Number.isInteger(value) || value < 1 || value > 300_000) {
    throw new TypeError(`${label} must be an integer between 1 and 300000 milliseconds`);
  }
  return value;
}

export function resolveGitPublishConfig(value) {
  if (value === undefined || value === null || value === false) return null;
  if (typeof value === 'object' && value !== null && RESOLVED_CONFIGS.has(value)) return value;
  if (typeof value !== 'object' || Array.isArray(value)) {
    throw new TypeError('config.gitPublish must be an object, false, or absent');
  }
  if (Object.hasOwn(value, 'repositories')) {
    assertExactKeys(value, new Set([
      'enabled', 'workspaceCli', 'gitBinary', 'repositories',
      'commandTimeoutMs', 'pushTimeoutMs',
    ]), 'config.gitPublish');
    if (value.enabled !== true || !Array.isArray(value.repositories) ||
        value.repositories.length !== CLOSED_REPOSITORY_ALIASES.length) {
      throw new TypeError('config.gitPublish requires the exact closed repository profile');
    }
    const names = new Set();
    const sources = new Set();
    const remotes = new Set();
    const profiles = value.repositories.map((profile) => {
      if (!profile || typeof profile !== 'object' || Array.isArray(profile)) {
        throw new TypeError('repository profile must be an object');
      }
      assertExactKeys(profile, new Set(['repository', 'sourceRepository', 'allowedRemoteUrls']),
        'config.gitPublish.repositories[]');
      if (!CLOSED_REPOSITORY_ALIASES.includes(profile.repository) || names.has(profile.repository)) {
        throw new TypeError('repository profile alias must be unique and closed');
      }
      if (profile.allowedRemoteUrls?.length !== 1 ||
          sources.has(profile.sourceRepository) || remotes.has(profile.allowedRemoteUrls[0])) {
        throw new TypeError('closed repository profile requires distinct source and remote bindings');
      }
      names.add(profile.repository);
      sources.add(profile.sourceRepository);
      remotes.add(profile.allowedRemoteUrls[0]);
      return resolveGitPublishConfig({
        enabled: true,
        workspaceCli: value.workspaceCli,
        gitBinary: value.gitBinary,
        repository: profile.repository,
        sourceRepository: profile.sourceRepository,
        allowedRemoteUrls: profile.allowedRemoteUrls,
        commandTimeoutMs: value.commandTimeoutMs,
        pushTimeoutMs: value.pushTimeoutMs,
      });
    });
    if (!CLOSED_REPOSITORY_ALIASES.every((alias) => names.has(alias))) {
      throw new TypeError('repository profile missing a closed alias');
    }
    const resolved = Object.freeze({
      enabled: true,
      workspaceCli: requireAbsoluteString(value.workspaceCli, 'config.gitPublish.workspaceCli'),
      gitBinary: requireAbsoluteString(value.gitBinary, 'config.gitPublish.gitBinary'),
      commandTimeoutMs: clampTimeout(value.commandTimeoutMs, DEFAULT_COMMAND_TIMEOUT_MS, 'config.gitPublish.commandTimeoutMs'),
      pushTimeoutMs: clampTimeout(value.pushTimeoutMs, DEFAULT_PUSH_TIMEOUT_MS, 'config.gitPublish.pushTimeoutMs'),
      repositories: Object.freeze(CLOSED_REPOSITORY_ALIASES.map((name) =>
        profiles.find((profile) => profile.repository === name))),
    });
    RESOLVED_CONFIGS.add(resolved);
    return resolved;
  }
  assertExactKeys(
    value,
    new Set([
      'enabled', 'workspaceCli', 'gitBinary', 'sourceRepository', 'allowedRemoteUrls',
      'commandTimeoutMs', 'pushTimeoutMs', 'repository',
    ]),
    'config.gitPublish',
  );
  if (value.enabled !== true) {
    throw new TypeError('config.gitPublish.enabled must be true when gitPublish is configured');
  }
  if (value.repository !== undefined && !['mastermind', 'macro', 'terminal'].includes(value.repository)) {
    throw new TypeError('config.gitPublish.repository is not a closed repository alias');
  }
  const allowedRemoteUrls = value.allowedRemoteUrls;
  if (!Array.isArray(allowedRemoteUrls) || allowedRemoteUrls.length < 1 || allowedRemoteUrls.length > 8) {
    throw new TypeError('config.gitPublish.allowedRemoteUrls must be a non-empty array of at most 8 URLs');
  }
  const normalizedRemotes = [];
  for (const remote of allowedRemoteUrls) {
    if (typeof remote !== 'string' || !remote || remote.length > 2048 || remote.includes('\0')) {
      throw new TypeError('config.gitPublish.allowedRemoteUrls contains an invalid URL');
    }
    if (normalizedRemotes.includes(remote)) {
      throw new TypeError('config.gitPublish.allowedRemoteUrls contains a duplicate URL');
    }
    normalizedRemotes.push(remote);
  }
  const resolved = Object.freeze({
    enabled: true,
    workspaceCli: requireAbsoluteString(value.workspaceCli, 'config.gitPublish.workspaceCli'),
    gitBinary: requireAbsoluteString(value.gitBinary, 'config.gitPublish.gitBinary'),
    sourceRepository: requireAbsoluteString(value.sourceRepository, 'config.gitPublish.sourceRepository'),
    allowedRemoteUrls: Object.freeze(normalizedRemotes),
    lane: ALLOWED_LANE,
    ...(value.repository !== undefined ? { repository: value.repository } : {}),
    commandTimeoutMs: clampTimeout(value.commandTimeoutMs, DEFAULT_COMMAND_TIMEOUT_MS, 'config.gitPublish.commandTimeoutMs'),
    pushTimeoutMs: clampTimeout(value.pushTimeoutMs, DEFAULT_PUSH_TIMEOUT_MS, 'config.gitPublish.pushTimeoutMs'),
  });
  RESOLVED_CONFIGS.add(resolved);
  return resolved;
}

function validateOperationId(value) {
  if (typeof value !== 'string' || !OPERATION_RE.test(value)) {
    throw new TypeError('operation_id is invalid');
  }
  return value;
}

function validateExpectedContentSha256(value) {
  if (typeof value !== 'string' || !SHA256_RE.test(value)) {
    throw new TypeError('expected_content_sha256 is invalid');
  }
  return value;
}

function validateExpectedHead(value) {
  if (typeof value !== 'string' || !SHA_RE.test(value)) {
    throw new TypeError('expected_head_sha is invalid');
  }
  return value;
}

function validateCommitMessage(value) {
  if (typeof value !== 'string') throw new TypeError('message is invalid');
  const text = value.trim();
  if (!text || text.length > 240 || text.includes('\0') || text.includes('\n') || text.includes('\r')) {
    throw new TypeError('message is invalid');
  }
  return text;
}

function parseJson(text, label) {
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new Error(`${label} returned invalid JSON`);
  }
  return parsed;
}

function oneLine(value, label) {
  const text = String(value ?? '').trim();
  if (!text || text.includes('\n') || text.includes('\r')) throw new Error(`${label} is invalid`);
  return text;
}

function actionRef(operationId, branch, head) {
  return createHash('sha256')
    .update('mastermind.studio_git_push_current_branch.v1\0')
    .update(operationId).update('\0').update(branch).update('\0').update(head)
    .digest('hex');
}

function commitActionRef(operationId, branch, oldHead, tree, message) {
  return createHash('sha256')
    .update('mastermind.studio_git_commit_current_changes.v1\0')
    .update(operationId).update('\0').update(branch).update('\0').update(oldHead)
    .update('\0').update(tree).update('\0').update(message)
    .digest('hex');
}

function publicStatus(state) {
  return {
    operation_id: state.operationId,
    branch: state.branch,
    local_head_sha: state.localHead,
    remote_head_sha: state.remoteHead,
    clean: state.clean,
    publication_state: state.remoteHead === state.localHead ? 'APPLIED' : (state.remoteHead === null ? 'NOT_APPLIED' : 'DIFFERENT_REMOTE_HEAD'),
    ready_to_push: state.clean && state.remoteHead !== state.localHead,
  };
}

function createClosedRepositoryPublisher(cfg, dependencies) {
  const execFile = dependencies.execFile ?? execFileDefault;
  const publishers = new Map(cfg.repositories.map((profile) =>
    [profile.repository, createGitPublisher(profile, dependencies)]));
  async function select(operationId) {
    const operation = validateOperationId(operationId);
    let selected = null;
    for (const profile of cfg.repositories) {
      let stdout;
      try {
        ({stdout} = await execFile(cfg.workspaceCli,
          ['status', '--operation-id', operation, '--lane', ALLOWED_LANE,
            '--repository', profile.repository],
          {
            timeout: cfg.commandTimeoutMs, maxBuffer: MAX_STDIO_BYTES, encoding: 'utf8',
            env: {
              PATH: '/usr/bin:/bin:/usr/sbin:/sbin',
              HOME: process.env.HOME ?? '',
              USER: process.env.USER ?? '',
              LOGNAME: process.env.LOGNAME ?? '',
              LANG: 'C', LC_ALL: 'C', GIT_TERMINAL_PROMPT: '0',
              GIT_ASKPASS: '/usr/bin/false', SSH_ASKPASS: '/usr/bin/false',
            },
          }));
      } catch (error) {
        // The installed mmx-workspace CLI emits its exact NOT_REGISTERED
        // read-only refusal as JSON on stderr and exits 2. Only this one
        // typed absence is a non-match; every other error remains a refusal.
        if (error?.code !== 2 || String(error.stdout ?? '').trim() ||
            typeof error.stderr !== 'string') throw error;
        const result = parseJson(error.stderr, 'closed mmx-workspace refusal');
        const exactKeys = ['action', 'effect', 'error', 'repository', 'schema_version'];
        if (result?.action === 'status' && result.effect === 'NOT_APPLIED' &&
            result.error === NOT_REGISTERED && result.repository === profile.repository &&
            result.schema_version === 'mastermind.workspace_cli/v2' &&
            Object.keys(result).length === exactKeys.length &&
            exactKeys.every((key) => Object.hasOwn(result, key))) continue;
        throw error;
      }
      const result = parseJson(stdout, 'closed mmx-workspace status');
      if (result?.action !== 'status' ||
          result.schema_version !== 'mastermind.workspace_cli/v2' ||
          result.effect !== 'NOT_APPLIED' || result.repository !== profile.repository) {
        throw new Error('closed workspace registry returned an invalid repository receipt');
      }
      // A successful stdout response can never report absence: only the exit
      // code 2 typed stderr refusal above is canonical non-registration. Any
      // error field here is malformed evidence and fails closed.
      if (result.error !== undefined || !result.receipt || typeof result.receipt !== 'object') {
        throw new Error('closed workspace registry returned an unexpected result');
      }
      if (selected !== null) throw new Error('operation ID is registered in more than one repository');
      selected = publishers.get(profile.repository);
    }
    if (!selected) throw new Error('operation is not registered in the closed repository profile');
    return selected;
  }
  const dispatch = (method) => async (args) => {
    const publisher = await select(args?.operation_id);
    return publisher[method](args);
  };
  return Object.freeze({
    status: dispatch('status'),
    commit: dispatch('commit'),
    push: dispatch('push'),
  });
}

export function createGitPublisher(config, dependencies = {}) {
  const cfg = resolveGitPublishConfig(config);
  if (!cfg) throw new TypeError('git publish is not configured');
  if (cfg.repositories) return createClosedRepositoryPublisher(cfg, dependencies);
  const execFile = dependencies.execFile ?? execFileDefault;
  const realpath = dependencies.realpath ?? realpathDefault;
  const remove = dependencies.rm ?? rm;

  async function run(file, args, { cwd, timeoutMs = cfg.commandTimeoutMs, envExtra = {}, encoding = 'utf8' } = {}) {
    return execFile(file, args, {
      cwd,
      timeout: timeoutMs,
      maxBuffer: MAX_STDIO_BYTES,
      encoding,
      env: {
        PATH: '/usr/bin:/bin:/usr/sbin:/sbin',
        HOME: process.env.HOME ?? '',
        USER: process.env.USER ?? '',
        LOGNAME: process.env.LOGNAME ?? '',
        LANG: 'C',
        LC_ALL: 'C',
        GIT_TERMINAL_PROMPT: '0',
        GIT_ASKPASS: '/usr/bin/false',
        SSH_ASKPASS: '/usr/bin/false',
        ...envExtra,
      },
    });
  }

  async function git(cwd, args, options = {}) {
    return run(cfg.gitBinary, args, { cwd, ...options });
  }

  async function gitWithIndex(cwd, args, indexPath, options = {}) {
    return git(cwd, args, { ...options, envExtra: { GIT_INDEX_FILE: indexPath } });
  }

  async function gitQuiet(cwd, args, options = {}) {
    try {
      await git(cwd, args, options);
      return true;
    } catch (error) {
      if (error?.code === 1) return false;
      throw error;
    }
  }

  async function seedPrivateIndex(workspacePath, indexPath) {
    const {stdout} = await git(workspacePath, ['rev-parse', '--git-path', 'index']);
    const realIndexPath = path.resolve(workspacePath, oneLine(stdout, 'real index path'));
    const originalIndex = await readFile(realIndexPath);
    await writeFile(indexPath, originalIndex);
    return {realIndexPath, originalIndex};
  }

  async function syncRealIndex(realIndexPath, originalIndex, stagedIndexPath) {
    // read-tree after a successful commit also destroys sparse skip-worktree
    // metadata. The private staged index already encodes the exact committed
    // tree; install those bytes with Git's normal exclusive index.lock protocol.
    // Never clobber a concurrent index writer. A sync failure after update-ref
    // is APPLIED/PARTIAL, never a denial or replay of the committed ref.
    const lockPath = realIndexPath + '.lock';
    let handle = null;
    let ownsLock = false;
    try {
      handle = await open(lockPath, 'wx', 0o600);
      ownsLock = true;
      if (!(await readFile(realIndexPath)).equals(originalIndex)) {
        throw new Error('real index changed before post-commit synchronization');
      }
      const stagedIndex = await readFile(stagedIndexPath);
      await handle.writeFile(stagedIndex);
      await handle.sync();
      await handle.close();
      handle = null;
      await rename(lockPath, realIndexPath);
      ownsLock = false;
    } finally {
      if (handle !== null) await handle.close().catch(() => {});
      // A failed exclusive open never grants ownership of someone else's lock.
      if (ownsLock) await rm(lockPath, {force: true}).catch(() => {});
    }
  }

  async function verifyDestinationBinding(binding) {
    const {workspacePath, remoteUrl, gitArgs} = binding;
    for (const mode of [[], ['--push']]) {
      const {stdout} = await git(workspacePath, [...gitArgs, 'remote', 'get-url', ...mode, '--all', 'origin']);
      if (oneLine(stdout, 'pinned origin destination') !== remoteUrl) {
        throw new Error('pinned origin destination changed or was rewritten');
      }
    }
  }

  async function captureDestination(workspacePath, branch) {
    const {stdout} = await git(workspacePath, ['remote', 'get-url', '--push', '--all', 'origin']);
    const remoteUrl = oneLine(stdout, 'complete effective push destination');
    if (!cfg.allowedRemoteUrls.includes(remoteUrl)) {
      throw new Error('effective push destination is outside the configured Mastermind remote boundary');
    }
    // Empty values clear inherited URL lists, then bind one destination for
    // both push and readback. Keep origin identity, hooks, credentials and all
    // unrelated repository controls; never persist a config change.
    const gitArgs = Object.freeze([
      '-c', 'remote.origin.url=', '-c', `remote.origin.url=${remoteUrl}`,
      '-c', 'remote.origin.pushurl=', '-c', `remote.origin.pushurl=${remoteUrl}`,
      // Git applies remote.mirror after parsing --no-mirror; constrain both.
      '-c', 'remote.origin.mirror=false',
    ]);
    const binding = Object.freeze({workspacePath, branch, remoteUrl, gitArgs});
    await verifyDestinationBinding(binding);
    return binding;
  }

  async function boundedSubmodulePolicy(workspacePath) {
    async function value(key, boolean = false) {
      try {
        const {stdout} = await git(workspacePath, ['config', ...(boolean ? ['--bool'] : []), '--get', key]);
        return String(stdout).trim();
      } catch (error) {
        if (error.code === 1) return null;
        throw error;
      }
    }
    const pushPolicy = await value('push.recurseSubmodules');
    if (pushPolicy === 'check') return 'check';
    if (pushPolicy === 'no' || pushPolicy === 'false') return 'no';
    if (pushPolicy !== null) {
      throw new Error('submodule-pushing policy is outside the one-repository publication boundary');
    }
    if (await value('submodule.recurse', true) === 'true') {
      throw new Error('recursive submodule policy requires explicit non-pushing publication policy');
    }
    return 'no';
  }

  async function workspace(operationId, { observeRemote = true, remoteBinding = null } = {}) {
    const operation = validateOperationId(operationId);
    const { stdout } = await run(
      cfg.workspaceCli,
      ['status', '--operation-id', operation, '--lane', cfg.lane,
        ...(cfg.repository === undefined ? [] : ['--repository', cfg.repository])],
      { timeoutMs: cfg.commandTimeoutMs },
    );
    const result = parseJson(stdout, 'mmx-workspace status');
    if (cfg.repository !== undefined && (result?.schema_version !== 'mastermind.workspace_cli/v2' ||
        result?.repository !== cfg.repository || result?.effect !== 'NOT_APPLIED')) {
      throw new Error('workspace repository binding does not match the selected repository');
    }
    const receipt = result?.receipt;
    if (result?.action !== 'status' || !receipt || typeof receipt !== 'object') {
      throw new Error('mmx-workspace status receipt is invalid');
    }
    const receiptSource = requireAbsoluteString(receipt.source_repository, 'workspace source repository');
    const [resolvedReceiptSource, resolvedConfiguredSource] = await Promise.all([
      realpath(receiptSource),
      realpath(cfg.sourceRepository),
    ]);
    if (resolvedReceiptSource !== resolvedConfiguredSource) {
      throw new Error('workspace source repository does not match the configured Mastermind repository');
    }
    const rawWorkspacePath = requireAbsoluteString(receipt.workspace_path, 'workspace receipt path');
    const workspacePath = await realpath(rawWorkspacePath);
    const branch = oneLine(receipt.branch, 'workspace branch');
    if (!BRANCH_RE.test(branch)) throw new Error('workspace branch is outside the sol/web-* publication boundary');
    if (cfg.repository !== undefined && branch !== `sol/web-${operation.toLowerCase()}`) {
      throw new Error('workspace repository binding has a foreign operation branch');
    }

    // Avoid the high-level status refresh on very large linked worktrees.
    // These three read-only probes preserve the same repository/global ignore,
    // attribute and filter semantics as commit while optional locks prevent
    // observation from rewriting the shared index.
    const observationOptions = Object.freeze({envExtra: {GIT_OPTIONAL_LOCKS: '0'}});
    const [
      { stdout: topOut }, { stdout: branchOut }, { stdout: headOut },
      worktreeClean, indexClean, { stdout: untrackedOut }, { stdout: remoteOut },
    ] = await Promise.all([
      git(workspacePath, ['rev-parse', '--show-toplevel']),
      git(workspacePath, ['symbolic-ref', '--quiet', '--short', 'HEAD']),
      git(workspacePath, ['rev-parse', 'HEAD']),
      gitQuiet(workspacePath, ['diff-files', '--quiet', '--'], observationOptions),
      gitQuiet(workspacePath, ['diff-index', '--cached', '--quiet', 'HEAD', '--'], observationOptions),
      git(workspacePath, ['ls-files', '--others', '--exclude-standard', '-z'], observationOptions),
      remoteBinding ? Promise.resolve({stdout: remoteBinding.remoteUrl}) : git(workspacePath, ['remote', 'get-url', 'origin']),
    ]);
    const top = await realpath(oneLine(topOut, 'workspace top level'));
    const currentBranch = oneLine(branchOut, 'current branch');
    const localHead = oneLine(headOut, 'local HEAD');
    const remoteUrl = oneLine(remoteOut, 'origin URL');
    if (top !== workspacePath) throw new Error('workspace path is not the Git top level');
    if (currentBranch !== branch) throw new Error('current Git branch does not match mmx-workspace ownership');
    if (!SHA_RE.test(localHead)) throw new Error('local HEAD is invalid');
    if (!cfg.allowedRemoteUrls.includes(remoteUrl)) throw new Error('origin URL is outside the configured Mastermind remote boundary');

    const ref = `refs/heads/${branch}`;
    let remoteHead;
    let binding;
    if (observeRemote) {
      binding = remoteBinding ?? await captureDestination(workspacePath, branch);
      if (binding.workspacePath !== workspacePath || binding.branch !== branch) {
        throw new Error('original publication destination lost its workspace or branch binding');
      }
      await verifyDestinationBinding(binding);
      remoteHead = null;
      const { stdout: lsOut } = await git(workspacePath, [...binding.gitArgs, 'ls-remote', '--heads', 'origin', ref]);
      const lines = String(lsOut ?? '').trim() ? String(lsOut).trim().split(/\r?\n/) : [];
      if (lines.length > 1) throw new Error('origin returned multiple exact branch refs');
      if (lines.length === 1) {
        const match = lines[0].match(/^([0-9a-f]{40})\s+refs\/heads\/(.+)$/);
        if (!match || match[2] !== branch) throw new Error('origin returned an invalid exact branch ref');
        remoteHead = match[1];
      }
    }

    return {
      operationId: operation,
      workspacePath,
      branch,
      localHead,
      ...(observeRemote ? { remoteHead, remoteBinding: binding } : {}),
      clean: worktreeClean && indexClean && String(untrackedOut ?? '') === '',
      remoteUrl,
      ref,
    };
  }


  async function committedCommissionDigest(workspacePath, revision) {
    const {stdout: entryOut} = await git(workspacePath, ['ls-tree', revision, '--', COMMISSION_PATH]);
    const entry = String(entryOut ?? '').trim();
    const match = entry.match(/^100644 blob ([0-9a-f]{40})\tresearch\/executive_commissions\/COMMISSION\.md$/);
    if (!match) return null;
    const blob = match[1];
    const {stdout: sizeOut} = await git(workspacePath, ['cat-file', '-s', blob]);
    const size = Number(oneLine(sizeOut, 'commission blob size'));
    if (!Number.isSafeInteger(size) || size < 0 || size > MAX_COMMISSION_BYTES) return null;
    const {stdout: blobBytes} = await run(cfg.gitBinary, ['cat-file', 'blob', blob], {
      cwd: workspacePath, encoding: 'buffer',
    });
    if (!Buffer.isBuffer(blobBytes) || blobBytes.length !== size) throw new Error('commission blob read is invalid');
    return createHash('sha256').update(blobBytes).digest('hex');
  }

  // Internal-only, read-only reconciliation record. It is deliberately absent
  // from STUDIO_GIT_PUBLISH_TOOLS and does not disclose document bytes or paths.
  async function commissionStatus(args) {
    if (!args || typeof args !== 'object' || Array.isArray(args) ||
        Object.keys(args).some((key) => key !== 'operation_id')) {
      throw new TypeError('internal commission status arguments are invalid');
    }
    const observed = await workspace(args.operation_id);
    const contentSha256 = await committedCommissionDigest(observed.workspacePath, observed.localHead);
    return {
      schema: 'mastermind.studio_git_commission_status.v1',
      operation_id: observed.operationId,
      branch: observed.branch,
      local_head_sha: observed.localHead,
      remote_head_sha: observed.remoteHead,
      clean: observed.clean,
      ...(contentSha256 === null ? {} : {commission_content_sha256: contentSha256}),
    };
  }

  async function status(args) {
    if (!args || typeof args !== 'object' || Array.isArray(args) || Object.keys(args).some((key) => key !== 'operation_id')) {
      throw new TypeError('studio_git_publish_status arguments are invalid');
    }
    return {
      schema: 'mastermind.studio_git_publish_status.v1',
      ...publicStatus(await workspace(args.operation_id)),
    };
  }

  async function commit(args) {
    if (!args || typeof args !== 'object' || Array.isArray(args) ||
        Object.keys(args).some((key) => !['operation_id', 'expected_head_sha', 'message'].includes(key))) {
      throw new TypeError('studio_git_commit_current_changes arguments are invalid');
    }
    const operationId = validateOperationId(args.operation_id);
    const expectedHead = validateExpectedHead(args.expected_head_sha);
    const message = validateCommitMessage(args.message);
    const before = await workspace(operationId, { observeRemote: false });
    if (before.localHead !== expectedHead) {
      return {
        schema: 'mastermind.studio_git_commit_result.v1',
        status: 'REFUSED',
        effect_state: 'NOT_APPLIED',
        code: 'EXPECTED_HEAD_MISMATCH',
        operation_id: operationId,
        branch: before.branch,
        expected_head_sha: expectedHead,
        local_head_sha: before.localHead,
      };
    }

    const scratch = await mkdtemp(path.join(tmpdir(), 'studio-git-commit-'));
    const indexPath = path.join(scratch, 'index');
    let refUpdateAttempted = false;
    try {
      // read-tree into a fresh GIT_INDEX_FILE loses linked-worktree sparse
      // skip-worktree metadata. On a large sparse checkout that produces
      // phantom deletions and makes git add -A exceed its bounded timeout.
      // Snapshot the actual index into the private staging index instead.
      // Neither the real index nor the source ref is modified at this step.
      const {realIndexPath, originalIndex} = await seedPrivateIndex(before.workspacePath, indexPath);
      await gitWithIndex(before.workspacePath, ['add', '-A', '--', '.'], indexPath);
      const { stdout: treeOut } = await gitWithIndex(before.workspacePath, ['write-tree'], indexPath);
      const tree = oneLine(treeOut, 'candidate tree');
      if (!SHA_RE.test(tree)) throw new Error('candidate tree is invalid');
      // A competing index writer must not be silently overwritten. The
      // original source ref is still untouched, so this refusal is NOT_APPLIED.
      if (!(await readFile(realIndexPath)).equals(originalIndex)) {
        return {
          schema: 'mastermind.studio_git_commit_result.v1',
          status: 'REFUSED',
          effect_state: 'NOT_APPLIED',
          code: 'REAL_INDEX_CHANGED_DURING_PREPARATION',
          operation_id: operationId,
          branch: before.branch,
          local_head_sha: expectedHead,
        };
      }
      const { stdout: baseTreeOut } = await git(before.workspacePath, ['rev-parse', `${expectedHead}^{tree}`]);
      const baseTree = oneLine(baseTreeOut, 'base tree');
      const ref = commitActionRef(operationId, before.branch, expectedHead, tree, message);
      if (tree === baseTree) {
        return {
          schema: 'mastermind.studio_git_commit_result.v1',
          status: 'REFUSED',
          effect_state: 'NOT_APPLIED',
          code: 'NO_COMMITTABLE_CHANGES',
          action_ref: ref,
          operation_id: operationId,
          branch: before.branch,
          local_head_sha: expectedHead,
        };
      }

      const { stdout: commitOut } = await gitWithIndex(
        before.workspacePath,
        ['commit-tree', tree, '-p', expectedHead, '-m', message],
        indexPath,
      );
      const commitHead = oneLine(commitOut, 'commit HEAD');
      if (!SHA_RE.test(commitHead)) throw new Error('commit HEAD is invalid');

      async function finishKnownApplied(successCode) {
        let indexSynced = true;
        try {
          // The private index protects the caller from pre-commit staging side
          // effects. Once the fenced ref update is known applied, align the
          // real index with that exact commit without touching the worktree.
          await syncRealIndex(realIndexPath, originalIndex, indexPath);
        } catch {
          indexSynced = false;
        }

        let observed = null;
        try {
          observed = await workspace(operationId, { observeRemote: false });
        } catch {
          // The ref update itself is already known applied. A failed readback
          // cannot turn that known effect into EFFECT_UNKNOWN.
        }
        if (!observed) {
          return {
            schema: 'mastermind.studio_git_commit_result.v1',
            status: 'PARTIAL',
            effect_state: 'APPLIED',
            code: indexSynced ? 'APPLIED_READBACK_FAILED' : 'APPLIED_INDEX_SYNC_AND_READBACK_FAILED',
            action_ref: ref,
            operation_id: operationId,
            branch: before.branch,
            previous_head_sha: expectedHead,
            commit_head_sha: commitHead,
            index_synced: indexSynced,
          };
        }
        const current = observed.localHead === commitHead;
        const complete = current && indexSynced;
        return {
          schema: 'mastermind.studio_git_commit_result.v1',
          status: complete ? 'OK' : 'PARTIAL',
          effect_state: 'APPLIED',
          code: complete ? successCode : (current ? 'APPLIED_INDEX_SYNC_FAILED' : 'APPLIED_BUT_SUPERSEDED'),
          action_ref: ref,
          operation_id: observed.operationId,
          branch: observed.branch,
          previous_head_sha: expectedHead,
          commit_head_sha: commitHead,
          local_head_sha: observed.localHead,
          clean: observed.clean,
          index_synced: indexSynced,
        };
      }

      refUpdateAttempted = true;
      try {
        await git(before.workspacePath, ['update-ref', before.ref, commitHead, expectedHead]);
      } catch {
        try {
          const observed = await workspace(operationId, { observeRemote: false });
          if (observed.localHead === commitHead) {
            return await finishKnownApplied('APPLIED_AFTER_AMBIGUOUS_UPDATE_RETURN');
          }
        } catch {
          // Preserve uncertainty from a lost ref-update response.
        }
        return {
          schema: 'mastermind.studio_git_commit_result.v1',
          status: 'UNKNOWN',
          effect_state: 'EFFECT_UNKNOWN',
          code: 'LOCAL_REF_UPDATE_UNCERTAIN',
          action_ref: ref,
          operation_id: operationId,
          branch: before.branch,
          previous_head_sha: expectedHead,
          commit_head_sha: commitHead,
        };
      }

      return await finishKnownApplied('APPLIED');
    } finally {
      try {
        await remove(scratch, { recursive: true, force: true });
      } catch (error) {
        // Before the ref update is admitted, cleanup failure can still fail the
        // operation normally. Once the ref update may have run, however, a
        // scratch cleanup error must never overwrite APPLIED/EFFECT_UNKNOWN
        // source truth with a synthetic NOT_APPLIED gateway precheck result.
        if (!refUpdateAttempted) throw error;
      }
    }
  }


  // Internal-only fixed-path primitive for the commissioned preparation endpoint.
  // It is deliberately absent from STUDIO_GIT_PUBLISH_TOOLS and accepts no path,
  // branch, remote, repository, or command selector.
  async function commitCommission(args) {
    if (!args || typeof args !== 'object' || Array.isArray(args) ||
        Object.keys(args).some((key) => !['operation_id', 'expected_head_sha', 'expected_content_sha256'].includes(key))) {
      throw new TypeError('internal commission commit arguments are invalid');
    }
    const operationId = validateOperationId(args.operation_id);
    const expectedHead = validateExpectedHead(args.expected_head_sha);
    const expectedContentSha256 = validateExpectedContentSha256(args.expected_content_sha256);
    const message = COMMISSION_COMMIT_MESSAGE;
    const before = await workspace(operationId, { observeRemote: false });
    if (before.localHead !== expectedHead) {
      return {
        schema: 'mastermind.studio_git_commit_result.v1',
        status: 'REFUSED', effect_state: 'NOT_APPLIED', code: 'EXPECTED_HEAD_MISMATCH',
        operation_id: operationId, branch: before.branch,
        expected_head_sha: expectedHead, local_head_sha: before.localHead,
      };
    }

    const {stdout: statusOut} = await git(before.workspacePath,
      ['status', '--porcelain=v1', '--untracked-files=all']);
    const statusLines = String(statusOut ?? '').split(/\r?\n/).filter(Boolean);
    if (statusLines.length !== 1 || statusLines[0].slice(3) !== COMMISSION_PATH) {
      return {
        schema: 'mastermind.studio_git_commit_result.v1',
        status: 'REFUSED', effect_state: 'NOT_APPLIED', code: 'FOREIGN_WORKTREE_CHANGES',
        operation_id: operationId, branch: before.branch, local_head_sha: expectedHead,
      };
    }

    const scratch = await mkdtemp(path.join(tmpdir(), 'studio-git-commission-'));
    const indexPath = path.join(scratch, 'index');
    let refUpdateAttempted = false;
    let commitHead = null;
    let ref = null;
    try {
      const {realIndexPath, originalIndex} = await seedPrivateIndex(before.workspacePath, indexPath);
      await gitWithIndex(before.workspacePath, ['add', '--', COMMISSION_PATH], indexPath);
      const {stdout: treeOut} = await gitWithIndex(before.workspacePath, ['write-tree'], indexPath);
      const tree = oneLine(treeOut, 'commission candidate tree');
      if (!SHA_RE.test(tree)) throw new Error('commission candidate tree is invalid');
      ref = commitActionRef(operationId, before.branch, expectedHead, tree, message);

      const {stdout: pathsOut} = await git(before.workspacePath,
        ['diff-tree', '--no-commit-id', '--name-only', '-r', expectedHead, tree]);
      if (String(pathsOut ?? '').trim() !== COMMISSION_PATH) {
        return {
          schema: 'mastermind.studio_git_commit_result.v1',
          status: 'REFUSED', effect_state: 'NOT_APPLIED', code: 'COMMISSION_PATHSET_MISMATCH',
          action_ref: ref, operation_id: operationId, branch: before.branch,
          local_head_sha: expectedHead,
        };
      }
      const actualContentSha256 = await committedCommissionDigest(before.workspacePath, tree);
      if (actualContentSha256 === null) {
        return {
          schema: 'mastermind.studio_git_commit_result.v1',
          status: 'REFUSED', effect_state: 'NOT_APPLIED', code: 'COMMISSION_ENTRY_NOT_REGULAR_BLOB',
          action_ref: ref, operation_id: operationId, branch: before.branch,
          local_head_sha: expectedHead,
        };
      }
      if (actualContentSha256 !== expectedContentSha256) {
        return {
          schema: 'mastermind.studio_git_commit_result.v1',
          status: 'REFUSED', effect_state: 'NOT_APPLIED', code: 'COMMISSION_CONTENT_SHA256_MISMATCH',
          action_ref: ref, operation_id: operationId, branch: before.branch,
          local_head_sha: expectedHead,
        };
      }

      if (!(await readFile(realIndexPath)).equals(originalIndex)) {
        return {
          schema: 'mastermind.studio_git_commit_result.v1',
          status: 'REFUSED', effect_state: 'NOT_APPLIED',
          code: 'REAL_INDEX_CHANGED_DURING_PREPARATION',
          operation_id: operationId, branch: before.branch, local_head_sha: expectedHead,
        };
      }
      const {stdout: commitOut} = await gitWithIndex(before.workspacePath,
        ['commit-tree', tree, '-p', expectedHead, '-m', message], indexPath);
      commitHead = oneLine(commitOut, 'commission commit HEAD');
      if (!SHA_RE.test(commitHead)) throw new Error('commission commit HEAD is invalid');

      refUpdateAttempted = true;
      try {
        await git(before.workspacePath, ['update-ref', before.ref, commitHead, expectedHead]);
      } catch {
        try {
          if ((await workspace(operationId, {observeRemote: false})).localHead === commitHead) {
            return finishCommissionApplied('APPLIED_AFTER_AMBIGUOUS_UPDATE_RETURN');
          }
        } catch { /* retain uncertainty */ }
        return {
          schema: 'mastermind.studio_git_commit_result.v1',
          status: 'UNKNOWN', effect_state: 'EFFECT_UNKNOWN', code: 'LOCAL_REF_UPDATE_UNCERTAIN',
          action_ref: ref, operation_id: operationId, branch: before.branch,
          previous_head_sha: expectedHead, commit_head_sha: commitHead,
        };
      }
      return finishCommissionApplied('APPLIED');

      async function finishCommissionApplied(successCode) {
        let indexSynced = true;
        try { await syncRealIndex(realIndexPath, originalIndex, indexPath); } catch { indexSynced = false; }
        let observed = null;
        try { observed = await workspace(operationId, {observeRemote: false}); } catch { /* known applied */ }
        if (!observed) {
          return {
            schema: 'mastermind.studio_git_commit_result.v1',
            status: 'PARTIAL', effect_state: 'APPLIED',
            code: indexSynced ? 'APPLIED_READBACK_FAILED' : 'APPLIED_INDEX_SYNC_AND_READBACK_FAILED',
            action_ref: ref, operation_id: operationId, branch: before.branch,
            previous_head_sha: expectedHead, commit_head_sha: commitHead, index_synced: indexSynced,
          };
        }
        const current = observed.localHead === commitHead;
        return {
          schema: 'mastermind.studio_git_commit_result.v1',
          status: current && indexSynced ? 'OK' : 'PARTIAL', effect_state: 'APPLIED',
          code: current && indexSynced ? successCode : (current ? 'APPLIED_INDEX_SYNC_FAILED' : 'APPLIED_BUT_SUPERSEDED'),
          action_ref: ref, operation_id: observed.operationId, branch: observed.branch,
          previous_head_sha: expectedHead, commit_head_sha: commitHead,
          local_head_sha: observed.localHead, clean: observed.clean, index_synced: indexSynced,
        };
      }
    } finally {
      try { await remove(scratch, {recursive: true, force: true}); }
      catch (error) { if (!refUpdateAttempted) throw error; }
    }
  }

  async function push(args) {
    if (!args || typeof args !== 'object' || Array.isArray(args) || Object.keys(args).some((key) => !['operation_id', 'expected_head_sha'].includes(key))) {
      throw new TypeError('studio_git_push_current_branch arguments are invalid');
    }
    const operationId = validateOperationId(args.operation_id);
    const expectedHead = validateExpectedHead(args.expected_head_sha);
    const before = await workspace(operationId);
    const ref = actionRef(operationId, before.branch, expectedHead);

    if (before.localHead !== expectedHead) {
      return {
        schema: 'mastermind.studio_git_push_result.v1',
        status: 'REFUSED',
        effect_state: 'NOT_APPLIED',
        code: 'EXPECTED_HEAD_MISMATCH',
        action_ref: ref,
        ...publicStatus(before),
      };
    }
    if (before.remoteHead === expectedHead) {
      return {
        schema: 'mastermind.studio_git_push_result.v1',
        status: 'OK',
        effect_state: 'APPLIED',
        code: 'ALREADY_APPLIED',
        action_ref: ref,
        push_attempted: false,
        ...publicStatus(before),
      };
    }
    if (!before.clean) {
      return {
        schema: 'mastermind.studio_git_push_result.v1',
        status: 'REFUSED',
        effect_state: 'NOT_APPLIED',
        code: 'WORKSPACE_DIRTY',
        action_ref: ref,
        ...publicStatus(before),
      };
    }

    const submodulePolicy = await boundedSubmodulePolicy(before.workspacePath);
    await verifyDestinationBinding(before.remoteBinding);
    try {
      await git(
        before.workspacePath,
        // Push the fenced commit object, never mutable HEAD. A concurrent local
        // branch advance after precheck must not widen the authorized remote effect.
        [...before.remoteBinding.gitArgs, 'push', '--porcelain', '--no-follow-tags', '--no-force', '--no-mirror', `--recurse-submodules=${submodulePolicy}`, 'origin', `${expectedHead}:${before.ref}`],
        { timeoutMs: cfg.pushTimeoutMs },
      );
    } catch (error) {
      try {
        const afterFailure = await workspace(operationId, {remoteBinding: before.remoteBinding});
        if (afterFailure.remoteHead === expectedHead) {
          return {
            schema: 'mastermind.studio_git_push_result.v1',
            status: 'OK',
            effect_state: 'APPLIED',
            code: 'APPLIED_AFTER_AMBIGUOUS_PUSH_RETURN',
            action_ref: ref,
            push_attempted: true,
            ...publicStatus(afterFailure),
          };
        }
      } catch {
        // The attempted remote write remains ambiguous. Do not replace the
        // original effect uncertainty with a readback failure.
      }
      return {
        schema: 'mastermind.studio_git_push_result.v1',
        status: 'UNKNOWN',
        effect_state: 'EFFECT_UNKNOWN',
        code: 'PUSH_RESULT_UNCERTAIN',
        action_ref: ref,
        push_attempted: true,
        operation_id: operationId,
        branch: before.branch,
        local_head_sha: expectedHead,
      };
    }

    try {
      const after = await workspace(operationId, {remoteBinding: before.remoteBinding});
      if (after.remoteHead === expectedHead) {
        return {
          schema: 'mastermind.studio_git_push_result.v1',
          status: 'OK',
          effect_state: 'APPLIED',
          code: 'APPLIED',
          action_ref: ref,
          push_attempted: true,
          ...publicStatus(after),
        };
      }
    } catch {
      // A successful push command followed by failed readback is still
      // ambiguous to the caller. Never call it success without exact ref proof.
    }
    return {
      schema: 'mastermind.studio_git_push_result.v1',
      status: 'UNKNOWN',
      effect_state: 'EFFECT_UNKNOWN',
      code: 'POST_PUSH_READBACK_UNCERTAIN',
      action_ref: ref,
      push_attempted: true,
      operation_id: operationId,
      branch: before.branch,
      local_head_sha: expectedHead,
    };
  }

  return Object.freeze({ status, commit, push, commitCommission, commissionStatus });
}

export function toolResult(value, isError = false) {
  return {
    content: [{ type: 'text', text: JSON.stringify(value, null, 2) }],
    structuredContent: value,
    ...(isError ? { isError: true } : {}),
  };
}
