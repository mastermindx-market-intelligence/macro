(
    <div style={{ backgroundColor: 'var(--mx-light-bg)', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', fontSynthesis: 'none', height: 'fit-content', MozOsxFontSmoothing: 'grayscale', overflow: 'clip', overflowWrap: 'anywhere', WebkitFontSmoothing: 'antialiased', width: '390px' }}>
      <div style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '154px', paddingBottom: '19px', paddingInline: '24px', paddingTop: '21px' }}>
        <div style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', flexBasis: '0%', flexDirection: 'column', flexGrow: '1', justifyContent: 'center' }}>
          <div style={{ boxSizing: 'border-box', color: '#1C2430', display: 'flex', flexWrap: 'wrap', fontFamily: 'system-ui, sans-serif', fontSize: '17px', fontWeight: 600, justifyContent: 'center', lineHeight: '22px', textAlign: 'center', width: 'max-content' }}>
            9:41
          </div>
        </div>
        <div style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', flexBasis: '0%', flexDirection: 'column', flexGrow: '1', justifyContent: 'center' }}>
          <svg width="82" height="22" viewBox="0 0 82 22" xmlns="http://www.w3.org/2000/svg" style={{ flexShrink: '0' }}>
            <path d="M3.7 13H2.5a1 1 0 0 0-1 1v2.5a1 1 0 0 0 1 1h1.2a1 1 0 0 0 1-1V14a1 1 0 0 0-1-1m5.2-2.5H7.7a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1h1.2a1 1 0 0 0 1-1v-5a1 1 0 0 0-1-1M14.1 8h-1.2a1 1 0 0 0-1 1v7.5a1 1 0 0 0 1 1h1.2a1 1 0 0 0 1-1V9a1 1 0 0 0-1-1m5.2-2.5h-1.2a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h1.2a1 1 0 0 0 1-1v-10a1 1 0 0 0-1-1" fill="#1C2430" />
            <path fillRule="evenodd" d="M36.57 7.8c2.49 0 4.88.92 6.68 2.58.14.13.36.12.49 0l1.3-1.27a.34.34 0 0 0 0-.5 12.55 12.55 0 0 0-16.93 0 .34.34 0 0 0 0 .5l1.3 1.26c.13.13.34.14.48 0a10 10 0 0 1 6.68-2.57m0 4.22a5.4 5.4 0 0 1 3.67 1.44c.14.13.35.13.48 0l1.3-1.33a.37.37 0 0 0-.01-.52 7.9 7.9 0 0 0-10.88 0 .37.37 0 0 0 0 .52l1.29 1.32c.13.14.34.14.48 0 1-.92 2.31-1.43 3.67-1.43m2.52 2.8q0 .15-.1.28l-2.18 2.45a.3.3 0 0 1-.24.11.3.3 0 0 1-.24-.1l-2.18-2.46a.43.43 0 0 1 .01-.56 3.44 3.44 0 0 1 4.82 0 .4.4 0 0 1 .11.28" clipRule="evenodd" fill="#1C2430" />
            <path fillRule="evenodd" d="M70.5 5c2.05 0 3.08 0 3.88.34a4.3 4.3 0 0 1 2.28 2.28c.34.8.34 1.83.34 3.88s0 3.08-.34 3.88a4.3 4.3 0 0 1-2.28 2.28c-.8.34-1.83.34-3.88.34h-12c-2.05 0-3.08 0-3.88-.34a4.3 4.3 0 0 1-2.28-2.28c-.34-.8-.34-1.83-.34-3.88s0-3.08.34-3.88a4.3 4.3 0 0 1 2.28-2.28C55.42 5 56.45 5 58.5 5zM58.28 6c-1.85 0-2.77 0-3.48.36a3.3 3.3 0 0 0-1.44 1.44C53 8.5 53 9.43 53 11.28v.44c0 1.85 0 2.77.36 3.48a3.3 3.3 0 0 0 1.44 1.44c.7.36 1.63.36 3.48.36h12.44c1.85 0 2.77 0 3.48-.36a3.3 3.3 0 0 0 1.44-1.44c.36-.7.36-1.63.36-3.48v-.44c0-1.85 0-2.77-.36-3.48a3.3 3.3 0 0 0-1.44-1.44C73.5 6 72.57 6 70.72 6z" clipRule="evenodd" fill="#1C2430" style={{ opacity: '0.35' }} />
            <path d="M54 11c0-1.4 0-2.1.27-2.63a2.5 2.5 0 0 1 1.1-1.1C55.9 7 56.6 7 58 7h13c1.4 0 2.1 0 2.64.27q.72.37 1.09 1.1C75 8.9 75 9.6 75 11v1c0 1.4 0 2.1-.27 2.64a2.5 2.5 0 0 1-1.1 1.09C73.1 16 72.4 16 71 16H58c-1.4 0-2.1 0-2.63-.27a2.5 2.5 0 0 1-1.1-1.1C54 14.1 54 13.4 54 12z" fill="#1C2430" />
            <path d="M78 9.5v4.08a2.2 2.2 0 0 0 1.33-2.04A2.2 2.2 0 0 0 78 9.5" fill="#1C2430" style={{ opacity: '0.35' }} />
          </svg>
        </div>
      </div>
      <div style={{ alignItems: 'center', borderBottomColor: 'var(--mx-light-line)', borderBottomStyle: 'solid', borderBottomWidth: '1px', boxSizing: 'border-box', display: 'flex', justifyContent: 'space-between', paddingBottom: '12px', paddingInline: '16px', width: '100%' }}>
        <div style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '10px' }}>
          <svg width="22" height="22" viewBox="0 0 22 22" xmlns="http://www.w3.org/2000/svg" style={{ flexShrink: '0' }}>
            <rect x="0" y="0" width="9" height="9" rx="2" fill="#45B873" />
            <rect x="12" y="0" width="9" height="9" rx="2" fill="#5B9BF0" />
            <rect x="0" y="12" width="9" height="9" rx="2" fill="#5B9BF0" />
            <rect x="12" y="12" width="9" height="9" rx="2" fill="#45B873" />
          </svg>
          <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: 'var(--font-ui)', fontSize: '13px', fontWeight: 700, letterSpacing: '1px', lineHeight: '16px' }}>
            MASTERMINDX
          </div>
        </div>
        <div style={{ alignItems: 'center', borderColor: 'var(--mx-light-line)', borderRadius: '8px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexShrink: '0', height: '44px', justifyContent: 'center', width: '44px' }}>
          <svg width="18" height="18" viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg" style={{ flexShrink: '0' }}>
            <path d="M2 4H16M2 9H16M2 14H16" fill="none" stroke="#1C2430" strokeWidth="1.5" />
          </svg>
        </div>
      </div>
      <div style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '18px', paddingBottom: '28px', paddingInline: '16px', paddingTop: '22px', width: '100%' }}>
        <div style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '10px', width: '100%' }}>
          <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-warn)', fontFamily: 'var(--font-ui)', fontSize: '11px', fontWeight: 600, letterSpacing: '1px', lineHeight: '14px' }}>
            ILLUSTRATIVE · 25 SEP 2026
          </div>
          <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: 'var(--font-ui)', fontSize: '25px', fontWeight: 600, lineHeight: '32px' }}>
            International Markets
          </div>
          <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '13px', lineHeight: '20px' }}>
            Leadership, drivers and risk across borders.
          </div>
        </div>
        <div style={{ alignItems: 'center', backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '8px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexShrink: '0', height: '46px', justifyContent: 'space-between', paddingInline: '14px', width: '100%' }}>
          <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: 'var(--font-ui)', fontSize: '14px', fontWeight: 600, lineHeight: '18px' }}>
            Overview
          </div>
          <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-link)', fontFamily: 'var(--font-ui)', fontSize: '13px', lineHeight: '16px' }}>
            Research views ▾
          </div>
        </div>
        <div style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '10px', width: '100%' }}>
          <div style={{ boxSizing: 'border-box', display: 'flex', gap: '10px', width: '100%' }}>
            <div style={{ alignItems: 'center', borderColor: 'var(--mx-light-line)', borderRadius: '8px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexBasis: '0%', flexGrow: '1', height: '44px', justifyContent: 'center', minWidth: '0px' }}>
              <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', display: 'flex', fontFamily: 'var(--font-ui)', fontSize: '13px', lineHeight: '16px' }}>
                1 month ▾
              </div>
            </div>
            <div style={{ alignItems: 'center', borderColor: 'var(--mx-light-line)', borderRadius: '8px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexBasis: '0%', flexGrow: '1', height: '44px', justifyContent: 'center', minWidth: '0px' }}>
              <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', display: 'flex', fontFamily: 'var(--font-ui)', fontSize: '13px', lineHeight: '16px' }}>
                USD · Unhedged ▾
              </div>
            </div>
          </div>
          <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '18px' }}>
            7 markets · Price return · S&P 500 benchmark
          </div>
        </div>
        <div style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '14px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px', padding: '18px', width: '100%' }}>
          <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-warn)', fontFamily: 'var(--font-ui)', fontSize: '11px', fontWeight: 600, letterSpacing: '0.8px', lineHeight: '14px' }}>
            SELECTIVE LEADERSHIP
          </div>
          <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: 'var(--font-ui)', fontSize: '24px', fontWeight: 600, letterSpacing: '-0.02em', lineHeight: '31px', whiteSpace: 'pre-wrap' }}>
            Japan leads.<br />Confirmation is uneven.
          </div>
          <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '14px', lineHeight: '22px' }}>
            Japan leads, Taiwan slows and Korea weakens in this sample. Price gains alone do not confirm the economic backdrop.
          </div>
          <div style={{ borderTopColor: 'var(--mx-light-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '16px', justifyContent: 'space-between', paddingTop: '14px' }}>
            <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '19px' }}>
              Positive USD returns
            </div>
            <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-up)', fontFamily: 'var(--font-ui)', fontSize: '15px', fontWeight: 600, lineHeight: '18px' }}>
              6 / 7
            </div>
          </div>
          <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-warn)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '19px' }}>
            Macro coverage varies · Inspect gaps →
          </div>
        </div>
        <div style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: 'var(--r-panel)', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', fontFamily: 'var(--font-ui)', minWidth: '0px', width: '100%' }}>
          <div style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '6px', paddingBlock: '18px', paddingInline: '16px' }}>
            <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: 'var(--font-ui)', fontSize: '18px', fontWeight: 600, lineHeight: '26px' }}>
              Returns in focus
            </div>
            <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '19px', whiteSpace: 'pre-wrap' }}>
              Three highest + lowest of 7 markets.<br />1-month USD price returns · Not picks.
            </div>
          </div>
          <div style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', width: '100%' }}>
            <div style={{ borderTopColor: 'var(--mx-light-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', fontFamily: 'var(--font-ui)', gap: '8px', padding: '16px', width: '100%' }}>
              <div style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '12px', justifyContent: 'space-between', minHeight: '44px' }}>
                <div style={{ boxSizing: 'border-box', display: 'flex', flexBasis: '0%', flexDirection: 'column', flexGrow: '1', gap: '3px', minWidth: '0px' }}>
                  <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: 'var(--font-ui)', fontSize: '16px', fontWeight: 600, lineHeight: '23px' }}>
                    Japan →
                  </div>
                  <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '11px', lineHeight: '18px' }}>
                    JP · TOPIX
                  </div>
                </div>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-up)', fontFamily: 'var(--font-ui)', fontSize: '22px', fontWeight: 600, lineHeight: '30px' }}>
                  +3.73%
                </div>
              </div>
              <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '20px' }}>
                ↑ Strengthening · Macro series delayed
              </div>
            </div>
            <div style={{ borderTopColor: 'var(--mx-light-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', fontFamily: 'var(--font-ui)', gap: '8px', padding: '16px', width: '100%' }}>
              <div style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '12px', justifyContent: 'space-between', minHeight: '44px' }}>
                <div style={{ boxSizing: 'border-box', display: 'flex', flexBasis: '0%', flexDirection: 'column', flexGrow: '1', gap: '3px', minWidth: '0px' }}>
                  <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: 'var(--font-ui)', fontSize: '16px', fontWeight: 600, lineHeight: '23px' }}>
                    Taiwan →
                  </div>
                  <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '11px', lineHeight: '18px' }}>
                    TW · TAIEX
                  </div>
                </div>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-up)', fontFamily: 'var(--font-ui)', fontSize: '22px', fontWeight: 600, lineHeight: '30px' }}>
                  +3.37%
                </div>
              </div>
              <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '20px' }}>
                ↘ Slowing · Participation is narrower
              </div>
            </div>
            <div style={{ borderTopColor: 'var(--mx-light-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', fontFamily: 'var(--font-ui)', gap: '8px', padding: '16px', width: '100%' }}>
              <div style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '12px', justifyContent: 'space-between', minHeight: '44px' }}>
                <div style={{ boxSizing: 'border-box', display: 'flex', flexBasis: '0%', flexDirection: 'column', flexGrow: '1', gap: '3px', minWidth: '0px' }}>
                  <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: 'var(--font-ui)', fontSize: '16px', fontWeight: 600, lineHeight: '23px' }}>
                    Euro area →
                  </div>
                  <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '11px', lineHeight: '18px' }}>
                    EZ · EURO STOXX
                  </div>
                </div>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-up)', fontFamily: 'var(--font-ui)', fontSize: '22px', fontWeight: 600, lineHeight: '30px' }}>
                  +2.81%
                </div>
              </div>
              <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '20px' }}>
                ↑ Improving · Yield series delayed
              </div>
            </div>
            <div style={{ borderTopColor: 'var(--mx-light-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', fontFamily: 'var(--font-ui)', gap: '8px', padding: '16px', width: '100%' }}>
              <div style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '12px', justifyContent: 'space-between', minHeight: '44px' }}>
                <div style={{ boxSizing: 'border-box', display: 'flex', flexBasis: '0%', flexDirection: 'column', flexGrow: '1', gap: '3px', minWidth: '0px' }}>
                  <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: 'var(--font-ui)', fontSize: '16px', fontWeight: 600, lineHeight: '23px' }}>
                    South Korea →
                  </div>
                  <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '11px', lineHeight: '18px' }}>
                    KR · KOSPI
                  </div>
                </div>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-down)', fontFamily: 'var(--font-ui)', fontSize: '22px', fontWeight: 600, lineHeight: '30px' }}>
                  −2.59%
                </div>
              </div>
              <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '20px' }}>
                ↓ Weakening · Local and USD returns fell
              </div>
            </div>
          </div>
          <div style={{ backgroundColor: 'var(--mx-light-panel2)', borderBottomLeftRadius: 'var(--r-panel)', borderBottomRightRadius: 'var(--r-panel)', borderTopColor: 'var(--mx-light-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', fontFamily: 'var(--font-ui)', gap: '10px', padding: '16px' }}>
            <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '20px' }}>
              Includes United Kingdom, India and Australia, with local returns and FX attribution.
            </div>
            <div style={{ alignItems: 'center', borderColor: 'var(--mx-light-line)', borderRadius: 'var(--r-ctl)', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '44px', paddingBlock: '10px', paddingInline: '12px', textAlign: 'center' }}>
              <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-link)', display: 'flex', fontFamily: 'var(--font-ui)', fontSize: '14px', fontWeight: 500, lineHeight: '22px', textAlign: 'center' }}>
                Expand all 7 markets ↓
              </div>
            </div>
          </div>
        </div>
        <div style={{ boxSizing: 'border-box', display: 'none', width: '100%' }}>
          <div style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', height: '44px', justifyContent: 'space-between', width: '100%' }}>
            <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: 'var(--font-ui)', fontSize: '17px', fontWeight: 600, lineHeight: '22px' }}>
              Markets at a glance
            </div>
            <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-link)', fontFamily: 'var(--font-ui)', fontSize: '13px', lineHeight: '16px' }}>
              Compare
            </div>
          </div>
          <div style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px', padding: '16px', width: '100%' }}>
            <div style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '12px', justifyContent: 'space-between', width: '100%' }}>
              <div style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '5px' }}>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: 'var(--font-ui)', fontSize: '15px', fontWeight: 600, lineHeight: '18px' }}>
                  Japan
                </div>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '16px' }}>
                  JP · TOPIX
                </div>
              </div>
              <div style={{ alignItems: 'end', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '5px' }}>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-up)', fontFamily: 'var(--font-ui)', fontSize: '22px', fontWeight: 600, lineHeight: '28px' }}>
                  +3.73%
                </div>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '11px', lineHeight: '14px' }}>
                  USD · 1M
                </div>
              </div>
            </div>
            <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '18px' }}>
              Local +5.20% · FX effect −1.47 pp
            </div>
            <div style={{ alignItems: 'center', borderTopColor: 'var(--mx-light-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '10px', justifyContent: 'space-between', paddingTop: '10px', width: '100%' }}>
              <div style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '5px' }}>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-up)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '16px' }}>
                  ↑ Strengthening
                </div>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-warn)', fontFamily: 'var(--font-ui)', fontSize: '11px', lineHeight: '14px' }}>
                  Macro series delayed
                </div>
              </div>
              <div style={{ alignItems: 'center', borderColor: 'var(--mx-light-line)', borderRadius: '8px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexShrink: '0', height: '44px', justifyContent: 'center', width: '76px' }}>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-link)', display: 'flex', fontFamily: 'var(--font-ui)', fontSize: '13px', lineHeight: '16px' }}>
                  Inspect →
                </div>
              </div>
            </div>
          </div>
          <div style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px', padding: '16px', width: '100%' }}>
            <div style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '12px', justifyContent: 'space-between', width: '100%' }}>
              <div style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '5px' }}>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: 'var(--font-ui)', fontSize: '15px', fontWeight: 600, lineHeight: '18px' }}>
                  Taiwan
                </div>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '16px' }}>
                  TW · TAIEX
                </div>
              </div>
              <div style={{ alignItems: 'end', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '5px' }}>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-up)', fontFamily: 'var(--font-ui)', fontSize: '22px', fontWeight: 600, lineHeight: '28px' }}>
                  +3.37%
                </div>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '11px', lineHeight: '14px' }}>
                  USD · 1M
                </div>
              </div>
            </div>
            <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '18px' }}>
              Local +4.10% · FX effect −0.73 pp
            </div>
            <div style={{ alignItems: 'center', borderTopColor: 'var(--mx-light-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '10px', justifyContent: 'space-between', paddingTop: '10px', width: '100%' }}>
              <div style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '5px' }}>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-warn)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '16px' }}>
                  ↘ Slowing
                </div>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-warn)', fontFamily: 'var(--font-ui)', fontSize: '11px', lineHeight: '14px' }}>
                  Macro coverage limited
                </div>
              </div>
              <div style={{ alignItems: 'center', borderColor: 'var(--mx-light-line)', borderRadius: '8px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexShrink: '0', height: '44px', justifyContent: 'center', width: '76px' }}>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-link)', display: 'flex', fontFamily: 'var(--font-ui)', fontSize: '13px', lineHeight: '16px' }}>
                  Inspect →
                </div>
              </div>
            </div>
          </div>
          <div style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px', padding: '16px', width: '100%' }}>
            <div style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '12px', justifyContent: 'space-between', width: '100%' }}>
              <div style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '5px' }}>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: 'var(--font-ui)', fontSize: '15px', fontWeight: 600, lineHeight: '18px' }}>
                  Euro area
                </div>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '16px' }}>
                  EZ · EURO STOXX
                </div>
              </div>
              <div style={{ alignItems: 'end', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '5px' }}>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-up)', fontFamily: 'var(--font-ui)', fontSize: '22px', fontWeight: 600, lineHeight: '28px' }}>
                  +2.81%
                </div>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '11px', lineHeight: '14px' }}>
                  USD · 1M
                </div>
              </div>
            </div>
            <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '18px' }}>
              Local +2.60% · FX effect +0.21 pp
            </div>
            <div style={{ alignItems: 'center', borderTopColor: 'var(--mx-light-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '10px', justifyContent: 'space-between', paddingTop: '10px', width: '100%' }}>
              <div style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '5px' }}>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-up)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '16px' }}>
                  ↑ Improving
                </div>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-warn)', fontFamily: 'var(--font-ui)', fontSize: '11px', lineHeight: '14px' }}>
                  Yield series delayed
                </div>
              </div>
              <div style={{ alignItems: 'center', borderColor: 'var(--mx-light-line)', borderRadius: '8px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexShrink: '0', height: '44px', justifyContent: 'center', width: '76px' }}>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-link)', display: 'flex', fontFamily: 'var(--font-ui)', fontSize: '13px', lineHeight: '16px' }}>
                  Inspect →
                </div>
              </div>
            </div>
          </div>
          <div style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px', padding: '16px', width: '100%' }}>
            <div style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '12px', justifyContent: 'space-between', width: '100%' }}>
              <div style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '5px' }}>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: 'var(--font-ui)', fontSize: '15px', fontWeight: 600, lineHeight: '18px' }}>
                  United Kingdom
                </div>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '16px' }}>
                  GB · FTSE 100
                </div>
              </div>
              <div style={{ alignItems: 'end', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '5px' }}>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-up)', fontFamily: 'var(--font-ui)', fontSize: '22px', fontWeight: 600, lineHeight: '28px' }}>
                  +2.39%
                </div>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '11px', lineHeight: '14px' }}>
                  USD · 1M
                </div>
              </div>
            </div>
            <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '18px' }}>
              Local +2.80% · FX effect −0.41 pp
            </div>
            <div style={{ alignItems: 'center', borderTopColor: 'var(--mx-light-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '10px', justifyContent: 'space-between', paddingTop: '10px', width: '100%' }}>
              <div style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '5px' }}>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '16px' }}>
                  → Steady
                </div>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-warn)', fontFamily: 'var(--font-ui)', fontSize: '11px', lineHeight: '14px' }}>
                  Macro series delayed
                </div>
              </div>
              <div style={{ alignItems: 'center', borderColor: 'var(--mx-light-line)', borderRadius: '8px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexShrink: '0', height: '44px', justifyContent: 'center', width: '76px' }}>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-link)', display: 'flex', fontFamily: 'var(--font-ui)', fontSize: '13px', lineHeight: '16px' }}>
                  Inspect →
                </div>
              </div>
            </div>
          </div>
          <div style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px', padding: '16px', width: '100%' }}>
            <div style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '12px', justifyContent: 'space-between', width: '100%' }}>
              <div style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '5px' }}>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: 'var(--font-ui)', fontSize: '15px', fontWeight: 600, lineHeight: '18px' }}>
                  India
                </div>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '16px' }}>
                  IN · NIFTY 50
                </div>
              </div>
              <div style={{ alignItems: 'end', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '5px' }}>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-up)', fontFamily: 'var(--font-ui)', fontSize: '22px', fontWeight: 600, lineHeight: '28px' }}>
                  +1.67%
                </div>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '11px', lineHeight: '14px' }}>
                  USD · 1M
                </div>
              </div>
            </div>
            <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '18px' }}>
              Local +2.90% · FX effect −1.23 pp
            </div>
            <div style={{ alignItems: 'center', borderTopColor: 'var(--mx-light-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '10px', justifyContent: 'space-between', paddingTop: '10px', width: '100%' }}>
              <div style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '5px' }}>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '16px' }}>
                  → Steady
                </div>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-warn)', fontFamily: 'var(--font-ui)', fontSize: '11px', lineHeight: '14px' }}>
                  Key macro inputs missing
                </div>
              </div>
              <div style={{ alignItems: 'center', borderColor: 'var(--mx-light-line)', borderRadius: '8px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexShrink: '0', height: '44px', justifyContent: 'center', width: '76px' }}>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-link)', display: 'flex', fontFamily: 'var(--font-ui)', fontSize: '13px', lineHeight: '16px' }}>
                  Inspect →
                </div>
              </div>
            </div>
          </div>
          <div style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px', padding: '16px', width: '100%' }}>
            <div style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '12px', justifyContent: 'space-between', width: '100%' }}>
              <div style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '5px' }}>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: 'var(--font-ui)', fontSize: '15px', fontWeight: 600, lineHeight: '18px' }}>
                  Australia
                </div>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '16px' }}>
                  AU · ASX 200
                </div>
              </div>
              <div style={{ alignItems: 'end', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '5px' }}>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-up)', fontFamily: 'var(--font-ui)', fontSize: '22px', fontWeight: 600, lineHeight: '28px' }}>
                  +1.09%
                </div>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '11px', lineHeight: '14px' }}>
                  USD · 1M
                </div>
              </div>
            </div>
            <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '18px' }}>
              Local +1.60% · FX effect −0.51 pp
            </div>
            <div style={{ alignItems: 'center', borderTopColor: 'var(--mx-light-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '10px', justifyContent: 'space-between', paddingTop: '10px', width: '100%' }}>
              <div style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '5px' }}>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '16px' }}>
                  → Steady
                </div>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-warn)', fontFamily: 'var(--font-ui)', fontSize: '11px', lineHeight: '14px' }}>
                  Macro series delayed
                </div>
              </div>
              <div style={{ alignItems: 'center', borderColor: 'var(--mx-light-line)', borderRadius: '8px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexShrink: '0', height: '44px', justifyContent: 'center', width: '76px' }}>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-link)', display: 'flex', fontFamily: 'var(--font-ui)', fontSize: '13px', lineHeight: '16px' }}>
                  Inspect →
                </div>
              </div>
            </div>
          </div>
          <div style={{ backgroundColor: 'var(--mx-light-panel)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '12px', padding: '16px', width: '100%' }}>
            <div style={{ alignItems: 'center', boxSizing: 'border-box', display: 'flex', gap: '12px', justifyContent: 'space-between', width: '100%' }}>
              <div style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '5px' }}>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: 'var(--font-ui)', fontSize: '15px', fontWeight: 600, lineHeight: '18px' }}>
                  South Korea
                </div>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '16px' }}>
                  KR · KOSPI
                </div>
              </div>
              <div style={{ alignItems: 'end', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '5px' }}>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-down)', fontFamily: 'var(--font-ui)', fontSize: '22px', fontWeight: 600, lineHeight: '28px' }}>
                  −2.59%
                </div>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '11px', lineHeight: '14px' }}>
                  USD · 1M
                </div>
              </div>
            </div>
            <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '18px' }}>
              Local −1.80% · FX effect −0.79 pp
            </div>
            <div style={{ alignItems: 'center', borderTopColor: 'var(--mx-light-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', gap: '10px', justifyContent: 'space-between', paddingTop: '10px', width: '100%' }}>
              <div style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '5px' }}>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-down)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '16px' }}>
                  ↓ Weakening
                </div>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-warn)', fontFamily: 'var(--font-ui)', fontSize: '11px', lineHeight: '14px' }}>
                  Macro coverage limited
                </div>
              </div>
              <div style={{ alignItems: 'center', borderColor: 'var(--mx-light-line)', borderRadius: '8px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexShrink: '0', height: '44px', justifyContent: 'center', width: '76px' }}>
                <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-link)', display: 'flex', fontFamily: 'var(--font-ui)', fontSize: '13px', lineHeight: '16px' }}>
                  Inspect →
                </div>
              </div>
            </div>
          </div>
          <div style={{ boxSizing: 'border-box', display: 'flex', flexDirection: 'column', fontFamily: 'var(--font-ui)', gap: '8px', paddingBlock: '14px', width: '100%' }}>
            <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', display: 'flex', flexWrap: 'wrap', fontFamily: 'var(--font-ui)', fontSize: '12px', justifyContent: 'center', lineHeight: '20px', textAlign: 'center' }}>
              All 7 markets · Your view is unchanged
            </div>
            <div style={{ alignItems: 'center', borderColor: 'var(--mx-light-line)', borderRadius: 'var(--r-ctl)', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', justifyContent: 'center', minHeight: '44px', paddingBlock: '10px', paddingInline: '14px', textAlign: 'center' }}>
              <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-link)', display: 'flex', fontFamily: 'var(--font-ui)', fontSize: '14px', lineHeight: '22px', textAlign: 'center' }}>
                Collapse to summary ↑
              </div>
            </div>
          </div>
        </div>
        <div style={{ backgroundColor: 'var(--mx-light-panel2)', borderColor: 'var(--mx-light-line)', borderRadius: '12px', borderStyle: 'solid', borderWidth: '1px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '14px', padding: '20px', width: '100%' }}>
          <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-text)', fontFamily: 'var(--font-ui)', fontSize: '17px', fontWeight: 600, lineHeight: '24px' }}>
            Look beneath the index
          </div>
          <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '13px', lineHeight: '20px' }}>
            Sample participation: Japan 61%, Taiwan 41%, Korea 38%. Similar index returns can hide different market internals.
          </div>
          <div style={{ alignContent: 'center', boxSizing: 'border-box', color: 'var(--mx-light-ink-link)', fontFamily: 'var(--font-ui)', fontSize: '13px', lineHeight: '16px', minHeight: '44px' }}>
            Participation & concentration →
          </div>
          <div style={{ alignItems: 'center', borderTopColor: 'var(--mx-light-line)', borderTopStyle: 'solid', borderTopWidth: '1px', boxSizing: 'border-box', display: 'flex', minHeight: '44px' }}>
            <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-ink-link)', display: 'flex', fontFamily: 'var(--font-ui)', fontSize: '13px', lineHeight: '16px' }}>
              Explore all 18 research tools →
            </div>
          </div>
        </div>
        <div style={{ boxSizing: 'border-box', color: 'var(--mx-light-muted)', fontFamily: 'var(--font-ui)', fontSize: '12px', lineHeight: '19px', whiteSpace: 'pre-wrap' }}>
          Illustrative snapshot · 25 Sep 2026<br />FX effect is in percentage points.<br />Not an allocation recommendation.
        </div>
      </div>
    </div>
  )