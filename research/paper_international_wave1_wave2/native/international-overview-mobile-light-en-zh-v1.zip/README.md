# Overview mobile light reference capture

Captured read-only from M2 Paper on 2026-10-06 around 12:09 UTC. File `01M3P1TW5Y3XWQC37ADDS8K5AG`, expected inspection guard `8636c956d5e42984d3cf6f7cc3d186f84ebc288ca2ce942cad3190c0b09891cb`; token contentHash `501cd923` is not a whole-file revision.

Targets: `101-0` (English) and `14I-0` (Chinese), Overview mobile light artboards. Each target's inline JSX was read before and after its native screenshot and was byte-identical. Target manifests bind actual JSX and screenshot SHA-256 values. This is bounded per-node evidence, not an atomic whole-file snapshot.

Both screenshots were visually inspected: cool gray canvas, white primary panels, hairline borders, dark ink, restrained green/red returns, subdued blue actions and warm qualification copy. The Chinese version retains the same section and action hierarchy at 390px. These are design references, not browser or product acceptance. Desktop, actual browser interaction, application data and production theme parity remain unverified.

The visible values, seven-market claims, participation percentages and TOPIX label are illustrative. They must not replace the actual source owner's instruments, availability or qualification rules. In particular the current country owner uses Nikkei for JP.

No Paper edits were made. Held nodes 3C4-0/3WS-0/3YE-0/400-0 were not accessed. No alternate browser/host was used to evade the previously reported live browser administrator block.
