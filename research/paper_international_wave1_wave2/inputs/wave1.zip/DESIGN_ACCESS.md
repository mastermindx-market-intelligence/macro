# Paper access and portable worker design inputs

## The recommended access model

**Astra/Sol or a delegated admitted design reader uses Paper; most leaf workers use a frozen, minimal evidence bundle.** Workers do not need to share the M2 desktop or have ambient access to every Paper file. A numerical/projection worker normally needs only the contract, fixture and source code. A frontend worker receives the relevant native screenshot, JSX and tokens; an independent visual reviewer must have actual visual capability and candidate-browser evidence.

Paper's official [MCP documentation](https://paper.design/docs/mcp) describes local-desktop MCP integration. The [build log](https://paper.design/build-log), consulted for this audit, did not establish a generally available remote-MCP path that can simply be assumed for all fleet workers. The live current Mastermind Paper adapter demonstrably supports bounded file/page reads, native screenshots and JSX. That local success does **not** prove every provider/harness has an admitted Paper or M2 grant.

Do not build a new tunnel/listener/gateway, share desktop credentials or bypass the existing adapter's export/file-transition restrictions to solve this. Use the existing admitted artifact transport. A direct worker Paper grant can be useful for a justified design task, but it must be explicitly bound to the correct carrier, file and action scope.

## What was actually exported

Seven native reference pairs are now frozen on the M2. Each includes a **JPEG screenshot and native inline-style JSX**. The pack also includes five native specification receipts, the complete six-file/78-page/1,589-artboard directory census, token reference metadata, an input manifest and per-file hashes. It contains no font files, credentials, account configuration or live financial-provider bodies.

| Asset directory | Paper node | Role |
|---|---|---|
| `boards/overview-desktop/` | `1-0` | Current compact desktop overview |
| `boards/overview-mobile/` | `VK-0` | Current 390px overview |
| `boards/compare-desktop/` | `6G-0` | Desktop comparison |
| `boards/compare-mobile/` | `2AM-0` | 390px comparison |
| `boards/inspector-desktop/` | `805-0` | Desktop market read |
| `boards/evidence-desktop/` | `8AM-0` | Field evidence within the same inspector |
| `boards/inspector-mobile/` | `50H-0` | 320px market inspector |

All seven are in [R10 page p-2-0](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG?page=p-2-0). Native references are design inputs, not produced-website screenshots. The displayed chat preview of the long 320px inspector was resized to fit; use the actual packaged native image/JSX for implementation dimensions.

### Verified M2 archive

```text
/Volumes/Mastermind/agent-evidence/paper-implementation-census-20261006-c3/
  international-r10-native-design-pack-v2.zip

Size: 1,014,330 bytes
SHA256: 53687f06fa83b26d9194d37b53df026075e62e57cd2c0521790ab072cd65c677
Created: 2026-10-06T05:52:26.783776+00:00
Native reference pairs: 7
Hashed payload files: 22 (plus manifest and SHA256SUMS)
ZIP integrity and all payload hashes: verified PASS
Font files: 0
```

Expanded source: the adjacent `worker-design-pack-v2/` directory. Archive receipt: `design-pack-v2-receipt.json`. Original raw reads remain in the same evidence root. The earlier five-reference archive is superseded for this handoff; it was not overwritten.

**This M2 archive is not embedded in the ChatGPT handoff ZIP.** The downloadable handoff ZIP contains plans, census, contract, provenance and verification. An admitted Astra/Sol session on M2 can consume the native archive at this exact path. Cross-host delivery to a worker has **not** been proven or claimed. The receiving project lead must use the existing approved artifact carrier and verify the same digest at the destination. Do not treat this host path as a sandbox download link or pretend a provider has received it.

## What each worker should receive

- IM-00 numerical/projection workers: source contract, exact fixtures and relevant code; normally no screenshots needed.
- IM-01 visual workers: overview desktop/mobile pairs, contract §§compact selection and metadata, actual shared tokens, and assigned variant references.
- IM-02 visual workers: comparison desktop/mobile pairs, exact chart/attribution contract and current primitives.
- IM-03 visual workers: inspector desktop/mobile and evidence desktop pairs, plus `5IR-0` §§08–09 and the source-gap rules.

Use the full directory census only for the project lead's navigation. Do not dump 1,589 artboards into every leaf context. Additional light/ZH/tablet/error variants are explicitly identified in the handoffs but not all captured or visually approved here. A bounded design reader can export only the required additional nodes; that is targeted acceptance work, not another portfolio census.

## Export method and drift discipline

The successful path used the **guarded adapter's read actions** `get_screenshot` and `get_jsx(format="inline-styles")`. The adapter's `--artifact-dir` option wrote the returned screenshot payload locally. This is not native host export, Paper mutation, file transition or raw-upstream bypass. The target was explicitly bound by file ID and node ID.

Reference method for an already admitted operator, with its locally registered bridge path:

```sh
python3 "$ADMITTED_PAPER_BRIDGE" read --tool get_screenshot \
  --arguments '{"fileId":"01M3P1TW5Y3XWQC37ADDS8K5AG","nodeId":"1-0","scale":1}' \
  --artifact-dir "$ASSIGNED_EVIDENCE_ROOT/overview-desktop"

python3 "$ADMITTED_PAPER_BRIDGE" read --tool get_jsx \
  --arguments '{"fileId":"01M3P1TW5Y3XWQC37ADDS8K5AG","nodeId":"1-0","format":"inline-styles"}'
```

These commands describe the observed capability, not a grant to an unadmitted worker. Do not substitute another user's bridge path, credentials or browser. Hash the outputs and retain exact file/page/node identity. Read the current catalog only if a materially new action/schema is needed.

The captures were separate reads, **not an atomic full-document revision**. `501cd923` is the observed token hash only. A style-token match does not prove layout/text identity. Freeze the exported artifact digests for implementation. A later design change needs an explicit changed-node comparison and re-export of affected references, not automatic replacement of accepted packets.

JSX exports are source references. Translate them to the existing Jinja/CSS/JavaScript architecture; remove illustrative values, bind real contracts, replace duplicated inline styling with scoped accepted tokens, and implement actual interactions. Do not ship an image of the design as the page or mount a parallel React app simply because JSX was exported.

## Acceptance boundaries

An exported file proves export. A verified archive proves bytes and integrity. A delivered archive proves delivery only. Neither proves worker comprehension, source compatibility, UI correctness, data rights, live freshness, monitoring or deployment. The handoff's actual browser and source gates remain necessary.
