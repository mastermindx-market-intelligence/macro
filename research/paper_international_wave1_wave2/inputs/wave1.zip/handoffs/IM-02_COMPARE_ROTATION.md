# IM-02 — Compare & Rotation

**Disposition:** specified for bounded implementation; exact-data extension and common-window policy are explicit prerequisites.  
**Owner:** International comparison lead under Sol International CEO.  
**Depends on:** IM-00 source/view contracts; IM-03 for evidence/inspector navigation.  
**Outcome:** compare 2–4 markets on a genuinely comparable return basis, separate local-price performance from currency contribution, and inspect current relative leadership without confusing it with capital flows, economic confirmation or investment instructions.

## 1. Design inputs and authority

[Paper R10 comparison and inspector page](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG?page=p-2-0).

| Node | Reference | Evidence scope |
|---|---|---|
| `6G-0` | Desktop Compare & Rotation, 1440 | Visual + native JSX/JPEG frozen |
| `2AM-0` | Mobile Compare, 390 | Visual + native JSX/JPEG frozen |
| `5IR-0` | Shared inspector/return/context rules | Native spec read |
| `A6K-0`, `ACB-0` | Same-sector-mix desktop/320 | Directory only; **not** permission to build a new factor model |
| `9ML-0`, `9SC-0`, `9XE-0` | Company exposure and transmission references | Separate source-qualification programme, not this packet |

[Methodology specifications](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG?page=p-1-0): `P9-0`, `Q2-0`, `R0-0`, `2FN-0`. The visible chart and percentages are illustrative. They specify presentation; they do not supply real series, benchmark returns or breadth.

Audited current owners: `engine/intl_performance.py`, `engine/intl_rotation.py`, `scripts/build_intl.py`, `templates/intl.html.j2`; immutable pin and links in `SOURCE_AUDIT.md`. Preserve current numerical tests, the existing rotation formula and the separate weekly-correlation method.

## 2. Product composition

Desktop uses a compact selection/context bar, a large normalized-price chart, a local/FX/USD attribution table, a current rotation/context section and progressively disclosed advanced research. Mobile uses readable market selectors, one chart, a compact attribution comparison and deeper evidence links. Never force a four-country desktop grid into 320px typography.

The user should be able to answer: “Which selected market performed better over the same actual interval? How much of that difference came from currency? Does current source-owned relative leadership agree, and what does the evidence not cover?” Do not conflate the answer with “which should I buy?”

Proposed implementation partial `templates/intl_workspace/compare.html.j2`; proposed suite `tests/test_intl_workspace_compare.py`; controller integration through IM-00's one state owner. The numerical/source extension is owned by IM-00-T1, not copied into this component.

## 3. Selection and window state

Preserve an ordered set of up to four unique canonical market IDs. Two to four valid selections enable comparison; fewer show a useful incomplete-selection state. The fifth selection produces an explicit capacity message with a named removal action; it never silently replaces an existing pin.

At mobile width, two foreground series/selectors are the default readable presentation, but any third/fourth pins must remain in state. Use an explicit visible-series selector or alternative small-multiple/table disclosure within the same comparison—not silent deletion on resize. Each hidden series remains named and retrievable. Do not render more lines than can be identified accessibly.

Horizon, currency basis, return basis, benchmark and source generation are one common context. Supported options come from the real owner. Hedged and total-return modes remain unavailable unless the actual data contract supports them. Changing a selector is presentation/calculation over already available admitted data; it does not refresh collectors or create history.

A selected market with stale/unsupported common-window data stays selected with an explanation. Do not silently remove it and report a different comparison. The user can choose to compare the remaining qualified subset, which must be explicit and reflected in the denominator and URL/state.

## 4. Chart: implement the real object, not the sample path

The current `_spark` helper returns an approximately 64-point trailing-year sample without timestamps. It cannot be stretched into this selected-period chart. Consume the timestamped, identity-qualified series from the compatible existing-owner extension in IM-00.

Every plotted line must bind market/index identity, actual timestamps, the same admitted start/end policy, local/USD basis, price/total-return basis, source generation, and a valid positive normalization base. Normalize to 100 at the actual shared start. Retain exact endpoints during downsampling; show gaps rather than inventing interpolated evidence. Axis labels describe real dates and units. Current selected-period headline numbers must reconcile to the same endpoint data or explicitly disclose a different owner horizon.

The default is a lightweight chart using existing accepted application chart primitives where they fit. Do not add a heavyweight framework solely for this chart. If no suitable primitive exists, a scoped SVG implementation with actual data and a parallel accessible table is sufficient; the project lead owns that ordinary reversible choice. Tooltips must work by keyboard and touch, not hover alone. Series use labels and line patterns as well as color. Reduced motion must not animate through fabricated intermediate financial values.

A benchmark may be plotted or shown as a textual reference, but the choice is explicit; the mobile reference says the benchmark is not plotted. Actual benchmark identity and any SPY substitution remain visible. Missing/unqualified benchmark does not authorize an unlabeled fallback; either withhold the reference or show its source gap while retaining valid market comparisons. No comparison to a total-return benchmark under a price-return label without explicit accepted treatment.

**No-data cases:** no shared window, insufficient history, zero/invalid base, unsupported basis, stale endpoints, missing FX, source denied, or numerical failure. Each has an explanatory state and accessible individual evidence, not a flat line at 100. A zero return is a valid flat line and must not be confused with missing data.

## 5. Attribution and comparison explanations

For each selected market, present qualified local return (%), FX contribution (percentage points), and USD return (%). Compute before rounding. Never label `USD minus local` as raw FX return. The underlying identity is:

```text
USD decimal return = (1 + local decimal return) * (1 + FX decimal return in USD/local) - 1
FX contribution in pp = 100 * (USD decimal return - local decimal return)
```

A statement such as “currency narrowed Japan's lead” requires qualified common-window legs for both markets. Derive the change in return spread: `(A_usd - B_usd) - (A_local - B_local)`, with units and source basis preserved. Emit the statement only if the data qualify and its direction is unambiguous at display precision. Prefer showing the arithmetic/evidence over inventing narrative confidence.

If local returns qualify but FX does not, show local comparison independently and withhold the USD attribution. Don’t zero-fill currency. When one market's index identity differs from the fixture, use the real name everywhere. No source-observation precision is gained by formatting additional decimals.

An evidence action opens the same inspector's calculation/evidence view with selected field and return context. It does not launch a second generic modal or reset the chosen pair.

## 6. Rotation: retain meaning, withhold unsupported history

The existing `intl_rotation.rank()` is a descriptive display score with frozen relative-strength weights, state governors and penalties. It is **not** the ranking of whichever one-month return the chart displays. Label the methods distinctly: “Selected-period return order” versus “Current rotation context”, each with its actual window/benchmark.

Preserve the existing formula and source-owned turn notes. Do not add a macro gate, change weights or convert its score into probability, confidence, sizing or a trading rule. Missing relative-strength inputs may currently be converted to zero internally; the new view must not infer complete qualification from a populated score alone. Require its real source-quality evidence or label the limitation.

The mockup's `#4 → #1` arrows require two compatible, existing historical rank snapshots with definition, universe, basis and chronology. This audit did not establish that owner. Default these arrows to unavailable with current rank shown separately. Do **not** create a historical ledger or reconstruct what was supposedly known at the time from today's revised inputs.

Retain the existing relative-strength quadrant view under an advanced disclosure, including exact benchmark and its own method. Rank movement is relative price change, not capital flow. Keep weekly correlation under its own explicitly labeled horizon; a one-month page selector cannot relabel a one-year weekly correlation matrix.

## 7. Participation, concentration and sector mix

“Share of constituents above their 50-day average” needs an actual constituent population, date, denominator, rights, lookback and selection method. The mockup's 61%/41% is not supplied by the new chart. Do not substitute “markets above 200-day average” or a current security list for point-in-time constituent breadth.

When the source owner is absent, retain an elegant “Coverage not yet available” explanation and valid existing research links. Same-sector-mix attribution, earnings revisions, valuation, concentration, economic exposure and residual factors need their own accepted source contracts. This packet does not manufacture them to fill an attractive card. Do not imply all deeper research is missing merely because these particular stronger objects are unqualified.

## 8. Worker packets

| Job | Deliverable | Exact boundary |
|---|---|---|
| IM02-T1 | Chart component + accessible table and state fixtures | Comparison partial/component and focused tests; consumes IM-00 series contract |
| IM02-T2 | Attribution table + deterministic spread explanation | Comparison presentation code/tests; no duplicate financial engine |
| IM02-T3 | Selection/responsive hooks, rotation disclosure | Assigned controller interface and compare CSS; no shared builder ownership |
| IM02-T4 | Independent numerical/visual acceptance | Read-only actual candidate and evidence; reject endpoint, identity and missing-data tricks |

T1 and T2 can execute independently only with distinct files or a serialized shared partial. The project lead integrates before T3 final interaction review. Escalate mathematical/source-policy contradictions to Sol; don’t ask Astra to inspect screenshots or tune chart margins.

## 9. Required proof

**Data tests:** FX orientation; identical/common endpoints; near-tie precision; all-zero legitimate returns; zero starting price refused; empty/gapped series; preserved sampled endpoints; timezone/date labels; unequal windows; real Nikkei identity; substituted benchmark; missing FX with local data; denied data absent from JSON; wrong unit and NaN/bool rejection.

**Interaction:** 1/2/4/5 selections; duplicate selection; explicit removal; missing selected market retained; mobile foreground-series changes do not drop pins; resize; period/basis switches; keyboard/touch chart detail; Back from evidence; safe direct URL; no-JS table; reload performs no write.

**Semantic:** current rotation method stays distinct from return order; no new macro gate or score change; historical arrows absent without valid source; correlation keeps weekly method/window; constituent breadth not approximated from another field; all-negative copy truthful; spread explanation suppressed on incomparable data.

**Actual browser:** 1440/768/390/320, dark/light, EN/ZH, 200% text, reduced motion, contrast/focus and no body overflow. Inspect the exact mobile composition, not just a scaled desktop screenshot. Compare chart endpoints to the rendered table and source fixture in the same run.

**Regression:** existing performance/rotation/build/mobile/session suites plus new compare tests and real page integration. Tests must invoke the actual component/projection/calculation under review. Register the suite with the existing CI owner and show a known-bad fixture that fails. Synthetic fixtures prove behavior, not market predictive value or live data freshness.

## 10. Return and release boundary

Return source head, source-series contract reference, exact chart/table reconciliation, known-bad/positive controls, current rotation compatibility, responsive captures, feature-preservation result and the remaining source gaps. IM-00's release/rollback rules apply. No active monitor, saved research write, new forecast, ledger or provider is enabled here. The live browser gate remains unresolved until a genuinely permitted operator can prove the actual served journey.
