# IM-01 — International Markets Overview

**Disposition:** ready to assign as a bounded design-to-source build after IM-00 contracts and source custody are accepted. This is not release approval.  
**Page owner:** International project lead under Sol International CEO.  
**Depends on:** IM-00; inspector actions depend on IM-03.  
**User outcome:** in one first read, understand which covered markets have the strongest and weakest comparable returns, how currency affected them, and what evidence limits the conclusion. Reach all existing detail without confronting it all at once.

## 1. Exact design authority and source inputs

[Open the authoritative R10 journey page](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG?page=p-2-0).

| Node | Reference | Review status in this census |
|---|---|---|
| `1-0` | Overview desktop 1440, dark EN | Visually inspected; JPEG + native JSX frozen |
| `VK-0` | Overview 390, dark EN | Visually inspected; JPEG + native JSX frozen |
| `268-0` | Overview tablet 768 | Directory verified; not visually accepted in this wave |
| `101-0`, `18Z-0`, `14I-0` | 390 light EN / dark ZH / light ZH | Directory verified; exact implementation comparison still required |
| `1QV-0`, `1ME-0`, `1DG-0`, `1HX-0` | 320 dark EN / light EN / dark ZH / light ZH | Directory verified; stress references, not redundant product pages |
| `1VC-0`, `1ZF-0`, `20S-0`, `1Y2-0` | Mobile views/navigation variants | Directory verified |
| `2D5-0`, `2EJ-0` | Coverage and source-unavailable states | Directory verified |
| `5IR-0` §§08–09 | Inspector and progressive overview behavior | Native specification read in full |

Use `1-0` as the overview composition authority. The old full-table background behind desktop inspector `805-0` must **not** replace it. All sample values, dates, market winners and coverage percentages are fixture content.

Current source seams: `scripts/build_intl.py`, `templates/intl.html.j2`, `engine/intl_performance.py`, `engine/intl_market_state.py`, `engine/intl_compare.py`. See the immutable source links and 18-family map in `SOURCE_AUDIT.md`. Do not read the full repository again.

## 2. Screen composition and reading order

### Desktop

Reuse the actual site shell, theme, locale, product navigation and authentication affordances. Do not rebuild a competing header from the mockup. Below it, compose:

1. **Identity and context:** title, one plain-language sentence, source/date qualification and research actions whose real owners exist. A save/export-looking control is not permission to invent persistence.
2. **Research-view navigation:** Overview, Compare & Rotation, Macro & Policy, Risk & Transmission, History & Scenarios, and the real Research Library destination. Each leads to a real retained or newly accepted view, never an empty placeholder.
3. **Small context controls:** configured population, horizon, supported currency basis and actual benchmark. Price/total-return and hedging limitations stay visible without monopolizing the header.
4. **Two-column first read:** a concise leadership/qualification card and compact “Returns in focus” list. Preserve the mockup's generous spacing and quiet typography; do not reinsert the old dense table into the default first screen.
5. **Deeper entry:** participation/concentration when genuinely qualified; otherwise an honest coverage explanation, plus the existing detailed research/library entry.

The hero is a display projection, not a new scorecard. It names the actual highest eligible market and the most important **supported** qualification. A source-owned turn label may be shown, but its window is not silently equated with the selected return horizon.

### Mobile and tablet

At tablet widths, let the content decide whether columns remain useful; `268-0` is the explicit comparison target. At 390/320, use the native mobile reading sequence: product identity; a **Views** control; horizon/basis controls; hero; return cards; expanded details; deeper tools. Do not shrink six desktop tabs into unreadable labels or require body-level horizontal scroll.

One model/controller serves every breakpoint. Responsive recomposition does not reset selected market, comparison pins, source generation or expanded state. Long names, localized labels and missing-data explanations wrap without cropping. At 200% text, content grows vertically rather than hiding substantive evidence.

## 3. Components and concrete build boundaries

Proposed partial: `templates/intl_workspace/overview.html.j2`. Proposed tests: `tests/test_intl_workspace_overview.py`. Shared view schema/controller/CSS belong to IM-00; the overview worker receives the frozen component seam and does not edit global navigation or the shared builder.

| Component | Required data | Behavior |
|---|---|---|
| `ResearchContextBar` | Canonical population, horizon, basis, benchmark, source reference | Supports only real options; announces changed context once |
| `LeadershipRead` | Deterministic qualified summary | Returns and macro confirmation remain distinct; no freeform invented market prose |
| `ReturnsFocus` | Compact exact-value selection | Highest 3 + lowest remaining; <=4 eligible shows all once |
| `MarketReturnRow` | Real index ID, supported turn label, qualified selected-basis return, quality reason | Row opens the same inspector; compare pin is a separate named control |
| `FullMarketDetail` | Every configured market including exclusions; local/USD/FX and qualifications | Expansion is presentation-only and preserves pins/scroll/generation |
| `CoverageEntry` | Field-level gaps and source receipts | Opens evidence context, not a generic unbound tooltip |
| `DetailedResearchEntry` | Existing real destinations | Preserves all audited legacy capabilities |

Use existing design tokens wherever accepted. Extracted inline JSX is a geometry reference, not permission for arbitrary duplicated CSS values throughout the codebase. Put any needed route-specific aliases under one `.intl-workspace` namespace and let the shared token/theme owner review genuine additions. Preserve real icons/assets from the application; no font files are part of the transfer bundle.

## 4. Data and copy rules that discriminate a correct build

**Population:** configured coverage and eligible current observations are separate. Seven configured markets does not imply seven qualified returns. World Risk's US/China/Hong Kong additions must not inflate this list. US can remain a benchmark without becoming an eighth ranked country.

**Selection:** sort unrounded admitted returns; tie-break by canonical market ID. With >4 eligible, show first three and the lowest remaining. No duplicate when the same market could occupy both roles. With zero eligible, show a genuine unavailable/coverage state—not four empty cards and not the mockup's Japan story.

**All-negative case:** show highest and lowest returns, not winners or “six markets gained”. Positive-return counts are recomputed within eligibility. A negative FX contribution means currency detracted; it is measured in percentage points, not raw FX percent.

**Actual identity:** Japan must display Nikkei 225 while the current owner supplies Nikkei. A TOPIX label must fail a fixture test. Do not turn the illustrative “61% participation” into a computed number from the share of markets above their averages: constituent breadth needs its own denominator and owner.

**Summary qualification:** stale/missing macro can be important context even with a fresh price return. The current source record's fresh date and `data_limited=false` do not validate its 2021-06 CPI observation. Do not print an economic regime or official policy conclusion from that alone. Optional unavailable inputs should not blank unrelated valid market returns.

**Known versus absent chronology:** month-level observations remain months. A page rebuild is not a new data observation. If a quote/series source changed, label the new source identity; don't show a stale benchmark name with substituted data.

## 5. Interaction contract

Overview is the default route view. A click on Compare, a country row or a deeper tool uses the existing route state owner. Save selected context and exact return anchor in that owner's history state; put only safe, allowlisted, non-account-sensitive research parameters in shareable URLs. Invalid URL IDs are rejected or normalized with a visible explanation, not interpolated into DOM/paths.

The **Expand all markets** control has a stable accessible name, `aria-expanded`, and a region relationship. It reveals the complete existing detail without fetching/recalculating. Keep focus on the trigger and announce the new rows once. Collapse restores the same position and comparison pins. A keyboard search targeting a hidden country opens the full view before moving focus.

Only one active representation is exposed to assistive technology. Avoid cloned live IDs and duplicate event handlers across desktop/mobile. Row open and pin actions cannot accidentally trigger each other. A pin limit of four produces an explicit message; no silent eviction of another market.

Without JavaScript, the page still provides the server-rendered summary, full named data/disclosures and real links. Progressive enhancement may change presentation once initialized; a controller failure cannot strand the user at a loading skeleton.

Refresh, save, export and follow are **not assumed built**. Retain an accepted existing action where verified. Otherwise remove a nonessential nonfunctional action or display a clear unavailable explanation. An in-memory draft must say it is not saved or monitored. Never replace a missing backend with optimistic success.

## 6. Worker assignments

| Job | Bounded deliverable | Files / review seam |
|---|---|---|
| IM01-T1 | Semantic overview markup + fixture rendering | Overview partial and focused Python rendering tests only |
| IM01-T2 | Scoped responsive styling for overview | Assigned overview region of route CSS; serial ownership or separate imported partial, as integration lead chooses |
| IM01-T3 | Expand/pin/navigation hooks and tests | Frozen controller interface, overview-specific state tests; no competing router |
| IM01-T4 | Independent visual/interaction review | Read-only candidate; actual screenshots, keyboard trace, known-bad fixture controls |

T1/T2 can work in parallel only with disjoint actual file ownership. T3 integrates after the shared event interface is frozen. The integration lead—not three page workers—mounts the overview in the existing builder/template. Sol decides whether accepted implementation meets the user outcome; Astra handles only a genuine cross-product architecture exception.

## 7. Required acceptance

**Deterministic tests:** 7/4/3/0 eligible; ties; all-negative; rounded tie versus exact ordering; missing FX/local-only; full list contains exclusions; changed basis recalculates display from the qualified projection; source identity mismatch; stale macro/fresh return; fake participation absent; zero is preserved; malformed values denied; duplicate IDs rejected.

**Interaction tests:** expand/collapse; hidden-country search; row versus pin click separation; two/four/fifth pin behavior; Back from inspector restores selected row/filter/scroll; direct deep link falls back to a valid heading; resize retains state; invalid URL parameters; browser reload does not repeat effects; JS failure/no-JS fallback.

**Real-browser matrix:** 1440/768/390/320 × EN/ZH × dark/light, plus 200% text, keyboard-only, touch and reduced motion. Review layout against the appropriate native variant rather than only the desktop screenshot. Check focus visibility, named controls, headings, status announcements, non-color meaning, contrast using actual rendered colors, and no document horizontal overflow. State exactly which combinations were captured and which were manually inspected.

**Preservation:** actual macro and stocks renders, all five country pages, current library, existing detailed analytics and normal asset/publication pipeline. Current-source and real served-page checks are required; a Paper screenshot or local component fixture cannot satisfy them.

## 8. Release and return

Deliver exact source head, screenshots bound to the tested source, unit/integration results, negative controls, a feature-preservation checklist, and unresolved dependencies. Mark active Follow, advanced factors, historical rank arrows and unsupported constituent breadth as unavailable until their real owners qualify them. Their absence does not block the read-only entry journey, provided no dead-end control misrepresents availability.

Roll back only this route's new macro mount/assets through the existing publication process. No finance data, histories, stocks pipeline or saved state is rewritten. Browser permission remains a real gate; the prior administrator denial must not be routed around. No release or live acceptance is claimed by this handoff.
