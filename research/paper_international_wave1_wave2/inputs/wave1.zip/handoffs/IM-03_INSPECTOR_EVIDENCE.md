# IM-03 — Country Inspector & Evidence

**Disposition:** specified for a **read-only** implementation commission. Active Follow, Saved Research writes and new company-exposure intelligence are excluded.  
**Owner:** International inspector lead under Sol International CEO.  
**Depends on:** IM-00 view/rights/context contract; IM-01 and IM-02 supply entry triggers.  
**Outcome:** inspect one market's return, supporting and limiting evidence, calculation basis and exact source lineage; return to the same research moment without losing comparison pins, focus or scroll.

## 1. Exact Paper references

[Open the R10 inspector journey page](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG?page=p-2-0).

| Node | Design input | Review scope |
|---|---|---|
| `805-0` | Desktop market inspector, 1440 | Visually inspected, native screenshot + JSX exported |
| `8AM-0` | Desktop Evidence field detail | Visually inspected, native screenshot + JSX exported |
| `8KL-0` | Tablet inspector, 768 | Directory verified; later visual comparison required |
| `50H-0` | Mobile market inspector, 320 | Visually inspected, native screenshot + JSX exported; chat preview was resized, native asset remains reference |
| `547-0` | Mobile policy evidence | Directory verified; later visual comparison required |
| `5IR-0` | Inspector/Evidence/Follow contract, including §§08–09 | Native specification fully read; behavior authority |
| `57H-0`, `5AN-0`, `5DS-0`, `5FM-0` | Follow draft/review/outcome/success | **Not active-build authority** |
| `9ML-0`, `9SC-0`, `9UA-0`, `9WA-0`, `9XE-0` | Company/exposure/transmission | Separate unqualified capability; not absorbed into this packet |

Follow the latest `5IR-0` rule: **one inspector shell**, with Evidence replacing its content. Do not implement older-looking evidence overlays as a stack of independent dialogs. The old full-list backdrop in `805-0`/`8AM-0` is context illustration; IM-01's current compact overview remains the background authority.

## 2. Layout and component architecture

At desktop width, use the specified approximately **880px inspector**, leaving meaningful selected-market context visible behind it. At widths where the backdrop is no longer useful, use the full available width. Tablet/mobile are not separate controllers or routes with divergent data. The same selection, period, currency, benchmark, evidence field and any permitted local draft survive resizing.

Proposed partials: `templates/intl_workspace/inspector.html.j2` and `evidence.html.j2`. Proposed suite: `tests/test_intl_workspace_inspector.py`. The IM-00 controller owns navigation state; a leaf implements these views against its frozen interface. No new account, monitoring, evidence database or country service.

The **Market read** view contains: real market/index identity and basis; compact qualified interpretation; return plus local/FX decomposition; Supports/Limits/Watch next; a measured-input disclosure; evidence-family health; actual deeper research links; and exact return navigation. The mobile design places the concise interpretation before the return card; preserve readable recomposition instead of shrinking the desktop grid.

“Supports” must contain qualified relevant observations. “Limits” includes missing/stale/unsupported evidence and methodological boundaries. “Watch next” is a research prompt from the defined source/projection, not a claim that an active monitor exists. No opaque score, forecast odds or investment instruction is added here.

The **Evidence** tab first presents the selected market's field ledger. Selecting a field replaces the content with: field identity, exact unit and basis, narrowly supported conclusion, source lineage, four clocks where present, revision/access state, exact record/revision links and return to the originating field. The desktop native evidence reference explicitly warns that one policy input does not prove a future rate path, liquidity impulse or equity outcome; preserve that narrow interpretation.

The **Go deeper** view contains valid existing domain links, not another country dashboard. Five registered country pages remain authoritative where available. Taiwan/Australia still have the in-page read and valid research entries without fabricated dedicated URLs.

## 3. Data mapping and source gaps

Use the same IM-00 market/evidence projection as Overview and Compare. Do not independently recalculate a country return from another cache or source window. Source generation and window identities must remain visible in evidence.

The pinned source uses Nikkei 225 for Japan. Render Nikkei, not the fixture's TOPIX. The mockup's 61% constituent participation and “3 of 5 macro inputs” are illustrative—not defaults. Compute a denominator only from the actual eligible evidence family and method. Do not call the share of supplied fields investment readiness or forecast confidence.

Current `policy_rate` may be a three-month-rate proxy outside the ECB-specific path. That requires an explicit proxy label and interpretation, not “Official policy rate / official decision series”. The four precise September timestamps in `8AM-0` are sample values; use actual observation/publication/ingestion/generation metadata when supplied, otherwise null plus reason. A month observation stays month precision.

Current country-dossier code has rights-cleared EU/UK sources and explicit no-coverage states for JP/KR/IN. A Japan evidence screen cannot fabricate a Bank of Japan news/decision dossier. The source catalog merely naming a publisher does not prove a retrieved, entitled, current record.

One evidence field can be qualified while its market-level macro evidence remains partial. A genuine proxy or model estimate remains labeled as such even when timely. Missing, denied, failed and unsupported are not synonyms for stale; each should explain the user's available next action without inventing a refresh, login entitlement or official-source connection.

## 4. State machine: navigation only

Suggested controller state, adapted to the existing route owner:

```text
closed
  → market_read(market_id, return_context)
  → evidence_ledger(market_id, source_reference, origin_field?)
  → evidence_field(market_id, field_id, source_reference)
  → go_deeper(market_id, return_context)
  → closed(return_target)
```

This is a route-local navigation model, **not** a new persisted lifecycle service. The controller also preserves the originating row/field, selected filters, comparison pins, list/inspector scroll and focus target. All source/account rights are revalidated by their actual owners when required; restored navigation state cannot restore a now-denied value.

A source generation change while an inspector is open must not silently splice old evidence into new market values. Preserve the existing generation visibly if its use is permitted, or show that the source has changed and offer an explicit refresh of the read. A denied or invalid old generation is removed/withheld; browser history is not entitlement authority. No duplicate collectors or arbitrary provider fetches.

**Back:** field detail → its ledger row → same market read → originating overview/comparison. Native browser Back follows safe navigation history and never repeats a write. Deep links without a prior row return to a valid market/list heading. Closing the shell restores the exact live trigger when present; a removed trigger falls back to the nearest meaningful heading.

**Escape:** close the topmost picker first; otherwise follow the inspector's defined internal Back behavior, then close at the top level. Keep a named Close control. Do not accidentally send the user out of the entire page when they intended to close a field detail.

## 5. Accessibility and responsive behavior

Use the existing admitted overlay primitive when compatible. While open, the background is inert, focus is contained within the active shell, and only the current content view is exposed. Avoid two competing focus traps. Name the inspector with the current market and the Evidence detail with its field label. Moving between tabs/field detail announces the changed heading once without re-reading the whole application.

Tab semantics, roving focus where appropriate, close/back controls and exact focus restoration need real-browser proof. Verify mobile screen readers and keyboard navigation conceptually through semantics and with the available real test environment; do not claim manual screen-reader testing without doing it. Long EN/ZH evidence labels and 200% text must not hide units, dates, missing-data reasons or close controls.

Use the shared 150ms fade / 200ms drawer motion where compatible with the site owner. Reduced motion removes translation and unnecessary animation. Never animate numerical values through unsupported intermediate readings. Full-width mobile should not trap the user behind an offscreen Close control or require horizontal document scrolling.

A no-JavaScript implementation still permits the server-rendered country evidence via a native disclosure or valid existing detail route. It must not expose denied data for the sake of a fallback. The enhanced overlay is a usability layer, not the only path to information.

## 6. Follow and saved actions: explicit exclusion

The native file contains a complete-looking Follow lifecycle. This packet **does not prove an authenticated follow owner, create/review/pause/stop API, durable identity or delivery path**. Therefore do not implement active Follow, optimistic success, hidden alerts, background workers or new persistence. No invented endpoint names belong in production code.

For the read-only release, the lead should either omit the nonessential active CTA while preserving a clear research next step, or expose a plainly labeled **local draft / not monitoring** affordance if its value justifies the additional UI. The default minimal scope is no active Follow action. A future integration packet must prove the existing owner and its real interface first.

If a local draft is included, it is memory-only in this packet, not an account-saved condition. Closing a dirty draft explicitly asks keep/discard; navigation alone cannot submit it. An actual in-flight modifying request from an accepted incumbent must retain its exact owner/request handle and be reconciled there; it is not transferred or replayed by this read-only feature.

Future active integration must independently prove one authenticated follow identity, explicit create/edit/pause/resume/stop, unknown-outcome duplicate fencing, material-change evaluation and separate delivery receipts. Four conditions must not become four hidden alerts. That later obligation is recorded, not implemented here.

## 7. Source links, security and privacy

“Open source record” resolves the actual selected record/field and available revision, not merely a publisher homepage. A homepage is acceptable only as a clearly named publisher/source reference—not as proof of the displayed observation. Missing record links are explicitly unavailable.

Use approved internal route IDs and permitted source URLs; reject unsafe schemes and escape all source strings. Rights are enforced **before** serialization. No client-side blur over data already delivered to an unauthorized session. Avoid private account IDs, tokens, source payloads or sensitive research drafts in shareable URLs, logs, screenshots and worker artifacts.

Cache/history restoration must not leak an evidence record across users or after permission change. The existing auth/entitlement owner decides access; this view must not implement its own login or rights evaluator. Do not copy full paid/licensed source bodies into the evidence panel unless the current source rights explicitly permit it.

## 8. Worker assignments

| Job | Bounded outcome | Files / constraints |
|---|---|---|
| IM03-T1 | Market read and measured-input components | Inspector partial + fixture rendering tests; same IM-00 metrics |
| IM03-T2 | Evidence ledger/field cards and source-link validation | Evidence partial/helpers/tests; no separate evidence store |
| IM03-T3 | Single-shell navigation, focus, scroll and breakpoint behavior | Frozen route-controller seam; serial shared-file ownership |
| IM03-T4 | Independent source-truth and accessibility review | Read-only candidate; explicit bad-record and focus-return controls |

T1 and T2 may run in parallel after the shared contract is accepted. T3 integrates into the one controller, not a second overlay runtime. Sol resolves substantive evidence/rights ambiguity; the project lead resolves layout and ordinary interface details. Astra is not the leaf debugger or Paper exporter.

## 9. Required tests and completion evidence

**Source truth:** correct index identity; local/USD/FX reconciliation; old CPI with a new generation; unavailable publication/ingestion metadata; month precision retained; proxy policy rate not official; JP dossier no-coverage; missing constituent denominator; one qualified field does not clear a partial panel; denied values absent; genuine zero; stale/failed/unknown distinct; unsafe source URL refused.

**Journey:** overview row → market read → evidence ledger → field → Back to same ledger row → market read → same overview row. Repeat from comparison with all pins retained. Verify direct link, reload, missing origin, source-generation change, permission change, resize during detail, Escape at picker/field/root, close button and no-JS fallback.

**Accessibility:** one focus trap, inert background, one active view for assistive technology, labeled tabs and controls, exact focus/scroll restoration, visible focus, long localized text, 200% text, reduced motion, keyboard/touch and no horizontal body overflow at 1440/768/390/320. Check actual runtime behavior, not just ARIA strings in source.

**Effect negatives:** no POST/PUT/PATCH/DELETE or account mutation from read navigation; no provider/collector refresh; no saved/follow success state; no job or delivery from a research prompt; browser Back/reload never repeats an action. If an incumbent read API is used, validate its actual permissions and response binding rather than inventing an API from the design.

**Regression:** full real-template integration through the actual page-writer seam, stock/country route preservation and registered existing owner tests. Include deliberately wrong official-rate and timestamp fixtures that fail. Actual browser evidence must bind to the exact source candidate and accepted source fixture; do not substitute a Paper screenshot.

## 10. Return, release and rollback

Return exact head, source/evidence contract digest, changed paths, tested navigation traces, negative controls, responsive capture manifest, rights/link checks, effect-negative evidence and unresolved gates. Explicitly state **read-only inspector delivered / active Follow not implemented** rather than “inspector complete” with hidden lifecycle debt.

Release is integrated with IM-00/01/02 through the current publisher after independent review and genuinely permitted real-browser acceptance. Rollback restores the previous route mount/assets; no database, market data, financial authority or monitoring state is rewritten. An administrator denial is not permission to use another host or browser carrier.
