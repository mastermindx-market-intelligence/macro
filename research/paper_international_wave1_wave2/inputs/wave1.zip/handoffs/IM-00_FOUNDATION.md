# IM-00 — International R10 shared foundation

**Disposition:** specified for bounded implementation; not dispatched, source-leased, implemented or released.  
**Consumer:** Sol International CEO → one data/contracts lead and one route-integration lead.  
**Dependencies:** admitted source custody and a compatible current Macro checkout; no dependency on active monitoring.  
**Outcome:** all new International views render the same honest, dated, rights-qualified research context from the existing International owners, without damaging stocks, country dashboards, deeper analytics or publication.

## 1. Read these inputs; do not restart the census

Read `SOURCE_AUDIT.md`, `contracts/INTERNATIONAL_VIEW_CONTRACT.md`, `orchestration/ASTRA_START_HERE.md` and `DESIGN_ACCESS.md`. The audited source is Macro **d0f14c62544daca98258cbf68a5e1e3bef54ab74**. Inspect only relevant deltas, current source custody and the exact dependency seams before START. A new commit elsewhere does not require repeating all research.

Paper file: **International Markets · R10 · Current Build**, `01M3P1TW5Y3XWQC37ADDS8K5AG`.

| Required reference | Page / exact node | Purpose |
|---|---|---|
| [Engine and state specifications](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG?page=p-1-0) | `P9-0`, `Q2-0`, `R0-0`, `2FN-0` | Existing-owner ledger; financial/lineage rules; interaction and recovery |
| [Inspector and compact overview contract](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG?page=p-2-0) | `5IR-0`, especially §§08–09 | One responsive inspector; exact returns selection; preserved context |
| [Desktop/mobile entry references](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG?page=p-2-0) | `1-0`, `VK-0`, `6G-0`, `2AM-0`, `805-0` | Five core references (seven total with evidence desktop and inspector mobile) |

Page URLs are verified page-level addresses; node IDs identify artboards within them. They are not invented direct-node URL parameters. The token hash `501cd923` is not a complete design revision. Design packet digests and source commits are the immutable references.

## 2. Architectural ruling

Keep the current **Python → Jinja → CSS + route JavaScript** stack. Reuse `scripts/build_intl.py`, `engine/intl_performance.py`, `intl_inputs.py`, `intl_compare.py`, `intl_rotation.py` and the existing risk/market-state producers. Paper JSX describes structure, typography and spacing; it is not a requirement for a React application.

Separate three concerns:

**Financial/data owners** retain prices, FX conversion, input chronology, rotation, macro/regime facts, risk and persistence. Compatible extra precision and timestamped chart projections belong to the existing performance/input boundary—not a second page engine.

**One presentation projection** converts already produced evidence into safe view data: deterministic rows, unit labels, evidence references, availability reasons, narrative clauses and link targets. It must not fetch, refresh a collector, write a ledger, create a monitor, alter financial scores or decide entitlements independently.

**One route state/controller** controls selected view, selected markets, comparison pins, period/basis, disclosure state and inspector navigation. It cannot mutate financial evidence. Theme, language, authentication and notifications keep their existing owners.

Proposed paths below are implementation locations, **not claims that files already exist**. The lead checks for an incumbent equivalent once before creating them. Reuse a compatible incumbent and record the mapping rather than creating a duplicate.

| Seam | Existing / proposed | Scope |
|---|---|---|
| Performance extension | Existing `engine/intl_performance.py` | Compatible unrounded returns and timestamped chart data from existing inputs |
| Source metadata adapter | Existing `engine/intl_inputs.py`, only if necessary | Expose actual identity/clocks/quality; do not invent dates or change scoring policy |
| Pure view model | Proposed `lib/intl_workspace_view.py` | Closed presentation projection, validation and deterministic summary |
| Main mount | Existing `scripts/build_intl.py`, `templates/intl.html.j2` | A **single integration writer** owns these shared files |
| View partials | Proposed `templates/intl_workspace/{overview,compare,inspector,evidence,legacy_research}.html.j2` | Separate bounded component paths |
| Route assets | Proposed `templates/intl_workspace.css`, `templates/intl_workspace.js` | Scoped selectors and one controller; normal asset-copy owner |
| Regressions | Proposed `tests/test_intl_workspace_view.py`, `tests/test_intl_workspace_integration.py` and per-view suites | Registered with the existing CI owner, including dependencies |

Do not add a public API, runtime service, database table, queue, replay store, universal framework or new publication workflow. An internal projection version is a compatibility check, not a new authority registry.

## 3. Fix the data/display mismatches before polishing the screen

### IM00-D1 — Real identities, precision and windows

Current Japan values are Nikkei 225 (`^N225`), not the sample TOPIX label. Read the source identity and propagate it to every row, chart, inspector and export. A changed index is a separate data-contract decision.

Current `usd_leaderboard()` rounds the USD/local/FX legs to one decimal. Add unrounded values **before rounding** inside the existing owner; keep existing rounded keys intact for compatibility. The new view rounds once at presentation. Do not add a decimal digit to a previously rounded number and call it more precise. Sorting uses the unrounded admitted return and a stable canonical market-ID tie-break.

The current horizons represent configured observation counts (`21/63/126/252`) and YTD’s prior-year endpoint. Expose actual start/end and calendar policy. The UI may say “1 month” as a familiar selector, but its evidence must state the actual calculation window. No claim of 21 local trading sessions follows from the current union calendar.

For a new comparison chart, compute timestamped points in the existing performance owner. The current trailing-year, approximately 64-point sparkline is **not** the selected-period chart. Preserve exact endpoints when downsampling; preserve gaps and source qualification. No interpolated synthetic market path.

### IM00-D2 — Qualification without another freshness authority

Pass through the accepted upstream freshness/access policy and its evidence. Where the current owner exposes only raw observation dates, record the missing policy/clock explicitly; do not invent a single “fresh within N days” rule for every asset and macro series. If a required qualification rule is truly absent, the data lead proposes it to the existing input owner as a separately reviewed change; the UI task must render `unknown` meanwhile.

Unbounded price/FX forward-filling in the old helper cannot prove current admissibility. Admission must know which actual observations contributed to an endpoint. Missing FX need not suppress a separately valid **local** return; it does suppress the dependent USD return and FX contribution. Missing macro evidence need not suppress valid market returns. The old `data_limited` boolean is not adequate evidence that every metric is current.

Preserve legitimate zero. Reject booleans, NaN, infinity, malformed units, mismatched market/benchmark identities, invalid chronology and missing denominator geometry where required. Stale data can appear in explicitly historical/evidence detail; it cannot silently enter a qualified current ranking.

### IM00-D3 — Common-period comparison

For 2–4 selected markets, require a common period with explicitly admitted endpoint policy and return basis. The default implementation should use common admissible endpoints from the existing owner’s aligned series. No page-specific unlimited fill. When no valid shared window exists, withhold the common comparison with a reason while preserving separately qualified individual observations.

A common-period chart may differ from a per-market horizon return. Carry both window identities and state the difference; never place unequal windows under one “like-for-like” label. Benchmark identity, price-versus-total-return basis and SPY substitution must match the owner. If no compatible benchmark is qualified, retain the market comparison with an explicit unavailable reference instead of silently substituting.

### IM00-D4 — Deterministic synthesis, not a new intelligence engine

Build a small, testable projection of existing qualified facts. The compact summary may state the highest return, the number positive among eligible markets, whether FX detracted and which evidence families are incomplete. It may project a source-owned turn label with its separate window. It must not infer economic confirmation, allocation, a new confidence score, a forecast or a buy instruction from price rank.

Do not hard-code Japan, “6/7”, “selective leadership”, an illustrative date or the mockup’s participation percentages. All-negative observations say “highest/lowest returns”, not “winners”. Unknown coverage says unavailable, not quiet or neutral. Source-dependent prose is emitted only when its predicate is satisfied; fixture tests cover every clause.

## 4. Preserve the existing estate

`templates/intl.html.j2` renders macro **and stocks**. Restrict the new mount to `mode="macro"`; keep stocks behavior and source ownership. Preserve all 18 families in `SOURCE_AUDIT.md` through working existing sections/routes. The initial redesign may put legacy research under a named disclosure, but cannot replace working research with dead cards or promises.

Retain `intl_stocks.html`, `intl_stock.html`, the existing library, and the five registered country routes. Taiwan and Australia use the in-page inspector and valid existing tools, not invented country URLs. Preserve World Risk’s ten-market universe separately from the seven-market international return cohort and US benchmark.

Keep the existing `lib.pages.write_page`, asset hashing/copying, normalization, shell/theme/locale and admitted publication path. PR #7001 concerns publication checkpointing; this programme does not supersede its ownership. An early builder exit with code zero is not successful output proof.

## 5. Work graph and bounded assignments

| Task | Owner | Permitted paths | Required result |
|---|---|---|---|
| IM00-T1 | Data lead + bounded numerical worker | Existing performance owner and its focused tests; inputs only after explicit seam assignment | Precision/series/identity extension with compatibility and mutation tests |
| IM00-T2 | GLM Flash or Minimax worker under data lead | Proposed pure view-model module + focused fixtures/tests | Closed projection satisfying the contract; no I/O or financial-policy ownership |
| IM00-T3 | Route integration lead + frontend worker | Route-local controller/CSS and state tests | One URL/disclosure/inspector state owner; no shared global changes |
| IM00-T4 | One integration writer | Existing builder/template and normal asset integration | Both legacy stocks and new macro render; no duplicate scripts or IDs |
| IM00-T5 | Independent review worker, then Sol | Read-only exact candidate and test evidence | Numerical, compatibility, rights, preservation and browser-gate disposition |

T1 freezes the source extension before T2 consumes it. T2 and T3 can run independently after the contract is fixed. T4 integrates accepted outputs; page workers do not concurrently edit the shared template. Shared CI changes belong to the existing CI owner, not each leaf. No model, host, child depth or budget is admitted by this table alone.

## 6. Acceptance tests

The following are **required tests to implement/run**, not tests claimed passed by this research packet.

**Numerical and identity:** USDJPY division / GBPUSD multiplication; mixed calendars; source window endpoints; exact pre-rounding identity `USD = local + FX contribution`; genuine zero; negative returns; near ties that reverse after rounding; ties broken by market ID; duplicate country IDs rejected; Nikkei never displayed as TOPIX; missing/stale FX; invalid source dates; SPY substitute label; compatible benchmark gap; YTD boundary and insufficient history.

**View qualification:** each quality state; separate local versus USD eligibility; stale CPI with a fresh shell; absent publication/ingestion clocks; three-month rate proxy not official policy; no invented breadth; seven-country versus ten-market coverage; denied data absent from serialized payload; source text escaped; failed optional family does not blank valid neighbors.

**Integration:** actual Jinja render and actual page-writer seam in temporary output, both modes; all preserved routes/features; asset copying and normalization; no pandas Series serialized; no leftover old/new leaderboard controllers racing; valid no-JavaScript fallback; UI state does not trigger collectors, ledger writes, auth writes or network refresh.

**Regression commands:** run the real current owner suites including `test_intl_build`, `test_intl_performance`, `test_intl_compare`, `test_intl_rotation`, `test_intl_mobile_layout`, `test_intl_session_asof` and affected country-dashboard/dossier suites. Resolve exact available paths and registered CI jobs at START. Run the existing differential contract/design/template-sync guards in their current supported form. Do not assert a command passed merely because its scope was deselected by a sparse checkout.

**Browser:** actual served candidate at 1440/768/390/320, dark/light, EN/ZH, 200% text, keyboard/touch and reduced motion; no body overflow; no stale UI after selection; rights-qualified payload; actual links and focus restoration. Administrator browser restrictions remain gates, not permission to use another host/profile/scheme to evade them.

## 7. Return, release and rollback

Return exact base/head, changed-path list, source extension shape, contract fixture digest, red/green evidence, preserved-feature matrix, browser evidence state and unresolved gaps. Source, local build, deployed artifact and authenticated product proof are separate checkboxes.

Sol accepts the source only after independent review. Public cutover uses the existing release owner after view packets and browser gates pass. A staged route-local rollout may use an **existing admitted configuration owner**, or a normal source cutover if none exists; do not create an extra flag service. Rollback restores the previous macro mount/assets through the normal publication path, without rewriting financial data, history or saved records. No database migration is part of this packet.

**Escalate only:** conflicting active source lease; a necessary new financial policy; incompatible incumbent interface; denied browser/resource permission; missing rights or accepted freshness rules that prevent a required claim; an unresolved modifying effect. Do not ask Astra to re-census the product or resolve ordinary CSS/component choices.
