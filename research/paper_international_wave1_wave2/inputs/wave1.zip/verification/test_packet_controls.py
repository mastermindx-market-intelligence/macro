"""Synthetic checks of the written specification and packet validator.
Not a test of Mastermind production code or investment performance.
Run: python3 -m unittest discover -s verification -p 'test_*.py' -v
"""
from decimal import Decimal
from pathlib import Path
import json
import shutil
import tempfile
import unittest
from verify_packet import validate, PacketError

ROOT = Path(__file__).resolve().parents[1]

def compact_reference(rows):
    """Executable specification example only; not production implementation."""
    eligible = sorted((r for r in rows if r[2]), key=lambda r: (-r[1], r[0]))
    return eligible if len(eligible) <= 4 else eligible[:3] + [eligible[-1]]

class SpecificationExamples(unittest.TestCase):
    def test_compounding_and_fx_contribution_are_distinct(self):
        local, fx = Decimal('.052'), Decimal('-.014')
        usd = (1 + local) * (1 + fx) - 1
        contribution = 100 * (usd - local)
        self.assertEqual(usd, Decimal('.037272'))
        self.assertEqual(contribution, Decimal('-1.4728'))
        self.assertNotEqual(contribution, 100 * fx)
        self.assertEqual(100 * usd, 100 * local + contribution)
    def test_usdjpy_divides(self):
        local = Decimal('100')
        a = local / Decimal('150'); b = local / Decimal('165')
        self.assertLess(b / a - 1, 0)
        self.assertGreater((local * 165) / (local * 150) - 1, 0)  # wrong orientation is discriminated
    def test_gbpusd_multiplies(self):
        a = Decimal('100') * Decimal('1.2'); b = Decimal('100') * Decimal('1.3')
        self.assertGreater(b / a - 1, 0)
    def test_seven_selects_top_three_and_lowest(self):
        rows = [(chr(65+i), Decimal(7-i), True) for i in range(7)]
        self.assertEqual([r[0] for r in compact_reference(rows)], ['A','B','C','G'])
    def test_small_eligible_population_has_no_duplicates(self):
        rows = [('A', Decimal(2), True), ('B', Decimal(1), False), ('C', Decimal(0), True)]
        self.assertEqual([r[0] for r in compact_reference(rows)], ['A','C'])
    def test_all_negative_keeps_order(self):
        rows = [(str(i), -Decimal(i), True) for i in range(1,8)]
        self.assertEqual([r[0] for r in compact_reference(rows)], ['1','2','3','7'])
    def test_exact_ties_use_market_id(self):
        self.assertEqual([r[0] for r in compact_reference([('TW',Decimal(1),True),('JP',Decimal(1),True)])], ['JP','TW'])
    def test_rounding_does_not_set_sort_order(self):
        rows=[('A',Decimal('1.044'),True),('B',Decimal('1.049'),True)]
        self.assertEqual(round(rows[0][1],1),round(rows[1][1],1))
        self.assertEqual(compact_reference(rows)[0][0], 'B')
    def test_no_qualified_rows_is_empty_not_zero(self):
        self.assertEqual(compact_reference([('JP',Decimal(0),False)]), [])
    def test_real_zero_is_retained(self):
        self.assertEqual(compact_reference([('JP',Decimal(0),True)])[0][1], 0)

class PacketMutationControls(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)/'packet'
        shutil.copytree(ROOT,self.root,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        self.assertEqual(validate(self.root,check_hashes=False)['result'], 'PASS')
    def tearDown(self):
        self.temp.cleanup()
    def change_manifest(self, fn):
        p=self.root/'BUILD_MANIFEST.json';v=json.loads(p.read_text());fn(v);p.write_text(json.dumps(v))
    def assert_rejected(self, reason):
        with self.assertRaisesRegex(PacketError, reason):
            validate(self.root, check_hashes=False)
    def test_unmodified_packet_passes(self):
        self.assertEqual(validate(self.root,check_hashes=False)['result'], 'PASS')
    def test_wrong_census_total_is_rejected(self):
        self.change_manifest(lambda v:v['counts'].__setitem__('fully_censused_artboards',1590));self.assert_rejected('Manifest census counts differ')
    def test_missing_handoff_is_rejected(self):
        (self.root/'handoffs/IM-02_COMPARE_ROTATION.md').unlink();self.assert_rejected('Missing/empty document')
    def test_dependency_cycle_is_rejected(self):
        self.change_manifest(lambda v:v['packets'][0].__setitem__('depends_on',['IM-01']));self.assert_rejected('Dependency cycle')
    def test_active_follow_claim_is_rejected(self):
        self.change_manifest(lambda v:v['held_capabilities'].__setitem__('active_follow',True));self.assert_rejected('Held capability was enabled')
    def test_live_proof_claim_is_rejected(self):
        self.change_manifest(lambda v:v.__setitem__('live_site_proof',True));self.assert_rejected('Live-site proof is not present')
    def test_dispatch_claim_is_rejected(self):
        self.change_manifest(lambda v:v.__setitem__('worker_dispatch_proven',True));self.assert_rejected('Worker dispatch is not present')

if __name__ == '__main__':
    unittest.main()
