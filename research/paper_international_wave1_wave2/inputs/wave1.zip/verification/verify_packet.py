#!/usr/bin/env python3
"""Verify this research packet's structure and hashes, not a website build.

Usage: python3 verification/verify_packet.py [--root PATH] [--structural-only]
No network, provider, Paper, repository-write or production operation is performed.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
from pathlib import Path
import re
import sys

class PacketError(ValueError):
    pass

def require(condition: bool, message: str) -> None:
    if not condition:
        raise PacketError(message)

def safe_path(root: Path, name: str) -> Path:
    p = (root / name).resolve()
    require(p.is_relative_to(root.resolve()), f'Unsafe relative path: {name}')
    return p

def validate(root: Path, *, check_hashes: bool = True) -> dict:
    root = root.resolve()
    m = json.loads((root / 'BUILD_MANIFEST.json').read_text())
    c = json.loads((root / 'census/PAPER_CENSUS.json').read_text())
    require(re.fullmatch(r'[0-9a-f]{40}', m['source_pin']) is not None, 'Invalid source pin')
    require(m['mission_complete'] is False, 'Whole-program completion is not proven')
    require(m['live_site_proof'] is False, 'Live-site proof is not present')
    require(m['worker_dispatch_proven'] is False, 'Worker dispatch is not present')
    require(m['native_asset_pack_in_chat_zip'] is False, 'M2 native pack is a separate object')
    require(all(v is False for v in m['held_capabilities'].values()), 'Held capability was enabled')
    full = [f for f in c['files'] if f['coverage'] == 'all_pages_directory_observed']
    totals = (len(full), sum(len(f['pages']) for f in full),
              sum(p['artboard_count'] for f in full for p in f['pages']))
    require(totals == (6, 78, 1589), f'Directory census totals differ: {totals}')
    require(len(c['files']) == 11, 'Known-file count differs')
    require((m['counts']['fully_censused_files'], m['counts']['fully_censused_pages'],
             m['counts']['fully_censused_artboards']) == totals, 'Manifest census counts differ')
    screens = c['native_product_screens_visually_reviewed']
    require(len(screens) == len(set(screens)) == 7, 'Reviewed/exported screen count differs')
    pairs = [(f['id'], p['id']) for f in c['files'] for p in f['pages']]
    require(len(pairs) == len(set(pairs)), 'Duplicate file/page identity')
    with (root / 'census/PAPER_PAGES.csv').open(newline='') as f:
        rows = list(csv.DictReader(f))
    require(len(rows) == len(pairs) == 90, 'CSV/page-directory row count differs')
    require({(x['file_id'], x['page_id']) for x in rows} == set(pairs), 'CSV/page identities differ')
    for name in m['required_documents']:
        p = safe_path(root, name)
        require(p.is_file() and p.stat().st_size > 100, f'Missing/empty document: {name}')
    packets = {p['id']: p for p in m['packets']}
    require(set(packets) == {'IM-00', 'IM-01', 'IM-02', 'IM-03'}, 'Packet set differs')
    def walk(pid: str, stack: set[str]) -> None:
        require(pid not in stack, f'Dependency cycle at {pid}')
        for dep in packets[pid]['depends_on']:
            require(dep in packets, f'Unknown dependency: {dep}')
            walk(dep, stack | {pid})
    for pid, p in packets.items():
        walk(pid, set())
        require(not p['dispatched'] and not p['production_accepted'] and p['source_lease'] is None,
                f'Unsupported execution/custody/acceptance claim: {pid}')
        doc = safe_path(root, p['file']).read_text()
        require(len(doc.split()) >= 1200, f'Unexpectedly incomplete build packet: {pid}')
        for task in p['worker_tasks']:
            require(task in doc, f'Missing worker task {task}')
        for ref in p['node_references']:
            require(ref['node_id'] in doc, f'Missing Paper reference {ref}')
        require('acceptance' in doc.lower() and re.search(r'roll\s?back', doc.lower()) is not None,
                f'Missing acceptance/rollback section: {pid}')
    for p in root.rglob('*.md'):
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', p.read_text()):
            if target.startswith(('https://', 'http://', '#', 'mailto:')):
                continue
            relative = target.split('#', 1)[0]
            if relative:
                dest = (p.parent / relative).resolve()
                require(dest.is_relative_to(root), f'Link escapes packet: {p.name}: {target}')
                require(dest.exists(), f'Broken local link: {p.name}: {target}')
    require(not any(p.suffix.lower() in {'.ttf', '.otf', '.woff', '.woff2'} for p in root.rglob('*')),
            'Font file detected')
    receipt = json.loads((root / 'evidence/DESIGN_PACK_RECEIPT.json').read_text())
    require(receipt['native_reference_pairs'] == 7 and receipt['bytes'] == 1014330,
            'Native pack receipt differs')
    require(receipt['sha256'] == '53687f06fa83b26d9194d37b53df026075e62e57cd2c0521790ab072cd65c677',
            'Native pack receipt digest differs')
    require(receipt['worker_delivery_proven'] is False and receipt['font_files'] == 0,
            'Unsupported native pack delivery/font claim')
    checked = 0
    if check_hashes:
        integrity = json.loads((root / 'INTEGRITY.json').read_text())
        expected_paths = set()
        for item in integrity['files']:
            p = safe_path(root, item['path']); b = p.read_bytes()
            require(len(b) == item['bytes'] and hashlib.sha256(b).hexdigest() == item['sha256'],
                    f'Integrity mismatch: {item["path"]}')
            expected_paths.add(item['path']); checked += 1
        actual_paths = {str(p.relative_to(root)) for p in root.rglob('*')
                        if p.is_file() and p.name != 'INTEGRITY.json'
                        and '__pycache__' not in p.parts and not p.name.endswith('.pyc')}
        require(actual_paths == expected_paths, 'Integrity manifest has missing or extra files')
    return {'result': 'PASS', 'scope': 'research-artifact structure and integrity, not product tests',
            'directory_files': totals[0], 'directory_pages': totals[1], 'artboards': totals[2],
            'known_files': len(c['files']), 'page_rows_including_partial': len(rows),
            'handoffs': len(packets), 'worker_tasks': sum(len(x['worker_tasks']) for x in packets.values()),
            'native_reference_pairs': len(screens), 'hashes_checked': checked,
            'website_build_tested': False, 'live_site_proven': False}

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--structural-only', action='store_true')
    args = parser.parse_args()
    try:
        print(json.dumps(validate(args.root, check_hashes=not args.structural_only), indent=2))
    except (PacketError, OSError, ValueError, KeyError, TypeError) as exc:
        print(f'FAIL: {exc}', file=sys.stderr)
        sys.exit(1)
