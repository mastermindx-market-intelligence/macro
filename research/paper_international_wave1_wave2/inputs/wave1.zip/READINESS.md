# Build-readiness decision — Wave 1

## Meaning of “ready” in this packet

**Ready for a bounded implementation commission** means the intended user journey, selected design authority, source seams, non-goals, worker boundaries and acceptance tests are specified. It does **not** mean already built, independently approved, production-ready, deployed, or free to displace an existing source writer. Source custody, model/grant admission and release gates still apply.

| Packet / family | Assessment now | What may proceed | What must not be inferred |
|---|---|---|---|
| IM-00 — International shared read model and route foundation | **Specified for bounded implementation** | Pure source projection, truthful metadata, compatible precision/series extension, route-local state, preservation tests | No new financial engine or central state store; no current-source lease yet |
| IM-01 — International Overview | **Specified; depends on IM-00** | Compact first read, expanded full detail, explicit quality states, existing-country entry points | The illustrative Japan story is not production copy; all 7 are not always qualified |
| IM-02 — Compare & Rotation | **Specified; data-extension dependency explicit** | Two-to-four selection, real common-window chart, attribution, current qualified rotation context | Historical rank arrows, constituent breadth and sector-neutral factors are not already supplied |
| IM-03 — Country Inspector & Evidence | **Specified for read-only scope** | One responsive inspector, source receipts, exact context return, existing domain links | Active follow, delivered alerts, full company-exposure intelligence or new regional sources |
| R10 Macro/Policy and Risk | **Preservation mapped; full handoff outstanding** | Keep existing capabilities accessible; no removal in entry-page release | Eight artboards are not eight routes or proof of complete backend readiness |
| R10 History/Scenarios | **Qualification and deep review required** | Retain existing history with truthful limits | Original-as-known history, new scenario odds, replay or a second ledger |
| R10 Library/Search/Saved | **Deep review required** | Existing library routes remain; full redesign not commissioned by these packets | Duplicate search-board label resolves authority; saved persistence or new account owner exists |
| R10 Follow/monitor lifecycle | **Not admitted for active implementation here** | Optional in-memory draft UI only, visibly not enabled | HTTP success, click, auth completion or optimistic UI proves durable Active |
| R10 advanced factors / company exposure / transmission | **Source qualification required** | Typed unavailable states and existing entitled links | Listing geography is economic exposure; sector neutrality or constituent history can be invented |
| Sector Intelligence R2 / Crypto R3 | **Priority next audits, not approved from title** | Read authoritative specs and reconcile source before issuing leaf jobs | “Current Build” means fully ready |
| Intelligence Hub | **Extracted owner resolved; deep review pending** | Audit current Refined vase pages and retained baseline | Rebuild the main-file source copy or bypass Transfer QA holds |
| Bonds / Forex | **Existing implementation to reconcile** | Review current #8241 / #8243 / #8326 before later build handoffs | Start competing replacement PRs or clear browser holds from source tests |
| Terminal / Prophet | **Directory-censused; not blanket-approved** | Later journey-by-journey audit; preserve current feature and regional owners | Port International controllers or assume identical state/persistence semantics |
| Mastermind OS | **Current Atelier location resolved; handoff separate** | Use p-D-0 visual authority, p-E-0 flow notes and retained backend contracts | Make OS’s design language or runtime architecture the automatic owner of all website pages |
| Mastermind AI / MarketOntology | **File directories found, page census incomplete** | Complete exact page/state census next | Held/shared-shell duplicates or MO WIP Company bridge are build targets |
| Noir / Guide / Dashboard Popups | **Navigator references only** | Inspect actual files and source ownership | Current content, counts or readiness are known |

## Hard exclusions

Do not build archive pages, source-only baseline boards, redirect stubs, QA HOLD duplicates, or explicitly WIP/not-for-build boards as new product pages. Keep them for feature archaeology and comparison. In particular, MarketOntology `HL-0` is **WIP Company bridge / NOT FOR BUILD**; its existence does not authorize a new company page.

The main file’s old sector and Hub pages that now contain one redirect board are not unfinished pages to reconstruct. The International Returns Calendar page has Terminal/dossier consumers and needs that owner’s packet. Shared-shell studies must not become competing global navigation implementations.

## Why the first build batch is International

It has unusually strong native product, engine, lineage, interaction and recovery specifications. The audit found concrete existing backend owners and exact gaps rather than a need to invent another research engine. The first release can materially improve the entry journey while deeper tools stay available, and it supplies reusable **presentation contracts** without prematurely defining a universal product backend.

## Recommended next research order

1. **Finish International deeper-view packets**: Macro/Policy + Risk (8 boards), then History/Scenarios (5), then the 50-board Library/Saved/Search family after resolving duplicate 102 labels. This completes one coherent website domain instead of scattering unfinished commissions.
2. **Sector Intelligence R2 and Crypto R3**: relatively bounded current-build page groups; audit the actual routes and useful old features before approving.
3. **Extracted Intelligence Hub**: its source move and state/denominator rules make premature implementation especially risky.
4. **Bonds/Forex existing candidate convergence**: reuse audited implementations; distinguish remaining design gaps from held browser acceptance.
5. Continue through remaining product families and the five additional files. The page registry is cumulative; do not recount the already captured six files unless a material directory invalidator appears.

This ordering is a research programme recommendation, not a dispatched job graph or permission to replace live owners.
