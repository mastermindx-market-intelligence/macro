# Paper file and page census

**6 files fully directory-censused: 78 pages / 1,589 artboards. 11 working/reference files discovered in total.**

“Censused” means the live page/artboard directory was enumerated. It does not mean every screen was visually reviewed or is ready to build. Three additional file references are still uninspected; two more have file directories but not a complete per-page artboard census.

Open the page link and use the exact artboard ID in the handoff. Artboard-specific URL syntax was not verified, so this packet does not invent it.

## [Refined vase](https://app.paper.design/file/01M2VWK62FA5S4VVF6G7SBPE5J)

File `01M2VWK62FA5S4VVF6G7SBPE5J` · coverage: `all_pages_directory_observed` · pages: 8 · artboards: 67

| Page | Artboards | Disposition |
|---|---:|---|
| [p-1-0 — Page 1](https://app.paper.design/file/01M2VWK62FA5S4VVF6G7SBPE5J?page=p-1-0) | 1 | REFERENCE_ONLY |
| [p-8-0 — 98 · SOURCE ONLY · Intelligence Hub Alt Data Baseline](https://app.paper.design/file/01M2VWK62FA5S4VVF6G7SBPE5J?page=p-8-0) | 1 | REFERENCE_ONLY |
| [p-7-0 — 99 · Hub · Transfer QA + Held](https://app.paper.design/file/01M2VWK62FA5S4VVF6G7SBPE5J?page=p-7-0) | 2 | QA_HOLD |
| [p-6-0 — 04 · Hub · Loading, Filters + Locale Coverage](https://app.paper.design/file/01M2VWK62FA5S4VVF6G7SBPE5J?page=p-6-0) | 23 | NOT_YET_DEEP_REVIEWED |
| [p-5-0 — 03 · Hub · Research + Risk States](https://app.paper.design/file/01M2VWK62FA5S4VVF6G7SBPE5J?page=p-5-0) | 17 | NOT_YET_DEEP_REVIEWED |
| [p-4-0 — 02 · Hub · Mobile Commands + Evidence](https://app.paper.design/file/01M2VWK62FA5S4VVF6G7SBPE5J?page=p-4-0) | 13 | NOT_YET_DEEP_REVIEWED |
| [p-3-0 — 01 · Hub · Desktop Commands + Evidence](https://app.paper.design/file/01M2VWK62FA5S4VVF6G7SBPE5J?page=p-3-0) | 5 | NOT_YET_DEEP_REVIEWED |
| [p-2-0 — Intelligence Hub · R4 · Working](https://app.paper.design/file/01M2VWK62FA5S4VVF6G7SBPE5J?page=p-2-0) | 5 | NOT_YET_DEEP_REVIEWED |

## [MASTERMIND PAGES](https://app.paper.design/file/01M2WGNCX9475G79JRKJTCM08P)

File `01M2WGNCX9475G79JRKJTCM08P` · coverage: `all_pages_directory_observed` · pages: 27 · artboards: 660

| Page | Artboards | Disposition |
|---|---:|---|
| [p-5-0 — Archetype Starters · Governed](https://app.paper.design/file/01M2WGNCX9475G79JRKJTCM08P?page=p-5-0) | 22 | NOT_YET_DEEP_REVIEWED |
| [p-Q-0 — Earnings + Dossiers · North Star Study · 2026-09-26](https://app.paper.design/file/01M2WGNCX9475G79JRKJTCM08P?page=p-Q-0) | 5 | NOT_YET_DEEP_REVIEWED |
| [p-3-1 — News Intelligence · 2026-09-20](https://app.paper.design/file/01M2WGNCX9475G79JRKJTCM08P?page=p-3-1) | 15 | NOT_YET_DEEP_REVIEWED |
| [p-D-0 — Mastermind · Shared Shell · Review 01 · 2026-09-24](https://app.paper.design/file/01M2WGNCX9475G79JRKJTCM08P?page=p-D-0) | 87 | NOT_YET_DEEP_REVIEWED |
| [p-13-1 — Market Breadth · Command Center · R1 · 2026-09-29](https://app.paper.design/file/01M2WGNCX9475G79JRKJTCM08P?page=p-13-1) | 3 | NOT_YET_DEEP_REVIEWED |
| [p-A-0 — Confluence Screener · Governed Reference · 2026-09-22](https://app.paper.design/file/01M2WGNCX9475G79JRKJTCM08P?page=p-A-0) | 12 | NOT_YET_DEEP_REVIEWED |
| [p-H-1 — Confluence Screener · R2 · 2026-09-26](https://app.paper.design/file/01M2WGNCX9475G79JRKJTCM08P?page=p-H-1) | 13 | NOT_YET_DEEP_REVIEWED |
| [p-O-1 — Bonds · Decision Workspace · R1 · 2026-09-26](https://app.paper.design/file/01M2WGNCX9475G79JRKJTCM08P?page=p-O-1) | 51 | EXISTING_IMPLEMENTATION_TO_RECONCILE |
| [p-N-1 — Forex · Guided Intelligence · R1 · 2026-09-26](https://app.paper.design/file/01M2WGNCX9475G79JRKJTCM08P?page=p-N-1) | 69 | EXISTING_IMPLEMENTATION_TO_RECONCILE |
| [p-J-1 — Policy Watch · Decision Desk · R1 Study · 2026-09-26](https://app.paper.design/file/01M2WGNCX9475G79JRKJTCM08P?page=p-J-1) | 23 | NOT_YET_DEEP_REVIEWED |
| [p-8-1 — Live Site Baselines · Wave 1 · 2026-09-21](https://app.paper.design/file/01M2WGNCX9475G79JRKJTCM08P?page=p-8-1) | 10 | NOT_YET_DEEP_REVIEWED |
| [p-T-0 — Intelligence Hub · Unified US + China · R4 · 2026-09-27](https://app.paper.design/file/01M2WGNCX9475G79JRKJTCM08P?page=p-T-0) | 66 | SOURCE_AFTER_EXTRACTION |
| [p-10-0 — Crypto Intelligence · R3 · Current Build · 2026-09-27](https://app.paper.design/file/01M2WGNCX9475G79JRKJTCM08P?page=p-10-0) | 14 | NOT_YET_DEEP_REVIEWED |
| [p-L-0 — Commodities · R1 Study · 2026-09-26](https://app.paper.design/file/01M2WGNCX9475G79JRKJTCM08P?page=p-L-0) | 43 | NOT_YET_DEEP_REVIEWED |
| [p-Y-0 — Sector Intelligence · R2 · Current Build · 2026-09-27](https://app.paper.design/file/01M2WGNCX9475G79JRKJTCM08P?page=p-Y-0) | 21 | NOT_YET_DEEP_REVIEWED |
| [p-S-1 — Gov Revenue · Signal Desk · R5 · 2026-09-26](https://app.paper.design/file/01M2WGNCX9475G79JRKJTCM08P?page=p-S-1) | 27 | NOT_YET_DEEP_REVIEWED |
| [p-K-0 — BioCatalyst · North Star + Build Blueprint · 2026-09-26](https://app.paper.design/file/01M2WGNCX9475G79JRKJTCM08P?page=p-K-0) | 47 | NOT_YET_DEEP_REVIEWED |
| [p-Z-0 — ARCHIVE · Sector Intelligence · Legacy Studies · Not for Build](https://app.paper.design/file/01M2WGNCX9475G79JRKJTCM08P?page=p-Z-0) | 70 | REFERENCE_ONLY |
| [p-V-0 — ARCHIVE · Company Intelligence · Not for Build](https://app.paper.design/file/01M2WGNCX9475G79JRKJTCM08P?page=p-V-0) | 5 | REFERENCE_ONLY |
| [p-11-0 — ARCHIVE · Crypto Intelligence · R1–R2 · Not for Build](https://app.paper.design/file/01M2WGNCX9475G79JRKJTCM08P?page=p-11-0) | 9 | REFERENCE_ONLY |
| [p-X-0 — ARCHIVE · Intelligence Hub · R1–R3 · Not for Build](https://app.paper.design/file/01M2WGNCX9475G79JRKJTCM08P?page=p-X-0) | 25 | REFERENCE_ONLY |
| [p-W-0 — ARCHIVE · International Markets · R9 · Not for Build](https://app.paper.design/file/01M2WGNCX9475G79JRKJTCM08P?page=p-W-0) | 14 | REFERENCE_ONLY |
| [p-E-1 — Sector Intelligence · vNext Study · 2026-09-24](https://app.paper.design/file/01M2WGNCX9475G79JRKJTCM08P?page=p-E-1) | 1 | REDIRECT_ONLY |
| [p-6-1 — Sector Intelligence · Unified Detail · 2026-09-21](https://app.paper.design/file/01M2WGNCX9475G79JRKJTCM08P?page=p-6-1) | 1 | REDIRECT_ONLY |
| [p-I-1 — Intelligence Hub · R1 Study · 2026-09-26](https://app.paper.design/file/01M2WGNCX9475G79JRKJTCM08P?page=p-I-1) | 1 | REDIRECT_ONLY |
| [p-9-0 — Sector Central · Redesign · 2026-09-21](https://app.paper.design/file/01M2WGNCX9475G79JRKJTCM08P?page=p-9-0) | 1 | REDIRECT_ONLY |
| [p-7-1 — China Intelligence · vNext · 2026-09-21](https://app.paper.design/file/01M2WGNCX9475G79JRKJTCM08P?page=p-7-1) | 5 | NOT_YET_DEEP_REVIEWED |

## [Mastermind OS](https://app.paper.design/file/01M3NRCX55B452A12819WNE1RH)

File `01M3NRCX55B452A12819WNE1RH` · coverage: `all_pages_directory_observed` · pages: 14 · artboards: 294

| Page | Artboards | Disposition |
|---|---:|---|
| [p-1-0 — Page 1](https://app.paper.design/file/01M3NRCX55B452A12819WNE1RH?page=p-1-0) | 1 | NOT_YET_DEEP_REVIEWED |
| [p-E-0 — 13 · Daily Experience · Flow + Builder Notes](https://app.paper.design/file/01M3NRCX55B452A12819WNE1RH?page=p-E-0) | 16 | NOT_YET_DEEP_REVIEWED |
| [p-D-0 — 12 · Canonical Atelier · Mastermind OS](https://app.paper.design/file/01M3NRCX55B452A12819WNE1RH?page=p-D-0) | 74 | NOT_YET_DEEP_REVIEWED |
| [p-C-0 — 11 · Chat Atelier · Current Design](https://app.paper.design/file/01M3NRCX55B452A12819WNE1RH?page=p-C-0) | 10 | NOT_YET_DEEP_REVIEWED |
| [p-B-0 — 10 · SOURCE ONLY · Signed-in Home Baseline](https://app.paper.design/file/01M3NRCX55B452A12819WNE1RH?page=p-B-0) | 1 | REFERENCE_ONLY |
| [p-A-0 — 09 · Global Search + Recovery](https://app.paper.design/file/01M3NRCX55B452A12819WNE1RH?page=p-A-0) | 10 | NOT_YET_DEEP_REVIEWED |
| [p-9-0 — 08 · All Tools + Research Drawer](https://app.paper.design/file/01M3NRCX55B452A12819WNE1RH?page=p-9-0) | 19 | NOT_YET_DEEP_REVIEWED |
| [p-8-0 — 07 · Global Shell + Navigation](https://app.paper.design/file/01M3NRCX55B452A12819WNE1RH?page=p-8-0) | 13 | NOT_YET_DEEP_REVIEWED |
| [p-7-0 — 06 · Access, Loading + Recovery](https://app.paper.design/file/01M3NRCX55B452A12819WNE1RH?page=p-7-0) | 31 | NOT_YET_DEEP_REVIEWED |
| [p-6-0 — 05 · Chairman Daily Journey](https://app.paper.design/file/01M3NRCX55B452A12819WNE1RH?page=p-6-0) | 15 | NOT_YET_DEEP_REVIEWED |
| [p-5-0 — 04 · Connected Company Journeys](https://app.paper.design/file/01M3NRCX55B452A12819WNE1RH?page=p-5-0) | 26 | NOT_YET_DEEP_REVIEWED |
| [p-4-0 — 03 · Missions, Work + Fleet](https://app.paper.design/file/01M3NRCX55B452A12819WNE1RH?page=p-4-0) | 32 | NOT_YET_DEEP_REVIEWED |
| [p-3-0 — 02 · Conversations + Message States](https://app.paper.design/file/01M3NRCX55B452A12819WNE1RH?page=p-3-0) | 27 | NOT_YET_DEEP_REVIEWED |
| [p-2-0 — 01 · Noir Experience + Build Guides](https://app.paper.design/file/01M3NRCX55B452A12819WNE1RH?page=p-2-0) | 19 | NOT_YET_DEEP_REVIEWED |

## [Terminal](https://app.paper.design/file/01M3NSZGE8JWN2EZCSF0DT05RM)

File `01M3NSZGE8JWN2EZCSF0DT05RM` · coverage: `all_pages_directory_observed` · pages: 16 · artboards: 330

| Page | Artboards | Disposition |
|---|---:|---|
| [p-1-0 — Company Intelligence · 2026-09-20](https://app.paper.design/file/01M3NSZGE8JWN2EZCSF0DT05RM?page=p-1-0) | 121 | NOT_YET_DEEP_REVIEWED |
| [p-G-0 — 12 · SOURCE ONLY · Terminal Live Baselines](https://app.paper.design/file/01M3NSZGE8JWN2EZCSF0DT05RM?page=p-G-0) | 3 | REFERENCE_ONLY |
| [p-F-0 — 11 · Company · Earnings + Dossiers · North Star Study](https://app.paper.design/file/01M3NSZGE8JWN2EZCSF0DT05RM?page=p-F-0) | 5 | NOT_YET_DEEP_REVIEWED |
| [p-E-0 — 10 · Retained Shared Shell · Stocks + Setups](https://app.paper.design/file/01M3NSZGE8JWN2EZCSF0DT05RM?page=p-E-0) | 8 | NOT_YET_DEEP_REVIEWED |
| [p-D-0 — 09 · Options · Volatility Lab](https://app.paper.design/file/01M3NSZGE8JWN2EZCSF0DT05RM?page=p-D-0) | 10 | NOT_YET_DEEP_REVIEWED |
| [p-C-0 — ARCHIVE · Company Intelligence · Superseded](https://app.paper.design/file/01M3NSZGE8JWN2EZCSF0DT05RM?page=p-C-0) | 1 | REFERENCE_ONLY |
| [p-B-1 — 08 · Company · Financials, Market + Ownership](https://app.paper.design/file/01M3NSZGE8JWN2EZCSF0DT05RM?page=p-B-1) | 11 | NOT_YET_DEEP_REVIEWED |
| [p-A-1 — 07 · Company · Research, Results + Sources](https://app.paper.design/file/01M3NSZGE8JWN2EZCSF0DT05RM?page=p-A-1) | 15 | NOT_YET_DEEP_REVIEWED |
| [p-9-1 — 06 · Company · Navigation + Interaction](https://app.paper.design/file/01M3NSZGE8JWN2EZCSF0DT05RM?page=p-9-1) | 14 | NOT_YET_DEEP_REVIEWED |
| [p-7-1 — 05 · Options · Compare](https://app.paper.design/file/01M3NSZGE8JWN2EZCSF0DT05RM?page=p-7-1) | 6 | NOT_YET_DEEP_REVIEWED |
| [p-6-1 — 04 · Options · Scenarios + Assumptions](https://app.paper.design/file/01M3NSZGE8JWN2EZCSF0DT05RM?page=p-6-1) | 21 | NOT_YET_DEEP_REVIEWED |
| [p-5-1 — 03 · Options · Review](https://app.paper.design/file/01M3NSZGE8JWN2EZCSF0DT05RM?page=p-5-1) | 22 | NOT_YET_DEEP_REVIEWED |
| [p-4-1 — 02 · Options · Save + Watch](https://app.paper.design/file/01M3NSZGE8JWN2EZCSF0DT05RM?page=p-4-1) | 16 | NOT_YET_DEEP_REVIEWED |
| [p-3-1 — 01 · Options · Plan](https://app.paper.design/file/01M3NSZGE8JWN2EZCSF0DT05RM?page=p-3-1) | 12 | NOT_YET_DEEP_REVIEWED |
| [p-2-0 — Terminal · Options Structure Intelligence · R1 · 2026-09-27](https://app.paper.design/file/01M3NSZGE8JWN2EZCSF0DT05RM?page=p-2-0) | 28 | NOT_YET_DEEP_REVIEWED |
| [p-8-1 — Market Heatmaps · Unified Workspace · 2026-09-29](https://app.paper.design/file/01M3NSZGE8JWN2EZCSF0DT05RM?page=p-8-1) | 37 | NOT_YET_DEEP_REVIEWED |

## [PROPHET](https://app.paper.design/file/01M3NT5Y3G5HTJHVR0K5W2MDJM)

File `01M3NT5Y3G5HTJHVR0K5W2MDJM` · coverage: `all_pages_directory_observed` · pages: 6 · artboards: 104

| Page | Artboards | Disposition |
|---|---:|---|
| [p-1-0 — PROPHET](https://app.paper.design/file/01M3NT5Y3G5HTJHVR0K5W2MDJM?page=p-1-0) | 50 | NOT_YET_DEEP_REVIEWED |
| [p-6-0 — 05 · SOURCE ONLY · Prophet US Live Baseline](https://app.paper.design/file/01M3NT5Y3G5HTJHVR0K5W2MDJM?page=p-6-0) | 1 | REFERENCE_ONLY |
| [p-5-0 — 04 · Shared Contracts + State Coverage](https://app.paper.design/file/01M3NT5Y3G5HTJHVR0K5W2MDJM?page=p-5-0) | 8 | NOT_YET_DEEP_REVIEWED |
| [p-4-0 — 03 · Screener · Table, Grid + Compare](https://app.paper.design/file/01M3NT5Y3G5HTJHVR0K5W2MDJM?page=p-4-0) | 7 | NOT_YET_DEEP_REVIEWED |
| [p-3-0 — 02 · R2 · Today, Setup + Plans](https://app.paper.design/file/01M3NT5Y3G5HTJHVR0K5W2MDJM?page=p-3-0) | 19 | NOT_YET_DEEP_REVIEWED |
| [p-2-1 — 01 · Regional · Hong Kong + Canada](https://app.paper.design/file/01M3NT5Y3G5HTJHVR0K5W2MDJM?page=p-2-1) | 19 | NOT_YET_DEEP_REVIEWED |

## [International Markets · R10 · Current Build](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG)

File `01M3P1TW5Y3XWQC37ADDS8K5AG` · coverage: `all_pages_directory_observed` · pages: 7 · artboards: 134

| Page | Artboards | Disposition |
|---|---:|---|
| [p-1-0 — International Markets · R10 · Current Build](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG?page=p-1-0) | 12 | SELECTED_CONTENT_DEEP_REVIEWED |
| [p-7-0 — 06 · Returns Calendar · Terminal + Dossier](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG?page=p-7-0) | 7 | NOT_YET_DEEP_REVIEWED |
| [p-5-0 — 04 · Research Library + Search](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG?page=p-5-0) | 50 | NOT_YET_DEEP_REVIEWED |
| [p-6-0 — 05 · China Intelligence · vNext](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG?page=p-6-0) | 5 | NOT_YET_DEEP_REVIEWED |
| [p-4-0 — 03 · History + Scenarios](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG?page=p-4-0) | 5 | NOT_YET_DEEP_REVIEWED |
| [p-3-0 — 02 · Macro, Policy + Risk](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG?page=p-3-0) | 8 | NOT_YET_DEEP_REVIEWED |
| [p-2-0 — 01 · Overview, Compare + Navigation](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG?page=p-2-0) | 47 | SELECTED_CONTENT_DEEP_REVIEWED |

## [Mastermind AI](https://app.paper.design/file/01M3P1QEHS5XXQY85BJT6QR2E1)

File `01M3P1QEHS5XXQY85BJT6QR2E1` · coverage: `file_directory_observed` · pages: 7 · artboards: not fully counted

| Page | Artboards | Disposition |
|---|---:|---|
| [p-1-0 — Chat Workbench vNext · 2026-09-24](https://app.paper.design/file/01M3P1QEHS5XXQY85BJT6QR2E1?page=p-1-0) | — | NOT_YET_DEEP_REVIEWED |
| [p-4-0 — Legacy Reference Assets](https://app.paper.design/file/01M3P1QEHS5XXQY85BJT6QR2E1?page=p-4-0) | — | REFERENCE_ONLY |
| [p-3-0 — Answer Craft · R7–R8 References](https://app.paper.design/file/01M3P1QEHS5XXQY85BJT6QR2E1?page=p-3-0) | — | NOT_YET_DEEP_REVIEWED |
| [p-2-0 — Interaction + Recovery · R2 References](https://app.paper.design/file/01M3P1QEHS5XXQY85BJT6QR2E1?page=p-2-0) | 9 | NOT_YET_DEEP_REVIEWED |
| [p-7-0 — SOURCE ONLY · Chat Baseline](https://app.paper.design/file/01M3P1QEHS5XXQY85BJT6QR2E1?page=p-7-0) | — | REFERENCE_ONLY |
| [p-6-0 — QA HOLD · Duplicate Shared Shell · Not for Build](https://app.paper.design/file/01M3P1QEHS5XXQY85BJT6QR2E1?page=p-6-0) | — | REFERENCE_ONLY |
| [p-5-0 — Retained Shared Shell · Research Reading + Evidence](https://app.paper.design/file/01M3P1QEHS5XXQY85BJT6QR2E1?page=p-5-0) | — | NOT_YET_DEEP_REVIEWED |

## [MarketOntology](https://app.paper.design/file/01M3P1X4FR6BRTB13KA736Y1HT)

File `01M3P1X4FR6BRTB13KA736Y1HT` · coverage: `file_directory_observed` · pages: 5 · artboards: not fully counted

| Page | Artboards | Disposition |
|---|---:|---|
| [p-1-0 — Joined Journey · 2026-09-25](https://app.paper.design/file/01M3P1X4FR6BRTB13KA736Y1HT?page=p-1-0) | 12 | NOT_YET_DEEP_REVIEWED |
| [p-5-0 — QA HOLD · Duplicate Shared Shell · Not for Build](https://app.paper.design/file/01M3P1X4FR6BRTB13KA736Y1HT?page=p-5-0) | — | REFERENCE_ONLY |
| [p-4-0 — Retained Shared Shell · Company + Comparison Evidence](https://app.paper.design/file/01M3P1X4FR6BRTB13KA736Y1HT?page=p-4-0) | — | NOT_YET_DEEP_REVIEWED |
| [p-3-0 — Thesis + Changes + Receipts](https://app.paper.design/file/01M3P1X4FR6BRTB13KA736Y1HT?page=p-3-0) | — | NOT_YET_DEEP_REVIEWED |
| [p-2-0 — Answers + Context + Evidence](https://app.paper.design/file/01M3P1X4FR6BRTB13KA736Y1HT?page=p-2-0) | — | NOT_YET_DEEP_REVIEWED |

## [Noir Design System](https://app.paper.design/file/01M312VSDSZFVT45674GDVJVZN)

File `01M312VSDSZFVT45674GDVJVZN` · coverage: `navigator_reference_only` · pages: not yet observed · artboards: not fully counted


## [Market Guide](https://app.paper.design/file/01M32XYWDYSFTNDZVJKQ5QHT33)

File `01M32XYWDYSFTNDZVJKQ5QHT33` · coverage: `navigator_reference_only` · pages: not yet observed · artboards: not fully counted


## [Dashboard Popups / Risk Radar](https://app.paper.design/file/01M38EVF74SJWG1GANN5VP380Z)

File `01M38EVF74SJWG1GANN5VP380Z` · coverage: `navigator_reference_only` · pages: not yet observed · artboards: not fully counted


## Preservation-only reference

`01M3NQQ5KHTEZ50AGPT3RAD4BN` was found as a historical preservation duplicate. It was not inspected and is not a build source.

## Corrections to the old directory

* Intelligence Hub current work was extracted into **Refined vase**; main-file p-T-0 is not automatically authoritative because its title says R4.
* Four main-file pages are redirect-only, despite old product-looking names.
* Mastermind OS canonical Atelier p-D-0 now has **74** boards, not the directory’s old 58. International has **134**, not 62.
* Search-matched Library board label 102 has at least four distinct nodes (`3C4-0`, `3WS-0`, `3YE-0`, `400-0`). Choose no winner from the label alone.
* The page titled Returns Calendar inside International belongs to Terminal/dossier consumers, not automatically to `intl.html`.
* Study, source, held, duplicate and regional variants must not inflate the website route count.
