# Bounded worker commission template

Use the current Executive/Fabric job envelope where one exists. This document specifies content, not a competing job schema, queue, scheduler or authority store.

## Identity and admissibility

```text
Parent operation / accepted assignment: <actual reference>
Task: <e.g. IM02-T2>
Responsible project lead: <accepted receiver>
Source repository / immutable base: <actual repo + SHA>
Managed workspace / exact owned branch: <existing registry reference>
Granted file allowlist: <specific files; no whole-repo wildcard>
Excluded surfaces: <engines/auth/publisher/global shell/etc. not assigned>
Requested economical avenue: <GLM Flash or Minimax M3, as suitable>
Actually admitted model + harness: <registry result, not an invented alias>
Budget, time, child depth and tools: <existing grant; unknown does not mean unlimited>
Input artifact references + SHA256: <small assigned subset>
Return carrier / recipient: <existing accepted owner>
START state: <actual receipt or not started>
```

## Outcome and implementation limits

State the user's observable capability in two or three sentences. Include the exact screen/state and contract excerpt, current source seam, what should be retained, and the decisions already made. A worker must not need to inventory Paper or reverse-engineer the whole website.

Specify ordinary choices the worker may make without a parent round trip. Give a bounded repair allowance through the existing grant. Name the few reasons to escalate: contract contradiction; out-of-scope source change; missing admitted input; source collision; safety/permission denial; ambiguous effect. No worker inherits the parent's credential, Paper session, source-writer lease or unbounded spawn authority.

## Tests and acceptance

Provide the relevant existing tests, new discriminating fixtures and acceptance outcomes. Require at least one meaningful negative control for a repaired truth/identity/interaction boundary. Use actual source/head-bound results. Screenshots alone do not prove an interactive journey; source tests alone do not prove visual/live acceptance. No skipped/missing fixture can become a silent pass.

## Return format

```text
Task and actual execution identity:
Exact base/head and artifact SHA256:
Changed files:
Capability implemented:
Requirement-to-evidence mapping:
Tests actually run / results / known-bad controls:
Screenshots and source binding, if relevant:
Preserved compatibility:
Unresolved gaps and blocked actions:
No-effect / effect state where relevant:
Next decision needed:
```

Return a compact summary plus immutable evidence. The lead reads the underlying artifacts selectively, accepts or requests bounded repair, and records the decision in the incumbent owner. Do not append full provider transcripts to every parent prompt.

## Example: IM02-T2 attribution worker

**Outcome:** render local return, FX contribution in percentage points, and USD return for the selected qualified comparison; provide a deterministic explanation of the change in the inter-market spread only when both windows and legs qualify.

**Input:** accepted IM-00 view contract, `IM-02_COMPARE_ROTATION.md` §§3–5, the assigned comparison partial/helper, exact synthetic fixtures, and `compare-mobile/reference.jsx` plus JPEG. No Paper access or new provider is required.

**Non-goals:** no FX fetch, new score, rotation formula change, chart data synthesis, account state, monitor, publisher or shared global CSS. Do not make a rounded legacy value “more precise”.

**Acceptance:** actual template/projection tests cover positive, negative, zero, missing FX, unequal windows, wrong unit, NaN/bool, and rounding ambiguity; USD and local plus FX contribution reconcile from the accepted unrounded payload; source strings escaped; no formula copied into an unrelated client engine. Return the exact file/head, results and any numerical contradiction to the project lead.
