# Astra Meta-CEO — Website Paper implementation programme

## Assignment and boundary

The user commissioned a careful, staged conversion of implementation-ready Paper designs into the existing Mastermind website, preserving useful old features and reducing frontier orchestration labor. This packet supplies the first source-grounded build batch, not a blanket approval to rewrite all pages. The user asked for handoffs; **no worker has been dispatched, no source custody transferred, and no product implementation or release is claimed here**.

On deliberate delivery of this packet by the user or accepted assignment owner, take the programme-level role. Do not interpret a retrieved document alone as worker assignment or permission to replace a current source writer. Follow current Executive/Fabric admission, source custody, review and release rules.

**First usable batch:** IM-00 foundation → IM-01 Overview + IM-02 Compare & Rotation + IM-03 read-only Country Inspector. The deep census and engineering decisions are already in the packet. Do not ask a frontier agent to repeat them. Current-state checks should be limited to material source/design/interface/custody invalidators.

## 1. Desired hierarchy, with economical instantiation

Use the user's preferred logical structure:

```text
Astra Meta-CEO — programme priorities, cross-domain architecture exceptions, final programme acceptance
  Sol 5.5 domain CEO — contract acceptance, source custody, integration, quality/release decisions
    Grok / GLM / Cursor project lead — page-level decomposition, worker direction, review and repairs
      GLM Flash / Minimax M3 — tightly bounded implementation and tests
```

These are **requested role/model preferences, not verified runtime model IDs, entitlements, capacities or granted child depth**. Cursor is also a harness/avenue, not a guarantee of a particular underlying model. Resolve actual registered models, available capacity, capability profiles, budget and child/depth grants through the current router/fabric owner. Do not silently route a cheap leaf to frontier GLM when GLM Flash was intended. Record the actual route and explain a substitution.

Logical layers do not require four continuously running agents for every leaf. Begin with **one Sol International CEO**. Instantiate a project lead only for a coherent work package large enough to justify its framing/review cost. Do not create separate CEOs for desktop/mobile, EN/ZH, light/dark or individual state screens. If the fabric's admitted maximum depth is lower, preserve the same accountable roles using its supported job graph; do not build another spawn system or bypass depth grants.

Fable is not the default implementation or review worker for this programme. **WHY NOT FABLE:** the first batch has frozen contracts, exact source seams and bounded review questions; its scarce principal capacity is not needed for routine design translation. Escalate genuinely unresolved cross-domain authority/architecture rather than spending frontier turns on ordinary layout repair.

## 2. What Astra should and should not do

Astra approves priorities, resolves a genuine cross-program conflict, consumes a compact accepted milestone and ultimately judges the whole user outcome. Astra should not inspect every artboard again, export screenshots, dispatch every leaf directly, manually copy patches, re-run every test, or keep a conversation active to poll a job.

Sol owns the domain delivery graph: contract acceptance, ownership conflicts, critical source semantics, integration, independent quality review and release evidence. Sol may do consequential judgment, but should not become the CSS worker. A page lead sends complete outcome packets, consumes worker returns, permits bounded repairs within the admitted grant and escalates only genuine contract/architecture issues.

Leaf workers implement and test their assigned component/adapter against a small source/reference subset. They cannot widen into scoring, auth, publisher, shared navigation, provider configuration or another page merely because they discover a problem there. Record a disjoint finding for the owner; do not silently absorb it.

## 3. Minimal pre-START checks

The receiving Sol performs these exact checks once, then begins useful work:

- Verify packet manifest and native design-pack digest; read the named contracts and selected references.
- Compare current Macro source with audited `d0f14c62544daca98258cbf68a5e1e3bef54ab74` on the **named International owners and shared seams**. Check current exact-path PR/workspace custody, not just titles. Preserve live or effect-unknown writers. PR #7001's publisher lane and #7872's risk-authority lane are adjacent, not permission to take them over.
- Resolve a registered managed workspace and source branch through the existing workspace owner. Do not write in the stale shared checkout just because it contains the repo.
- Verify admitted worker avenue/model, tool capabilities, confidentiality/rights, budget, child depth, artifact access and return channel. An online device or a listed model alone is insufficient.
- Verify the applicable browser-permission state. Existing administrator denial is not cleared by another account, browser, host, port or scheme. It gates browser/release evidence, not otherwise permitted source work.

Do not reopen every historical handoff. Refresh only material invalidators. The local source checkout seen during this audit was behind the immutable source pin; explicit commit reads were used. A normal current-main comparison is necessary, not a new product census.

## 4. Build graph and integration ownership

```text
S0  custody + grant + source/design drift check
 └─ F1  IM-00 performance precision/series/metadata seam
     ├─ F2  pure view model and qualification fixtures
     └─ F3  one route/context controller
          ├─ V1  IM-01 overview components
          ├─ V2  IM-02 comparison components
          └─ V3  IM-03 inspector/evidence components
              └─ I1  single writer mounts accepted components in builder/template
                  └─ Q1  independent source, semantic and feature-preservation review
                      └─ Q2  permitted real-browser integration/rights proof
                          └─ R1  existing release/publication owner + real served journey
                              └─ R2  subsequent normal publication preserves the upgrade
```

Component markup/styling can start against accepted synthetic fixtures while the compatible source extension is being completed. A fixture-ready component is not data-integrated. Do not block unrelated components on a browser permission gate; do not release them without required browser acceptance either.

**One integration writer** owns `scripts/build_intl.py`, the shared `templates/intl.html.j2` mount, final shared controller assembly and asset integration. Page leads own their actual disjoint partial/component paths. Shared CSS or JS edits are serialized or split into explicit imported files before fanout. Every job lists exact allowlisted files; path overlap is a custody decision, not something to leave to competing workers.

## 5. Quality gates that cannot be traded for speed

**Gate A — source contract:** exact financial identity, units, unrounded values, common windows, metadata qualification, no zero-fill, no new financial authority.

**Gate B — feature preservation:** all 18 audited legacy families remain reachable; stocks mode and five country routes still work; no duplicate controllers or publisher.

**Gate C — interaction:** overview expansion, comparison pins, inspector/evidence Back, focus and scroll preservation, no-JS fallback, responsive and localized states.

**Gate D — rights/effects:** denied values not serialized; actual source links; no Follow/Saved/Delivered claims without proven incumbent owners; no writes from read navigation.

**Gate E — release proof:** exact-head tests/CI, author-distinct independent review, real-browser evidence, accepted publication, served-page binding and a normal subsequent publication. Green source tests do not satisfy all five gates.

A source-review PASS must not be represented as visual, market-validation, authenticated or production acceptance. Test runs that silently omit sparse fixtures are not full passes. Browser proof remains an explicit held gate until permission genuinely permits it.

## 6. Efficient work and return policy

Use `WORKER_PACKET_TEMPLATE.md`. Send each worker the assigned contract excerpt, one or two screen/state references, relevant source files and explicit tests—not the complete 1,589-artboard census. A numerical worker normally needs no Paper session. A visual worker needs admitted image/JSX access and suitable visual capability; a text-only worker should not be assigned independent visual acceptance.

Let accepted grants, available capacity and review throughput bound fanout. Do not multiply a per-account allowance across nested agents. A reasonable initial scheduling preference is a small number of independent leaves while integration/review catches up; this is not a grant to increase concurrency. Stop expanding work when completed returns exceed the lead's review capacity.

The return is a compact decision packet: exact source head and artifact digest; changed files; requirement coverage; actual tests and meaningful negative controls; key screenshots; unresolved issues; next needed decision. Full transcripts stay with their existing owner. Repeated identical failure without new evidence requires a changed hypothesis or escalation within current retry policy, not unlimited cheap-model loops.

The project lead classifies the return, requests bounded repair or accepts the component. Sol reviews material semantics/integration and consumes independent evidence. Astra receives only accepted milestones and substantive exception requests, not every worker ACK or routine retry.

## 7. Held work and scope protection

Do not turn this first build batch into an active monitor programme, global framework migration, new factor engine, historical replay, account-store build or a new website-wide design system. Deep R10 Macro/Risk, History/Scenarios, Library/Saved, company exposure and returns-calendar consumer packets are outstanding. Preserve current functionality until those packets exist.

Bonds/Forex already have implementation candidates (#8241/#8243/#8326); later handoffs must reconcile them instead of commissioning replacements. Mastermind OS, Terminal, Prophet, AI and MarketOntology have separate application/state owners. Their directory presence is not approval to build them all from this International plan.

## 8. First commission text

> Sol International CEO: consume this Wave 1 packet and its source/design manifests. Take ownership of the permitted International implementation graph without repeating the completed census. Verify only material current-source/design/custody/grant changes. Commission IM-00 first, then the three bounded views through the current admitted fabric using the requested economical hierarchy where supported. Preserve every source, rights, numerical, feature-parity and release boundary in these handoffs. Keep one shared integration writer, use existing data/persistence/navigation/publication owners, and return accepted milestones or precise exceptions. Active Follow/Saved writes, advanced factor systems, new historical ledgers and unrelated application rewrites are held. Do not claim dispatch, acceptance, deployment or live proof without the actual corresponding receipt.

This text is ready for deliberate user/owner delivery. Its inclusion in an attachment does not itself start a job.
