# Research receipt — Wave 1

Audit date: **6 October 2026 (UTC)**. This is a design/source-research receipt, not release evidence.

## What was actually observed

* The guarded Paper adapter inspected six files and every page returned by their live directories: **78 pages / 1,589 artboards**. Every page has a saved `get_basic_info` response on M2. This is directory completeness for those six files, not a visual review of 1,589 artboards, and not a workspace-wide enumeration.
* The published working-file navigator identified five additional files. Mastermind AI and MarketOntology were subsequently inspected at file-directory level; their full page/artboard census is still outstanding. Noir Design System, Market Guide and Dashboard Popups are discovered references, not inspected files in this wave. A preservation duplicate is recorded separately and is not a build source.
* International R10 has **7 pages / 134 artboards**, rather than the stale “62 boards” label. Its Overview/Compare/Navigation page has 47 artboards. The selected product screenshots actually viewed were `1-0`, `6G-0`, `VK-0`, `2AM-0`, `805-0`, `8AM-0` and `50H-0`. Native JPEG and inline-style JSX exports of these seven have been saved on M2.
* Full native specification text was read for `P9-0` (90), `Q2-0` (91), `R0-0` (92), `2FN-0` (93), and `5IR-0` (127, including its later sections 08 and 09). Directory/authority boards `3RW-0`, main-file `5G0X-2`, and Mastermind OS `A2Q-0` were also read. Other board names and dimensions alone are not design acceptance.
* All source findings in this packet bind to **Macro `d0f14c62544daca98258cbf68a5e1e3bef54ab74`**, observed from the protected `main` ref. Local checked-out Macro HEAD was different; source inspection used `git show <exact-sha>:<path>`, not that working tree.
* The protected Mastermind procedure pin inspected was `877b1e7f275da0b6d3558d2667778b32d628bf67`. This is separate from installed runtime pins.
* A public live-page fetch timed out. Chromium navigation to the requested International route returned `net::ERR_BLOCKED_BY_ADMINISTRATOR`. No alternative hostname, host, profile or browser was used to evade that restriction. **There is no live-site screenshot, authenticated production journey, or served-source equivalence proof in this packet.**
* No product source, Paper document, production data, provider account, monitor, alert, deployment, or runtime job was modified. No worker was commissioned. The only writes are research/export/handoff artifacts.

## Exact source files and inspection bounds

| Source at the Macro pin | Inspected evidence |
|---|---|
| `scripts/build_intl.py` | Full source saved, 962 lines; initial section, owner calls and lines 660–962 read, plus targeted calls/outputs throughout |
| `templates/intl.html.j2` | Full source saved, 2,214 lines; first 135 lines, complete heading/section discovery, and lines 2060–2214 read; not a claim that every template line was semantically reviewed |
| `engine/intl_performance.py` | `usd_series`, `_local_aligned`, `_ret`, `_ytd_ret`, `_spark`, `usd_leaderboard`, `correlation_matrix`, `performance_panel`; function inventory and return locations |
| `tests/test_intl_performance.py` | First 190 lines, including conversion, decomposition, calendar alignment, ordering, RRG and correlation controls |
| `engine/intl_rotation.py` | First 230 lines: display-only score, governors, missingness behavior and ranking |
| `engine/intl_compare.py` | First 175 lines: metric rankings, heatmap, periphery, summary |
| `engine/intl_inputs.py` | Function/forward-fill inventory; lines 119–171 and 181–265 read |
| `engine/intl_run.py` | Country-record/persistence/clock field locations; not a complete semantic review |
| `scripts/build_international_macro.py` | First 190 lines: required five-route build, existing view contract, risk adapter, dossier/news composition |
| `engine/international_macro_dashboard.py` | First 145 lines, JP region specification and exact route enumeration; not all country logic reviewed |
| `tests/test_intl_build.py` | First 160 lines, including both-mode and descriptive-only regression contracts |
| `data/intl/latest.json` | First 108 lines of the pinned artifact, including JP record date, CPI period, null real yield and `data_limited` |

Use immutable source links in `SOURCE_AUDIT.md`. A source-read receipt is not a passing test receipt.

## M2 evidence anchor

`/Volumes/Mastermind/agent-evidence/paper-implementation-census-20261006-c3/`

This holds the full six-file census, 78 raw page observations, seven selected screen exports, native specification receipts, and exact saved builder/template source. It is a host path, **not a sandbox download URL**. The portable design-evidence archive and its checksum are listed in `DESIGN_ACCESS.md`; the v2 archive and all 22 payload digests were verified on M2.

## Current ownership checks

Observed through exact GitHub/`gh` reads, not inferred from old comments:

| PR | Observed disposition / source head | Use in this programme |
|---|---|---|
| Macro #7001 | OPEN; `3684c7d51a0b5d894314c369b408896f54df2ffd` | International publication checkpoint; touches `.github/workflows/daily.yml` and `scripts/ci/daily_engine_intl_checkpoint.sh`. Do not duplicate or replace publication ownership. |
| Macro #7872 | Open list; Draft; `5d6ae511c7b82b05e175ba7ea36e2fc5003b6502` | Adjacent International Risk Radar authority work; reconcile before touching risk interpretation. |
| Macro #8241 | OPEN / Draft; `33824eb66a76bc6bd2293c9255c5680e54128e9f` | Existing Bonds R11 duration integration, not a blank-page build. The PR body still cites an earlier head; metadata is the fresh identity. |
| Macro #8243 | OPEN / Draft; `bf3caf5257301f1a32db6803ba04a1c75a8e44f0` | Existing Forex movement-evidence integration. |
| Macro #8326 | OPEN / Draft; `0f9bd7d73367c65b5d956252cda4ae3a049c0dda` | Existing shared Bonds/Forex projection and Macro Context consumer. |

The title-scoped International PR search is **not** a comprehensive path-collision census or a live source lease. START requires the existing source-custody owner to qualify the exact touched paths. No lease was acquired in this research wave.
