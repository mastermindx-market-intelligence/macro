# International R10 — current-source audit and preservation map

**Audit basis:** Macro [`d0f14c62544daca98258cbf68a5e1e3bef54ab74`](https://github.com/mastermindx-market-intelligence/macro/tree/d0f14c62544daca98258cbf68a5e1e3bef54ab74). These are repository facts, not assertions about bytes currently served to a user. Inspection bounds are in `evidence/RESEARCH_RECEIPT.md`.

## 1. Use the current stack, not a new website framework

The International page is a **Python-produced Jinja page with existing CSS and browser JavaScript**. [`scripts/build_intl.py`](https://github.com/mastermindx-market-intelligence/macro/blob/d0f14c62544daca98258cbf68a5e1e3bef54ab74/scripts/build_intl.py) assembles existing domain outputs; [`templates/intl.html.j2`](https://github.com/mastermindx-market-intelligence/macro/blob/d0f14c62544daca98258cbf68a5e1e3bef54ab74/templates/intl.html.j2) renders them. Its final VM contains `latest`, `records`, `summary`, `rankings`, `heatmap`, `periphery`, `sector_board`, `setups`, `perf`, `rates`, `risk_desk`, `CGL`, `turn_board`, `turn_events`, `rotation_ranks`, and `bench_note`.

**Important shared seam:** the same template renders **both** `site/intl.html` (`mode="macro"`) and `site/intl_stocks.html` (`mode="stocks"`). A wholesale template replacement can break stock setups while its new International screenshot looks correct. Preserve the stocks branch and its tests. `intl_stock.html` remains a separate existing shell. Use the normal asset-copy, page-writer, normalization and publication owners.

The builder also calls the required five-country dashboard build. Keep `japan.html`, `south_korea.html`, `euro_area.html`, `united_kingdom.html`, and `india.html` intact. These routes are explicitly registered in [`engine/international_macro_dashboard.py`](https://github.com/mastermindx-market-intelligence/macro/blob/d0f14c62544daca98258cbf68a5e1e3bef54ab74/engine/international_macro_dashboard.py). Taiwan and Australia must not be assigned invented dedicated country routes.

No React/Next.js migration, Electron dependency, universal financial API, new state store, new pipeline or parallel forward ledger is justified by this page. Paper JSX is **implementation reference**, not a mandate to replace the runtime stack. Terminal and Mastermind OS are separately owned applications.

## 2. Blocking semantic differences between the mockup and the source

| ID | Observed disagreement | Implementation decision |
|---|---|---|
| S01 | R10 sample labels Japan as TOPIX. Current inputs/tests and country specification use **Nikkei 225 / `^N225`**. | Render the owner-supplied index identity. Never label Nikkei values TOPIX. A genuine index migration is a different source-contract task. |
| S02 | `usd_leaderboard` rounds all three legs to **one decimal**. R10 uses two decimals and its compact-list specification sorts **unrounded** returns. | Add a compatible exact-value projection inside the existing performance owner; preserve old one-decimal fields for current consumers. Do not reconstruct precision from rounded JSON or merely append a zero. |
| S03 | `_spark()` takes a trailing 252-observation series, downsamples to about 64 points and returns values without timestamps. R10 compare needs the selected window with explicit endpoints and a common base. | Supply timestamped, qualified comparison data from the existing performance calculation. Never stretch the old sparkline or draw the illustrative Paper path as market data. |
| S04 | Current leaderboard defaults to rotation score, otherwise 12-month returns. R10 overview defaults to the selected **1-month price-return** lens. | Keep distinct, named views: selected-horizon return ordering versus existing display-only rotation score. Preserve old rotation capability in deeper comparison/library views. |
| S05 | The pinned JP artifact says record date `2026-10-05`, CPI observation month `2021-06`, `cpi_yoy=-0.5`, and `data_limited=false`; real yield is null. | Treat the field clock, not record generation or `data_limited`, as the source of currency/freshness qualification. Do not present this old CPI as current inflation or use it to confirm current macro conditions. This is an artifact diagnosis, not a claim about Japan’s actual current CPI. |
| S06 | Except for EZ’s explicit deposit-rate path, `intl_inputs.country_frame` assigns `policy_rate = short_3m`. | Carry a **short-rate proxy** basis where applicable. Do not rename that number “BoJ policy rate” or an official decision. A current official series requires its actual owner and provenance. |
| S07 | `usd_series` forward-fills on the union of equity and FX calendars without a per-leg stale limit in that function. | Preserve old math for compatibility, but bind raw observation clocks and accepted source qualification before allowing a row into the new current ranking. Unknown freshness remains unknown; do not invent a page-specific freshness regime. |
| S08 | `intl_rotation.rank` converts unavailable RS windows to zero inside its existing score calculation, and emits a state-governed display score. | Do not treat a numeric score as proof all windows exist. Add projection-level availability from the underlying owner inputs. No score-weight, governor, risk-gate or trading-authority changes are in this UI programme. |
| S09 | The benchmark helper can substitute SPY for stale `^GSPC` and provides `bench_note`. | Identity and substitution notice must travel with chart, attribution, export and evidence. “S&P 500” alone must not hide an ETF substitution or a still-stale source. |
| S10 | Seven-market international returns/rotation coexist with a **ten-market** World Risk Appetite surface including US/CN/HK. Correlation includes the US benchmark separately. | Preserve explicitly named scopes. World-risk coverage cannot enlarge the seven-country leaderboard or constituent denominator. Do not silently remove the legitimate US benchmark from correlation. |
| S11 | Desktop inspector board `805-0` shows an older full-list background; current overview `1-0` and spec `5IR-0` §09 use compact first disclosure. | Use `1-0` for the base page and `805-0` for inspector composition. Do not regress the overview by copying the inspector’s background. |
| S12 | Earlier evidence language can suggest stacked drawers; the later `5IR-0` §08 says evidence replaces content **inside one inspector shell**. | One responsive inspector/controller, with nested navigation state—not a second modal controller mounted on top of the first. |
| S13 | Some saved/follow/advanced-factor designs have complete-looking success screens, but their data, auth, persistence and delivery contracts are not verified here. | Visual existence is not executable authority. Keep explicit unavailable/draft states and separate qualification tasks. Never emit optimistic Active/Saved/Delivered. |

Sources: [performance owner](https://github.com/mastermindx-market-intelligence/macro/blob/d0f14c62544daca98258cbf68a5e1e3bef54ab74/engine/intl_performance.py), [input owner](https://github.com/mastermindx-market-intelligence/macro/blob/d0f14c62544daca98258cbf68a5e1e3bef54ab74/engine/intl_inputs.py), [rotation owner](https://github.com/mastermindx-market-intelligence/macro/blob/d0f14c62544daca98258cbf68a5e1e3bef54ab74/engine/intl_rotation.py), [pinned artifact](https://github.com/mastermindx-market-intelligence/macro/blob/d0f14c62544daca98258cbf68a5e1e3bef54ab74/data/intl/latest.json), and Paper `5IR-0` / `Q2-0` at the [R10 specifications page](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG?page=p-1-0) and [journey page](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG?page=p-2-0).

## 3. Frozen financial interpretation

Normalize FX to **USD per unit of local currency** before describing the relationship. In decimal-return notation:

```
r_usd = (1 + r_local) * (1 + r_fx_usd_per_local) - 1
fx_contribution_pp = 100 * (r_usd - r_local)
```

The displayed FX contribution includes compounding interaction. It is **not** the raw exchange-rate percentage change. For a USD/JPY quote the USD-valued equity series divides by that quote; GBP/USD multiplies. Both legs must use the same observation endpoints. Return percentages, percentage-point contributions and basis points must have different unit types. The current test suite already protects orientation and identical equity/FX calendars; preserve these tests.

The current default horizon configuration is `1m=21`, `3m=63`, `6m=126`, `12m=252` observations, with YTD from the last prior-year point. The new projection must expose the actual start/end/session basis. Do not quietly call a union-calendar 21-observation window exactly one calendar month, or exactly 21 local exchange sessions. A cross-market common-period comparison needs its own **explicit projection policy over existing inputs**, compatible with the accepted source calendar and missing-data policy, and must label any mismatch with the individual-market leaderboard. Never disguise unequal windows as like-for-like.

The existing display-only rotation score is not simply return rank:

```
raw = 0.5*rs20 + 0.3*rs10 + 0.2*rs5
score = state_governor*raw - overbought_penalty - macd_penalty
```

Those coefficients and governors are **not** being redesigned here. No macro gate is to be added. Past rank movement is not capital flow. A claim that rank changed requires two compatible snapshots with universe, definition, basis and time identity; this audit did not prove such a historical owner. Withhold the arrow/history rather than inventing it.

The correlation owner uses **weekly W-FRI returns**, its own configured window and minimum observations, not whichever one-month selector is showing in the header. Likewise annual structural vulnerability, fixed credit-change windows and source release periods remain independent clocks.

## 4. Preserve useful legacy functionality through progressive disclosure

This is the minimum non-removal map. The first three handoffs build the entry journey, not all deeper research pages. Until a deeper view has its own accepted packet, retain the actual legacy section/route under a clearly named “Detailed research” disclosure or existing library entry. A dead link or an empty “coming soon” replacement is not feature parity.

| Existing capability | Current owner/VM seam | New destination / preservation obligation |
|---|---|---|
| USD/local/FX return decomposition and horizon switching | `intl_performance.usd_leaderboard`; `perf.leaderboard` | Overview expanded detail + Compare. Preserve units and endpoint identity. |
| US-versus-world relative strength / rotation quadrants | `intl_performance.relative_to_us`; `perf.rrg` | Compare advanced disclosure. Descriptive relative leadership, not money flow. |
| Display rotation rankings and turn notes | `intl_rotation.rank`; `rotation_ranks`, `turn_board` | Compare rotation section; distinguish rank score from selected-window return order. |
| Market turns and recent events | `intl_market_state`, recovery naming; `turn_board`, `turn_events` | Overview contextual changes / country detail / retained history. Do not infer events from a missing row. |
| Cross-country macro comparison | `intl_compare.rankings`, records and `macro_asof` | Macro & Policy / full comparison. Field-level dates and proxy basis required. |
| Growth/inflation regime map and metric rankings | `intl_compare.regime_heatmap`, `global_summary` | Macro & Policy / Library. Descriptive composite, not a new global confidence. |
| Rates/curve and liquidity anchors | `intl_rates.rates_desk`; `rates` | Macro & Policy. Units and source cadence do not follow the equity-period selector. |
| Euro-area fragmentation | `intl_compare.periphery_panel`; `periphery` | Macro & Policy → Euro fragmentation. Keep bps and widening/change horizon. |
| Central-bank stance, balance sheets and meetings | `cb_desk` via existing builder | Macro & Policy. Realized stance is not forward guidance; missing regional balance sheets remain missing. |
| Inversion and bond/credit stress | `intl_bonds` / existing risk payload | Macro & Policy and Risk. Do not promote old or absent credit data to current. |
| Dollar drivers and FX context | Existing Forex artifact and risk payload | Risk & Transmission with source-as-of and proxy limitations. |
| Annual fragility/vulnerability | `intl_risk.vulnerability_table` | Risk & Transmission / structural research. Annual denominator and date remain explicit. |
| Spillover and correlation tightening | `contagion` via current builder | Risk & Transmission. Association is not causation or forecast. |
| Trade/contagion links | `contagion_links.snapshot`; `CGL` | Risk & Transmission / linked-country evidence. Keep existing event/ledger owner. |
| World risk appetite, including US/CN/HK | `perf.risk_appetite` plus world states | Separate global-context disclosure; retain ten-market coverage and weighting explanation. |
| Cross-market correlation | `perf.correlation` | Compare advanced / Library; weekly-return methodology and US reference retained. |
| Country sectors, stock setups, alpha/library | `intl_stocks.panel`, `compute_intl_alpha`, `sector_board`, `build_intl_library` | Existing stock/library routes. Preserve AddedDate owner and no duplicate stamping. |
| Calibrated risk / track-record evidence where valid | Existing risk-radar/profile/ledger owners | Existing risk evidence route. Never manufacture forecast permission or merge it into the new summary score. Source acceptance is separately owned. |

The source/spec map references some deeper families whose complete producer implementation was not read in this wave. Their preservation destination is frozen; their full redesign handoff remains explicitly outstanding.

## 5. Existing dossier and evidence limits

[`scripts/build_international_macro.py`](https://github.com/mastermindx-market-intelligence/macro/blob/d0f14c62544daca98258cbf68a5e1e3bef54ab74/scripts/build_international_macro.py) already consumes `international_macro_dashboard.v1`. The country-dossier code documents rights-cleared EU/UK sources and explicit `no_coverage` for JP/KR/IN. A Japan inspector must not fabricate an official-news dossier simply because a policy evidence mockup exists. The current risk-card adapter also has an odds gate; do not silently “fix” risk authority while adding the inspector.

The audited macro freshness map exposes observation **months** for CPI, GDP, unemployment and 10-year yield. It does not provide all of Paper’s publication, ingestion, known-at, revision and methodology clocks. Carry null plus a reason for missing metadata; do not upgrade a month to a fabricated exact timestamp or use build time for all clocks.

## 6. Test and publication implications

Existing tests to preserve include `test_intl_build.py`, `test_intl_performance.py`, `test_intl_compare.py`, `test_intl_rotation.py`, `test_intl_mobile_layout.py`, `test_intl_session_asof.py`, `test_intl_market_state.py`, `test_intl_market_confirmation.py`, `test_intl_recovery_quality.py`, `test_intl_rates.py` and the international country-dashboard/dossier suites. Not all were executed or fully read in this audit. Future CI must identify its real owning job and import closure, not just add a passing orphan test.

Do not run the full builder casually in a shared tree: it writes artifacts and invokes existing flow/ledger-adjacent owners. Build tests must isolate paths and stub the **effect seams**, not rewrite financial logic or call production collectors. Several non-core failures return exit code zero. Therefore “command exited 0” is insufficient: assert output existence, current source binding, expected sections/schema and non-stale publication explicitly.

PR #7001 remains a separate publication checkpoint candidate. This redesign must not create another publisher or edit the daily workflow by accident. Keep generated pages and copied assets consistent through the existing build/normalize/publish path. A tested source commit, a generated local page, a deployed artifact, an authenticated browser journey and a natural subsequent publication are separate evidence levels.
