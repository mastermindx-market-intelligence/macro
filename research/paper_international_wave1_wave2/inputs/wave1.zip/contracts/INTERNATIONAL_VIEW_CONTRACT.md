# Proposed International presentation contract

**Design specification, not an installed API.** Implement inside existing International owners and one pure display adapter. Suggested internal schema ID: `intl_workspace_view.v1`. An equivalent accepted incumbent takes precedence; document the mapping. This is not a new durable store, public service or lifecycle authority.

## Envelope

The projection carries `schema`, an existing producer/source reference, calculation revision when actually known, generation time, declared market universe, supported view capabilities, current presentation context, market rows, source evidence, and deep-link targets. A deterministic content digest can bind test/export evidence; it must not create a new central generation registry.

Do not confuse generation time with observation, publication or ingestion time. Do not infer a complete design revision from Paper's token hash.

```text
Context
  view: overview | compare | macro | risk | history | library
  selected_market: canonical ID or null
  compare_markets: ordered unique list, at most 4
  horizon: an actually supported owner horizon
  currency_basis: local | usd_unhedged
  return_basis: price (until another basis is genuinely supported)
  benchmark_id: real source identity or null
  eligible_universe_id: existing definition/reference
  source_reference: existing generation/revision or explicit unknown
```

One selected market is allowed as an incomplete comparison draft, but the chart is withheld until 2–4 qualified selections exist. Resizing never drops comparison pins. Unsupported options are visibly unavailable rather than silently interpreted as another mode.

## Metric and evidence records

A metric record has its own quality, semantics and provenance. A panel may be partial while one metric is qualified. `null` is not zero. A fresh observation is not automatically entitled; entitlement is decided by the existing server-side owner before value serialization.

```text
Metric
  key: closed known field name
  market_id: canonical country/region identity
  instrument_id: actual index, rate or series identity when applicable
  value: finite number | null
  unit: percent | percentage_points | basis_points | index_level | count | ratio
  quality: qualified | stale | missing | denied | failed | unsupported | unknown
  reason: stable explanatory reason; required when not qualified
  interpretation: observed | proxy | model_estimate | descriptive_composite
  window: start, end, cadence, calendar_policy, return_basis, currency_basis
  denominator: eligible_n, observed_n, universe_reference (where meaningful)
  evidence_refs: exact available source-field references
  calculation_revision: real owner revision or null with reason
```

`interpretation` and `quality` are separate. A properly dated proxy can be qualified **as a proxy**, but cannot be relabeled as an observed official rate. A source-wide rights denial can also prohibit disclosing a label or URL; use the existing access policy, not a universal “all metadata is safe” assumption.

```text
Evidence
  evidence_id: stable owner field/reference, or packet-local nonpersistent reference
  source_owner: existing module/artifact/service
  source_record_ref: actual record reference or null
  rights: accepted owner state/reference; denied fields removed before JSON
  observation: {value, precision, timezone} | null
  publication: {value, precision, timezone} | null
  ingestion: {value, precision, timezone} | null
  generation: {value, precision, timezone} | null
  revision: actual revision or null
  unit, basis, methodology: explicit supported values
  missing_metadata_reasons: named absent fields and reasons
```

A temporal reference's precision is `year`, `month`, `day`, or `instant`. A source month such as `2021-06` stays month precision; do not turn it into midnight on the first day. An instant needs a timezone/UTC identity. Chronology validation cannot compare incomparable precisions as though they were exact instants. A later generation does not freshen an older observation.

## Market identity and return payload

Core international universe is currently JP/KR/TW/IN/AU/GB/EZ, subject to the actual source configuration at START. World-risk context and US reference remain separately scoped. Never derive economic exposure from an exchange/listing country.

Each market row includes `market_id`, localized name, actual index identity, independently qualified local/USD/FX-contribution metrics, a source-owned turn state with its own horizon, and optional supported evidence. Unknown turn data stays unknown; it does not become neutral.

Financial invariants in decimal-return notation:

```text
usd_return = (1 + local_return) * (1 + fx_return_usd_per_local) - 1
fx_contribution_pp = 100 * (usd_return - local_return)
```

When displayed in percentage units, `usd_percent = local_percent + fx_contribution_pp` before rounding. Display-rounding tolerance is a formatting question, not permission to change exact arithmetic. The field named `fx` in the old return object is a contribution; do not rename it “FX return”. Keep existing rounded fields for legacy consumers while providing genuinely unrounded values to the new view.

## Chart projection

Each series contains actual instrument identity, timestamped qualified points, exact first/last calculation endpoints, currency/return basis, source/quality reasons and an explicit sampling policy. `normalized_100 = 100 * price_at_t / price_at_start` is computed only with a positive qualified start and compatible data. Endpoints must survive any downsampling; missing segments must remain gaps. Do not normalize an empty series, a zero start or mixed definitions.

The comparison bundle also states the common-window policy and any difference from individual headline horizons. The benchmark is a separate series/reference with actual substituted identity when applicable. No automatic numerical confidence, no synthetic chart reconstructed from a percentage endpoint, and no hidden browser fetch to another provider.

## Compact selection

Sort qualified returns by exact value descending, then canonical market ID ascending. With more than four eligible markets, show the highest three plus the lowest remaining market. With four or fewer, show every eligible market once. Excluded markets remain in full detail with a reason. Counts refer to eligible coverage; the configured universe is separately named. Avoid “winner” language when all values are negative.

Expanded state shows the same generation and context, not a new calculation. Hide the inactive representation from assistive technology and avoid duplicate live IDs. “Above 200-day average”, “positive market returns” and “constituent breadth above 50-day average” are three different measures, never interchangeable.

## Optional capabilities and hard gates

Capabilities include read-only overview/compare/inspector/evidence and separately qualified deeper features. `active_follow`, `saved_research_write`, `historical_rank_change`, `point_in_time_breadth`, `sector_neutral_attribution` and `company_economic_exposure` are **false/unavailable in this handoff unless an existing owner is independently proven at implementation time**. An accepted source may later enable them through its real contract. A design success screen is not capability evidence.

No JSON payload includes forbidden account data or denied values behind a client-side blur. Evidence links are allowlisted internal routes or validated permitted source URLs. Source strings are escaped and never injected as HTML. Pure view projection must be side-effect free.

## Fixture families to create

Create a small synthetic reference family for every material boundary: all-qualified; all-negative; two eligible; exact tie; rounded tie; one missing FX with valid local return; old CPI/fresh build; wrong-index label; proxy policy rate; changed benchmark; unequal windows; zero/NaN/bool; duplicate market; insufficient series; denied field; unsupported country; stale cached evidence; source failure; long EN/ZH names; expanded 320px layout; no-JavaScript render. Use synthetic values and mark them as such; never treat them as current market observations.

The contract fixture is the common input for unit, real-template integration and browser journeys. It must not mock away the projection or financial calculations whose correctness the tests claim to prove.
