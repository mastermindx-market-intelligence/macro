# Mastermind website upgrade — Paper census and build handoffs

## Wave 1 · 6 October 2026 UTC

**Start with [`orchestration/ASTRA_START_HERE.md`](orchestration/ASTRA_START_HERE.md).** It is the copyable Astra Meta-CEO commission and the delegation/integration plan. The accompanying `index.html` is a readable, self-contained browser edition of the substantive packet.

This delivery contains a **source-grounded first implementation batch**, not a claim that every Paper design is ready. Six files were inventoried page by page: **78 pages and 1,589 artboards**. Five additional working/reference files were discovered, with incomplete review explicitly marked. Seven International native screens were visually reviewed and exported; full native specifications and the existing backend/source were investigated.

No product source, Paper design, live data, runtime job, monitor or deployment was changed. No worker has been commissioned by this packet. Source custody, admitted model/tool grants, independent review and actual browser/release evidence remain implementation gates.

## Build packets ready for deliberate handoff

| Packet | User capability | Dependency / boundary |
|---|---|---|
| [IM-00 Foundation](handoffs/IM-00_FOUNDATION.md) | Honest shared data/view contract, compatible precision/series extension and one route controller | Required before integration; no new financial engine or publisher |
| [IM-01 Overview](handoffs/IM-01_OVERVIEW.md) | Clear leadership/coverage first read, compact returns, complete expanded detail | IM-00; no loss of existing research or stocks mode |
| [IM-02 Compare & Rotation](handoffs/IM-02_COMPARE_ROTATION.md) | Real common-window comparison, local/FX/USD attribution, qualified rotation context | IM-00 exact-series extension; unsupported breadth/history/factors withheld |
| [IM-03 Inspector & Evidence](handoffs/IM-03_INSPECTOR_EVIDENCE.md) | One responsive country/evidence inspector with exact context restoration | Read-only; active Follow and Saved writes excluded |

Each packet provides exact Paper page links and node IDs, existing/proposed source paths, component and data architecture, non-goals, bounded worker tasks, source-truth and UI tests, release gates and rollback. It identifies unknowns instead of hiding them behind a polished mockup.

## Research and navigation

| Document | What it supplies |
|---|---|
| [Readiness decisions](READINESS.md) | Ready bounded slices versus archives, studies, held effects and next audits |
| [Source audit and preservation map](SOURCE_AUDIT.md) | 13 material source/design disagreements and 18 existing feature families to retain |
| [File/page census](census/CENSUS.md) | Linked file-by-file, page-by-page inventory with observed counts and triage |
| [Machine-readable census](census/PAPER_CENSUS.json) / [CSV](census/PAPER_PAGES.csv) | Full 78-page directory coverage plus explicitly partial additional files |
| [View contract](contracts/INTERNATIONAL_VIEW_CONTRACT.md) | Identity, units, clocks, rights, qualification, series and UI-state specification |
| [Paper access and exports](DESIGN_ACCESS.md) | Verified M2 native design ZIP, checksum and minimal worker input strategy |
| [Worker template](orchestration/WORKER_PACKET_TEMPLATE.md) | Bounded task, grants, allowed files, evidence and return format |
| [Research receipt](evidence/RESEARCH_RECEIPT.md) | What was actually read, viewed and verified; source pins and browser limits |
| [Continuation](CONTINUATION.md) | Completed work not to repeat and exact next Macro/Policy + Risk research nodes |
| [Validation report](verification/VALIDATION_REPORT.md) | Actual artifact-integrity and numerical-specification checks; not website build tests |

## Important findings before any builder starts

The current International source is Python/Jinja/CSS/JavaScript. Keep that stack. Paper JSX is a design reference, not a React migration mandate. The same template renders International stocks, so a wholesale replacement would create unnecessary regression risk.

Japan is Nikkei in the existing source, not the sample TOPIX. Legacy returns are rounded before serialization, and the old sparkline is not a selected-window chart. A fresh record date does not freshen stale CPI. The apparent policy rate can be a short-rate proxy rather than an official policy decision. The inspector's four precise timestamps, constituent participation and successful Follow screens are not proof that corresponding source/runtime capabilities exist.

The main Paper file includes moved source copies, archives, studies and redirect stubs. Current Intelligence Hub work is in **Refined vase**; build candidates in the old location must not be treated as separate pages. Bonds and Forex already have open Draft/HOLD implementation candidates to reconcile later, not replace blindly.

## Two separate delivery objects

**This downloadable handoff packet** contains plans, census, contracts, provenance and verification. **The native Paper asset ZIP** is separately verified on M2 at the exact path in `DESIGN_ACCESS.md`; it contains seven JPEG/JSX pairs, specs, token references and the full 1,589-artboard inventory. It is not embedded in this chat ZIP. An admitted M2 orchestrator can consume it; cross-host worker delivery is a separately verified step through the existing artifact carrier. No font files are included in either bundle.

## What remains open

This is not the complete website-wide census-to-build programme. Full handoffs for International Macro/Risk, History/Scenarios and Library/Saved remain next. Other current-build families still require deep source/design qualification. Production browsing was blocked; no authenticated current-site appearance or live behavior is claimed. All website tests listed in the handoffs are acceptance requirements, not test results from this research turn.
