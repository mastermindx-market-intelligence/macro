"""Specification examples, NOT tests of deployed product code."""
import copy
import json
from decimal import Decimal
from pathlib import Path
import pytest
from contract_examples import search_tools, same_reply, policy_gap, selected_coverage, review_status, allowed_actions, validate_context
ROOT=Path(__file__).resolve().parents[1]
CAT=json.loads((ROOT/'contracts/TOOL_BINDINGS.json').read_text())['tools']

def test_empty_catalogue_has_all_eighteen():
    assert len(search_tools(CAT,'')) == 18

def test_exact_match_precedes_group_matches():
    assert search_tools(CAT,'Central banks & liquidity')[0]=='central_banks_liquidity'

def test_fullwidth_search_is_search_only():
    original=copy.deepcopy(CAT)
    assert search_tools(CAT,'ＦＸ')==search_tools(CAT,'FX')
    assert CAT==original

def test_chinese_policy_alias_is_found():
    assert 'central_banks_liquidity' in search_tools(CAT,'政策')

def test_group_filter_stays_applied_on_clear():
    assert len(search_tools(CAT,'',group='policy'))==3

def test_all_query_terms_must_match():
    assert search_tools(CAT,'currency impossibleterm')==[]

def test_ime_does_not_commit_partial_query():
    assert search_tools(CAT,'政',composing=True) is None

@pytest.mark.parametrize('bad',['x'*257,'a\x00b','a\ud800b'])
def test_invalid_query_not_silently_truncated(bad):
    with pytest.raises(ValueError):search_tools(CAT,bad)

@pytest.mark.parametrize('field,value',[('principal','other'),('catalogue','v2'),('generation',2),('query','rates'),('group','policy')])
def test_obsolete_search_reply_rejected(field,value):
    a={'principal':'p','catalogue':'v1','generation':1,'query':'fx','group':None};b={**a,field:value}
    assert not same_reply(a,b)

def test_matching_reply_accepted():
    x={'principal':'p','catalogue':'v1','generation':1,'query':'fx','group':None}
    assert same_reply(x,x)

@pytest.mark.parametrize('values,absolute,direction',[
    ((.5,.5,3.5,3),'-50','narrowed'),((3.5,3,.5,.5),'-50','narrowed'),
    ((.5,.5,3,3.5),'50','widened'),((0,0,0,0),'0','unchanged'),
    ((-1,-.5,-2,-2),'50','widened'),((0,2,1,1),'0','unchanged'),
    ((.5,.50001,3,3),'-0.00100','narrowed')])
def test_exact_nominal_policy_examples(values,absolute,direction):
    result=policy_gap(*values)
    assert result['absolute_change_bp']==Decimal(absolute)
    assert result['direction']==direction

def test_signed_increase_can_narrow():
    result=policy_gap(.5,.5,3.5,3)
    assert result['signed_start_bp']==-300 and result['signed_end_bp']==-250
    assert result['signed_change_bp']==50 and result['absolute_change_bp']==-50

@pytest.mark.parametrize('bad',[True,None,float('nan'),float('inf'),'3.5'])
def test_invalid_numeric_examples(bad):
    with pytest.raises(ValueError):policy_gap(bad,.5,3.5,3)

def test_selected_coverage_not_answer_probability():
    result=selected_coverage(['a','b','c'],{'a':'qualified','b':'qualified','c':'stale'})
    assert result=={'qualified_n':2,'selected_n':3}
    assert 'confidence' not in result and 'answer' not in result

def test_duplicate_selected_measure_refused():
    with pytest.raises(ValueError):selected_coverage(['a','a'],{'a':'qualified'})

def test_empty_selected_scope_not_fabricated_denominator():
    assert selected_coverage([],{})=={'qualified_n':0,'selected_n':0}

def test_incomplete_review_keeps_real_change():
    assert review_status('incomplete',[{'id':'a','version':'revised'}])=={'has_change':True,'changed_fields':1,'complete':False}

def test_no_material_change_in_partial_is_unknown():
    assert review_status('incomplete',[{'id':'a','version':'unchanged'}])['has_change'] is None

@pytest.mark.parametrize('state',['denied','unavailable','scope_changed','invalid'])
def test_failed_review_does_not_become_zero_changes(state):
    result=review_status(state,[{'id':'private','version':'revised'}])
    assert result['has_change'] is None and result['changed_fields'] is None

def test_same_field_changes_count_once():
    assert review_status('changed',[{'id':'a','version':'revised','qualification':'changed'}])['changed_fields']==1

@pytest.mark.parametrize('phase',['pending','uncertain'])
def test_unknown_outcome_cannot_resend_or_mint_id(phase):
    assert set(allowed_actions(phase))=={'check_original_outcome','continue_research'}

def test_receipt_miss_is_not_final_no_effect():
    assert 'review_new_save' not in allowed_actions('receipt_not_found')

def test_only_owner_fence_allows_new_save():
    assert allowed_actions('not_applied')==['review_new_save','continue_research']

def sample_context():
    return {'schema':'intl_research_context.v1','research_market':'JP','tool_key':'central_banks_liquidity',
      'tool_binding_version':'fixture-v1','period':{'mode':'owner_horizon','key':'1m'},'currency_basis':'usd_unhedged',
      'return_basis':'price','benchmark_ref':None,'selected_measure_refs':[{'owner':'engine.intl_run','object_type':'country_record','object_id':'JP','field':'policy_rate'}],
      'analytical_filters':[],'comparison':None}

def test_context_round_trip_and_author_text_not_repurposed():
    x=sample_context(); before=copy.deepcopy(x)
    assert validate_context(x,{t['presentation_key'] for t in CAT})==x and x==before

@pytest.mark.parametrize('key,value',[('conclusion','BUY'),('confidence',.9),('scroll',100),('focus','x'),('user_id','p'),('html','<div>'),('result_bp',50)])
def test_durable_context_rejects_forbidden_fields(key,value):
    x=sample_context();x[key]=value
    with pytest.raises(ValueError):validate_context(x,{t['presentation_key'] for t in CAT})

@pytest.mark.parametrize('period',[{'mode':'fixed_dates','start':'2026-10-02','end':'2026-10-01'},
 {'mode':'fixed_dates','start':'2026-02-30','end':'2026-03-01'},
 {'mode':'owner_horizon','key':'unsupported'},
 {'mode':'fixed_dates','start':'2026-10-01T00:00:00Z','end':'2026-10-02'}])
def test_invalid_periods_refused(period):
    x=sample_context();x['period']=period
    with pytest.raises(ValueError):validate_context(x,{t['presentation_key'] for t in CAT})

def test_duplicate_measure_refs_refused():
    x=sample_context();x['selected_measure_refs']*=2
    with pytest.raises(ValueError):validate_context(x,{t['presentation_key'] for t in CAT})

def test_no_generic_filter_bag():
    x=sample_context();x['analytical_filters']=[{'raw_provider_url':'https://example.invalid'}]
    with pytest.raises(ValueError):validate_context(x,{t['presentation_key'] for t in CAT})

def test_fixed_dates_do_not_gain_fake_instant():
    x=sample_context();x['period']={'mode':'fixed_dates','start':'2026-08-31','end':'2026-09-30'}
    result=validate_context(x,{t['presentation_key'] for t in CAT})
    assert result['period']['start']=='2026-08-31' and 'research_as_of' not in result

def comparison():
    return {'economy_a':'JP','economy_b':'US','lens':'nominal_policy_point_gap','definition':'absolute_gap_change_bp','method_version':'fixture-v1','period':{'mode':'fixed_dates','start':'2026-08-31','end':'2026-09-30'},'instrument_a_ref':None,'instrument_b_ref':None,'revision_policy':'latest_vintage'}

def test_valid_incomplete_comparison_intent_can_be_retained():
    x=sample_context();x['comparison']=comparison()
    assert validate_context(x,{t['presentation_key'] for t in CAT})['comparison']['instrument_a_ref'] is None

@pytest.mark.parametrize('change',[{'economy_b':'JP'},{'lens':'real_rates'},{'definition':'forecast'},{'value_bp':50}])
def test_invalid_comparison_intent_refused(change):
    x=sample_context();x['comparison']={**comparison(),**change}
    with pytest.raises(ValueError):validate_context(x,{t['presentation_key'] for t in CAT})

def test_measures_above_limit_refused():
    x=sample_context();x['selected_measure_refs']=[{**x['selected_measure_refs'][0],'field':str(i)} for i in range(25)]
    with pytest.raises(ValueError):validate_context(x,{t['presentation_key'] for t in CAT})
