"""Executable handoff examples ONLY. No product imports, I/O, auth or persistence.
These demonstrate selected invariants; they are not a complete production validator,
financial owner, search service, or retry authority.
"""
from __future__ import annotations
import json
import math
import re
import unicodedata
from datetime import date
from decimal import Decimal
from typing import Any

def search_tools(catalogue, query, group=None, composing=False):
    if not isinstance(query,str) or len(query)>256 or any(ord(c)<32 or 0xD800<=ord(c)<=0xDFFF for c in query):
        raise ValueError('invalid query')
    if composing:return None
    norm=lambda s:unicodedata.normalize('NFKC',s).lower()
    q=norm(query).strip(); tokens=q.split(); out=[]
    for row in catalogue:
        if group is not None and row['group_id']!=group:continue
        labels=[norm(row['label_en']),norm(row['label_zh'])]
        hay=norm(' '.join([row['label_en'],row['label_zh'],row['question_en'],row['question_zh'],*row['aliases']]))
        if not all(t in hay for t in tokens):continue
        score=0 if q and q in labels else 1 if q and any(s.startswith(q) for s in labels) else 2
        out.append((score,row['order'],row['presentation_key']))
    return [r[2] for r in sorted(out)]

def same_reply(active,reply):
    fields=('principal','catalogue','generation','query','group')
    return all(k in active and k in reply and active[k]==reply[k] for k in fields)

def policy_gap(a_start,a_end,b_start,b_end):
    values=(a_start,a_end,b_start,b_end)
    if any(isinstance(v,bool) or not isinstance(v,(int,float,Decimal)) or not math.isfinite(v) for v in values):
        raise ValueError('four finite numeric percent levels required')
    a0,a1,b0,b1=[Decimal(str(v)) for v in values]
    start=100*(a0-b0);end=100*(a1-b1);absolute=abs(end)-abs(start)
    return {'signed_start_bp':start,'signed_end_bp':end,'signed_change_bp':end-start,
            'absolute_change_bp':absolute,'direction':'narrowed' if absolute<0 else 'widened' if absolute>0 else 'unchanged'}

def selected_coverage(selected,qualities):
    if len(selected)!=len(set(selected)):raise ValueError('duplicate selected reference')
    return {'qualified_n':sum(qualities.get(k)=='qualified' for k in selected),'selected_n':len(selected)}

def review_status(summary,items):
    if summary in {'denied','unavailable','scope_changed','invalid'}:
        return {'has_change':None,'changed_fields':None,'complete':False}
    changed={x['id'] for x in items if x.get('version')=='revised' or x.get('qualification')=='changed' or x.get('membership') in {'added','removed'} or (x.get('interpretation',{}).get('comparable') and x['interpretation'].get('delta')!=0)}
    complete=summary in {'changed','unchanged'}
    return {'has_change':True if changed else False if complete else None,'changed_fields':len(changed),'complete':complete}

def allowed_actions(phase):
    # Fixture display expectations, NOT a runtime operation authorizer.
    if phase in {'pending','uncertain','receipt_not_found'}:return ['check_original_outcome','continue_research']
    if phase=='not_applied':return ['review_new_save','continue_research']
    if phase=='committed':return ['open_saved_record','review_undo']
    return ['continue_research']

def _period(value):
    if not isinstance(value,dict):raise ValueError('period required')
    if value.get('mode')=='owner_horizon':
        if set(value)!={'mode','key'} or value['key'] not in {'1m','3m','6m','12m','ytd'}:raise ValueError('unsupported horizon')
    elif value.get('mode')=='fixed_dates':
        if set(value)!={'mode','start','end'}:raise ValueError('invalid fixed period')
        for k in ('start','end'):
            if not isinstance(value[k],str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',value[k]):raise ValueError('day precision required')
        a,b=date.fromisoformat(value['start']),date.fromisoformat(value['end'])
        if b<a:raise ValueError('date order')
    else:raise ValueError('unsupported period mode')

def _ref(value,keys):
    if not isinstance(value,dict) or set(value)!=set(keys):raise ValueError('closed reference expected')
    if any(not isinstance(v,str) or not v.strip() or len(v)>256 or any(ord(c)<32 for c in v) for v in value.values()):raise ValueError('invalid reference string')

def validate_context(raw,tool_keys):
    keys={'schema','research_market','tool_key','tool_binding_version','period','currency_basis','return_basis','benchmark_ref','selected_measure_refs','analytical_filters','comparison'}
    if not isinstance(raw,dict) or set(raw)!=keys:raise ValueError('closed context expected')
    if raw['schema']!='intl_research_context.v1' or raw['research_market'] not in {'JP','KR','TW','GB','EZ','IN','AU'} or raw['tool_key'] not in tool_keys:raise ValueError('unsupported context')
    if not isinstance(raw['tool_binding_version'],str) or not raw['tool_binding_version']:raise ValueError('binding version')
    if raw['currency_basis'] not in {'local','usd_unhedged'} or raw['return_basis']!='price':raise ValueError('basis')
    _period(raw['period'])
    if raw['benchmark_ref'] is not None:_ref(raw['benchmark_ref'],['owner','object_type','object_id'])
    refs=raw['selected_measure_refs']
    if not isinstance(refs,list) or len(refs)>24:raise ValueError('measure count')
    for ref in refs:_ref(ref,['owner','object_type','object_id','field'])
    if len({json.dumps(x,sort_keys=True) for x in refs})!=len(refs):raise ValueError('duplicate measure')
    # First-wave tools expose no additional analytical-filter keys.
    if raw['analytical_filters']!=[]:raise ValueError('no arbitrary filter bag')
    c=raw['comparison']
    if c is not None:
        required={'economy_a','economy_b','lens','definition','method_version','period','instrument_a_ref','instrument_b_ref','revision_policy'}
        if not isinstance(c,dict) or set(c)!=required:raise ValueError('closed comparison')
        if c['economy_a']!=raw['research_market'] or c['economy_b'] not in {'JP','KR','TW','GB','EZ','IN','AU','US'} or c['economy_a']==c['economy_b']:raise ValueError('comparison economy')
        if c['lens']!='nominal_policy_point_gap' or c['definition']!='absolute_gap_change_bp' or not isinstance(c['method_version'],str) or not c['method_version']:raise ValueError('comparison method')
        if c['revision_policy'] not in {'latest_vintage','original_known'}:raise ValueError('revision policy')
        _period(c['period'])
        for k in ('instrument_a_ref','instrument_b_ref'):
            if c[k] is not None:_ref(c[k],['owner','object_type','object_id'])
    try:encoded=json.dumps(raw,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf-8')
    except (ValueError,UnicodeError,TypeError) as e:raise ValueError('invalid JSON') from e
    if len(encoded)>8192:raise ValueError('context byte limit')
    return json.loads(encoded)
