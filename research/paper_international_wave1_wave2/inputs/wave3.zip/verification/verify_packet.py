"""Verify artifact structure and lineage, not the production application."""
from pathlib import Path
import hashlib,json,re,zipfile,sys
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def check(name,condition):
    if not condition:raise AssertionError(name)
    checks.append(name)
for name in ['README.md','READINESS.md','SOURCE_AUDIT_WAVE3.md','CONTINUATION.md','DESIGN_ACCESS.md','contracts/LIBRARY_AND_SAVED_CONTRACT.md','orchestration/ASTRA_WAVE3_ADDENDUM.md']:
    check('required '+name,(ROOT/name).is_file())
cat=json.loads((ROOT/'contracts/TOOL_BINDINGS.json').read_text());rows=cat['tools']
check('eighteen families',len(rows)==18)
check('six groups',len(cat['groups'])==6)
check('unique family keys',len({x['presentation_key'] for x in rows})==18)
check('unique proposed region IDs',len({x['proposed_region_id'] for x in rows})==18)
check('three families per group',all(sum(t['group_id']==g['id'] for t in rows)==3 for g in cat['groups']))
check('source references bound to exact Macro pin',all(cat['source_sha'] in t['source_url'] for t in rows))
check('anchors not falsely declared existing',all(t['region_id_state']=='PROPOSED_NOT_EXISTING' for t in rows))
m=json.loads((ROOT/'census/PAPER_REVIEW_MANIFEST.json').read_text());boards=m['boards']
check('fifty inherited native nodes',len(boards)==50)
check('unique native nodes',len({x['node_id'] for x in boards})==50)
check('four denied target fences exact',{x['node_id'] for x in boards if x['review_depth']=='HELD_DO_NOT_RETRY'}=={'3C4-0','3WS-0','3YE-0','400-0'})
check('fourteen visual observations',sum(x['review_depth']=='DIRECT_VISUAL_OBSERVATION' for x in boards)==14)
check('no false frozen export claim',m['native_exports_bundled'] is False and m['token_hash_is_document_revision'] is False)
check('exact native file page',m['page_url'].endswith(m['file_id']+'/p-5-0'))
handoffs=sorted((ROOT/'handoffs').glob('*.md'));taskids=[]
check('four new handoffs',len(handoffs)==4)
for p in handoffs:
 text=p.read_text();tasks=re.findall(r'^### (IM\d{2}-T\d+)',text,re.M);taskids+=tasks
 check(p.stem+' five task contracts',len(tasks)==5)
 check(p.stem+' explicit Paper source',m['page_url'] in text)
 check(p.stem+' rollback specified','rollback' in text.lower())
 check(p.stem+' actual proof boundary','browser' in text.lower() and ('not' in text.lower()))
check('twenty unique tasks',len(taskids)==20 and len(set(taskids))==20)
# Follow only local links in new docs. Frozen parent documents retain their original relative context.
for p in [*ROOT.glob('*.md'),*ROOT.joinpath('handoffs').glob('*.md'),*ROOT.joinpath('orchestration').glob('*.md')]:
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if '://' in target or target.startswith('#'):continue
  check('local link '+str(p.relative_to(ROOT))+' -> '+target,(p.parent/target.split('#')[0]).resolve().is_file())
p=json.loads((ROOT/'evidence/SOURCE_PROBES.json').read_text())
check('twenty-one scoped source checks',sum(x['checks'] for x in p['probes'])==21)
check('original probe exits confirmed',all(x['exit_code']==0 and x['result']=='PASS' for x in p['probes']))
check('source hashes full sha256',all(re.fullmatch('[a-f0-9]{64}',x['sha256']) for x in p['probes']))
check('unexecuted full probe excluded','NOT_EXECUTED' in p['full_investigation_probe'])
check('no source or database writes',p['source_or_database_writes'] is False)
for entry in json.loads((ROOT/'evidence/PARENT_LINEAGE.json').read_text()):
 archive=ROOT.parent/entry['name']
 if archive.exists():check('parent unchanged '+entry['name'],hashlib.sha256(archive.read_bytes()).hexdigest()==entry['sha256'])
# Portable input verification uses individual immutable hashes, no need to have parent ZIPs beside extracted packet.
for entry in json.loads((ROOT/'evidence/INPUT_LINEAGE.json').read_text()):
 check('input immutable '+entry['path'],hashlib.sha256((ROOT/entry['path']).read_bytes()).hexdigest()==entry['sha256'])
check('no font files',not any(p.suffix.lower() in {'.ttf','.otf','.woff','.woff2'} for p in ROOT.rglob('*') if p.is_file()))
check('no credentials files',not any(p.name in {'.env','credentials.json','auth.json'} for p in ROOT.rglob('*') if p.is_file()))
text=(ROOT/'contracts/LIBRARY_AND_SAVED_CONTRACT.md').read_text()
check('candidate schema not claimed installed','proposed, not allocated/live' in text)
check('no hidden same-record answer persistence','settings only' in text.lower())
print(json.dumps({'scope':'packet structure, references and lineage only','checks':len(checks),'result':'PASS','cases':checks},indent=2))
