# Wave 3 validation — scope and observed results

## Executed evidence

**64 executable specification examples passed**, zero failed, using the shipped `contract_examples.py` and `test_contract_examples.py`. They exercise local search, normalization/IME boundaries, obsolete-result identity, nominal policy-gap arithmetic, invalid numeric/date/context cases, selected-data coverage, incomplete-yet-changed review display and original-outcome action expectations. The initial incomplete example scaffold produced50 failures / 8 passes; those are not product red/green tests.

**64 packet-structure/reference/lineage checks passed** in the build environment, including exact parent ZIP hashes, three unchanged inherited input files, four handoffs, twenty unique task IDs, eighteen source-bound tool keys, fifty inherited native nodes, fourteen new visual observations and four preserved denied-target fences. The portable verifier omits the two parent-ZIP checks when those archives are not present beside an extracted package; individual inherited-input hashes remain mandatory.

**21 exact-source synthetic checks passed on M2**, each process exit 0:

| Source | Checks | Scope |
|---|---:|---|
| Protected RMS `normalizeViewFilter` |8|Current preset semantics and R10 field-loss boundary |
| Held #804 candidate `reviewEvidence` |13|Content/qualification/membership/scope semantics and excluded-number caller requirement |

The source probe functions were read from exact Git commits and evaluated in memory using Node's built-in strip-only type support. The earlier attempted whole Investigation contract probe did not execute because transform mode was unsupported and is excluded. These are not full owner unit suites, DB tests or endpoint acceptance.

## Clean extraction

A clean archive extraction reran all 64 specification examples successfully (exit 0) and all 62 portable packet checks successfully (exit 0). Every payload hash was verified. The two build-only parent-ZIP checks are not counted when parent archives are absent; the three included parent-input hashes are still checked.

## Reproduction inside the extracted package

```sh
python -m pytest -q verification/test_contract_examples.py
python verification/verify_packet.py
```

Python and pytest are needed for these artifact checks. Production tests belong in the actual owning repositories and their existing CI/database/browser harnesses. Do not install this example module into the application or treat its display-action table as an operation authorizer.

## Proof limits and repairs

A prose-formatting pass temporarily broke local Markdown filenames; packet validation caught the exact bad link. Exact task/source identifiers and link targets were repaired, then the complete packet verifier passed. No failed check was waived. The source probe compiler limitation changed the diagnostic method, not a product implementation.

The conversation container reset once and discarded Wave 3 scratch. A verified checkpoint in the existing M2 research evidence root preserved the source findings. Reconstruction was bounded to research artifacts; neither product source nor an unknown remote write was replayed.

There is **no new native screenshot/JSX bundle** in this wave. Native visual observations are not browser tests. No product source, database, Paper design, deployment, GitHub publication, worker or watcher was modified/started. #804review/migration, actual International admission, current source rights, authenticated cross-product transfer and real-browser proof remain separate release obligations.
