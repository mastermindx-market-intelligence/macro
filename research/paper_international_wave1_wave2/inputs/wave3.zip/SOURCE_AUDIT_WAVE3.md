# Wave 3 — source recovery, disagreements and implementation consequences

## Scope and immutable references

Observed 6 October 2026. This audit concerns International Research Library, Saved Research and Policy Comparison. It is not a new whole-estate census or a production health report.

| Source | Pin / evidence role |
|---|---|
| Protected procedure | Mastermind `a6d40ff648671b03bd4d829d84dd066b58ea8c3f`; compatible Skillpack 1.0.1/bootstrap 1; required same-pin blobs matched prior accepted reads |
| Macro implementation | `dd3d218eec55fb2f55526e81877a7ee3134efd8c` |
| Terminal implementation | `64c1ea5e25a335a0b0636e73e7fdbe0f8beb7b0e` |
| Existing Investigation release carrier | [Terminal #777](https://github.com/mastermindx-market-intelligence/mastermind-terminal/pull/777), merged 4 Oct 2026 at 10:18:46 Z; merge`d9128b500fb434e3548574e89b25a2a85053f3d7` |
| Open incumbent kernel | [Terminal #804](https://github.com/mastermindx-market-intelligence/mastermind-terminal/pull/804), Draft/HOLD; observed head`0654cf7ad2fb6c5242fe1fc4ffaae3d48b912a7b`; candidate evidence, not merged law |
| Existing parent programme | [Macro #8338](https://github.com/mastermindx-market-intelligence/macro/pull/8338), OPEN; observed head`90336ccdd7173dd856e9c00b81e267ab3cc7abb3` |
| Paper | file`01M3P1TW5Y3XWQC37ADDS8K5AG`, page`p-5-0`; token hash`501cd923` is not a document revision |

The following paths are at the pinned repository above unless the entry explicitly says candidate. Relevant current source must be compared at implementation START. A moving PR title or old paragraph is not source custody or runtime proof.

## Findings

### F 01 — The saved owner is no longer a greenfield build

`docs/superpowers/plans/2026-09-29-saved-research-owner.md` explicitly marks its separate-store proposal superseded. #777 merged the Investigation aggregate. Creating `saved_research_records`, reusing the old 0028 reservation or adding another R10 workspace-settings namespace would duplicate the actual owner. **Action:** IM08 extends the Investigation aggregate; IM09 extends its existing workspace.

### F 02 — Protected G1 admission is narrower than the Paper journey

`terminal/lib/investigations.ts::INVESTIGATION_ADMISSION` allows `terminal.analysis_symbol/security`, `data_os.security_master/security|issuer` and `earnings.workspace_generation/event_workspace`. It does not admit an economy or International source. The SQL 0028 validator repeats those restrictions. **Action:** coordinated owner/kind/reference admission, not a browser-only dropdown change.

### F 03 — R10 intent has nowhere lossless to go in the current manifest

`investigationContracts.ts::InvestigationManifest` has intent, layout/Thesis/evidence references, continuation and optional baseline; no typed currency/basis/measure-selection/comparison object. Unknown keys refuse. **Action:** an explicit closed versioned International intent extension, preserving all old records; no generic metadata or encoded prose.

### F 04 — RMS presets silently discard R10 fields

`terminal/lib/savedViews.ts::normalizeViewFilter` preserves only lifecycle, staleDays, windowClosed and subjectGroupKey. An exact-source in-memory probe confirmed that market/question/period/currency/selectedMeasureIds disappear when combined with a valid lifecycle. Eight positive/negative controls passed. **Action:** do not call `/api/thesis-saved-views` for R10. This source observation is not a request to change valid RMS behavior.

### F 05 — The actual Saved UI and private route already exist

`terminal/components/workspaces/InvestigationWorkspace.tsx` and `/api/investigations` already support inventory, exact revisions, save/readback and user context. `/analysis?view=investigations` is the existing host. **Action:** reuse and extend, preserve existing security/Earnings/layout journeys. Do not create a second Macro cloud workspace.

### F 06 — #804 owns overlapping kernel and UI repairs

Its candidate changes immutable revision identity, canonical byte rules, manifest argument relations, layout ownership, temporal intent, recovery and selected-source rights. It owns forward 0030, currently recorded unapplied. **Action:** compose on its accepted interface under the incumbent owner. Applied 0028/0029 must not be edited or replayed. Do not cherry-pick an unaccepted repair to bypass review.

### F 07 — Unknown-outcome behavior differs across protected and candidate code

Protected `investigationSave.ts` exposes original resend; candidate #804 adds same-owner reconciliation with terminal `not_applied` fencing and no resend while uncertain. A receipt miss is not a safe new-save signal. **Action:** full R10 write acceptance depends on accepted kernel behavior, not a new page-owned retry mechanism.

### F 08 — Source contract and release narrative can disagree

The protected Investigation document contains historical “merge/application pending” paragraphs, but live GitHub metadata proves #777 merged. Neither fact proves the current deployed application or authenticated International support. **Action:** track source merge, DB migration evidence, deployed build and actual user journey separately; do not project an old paragraph as current release state.

### F 09 — Baseline storage is not rights or historical-availability proof

Current baseline support is Earnings-specific. #804's newer selected-release rights are default-denied until the existing rights dependency is admitted. International latest artifacts are not automatically retained historical generations. **Action:** a domain resolver with current rights; valid intent may save without baseline. No mixed-workspace rights inference or present-data fallback.

### F 10 — Current generic inventory cannot classify R10 by itself

`listInvestigations` summaries include ID, revision, lifecycle, title, question and updated_at. There is no typed International discriminator or evidence-change index. **Action:** additive accepted summary projection/filters; do not infer category from question text or fetch every full record just to fill a count.

### F 11 — The review kernel can be incomplete and materially changed simultaneously

Candidate `investigationEvidenceDiff.ts::reviewEvidence` returns `summary=incomplete` with `items[*].version=revised` when another field is stale. Thirteen exact-source synthetic controls passed. **Action:** preserve material-change flags independently of completeness; a changed-first filter based only on summary=changed is wrong.

### F 12 — Not observed is not removed

The same review kernel distinguishes page/top-k omissions from complete membership or tombstones. **Action:** preserve that distinction in the adapter and visual copy. Never delete a saved interest, baseline member or displayed history because it was absent from one response.

### F 13 — Excluded numbers need an adapter guard

The candidate generic numeric comparator checks availability but does not independently reject `excluded=true`. The source probe confirmed comparable numeric output for that contradictory input. **Action:** the International adapter clears numeric interpretation for excluded/unqualified data before invoking the generic function. This is a caller-qualification requirement, not authority to duplicate or quietly patch the held kernel.

### F 14 — A refresh is not acknowledgement or new intent

Paper 6 EG explicitly keeps the saved baseline immutable on open. Existing owner transactions distinguish writes from reads. **Action:** open/refresh/source-inspect must leave revision and baseline unchanged; meaningful new baseline selection requires its explicit reviewed owner operation.

### F 15 — “Library” currently names the stock producer too

Macro `scripts/build_intl_library.py` builds ticker-level analysis and pooled stock standouts, not eighteen-tool navigation. **Action:** pure presentation projection over supplied view fields; no producer/ledger work on Library search.

### F 16 — Route IDs exist, but most analytical section anchors do not

`build_product_page_registry.py::_macro_page_id` derives `macro:intl` and `macro:intl_stocks`. The pinned`intl.html.j2` has many headings without stable intended tool anchors. **Action:** proposed local region IDs must be mounted and integration-tested. The handoff does not represent them as existing links.

### F 17 — Research subject and analytical scope differ

Native backdrop`3MN-0` keeps Japan while opening explicit euro-area fragmentation or global dollar conditions. Existing producers likewise have distinct regional/ETF/IMF populations. **Action:** two named scope fields and exact return context; no wrong-country relabeling or implied country coverage from global tool membership.

### F 18 — Two qualified fields cannot answer an unspecified policy comparison

The saved sample's domestic policy and 10 Y–2 Y curve do not establish a cross-country nominal-policy gap. `6EG-0`, `77R-0` and`7D2-0` make comparator/instruments/endpoints explicit. **Action:** answer-readiness separate from 2/3 measure coverage; missing comparison remains unresolved.

### F 19 — Signed increase can mean absolute narrowing

Synthetic Japan.50→.50 andUS 3.50→3.00 gives signed gap−300→−250 bp. The signed change is+50 bp; the absolute gap narrows 50 bp. **Action:** IM10 calculates and displays both concepts; policy rates are not USD-converted. A range cannot silently become midpoint, and four values require compatible instruments and timing.

### F 20 — Older save-copy promises too much presentation persistence

Older`4OU-0` lists return position under what will save. Newer`6EG-0` and `DEC-RESEARCH-CONTEXT-IS-PORTABLE-REFERENCE-NOT-MEMORY.md` keep ephemeral presentation mechanics out of durable analytical truth. **Action:** correct the review promise; retain scroll/focus in the session/navigation owner, not the Investigation manifest.

### F 21 — Cross-product hosting is a real dependency

No direct Macro `/api/investigations` binding was found in the inspected templates/lib paths. A standalone static origin cannot assume Terminal's private relative route/cookies. **Action:** existing Terminal host first, then admitted canonical-context transfer. No credential relay, copied cookie or wildcard-CORS workaround.

### F 22 — Some design states and browser proof remain held

Four same-titled search-state nodes remain under the prior refusal. This wave's Studio compound runtime/catalog preflight was also refused before dispatch, not retried. Independent direct Paper target reads succeeded, yielding 14 visual observations but **no new exported native asset bundle**. Live-site browser restriction remains. **Action:** preserve exact gates; do not call all 50 boards approved, or direct a different worker to perform a refused effect.

## Exact-source executable evidence

1. Protected RMS `normalizeViewFilter`:8 checks, source SHA-256`16e2914a032cba50cce999d1802c53e51098ce76dd82931925ef41b8e0f7af54`.
2. Candidate #804 `reviewEvidence`:13 checks, source SHA-256`c10f75678b5e1a5caf1004007b60bf70e946cb0fc6b1f5aba0d193364b121579`.

Both used exact immutable Git source, Node's built-in strip-only TypeScript handling and synthetic inputs, with no database/network/product writes. An earlier full Investigation validator probe did **not execute** because the local compiler API rejected transform mode; it is excluded from counts. No full unit suite, database, deployment or live browser pass is claimed here.

## Source entry points

- [Protected Investigation service/admission](https://github.com/mastermindx-market-intelligence/mastermind-terminal/blob/64c1ea5e25a335a0b0636e73e7fdbe0f8beb7b0e/terminal/lib/investigations.ts)
- [Protected manifest contract](https://github.com/mastermindx-market-intelligence/mastermind-terminal/blob/64c1ea5e25a335a0b0636e73e7fdbe0f8beb7b0e/terminal/lib/investigationContracts.ts)
- [Protected RMS filter normalizer](https://github.com/mastermindx-market-intelligence/mastermind-terminal/blob/64c1ea5e25a335a0b0636e73e7fdbe0f8beb7b0e/terminal/lib/savedViews.ts)
- [Candidate kernel contract — held](https://github.com/mastermindx-market-intelligence/mastermind-terminal/blob/0654cf7ad2fb6c5242fe1fc4ffaae3d48b912a7b/docs/INVESTIGATION_V2_CONTRACT.md)
- [Candidate evidence review — held](https://github.com/mastermindx-market-intelligence/mastermind-terminal/blob/0654cf7ad2fb6c5242fe1fc4ffaae3d48b912a7b/terminal/lib/investigationEvidenceDiff.ts)
- [Portable research context decision](https://github.com/mastermindx-market-intelligence/macro/blob/dd3d218eec55fb2f55526e81877a7ee3134efd8c/agentos/decisions/DEC-RESEARCH-CONTEXT-IS-PORTABLE-REFERENCE-NOT-MEMORY.md)
- [Current International template](https://github.com/mastermindx-market-intelligence/macro/blob/dd3d218eec55fb2f55526e81877a7ee3134efd8c/templates/intl.html.j2)
- [Existing page registry](https://github.com/mastermindx-market-intelligence/macro/blob/dd3d218eec55fb2f55526e81877a7ee3134efd8c/scripts/build_product_page_registry.py)
