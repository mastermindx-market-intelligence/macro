# Astra — Wave 3 execution addendum

Continue the existing website-upgrade programme. Do not create a competing Investigation programme, a second International integration branch, or a new hierarchy merely because another packet arrived. Wave 1/2 artifacts remain unchanged.

## Outcome and economical hierarchy

Astra Meta-CEO sets priorities, resolves cross-domain decisions and accepts the programme outcome. One Sol International CEO owns these consumer contracts, source integration and acceptance. Existing Investigation programme leadership retains its kernel/API/migration custody. Grok/GLM/Cursor project leads manage distinct Library, domain adapter and presentation outcomes. GLM Flash/Minimax M 3 workers perform bounded implementation/test tasks. Exact model IDs, availability, spend, depth and grants must be resolved by the existing fabric; the names are preferences, not observed activation.

No Claude native subagent or alternate queue is introduced by this packet. Use the existing admitted fabric. Do not dispatch a whole Paper file, run the census again, or make Astra supervise every CSS edit. WHY NOT FABLE: the source-backed contracts decompose into bounded delivery; reserve scarce principal capacity for a real architecture/admission dispute. This is routing rationale, not a provider grant.

## Start with the important change

Saved Research already has an Investigation owner: Terminal#777 merged. #804 is its active Draft/HOLD kernel repair. Share IM08's dependency/extension brief with that incumbent; **do not spawn a worker to recreate or take over #804**. Current G1 admission does not support International economies/measure context. Avoid both false claims: “there is no saved owner” and “the existing owner already supports all R10.”

## Work order and ready work

1. Start IM07 T 1/T 2 over accepted Wave 1 context. This read-only Library lane does not depend on #804 release.
2. Sol settles IM08-T1 with the existing Investigation owner: exact dependency base, proposed manifest extension, source-custody partition and forward-migration sequence. This is an interface decision, not a request for Chairman to rediscover the owner.
3. In parallel, economical workers can implement IM08 pure fixtures/adapter, IM09 presentation and IM10 pure arithmetic/draft UI with synthetic inputs and explicit unresolved integration.
4. The incumbent kernel/integration writer owns shared validator/API/recovery/database edits. Library page workers own no Terminal kernel files. The International integration writer alone owns Macro builder/template/controller/asset/CI integration.
5. Accept each leaf against real observed failures. Integrate accepted outputs, then perform actual source/database/browser/product proofs. Source/fixture green does not authorize held migrations, rights or deployment.

There are 20 bounded tasks:5 each in IM07–IM10. Stage their dispatch; do not reserve 20 workers at once. Limit concurrency to admitted capacity, disjoint writers, review throughput and budget. A lead may split a task only when a separately testable boundary benefits cost/quality. Repeated same failure without new evidence requires a new hypothesis, not another identical worker loop.

## Compact worker packet

Supply only taskID, exact source/dependency SHA, assigned paths, relevant native node IDs or admitted frozen subset, consumed/produced interface, failing cases, non-goals, validation commands, spend/child limits and the existing return destination. Ask for exact artifact/commit, tests actually run, error signatures, changed capability, remaining uncertainty and review status. A delivery is not pickup; pickup is not START; CI is not acceptance.

For visual work, Sol/Astra have Paper access but worker access is not inherited. This wave has native observations and exact links, not a new frozen screenshot/JSX ZIP. Follow `../DESIGN_ACCESS.md`. Do not route denied target qualification or bridge preflight to another worker as an access workaround.

## Mandatory independent review focus

Review: RMS silent-field loss; International owner admission parity in TS/Python/SQL; legacy manifest preservation; baseline rights/current qualification; incomplete-yet-changed reviews; pagination versus deletion; excluded numeric interpretation; wrong-scope country labels; original-operation no-resend fence; version-conditional undo; signed-vs-absolute policy gap; source vintage/date precision; no accidental cloud/private-data exposure.

Keep author-distinct review independent. Sol must inspect decisive evidence but should not reimplement every worker function. Feed failures back to the original carrier within its admitted repair allowance. Preserve current#804/#792/#7870 holds; do not relax checks to fit the planned mockups.

## Release/finish

IM07 is the first independently deliverable consumer. IM08/09 are complete only when a real International question survives authenticated exact save/reopen and current evidence handling. IM10 may prove a useful unavailable-result intent flow when real policy inputs are missing; it cannot be called a live numerical comparison without the four qualified endpoint observations.

Use existing release/rollback authorities. No new watcher or background worker is created by this document. If durable waiting becomes necessary, use the existing accepted return path; do not leave a Pro session polling unchanged statuses. Record the last exact accepted result and the next gate in the incumbent programme, not a new lifecycle ledger.
