# Wave 3 — page and artboard review

[Open the exact Paper page](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG/p-5-0). File `01M3P1TW5Y3XWQC37ADDS8K5AG`, page `p-5-0`.

The following is the **50-node inherited directory**, annotated with this wave’s actual review depth. Fourteen nodes were visually inspected. Specification text was read for6EG-0;7D2-0 also supplied builder-state text. Other entries are not promoted to fresh approval. The four refused state nodes remain held. No new native export bundle is included.

| Node | Native label | Role | Size | This-wave depth |
|---|---|---|---|---|
| `RU-0` | 35 | Library desktop | 1440 | DIRECT_VISUAL_OBSERVATION |
| `35T-0` | 49 | Library mobile | 390 | DIRECT_VISUAL_OBSERVATION |
| `38A-0` | 68 | Pressure group | 390 | INHERITED_DIRECTORY_ONLY |
| `39M-0` | 85 | Library | 320 | INHERITED_DIRECTORY_ONLY |
| `3C4-0` | 102 | Same-title search state | 320 | HELD_DO_NOT_RETRY |
| `3WS-0` | 102 | Same-title search state | 320 | HELD_DO_NOT_RETRY |
| `3YE-0` | 102 | Same-title search state | 320 | HELD_DO_NOT_RETRY |
| `400-0` | 102 | Same-title search state | 320 | HELD_DO_NOT_RETRY |
| `3DH-0` | 86 | Pressure group | 320 | INHERITED_DIRECTORY_ONLY |
| `3ET-0` | 87 | Library enlarged text | 320/200% | INHERITED_DIRECTORY_ONLY |
| `3HB-0` | 88 | Pressure enlarged text | 320/200% | INHERITED_DIRECTORY_ONLY |
| `3IN-0` | 80 | Leaders group | 390 | INHERITED_DIRECTORY_ONLY |
| `3JZ-0` | 81 | Recovery group | 390 | INHERITED_DIRECTORY_ONLY |
| `3LB-0` | 82 | Policy group | 390 | INHERITED_DIRECTORY_ONLY |
| `3MN-0` | 83 | Backdrop group | 390 | DIRECT_VISUAL_OBSERVATION |
| `3NZ-0` | 84 | Challenge group | 390 | INHERITED_DIRECTORY_ONLY |
| `422-0` | 106 | Search/coverage/saved specification | 1440 | INHERITED_DIRECTORY_ONLY |
| `47Q-0` | 107 | Saved inventory | 320 | INHERITED_DIRECTORY_ONLY |
| `49K-0` | 108 | True empty | 320 | INHERITED_DIRECTORY_ONLY |
| `4BC-0` | 109 | Saved loading | 320 | INHERITED_DIRECTORY_ONLY |
| `4D4-0` | 110 | Saved unavailable | 320 | INHERITED_DIRECTORY_ONLY |
| `4F1-0` | 111 | Coverage ledger | 320 | INHERITED_DIRECTORY_ONLY |
| `4I8-0` | 112 | Access required | 320 | INHERITED_DIRECTORY_ONLY |
| `4K3-0` | 113 | Filtered empty | 320 | INHERITED_DIRECTORY_ONLY |
| `4M2-0` | 114 | Reopened detail | 320 | DIRECT_VISUAL_OBSERVATION |
| `4OU-0` | 115 | Save review | 320 | DIRECT_VISUAL_OBSERVATION |
| `4QU-0` | 116 | Save success/undo | 320 | DIRECT_VISUAL_OBSERVATION |
| `4SM-0` | 117 | Outcome checking | 320 | DIRECT_VISUAL_OBSERVATION |
| `4UQ-0` | 118 | Retry-safe failure | 320 | INHERITED_DIRECTORY_ONLY |
| `4WY-0` | 119 | Remove review | 320 | INHERITED_DIRECTORY_ONLY |
| `4YQ-0` | 120 | Remove success/undo | 320 | INHERITED_DIRECTORY_ONLY |
| `5ZJ-0` | 121 | Saved desktop Dark EN | 1440 | DIRECT_VISUAL_OBSERVATION |
| `6WR-0` | 129 | Saved desktop Dark ZH | 1440 | INHERITED_DIRECTORY_ONLY |
| `6NG-0` | 127 | Saved desktop Light EN | 1440 | DIRECT_VISUAL_OBSERVATION |
| `66Y-0` | 122 | Saved tablet | 768 | INHERITED_DIRECTORY_ONLY |
| `6BY-0` | 123 | Saved mobile Dark EN | 390 | DIRECT_VISUAL_OBSERVATION |
| `73O-0` | 130 | Saved mobile Dark ZH | 390 | DIRECT_VISUAL_OBSERVATION |
| `6UD-0` | 128 | Saved mobile Light EN | 390 | INHERITED_DIRECTORY_ONLY |
| `6IO-0` | 125 | Saved small screen | 320 | INHERITED_DIRECTORY_ONLY |
| `6L2-0` | 126 | Saved enlarged text | 320/200% | INHERITED_DIRECTORY_ONLY |
| `6EG-0` | 124 | Saved owner/evidence specification | 1440 | SPEC_TEXT_READ |
| `77R-0` | 131 | Policy comparison preview | 1440 | DIRECT_VISUAL_OBSERVATION |
| `7D2-0` | 132 | Comparison review and builder states | 1440 | DIRECT_VISUAL_OBSERVATION |
| `7HX-0` | 133 | Comparison setup | 390 | DIRECT_VISUAL_OBSERVATION |
| `7JV-0` | 134 | Comparison preview | 390 | INHERITED_DIRECTORY_ONLY |
| `7MG-0` | 135 | Comparison review | 390 | INHERITED_DIRECTORY_ONLY |
| `7PV-0` | 136 | Comparison setup | 320 | INHERITED_DIRECTORY_ONLY |
| `7RR-0` | 137 | Comparison preview | 320 | INHERITED_DIRECTORY_ONLY |
| `7U3-0` | 138 | Comparison review | 320 | INHERITED_DIRECTORY_ONLY |
| `7WK-0` | 139 | Comparison enlarged review | 320/200% | INHERITED_DIRECTORY_ONLY |

## Eighteen retained families and actual owners

These are local navigation bindings, not a new global registry. Region IDs are proposed, not already present in the current template.

| Group | Family | Source owner / existing projection | Actual scope |
|---|---|---|---|
| leaders | Performance & currency | `engine/intl_performance.py`: `perf.leaderboard` | seven-market |
| leaders | Leadership rotation | `engine/intl_rotation.py`: `rotation_ranks` | seven-market; not capital flow |
| leaders | Cross-country comparison | `engine/intl_compare.py`: `records; rankings` | seven-market |
| recovery | Market turns | `engine/intl_market_state.py`: `turn_board; turn_events` | world-context plus core; preserve cohort |
| recovery | Recovery quality | `engine/intl_recovery_quality.py`: `turn_board recovery_assessment where supplied` | owner profile; partial coverage |
| recovery | Participation & concentration | `engine/intl_market_confirmation.py`: `owner confirmation only; full PIT concentration unbound` | owner profile; no invented breadth |
| policy | Rates, curves & carry | `engine/intl_rates.py`: `rates` | seven-market plus US anchor |
| policy | Central banks & liquidity | `engine/cb_desk.py`: `risk_desk.cb_desk; rates.liquidity` | central-bank roster; proxies labeled |
| policy | Credit & bonds | `engine/intl_bonds.py`: `risk_desk.inversion_board; em_stress; two_tier` | sovereign and EM regional; not country-credit substitute |
| backdrop | Euro-area fragmentation | `engine/intl_compare.py`: `periphery; rates.periphery` | EZ regional context; preserve Japan on return |
| backdrop | Growth & inflation | `engine/intl_regime.py`: `records; heatmap` | qualified core; unclassified visible |
| backdrop | Dollar conditions | `engine/flow_regime.py`: `risk_desk.smile; existing flow_regime publication` | global context; distinguish source families |
| pressure | Structural fragility | `engine/intl_risk.py`: `risk_desk.vulnerability` | IMF country roster; qualified vintage |
| pressure | Contagion | `engine/contagion.py`: `risk_desk.spillover; corr_tightening; two_tier` | distinct statistical and EM-US methods |
| pressure | Trade & supply links | `engine/contagion_links.py`: `CGL static/blended model context; sourced business exposure unbound` | model context is not documented company exposure |
| challenge | Cross-market correlation | `engine/intl_performance.py`: `perf.correlation` | qualified weekly USD population; not causality |
| challenge | Risk-radar track record | `engine/risk_radar_intl_audit.py`: `records risk_radar.forward_log; existing read-only scorecard` | market profile; sample and authority gate |
| challenge | Country sectors & stocks | `scripts/build_intl_library.py`: `sector_board; setups; intl_stocks.html; intl_stock.html` | existing stock universe; no assumed market filter |
