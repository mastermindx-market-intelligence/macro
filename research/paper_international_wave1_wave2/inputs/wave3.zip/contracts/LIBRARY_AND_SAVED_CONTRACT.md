# International Library and Saved Research — shared build specification

**Proposed consumer specification, not an installed API.** Read the unchanged Wave 1 view contract in `../inputs/W1_INTERNATIONAL_VIEW_CONTRACT.md`. Observed implementation and the held #804 candidate are separated in `../SOURCE_AUDIT_WAVE3.md`.

## Architecture and rejected alternatives

Macro's existing International render pipeline owns the Library and analytical reading. Terminal's **existing Investigation aggregate** owns authenticated saved intent, immutable revisions, original-operation receipts and recovery. Add an International domain adapter and a presentation variant of the existing Terminal Saved Research workspace. No second saved-state, authentication, history or retry service.

Do not put R10 into the RMS thesis-filter preset: its normalizer drops these semantics. Do not resurrect the superseded separate SavedResearch tables, add an R10 `workspace_settings` store, or stuff analytical context into the question, URL, `selection.field` or generic metadata. Paper JSX is a reference, not a reason to create another frontend application.

The protected G1 owner currently admits security/issuer subjects and Earnings evidence, not International economies. The open #804 kernel is a dependency candidate, not merged authority. Saving valid research intent may work while baseline evidence is unavailable; do not require a fabricated answer before a user can save a question.

## Catalogue and route bindings

`TOOL_BINDINGS.json` defines eighteen **local presentation keys** in six research groups. They are not global tool-service IDs. Reuse `macro:intl` and `macro:intl_stocks` from the existing page-registry grammar. Registry membership is not evidence of current rights, analytical availability or production acceptance.

Each binding declares source symbols, supplied view fields, actual analytical scope, existing route and a **proposed** region ID. Most old sections have no suitable stable anchor. The shared integration writer creates each new region once, verifies target existence, and removes old/new controller overlap. Do not link to guessed fragments.

```text
Macro lib/intl_library_view.py
  build_intl_library_view(context, qualified_workspace, route_bindings) -> LibraryView
  resolve_intl_tool(presentation_key, context, qualified_workspace) -> ToolResolution

LibraryView: catalogue_state, catalogue_generation, groups, tools, Wave1 Context
ToolResolution:
  presentation_key
  route_state: target_ready | unavailable
  data_state: supported | partial | not_applicable | missing | stale | denied | failed | unknown
  research_market: original selected subject
  analytical_scope: actual country, region, population or global context
  target: allowlisted implemented route/region | null
  reason; qualified evidence_refs
```

A working link to the credit desk can coexist with unavailable country-specific credit data. Keep the desk; do not invent a Korean spread. A denied source can also prohibit metadata, so catalogue output must consume the existing access decision before serialization. Never run the global page-registry builder, stock-analysis library, collectors, financial engines or forward ledgers during search/open/return.

## Search and navigation

Match locally over permitted localized labels, group questions and approved aliases. Search-only normalization is Unicode NFKC plus lowercase. Preserve the raw editing string; do not normalize saved author text. Proposed bound: 256 Unicode scalars. Over-bound or invalid input yields a field error without silently truncating a draft. English/Chinese aliases share the same catalogue; no embedding, LLM or external translation request.

Every normalized whitespace-delimited query term must match allowed search text. Rank an exact tool-label match first, then label prefix, then other matches; declared catalogue order breaks ties. A group-question match can return its member tools. A country word does not silently change the selected research market or prove coverage. Use copy that promises tool/question search, not an unimplemented general-market search engine.

IME composition must not submit partial text or announce intermediate results. Each committed query/filter change gets a session-local generation. Only the exact `(principal partition, catalogue generation, query generation, query, group)` may paint. Abort/ignore obsolete replies. Clear resets query only; it preserves market, group, filters and return state. A successful old reply cannot cross logout or account change.

Keep one Macro controller with Wave1 `view=library` and local `library_group`, `library_query`, selected tool and return stack. Back from a tool restores its group; back from a group restores the same search. Retain market, comparison pins, horizon/basis and source reference. Scroll/focus are session mechanics; missing triggers fall back to the relevant heading. Use search input/list semantics, not a fake combobox. Announce a settled result count once.

The authenticated Saved host remains `/analysis?view=investigations`, with exact `investigation=<uuid>&revision=<n>` links. Resolve the production Terminal origin/base path from existing navigation configuration. No current cross-origin cookie/route proof was obtained. A relative `/api/investigations` fetch from Macro must not be assumed to reach Terminal. Do not create wildcard CORS, token/cookie relays, service-role browser code or private questions in URLs.

Initially an ordinary link may open Terminal, but it must not claim lossless R10 transfer until an admitted context consumer exists. Extend the existing navigation/context owner using canonical references only. No compatible transport means an explicit integration dependency, not a new context store. The Macro read-only Library may ship independently; full Saved acceptance requires the actual cross-product round trip.

## Proposed lossless International intent extension

**Candidate version:** reserve `investigation_manifest.v3` with the incumbent contract owner. The name is proposed, not allocated/live. A different accepted version must publish a field-for-field mapping. Preserve published v1/v2 manifests and original receipts unchanged. Do not mutate applied 0028/0029; resolve #804/0030's disposition before reserving any next forward migration.

Extend the accepted Investigation manifest with one closed `research_context`. Reuse the accepted canonicalizer, reference grammar, argument relations, head/revision transaction and receipt/reconcile owner. A new manifest version does not require a parallel RPC service. Keep existing envelope bounds unless the owner explicitly changes them.

```text
research_context:
  schema: intl_research_context.v1
  research_market: canonical existing core International ID
  tool_key: one of eighteen local bindings
  tool_binding_version: accepted immutable mapping version
  period: {mode: owner_horizon, key: actually supported horizon}
       OR {mode: fixed_dates, start: YYYY-MM-DD, end: YYYY-MM-DD}
  currency_basis: local | usd_unhedged
  return_basis: price
  benchmark_ref: existing typed reference | null
  selected_measure_refs: 0..24 unique owner/object/field references
  analytical_filters: 0..16 entries from the selected tool's closed allowlist
  comparison: null OR PolicyComparisonIntent

PolicyComparisonIntent:
  economy_a: research_market
  economy_b: a distinct admitted comparison economy
  lens: nominal_policy_point_gap
  definition: absolute_gap_change_bp
  method_version: accepted method reference
  period: same typed period grammar
  instrument_a_ref, instrument_b_ref: mapped references | null
  revision_policy: latest_vintage | original_known
```

Proposed context bound: 8192 canonical UTF-8 bytes **inside** the existing manifest ceiling. Reference identity/length and canonicalization follow the accepted owner grammar. No generic filters: the first slice admits `analytical_filters=[]` only. Future per-tool keys require explicit closed admission; unknown fields refuse rather than disappear. Selected-measure references have exactly `owner`, `object_type`, `object_id`, `field`; these identify an interest, not an available observation. Mapping/reference identity must agree with the admitted domain adapter. Context names preserve the existing country's canonical identity; `engine.intl_inputs.countries()` remains the core roster. Admitting US as a policy comparator does not widen seven-market return ranks.

Only nominal point settings are in the first comparison lens. Expected paths, real-rate gaps, automatic range midpoints and hedged return modes remain unavailable. A valid incomplete intent may save with unmapped instruments, but cannot calculate. `original_known` can be intent while its result remains unavailable until actual vintages qualify.

Store the question and analytical references, not current values, a conclusion, provider bodies, confidence, rights grants, rendered HTML, screenshots, scroll, focus, temporary tabs or query-cache state. Owner/created/revision fields are server-owned. Theme/locale stay with existing preference owners.

Selected measures are research interests, not claims that their evidence is retained. A baseline remains an ordinary admitted pinned evidence member. If the International domain cannot re-resolve that exact generation under current rights, save valid intent without a baseline and show comparison unavailable. Do not manufacture a historical service by substituting today's latest.json or handing private Git paths to the browser.

TypeScript, Python, SQL admission and compatibility readers must change coherently under the incumbent owner. Current G1 SQL has the same restricted owner list as TypeScript; a frontend-only allowlist edit does not unlock R10.

## Evidence refresh and changed-first inventory

Opening, refreshing, inspecting, filtering and returning never revise the saved record, advance its baseline or mark evidence acknowledged. Recheck current rights even for retained observations. Preserve the original reference after a correction; inaccessible history is `HISTORICAL_UNAVAILABLE`.

Adapt International observations into accepted `EvidenceCensus` and `reviewEvidence` from the incumbent review kernel. Do not copy another change store. Bind owner/query/cohort/temporal policy; preserve membership completeness, content/qualification identity, correction, exclusion and units/basis/clock. **Remove numeric interpretation from excluded/stale/denied/unqualified observations before invoking the generic comparator.**

An overall `incomplete` review can contain a verified revised item. Show that change and the limitation. Do not count only `summary=changed`. A page's missing row is `not_observed`, not removed: removal requires complete same-scope membership or an explicit tombstone. New timestamps alone do not mean content changed. Missing baseline or changed scope is unavailable comparison, not zero changes.

Inventory states, evidence states and write states are separate. “Nothing saved” requires a successful owner inventory; filtered-empty retains the real inventory; auth failure/network failure are not empty. Do not silently filter the global list into International by inspecting title prose. A typed accepted `research_kind` summary projection/filter is needed to distinguish these records. Preserve non-International inventory and exact historical-revision navigation.

Proposed read budget: 12 visible summary rows and at most four in-flight read tasks; deep-read only the selected record. These are local UI bounds, not provider quotas. Avoid N+1 evidence reads over 500 records. Display “2 changed among 12 checked” unless completeness proves the whole count. Unchecked stays unchecked. Existing storage/capacity law remains with Investigation.

## Writes, uncertain outcomes and undo

Full R10 modifying acceptance depends on the accepted no-resend recovery from #804. The protected G1 code and held candidate differ; report the exact deployed capability rather than treating candidate source as live.

Explicit save freezes target, expected revision, original operation UUID, exact manifest and capture semantics in the existing principal-partitioned pending buffer before dispatch. Accept a result only when target, operation, lifecycle, revision identity and semantic readback match. Timeout, malformed reply, expired authentication or GET receipt miss remain uncertain.

While uncertain, allow Check original outcome and independent read-only research, never resend/new UUID. The same-owner reconciliation operation may return the committed receipt or atomically fence terminal `not_applied`. Only that exact fence permits an explicit new save with a new operation UUID. Reload checks the original outcome; local storage is not the authority. Preserve the denied #792 raw-ingress lane with its current owner.

Undo is a **new**, reviewed version-conditional write. Undo create = soft remove the acknowledged record; undo remove = restore; undo comparison = revise only the prior settings while preserving question, measures, baseline and unrelated fields. A newer current revision produces conflict. Never move a head backward, rewrite history, repeat the original command or overwrite later edits. Capacity refusal on restore remains visible if the incumbent capacity rules require it; do not promise unconditional undo.

## Policy preview

For four qualified nominal point settings, rates in percent units:

```text
gap_start_bp = 100 × (A_start − B_start)
gap_end_bp = 100 × (A_end − B_end)
signed_change_bp = gap_end_bp − gap_start_bp
absolute_change_bp = abs(gap_end_bp) − abs(gap_start_bp)
```

Negative absolute change = narrowed; positive = widened; zero = unchanged at endpoints. Preserve signed endpoints, especially across a sign crossing. USD display preference does not currency-convert policy rates. The illustrative Japan .50→.50 / US3.50→3.00 yields −300→−250bp: signed change+50bp but **narrowing50bp**.

Bind every result to principal partition, saved ID/revision, ordered pair, lens/method, instruments, period/cutoffs, vintage/revision policy, qualification identities and source generation. An analytical input change immediately invalidates the displayed number. Ignore late replies. Require comparable instrument definitions and four admitted observations; a target range cannot silently become a midpoint, and proxies/effective/target/deposit/refinancing rates are not interchangeable.

Fixed dates remain day-precision intent; do not convert them to #804's exact-instant research_as_of with fabricated midnight. Date order and distinct economies are required. Valid settings with unavailable evidence may still be reviewed/saved; invalid settings may not. Save updates the **same record and settings only**, not the preview answer. A new pair/fixed window leaves an unmatched old baseline unavailable and unchanged.
