# Native design access and worker inputs

Paper file `01M3P1TW5Y3XWQC37ADDS8K5AG`, [Library/Saved/Comparison page](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG/p-5-0).

This package contains **no native screenshot or JSX files for Wave 3**. Fourteen actual Paper screenshots were inspected through the existing direct tool, and key native specification text was read. Token hash 501 cd 923 is not a full-file revision. Exact node links/IDs and semantic contracts are supplied; no atomically frozen design snapshot is claimed.

The earlier Wave 1/2 native archives on M 2 remain their own inputs. Their images do not automatically cover this newly reviewed family. The current wave's Studio compound runtime/catalog preflight was refused before dispatch and was not retried. Do not repeat that preflight through another carrier or have a worker perform it as a workaround.

## Minimal inputs per worker

| Consumer | Relevant native references | Other required inputs |
|---|---|---|
| IM07 Library | RU-0,35T-0; six group entries in the census; 422-0/3 Q 6-0 specifications |18 binding map, context contract, group/search state cases |
| IM08 backend adapter |6EG-0;4OU-0/4SM-0/4QU-0 for write intent |current Investigation source, held dependency interface and source audit; numerical workers do not need pixel assets |
| IM09 Saved UI |5ZJ-0,6NG-0,6BY-0,73O-0,4M2-0,4OU-0,4QU-0,4SM-0 |review/read/write state contract; exact responsive variants listed in manifest |
| IM10 comparison |77R-0,7D2-0,7HX-0; inherited mobile/small variants |policy comparator and draft/review vectors |

A worker with independently admitted Paper read access may use the exact permitted targets through its own approved interface; installation alone is not a grant. A worker without access needs a frozen bounded reference subset supplied by an admitted design owner once that exact export route is lawfully available. Publication/transfer to that worker is a separate receipt. Do not claim the subset delivered merely because it exists on M 2 or in a different account.

A future permitted subset should bind file/page/node, capture time, actual screenshot and JSX hashes, reference role and known drift. Before/after target JSX equality is useful evidence but not a whole-file revision. No fonts, credentials, personal storage exports or provider payloads belong in that subset.

**Held targets:**3C4-0,3WS-0,3YE-0,400-0. Their identical inherited titles do not identify the four search states. Preserve their read/export gate until a genuine permission change; do not reorder, infer, regenerate or redistribute them to evade the refusal. This does not block implementing search semantics from the already-read specification.

Native composition is not interaction, real typography, backend binding, rights, accessibility or production proof. The existing live-browser administrator restriction remains; exact UI proof is owed on the actual admitted served build, not through an alternate browser/profile/host workaround.
