# Mastermind Paper build handoffs — Wave 3

**International R10: Library, Search, Saved Research and Policy Comparison**  
Research date:6 October 2026. Four handoffs,20 bounded tasks,18 retained tool-family bindings. Wave 1/2 remain unchanged.

## Start here

- [Astra addendum](orchestration/ASTRA_WAVE3_ADDENDUM.md): sequence work and coordinate the incumbent Investigation owner.
- [Readiness](READINESS.md): what can start independently and what remains genuinely gated.
- [Shared specification](contracts/LIBRARY_AND_SAVED_CONTRACT.md): navigation/search, closed intent, evidence review, recovery and comparison contracts.
- [Source audit](SOURCE_AUDIT_WAVE3.md):22 source/design findings and exact source pins.
- [Page/node census](census/CENSUS_WAVE3.md):50 inherited nodes,14 new visual observations and 4 held search-state nodes.
- [Design access](DESIGN_ACCESS.md): exact Paper references and missing frozen-export/worker-transfer evidence.

## Implementation packets

| Packet | Outcome |
|---|---|
| [IM-07](handoffs/IM-07_LIBRARY_SEARCH.md) |Find eighteen research families, enter valid existing analytics, preserve search/market and return correctly |
| [IM-08](handoffs/IM-08_INVESTIGATION_ADAPTER.md) |Losslessly bind International intent and evidence to the existing Investigation owner |
| [IM-09](handoffs/IM-09_SAVED_WORKSPACE.md) |Reopen the same question, show evidence changes honestly, and handle reviewed writes/recovery |
| [IM-10](handoffs/IM-10_POLICY_COMPARISON.md) |Qualified nominal policy-gap preview and deliberate same-record settings changes |

**Important correction:** Terminal#777 merged the Saved Research/Investigation aggregate. Current G1 does not admit International yet, and its #804 kernel repair remains Draft/HOLD. Do not create another saved-research store, call the RMS preset API, or take over the incumbent carrier.

The package includes executable **specification examples**, not production implementation. See [verification](verification/VALIDATION_REPORT.md). Actual source probes separately demonstrated the RMS field-loss boundary and review-kernel semantics. No database migration, product source, Paper design, alert, trade, deployment or worker launch was performed.

This is a conversation artifact, not a GitHub/Agent OS publication. The current host checkpoint is in the established M 2 research evidence directory. No autonomous continuation after this turn is claimed. [Continuation](CONTINUATION.md) records the remaining programme frontier and preserved gates.
