# IM-07 — Research Library, six groups and deterministic search

**Disposition:** ready for bounded source implementation against accepted Wave 1/2 interfaces; not dispatched or released. This read-only lane is independent of the Investigation kernel hold. **Goal:** users can find all eighteen retained research families, enter the correct evidence view and return without losing their investigation. No stock engine, user-state write or monitor runs on navigation.

**Architecture:** Python/Jinja presentation over existing International producers, one existing route controller, scoped CSS/JavaScript. **Read:** `../contracts/LIBRARY_AND_SAVED_CONTRACT.md` §§Catalogue/Search/Navigation; `../contracts/TOOL_BINDINGS.json`; Wave 1 contract and preservation map. **Source:** Macro dd3d218eec55fb2f55526e81877a7ee3134efd8c. Source custody and material source/interface deltas must be checked before START; do not repeat the whole census.

## 1. Paper reference and what is actually approved by observation

[International R10 — Library page](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG/p-5-0): desktop `RU-0`, mobile `35T-0`, group pattern `3MN-0` were visually inspected in Wave 3. The six group references are leaders`3IN-0`, recovery`3JZ-0`, policy`3LB-0`, backdrop`3MN-0`, pressure`38A-0`, challenge`3NZ-0`. Small-screen references`39M-0`, `3DH-0`, `3ET-0`, `3HB-0` are inherited directory references, not fresh visual acceptance. Specification`3Q6-0` is on page`p-1-0`; state architecture`422-0` on this page.

The four same-title search-state nodes `3C4-0 / 3WS-0 / 3YE-0 / 400-0` remain **HELD_DO_NOT_RETRY** after a prior refusal. Do not guess that their title order means matched/empty/loading/error, re-export them, or delegate the refused qualification to another worker. Implement state semantics from the already-read specification; qualify exact visual specimens only after the real gate changes. A screenshot of a new local implementation is not proof that these native states were approved.

## 2. Component construction and preservation

Desktop: reuse the shared header, then back-to-International, title/subtitle, scoped research context, search and All tools/Coverage/Saved controls. Render six question cards in declared order with three tool entries per card. Each row includes concise purpose, actual scope and qualified availability; unavailable rows remain useful explanations, not dead links. A working existing legacy section can be opened under a named disclosure while the modern detail is introduced.

Mobile: selected research context first, input and controls, then six stacked group entries. A group opens a three-tool reading view, not another engine. Long translated labels wrap; avoid sideways scrolling and tiny text. A second mobile backend/controller is prohibited. The older full-desktop search copy mentions markets; use tool/question wording until market discovery itself is implemented.

The complete preservation map travels in `TOOL_BINDINGS.json`. Important traps:

- Recovery confirmation is not complete seven-market constituent breadth or PIT concentration.
- Country-specific credit is not a regional OAS proxy.
- Euro-area fragmentation is regional context while researching Japan; never silently replace the selected Japan context.
- CGL model weights are not verified company trade/supply exposure. Expose qualified model context separately and keep the stronger business-exposure question unavailable until its domain owner supports it.
- The country-stocks link must use a real existing route. An unimplemented `?country=JP` filter does not make the global stock board Japan-specific.
- Retain World Risk and all existing advanced research accessible after the simplified first read. Presence of eighteen cards does not satisfy preservation.

## 3. File map and interfaces

New presentation-only helper: `lib/intl_library_view.py`, with `build_intl_library_view(context, qualified_workspace, route_bindings)` and `resolve_intl_tool(...)` from the shared spec. It reads supplied objects, performs no network or storage, and never calls the producers named in the binding table.

New partials: `templates/intl_workspace/library.html.j2` and `library_group.html.j2`. New route-local search helper: `templates/intl_library_search.js`. Integrate through the Wave 1 `templates/intl_workspace.js` and scoped stylesheet **only through their current integration writer**. Use existing Jinja escaping, locale and theme tokens. Do not introduce a new global navigation system.

Proposed JS functions:

```text
searchIntlTools(catalogue, rawQuery, groupId|null) -> Match[]
  Match: {presentation_key, matched_label, order}; no investment score
acceptIntlSearchReply(activeIdentity, replyIdentity) -> boolean
openIntlTool(toolKey, context, returnEntry) -> existing controller transition
```

The catalogue is a small static/permitted presentation projection. Source field access and rights are qualified before browser serialization. Use existing compiled asset handling through `scripts/build_intl.py`; that file and `templates/intl.html.j2` have one writer shared with Waves 1/2. Preserve `mode=stocks` byte/behavior compatibility as defined by the current programme.

## 4. Bounded task graph

Every task follows failing focused test → minimal change → focused and relevant regression pass → exact commit/diff receipt. No worker needs the whole Paper file or full parent transcript.

### IM07-T1 — Pure catalogue projection
**Worker:** economical Python worker under data lead. **Paths:** new `lib/intl_library_view.py`, `tests/test_intl_library_view.py`; approved fixture folder only. **Input:** accepted Wave 1 view payload and binding table. **Output:** eighteen unique keys, six groups, exact source scope and typed target state.

Required tests: six groups × three unique tools; duplicate key/group rejected; missing projection affects only its family; denied value absent from serialized output; metadata denial does not leak a label; Japan+fragmentation resolves explicit EZ context while retaining research_market=JP; trade-links never calls static model weights documented company exposures. A missing region must return unavailable rather than a guessed URL.

### IM07-T2 — Deterministic local search
**Worker:** GLM Flash/Minimax JavaScript worker. **Paths:** `templates/intl_library_search.js`, `tests/test_intl_library_search_js.py` and synthetic cases. **Output:** functions above, same behavior EN/ZH.

Required tests: empty-query eighteen results; exact-label precedence; all-term match; declared-order tie; fullwidth Latin NFKC; Chinese alias; long input error preserving raw input; IME composition no premature match; catalogue revision/query/account changes reject obsolete reply; clear affects query only. Prove zero fetch/provider/model calls. Search normalization must not mutate the saved question or catalogue strings.

### IM07-T3 — Responsive Library and group rendering
**Worker:** frontend worker. **Paths:** the two partials and path-disjoint scoped CSS section assigned by integration lead; `tests/test_intl_library_render.py`. **Input:** T 1 projection. **Output:** desktop six cards and mobile group journey, semantic search/result controls.

Required tests: all eighteen links or explicit unavailable states; one active representation for assistive technology; all six groups keep their identity; 320 px/200%-text fixtures retain full labels and controls; no unsafe source HTML; empty search differs from catalogue failure. Use native references specified above, not a newly generated redesign.

### IM07-T4 — One controller, real targets and legacy preservation
**Worker:** incumbent International integration writer. **Paths:** accepted `intl_workspace.js/css`, builder/template mount, current asset/CI owner declarations and integration tests. **Output:** real `im-tool-*` anchors from the binding map, return stack, no duplicate old/new script handlers.

Required tests: eighteen target resolutions against actual rendered HTML; group→tool→group→search exact return; URL reload with unsupported key fails visibly; focus fallback when a row is absent; source generation pinned throughout expansion; both macro and stocks renders. Instrument the build/test seam to show navigation does not call `build_intl_library.main`, `intl_run.run`, `contagion_links.snapshot`, scorecard governance, save, alert or trade methods.

### IM07-T5 — Independent consumer and browser acceptance
**Worker:** author-distinct review worker, then Sol. **Output:** exact candidate/base, 18-row preservation checklist, source tests, native-reference deviations and real-browser evidence state.

Browser matrix:1440/768/390/320 × dark/light × EN/ZH, keyboard/touch, 200% text, reduced motion. Exercise all six returns, no-JavaScript fallback and a source outage. Validate accessible status/error text, not only resting screenshots. Any existing administrator restriction remains a gate; do not change host/profile to bypass it.

T 1/T 2 can proceed independently after contract freeze. T 3 consumes T 1. T 4 owns shared files; page workers return bounded patches. T 5 cannot approve unobserved live claims.

## 5. Release and rollback

This packet can ship read-only without IM08–10 only when every advertised link/state is truthful and the accepted browser/preservation gates pass. Saved controls can link to the real existing Terminal host; they must not claim an R10 intent transfer or working save before that integration exists. No new flag service is needed; use existing route rollout/publication authority.

Rollback restores the old Macro mount/assets through the existing publication path. Do not alter current financial outputs, stock ledgers, Investigation records or its database migrations. Return a precise partial-readiness result rather than a cosmetic eighteen-card completion.
