# IM-09 — Saved Research workspace, evidence refresh and safe recovery

**Disposition:** source-design ready; live modifying release depends on IM08 and accepted incumbent #804 recovery. **Goal:** a user reopens the same International question, sees what evidence changed and what remains unresolved, and can explicitly edit/remove/restore without lost drafts or duplicate records.

**Architecture:** extend Terminal's existing `InvestigationWorkspace`, not a new Macro cloud workspace. Use accepted Investigation API/recovery, shared theme/locale and the International evidence adapter. **Read:** shared contract, IM08, source audit and design-access limitations. **Source base:** Terminal 64c1ea5e25a335a0b0636e73e7fdbe0f8beb7b0e; #8040654cf7ad2fb6c5242fe1fc4ffaae3d48b912a7b is a held integration candidate.

## 1. Paper and component anatomy

[Saved Research designs](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG/p-5-0): inspected desktop dark EN`5ZJ-0`, desktop light EN`6NG-0`, mobile dark EN`6BY-0`, mobile dark ZH`73O-0`, reopened 320`4M2-0`, review`4OU-0`, success/undo`4QU-0`, uncertain`4SM-0`. Specification`6EG-0` governs current semantics. Tablet`66Y-0`,320`6IO-0`,200%text`6L2-0` and other failure-state boards are inherited references awaiting exact visual qualification, not claimed reviewed this turn.

Desktop is three regions: inventory, selected research, evidence/next-action rail. The top change banner names checked coverage and does not presume every saved record was re-evaluated. Inventory keeps All/Changed/Needs review and explicit Unchecked behavior; newest saved revision is not necessarily newest evidence. Sort by a real available field and label the sort honestly.

Selected research shows exact question and analytical context, current qualified generation, comparison against saved evidence, supported/excluded changes, and a modest current research read. Then selected-measure rows and what would resolve the question. The evidence rail separates saved/updated/inventory-check clocks from field observation/publication/generation clocks.

Mobile shows changed-first inventory and opens full selected detail on the same route/state owner. It does not render the desktop into a narrow horizontal viewport. Tablet can use a compact inventory rail, but selection, exact revision, source field and pending draft remain one state. Use intrinsic heights at 320/200% text, not fixed-height clipping. Never build a second responsive data controller.

The Japan sample has 2/3 selected measures qualified, yet the comparison economy/history is missing. Render **“The evidence updated; the comparison is still open”**, not “policy divergence confirmed.” Those numbers/dates are fixtures. “Up to date” requires a successful matched review, not a record omitted from the summary batch.

## 2. Integration and file map

Existing files: `terminal/components/workspaces/InvestigationWorkspace.tsx` and `.module.css`, `terminal/lib/investigationSave.ts`, `terminal/lib/investigations.ts`, `/api/investigations`, and the existing mounted Analysis route. All are incumbent-owned; avoid duplicate concurrent edits with #804.

Proposed presentation components, extracted only along accepted component boundaries:

```text
terminal/components/workspaces/IntlInvestigationPanel.tsx
terminal/components/workspaces/IntlInvestigationPanel.module.css
  IntlInvestigationPanel({record, evidence, review, onInspect, onContinue, onEdit})
terminal/lib/intlInvestigationPresentation.ts
  summarizeIntlReview(review) -> {has_material_change: boolean|null, completeness, changes}
  projectIntlInventory(items, checkedReviews, filter) -> visible rows + checked coverage
```

The parent remains owner of selection, authentication, exact revision URL, pending operation and read cancellation. Child components do not call Supabase directly or create their own persistence hooks. Safe display fields come from IM08's adapter. A new domain-summary discriminator must be typed; do not filter records by words in a question or assume all Investigation items are International.

No anonymous local “saved research” fallback should impersonate cloud persistence. An optional unsent draft can remain in the existing principal/session draft buffer, clearly unsaved. Browser storage failure before dispatch prevents the write; a lost response after dispatch instead enters uncertain recovery.

## 3. State contracts that must survive visual simplification

Inventory: loading; successful populated; successful true-empty; filtered-empty; access-required; unavailable. A filtered result of zero does not overwrite the underlying inventory. A partial or malformed list is not proof that the user owns no questions. Account change aborts reads and clears mounted private state.

Evidence: independent source loading/qualified/partial/stale/missing/denied/failed/unknown. Missing baseline is not a comparison with zero changes. An obsolete refresh cannot paint over a newer selected record, revision or draft. Retain the selected question even when its source fails, but do not show a no-longer-entitled value as a stale fallback.

Write: explicit review, pending, uncertain, exact committed receipt, semantic-readback pending/failed, definitive refusal, version conflict. The immutable receipt can prove a commit even if subsequent readback is temporarily unavailable; show **saved, readback unavailable**, not retry-create. Conversely, HTTP 200 without matching semantic receipt does not prove save.

Undo of create/remove/settings is its own reviewed CAS write. A later current revision must not be overwritten by the old undo. Keep a user's draft when resolving a conflict; never merge their question or settings automatically. Reads, refreshes, tabs and navigation do not save, acknowledge a baseline, start a monitor, trade or task.

## 4. Five bounded tasks

### IM09-T1 — Pure presentation and checked-coverage projection
**Worker:** economical TypeScript worker. **Paths:** new `intlInvestigationPresentation.ts` and `__tests__/intlInvestigationPresentation.test.ts`. **Input:** existing inventory plus IM08 review objects. **Output:** typed counts, selected-data coverage and material changes with explicit unknowns.

Tests: incomplete review with a revised item still shows a material change; unchecked is not unchanged; scope-changed/denied/unavailable cannot be zero-change; multiple changes on one field do not inflate changed-field count; all 3 selected with 2 qualified retains 3 denominator; missing question prerequisites keep readiness incomplete; zero-value field remains valid; no count is an investment confidence score. Preserve actual incumbent lifecycle fields.

### IM09-T2 — Responsive selected detail and evidence rail
**Worker:** frontend worker. **Paths:** new domain panel/CSS/test; receives a disjoint child component, not the parent controller. **Output:** the desktop/mobile anatomy in §1, EN/ZH and both themes.

Tests: source text escaped; exact question whitespace retained; signed values and units; no repeated IDs across responsive variants; 320 px/200% reflow; source clock absent reasons; denied values absent;2/3 coverage does not imply answer; longer Chinese labels retain action names. Own source screenshots should be compared to the exact native node references; no “pixel match” claim without actual comparison.

### IM09-T3 — Existing workspace mounting and read navigation
**Worker:** current Investigation UI integration writer. **Paths:** existing workspace/mount/API read-summary seam and relevant tests. **Output:** typed International variant under the same `/analysis?view=investigations` route and revision URLs.

Tests: filter empty versus true empty; selected record survives refresh; late old-record response ignored; explicit original revision is not replaced by head; safe Back/close focus restoration; auth-return resolves current principal; source unavailable retains question; independent account partitions; neither open nor refresh creates revision, baseline write or layout mutation. Preserve existing security/Earnings/Thesis/layout views, and regression-test them.

### IM09-T4 — Review, save, readback and conditional undo
**Worker:** incumbent recovery/UI worker after #804 acceptance. **Paths:** existing recovery glue plus domain review payload; **not** a new retry implementation. **Output:** exactly reviewed semantic changes through IM08 and accepted `begin/settle/reconcile` behavior.

Tests: storage failure before dispatch; double click; delayed mutation plus response loss; GET receipt miss retains original key; Check original outcome only while uncertain; final not_applied fence permits explicit new save; committed receipt + failed detail read does not resend; conflict retains draft; remove/restore same ID; comparison undo only settings; account change clears private mounted data and blocks stale callbacks. Do not recreate the denied #792 raw parser task or copy source around its gate.

### IM09-T5 — Author-distinct real-path acceptance
**Worker:** reviewer and admitted browser operator; Sol accepts. **Output:** responsive/locale/theme captures for real transitions, authenticated multi-session persistence and isolation proof, exact release binding.

Exercise save→readback→leave→fresh-session reopen, source correction, entitlement loss, source failure, partial changed review, concurrent edit and undo conflict. Capture pending/uncertain/conflict—not just rest states. Prove no hidden alerts/monitors/trades/tasks and no original-baseline advancement on open. Browser/admin restrictions are not overcome by changing host/profile. Mocked transport is useful fixture proof only.

T 1/T 2 can proceed over fixtures. T 3 must coordinate the shared candidate. T 4/T 5 cannot claim live save without the accepted owner extension/recovery and actual deployed contracts.

## 5. Release, rollback and exact return

A presentation-only preview is not a saved-workspace delivery. It may be reviewed before backend release, but production labels/buttons must reflect actual admitted capabilities. Separate `UI_READY`, `OWNER_BOUND`, `MIGRATION_OBSERVED`, `DEPLOYED`, and `AUTHENTICATED_JOURNEY_PROVEN` evidence in the return; these are reporting dimensions, not a new lifecycle system.

Return exact kernel and consumer commits, modified files, semantic save/readback sample, failure-state results, tested viewport/locale matrix, field-clock/rights receipts and remaining gates. Rollback removes the new domain UI mount while leaving Investigation heads/revisions/receipts and historical reader compatibility intact. Never delete saved questions or disable existing Earnings/RMS functionality to make the new UI appear consistent.
