# IM-08 — International intent and evidence binding to the existing Investigation owner

**Disposition:** architecture-ready and dependency-bounded; not a new Saved Research implementation. **Goal:** save and reopen a lossless International question/context through Terminal's existing Investigation aggregate, with current evidence qualification and no duplicate persistence/retry plane.

**Dependencies:** incumbent Terminal #804 accepted kernel interface and source custody; compatible International Wave 1/2 projection; admitted reference/rights owners. Current #804 is Draft/HOLD, not permission to merge/apply it. Independent fixtures and domain adapter design can proceed; shared kernel writes cannot conflict with its incumbent.

**Source:** protected Terminal 64c1ea5e25a335a0b0636e73e7fdbe0f8beb7b0e; candidate #804 head 0654cf7ad2fb6c5242fe1fc4ffaae3d48b912a7b; Macrodd3d218eec55fb2f55526e81877a7ee3134efd8c. **Read:** shared contract and source audit, not the superseded September 29 saved-owner plan.

## 1. Current owner and mandatory integration ruling

#777 merged on October 4 as d9128b500fb434e3548574e89b25a2a85053f3d7. The source already contains `investigations`, `investigation_revisions`, `investigation_mutation_receipts`, layout retention, authenticated API, save recovery and the Saved Research workspace. Its initial owners are security/issuer and Earnings. The old `thesis-saved-views` route is a separate RMS preset API and cannot retain the R10 fields.

#804 owns the active repair of immutable identity, canonical bytes, no-effect fencing and owner reference review. Its candidate changes new-v 2 grammar and temporal semantics, so blindly building against either an old Paper payload or a moving branch is unsafe. Bind to an **accepted exact dependency interface**, preserve legacy stored manifests, and integrate on the incumbent programme path. Do not cherry-pick an unaccepted kernel to claim this dependency solved.

The four gates are independent: reference syntax, admitted owner/kind, actual source/rights resolution, and authenticated persistence. Updating a TypeScript enum proves only one part. SQL currently rejects International owner/kind combinations too. No `owner_principal` field from the client can override `auth.uid()`.

## 2. Native design inputs

[Saved Research specification and workflow](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG/p-5-0): `6EG-0` fully read, especially 124.7–124.8. `4OU-0` save review, `4SM-0` unknown outcome, `4QU-0` success/undo, `4M2-0` reopened detail and `5ZJ-0` full workspace were visually inspected. Paper 124.7's old owner census is now superseded by actual #777/#804 source, while the user journey remains useful.

One older review specimen promises saved scroll/focus. Implement the newer specification and portable-context source ruling instead: **analytical intent is durable; presentation return mechanics are session-local**. Change that review copy accordingly; do not persist raw UI state to satisfy an outdated label.

## 3. Required adapter boundary

Proposed domain files (create only when no equivalent accepted owner helper exists):

```text
terminal/lib/intlInvestigation.ts
  validateIntlResearchContext(raw, admittedBindings) -> typed result
  compileIntlInvestigationIntent(existingManifest, context) -> proposed versioned manifest
  classifyIntlInvestigation(manifest) -> international | other | unsupported_version

terminal/lib/intlInvestigationEvidence.ts
  resolveIntlInvestigationEvidence(context, baselineRef|null, ownerReaders)
      -> {current, baseline, review, coverage, answer_readiness}
  toIntlEvidenceCensus(ownerResult, exactContext) -> accepted EvidenceCensus
```

Use the shared contract's **proposed** manifest/context extension. Reserve the version with the incumbent contract owner rather than widening v 2 ad hoc. All new-schema canonicalization and persistence remain in `investigationContracts.ts`, `investigations.ts`, paired`api/investigation_contracts.py`, and the existing SQL authority. Domain files must not contain their own auth, database table, retry loop, generation registry or user-state writer.

Additive read support goes through the existing Investigation API/BFF. Extend the existing owner-dispatch seam with a typed International resolver rather than making the Earnings-only baseline route pretend it resolves countries. Never accept arbitrary caller owner-module names, file paths or provider URLs. Readers consume admitted owner publications; missing retained history stays unavailable. The generic review kernel is reused after acceptance, not copied.

A useful first vertical may save question/context without a baseline. It must round-trip exact semantic fields and tell the user that changes-since-save are unavailable. This is preferable to either an indefinitely disabled save or a fabricated snapshot. Pinned evidence is enabled only when its actual source owner supplies qualified retention and current authorization.

## 4. Bounded work graph

### IM08-T1 — Freeze the International contract against the incumbent kernel
**Lead:** Sol International + existing Investigation owner; work is an interface decision, not a new orchestrator. **Paths:** domain spec/fixtures and accepted contract-owner documentation only. **Result:** exact accepted/proposed version map, source/candidate hashes, forward-migration ownership and no-overlap disposition.

Verify published v 1/v 2 read preservation, new-v 2 candidate argument relations, exact timestamp difference, reference identity/baseline membership, context 8 KiB-inside-envelope ceiling,24 measure/16 filter limits and closed per-tool filter registry. Resolve explicit instrument-policy comparability separately from storage. Keep #792 raw-ingress and current-rights restrictions with their owners; this packet does not recreate their denied work.

### IM08-T2 — Pure context compiler and discriminating vectors
**Worker:** bounded TypeScript worker, paired Python reviewer. **Paths:** new `intlInvestigation.ts`, `terminal/lib/__tests__/intlInvestigation.test.ts`, shared fixture vectors. **Inputs/outputs:** functions in §3.

Test exact EN/ZH/CRLF/composed-vs-decomposed text preservation; tool/market identity; duplicate measure references; overbounds; unknown fields; prohibited source bodies, UI state and client authority; incompatible period modes; fixed-date precision; null baseline; global-vs-local scope. `compile` must retain unrelated existing Thesis/layout/evidence/argument fields exactly; it may change only explicitly reviewed International intent and the explicitly chosen schema version. If the stored source cannot safely migrate, refuse with a retained draft, never drop fields.

### IM08-T3 — Same-owner admission and persistence extension
**Worker:** incumbent Investigation kernel implementer, not a parallel page worker. **Paths:** accepted `investigationContracts.ts`, `investigations.ts`, paired Python contract, existing API and a newly reserved forward SQL migration/namespace ledger. **Result:** transactional round trip through existing owner tables/receipts; historical data untouched.

Red tests must prove the current restricted service rejects economy/context before extension. Then test TS/Python/SQL parity, authenticated owner derivation, foreign/missing indistinguishable reads, atomic head/revision/receipt, exact original replay, changed request-ID conflict, concurrent revise conflict, cap race and old-record compatibility. Do not edit applied 0028/0029 or assume 0030 is installed. Migration application/review/readback are separate gates. A function name ending v 2 need not create a second service merely because the manifest version changes; the incumbent owns that compatibility decision and exact public mapping.

### IM08-T4 — International evidence adapter and bounded review
**Worker:** domain data lead + economical worker. **Paths:** `intlInvestigationEvidence.ts`, its tests and current owner reader extension. **Result:** qualified current evidence, truthful absent baseline, exact-scope change review and answer-readiness separate from coverage.

Required cases: historical missing never falls forward to latest; rights revocation suppresses retained value; excluded/stale numeric interpretation removed before generic review; same-value source revision remains revised; partial review still displays verified changes; page/top-k omission not removal; exact tombstone; changed cohort/period/basis refuses old comparison; generation equality with changed qualification not automatically unchanged; two qualified domestic measures still cannot answer an unspecified cross-country policy question. All reads leave saved revision/baseline unchanged.

### IM08-T5 — Real owner journey, recovery and regression acceptance
**Worker:** author-distinct reviewer/test operator; Sol accepts. **Paths:** actual existing Investigation unit/API/PostgreSQL/browser harnesses, with new domain cases. **Result:** one admitted International record survives save→exact readback→leave→fresh-session reopen→evidence qualification→return.

Prove lost response, original receipt miss, same-owner terminal no-effect fence, delayed original request after fencing, account change, source outage, remove/restore and a concurrent newer revision. Exercise generic RMS saved views, Earnings/security investigations, retained layouts and exact historical reads as controls. Do not count mocked endpoint success as a real database or authenticated browser proof. Actual source/persistence/platform installation each needs its own receipt.

T 2/domain fixture work can proceed independently while #804's release gates are resolved. T 3 waits for current source custody and accepted kernel composition. T 4 can use injected owner fixtures while real rights/retention are absent; fixture success cannot enable production. T 5 is the cross-layer acceptance boundary.

## 5. Source review and release checklist

Review specifically for a silent field-dropping adapter, spoofed owner, over-broad provider lookup, second canonicalizer, implied source-rights grant, mutable latest substituted as history, omitted baseline relation, wrong version replay, or financial numbers stored as the user's research intent. The test oracle in this package is illustrative and must be replaced by actual production-bound tests before acceptance.

The implementation return must include accepted dependency commit, candidate head, exact changed paths, migration status/readback, shared corpus results, representative round-trip manifest, no-hidden-write evidence and browser status. Keep comparisons/baselines withheld where unavailable, but do not call the entire valid-intent capability unavailable merely because one optional evidence source is missing.

Rollback disables the new consumer/manifest admission through the existing owner deployment policy while retaining all existing heads, revisions, receipts and retained references. Never delete new user records or rewrite old receipts to roll back the UI. A newly admitted saved schema needs a reader-preserving rollback plan, not simply reverting the validator and making users' records unreadable.
