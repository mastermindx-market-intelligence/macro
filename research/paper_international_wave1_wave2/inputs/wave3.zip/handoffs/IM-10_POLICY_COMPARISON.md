# IM-10 — Policy comparison: draft, qualified preview, review and same-record save

**Disposition:** pure calculation/presentation work is spec-ready; real policy data and modifying integration are dependency-gated. **Goal:** make the missing comparator explicit, calculate only the supported nominal policy-gap question, and save deliberate settings changes without turning a preview into a permanent answer.

**Architecture:** one pure comparison projection in the existing International rates owner; the existing Saved Research workspace owns the draft/review journey and Investigation owns writes. **Dependencies:** IM04 policy-instrument/field qualification, IM08 typed intent, IM09 existing recovery UI, accepted #804 kernel for writes. **Read:** shared contract §Policy preview and source audit. No forecast, signal, trading authority or new financial model is created.

## 1. Exact native source

[Comparison designs](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG/p-5-0): `77R-0` desktop draft/preview, `7D2-0` desktop review plus alternative recovery/preview states, `7HX-0` mobile setup were visually inspected. Mobilepreview`7JV-0`,review`7MG-0`,320 setup`7PV-0`,preview`7RR-0`,review`7U3-0` and 200%review`7WK-0` are exact inherited directory references, not new visual proof. Builder text in`7D2-0` and source specification`6EG-0` were read.

The review board contains **alternative states**, not a single tall product screen: newer version, uncertain outcome, confirmed save; separately updated-preview loading and missing-start-observation. Implement mutually exclusive states within the normal journey rather than stacking all specimens into production.

## 2. Meaning and calculation

The first supported lens is change in the **absolute gap between nominal point policy settings**, in basis points. It is not expected policy, real rates, a domestic yield-curve slope or an earnings forecast. Eligible mapped instruments and comparable four endpoint observations are required. Do not substitute effective Fed funds, an interbank proxy, a target midpoint or an unmatched deposit/refinancing rate just to fill the comparison.

Pure owner interface (proposed addition in `engine/intl_rates.py`):

```text
compare_policy_points(intent, observations, mapping_receipt) -> PolicyComparisonResult
Result = {state: qualified, identity, signed_start_bp, signed_end_bp,
          signed_change_bp, absolute_change_bp, direction, evidence_refs}
      OR {state: unavailable|invalid, identity, reasons, missing_refs}
```

Input numbers retain their actual units. Normalize percent levels to basis-point differences once; reject bool/NaN/infinity, malformed dates, duplicate/same economies, incompatible instruments, stale/denied/unavailable endpoint observations and unsupported revision policies. Common positive or negative rate levels are legitimate; zero is legitimate. A field's freshness and temporal precision come from its owner, not a new universal time threshold.

The native example is **synthetic**: Japan 0.50→0.50%, US 3.50→3.00%,31 Aug→30 Sep 2026. Signed Japan−US gap rises −300→−250 bp; its absolute size narrows by 50 bp. Show both endpoints, the signed change and absolute-distance interpretation. Swapping A/B reverses signed quantities but preserves absolute widening/narrowing. A sign crossing with equal absolute endpoints is not proof of a flat path; disclose the crossing. Dates alone do not prove what was known at that time.

Policy percentages are not currency-converted because the surrounding page says USD. A changed 1-month price selector must not silently relabel policy data or rescale the calculation. A fixed-date period is explicit intent, distinct from the saved rolling window until confirmation. Original-known replay remains unavailable without the domain's actual retained vintages.

## 3. Draft and result identity

Settings panel: fixed focus economy from the saved question; one distinct eligible comparator; rolling-owner-horizon or fixed dates; nominal-point lens; Preview control. Do not preselect the illustrative US for every user. Empty comparator is a genuine invalid field, not “all markets”. Date end must be on/after start. Provide exact persistent field errors and focus the first invalid input after attempted preview/save.

Every preview binds authenticated partition when private, exact saved ID/revision, ordered pair, lens, method version, instrument mapping, period mode/cutoffs, vintage policy, source generation and qualification identities. Changing any analytical input hides the old number immediately and invalidates any prior review. Old replies cannot restore the number. Switching theme/locale alone does not recompute a financial result.

Preview is read-only. When an endpoint is missing, preserve valid draft settings and explain which observation is absent. The user may still review/save valid research intent without an answer. Invalid dates/same economy cannot preview or save. Source inspection returns to the same draft and focus without mutation.

## 4. Review and write semantics

The normal review shows exactly three changes in the fixture: comparator not-selected→US; rolling month→fixed dates; unspecified lens→nominal point-gap. Preserve original question wording, focusJapan,3 original selected measures,displayUSD preference,baseline references and creationidentity. New comparison observations do not change the old coverage denominator or remove the excluded liquidity interest.

“Save changes to this question” calls Investigation revise on the **same ID**, with the reviewed expected revision and exact original operation ID. Do not call create, save the 50 bp result or recompute-and-store a conclusion. Display committed success only from the matching immutable receipt and semantic readback; readback failure after commit is not retry-create permission.

Adding the comparator and fixed dates makes the old baseline incomparable unless an actual matched baseline exists. Keep the original baseline reference; show “Compared with saved evidence: unavailable for this setup.” The 50 bp is across selected dates, not a change since save.

Undo settings is a separate conditional revise preserving all unrelated fields. A newer revision conflicts; no automatic merge or rollback to an old whole manifest. Reuse #804's accepted original-outcome reconciliation; don't add a retry queue or resurrect the protected old UI's resend behavior.

## 5. Five bounded tasks

### IM10-T1 — Pure nominal comparison and numerical vectors
**Worker:** economical numerical worker under policy data lead. **Paths:** existing `engine/intl_rates.py` with isolated helper; `tests/test_intl_policy_comparison.py`. **Output:** interface in §2; no store/network/ledger writes.

Test native sample; swapped pair; widening; true zero; both-negative rates; sign crossing; very small pre-rounding difference; percent-vs-bp input; invalid bool/nonfinite; mismatched unit/period; missing/denied/stale endpoint; target range refused; same economy/date-order invalid. Do not add a second classification engine or normalize monetary policy instruments inside the arithmetic helper.

### IM10-T2 — Actual owner instrument and observation resolver
**Worker:** policy domain owner, not UI worker. **Paths:** the existing rates/CB input and projection seams assigned by IM04; `tests/test_intl_policy_comparison_binding.py`. **Output:** four qualified observation refs plus explicit comparability/mapping receipt, or typed missing reasons.

Prove exact institution/instrument/time identity; first/last observation policy; values with independent clocks; latest-vintage versus original-known refusal; no effective-rate/target-range/proxy substitution; no assumption that four source numbers are automatically comparable. When actual provider support is absent, return unavailable and preserve the valid question. Do not open a new provider account or change rights/freshness policy on this page task.

### IM10-T3 — Draft, preview and result coherence
**Worker:** frontend worker with fixture adapter. **Paths:** proposed `terminal/components/workspaces/IntlPolicyComparison.tsx`, its scopedCSS and `terminal/lib/__tests__/intlPolicyComparison.test.tsx`. **Output:** three-step setup→preview→review inside the existing workspace, not a new route controller.

Required tests: no synthetic default pair; visible errors for missing/same comparator and end-before-start; input edit invalidates old result/review; out-of-order responses and sign-out ignored; preserve draft through source drawer/back; result unavailability differs from 0 bp; rolling→fixed affects draft only; dark/light/EN/ZH and 320/200% layout retain labeled controls; chart values also available as text/table.

### IM10-T4 — Exact review diff, revise and conditional undo
**Worker:** incumbent Investigation UI/recovery integrator. **Paths:** accepted existing review/save seam, domain payload helper and tests. **Output:** only the reviewed comparison settings update the same Investigation record through IM08; no copied answer.

Test save valid settings with unavailable result; prevent save invalid settings; keep original 3 measures/question/baseline; exclude preview output from serialized manifest; exactlyone revise after doubleclick; unknown outcome no resend; a newer source generation invalidates preview but does not silently change reviewed intent; newer savedrevision requires review; undo settings preserves unrelated later edits by refusing staleCAS. Date-only fixed window does not become an instant research_as_of.

### IM10-T5 — End-to-end comparison acceptance
**Worker:** author-distinct reviewer plus admitted real-browser operator. **Output:** actual policy qualification, rendered comparison and authenticated same-recordrevision proof, separated from fixture success.

Exercise set→preview→edit→stale reply→newpreview→review→save→readback→reopen; missingstartdata; authloss; concurrentedit; undo conflict. Show source dates/units/mappings alongside the result. Inspect actual 320 px/200%-text and keyboard focus behavior. Verify no alerts/monitors/trades/history writes, no changed baseline and no new record. If the real data lane is absent, accept only the honest unavailable-result flow plus intent persistence—not a live numerical comparison.

T 1/T 3 can proceed over synthetic inputs. T 2 owns data admission. T 4 waits for accepted IM08/#804 integration. T 5 proves the whole user journey. Native mock data and the package's arithmetic tests do not clear these release gates.

## 6. Return and rollback

Return exact source/dependency/candidate revisions, changed files, synthetic/real-source distinction, instrument admission decisions, four endpoint receipts or missing reasons, full comparison identity, serialized reviewed-change proof, and actual save/readback/undo/browser outcomes. Rollback the comparison UI/lens admission without deleting saved questions, source history or immutable revisions. Existing readers must still display previously saved intent, with its calculation capability unavailable where necessary.
