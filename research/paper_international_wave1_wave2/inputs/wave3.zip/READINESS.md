# Readiness — distinguish a buildable slice from full production acceptance

| Packet | Design/architecture readiness | Safe independent work now | Required integration/release gates |
|---|---|---|---|
| IM07 Library/Search |Detailed source-backed specification;14-wave visual set includes Library and one complete group example |Pure catalogue projection, deterministic search, responsive partials, eighteen-target preservation tests |Accepted Wave 1/2 interfaces; one shared writer; exact native state qualification where held; actual browser and publication proof |
| IM08 International Investigation adapter |Detailed owner-native extension plan; no new storage plane |Pure context fixtures/compiler and domain resolver interface; coordinate existing owner |#804 accepted kernel/source custody; coherent TS/Python/SQL admission; lossless context version; admitted source rights/retention; real save/reopen proof |
| IM09 Saved workspace |Main desktop/mobile/light/Chinese and recovery specimens inspected |Pure presentation, coverage/change tests, responsive child component over fixtures |IM08 binding and existing workspace integration; original-operation recovery; authenticated round trip; native variant/browser proof |
| IM10 Policy comparison |Draft/preview/review semantics and arithmetic resolved |Pure arithmetic, draft/result-identity tests and UI fixtures |Actual instrument comparability/endpoint data for a live number; IM08/09 for writes; same-record recovery and browser proof |

No row is labeled production-ready. Design intent may be implementable while a capability is still `SPEC_ONLY`, `PARTIAL`, or `BUILT_NOT_PROVEN`. Those labels cannot be inferred solely from a screenshot or the number of completed tests.

## Do not reduce the product to read-only forever

A valid research question/context can be saved without a qualified historical baseline. Implement that useful capability through the accepted Investigation owner, then show baseline comparison unavailable until the domain supports it. Likewise a valid comparison setup can be saved when one source is absent. The forbidden shortcut is an invented result, not a useful incomplete research state.

The Library's read-only slice is independently useful and should not wait for the entire Investigation programme. Its saved-navigation label must remain honest about the current cross-product integration.

## Preserved holds

Terminal#804's kernel/review/migration gates, its denied#792 raw-ingress follow-up, Macro#7870 rights dependency, four refused search-state targets and the live-browser administrator restriction remain with their existing owners. Neither the user’s continuation nor this plan clears them. Unrelated permitted work continues without duplicating those lanes.
