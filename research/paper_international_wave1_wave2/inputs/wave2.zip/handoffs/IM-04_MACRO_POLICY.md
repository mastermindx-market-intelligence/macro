# IM-04 — International Macro & Policy implementation handoff

**Goal:** a prepared economic/policy read that makes evidence gaps explicit and preserves the existing detailed macro, rates, liquidity and country research. **Status:** BUILD_SPECIFIED; current-source integration, native metadata, browser review and deployment remain unproven. This is not a commission to invent a policy predictor or rewrite the regime engine.

**Architecture:** extend Wave 1's one International view model, Jinja route and controller with a pure Macro leaf, current-only native component evidence and a responsive Macro partial. Preserve the existing financial definitions and their source owners. **Stack:** existing Python/Jinja/CSS/JavaScript; no framework migration. **Spec:** `contracts/MACRO_RISK_EXTENSION.md` and the unchanged Wave 1 contract.

## 1. Exact references and custody

Macro audit: `ef1f7db98cff38b2a2b2d50e221da61c99e97611`. Governing Mastermind pin: `d8c302b8a8a65ab13e2afba98cc73481606ed4d0`. These pin research, not a perpetual START lease. Receiving Sol checks only relevant source/interface changes and current assigned custody; no new whole-estate census.

[Open Macro & Policy in Paper](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG/p-3-0). File: International Markets · R10 · Current Build.

| Role | Exact node | Review this turn |
|---|---|---|
| Desktop 1440 | `B4-0` | Full native screenshot + exact JSX |
| Mobile 390 | `2HL-0` | Full native screenshot + exact JSX |
| Compact 320 | `2K5-0` | Full native screenshot + exact JSX |
| Enlarged text 320 | `2MP-0` | Native composition + JSX; heading 52px/64px confirmed |
| Source/behavior specification | `2WI-0` on [specification page](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG/p-1-0) | All 19 text nodes read |
| Small-screen contract | `3TE-0` on specification page | Frozen JSX accompanies design pack |

Use the new frozen design archive receipt in `evidence/NATIVE_DESIGN_PACK.json`. Each board's JSX was identical immediately before and after its screenshot. That is target stability during capture, not an atomic full-file revision. No open comment threads were returned on this page; absence of comments is not design approval.

Wave 1 may already be executing. Do not alter its handed-off files, branch or worker assignment. One existing integration writer owns `lib/intl_workspace_view.py`, `scripts/build_intl.py`, `templates/intl.html.j2`, shared route CSS/JS and CI. Leaf workers return their bounded changes to that writer; do not create a second route mount.

## 2. Page construction and feature preservation

The first screen has three layers: a brief qualified economic interpretation (or an explicit inability to classify), coverage immediately beside it, and a direct path to the relevant source evidence. Never bury missing CPI/GDP behind Advanced. Desktop pairs the categorical quadrant with the explanation of economic cycle, realized policy and market response; it does not make one score from the three.

The table retains every configured market. Its columns are GDP YoY, CPI YoY, the correctly identified policy instrument, nominal 10y yield, qualified yield change with actual interval, and a field-evidence action. Values and dates come from the one admitted generation, not Paper sample copy. For a proxy-only market, the official-policy cell is unavailable while a clearly named proxy remains discoverable in evidence. Policy levels, release prose, next meetings and market-implied paths are separate capabilities.

Mobile renders the selected subject as one research thread: cycle interpretation → explicit unclassified coverage → GDP/CPI evidence → realized policy/rates → separate market return → deeper tools → Back to overview. Switching the subject never resets benchmark, period or comparison pins. The Euro-area specimen is an example, not the default for every user. When no subject is selected, use the first configured accessible subject or retain the all-market view; never select the best-looking fixture.

Retain rates/curve comparison, US anchor and yield differential, ECB balance-sheet context, peripheral spreads, central-bank source details, existing country dashboards, credit and monetary-policy research. They may live in named disclosures on this route, but a page card cannot replace working depth with a promise. Native statements stronger than the actual source are qualified or withheld, not mechanically copied.

## 3. Existing seams and exact decisions

| Source seam | Existing fact to reuse | Required treatment |
|---|---|---|
| `engine/intl_run.py:40–74` | Record and already computed classifier row | Add current component evidence once; do not recompute classification |
| `engine/intl_regime.py:54–94,144–161` | Components, fixed weights, hysteresis, reported quadrant | Read source method; keep proxy/macro mixture visible; no new state machine |
| `engine/intl_inputs.py:181–246` | Latest values and observation-month metadata | Month precision is not a fresh release timestamp |
| `engine/intl_rates.py:86–149` | Rates rows, anchor, carry, ECB impulse, periphery | Respect source clocks, units and exact legs |
| `engine/cb_desk.py:48–160,333–429` | Bank/instrument/cadence plus realized source state | Explicit `ECB/XM → EZ` join; official/proxy/effective distinctions |
| `engine/ird_velocity.py:33–121` | Observation-count change and z-score | Do not claim 20 sessions from 20 raw monthly points |
| `scripts/build_intl.py:594–613,888–924` | Existing risk/CB and rates packets; macro/stocks render | Compose accepted leaf once, keep stocks unchanged |

The source audit found `_trend_3m()` uses `0.10/100` while its comment says 10bps, and its monthly lookback spans two intervals. `_bs_impulse()` counts monthly BoJ observations as weeks. A routine UI worker must not choose new thresholds or redefine these shared calculations. IM04 publishes qualified exact rate levels/source steps and withholds unsupported trend/weekly-impulse claims. A separately assigned owning source repair can later qualify them without blocking this page's otherwise useful read-only build.

The country history currently strips component columns. Do not promise historical contribution charts from that parquet. Current-only component evidence is a small additive change; original-as-known component history is a later capability with real vintage requirements.

## 4. Bounded task graph

### IM04-T1 — Preserve and expose native current component evidence
**Files:** modify `engine/intl_regime.py`, `engine/intl_run.py`; create `tests/test_intl_cycle_component_evidence.py`. No collector, weights, scoring thresholds, hysteresis, historical rewrite or provider changes.

**Consumes:** existing `classify()` result at the exact record `asof`. **Produces:** `component_evidence_at(reg, asof)` and additive `record.cycle_components`, exactly as specified in the extension contract.

- [ ] Write a red test asserting the new helper returns all native growth/inflation component keys, owner weights, emitted axis scores/counts, true zero and null without changing the classifier frame.
- [ ] Prove red because the helper/additive field is absent, not because fixtures or dependencies are missing.
- [ ] Implement extraction from the already computed row; use owner constants, not copies in the UI. Add the field once in `country_record()`.
- [ ] Test old record fields byte/value-equivalent and the saved history columns unchanged. Assert one `classify` call and no source/store writes by the helper.
- [ ] Run the existing regime/record owner suite plus the new tests, then commit only these paths and return the exact contract diff.

### IM04-T2 — Pure Macro view projection
**Files:** create `lib/intl_workspace_macro.py`, `tests/test_intl_workspace_macro.py`, `tests/fixtures/intl_workspace/macro_cases.json`. One shared integrator adds the call in `lib/intl_workspace_view.py` later.

**Consumes:** `build_macro_section` inputs in the extension contract, including IM04-T1 metadata when present and Wave 1 rights-admitted metrics. **Produces:** `sections.macro` without I/O.

- [ ] Write parameterized red tests for qualified economic evidence, missing GDP, stale CPI/fresh build, proxy-only policy, ECB identity, zero value, malformed data, owner-hysteresis disagreement, source denial and no current component metadata.
- [ ] Assert configured IDs = classified union unclassified, disjoint and unique. A filtered table never silently changes that set. No literal `1/7`, sample country story or probability.
- [ ] Implement deterministic copy predicates and separate source-reported state from economic presentation eligibility. Do not reconstruct a financial signal.
- [ ] Verify the pure helper with network/store/ledger functions replaced by fail-fast traps; any call is a failure. Verify denied input and forbidden derived copy absent from serialized JSON.
- [ ] Commit the leaf and fixtures; return exact test results and degraded-state examples.

### IM04-T3 — Responsive Macro reading and evidence actions
**Files:** create `templates/intl_workspace/macro.html.j2`, `tests/test_intl_workspace_macro_render.py`, `tests/intl_workspace_macro_dom.test.cjs`. CSS/JS changes are a scoped patch for the existing integration writer, not a competing standalone controller.

**Consumes:** `sections.macro` and Wave 1 evidence/navigation callbacks. **Produces:** semantic Macro markup and named actions `openEvidence(fieldRef)`, `selectMarket(id)`, `openResearch(key)`, `returnToOverview()` dispatched through the one existing controller.

- [ ] Create render tests that require all source IDs and field-evidence bindings, escaped hostile copy, caption/header semantics, explicit proxy wording and usable no-JavaScript depth.
- [ ] Implement desktop composition from B4; implement selected-subject mobile from 2HL/2K5 with enlarged-text wrapping from 2MP. Do not ship the fake iOS status bar or canvas coordinates.
- [ ] Add DOM-port tests for subject switch, evidence open/close, exact return, unsupported destination, theme/locale preservation and duplicate-live-ID prevention. Do not mock away the route reducer under test.
- [ ] Confirm no new fetch/save/alert handlers, no inline source HTML and one active representation for assistive technology.
- [ ] Return the leaf, shared-file patch, exact fixture and design-node mapping for integration.

### IM04-T4 — One integration, independent review and release qualification
**Owner:** existing International integration lead; independent review by a different worker and Sol acceptance. **Files:** shared Wave 1 root/builder/template/assets, existing CI owner declarations, applicable source tests only.

- [ ] Integrate T1/T2/T3 without displacing active Wave 1 work. Call the leaf from the one root composition using the existing `rates` and `risk_desk.cb_desk` packets.
- [ ] Render through actual Jinja + `lib.pages.write_page` into a temporary sink in both macro and stocks modes. Assert preserved stocks behavior and existing country/library routes.
- [ ] Add these new tests to the existing applicable CI owner. `ird-substrate-engines` already runs CB/IRD tests in `.github/ci/legacy-jobs.yml`; preserve pack routing and current path/import closure rather than creating a new workflow.
- [ ] Obtain independent exact-head review of component extraction, claim predicates, fields/units, HTML safety, feature retention and side effects. A returned summary is not acceptance without its actual evidence.
- [ ] After actual browser admission, prove 1440/768/390/320 × dark/light × EN/ZH, 200% text, keyboard/Back/focus, reduced motion and authenticated rights. Then use the normal release owner and verify served generation. Do not bypass the inherited browser restriction.

## 5. Review focus and discriminating cases

**Sparse data:** a qualified index return coexists with unclassified economic cycle. **Identity:** DFF is an effective rate, not a target range; interbank proxies remain proxies. **Time:** monthly observations and a fresh shell never counterfeit a daily change. **Authority:** reported composite is not forecast probability or allocation. **Navigation:** subject, period and invoking focus survive evidence and browser Back. All five classes have owning tests above; untested browser semantics remain explicitly owed.

Proposed commands, to run after implementation:
```sh
python -m pytest tests/test_intl_cycle_component_evidence.py tests/test_intl_workspace_macro.py tests/test_intl_workspace_macro_render.py -q
python -m pytest tests/test_cb_desk.py tests/test_ird_velocity.py tests/test_ird_wiring.py tests/test_intl_regime.py tests/test_intl_rates.py tests/test_intl_build.py -q
node --test tests/intl_workspace_macro_dom.test.cjs
```
These are acceptance commands, not results from this research turn. Keep the established differential contract, design and template/site synchronization checks; the actual current owner chooses supported flags. No sparse skip, deselection or empty fixture counts as observed behavior.

## 6. Release, rollback and stop conditions

Source-ready requires agreed interfaces, red/green evidence, real-template parity and independent review. Public-ready additionally needs the admitted full browser/rights journey and actual publication identity. No new subscription, data procurement, live allocation, Follow or Saved feature is authorized by this packet.

Rollback restores the prior Macro partial/mount/assets through the normal release path; additive unused metadata is harmless. Never roll back or rewrite market history to reverse a UI release. Return to Sol only for a current source collision, a missing required owner contract, reserved financial-policy decision, permission denial or uncertain effect. Ordinary layout and test repairs stay with the project lead.

### Positive-path completion guard

An all-null placeholder is not acceptance. Source tests must execute the actual positive and negative implementation paths; product release must demonstrate a useful real source-backed journey (and the real manual calculator for IM06), retained legacy depth, and genuine source-specific abstention. Missing advanced sources stay explicit unfinished data obligations; they do not license silently shrinking the promised core capability.
