# IM-05 — International Risk & Transmission implementation handoff

**Goal:** show how price/currency arithmetic, current stress, statistical linkage and slow structural exposure differ, with useful evidence at each step and an explicit stop before unsupported company-impact claims. **Status:** BUILD_SPECIFIED; not a new risk model, current-data certification, monitor or deployed route.

**Architecture:** a pure Risk leaf inside Wave 1's one International composition, plus a Jinja partial and actions through its existing route controller. Reuse existing `risk_desk`, `CGL`, country and performance packets; never run source engines from a renderer or navigation event. **Spec:** `contracts/MACRO_RISK_EXTENSION.md`. **Stack:** existing Python/Jinja/CSS/JavaScript.

## 1. Exact design and source inputs

[Paper Risk & Transmission page](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG/p-3-0): desktop `GH-0`, 390 `2P9-0`, 320 `2RO-0`, 320/200% text `2U3-0`. Specification `2WI-0` is on [the specification page](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG/p-1-0). All four native layouts and their exact JSX were inspected; the dark/English variants do not establish other locale/theme or browser acceptance.

Macro audit pin `ef1f7db98cff38b2a2b2d50e221da61c99e97611`; source-to-Wave-1 comparison showed no change in the principal International/rates/risk files. Reconcile only relevant deltas and existing source custody before START. Keep Wave 1 branches, source owners and artifact bytes untouched.

Source `PR #7872` remains an open Draft/HOLD episode-aware Risk Radar authority candidate at `5d6ae511c7b82b05e175ba7ea36e2fc5003b6502`. Its separate audit/evidence/CI paths do not become this page's property. This handoff changes neither radar grants nor predictive eligibility.

## 2. User journey and composition

The selected-market currency channel comes first. It explains local index return, the change in USD per local currency unit, received USD return and the difference in percentage points. The period/basis/identity must agree. For the synthetic Korean case: local −1.8% and raw currency −0.8% compound to −2.5856%; FX contributes −0.7856pp. Rounded displays are −2.59% and −0.79pp. Missing FX preserves a separately valid local return, not a fabricated USD outcome.

The “fast pressure / slow resilience” table retains all configured subjects with independent columns and clocks. Country credit, above-50-day constituent breadth and annual current account require their own qualified data. They may legitimately be unavailable. Do not fill those empty columns with regional EM OAS, price above MA200, a few bellwethers or a different country. A country-level table can be useful precisely because it distinguishes known from unknown.

Below the glance tier, keep the existing EM stress thermometer, two-tier US transmission, connectedness, correlation, fragility, directed pressure, central-bank/credit research and forward-record entry points accessible. None of these is the same semantic object. A currently accepted calibrated Risk Radar retains its own evidence and eligibility in its existing detail; do not promote an unreviewed probability or copy it into a new composite.

The company-impact boundary is actionable research, not an empty disclaimer: show which revenue, costs, debt, hedge, effective-date or identity evidence is missing, and offer the existing permitted company-research destination. Without that owner, open a contextual explanation with Back. No claimed earnings effect follows merely from listing country, a weak exchange rate or a model arrow.

## 3. Exact source bindings and non-substitutions

| Existing input | Meaning / required action |
|---|---|
| Wave 1 precise return fields | Arithmetic only; same endpoints and price/currency basis |
| `risk_desk.em_stress` | Coincident EM aggregate; retain leg coverage and thresholds, not local country risk |
| `risk_desk.two_tier` | Existing reported US-transmission state plus origin, counted legs and gaps; separately validate whether its summary can be published |
| `risk_desk.spillover` | Garman–Klass/close-volatility VAR/GFEVD context, not proved causal transmission |
| `risk_desk.corr_tightening` | Current daily-return correlation method, distinct from International weekly-return matrix |
| `risk_desk.vulnerability.countries` | ISO3 structural rows; field-year/vintage/type may be missing, and projections must not be called observed facts |
| `CGL.pressure`, `CGL.matrix`, `CGL.data_sessions` | Directed model pressure, destination→source indexing, model version and actual per-market session |
| `risk_desk.two_tier.tier1.regional_oas` | Asia/LatAm/EMEA aggregates; not seven country credit cells |
| `risk_desk.two_tier.tier2.legs.sofr_iorb_corridor.value` | Percentage-point spread; multiply by 100 only when formatting as bp |

Source function ranges and immutable links are in `SOURCE_AUDIT_WAVE2.md`. `scripts/build_intl.py` already computes these packets. `contagion_links.snapshot()` can write current artifacts and gated ledgers; calling it from this view is a correctness defect even when the caller thinks the lane is “read-only”.

### State-publication gate

The current `two_tier_read` implementation maps any non-hot origin—including unknown or insufficient—to `quiet`; strained origin with no counted hot legs becomes `contained` even if all those legs are absent. The new page must not repeat those false-calm readings.

Keep the source result as evidence where permitted. Require the extension contract's declared origin/leg qualification and count consistency before publishing the state as a current assessment. If those receipts are absent, render “Transmission assessment unavailable” and still expose qualified individual readings. Do not invent a new state machine or repair this by arbitrarily changing the hot-count threshold. Shared-owner correction is separately reviewed; useful non-state research can ship meanwhile.

### Statistical geometry gate

`us_from_others` is already percentage-scaled in the source return object despite an outdated docstring. The outgoing per-source total sums recipient shares and can exceed 100; it is not an individual probability. Reject invalid values according to the exact measure geometry, not a universal 0–100 rule. Keep top-transmitter identity as the actual ETF proxy. Never use an ETF label as proof of a country's economic causation.

CGL's `matrix[dst][src]` direction is test-critical. Preserve the frozen structural version and explicitly disclose dynamic-unavailable/structural-only fallback. No bidirectional symmetrization, new graph, recalculated weights, shadow promotion or market-specific ranking is authorized.

## 4. Task graph and path ownership

### IM05-T1 — Pure risk projection and supported-summary validation
**Files:** create `lib/intl_workspace_risk.py`, `tests/test_intl_workspace_risk.py`, `tests/fixtures/intl_workspace/risk_cases.json`. Shared root integration is T4. Financial source modules remain read-only in this task.

**Consumes:** `build_risk_section` inputs from the extension contract. **Produces:** `sections.risk`, with separate currency, pressure-row, domain and exposure-boundary objects.

- [ ] Write red tests for origin unknown/insufficient with raw Quiet, missing Tier-2 with raw Contained, malformed hot flags/counts, denied origin, a fully qualified positive control and valid individual evidence beside an unavailable summary.
- [ ] Write field tests for legitimate zero, monthly-change mismatch, regional-versus-country OAS, absent membership denominator, yearly projection, mixed field years, wrong country identity, SOFR−IORB units, US incoming-share scale and outgoing share >100.
- [ ] Implement validation/projection only. Consume already admitted metrics; preserve existing financial method and state. Do not calculate weights, model outcomes or fallback country values.
- [ ] Prove no imports/calls to `snapshot`, `compute`, a collector, store writer or ledger. Verify raw denied values and derived labels do not leak through JSON, tooltips, hidden DOM or exports.
- [ ] Run tests and commit the focused leaf; return source-field and abstention mappings.

### IM05-T2 — Currency explanation and multi-clock pressure table
**Files:** create `templates/intl_workspace/risk.html.j2`, `tests/test_intl_workspace_risk_render.py`; deliver scoped CSS/controller patch to one integration writer.

**Consumes:** admitted `sections.risk` and existing evidence/return callbacks. **Produces:** desktop GH and mobile 2P9/2RO/2U3 reading flow, with live values bound by source field reference.

- [ ] Write render tests requiring local/raw-FX/USD/contribution distinction, exact units, separate each-column windows, honest missing values and evidence actions.
- [ ] Implement a semantic desktop table and selected-subject mobile sequence; use one active accessible representation. Never redraw the sample negative returns as current data.
- [ ] Bind selecting a subject/lens to existing Context. Unsupported lenses remain unavailable with an explanation; they must not select another basis silently.
- [ ] Use qualified deterministic copy. With local gain and FX drag, do not keep the sample heading “The index fell”; with unknown input, withhold the unsupported clause.
- [ ] Test hostile source text, long ZH labels, 320px stacking, retained selection after re-render and noninteractive absent fields. Return exact design mapping and source fixture.

### IM05-T3 — Retained deep research and evidence boundaries
**Files:** focused additions to the proposed shared `templates/intl_workspace/legacy_research.html.j2` under its existing writer; create `tests/test_intl_workspace_risk_depth.py`, `tests/intl_workspace_risk_dom.test.cjs`.

**Consumes:** already composed domain panels, existing destinations and the IM03 evidence controller. **Produces:** working named deep entries, not replacement cards or another engine.

- [ ] Write tests requiring reachable EM stress, US transmission, connectedness, correlation, fragility and directed-pressure detail, each with the correct scope/method/date/units.
- [ ] Use stable route-local target keys from the common destination registry. Any missing installed destination opens a contextual capability explanation; no fake HTTP URL or `href="#"` placeholder.
- [ ] Bind exact CGL direction and source identity in detail. Preserve source model version, dynamic coverage, per-market tape date and genuine nulls.
- [ ] Add DOM tests for evidence open/close, nested Back/Escape and exact return; opening any detail must not call a provider, write state or append history.
- [ ] Verify positive and negative paths against actual partial/controller code, then return the patch to the single integration writer.

### IM05-T4 — Integration, hostile-case review and release
**Owner:** incumbent International integration lead and independent reviewer. **Files:** one shared mount/root, existing asset pipeline and existing CI declarations; no competing ownership.

- [ ] Integrate accepted T1–T3 with IM00/IM03. Wire `risk_desk` and `CGL` from existing build variables, not freshly executed engines or ad hoc disk loads in templates.
- [ ] Run actual root→Jinja→page-writer tests for fully populated, partial, denied and missing families, plus stocks-mode preservation. Validate old research remains reachable and old/new scripts cannot race.
- [ ] Enroll the new leaf and integration cases under the existing `ird-substrate-engines` / applicable page owner; preserve CI-pack semantics and current path/import closure. No new job for each page.
- [ ] Independent review must challenge false-calm states, identity substitutions, numeric units, matrix direction, secret exposure and side effects—not merely approve screenshot similarity.
- [ ] After legitimate browser admission, run the full device/theme/locale/state journey and publication proof. The previously observed browser administrator denial is not waived by unit tests, another host or this handoff.

## 5. Required proof and commands

Required source tests to implement/run:
```sh
python -m pytest tests/test_intl_workspace_risk.py tests/test_intl_workspace_risk_render.py tests/test_intl_workspace_risk_depth.py -q
python -m pytest tests/test_intl_risk.py tests/test_contagion.py tests/test_contagion_links.py tests/test_ird_velocity.py tests/test_ird_wiring.py tests/test_intl_build.py -q
node --test tests/intl_workspace_risk_dom.test.cjs
```
Do not claim these passed from this planning bundle. The supplied contract-oracle tests validate specification examples only, not these future production modules.

Actual release evidence includes deployed exact SHA/source generation, selected market, precise arithmetic, partial/denied source behavior, qualified/unqualified contagion summary, matrix direction, functioning legacy destinations and exact keyboard/scroll return. Browser matrix: 1440/768/390/320, dark/light, EN/ZH, 200% text, reduced motion. A full-height static capture is insufficient for interactions or entitlements.

## 6. What remains separately held

Country credit feeds, point-in-time constituent breadth, current-account observation/vintage annotations, first-known event history and economic issuer exposures are not invented by this build. Their unavailable states are part of the complete interface. Completing those data capabilities requires their existing owners and separate evidence, not another UI worker guessing fields.

No Follow, Saved write, trade, allocation, risk grant, prospective calibration, new graph or weight change. Existing authoritative Risk Radar data remains in its original permitted detail, not relabeled as this page's crisis probability. Rollback restores only the UI root/partial/assets through the normal release owner, never historical ledgers or risk policy.

### Positive-path completion guard

An all-null placeholder is not acceptance. Source tests must execute the actual positive and negative implementation paths; product release must demonstrate a useful real source-backed journey (and the real manual calculator for IM06), retained legacy depth, and genuine source-specific abstention. Missing advanced sources stay explicit unfinished data obligations; they do not license silently shrinking the promised core capability.
