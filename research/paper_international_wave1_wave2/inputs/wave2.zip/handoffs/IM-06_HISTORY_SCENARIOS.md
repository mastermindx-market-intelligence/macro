# IM-06 — History & Scenarios implementation handoff

**Goal:** inspect honestly labeled historical reconstructions and evaluate manual currency assumptions without confusing either with original-known evidence or forecasts. **Status:** BUILD_SPECIFIED for recomputed history + manual scenario UI; original-known replay, unqualified revisions/rank history and production release remain held.

**Architecture:** one typed read receipt over the existing country-history reader, a pure History helper under Wave 1's root, and a bounded manual arithmetic component in the existing browser route. No new event store, history writer, trading authority, forecast model or saved-state service. **Spec:** `contracts/HISTORY_SCENARIO_EXTENSION.md`. **Stack:** existing Python/Jinja/CSS/JavaScript; no new application framework.

## 1. Frozen design and source references

[Paper History & Scenarios](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG/p-4-0).

| Purpose | Exact node | Observed evidence |
|---|---|---|
| Desktop combined view | `L9-0` | Native full screenshot + exact JSX |
| Mobile History 390 | `2XD-0` | Native full screenshot + exact JSX |
| Mobile Scenario 390 | `2Z7-0` | Native full screenshot + exact JSX |
| Scenario 320 | `31D-0` | Native full screenshot + exact JSX |
| Scenario 320 / 200% text | `33J-0` | Full native composition and exact JSX; screenshot downscaled by tool |
| History/scenario/library contract | `3PB-0` on [specification page](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG/p-1-0) | All 19 text nodes read |
| Scenario invalid/context/reset states | `3U4-0` on specification page | All 54 text nodes read |

Five target JSX snapshots were identical before/after screenshot capture. Native archive and verified hashes: `evidence/HISTORY_NATIVE_DESIGN_PACK.json`. This is illustrative design evidence, not working native prototype wiring, browser functionality or market data. Historical held Paper operations mentioned in the specifications are not retried or cleared by this read-only census.

Audited source: Macro `ef1f7db98cff38b2a2b2d50e221da61c99e97611`. Relevant seams:
- `engine/intl_run.py:40–74,76–98`: classifier record; `c_` component columns removed; current history parquet rewritten.
- `engine/international_macro_dashboard.py:1089–1118`: `_spark` is a current descriptive composite over the last 60 rows, not a return chart or ranking ledger.
- `engine/international_macro_dashboard.py:1392–1400`: `load_history` collapses missing path and read failure to None.
- `engine/intl_market_state.py:544–614`: source-created state/MA/MACD events are dated recalculations, not first-known publication receipts.
- `scripts/build_intl.py:804–842` (event assembly; verify exact boundaries at START): global newest ten events are a compact view, not the complete selected-market timeline.
- `engine/risk_radar_intl_audit.py:308–424`: scorecard defaults to a governance-writing mode; use existing supplied result or explicitly read-only incumbent path.

No matching existing static scenario UI strings were found in the bounded current `lib/templates/tests` search. This is evidence for a missing exact page implementation, not proof no financial arithmetic helper exists elsewhere. Reuse an equivalent incumbent helper through a simple interface mapping when present; do not reopen a broad census.

## 2. Build-ready scope and retained features

Desktop separates “what happened” from “what was knowable then”, with recomputed-history selected and unavailable as-known replay clearly explained. The timeline uses genuine owner events or dated series; no sample Japan #4→#1 story unless an exact qualified historical rank owner supplies it. A genuine revision must bind two source versions. Keep the original saved research untouched; this page does not implement revision persistence.

Mobile History shows selected market, the same mode distinction, owner-backed event/series entries, full-history detail and a useful risk-track-record destination. Mobile Scenario is the same route's subview, not a second page/controller with a separate state store. It retains drafts through tab switches. Its “market rises / currency weakens” wording is conditional on entered signs, not copied unconditionally from the sample.

Manual inputs begin blank. Users can enter assumed local and currency returns, see the compounded USD result plus FX contribution, compare three explicitly illustrative currency assumptions, inspect the formula, and reset with review. Invalid edits clear stale results; changing horizon or market requires review rather than reinterpretation. This part works without live price feeds because it does not claim to be an observed return.

Retain source history tables, current regime components when present, source-owned events, precise return-basis evidence, existing country research and the qualified warning track record. A missing replay or revision system must not remove the useful manual calculator or available recomputed history.

## 3. Detailed implementation tasks

### IM06-T1 — Distinguishable read receipt and pure history projection
**Files:** modify `engine/international_macro_dashboard.py` only at the existing history read seam; create `lib/intl_workspace_history.py`, `tests/test_intl_history_read_receipt.py`, `tests/test_intl_workspace_history.py`, `tests/fixtures/intl_workspace/history_cases.json`.

**Consumes:** actual existing history parquet shape, selected canonical market, source events/track-record input supplied by the current root. **Produces:** `load_history_result` and `build_history_section` shapes in the extension contract. The existing `load_history()` remains compatible.

- [ ] Write red tests differentiating missing file, failed read, empty valid file, invalid date/column geometry, unsupported country, valid history and denied content.
- [ ] Add the typed result in the existing reader and preserve one read per call. The wrapper returns its original frame/None shape. No new path/store or source writer.
- [ ] Project only actual source points/events. Mark all current-history rows/events recomputed; preserve gaps and selected-market identity. Use each market's attached events rather than interpreting absence from the global top ten as no history.
- [ ] Test that rank arrows, original-known replay and revision events remain unavailable without exact owner evidence. Block incompatible date comparisons without deleting separately valid observations.
- [ ] Verify the pure leaf never invokes a reader/engine/ledger/grant function; run existing country-dashboard/dossier regressions and the new tests; commit scoped files.

### IM06-T2 — Manual calculation and locale parsing
**Files:** create `templates/intl_workspace_scenario.js`, `tests/intl_workspace_scenario_math.test.cjs`. The shared controller's module import/asset loading is reserved for T5's integration writer.

**Consumes:** raw user strings and confirmed same-horizon percentage assumptions. **Produces:** `parsePercent`, `calculateScenario`, `sensitivityCases` exactly as the extension contract specifies; no side effects.

- [ ] Write red tests for blank, lone sign/dot, malformed grouping, Unicode minus, fullwidth ZH digits/percent, optional percent sign, exponent rejection, overflow, true zero and unknown locale.
- [ ] Write arithmetic controls: +5/−3 gives +1.85 USD and −3.15pp; −1.8/−0.8 gives −2.5856 and −0.7856pp; local −100 valid, FX −100 invalid; inverse quote is reciprocal not sign flip.
- [ ] Implement pure parsing/calculation with raw input retained by the controller. Preserve both raw FX and contribution meanings. Do not call the financial engine or load a provider.
- [ ] Prove the current/0/+3 sensitivity rows use the entered local return, deduplicate exact equal assumptions and are entirely withheld after invalid input. Compare finite outputs against reference arithmetic with a suitable floating-point tolerance, not display-rounded equality.
- [ ] Commit the pure helper and tests; deliver the exact import/test interface to the integration lead.

### IM06-T3 — One draft/context reducer
**Files:** scoped patch to `templates/intl_workspace.js` for the existing writer; create `tests/intl_workspace_scenario_state.test.cjs`. No new persistent state module or account store.

**Consumes:** the existing route context, T2 functions and current evidence/overlay callbacks. **Produces:** raw draft, parsed validity, committed context, pending candidate context, result and named actions within that controller.

- [ ] Write red state-transition tests for blank initial state, valid edit, invalid-after-valid clearing, tab round trip, source refresh preserving manual draft, context proposal/confirm/cancel and reset confirm/cancel.
- [ ] Stage horizon/market/quote changes without changing the old committed context. Withhold proposed-context results; Confirm atomically adopts reviewed inputs and context; Cancel restores exact prior values.
- [ ] Keep raw `-`, decimal and fullwidth text during editing. Do not format away input or turn blank into zero. Source reload does not overwrite assumptions.
- [ ] Verify no localStorage/account/network/alert/history side effect. A normal reload starts blank; internal tabs retain the in-memory draft. Validate Back/Escape behavior and first-invalid focus ports.
- [ ] Return a bounded patch to the one active controller writer, not a replacement file that discards Wave 1/IM04/IM05 behavior.

### IM06-T4 — History and scenario presentation
**Files:** create `templates/intl_workspace/history.html.j2`, `templates/intl_workspace/scenario.html.j2`, `tests/test_intl_workspace_history_render.py`; deliver scoped CSS patch for existing writer.

**Consumes:** `sections.history`, the one scenario draft model and evidence actions. **Produces:** desktop combined layout and mobile subviews with progressive detail.

- [ ] Write render tests for “recomputed” versus “as-known unavailable”, distinct empty/failed histories, no unsourced rank/revision story, formula/units, exact field labels and error associations.
- [ ] Implement L9 desktop plus 2XD/2Z7 mobile, then 31D/33J reflow. Use intrinsic heights, stack controls at 320/200% text, retain signs and units, and omit the drawn OS status bar.
- [ ] Hide every result/sensitivity region while input is invalid or context pending. Announce only a committed valid result once; focus errors through real label/described-by bindings.
- [ ] Make history, track-record, source and formula destinations real existing actions or honest contextual capability explanations with Back. No dead `#` links.
- [ ] Run the actual Jinja fixture tests and return source-node mapping plus all state fixtures.

### IM06-T5 — Integration, independent review and browser proof
**Owner:** the incumbent International integration lead; never a second shared-file writer.

- [ ] Integrate T1–T4 under the same `sections.history` root and controller; add the scenario asset to existing copy/hash/normalization pipeline, preserving module semantics without introducing a bundler/app.
- [ ] Reuse already supplied track-record data. Do not call `scorecard()` in its default writing mode and never call `snapshot_and_grade`. Verify filesystem/ledger writers are trapped in view/controller integration tests.
- [ ] Exercise actual root→templates→page writer for current/recomputed, missing, failed, denied and no-JavaScript states, with stock mode and existing routes intact.
- [ ] Enroll tests in the current applicable CI pack/IRD/page owner, verify exact-head checks and obtain author-distinct review of history claims, parsing, context transitions and side effects.
- [ ] After legitimate browser admission, prove actual typing, invalid recovery, context confirm/cancel, reset, tab retention, Back/Escape/focus and source evidence at 1440/768/390/320, EN/ZH, dark/light, 200% text/zoom and reduced motion. Static native screenshots do not close this gate.

## 4. Acceptance commands and review focus

Proposed commands after implementation:
```sh
python -m pytest tests/test_intl_history_read_receipt.py tests/test_intl_workspace_history.py tests/test_intl_workspace_history_render.py -q
python -m pytest tests/test_international_macro_dashboards.py tests/test_international_macro_dossier.py tests/test_international_macro_dossier_page.py tests/test_intl_market_state.py tests/test_ird_wiring.py -q
node --test tests/intl_workspace_scenario_math.test.cjs tests/intl_workspace_scenario_state.test.cjs
```
These have not been run against product code in this research turn. Included contract-oracle tests are specification evidence only.

Five mandatory review classes: revised historical inputs must not counterfeit earlier knowledge; read failure must not counterfeit empty history; raw input must not disappear or become zero; a changed horizon/currency must not reuse unreviewed assumptions; no navigation must trigger a grant/ledger/save/monitor effect. Tests above pin all five; real browser behavior remains separately owed.

## 5. Release and rollback

The complete bounded UI can ship with as-known replay, unavailable rank revisions and absent source vintages explicitly unavailable. That is not full realization of the wider historical-data ambition. Release needs independently reviewed exact source, normal build/asset proof, genuine browser/rights evidence and the served publication identity.

Rollback removes/reverts only the new route partial/controller import/assets via the existing release owner. Never reverse a UI release by modifying historical parquets, graded logs, source revisions or saved research. No local/private result from this task becomes a historical trading signal.

### Positive-path completion guard

An all-null placeholder is not acceptance. Source tests must execute the actual positive and negative implementation paths; product release must demonstrate a useful real source-backed journey (and the real manual calculator for IM06), retained legacy depth, and genuine source-specific abstention. Missing advanced sources stay explicit unfinished data obligations; they do not license silently shrinking the promised core capability.
