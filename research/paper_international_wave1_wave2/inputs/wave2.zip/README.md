# Mastermind Paper → implementation handoffs — Wave 2

**Three additional page handoffs: Macro & Policy, Risk & Transmission, and History & Scenarios.** These extend the first package without changing its bytes or displacing its workers. Thirteen new bounded tasks, two precise extension contracts, source-bound gap analysis and thirteen native reference pairs reduce the receiving orchestrator's research burden.

## Start here

1. Read `orchestration/ASTRA_WAVE2_ADDENDUM.md` for assignment/dependency/path ownership.
2. Read the relevant page handoff and its extension contract. The unchanged shared Wave 1 contract/foundation/inspector/preservation map are included under `inputs/wave1` with byte hashes; they are reference copies, not a second owner or replacement publication.
3. Give each worker only its task, contract excerpt, source pin, accepted fixture and native reference subset. Run source, integration, independent review and browser/release gates separately.

| Packet | Build outcome | Native design |
|---|---|---|
| [IM-04 Macro & Policy](handoffs/IM-04_MACRO_POLICY.md) | Qualified economic/policy/market reading; retained rates and macro depth | [Paper p-3-0](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG/p-3-0), B4 / 2HL / 2K5 / 2MP |
| [IM-05 Risk & Transmission](handoffs/IM-05_RISK_TRANSMISSION.md) | Currency arithmetic plus separately qualified stress/statistical/structural research | Same Paper page, GH / 2P9 / 2RO / 2U3 |
| [IM-06 History & Scenarios](handoffs/IM-06_HISTORY_SCENARIOS.md) | Honest recomputed history and manual conditional FX calculation | [Paper p-4-0](https://app.paper.design/file/01M3P1TW5Y3XWQC37ADDS8K5AG/p-4-0), L9 / 2XD / 2Z7 / 31D / 33J |

See the handoffs and CSVs for full exact node IDs including `-0` suffix. Paper page links above use observed file/page path syntax. Old copied Wave 1 query-style links are preserved as historical input; use the observed paths supplied by these handoffs for current navigation.

## Verification achieved in this research turn

- All eight Macro/Risk and five History/Scenario native screenshots were visually inspected. Exact JSX was captured with equal before/after target digests. Four source-specification JSX captures accompany the native packs.
- Both native archives were opened, ZIP-tested and every payload hash verified on M2; they contain no fonts. Their checksums and locations are in `evidence/NATIVE_DESIGN_PACK.json` and `evidence/HISTORY_NATIVE_DESIGN_PACK.json`.
- 75 executable contract-oracle tests passed. These prove specified arithmetic, parsing, qualification and draft examples—not production implementation.
- Packet/lineage checks and final archive integrity results are recorded in `verification/VALIDATION_REPORT.md`.

**The planning ZIP does not contain the native images/JSX.** They are in the two verified M2 archives. They must be delivered to non-M2 workers through the existing admitted artifact transport. We have not proven that delivery or granted worker access to Paper.

## Source and acceptance limits

Macro research pin: `ef1f7db98cff38b2a2b2d50e221da61c99e97611`.
Protected Mastermind pin: `d8c302b8a8a65ab13e2afba98cc73481606ed4d0`.
Parent Wave 1 SHA256: `81d04f9e10e3502532859d32557d7a91a240b2fdcfe2b294b1f30d2014a788b6`.

No product/Paper mutation, worker dispatch, runtime lease transfer, monitor or deployment was performed. This is a researched implementation specification, not a source-merged feature. GitHub/Agent OS publication is not claimed. Source inspection is not a current-data exercise; rejected read/export batches were not retried. The inherited live-browser administrator restriction remains respected.

Implementation-ready means the scoped code/interfaces/tasks and safe behavior are specified. It does not mean every new data capability exists. Missing country credit, first-known vintages, constituent breadth or company exposure remains an explicit owner dependency. Do not declare the programme complete by rendering all-null placeholders: release must demonstrate real useful positive paths and honest negative paths against their actual source owners.

The next research frontier is Library/Search/Saved, documented in `census/LIBRARY_PREFLIGHT.md` and `CONTINUATION.md`. This package does not mark that larger family ready or repeat the completed whole-file directory census.
