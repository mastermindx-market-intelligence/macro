# Astra — add Wave 2 without restarting Wave 1

This is an additive research/build packet under the Chairman's existing Paper-upgrade commission. The Chairman said the first packet will be handed off; actual receiver pickup, runtime START, accepted scope and source custody are not observed here. Reconcile the incumbent before changing it.

Read README, SOURCE_AUDIT_WAVE2, contracts/MACRO_RISK_EXTENSION, the two page handoffs and the native design receipt. Do not resend the 1,589-board directory census to every worker. Do not repeat Wave 1's numerical source investigation. Keep its ZIP bytes unchanged.

## Routing and management budget

Astra Meta-CEO retains programme priority, cross-domain exceptions and final acceptance. One Sol International CEO owns current contract resolution and integration. A capable Grok/GLM/Cursor project lead handles each genuinely separable page; a single lead may own both when that reduces overhead. Tightly bounded GLM Flash/Minimax M3 workers implement leaves and tests. These are the user's role/model preferences, not verified API aliases, capacity, depth grants or account placement.

**WHY NOT FABLE:** these source-grounded read-only page builds have bounded contracts and deterministic acceptance; no new principal ambiguity requires scarce Fable capacity. Native cheap workers still need explicit accepted grants, provider availability, workspace custody and review budget. No direct provider spawning or nested worker permission is invented by the hierarchy. Collapse management levels for a small task; never add a Sol solely to relay messages.

## Dependency order

IM00 contract/root/controller and IM03 evidence semantics are shared dependencies. IM04-T1 current metadata can be handled by the existing data lead. IM04-T2 and IM05-T1 can proceed on disjoint leaf files after the extension contract is frozen. Their UI tasks follow accepted fixtures. IM05-T3 touches the shared retained-depth partial and therefore belongs to the single integration writer or a specifically partitioned owned section.

IM04-T4 and IM05-T4 are **two acceptance scopes, not two concurrent writers**. The same integration owner consumes them serially into the incumbent carrier and obtains independent exact-head review. The source/CI manifest, parent template, root view and controller are not free-for-all worker surfaces. No model-specific duplicate controller or device-specific engine.

## What Astra should not do

Do not copy illustrative rates, risk states or calendar dates. Do not decide new financial thresholds in response to the source defects. Do not turn the source-derived abstention rules into another policy plane. Do not require a second human approval for ordinary reversible task execution already commissioned, but preserve real source, budget, account, deployment and browser gates.

Do not launch Active Follow, Saved writes, first-known replay or new country feeds merely because a design shows success. Keep negative states genuinely usable, not disabled dummy pages. Preserve existing independent review and release owners.

## Worker inputs and return

Each worker receives its exact task/paths, the relevant contract excerpt, source pin, assigned native JSX/screenshot subset and accepted fixture. Numerical workers do not need the whole design file. The eight-board archive is on M2 with checksum in `evidence/NATIVE_DESIGN_PACK.json`; existing admitted artifact transport must deliver it to remote workers. Its presence on M2 is not proof a Mini, Grok or GLM harness can read it.

Return base/head, exact changed paths, producer/consumer signature, red/green evidence, no-I/O and rights results, visual reference mapping, browser acceptance status and unresolved decisions. A delivery is not START; an ACK is not acceptance; green CI is not deployment. Do not request another Astra turn for each CSS fix or test cycle.

## Stop and escalation

The lead repairs inside the accepted task envelope. Architectural/custody/financial-method conflicts return to Sol. Astra receives only programme-level exceptions or acceptance recommendations. Actual provider denial, human authentication and uncertain effects retain their fences; another model/host is not a workaround. Browser review remains held until genuine admission changes, never merely because another harness exists.

## Same-turn next phase — IM06 added

IM06 History & Scenarios adds five bounded tasks and `contracts/HISTORY_SCENARIO_EXTENSION.md`. Use the same International Sol/integration owner. T1 (existing history-reader receipt/pure projection) and T2 (pure manual arithmetic) can run independently on disjoint paths; T3 joins the existing controller only through its writer. T4 visual leaves follow fixed fixtures; T5 integrates/reviews. No new history, forecast, saved-state or alert owner is authorized. The five-board history native archive is a separate assigned worker-input subset.
