# Wave 2 source audit — build-relevant findings

Research source: Macro `ef1f7db98cff38b2a2b2d50e221da61c99e97611`. Current procedure: Mastermind `d8c302b8a8a65ab13e2afba98cc73481606ed4d0`.

The principal International builder, template, inputs, performance, rates, bonds, central-bank and contagion source paths were unchanged between Wave 1's `d0f14c62544daca98258cbf68a5e1e3bef54ab74` and this audit pin. This is a bounded source comparison, not a complete repository, runtime or deployment census. Working checkout HEAD was not used as source truth.

**Evidence class:** source inspection and native design review. No current live-data, authenticated-site or production-behavior conclusion follows. Two particular Studio read/export batches were explicitly refused; they were not replayed. The denied source-copy batch was not recreated. The separate rejected committed-data extraction was not retried; this packet does not contain or claim that current-data exercise.

## W2-01 — Observation count is not trading-session count

Observed in [`engine/ird_velocity.py:33–121`](https://github.com/mastermindx-market-intelligence/macro/blob/ef1f7db98cff38b2a2b2d50e221da61c99e97611/engine/ird_velocity.py#L33-L121): vel_20d_bp uses last minus 21st-from-last nonnull observation; window_days is normalization sample count.

**Build decision:** Withhold a 20-session label without cadence/endpoints; show honest observed interval only when supplied. **Boundary:** Existing velocity/input metadata owner; IM04-T2/IM05-T1.

## W2-02 — Official rates, effective rates and proxies differ

Observed in [`engine/cb_desk.py:48–160`](https://github.com/mastermindx-market-intelligence/macro/blob/ef1f7db98cff38b2a2b2d50e221da61c99e97611/engine/cb_desk.py#L48-L160): DFF effective rate; ECB deposit facility; several monthly interbank proxies.

**Build decision:** Exact instrument label; proxy separate from official-policy cell; no decision-event inference. **Boundary:** CB desk + IM04-T2.

## W2-03 — Policy-trend threshold and monthly interval discrepancy

Observed in [`engine/cb_desk.py:226–251`](https://github.com/mastermindx-market-intelligence/macro/blob/ef1f7db98cff38b2a2b2d50e221da61c99e97611/engine/cb_desk.py#L226-L251): 0.10/100 in percentage units is 0.1bp although comment says 10bps; last versus -3 spans two intervals.

**Build decision:** Do not publish stronger hiking/easing interpretation; leave financial repair with existing owner. **Boundary:** CB owner; separate scoped repair.

## W2-04 — BoJ monthly balance-sheet changes named weeks

Observed in [`engine/cb_desk.py:254–294`](https://github.com/mastermindx-market-intelligence/macro/blob/ef1f7db98cff38b2a2b2d50e221da61c99e97611/engine/cb_desk.py#L254-L294): _imp(13/52) counts observations; short history is truncated but output name retains full horizon.

**Build decision:** Actual source interval/cadence required; preserve units; no false 13/52-week claim. **Boundary:** CB owner; IM04-T2.

## W2-05 — Curve basis and rates differ across owners

Observed in [`engine/intl_rates.py:67–125`](https://github.com/mastermindx-market-intelligence/macro/blob/ef1f7db98cff38b2a2b2d50e221da61c99e97611/engine/intl_rates.py#L67-L125): US anchor 2s10s versus core-country 10y-3m; carry is pp and dates may differ.

**Build decision:** Expose leg identity and dates; do not claim common-date hedge/carry return. **Boundary:** Rates owner; IM04-T2.

## W2-06 — Inversion board omits basis and counts observations as days

Observed in [`engine/intl_bonds.py:361–439`](https://github.com/mastermindx-market-intelligence/macro/blob/ef1f7db98cff38b2a2b2d50e221da61c99e97611/engine/intl_bonds.py#L361-L439): Rows omit slope_basis and leg dates; since_days counts rows on 2y branch; n_total=0 yields false synchronized.

**Build decision:** Unknown basis/duration unavailable; zero coverage not no inversion. **Boundary:** Bond metadata owner; IM04/05 detail.

## W2-07 — Reported quadrant is a mixed proxy composite

Observed in [`engine/intl_regime.py:24–94`](https://github.com/mastermindx-market-intelligence/macro/blob/ef1f7db98cff38b2a2b2d50e221da61c99e97611/engine/intl_regime.py#L24-L94): Growth includes index/copper-gold; inflation includes oil/yield; renormalizes over available inputs.

**Build decision:** Retain source composite, withhold unsupported current economic headline; no new quadrant engine. **Boundary:** IM04-T1/T2.

## W2-08 — Current components are discarded from retained history

Observed in [`engine/intl_run.py:40–74`](https://github.com/mastermindx-market-intelligence/macro/blob/ef1f7db98cff38b2a2b2d50e221da61c99e97611/engine/intl_run.py#L40-L74): country_record uses classifier then drops c_ columns for history.

**Build decision:** Expose current components once; no invented historical contribution/vintage series. **Boundary:** IM04-T1; IM06 boundary.

## W2-09 — Unknown origin can become Quiet

Observed in [`engine/contagion.py:741–774`](https://github.com/mastermindx-market-intelligence/macro/blob/ef1f7db98cff38b2a2b2d50e221da61c99e97611/engine/contagion.py#L741-L774): not tier1_hot includes unknown/insufficient_data; zero Tier2 hot can mean no available legs.

**Build decision:** Withhold unsupported Quiet/Contained copy while retaining valid individual evidence. **Boundary:** IM05-T1; source-state owner separately.

## W2-10 — Regional credit is not country credit

Observed in [`engine/contagion.py:603–637`](https://github.com/mastermindx-market-intelligence/macro/blob/ef1f7db98cff38b2a2b2d50e221da61c99e97611/engine/contagion.py#L603-L637): Asia/LatAm/EMEA OAS packets provide value and velocity z, not seven country bp changes.

**Build decision:** Never fill country credit cell from regional OAS or z-score. **Boundary:** IM05-T1.

## W2-11 — Slow structural row may contain projected year and mixed periods

Observed in [`engine/intl_risk.py:632–699`](https://github.com/mastermindx-market-intelligence/macro/blob/ef1f7db98cff38b2a2b2d50e221da61c99e97611/engine/intl_risk.py#L632-L699): _latest falls back to projection; asof_year is maximum over debt/fiscal/current account.

**Build decision:** Field-specific period/vintage/type; no inferred observed actual; no wrong-country fallback. **Boundary:** Structural owner; IM05-T1.

## W2-12 — EM stress is coincident aggregate

Observed in [`engine/intl_risk.py:486–569`](https://github.com/mastermindx-market-intelligence/macro/blob/ef1f7db98cff38b2a2b2d50e221da61c99e97611/engine/intl_risk.py#L486-L569): Six-leg aggregate with insufficient_data state and newest-leg as_of.

**Build decision:** Preserve aggregate/leg scope; not local-country signal or forecast odds. **Boundary:** IM05-T1/T3.

## W2-13 — Incoming share already percent; outgoing can exceed 100

Observed in [`engine/contagion.py:379–437`](https://github.com/mastermindx-market-intelligence/macro/blob/ef1f7db98cff38b2a2b2d50e221da61c99e97611/engine/contagion.py#L379-L437): from_dict/to_dict multiply by100; us_from_others comes from from_dict; column sum is multi-recipient.

**Build decision:** No second ×100 and no probability clamp on outgoing sum. **Boundary:** IM05-T1/T3.

## W2-14 — Connectedness is volatility model, not causal return flow

Observed in [`engine/contagion.py:268–339`](https://github.com/mastermindx-market-intelligence/macro/blob/ef1f7db98cff38b2a2b2d50e221da61c99e97611/engine/contagion.py#L268-L339): GK volatility inputs with close-return-volatility fallback.

**Build decision:** Disclose proxy/model/window; do not describe arrows as proved issuer causation. **Boundary:** IM05-T3.

## W2-15 — Daily and weekly correlations must remain distinct

Observed in [`engine/contagion.py:448–556`](https://github.com/mastermindx-market-intelligence/macro/blob/ef1f7db98cff38b2a2b2d50e221da61c99e97611/engine/contagion.py#L448-L556): corr_tightening implementation uses daily log returns despite weekly wording.

**Build decision:** Native method labels; retain separate intl_performance weekly-return method. **Boundary:** IM05-T1/T3.

## W2-16 — SOFR corridor units and counted-leg membership

Observed in [`engine/contagion.py:696–739`](https://github.com/mastermindx-market-intelligence/macro/blob/ef1f7db98cff38b2a2b2d50e221da61c99e97611/engine/contagion.py#L696-L739): SOFR-IORB value is pp; safety-bid hot is false/informational.

**Build decision:** -0.02pp=-2bp; do not count safety bid as fifth threshold leg. **Boundary:** IM05-T1.

## W2-17 — Directed model matrix orientation and persistence

Observed in [`engine/contagion_links.py:901–1015`](https://github.com/mastermindx-market-intelligence/macro/blob/ef1f7db98cff38b2a2b2d50e221da61c99e97611/engine/contagion_links.py#L901-L1015): Export matrix[dst][src]; data_sessions per market; snapshot can append gated logs.

**Build decision:** Read existing CGL only; no transpose, recompute, weight edit or browser-triggered ledger. **Boundary:** IM05-T1/T3.

## W2-18 — Builder already composes the domain packets

Observed in [`scripts/build_intl.py:594–613`](https://github.com/mastermindx-market-intelligence/macro/blob/ef1f7db98cff38b2a2b2d50e221da61c99e97611/scripts/build_intl.py#L594-L613): risk_desk includes CB, fragility, connectedness, two-tier and CGL compact summary.

**Build decision:** Reuse existing variables; no extra engine run in pure root/leaf or event handler. **Boundary:** Single integration writer.

## Existing delivery and CI ownership

`ird-substrate-engines` in `.github/ci/legacy-jobs.yml` is the current registered owner for IMF/CB calendar/plumbing/IRD/CB/contagion tests. It runs inside the existing CI pack; the legacy `if: false` is not a reason to invent another workflow. Its Python 3.12 dependency set includes pytest, pandas, numpy, pyyaml, pyarrow, requests, Jinja2 and Plotly. Add new leaf/integration test paths through the existing owner and verify current import/path closure. New DOM tests use the repository's admitted Node environment. Do not install a separate test service.

`PR #7872` was observed open Draft/HOLD on exact head `5d6ae511c7b82b05e175ba7ea36e2fc5003b6502`. It owns episode-aware Risk Radar audit/evidence paths and is not this redesign's authority or source custody. Current role/lease and changes must be checked before implementation, not assumed from a historical author or document.

## Preserved versus held capabilities

Preserve the existing rates/curves, actual instrument/proxy levels, liquidity context, peripheral spreads, country research, EM stress, individual transmission inputs, connectedness, separate correlation methods, fragility and directed pressure through accessible source-qualified detail. Do not delete useful numeric depth merely because its headline interpretation requires qualification.

Country credit feeds, full point-in-time constituent breadth, field-specific structural vintages, market-implied policy expectations, company economic exposures and first-known historical replay are different deliverables. An explicit unavailable state is an honest completed UI behavior, not a claim that the underlying data programme is finished.

## History continuation — additional source boundaries

- `engine/intl_run.py:76–98` writes recomputed current-history parquets. A dated row is not a past information set or immutable publication.
- [`international_macro_dashboard.py:1089–1118`](https://github.com/mastermindx-market-intelligence/macro/blob/ef1f7db98cff38b2a2b2d50e221da61c99e97611/engine/international_macro_dashboard.py#L1089-L1118) derives a current descriptive-score sparkline from 60 rows; it must not become a return/rank timeline.
- [`international_macro_dashboard.py:1392–1400`](https://github.com/mastermindx-market-intelligence/macro/blob/ef1f7db98cff38b2a2b2d50e221da61c99e97611/engine/international_macro_dashboard.py#L1392-L1400) returns None for both missing and read error. The bounded additive receipt must retain these distinctions.
- `engine/intl_market_state.py:544–614` creates dated state/MA/MACD event descriptions from its current computation. They do not prove first-known receipt dates. The global newest-ten list in the builder is not complete per-market history.
- [`risk_radar_intl_audit.py:308–424`](https://github.com/mastermindx-market-intelligence/macro/blob/ef1f7db98cff38b2a2b2d50e221da61c99e97611/engine/risk_radar_intl_audit.py#L308-L424) defaults scorecard to `log_governance=True`. Read-only rendering must reuse the existing supplied result or explicitly admitted read-only owner path. Its read-exception fallback to an empty graded set also requires separate read-health qualification.

The History/Scenario specification is a new bounded build decision, not a rewrite of Wave 1. Its five native reference pairs and two specification captures have a separate verified archive. No existing Paper held operation was replayed.
