# History / Scenario extension — one context, two distinct jobs

Proposed addition `sections.history` to Wave 1's internal `intl_workspace_view.v1`. This is not an installed API, new history store or forecast engine. It consumes existing history and source-owned events; local scenario arithmetic uses manual assumptions and does not update those records.

## History inputs and output

Proposed pure helper:
```python
# lib/intl_workspace_history.py
from typing import Mapping, Sequence

def build_history_section(
    *, context: Mapping[str, object], history_read: Mapping[str, object],
    turn_events: Sequence[Mapping[str, object]],
    track_record: Mapping[str, object] | None,
    capabilities: Mapping[str, object], destinations: Mapping[str, str]
) -> dict[str, object]: ...
```

The existing builder loads the selected/allowed source once and passes it in. The helper never imports a parquet reader, financial engine, grant evaluator or writer. `history_read` has `status=ready|empty|missing|failed|invalid|unsupported`, `market_id`, `artifact_ref`, `read_at`, `method_ref`, and `points`. `read_at` is an acquisition/generation clock, not historical first-known evidence. `points` contain actual dated source values, with null and qualification where required; the existing shared serializer applies access before client delivery.

Suggested additive seam in the **existing** `engine/international_macro_dashboard.py`:
```python
def load_history_result(cc: str) -> dict[str, object]: ...
```

Return `frame` (the existing DataFrame or null) plus the explicit read status and existing artifact identity/metadata when available. Validate the exact configured country key before constructing the existing path. Existing `load_history(cc)` delegates to this once and returns its old DataFrame/None shape, preserving callers. Missing path is `missing`; read/parse exception is `failed`; zero-row valid parquet is `empty`; invalid date/column geometry is `invalid`. Do not emit paths, stack traces or secret exception details to public JSON. A source reader is not a new archive or publication owner.

The UI defaults to **recomputed history**. The existing `intl_run.run()` rewrites `data/intl_regime/{cc}_history.parquet` from today's classifier and store. Those dated rows are not immutable past publications. The companion `_spark()` transforms up to 60 rows into a current descriptive composite; it is not a historical return or ranking series. Keep its original purpose separate.

Render source-owned transition/MA/MACD events as recomputed changes with event date, source reference and method scope. Prefer the selected market's already attached `record.turn.events`; the builder's global ten-event list is truncated and is not a complete market history. Do not invent earlier alerts or a #4→#1 rank change from the current rank. A year/month date does not become a precise observation instant.

Output:
```text
history
  mode: recomputed
  selected_market
  source_read_status, source_reference, method_ref
  points[] and gaps[]
  events[]: event_date, code, localized text, evidence_ref, history_kind=recomputed
  as_known: available=false, reason, destination|null
  snapshot_compare: eligible, reason, available_dates[]
  revisions: status, records[]  # no fabricated revision events
  track_record: source-qualified read-only display or unavailable
```

Two selected dates can be inspected from the same current artifact only when their market, unit, return basis, universe and method meanings are compatible. State explicitly that both are viewed through the current reconstruction. If method/identity/period comparability cannot be established, show the observations separately and withhold comparison. Never insert future values into a missing date or call revised history “what we knew then”.

`as_known.available` stays false until an existing owner supplies immutable original vintages, trustworthy first-known times, universe/formula versions and rights for the exact query. A Git commit date, market event date, latest-data date or a browser capture is not enough. This packet does not build that capability. A source-revision card requires actual linked prior/new versions; absence of a revision record is not evidence that no revision occurred.

## Forward-record consumption

Use an already supplied `record.risk_radar.forward_log` or a read-only result from the incumbent qualified track-record owner. Prefer reuse over another call. `risk_radar_intl_audit.scorecard()` defaults `log_governance=True`; never invoke that default from this view. `snapshot_and_grade`, grant/lapse appends and shadow accrual remain outside UI scope. A source read failure that yields zero graded rows must not be called a proven empty track record; independent read-health qualification is required.

Display only accepted field semantics: real graded count, alert count, sample dates, precision/hit-rate/lift distinctions, false alarms/drawdowns and qualification notes when available. No new success percentage, no borrowed calibrated status and no `can_force` computation. An existing grant is not a generic permission for this page to trade or forecast.

## Manual scenario input contract

Two raw strings belong to the existing route's in-memory draft: local-price return and currency return in USD per local unit. Both are percentages over the explicitly confirmed horizon. Initial strings are blank. Never auto-install the Paper +5%/−3% example or silently prefill current market data.

Proposed dependency-free helper module `templates/intl_workspace_scenario.js`, imported once by the existing route controller using its accepted module convention:
```text
parsePercent(raw, locale) → {status:blank|editing|invalid|valid, value:number|null, reason:string|null}
calculateScenario(localPercent, fxPercent) → {status:valid|invalid, usdPercent, fxContributionPp, reason}
sensitivityCases(localPercent, currentFxPercent) → [{kind, fxPercent, usdPercent}]
```

Parsing is intentionally explicit for the supported EN/ZH UI: normalize fullwidth digits/punctuation with NFKC and the Unicode minus to ASCII; preserve the original raw string separately. Accept optional leading sign, dot-decimal notation, optional final percent sign and correctly grouped comma thousands. Reject decimal commas such as `1,5`, exponent notation, accounting parentheses, double signs, internal words, trailing junk and non-finite values. Blank is blank; a lone sign/dot or sign+dot is editing, never zero. Maximum raw field length 128 characters is an input-resource limit, not a financial range. Reject unsupported locale formats with a visible decimal-format hint rather than guessing.

Require local return ≥ −100% and raw FX return > −100%. A local total loss with a valid currency returns −100% USD and zero FX contribution; the currency's endpoint cannot be nonpositive. No arbitrary upper investment threshold is invented. Reject non-finite input or arithmetic overflow, withholding **all** result/sensitivity output. Round only at display. Numerical tests compare to the supplied Decimal oracle with floating-point-aware tolerance for finite results.

Let `l=localPercent/100`, `f=fxPercent/100`:
```text
usdPercent = 100 * ((1+l)*(1+f)-1)
fxContributionPp = 100 * (1+l)*f
```

For +5% / −3%: USD +1.85%, FX contribution −3.15pp. A raw reverse-quote percentage must be reciprocally transformed, not sign-reversed. The first implementation exposes only the declared USD-per-local orientation; a quote-mode switch is not required. Its absence avoids silently reinterpreting a draft. The explanation still tests the inverse-quote boundary.

Sensitivity rows are deterministic illustrative assumptions: current FX input, 0%, +3%, in that order, deduplicated by numeric FX value while retaining the `current` label when equal. They are not an expected range, likelihood or optimizer output. With either invalid input or pending context, the result and all sensitivity rows are withheld. No-data/current-data failure cannot break a valid **manual** calculation; it simply prevents importing or claiming observed values.

## Draft and context behavior

Keep draft state inside the existing route controller; no new localStorage/database/account object. It survives internal History/Scenario tab switches. Reload starts blank unless an already admitted exact saved-draft owner exists; do not add persistence to simulate one.

When horizon, market or quote-currency changes with a nonempty draft, stage a **candidate context**. Preserve old raw inputs and old committed context untouched. Withhold a result under the proposed context. Confirm atomically commits the new context with reviewed valid inputs; Cancel restores the original draft/context/result. Never multiply or annualize returns. Source refresh cannot silently rewrite manual inputs.

Reset asks once, then clears only the two raw inputs and computed result. Market, horizon, basis, benchmark, history, saved records and monitors are unchanged. Cancel does nothing. An invalid input after a valid calculation clears the displayed result immediately so a stale success is not mistaken for the edited scenario.

Associate errors with their fields and focus the first invalid field on explicit Calculate/Confirm. Update results on valid committed input or Calculate; announce one polite result, not every keystroke. The script does no network, source refresh, saved write, monitor creation or source-history overwrite. One shared route controller owns focus/Back/Escape and exact return.
