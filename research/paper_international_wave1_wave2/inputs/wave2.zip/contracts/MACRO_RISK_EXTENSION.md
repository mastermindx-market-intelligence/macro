# International R10 — Macro / Risk extension contract

**A specification for implementation, not an installed API.** This extends Wave 1's `intl_workspace_view.v1` inside its one existing composition path. Do not create another endpoint, identity master, database, freshness policy, engine scheduler or controller. Wave 1 remains immutable. This document pins the new leaf interfaces and the distinctions its original generic contract deliberately left to later pages.

## 1. Shared envelope and execution boundaries

Use Wave 1's existing `Context`, `Metric`, `Evidence`, quality vocabulary and rights-first serializer unchanged. `view="macro"` and `view="risk"` were already reserved. New subobjects are `sections.macro` and `sections.risk`. They share the same selected market, benchmark, comparison pins, horizon, currency basis and source reference. A new page does not choose a new universe.

`lib/intl_workspace_view.py` remains the single pure presentation-composition owner. Delegate focused, dependency-free helpers to the two proposed files below; neither is independently published or called by the browser. Existing code with an equivalent accepted interface takes precedence, with a small documented signature mapping rather than a second implementation.

```python
# Proposed files, not existing APIs. JSON-compatible output; no I/O.
# Type aliases below denote existing rights-admitted Wave 1 records.
from typing import Mapping, Sequence
Row = Mapping[str, object]

def build_macro_section(
    *, context: Row, records: Sequence[Row], rates: Row | None,
    cb_desk: Row | None, measures: Mapping[str, Row],
    cycle_evidence: Mapping[str, Row], destinations: Mapping[str, str]
) -> dict[str, object]: ...  # lib/intl_workspace_macro.py

def build_risk_section(
    *, context: Row, markets: Sequence[Row], risk_desk: Row | None,
    cgl: Row | None, measures: Mapping[str, Row],
    summary_eligibility: Mapping[str, Row], destinations: Mapping[str, str]
) -> dict[str, object]: ...  # lib/intl_workspace_risk.py
```

`measures` keys are packet-local field references such as `JP.gdp_yoy`, `KR.credit_change`, `EZ.policy_rate`. Their values are the already admitted Wave 1 `Metric`; helpers do not admit raw provider data or invent a missing quality rule. Missing entries become a typed missing/unknown metric, never zero. `destinations` contains only registered internal actions or validated existing URLs. All dynamic copy goes through escaped template/text APIs.

`cycle_evidence` and `summary_eligibility` are derived annotations inside the existing composition, not stored authorities. They identify exactly which existing method/input receipt permits a new presentation claim. Unknown permission, source date or method support stays unknown. A numerical proxy may be qualified as a proxy while its stronger interpretation is withheld.

## 2. Macro section shape

```text
macro
  selected_market: same Context.selected_market
  coverage: configured_ids, classified_ids, unclassified[{market_id, reason}]
  cycle_rows[]:
    market_id
    reported_quad: Q1 | Q2 | Q3 | Q4 | null
    reported_method_ref: exact owner/version or null
    presentation_quality: Wave 1 quality
    supported_heading: localized deterministic copy or null
    components: growth[], inflation[]
    evidence_refs[]
  market_rows[]:
    market_id, gdp_yoy, cpi_yoy, policy_rate, policy_proxy,
    yield_10y, yield_change, field_evidence_refs
  selected_reads:
    economic_cycle, realized_policy, market_response  # separate blocks
  deep_research[]: key, title, destination | null, capability_reason | null
```

`gdp_yoy` and `cpi_yoy` are levels of year-on-year growth, not acceleration labels. The economic headline requires an existing method, the necessary qualified native component history and qualified local GDP/CPI evidence; a latest GDP/CPI level does not satisfy that condition. A mixed market/macro owner composite without this support remains readable as that composite in detail, not promoted to a current economic diagnosis. The presentation gate does not change its source score, hysteresis or historical data.

If the owner retains a quadrant through hysteresis while current component signs differ, show the retained source state and component disagreement explicitly. Do not derive a competing state by taking the sign of two numbers in JavaScript. The compact economic headline is withheld when its predicate does not hold.

The configuration order determines the table order, not the sample's ordering or its `1/7` count. Denominator is configured subjects; classified IDs require qualification. Filtering the table does not silently change the coverage headline's source universe. Selected EZ means the currency area, not an average of Germany or a default Bund record.

### Current-only component extension

`engine/intl_run.country_record()` has the full classifier row, but currently omits component evidence from the country record and strips `c_` columns from saved history. Preserve historical output. A bounded additive source task may expose `record.cycle_components`, constructed from the **already computed** classifier row and the owner's existing component definitions. Proposed helper in `engine/intl_regime.py`:

```python
def component_evidence_at(reg: pd.DataFrame, asof: pd.Timestamp) -> dict[str, object]: ...
```

Output contains `asof`, `growth` and `inflation` arrays of `{key, score, weight}`, plus each axis's emitted score and available-component count. Weights come from the existing `_GROWTH`/`_INFLATION` definitions; do not repeat them in a UI constant. Non-finite/missing component scores are null. This is current calculation evidence only: it does not produce source rights, observation/publication clocks or historical vintages. Wave 1 attaches those separately when genuinely available. Do not call `classify()` a second time or change the existing persisted history to make the new screen look complete.

## 3. Rate and time semantics

| Field | Accepted meaning | Disallowed substitution |
|---|---|---|
| `policy_rate` | Exact admitted official instrument, e.g. ECB deposit facility | Interbank proxy, effective Fed funds as FOMC target range, next-meeting prediction |
| `policy_proxy` | Explicitly named observed proxy with its own source/cadence | Claiming a proxy tick was a central-bank hike/cut decision |
| `yield_10y` | Exact sovereign/curve series and timestamp | ECB AAA curve called Germany Bund, or Bund called the full EZ economy |
| `yield_change` | Change over explicitly evidenced endpoints/cadence | Calling 20 monthly observations 20 sessions |
| `real_yield` | Exact source method and input dates | 10y minus historical CPI described as a TIPS yield or market-implied real yield |
| `carry_vs_us` | Unhedged nominal yield differential in pp | Hedged carry, forecast return or free arbitrage |
| `curve` | Explicit long/short legs and basis | Mixing 2s10s and 10y–3m without labeling |
| `bs_impulse` | Actual interval, bank, currency and unit | BoJ monthly row counts called 13/52 weeks or adding different currencies |

The existing velocity helper counts rows after `dropna()`. `vel_window_days` is the z-normalization sample count, not the change horizon. Until the source supplies calendar/cadence/endpoints, the new fixed `20-session` cell is unknown. A separately named `20-observation change` may be shown with its actual date interval when that interval is available. Never fill missing dates in the UI. This is metadata admission, not permission to replace the shared calculation.

ECB's central-bank source code `XM` may join to existing International `EZ` only through an explicit adapter map `ECB/XM → EZ/deposit_facility`. No generic two-letter transformation. `DE/ez_aaa_10y` is a distinct curve identity; keep it out of a country's nominal-yield field unless the existing owner explicitly defines and discloses that proxy.

The source's `_trend_3m` threshold and balance-sheet cadence defects are retained as findings. This page does not silently repair shared financial semantics. A dedicated existing-owner repair may later supply qualified readings; until then retain exact levels/source steps with honest labels, not the misleading stronger summary.

## 4. Risk section shape

```text
risk
  selected_market: same Context.selected_market
  currency_channel:
    local_return, fx_return_usd_per_local, usd_return, fx_contribution_pp
    endpoint_policy, input_evidence_refs, arithmetic_quality
  pressure_rows[]:
    market_id, currency_return, country_credit_change,
    constituent_breadth_50d, annual_current_account
  domain_panels:
    origin_stress, us_transmission, statistical_connectedness,
    return_correlation, directed_pressure, structural_fragility
  exposure_boundary:
    quality, message, destination | null, missing_evidence[]
  deep_research[]
```

Do not average these panels into one risk score. The selected subject does not transform a regional aggregate into country evidence. An Asia OAS is never Japan/Korea/Taiwan OAS. A broad EM ETF or USD equity index is not a country's constituent participation denominator. An annual surplus is not funding safety.

Pure arithmetic uses the already qualified unrounded Wave 1 return inputs. If the owner supplies only local/USD return, raw currency return may be derived as `(1+usd)/(1+local)-1` only when endpoints and all basis definitions match and `1+local > 0`. Prefer direct owner raw FX data. Do not derive it from display-rounded values. The existing `fx` contribution must never be fed into the multiplicative FX term.

### Reported contagion state versus publishable statement

Keep the incumbent state machine and tuning intact. `summary_eligibility["us_transmission"]` validates that the reported statement is supported; it does not recalculate a replacement state. Qualified overall copy needs: recognized current origin state (`calm`, `strained`, `stressed`), qualified source support for the four counted Tier-2 families, boolean owner hot flags, and a reconciled hot count. The safety-bid flag is informational and not a fifth counted family. Unknown/denied dependencies suppress derived summary copy; valid independent measures remain readable.

For `unknown` or `insufficient_data` origin, **do not publish Quiet** merely because the existing source reports `state="quiet"`. For absent/unqualified Tier-2 evidence, **do not publish Contained** from a zero hot count. Use “Transmission assessment unavailable” and name the missing requirements. Raw reported state may be shown in an explicitly historical/diagnostic evidence panel only when that disclosure itself is permitted. It is not a qualified current claim.

### Statistical and structural channels

`spillover.us_from_others` is already in percent units; do not multiply by 100 again. Directional outgoing shares sum across recipients and can exceed 100: they are not probabilities and must not be clamped to 100. Total connectedness and incoming shares have their separately defined bounded geometry. Label the observed source methodology: rolling Garman–Klass volatility with disclosed close-return-volatility fallback, VAR/GFEVD, not causal company impact.

`contagion.corr_tightening()` uses daily log-return observations in its current implementation. The separately retained `intl_performance.correlation_matrix()` uses weekly returns. Keep method labels, windows and baskets distinct even when both panels say “correlation”.

CGL matrices are `matrix[destination][source]`; an edge from Japan to Korea reads `["kr"]["jp"]`. The structural matrix is a versioned model prior; do not redraw it as verified issuer exposure. Dynamic-missing/structural-only fallback remains visible. Preserve `data_sessions[market]`, structural version, model parameters and input gaps. No changes to weights, shadow-state rules, forward logs or model parameters are part of this page. `CGL` is consumed from the existing builder; no `compute()`/`snapshot()` call from this helper or browser.

### Annual structural observations

Use field-specific period, source/vintage and actual/estimate/projection status. A row's maximum `asof_year` does not qualify all three underlying IMF measures. The current source can fall back to a projected year; therefore do not label a raw `current_account` as an observed annual fact without its field receipt. Display qualified model estimates as estimates; leave absent metadata unknown. Never substitute China for Taiwan or Germany for the euro area. A fiscal/current-account/debt gap does not become a neutral structural warning.

## 5. Failure and journey requirements

All pages support qualified, partial, stale, missing, denied, failed, unsupported and unknown content without erasing valid neighbors. Empty configured coverage is distinct from an empty filter. Initial loading uses actual pending work only; static absent data must not shimmer forever. A failed source read is not “no risk”.

Opening Macro/Risk, changing market, changing theme/locale, expanding old research or opening evidence performs **no financial recalculation, provider fetch, saved write, alert mutation or ledger advance**. One active controller restores the same market, comparison pins, period, source generation, focus and scroll. For an unavailable destination, open a contextual read-only explanation with a real Back action rather than a fake success or dead link.

Keep the status bar drawn in mobile Paper out of the website implementation; the device already owns it. Keep canvas absolute offsets out of page CSS. Use semantic tables with captions/header associations on desktop and one accessible active representation after mobile reflow. Controls have at least 44px targets. Enlarge typography, stack lanes and allow vertical growth at 320px/200% text; do not squeeze text or clip it to fit a mockup height. Theme/locale variants still require real implementation proof; eight dark/EN boards do not prove light/ZH.
