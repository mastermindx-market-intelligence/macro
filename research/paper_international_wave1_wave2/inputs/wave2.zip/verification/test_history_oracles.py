import unittest
from decimal import Decimal
from contract_oracles import *

class HistoryScenarioExamples(unittest.TestCase):
    def test_initial_blank_no_sample(self):
        d=initial_draft();self.assertEqual(d["local_raw"],"");self.assertIsNone(scenario_result(d["local_raw"],d["fx_raw"]))
    def test_ascii_percent(self):self.assertEqual(parse_percent("+5.00%","en"),("valid",Decimal(5)))
    def test_unicode_minus(self):self.assertEqual(parse_percent("−3.00%","en"),("valid",Decimal(-3)))
    def test_fullwidth_zh(self):self.assertEqual(parse_percent("＋５．００％","zh"),("valid",Decimal(5)))
    def test_dot_fraction(self):self.assertEqual(parse_percent("-.5","en"),("valid",Decimal("-.5")))
    def test_valid_thousands(self):self.assertEqual(parse_percent("1,234.5%","en"),("valid",Decimal("1234.5")))
    def test_decimal_comma_rejected(self):self.assertEqual(parse_percent("1,5","en")[0],"invalid")
    def test_wrong_group_rejected(self):self.assertEqual(parse_percent("12,34.0","zh")[0],"invalid")
    def test_trailing_text_rejected(self):self.assertEqual(parse_percent("5 percent","en")[0],"invalid")
    def test_double_percent_rejected(self):self.assertEqual(parse_percent("5%%","en")[0],"invalid")
    def test_exponent_rejected(self):self.assertEqual(parse_percent("1e3","en")[0],"invalid")
    def test_unknown_locale_rejected(self):self.assertEqual(parse_percent("1.5","fr")[0],"invalid")
    def test_accounting_parentheses_rejected(self):self.assertEqual(parse_percent("(5)","en")[0],"invalid")
    def test_resource_limit(self):self.assertEqual(parse_percent("1"*129,"en")[0],"invalid")
    def test_blank_not_zero(self):self.assertEqual(parse_percent(" ","en"),("blank",None))
    def test_lone_sign_retained_as_editing(self):self.assertEqual(parse_percent("-","en"),("editing",None))
    def test_sign_dot_retained_as_editing(self):self.assertEqual(parse_percent("+.","en"),("editing",None))
    def test_scenario_golden(self):self.assertEqual(scenario_result("5","-3")["usd_percent"],Decimal("1.85"))
    def test_local_total_loss_valid(self):
        r=scenario_result("-100","3");self.assertEqual(r["usd_percent"],-100);self.assertEqual(r["contribution_pp"],0)
    def test_below_total_loss_invalid(self):self.assertIsNone(scenario_result("-100.01","3"))
    def test_fx_total_loss_invalid(self):self.assertIsNone(scenario_result("5","-100"))
    def test_invalid_after_valid_withholds(self):
        self.assertIsNotNone(scenario_result("5","-3"));self.assertIsNone(scenario_result("5","-"))
    def test_pending_context_withholds(self):self.assertIsNone(scenario_result("5","-3",pending=True))
    def test_invalid_sensitivity_withheld(self):self.assertEqual(scenario_sensitivity("5","-"),[])
    def test_pending_sensitivity_withheld(self):self.assertEqual(scenario_sensitivity("5","-3",pending=True),[])
    def test_sensitivity_golden(self):self.assertEqual([r["usd_percent"] for r in scenario_sensitivity("5","-3")],[Decimal("1.85"),Decimal(5),Decimal("8.15")])
    def test_sensitivity_dedup_current_zero(self):
        r=scenario_sensitivity("5","0");self.assertEqual(len(r),2);self.assertEqual(r[0]["kind"],"current")
    def draft(self):return {**initial_draft(),"local_raw":"+5.00%","fx_raw":"−3.00%"}
    def test_context_proposal_not_commit(self):
        a=self.draft();b=propose_context(a,horizon="3m");self.assertEqual(b["horizon"],"1m");self.assertEqual(b["pending"]["horizon"],"3m");self.assertIsNone(a["pending"])
    def test_context_cancel_exact_restore(self):
        d=self.draft();self.assertEqual(cancel_context(propose_context(d,horizon="3m")),d)
    def test_context_confirm_no_annualizing(self):
        d=confirm_context(propose_context(self.draft(),horizon="3m"));self.assertEqual(d["horizon"],"3m");self.assertEqual(d["local_raw"],"+5.00%")
    def test_context_confirm_invalid_refused(self):
        d=propose_context({**self.draft(),"fx_raw":"-"},market="KR");self.assertEqual(confirm_context(d),d)
    def test_reset_cancel_no_change(self):self.assertEqual(clear_assumptions(self.draft(),False),self.draft())
    def test_reset_clears_inputs_only(self):
        d=clear_assumptions(self.draft(),True);self.assertEqual((d["market"],d["horizon"]),("JP","1m"));self.assertEqual((d["local_raw"],d["fx_raw"]),("",""))
    def point(self):return {"market":"JP","unit":"ratio","basis":"current_composite","universe":"core7","method":"method1","artifact_ref":"digest1","kind":"recomputed"}
    def test_same_reconstruction_compare(self):self.assertTrue(compare_recomputed(self.point(),self.point()))
    def test_changed_universe_incomparable(self):self.assertFalse(compare_recomputed(self.point(),{**self.point(),"universe":"other"}))
    def test_unknown_method_incomparable(self):self.assertFalse(compare_recomputed(self.point(),{**self.point(),"method":None}))
    def test_original_known_not_inferred(self):self.assertFalse(compare_recomputed(self.point(),{**self.point(),"kind":"as_known"}))

if __name__=="__main__":unittest.main(verbosity=2)
