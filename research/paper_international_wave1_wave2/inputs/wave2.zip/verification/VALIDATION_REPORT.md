# Validation report — Wave 2

## Observed results

- Specification examples: `python -m unittest discover -s verification -p 'test_*oracles.py' -v` → **75 tests / OK**.
- Packet/source-lineage controls: `python verification/verify_packet.py` → **33 checks passed**.
- Wave 1 parent archive SHA256 remains `81d04f9e10e3502532859d32557d7a91a240b2fdcfe2b294b1f30d2014a788b6`.
- Four included Wave 1 input files match their exact extracted parent-member bytes and individual hashes.
- Macro/Risk native archive: 8 paired references, 2 specification JSX, 27 payload files; all hashes and ZIP integrity verified on M2.
- History/Scenario native archive: 5 paired references, 2 specification JSX, 18 payload files; all hashes and ZIP integrity verified on M2.
- Every native target's JSX matched before/after its screenshot. No full-file atomic revision claim; no fonts included.

## Scope of these checks

The 75 tests execute a reference model of the proposed contract: FX arithmetic, inverse quotes, missing/denied/invalid data, explicit transmission qualification, unit geometry, scoped matrix direction, EN/ZH parsing, scenario context/reset behavior and comparable historical fields. They do **not** run the future product helpers, served controllers, financial pipelines, auth or browser. They are discriminating acceptance examples for the builder, not evidence the website is implemented.

The packet checks verify references/counts, bounded task IDs, no placeholder markers, source-linked findings, archive receipts and immutable lineage. They are not independent design/source review. CI, product tests, source PR, runtime START, browser rights and production deployment were not performed by this research turn.

The final planning archive also contains `INTEGRITY.json`; final ZIP/member/clean-extraction verification is recorded separately in the sibling delivery receipt. No tests are counted twice as product acceptance. Byte hashes are input/evidence integrity, not semantic or financial validity.
