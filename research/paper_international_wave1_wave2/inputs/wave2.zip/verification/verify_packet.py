"""Validate packet structure and exact Wave 1 lineage; no product test claim."""
from pathlib import Path
import csv,json,hashlib,re
R=Path(__file__).resolve().parents[1]
W1=R.parent/'Mastermind_Paper_Census_Build_Handoffs_Wave_1.zip'
EXPECTED='81d04f9e10e3502532859d32557d7a91a240b2fdcfe2b294b1f30d2014a788b6'
checks=[]
def check(name,ok):
    if not ok:raise AssertionError(name)
    checks.append(name)
check('Wave 1 lineage known',len(EXPECTED)==64)
if W1.exists():check('Wave 1 archive unchanged',hashlib.sha256(W1.read_bytes()).hexdigest()==EXPECTED)
boards=list(csv.DictReader((R/'census/WAVE2_BOARDS.csv').open()))
check('eight unique current-page boards',len(boards)==8 and len({b['node_id'] for b in boards})==8)
check('exact current file/page',all(b['file_id']=='01M3P1TW5Y3XWQC37ADDS8K5AG' and b['page_id']=='p-3-0' for b in boards))
check('both pages four reviewed variants',all(sum(b['handoff']==h for b in boards)==4 for h in ('IM-04','IM-05')))
check('path-based observed Paper URLs',all(b['page_url'].endswith('/p-3-0') for b in boards))
for h,n in [('IM-04_MACRO_POLICY.md','IM04'),('IM-05_RISK_TRANSMISSION.md','IM05')]:
    s=(R/'handoffs'/h).read_text()
    check(n+' four bounded tasks',all(f'{n}-T{x}' in s for x in range(1,5)))
    check(n+' referenced nodes included',all(b['node_id'] in s for b in boards if b['handoff']==n[:2]+'-'+n[2:]))
    check(n+' no placeholder TODO',not re.search(r'\b(TODO|TBD)\b',s))
    check(n+' acceptance not invented as passed','not results' in s or 'not results from' in s or 'not claim these passed' in s)
    check(n+' preserves release boundary','browser' in s and 'Rollback' in s or 'rollback' in s)
rows=list(csv.DictReader((R/'contracts/SOURCE_BINDINGS_AND_GAPS.csv').open()))
check('18 unique source findings',len(rows)==18 and len({r['finding'] for r in rows})==18)
check('immutable source refs with line anchors',all('/ef1f7db98cff38b2a2b2d50e221da61c99e97611/' in r['immutable_source_url'] and '#L' in r['immutable_source_url'] for r in rows))
receipt=json.loads((R/'evidence/NATIVE_DESIGN_PACK.json').read_text())
check('eight native reference pairs receipt',receipt['native_reference_pairs']==8 and receipt['all_target_jsx_stable'])
check('no font/production/delivery claims',not receipt['fonts_bundled'] and not receipt['production_acceptance'] and not receipt['worker_delivery_proven'])
check('exact native archive hash',receipt['sha256']=='a3ec2a629a1ed077cbf914eeee6c18b3fdb49c3a75cefd862ab847f079456575')
check('no font files in planning packet',not any(p.suffix.lower() in ('.woff','.woff2','.ttf','.otf') for p in R.rglob('*') if p.is_file()))
history=list(csv.DictReader((R/'census/HISTORY_BOARDS.csv').open()))
check('five unique history boards',len(history)==5 and len({b['node_id'] for b in history})==5)
check('history exact page',all(b['page_id']=='p-4-0' for b in history))
h=(R/'handoffs/IM-06_HISTORY_SCENARIOS.md').read_text()
check('history five bounded tasks',all(f'IM06-T{x}' in h for x in range(1,6)))
check('history all node refs included',all(b['node_id'] in h for b in history))
check('history no TODO placeholders',not re.search(r'\b(TODO|TBD)\b',h))
hr=json.loads((R/'evidence/HISTORY_NATIVE_DESIGN_PACK.json').read_text())
check('history archive integrity observed',hr['zip_and_payload_integrity']=='PASS' and hr['native_reference_pairs']==5 and hr['all_target_jsx_stable'])
check('history no production/font/worker transfer claim',not hr['production_acceptance'] and not hr['fonts_bundled'] and not hr['worker_delivery_proven'])
lineage=json.loads((R/'inputs/WAVE1_LINEAGE.json').read_text())
check('frozen Wave 1 references have exact hashes',all(hashlib.sha256((R/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in lineage['files']))
check('continuation preserves source-publication honesty','NOT_CANONICALLY_PERSISTED' in (R/'CONTINUATION.md').read_text())
check('Library preflight not prematurely accepted','not IM-07 completion' in (R/'census/LIBRARY_PREFLIGHT.md').read_text())
check('copied references from known exact parent',lineage['parent_sha256']==EXPECTED)
print(json.dumps({'scope':'packet specification and lineage only','checks_passed':len(checks),'checks':checks},indent=2))
