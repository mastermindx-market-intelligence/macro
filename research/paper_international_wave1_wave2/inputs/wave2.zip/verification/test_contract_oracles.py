import unittest, json
from decimal import Decimal
from contract_oracles import *

class ContractExamples(unittest.TestCase):
    def legs(self, count=0):
        return {k:{"hot":i<count,"quality":"qualified"} for i,k in enumerate(sorted(COUNTED))}
    def test_fx_exact(self):
        self.assertEqual(fx_arithmetic(-1.8,-.8),{"usd_percent":Decimal("-2.585600"),"contribution_pp":Decimal("-0.785600")})
    def test_fx_gain_and_drag(self):self.assertEqual(fx_arithmetic(5,-2)["usd_percent"],Decimal("2.9"))
    def test_fx_zero_is_valid(self):self.assertEqual(fx_arithmetic(0,0)["usd_percent"],0)
    def test_fx_bool_rejected(self):
        with self.assertRaises(ValueError):fx_arithmetic(True,0)
    def test_fx_nonfinite_rejected(self):
        with self.assertRaises(ValueError):fx_arithmetic(float("nan"),0)
    def test_quote_inverse_not_sign_flip(self):
        self.assertNotEqual(inverted_quote_return(.01),Decimal("-.01"))
        self.assertEqual(inverted_quote_return(.01),1/Decimal("1.01")-1)
    def test_quote_nonpositive_rejected(self):
        with self.assertRaises(ValueError):inverted_quote_return(-1)
    def test_unknown_origin_not_quiet(self):self.assertFalse(publishable_transmission("unknown","quiet",self.legs(),0))
    def test_insufficient_origin_not_quiet(self):self.assertFalse(publishable_transmission("insufficient_data","quiet",self.legs(),0))
    def test_absent_tier2_not_contained(self):self.assertFalse(publishable_transmission("strained","contained",{},0))
    def test_unqualified_tier2_not_contained(self):
        x=self.legs();x["move_pctile"]["quality"]="stale"
        self.assertFalse(publishable_transmission("strained","contained",x,0))
    def test_denied_origin_withheld(self):self.assertFalse(publishable_transmission("calm","quiet",self.legs(),0,origin_qualified=False))
    def test_qualified_calm_positive_control(self):self.assertTrue(publishable_transmission("calm","quiet",self.legs(),0))
    def test_qualified_contained_positive_control(self):self.assertTrue(publishable_transmission("strained","contained",self.legs(),0))
    def test_qualified_watching_positive_control(self):self.assertTrue(publishable_transmission("strained","watching",self.legs(1),1))
    def test_qualified_transmitting_positive_control(self):self.assertTrue(publishable_transmission("stressed","transmitting",self.legs(2),2))
    def test_mismatch_state_refused(self):self.assertFalse(publishable_transmission("stressed","contained",self.legs(2),2))
    def test_mismatch_count_refused(self):self.assertFalse(publishable_transmission("stressed","watching",self.legs(2),1))
    def test_bool_count_refused(self):self.assertFalse(publishable_transmission("stressed","watching",self.legs(1),True))
    def test_nonbool_hot_refused(self):
        x=self.legs();x["move_pctile"]["hot"]=0
        self.assertFalse(publishable_transmission("calm","quiet",x,0))
    def test_safety_bid_not_fifth_counted_leg(self):
        x=self.legs();x["safety_bid_flag"]={"hot":True,"quality":"qualified"}
        self.assertTrue(publishable_transmission("strained","contained",x,0))
    def time_meta(self):return {"source_cadence":"daily","unit":"basis_points","window_kind":"sessions","observations":21,"endpoints_known":True,"calendar_receipt":True}
    def test_qualified_session_positive_control(self):self.assertTrue(session_change_admitted(self.time_meta()))
    def test_monthly_not_twenty_sessions(self):
        x=self.time_meta();x["source_cadence"]="monthly";self.assertFalse(session_change_admitted(x))
    def test_window_days_not_endpoint_receipt(self):
        x=self.time_meta();x["calendar_receipt"]=False;x["vel_window_days"]=504;self.assertFalse(session_change_admitted(x))
    def test_no_endpoints_not_session_change(self):
        x=self.time_meta();x["endpoints_known"]=False;self.assertFalse(session_change_admitted(x))
    def test_pp_to_bp(self):self.assertEqual(Decimal("-.02")*100,Decimal("-2"))
    def test_documented_threshold_discrepancy(self):self.assertEqual((Decimal("0.10")/100)*100,Decimal("0.10"))
    def annual(self):return {"field_period":2025,"field_vintage":"source-vintage-1","observation_type":"observed","rights":"permitted","identity_exact":True}
    def test_observed_annual_positive_control(self):self.assertTrue(observed_annual_admitted(self.annual()))
    def test_projection_not_observed(self):
        x=self.annual();x["observation_type"]="projection";self.assertFalse(observed_annual_admitted(x))
    def test_row_max_year_not_field_year(self):
        x=self.annual();x["field_period"]=None;x["row_max_year"]=2026;self.assertFalse(observed_annual_admitted(x))
    def test_wrong_country_not_annual_substitute(self):
        x=self.annual();x["identity_exact"]=False;self.assertFalse(observed_annual_admitted(x))
    def test_incoming_is_already_percent(self):self.assertEqual(formatted_incoming_percent(38.4),38.4)
    def test_outgoing_sum_can_exceed_hundred(self):self.assertEqual(formatted_outgoing_sum(145.5),145.5)
    def test_negative_outgoing_refused(self):
        with self.assertRaises(ValueError):formatted_outgoing_sum(-.1)
    def test_cgl_destination_source_direction(self):
        matrix={"jp":{"kr":.1},"kr":{"jp":.7}}
        self.assertEqual(directed_weight(matrix,"jp","kr"),.7)
    def test_denied_value_removed(self):
        value=serialized_metric(12345.6789,rights="denied");self.assertNotIn("12345",json.dumps(value));self.assertIsNone(value["value"])
    def test_zero_metric_remains_valid(self):self.assertEqual(serialized_metric(0,rights="permitted"),{"quality":"qualified","value":0})
    def test_bool_not_numeric_metric(self):self.assertEqual(serialized_metric(True,rights="permitted")["quality"],"unknown")

if __name__=="__main__":unittest.main(verbosity=2)
