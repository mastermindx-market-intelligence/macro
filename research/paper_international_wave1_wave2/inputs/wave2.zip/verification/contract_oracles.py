"""Executable examples of the PROPOSED build contract, not production code.

No source, browser, authenticated service or financial data is called. These
oracles make expected distinctions checkable; product workers must separately
exercise their actual helpers/controllers and the real integration path.
"""
from decimal import Decimal
import math

COUNTED = frozenset({"us_hy_oas_vel", "kre_spy_rs", "move_pctile", "sofr_iorb_corridor"})
def finite_number(value):
    return isinstance(value, (int,float,Decimal)) and not isinstance(value,bool) and math.isfinite(value)

def fx_arithmetic(local_percent, raw_fx_percent):
    if not all(finite_number(x) for x in (local_percent,raw_fx_percent)):
        raise ValueError("finite numeric input required")
    local,fx=Decimal(str(local_percent))/100,Decimal(str(raw_fx_percent))/100
    if local < -1 or fx <= -1: raise ValueError("invalid price/currency geometry")
    usd=(1+local)*(1+fx)-1
    if not finite_number(usd*100) or not finite_number((usd-local)*100):
        raise ValueError("arithmetic overflow for browser numeric output")
    return {"usd_percent":usd*100,"contribution_pp":(usd-local)*100}

def inverted_quote_return(raw_quote_return):
    q=Decimal(str(raw_quote_return))
    if q<=-1:raise ValueError("nonpositive quote endpoint")
    return 1/(1+q)-1

def publishable_transmission(origin, reported, legs, hot_count, *, origin_qualified=True):
    if not origin_qualified or origin not in {"calm","strained","stressed"}:return False
    if not isinstance(hot_count,int) or isinstance(hot_count,bool):return False
    if not COUNTED.issubset(legs):return False
    if any(legs[k].get("quality")!="qualified" or type(legs[k].get("hot")) is not bool for k in COUNTED):return False
    n=sum(legs[k]["hot"] for k in COUNTED)
    if n!=hot_count:return False
    # Validate the incumbent's declared rule, not a replacement runtime state.
    expected="quiet" if origin=="calm" else "contained" if n==0 else "watching" if n==1 else "transmitting"
    return reported==expected

def session_change_admitted(meta):
    return (meta.get("source_cadence")=="daily" and meta.get("unit")=="basis_points"
            and meta.get("window_kind")=="sessions" and meta.get("observations")==21
            and meta.get("endpoints_known") is True and meta.get("calendar_receipt") is True)

def observed_annual_admitted(meta):
    return (meta.get("field_period") is not None and meta.get("field_vintage") is not None
            and meta.get("observation_type")=="observed" and meta.get("rights")=="permitted"
            and meta.get("identity_exact") is True)

def directed_weight(matrix, source, destination):
    return matrix[destination][source]

def formatted_incoming_percent(value):
    if not finite_number(value) or not 0<=value<=100:raise ValueError("invalid incoming share")
    return float(value)

def formatted_outgoing_sum(value):
    if not finite_number(value) or value<0:raise ValueError("invalid outgoing sum")
    return float(value)  # not a probability; can exceed 100

def serialized_metric(value, *, rights):
    return {"quality":"denied","value":None} if rights!="permitted" else {"quality":"qualified" if finite_number(value) else "unknown","value":value if finite_number(value) else None}

# Scenario parsing/state below are specification examples only.
import re, unicodedata
from copy import deepcopy

def parse_percent(raw, locale):
    if not isinstance(raw,str) or len(raw)>128 or locale not in ("en","zh"):
        return ("invalid",None)
    s=unicodedata.normalize("NFKC",raw).replace("−","-").strip()
    if not s:return ("blank",None)
    if s in {"+","-",".","+.","-."}:return ("editing",None)
    if s.endswith("%"):s=s[:-1].strip()
    grammar=r"[+-]?(?:(?:[0-9]{1,3}(?:,[0-9]{3})+|[0-9]+)(?:\.[0-9]*)?|\.[0-9]+)"
    if not re.fullmatch(grammar,s):return ("invalid",None)
    v=Decimal(s.replace(",",""))
    return ("valid",v) if finite_number(v) else ("invalid",None)

def scenario_result(local_raw,fx_raw,locale="en",pending=False):
    if pending:return None
    a,l=parse_percent(local_raw,locale);b,f=parse_percent(fx_raw,locale)
    if a!="valid" or b!="valid":return None
    try:return fx_arithmetic(l,f)
    except ValueError:return None

def scenario_sensitivity(local_raw,fx_raw,locale="en",pending=False):
    if scenario_result(local_raw,fx_raw,locale,pending) is None:return []
    l=parse_percent(local_raw,locale)[1];f=parse_percent(fx_raw,locale)[1]
    out=[];seen=set()
    for kind,x in [("current",f),("unchanged",Decimal(0)),("illustrative_plus3",Decimal(3))]:
        if x in seen:continue
        seen.add(x);out.append({"kind":kind,"fx_percent":x,"usd_percent":fx_arithmetic(l,x)["usd_percent"]})
    return out

def initial_draft():return {"market":"JP","horizon":"1m","local_raw":"","fx_raw":"","pending":None}
def propose_context(draft,**changes):
    d=deepcopy(draft);d["pending"]={"market":draft["market"],"horizon":draft["horizon"],**changes};return d
def cancel_context(draft):
    d=deepcopy(draft);d["pending"]=None;return d
def confirm_context(draft):
    d=deepcopy(draft)
    if d["pending"] is None or scenario_result(d["local_raw"],d["fx_raw"]) is None:return d
    d.update(d["pending"]);d["pending"]=None;return d
def clear_assumptions(draft,confirmed):
    d=deepcopy(draft)
    if confirmed:d.update(local_raw="",fx_raw="")
    return d

def compare_recomputed(left,right):
    keys=("market","unit","basis","universe","method","artifact_ref")
    return (all(left.get(k) is not None and left[k]==right.get(k) for k in keys)
            and left.get("kind")==right.get("kind")=="recomputed")
