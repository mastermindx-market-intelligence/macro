# What is ready to commission, and what is not

| Surface | Ready for bounded implementation | Data/source constraints | Release still owed |
|---|---|---|---|
| Macro & Policy | Yes: exact four tasks, native responsive direction, current component/field contracts | Official/proxy identity, cadence metadata and economic-claim qualification; source defects not silently repaired by UI | Independent review, real useful qualified reads, preservation, browser/rights, served publication |
| Risk & Transmission | Yes: exact four tasks, arithmetic and separate research panels | False-calm publication guard; country-vs-regional data; period/vintage/units/matrix direction | Positive and abstention paths, no side effects, independent/browser/rights/deployment proof |
| History & Scenarios | Yes: exact five tasks, typed history receipt and manual calculator | Latest-vintage histories are not as-known; no invented rank/revision or track-record health | Actual typing/context/return behavior, real history owner path, no governance writes, release proof |
| As-known replay / new historical rank ledger | No | Existing qualified original vintages, first-known clocks, universe/method versions and rights required | Separate owner programme, not invented in this UI task |
| Country credit / PIT breadth / business exposures | Presentation of unavailable states is specified; underlying new data not declared built | Domain contracts and licensed/current evidence | Separately qualified extensions; do not erase useful existing tools |
| Active Follow / Saved writes | Not included in these three packets | Existing authenticated state/effect owners must be found and qualified | No optimistic success, duplicate alerts, shadow database or inferred save |
| Library/Search/Saved | Preliminary contracts recovered; not yet a completed build handoff | Eighteen tool-family mapping and exact state/owner qualification remain | See next frontier; four same-name state-board inspection was refused and not retried |

## Minimum useful acceptance, not an all-null escape hatch

For a source review, fixtures must exercise genuine positive and negative code paths through the actual implementation. For production release, Macro must show real qualified existing source readings and retain its deeper tools; Risk must show a real admitted currency/evidence path and correctly scoped deeper research; History must show a real source-reader journey or a proven source-specific absence while its manual calculator is genuinely usable. An empty/static placeholder with all capabilities disabled is not product acceptance.

A legitimate missing advanced source need not block unrelated useful functionality. Conversely, a missing source needed for the page's promised core capability remains a visible unfinished obligation, not a reason to relabel the product complete. No source/CI/native screenshot receipt alone proves a paid user's journey.
