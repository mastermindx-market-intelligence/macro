# Next phase already opened — Library, Search and Saved

This is a preliminary research result, **not IM-07 completion or build authority**. It preserves findings so the next turn does not restart the catalogue census.

## Three newly resolved distinctions

**Research catalogue is not the stock-analysis library.** [Pinned `scripts/build_intl_library.py:1–58`](https://github.com/mastermindx-market-intelligence/macro/blob/ef1f7db98cff38b2a2b2d50e221da61c99e97611/scripts/build_intl_library.py#L1-L58) runs per-ticker cycle/technical analysis, writes `site/intlstockdata/*.json` and creates a pooled standout ranking. It can fan work across processes. It is not the eighteen-item navigation catalogue or a user's saved research store. Never call it when a user searches or opens Research Library.

**Wave 1's eighteen preservation checks are not eighteen canonical tool IDs.** They are regression obligations over the old site. Native specification `3Q6-0` instead groups eighteen semantic tool families into six questions. Build a verified mapping; do not turn `PF-01…PF-18`, translated labels or Paper board numbers into a second permanent tool registry.

**Search, coverage and saved inventory are separate.** Specification `422-0` was read in full. Local matching operates only on the permitted catalogue, is IME-safe and suppresses obsolete query results. Zero matches does not mean no market coverage. Market-specific data quality/rights are independent of catalogue membership. “Nothing saved” requires a successful authenticated inventory read, not a failed request. Query clear preserves group, filters, market, period and return context. Navigation never auto-saves or creates a monitor.

## Actual six-group / eighteen-family native map

| Group | Paper group entry | Native tool-family labels |
|---|---|---|
| Find the leaders | 80 / `3IN-0` | Performance & currency; Leadership rotation; Cross-country comparison |
| Check the recovery | 81 / `3JZ-0` | Market turns; Recovery quality; Participation & concentration |
| Follow policy divergence | 82 / `3LB-0` | Rates, curves & carry; Central banks & liquidity; Credit & bonds |
| Understand the backdrop | 83 / `3MN-0` | Euro-area fragmentation; Growth & inflation; Dollar conditions |
| Trace the pressure | 68 / `38A-0` | Structural fragility; Contagion; Trade & supply links |
| Challenge the conclusion | 84 / `3NZ-0` | Cross-market correlation; Risk-radar track record; Country sectors & stocks |

Native specification `3Q6-0` supersedes the older `3PB-0` statement that five group entries remained undesigned. Its other history/data/effect rules remain. The existence of a group entry does not mean three underlying analytical workspaces are implemented.

Research context and tool scope differ: Japan may remain selected while an explicitly euro-area fragmentation tool opens. Preserve Japan on return; never relabel euro-area measures as Japanese ones. Structural CGL model links are not yet proved company trade/supply exposures.

## Unresolved exact-state qualification

The saved Wave 1 directory contains four artboards with the same “102 · Library Search · Matched” title: `3C4-0`, `3WS-0`, `3YE-0`, `400-0`. The newer specification describes matched102, zero103, loading104 and unavailable105. A bounded attempt to inspect/export those four exact targets was explicitly refused before dispatch; it was not retried or routed through another tool. Their current semantic mapping is **unresolved**, not four approved duplicates and not four automatically renamed states.

Do not delete, rename or rebuild them from this discrepancy. Exact-target inspection remains fenced until actual permission/admission evidence changes. Independent catalogue/backend/rights investigation can continue without touching those targets. The page is not globally inaccessible: source specifications were read independently.

## Next useful independent work

Resolve existing catalogue/destination IDs and every domain's actual scope against the eighteen family labels. Map the authenticated saved-inventory owner and its read/write/effect contracts before specifying Save/Remove/Undo. Separate read-only Library/Search implementation from saved-write deployment. Freeze current canonical core/group JSX and inspect semantic states when legitimately admitted. Then author IM-07 and the separately gated Saved packet without duplicating stock analysis, monitoring, source rights or user state owners.
