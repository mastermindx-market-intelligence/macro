"""V27 actual after-close vintage paper-only native oscillator freeze.
Cannot install trades or know future close; all observations stamped now.
"""
from pathlib import Path
from datetime import datetime,timezone
from zoneinfo import ZoneInfo
import json,hashlib,sys
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parents[2]
V=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source'))
sys.path.insert(0,str(ROOT/'v11_published/source'))
sys.path.insert(0,str(ROOT/'v21/source'))
import v12_engine as native
import empirical as e
import paper_ledger as old
import verify_vintage as verify
NY=ZoneInfo('America/New_York')
ASOF='2026-10-13'
def provider_status(last_bar,observed_time):
    local=observed_time.astimezone(NY)
    date=pd.Timestamp(last_bar).date()
    if date>local.date():raise ValueError('Future vendor observation')
    if date<local.date():return 'STALE'
    return 'AFTER_CLOSE_VENDOR_UNATTESTED' if (local.hour>=16) else 'PRE_CLOSE_PROVISIONAL'
def paper_fill_observation(last_signal_i,last_i):
    if last_signal_i is None:return {'status':'NO_SIGNAL','broker_filled':False}
    if last_signal_i>last_i:raise ValueError('Future signal')
    if last_signal_i==last_i:return {'status':'NEXT_OPEN_UNOBSERVED','broker_filled':False}
    return {'status':'PRICE_OPEN_OBSERVED_NOT_BROKER_FILL','broker_filled':False}
def require_asof(index,asof):
    ix=pd.DatetimeIndex(index)
    if len(ix)<2 or not ix.is_monotonic_increasing or ix.has_duplicates or str(ix[-1].date())!=asof:
        raise ValueError('Expected market-cutoff bar missing/misaligned')
def load(sym,expected):
    p=V/'new_vintage'/(sym+'_1d.json')
    meta=json.loads((V/'results/NEW_VINTAGE_MANIFEST.json').read_text())
    row=next((x for x in meta if x['symbol']==sym),None)
    if not row or row['status']!='VALIDATED':raise ValueError('Symbol not fully validated in acquired snapshot')
    blob=p.read_bytes()
    if hashlib.sha256(blob).hexdigest()!=row['sha256']:raise RuntimeError('Source data modified')
    q=verify.validate(blob,sym,expected)
    result=json.loads(blob)['chart']['result'][0]
    ix=pd.DatetimeIndex(expected)
    frame=pd.DataFrame(result['indicators']['quote'][0],index=ix)
    adj=pd.Series(result['indicators']['adjclose'][0]['adjclose'],index=ix)
    factor=adj/frame.close
    frame[['open','high','low','close']]=frame[['open','high','low','close']].mul(factor,axis=0)
    if frame[['open','high','low','close']].isna().any().any() or (frame.low<=0).any():raise ValueError('Adjusted OHLC invalid')
    return frame,q
def run():
    spec=json.loads((V/'SPEC.json').read_text())
    manifest=json.loads((V/'results/NEW_VINTAGE_RECEIPT.json').read_text())
    if not manifest['all_expected_accepted']:raise RuntimeError('Incomplete provider snapshot')
    px=ROOT/'results/portfolio_v13_summary.csv'
    # Existing validated V12 data supplies the historical calendar and native suffix.
    start_ix=native.load_daily('SPY').index
    extended=start_ix.append(pd.DatetimeIndex(native.CALENDAR_TAIL[:3]))
    require_asof(extended,ASOF)
    future=pd.DatetimeIndex(native.CALENDAR_TAIL[3:])
    cal=extended.append(future)
    now=datetime.now(timezone.utc)
    source_status=provider_status(ASOF,now)
    if source_status!='AFTER_CLOSE_VENDOR_UNATTESTED':raise RuntimeError('Not after end-of-day clock; refuse current observation')
    past=pd.read_csv(ROOT/'v21/results/ASOF_2026-10-08_WATCH_LEDGER.csv')
    rows=[];snapshot_versions=[]
    for sym in e.STOCKS:
        d,meta=load(sym,extended)
        assert len(d)==4220 and d.index.equals(extended)
        price_old=native.load_daily(sym)
        # Known provider vintage drift: compare prior overlapping adjusted daily closes but do not rewrite history.
        previous_close=price_old.close
        span=d.close.iloc[:len(previous_close)]
        delta=float(((span/previous_close)-1).abs().max())
        snapshot_versions.append({'symbol':sym,'last_adjusted_close':meta['last_adjusted_close'],'largest_old_source_adjusted_ratio_delta':delta})
        low={frame:e.snapshots(d.close,cal,frame,'confirmed',phase=0) for frame in ['1D','2D']}
        for mode in ['confirmed','developing']:
            weekly,two,context=e.feature_context(d,cal,mode=mode,phase=0,warmup=200)
            for frame in ['1D','2D']:
                base=low[frame]
                watches=e.episodes(context,two.k.to_numpy(float),base.bull.to_numpy(bool),start_i=int(extended.searchsorted('2018-01-01')))
                last=watches[-1] if watches else None
                status=old.classify(last,len(extended))
                si=last['signal_i'] if last is not None else None
                # No actual order/fill claim, even where the model has now seen a historical next open.
                paper=paper_fill_observation(si,len(extended)-1)
                oldrow=past[(past.symbol==sym)&(past.frame==frame)&(past.context_mode==mode)].iloc[0]
                rows.append({'symbol':sym,'frame':frame,'context_mode':mode,
                    'market_asof':ASOF,'observed_utc':now.isoformat(),'source_finality':source_status,
                    'first_observation_after_prior_cutoff':True,
                    'last_watch_arm':str(extended[last['arm_i']].date()) if last is not None else None,
                    'last_signal_date':str(extended[si].date()) if si is not None else None,
                    'asof_state':status['state'],'prior_2026_10_08_state':oldrow.asof_state,
                    'state_changed_since_prior_asof':status['state']!=oldrow.asof_state,
                    'weekly_k_at_close':float(weekly.k.iloc[-1]) if pd.notna(weekly.k.iloc[-1]) else None,
                    'two_week_k_at_close':float(two.k.iloc[-1]) if pd.notna(two.k.iloc[-1]) else None,
                    'joint_context':bool(context[-1]),
                    'lower_new_bull_on_asof':bool(base.bull.iloc[-1]),
                    'lower_fresh':bool(base.fresh.iloc[-1]),
                    'lower_hist_at_close':float(base['hist'].iloc[-1]) if pd.notna(base['hist'].iloc[-1]) else None,
                    'paper_next_open_status':paper['status'],'actual_broker_fill':False,
                    'user_chart_parity':'UNVERIFIED','production_trade_allowed':False})
        print('V27_FROZEN_NAME',sym,flush=True)
    state=pd.DataFrame(rows)
    assert len(state)==72 and not state.duplicated(['symbol','frame','context_mode']).any()
    state.to_csv(V/'results/ASOF_2026-10-13_PAPER_LEDGER.csv',index=False)
    state[state.symbol.isin(e.CORE)].to_csv(V/'results/CORE_2026-10-13_PAPER_LEDGER.csv',index=False)
    changes=state.groupby(['context_mode','frame','asof_state']).size().rename('count').reset_index()
    changes.to_csv(V/'results/STATE_COUNTS_2026-10-13.csv',index=False)
    pd.DataFrame(snapshot_versions).to_csv(V/'results/ADJUSTMENT_VINTAGE_DIFF.csv',index=False)
    from collections import Counter
    receipt={'authored_utc':now.isoformat(),'asof':ASOF,'vendor_after_close_status':source_status,
        'new_adjusted_price_vintage':True,'provider_19of19_accepted':True,'observed_bars':len(extended),
        'historical_Jan2010_start_preserved':True,'earlier_V11_V12_bytes_unchanged':True,
        'paper_rows':len(state),'broker_order_or_fill_claim':False,'chart_parity_verified':False,
        'future_returns_after_oct13_observed':False,'no_automatic_monitoring':True,
        'state_counts':{str(k):int(v) for k,v in state[state.context_mode=='confirmed'].asof_state.value_counts().items()}}
    (V/'results/FREEZE_RECEIPT.json').write_text(json.dumps(receipt,indent=2))
    print('CORE_STATUS',state[(state.symbol.isin(e.CORE))&(state.context_mode=='confirmed')][['symbol','frame','asof_state','last_watch_arm','last_signal_date','lower_new_bull_on_asof']].to_json(orient='records'))
    print('SOURCE_VINTAGE',pd.DataFrame(snapshot_versions).round(7).to_json(orient='records'))
    print('FREEZE_COMPLETE',json.dumps(receipt))
if __name__=='__main__':run()
