"""V27 fail-closed provider daily chart parser; no broker interface."""
import json
import numpy as np
import pandas as pd
def validate(blob,symbol,expected_dates):
    try:
        obj=json.loads(blob)
        entry=obj['chart']['result'][0]
        source_symbol=entry['meta']['symbol']
        timestamps=entry['timestamp']
        quote=entry['indicators']['quote'][0]
        adj=entry['indicators']['adjclose'][0]['adjclose']
    except (KeyError,TypeError,IndexError,ValueError) as exc:raise ValueError('Missing or malformed market source') from exc
    if source_symbol!=symbol:raise ValueError('Unexpected symbol')
    ix=pd.to_datetime(timestamps,unit='s',utc=True).tz_convert('America/New_York').normalize().tz_localize(None)
    exp=pd.DatetimeIndex(expected_dates)
    if not ix.equals(exp) or ix.has_duplicates or not ix.is_monotonic_increasing:raise ValueError('Session mismatch')
    n=len(ix);values={}
    for k in ['open','high','low','close']:
        vals=np.asarray(quote[k],dtype=float)
        if len(vals)!=n or not np.isfinite(vals).all() or (vals<=0).any():raise ValueError('Missing/invalid OHLC')
        values[k]=vals
    adjusted=np.asarray(adj,dtype=float)
    if len(adjusted)!=n or not np.isfinite(adjusted).all() or (adjusted<=0).any():raise ValueError('Adjusted close malformed')
    if (values['high']+1e-4<np.maximum(values['open'],values['close'])).any() or (values['low']-1e-4>np.minimum(values['open'],values['close'])).any() or (values['high']<values['low']).any():raise ValueError('Impossible high/low')
    return {'symbol':symbol,'bars':n,'first':str(ix[0].date()),'last':str(ix[-1].date()),'last_adjusted_close':float(adjusted[-1]),'last_raw_close':float(values['close'][-1]),'session_last3':ix[-3:].strftime('%Y-%m-%d').tolist()}
