"""V27 one-shot forward-window snapshot acquisition. No historical extension
before 2010, no V3 result access, no V4 denied 1985 acquisition, no orders.
Strictly preserve SPY preflight and already-written files.
"""
from pathlib import Path
import urllib.request,urllib.parse
from datetime import datetime,timezone
import json,hashlib,sys
import pandas as pd
from concurrent.futures import ThreadPoolExecutor,as_completed
ROOT=Path('/Volumes/Mastermind/research/defensive_nested_v12_20261013')
V=ROOT/'v27'
sys.path.insert(0,str(V/'source'))
sys.path.insert(0,str(ROOT/'source'))
import verify_vintage as parser
import v12_engine as original
TARGET=V/'new_vintage'
SPEC=json.loads((V/'SPEC.json').read_text())
STOCKS=SPEC['symbols']
EXPECTED=original.load_daily('SPY').index.append(pd.DatetimeIndex(original.CALENDAR_TAIL[:3]))
assert len(EXPECTED)==4220 and EXPECTED[-1]==pd.Timestamp('2026-10-13')
def fetch(sym):
    vals={'period1':1262304000,'period2':1791936000,'interval':'1d','events':'div,splits'}
    url='https://query1.finance.yahoo.com/v8/finance/chart/'+sym+'?'+urllib.parse.urlencode(vals)
    try:
        blob=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=20).read()
        quality=parser.validate(blob,sym,EXPECTED)
        path=TARGET/(sym+'_1d.json')
        if path.exists():raise RuntimeError('Existing original target, refuse overwrite')
        path.write_bytes(blob)
        return quality|{'status':'VALIDATED','filename':path.name,'sha256':hashlib.sha256(blob).hexdigest(),'fetched_utc':datetime.now(timezone.utc).isoformat(),'source_url':url}
    except Exception as exc:
        return {'symbol':sym,'status':'FAILED_NO_RETRY','error':type(exc).__name__+': '+str(exc)[:300]}
def main():
    p=V/'results/NEW_VINTAGE_MANIFEST.json'
    if p.exists():raise RuntimeError('A previous acquisition exists; reconcile instead of retry')
    assert set(q.name for q in TARGET.iterdir())=={'SPY_1d.json'}
    prior=json.loads((V/'results/SPY_PREFLIGHT.json').read_text())
    spy=(TARGET/'SPY_1d.json').read_bytes()
    assert hashlib.sha256(spy).hexdigest()==prior['sha256']
    valid=parser.validate(spy,'SPY',EXPECTED)
    out=[valid|{'status':'VALIDATED','filename':'SPY_1d.json','sha256':prior['sha256'],'fetched_utc':prior['fetched_utc'],'source_url':prior['url']}]
    # One three-worker bounded acquisition, no retries. Journal acknowledged successes.
    with ThreadPoolExecutor(max_workers=3) as ex:
        fs={ex.submit(fetch,s):s for s in STOCKS if s!='SPY'}
        for f in as_completed(fs):
            out.append(f.result())
            p.write_text(json.dumps(sorted(out,key=lambda x:x['symbol']),indent=2))
    ok=sum(x['status']=='VALIDATED' for x in out)
    proof={'market_date':'2026-10-13','retrieval_utc':datetime.now(timezone.utc).isoformat(),
      'expected_sessions':len(EXPECTED),'all_expected_accepted':ok==len(STOCKS),
      'stocks_accepted':ok,'stocks_expected':len(STOCKS),'invalid':[x for x in out if x['status']!='VALIDATED'],
      'source_vendor':'Yahoo chart daily adjusted-price snapshot','same_vendor_independent_holdout':False,
      'eod_vendor_provisional_status':'UNKNOWN','original_v12_vendor_data_preserved':True,
      'no_live_trades':True,'new_bar_dates':EXPECTED[-3:].strftime('%Y-%m-%d').tolist()}
    (V/'results/NEW_VINTAGE_RECEIPT.json').write_text(json.dumps(proof,indent=2))
    print('V27_ACQUISITION',json.dumps(proof))
if __name__=='__main__':main()
