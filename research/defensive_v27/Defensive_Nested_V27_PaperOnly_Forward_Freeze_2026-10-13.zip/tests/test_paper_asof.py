"""V27 current-source paper observation causality tests."""
import unittest,sys
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import paper_asof as p
class Status(unittest.TestCase):
 def test_after_close_does_not_claim_exchange_final(self):
  now=datetime(2026,10,13,17,40,tzinfo=ZoneInfo('America/New_York'))
  self.assertEqual(p.provider_status('2026-10-13',now),'AFTER_CLOSE_VENDOR_UNATTESTED')
 def test_before_close_is_provisional(self):
  now=datetime(2026,10,13,15,59,tzinfo=ZoneInfo('America/New_York'))
  self.assertEqual(p.provider_status('2026-10-13',now),'PRE_CLOSE_PROVISIONAL')
 def test_old_data_is_stale(self):
  now=datetime(2026,10,13,17,40,tzinfo=ZoneInfo('America/New_York'))
  self.assertEqual(p.provider_status('2026-10-08',now),'STALE')
 def test_future_date_rejected(self):
  now=datetime(2026,10,13,17,40,tzinfo=ZoneInfo('America/New_York'))
  with self.assertRaises(ValueError):p.provider_status('2026-10-14',now)
 def test_last_bar_no_broker_fill(self):
  q=p.paper_fill_observation(last_signal_i=4219,last_i=4219)
  self.assertEqual(q['status'],'NEXT_OPEN_UNOBSERVED');self.assertFalse(q['broker_filled'])
 def test_past_next_open_exists_not_real_broker_receipt(self):
  q=p.paper_fill_observation(last_signal_i=4217,last_i=4219)
  self.assertEqual(q['status'],'PRICE_OPEN_OBSERVED_NOT_BROKER_FILL');self.assertFalse(q['broker_filled'])
 def test_no_signal_none(self):
  q=p.paper_fill_observation(last_signal_i=None,last_i=4219)
  self.assertEqual(q['status'],'NO_SIGNAL')
 def test_snapshot_cutoff_prefix(self):
  ix=pd.to_datetime(['2026-10-08','2026-10-09','2026-10-12','2026-10-13'])
  p.require_asof(ix,'2026-10-13')
 def test_reject_future_date_during_freeze(self):
  ix=pd.bdate_range('2026-10-09',periods=4)
  with self.assertRaises(ValueError):p.require_asof(ix,'2026-10-13')
if __name__=='__main__':unittest.main(verbosity=2)