"""V27 provider-vintage parser validation tests, no network."""
import unittest,sys,json
from pathlib import Path
from datetime import datetime,timezone
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import verify_vintage as v
class Validation(unittest.TestCase):
 def payload(self):
  ts=[int(datetime(y,m,d,20,0,tzinfo=timezone.utc).timestamp()) for y,m,d in [(2026,10,9),(2026,10,12),(2026,10,13)]]
  return json.dumps({'chart':{'result':[{'meta':{'symbol':'XYZ'},'timestamp':ts,
   'indicators':{'quote':[{'open':[100.,101.,102.],'high':[101.,102.,103.],'low':[99.,100.,101.],'close':[100.5,101.5,102.5],'volume':[100,200,300]}],
     'adjclose':[{'adjclose':[100.5,101.5,102.5]}]}}],'error':None}}).encode()
 def dates(self):
  return pd.to_datetime(['2026-10-09','2026-10-12','2026-10-13'])
 def test_accept_exact_final_sessions(self):
  x=v.validate(self.payload(),'XYZ',self.dates())
  self.assertEqual(x['bars'],3);self.assertEqual(x['last'],'2026-10-13')
 def test_ticker_mismatch_refuse(self):
  with self.assertRaises(ValueError):v.validate(self.payload(),'ZZZ',self.dates())
 def test_missing_last_session_refuse(self):
  with self.assertRaises(ValueError):v.validate(self.payload(),'XYZ',self.dates()[:-1])
 def test_null_adjusted_close_refuse(self):
  x=json.loads(self.payload());x['chart']['result'][0]['indicators']['adjclose'][0]['adjclose'][-1]=None
  with self.assertRaises(ValueError):v.validate(json.dumps(x).encode(),'XYZ',self.dates())
 def test_invalid_market_highlow_refuse(self):
  x=json.loads(self.payload());x['chart']['result'][0]['indicators']['quote'][0]['low'][0]=105.
  with self.assertRaises(ValueError):v.validate(json.dumps(x).encode(),'XYZ',self.dates())
 def test_corrupt_json_refuse(self):
  with self.assertRaises(ValueError):v.validate(b'not json','XYZ',self.dates())
if __name__=='__main__':unittest.main(verbosity=2)