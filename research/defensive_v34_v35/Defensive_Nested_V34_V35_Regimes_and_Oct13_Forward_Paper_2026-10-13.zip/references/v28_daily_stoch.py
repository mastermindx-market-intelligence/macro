"""V28 fixed 2D RSI-MACD crossover + 1D StochRSI washout gate.
Retrospective test; never optimize thresholds with subsequent returns.
"""
from pathlib import Path
import sys,json,hashlib
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[2]
THIS=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source'))
sys.path.insert(0,str(ROOT/'v11_published/source'))
import v12_engine as native
import empirical as e

def flags(k,d,window=5):
    """5 COMPLETED daily bars including signal close, not shifted future."""
    if window<2 or not k.index.equals(d.index):raise ValueError('Invalid causal window/index')
    k=k.astype(float);d=d.astype(float)
    known=k.rolling(window,min_periods=window).count().ge(window)&d.rolling(window,min_periods=window).count().ge(window)
    cross=k.gt(d)&k.shift(1).le(d.shift(1))
    recent_cross=cross.rolling(window,min_periods=window).max().eq(1)
    floor=k.rolling(window,min_periods=window).min().le(20)
    inforce=recent_cross &k.ge(d)&floor&known
    return pd.DataFrame({'recent_washout':(floor&known).astype(bool),
                         'kd_cross_recent_inforce':inforce.astype(bool),
                         'current_k_above_d':(k>=d)&known},index=k.index)
def gate(df,column):
    if column not in df or 'net' not in df:raise ValueError('Missing evidence columns')
    v=df[column]
    if v.isna().any() or not v.isin([True,False]).all():raise ValueError('Unknown gate status must not be treated as rejection')
    out=df.copy()
    accept=v.astype(bool)
    out['status']=np.where(accept,'ACCEPTED','REJECTED')
    out['cash_or_trade_return']=np.where(accept,out.net.astype(float),0.)
    return out
def summarize(d,label):
    a=d[d[label].eq(True)];b=d[d[label].eq(False)]
    return {'filter':label,'all_n':len(d),'accepted_n':len(a),'rejected_n':len(b),
            'accepted_mean':float(a.net.mean()) if len(a) else None,
            'rejected_mean':float(b.net.mean()) if len(b) else None,
            'accepted_positive':float(a.net.gt(0).mean()) if len(a) else None,
            'rejected_positive':float(b.net.gt(0).mean()) if len(b) else None,
            'all_watch_cash_or_trade_mean':float(d.net.where(d[label],0).mean()) if len(d) else None,
            'unfiltered_mean':float(d.net.mean()) if len(d) else None,
            'missed_positive_n':int((b.net>0).sum()),
            'avoided_negative_n':int((b.net<=0).sum())}
def run():
    desc=json.loads((THIS/'SPEC.json').read_text())
    source=pd.read_csv(ROOT/'v11_published/results/signal_state_events.csv')
    supplement=pd.read_csv(ROOT/'v22/results/V22_ALL_CROSS_EVENTS.csv')
    assert len(source)==len(supplement)==2771
    core=source[source.frame.eq('2D')].copy()
    core=core.merge(supplement[['symbol','frame','signal_date','beta_spread']],
                    on=['symbol','frame','signal_date'],how='left',validate='one_to_one')
    assert core.beta_spread.notna().all()
    chunks=[]
    for symbol in e.STOCKS:
        d=native.load_daily(symbol);ix=d.index;cal=ix.append(pd.DatetimeIndex(native.CALENDAR_TAIL))
        daily=e.snapshots(d.close,cal,'1D',mode='confirmed',phase=0)
        assert daily.index.equals(ix)
        fl=flags(daily.k,daily.d,window=5)
        x=core[core.symbol==symbol].copy()
        k=pd.to_datetime(x.signal_date)
        found=fl.reindex(k)
        if found.isna().any().any():raise RuntimeError('Unmatched daily stoch flag signal timestamp '+symbol)
        x['daily_k_at_signal']=daily.k.reindex(k).to_numpy(float)
        x['daily_d_at_signal']=daily.d.reindex(k).to_numpy(float)
        x['daily_bottom']=found.recent_washout.to_numpy(bool)
        x['daily_kd_bull_inforce']=found.kd_cross_recent_inforce.to_numpy(bool)
        x['joint_bottom_gate']=x.cell.eq('JOINT') & x.daily_bottom
        x['joint_strict_kd_gate']=x.joint_bottom_gate & x.daily_kd_bull_inforce
        x['two_week_oversold']=x.cell.isin(['JOINT','TWO_WEEK_ONLY'])
        chunks.append(x)
        print('V28_DAILY_STOCH',symbol,flush=True)
    out=pd.concat(chunks,ignore_index=True)
    assert len(out)==len(core)
    assert not out.duplicated(['symbol','frame','signal_date']).any()
    out.to_csv(THIS/'results/V28_FIXED_2D_CROSS_EVENTS.csv',index=False)
    summaries=[]
    for (panel,cell),g in out.groupby(['panel','cell']):
        for filt in ['daily_bottom','daily_kd_bull_inforce']:
            q=summarize(g,filt)
            summaries.append({'panel':panel,'cell':cell,**q,
                              'avg_beta_residual_accepted':float(g.loc[g[filt],'beta_spread'].mean()) if g[filt].any() else None,
                              'avg_beta_residual_rejected':float(g.loc[~g[filt],'beta_spread'].mean()) if (~g[filt]).any() else None})
    for panel,g in out.groupby('panel'):
        for filt in ['joint_bottom_gate','joint_strict_kd_gate']:
            q=summarize(g,filt)
            summaries.append({'panel':panel,'cell':'ALL',**q})
    table=pd.DataFrame(summaries);table.to_csv(THIS/'results/V28_CONFLUENCE_SUMMARY.csv',index=False)
    # Preserve named events and first-watch vs unconditioned cohort semantics. No
    # overlap reweighting, return selection, or confident deployment gate.
    receipt={'method':'2D RSI-MACD confirmed cross at next open and 1D SMA3 K/D StochRSI recent-5 completed daily states',
             'source_2D_cross_events':len(core),'reproduced_rows':len(out),
             'core_2d_joint':len(out[(out.panel=='CORE5')&(out.cell=='JOINT')]),
             'no_data_after_cutoff':True,'source_cutoff':'2026-10-08',
             'no_change_to_long_watch_or_2D_entry':True,'comparison_timing':'stoch states known at 2D cross close',
             'excluded_future_vendor_v27':True,'rejected_opportunity_counted_as_cash':True,
             'source_digests':{'base_v11':hashlib.sha256((ROOT/'v11_published/results/signal_state_events.csv').read_bytes()).hexdigest(),
                               'base_v22':hashlib.sha256((ROOT/'v22/results/V22_ALL_CROSS_EVENTS.csv').read_bytes()).hexdigest()},
             'not_proven_chart_parity_or_live_alpha':True}
    (THIS/'results/VERIFICATION.json').write_text(json.dumps(receipt,indent=2))
    print('V28_CORE_JOINT',table[(table.panel=='CORE5')&(table.cell=='JOINT')].round(6).to_json(orient='records'),flush=True)
    print('V28_CORE_ALL',table[(table.panel=='CORE5')&(table.cell=='ALL')].round(6).to_json(orient='records'),flush=True)
    print('V28_PEER_JOINT',table[(table.panel=='PEERS13')&(table.cell=='JOINT')].round(6).to_json(orient='records'),flush=True)
    print('V28_PROOF',json.dumps(receipt))
if __name__=='__main__':run()
