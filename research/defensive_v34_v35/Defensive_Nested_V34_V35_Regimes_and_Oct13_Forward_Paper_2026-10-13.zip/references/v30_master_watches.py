"""V30 causal master-watch comparison:
(1) arm-immediate, (2) first confirmed 2D RSI-MACD cross,
(3) first independently eligible daily StochRSI K>D after short washout,
(4) 2D RSI-MACD after daily Stoch K/D confirmation in-force.
All original W+2W slow episodes held fixed; no rejected events deleted.
"""
from pathlib import Path
import sys,json,hashlib
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[2]
THIS=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source'))
sys.path.insert(0,str(ROOT/'v11_published/source'))
sys.path.insert(0,str(ROOT/'v28/source'))
import v12_engine as native
import empirical as e
import v28_daily_stoch as v28
POLICIES=['WATCH_IMMEDIATE','FIRST_2D_MACDRSI','FIRST_DAILY_STOCH','DAILY_STOCH_THEN_2D']
def first_signal(mask,arm,end):
    a=np.asarray(mask,dtype=bool)
    if arm<0 or end>len(a) or arm>=end:raise ValueError('Invalid episode bound')
    hits=np.flatnonzero(a[arm:end])
    return int(arm+hits[0]) if len(hits) else None
def sequential(two_bull,stoch_cross,recent_floor,k,d,arm,end,window=5):
    if window<1:raise ValueError('Window')
    a=np.asarray(two_bull,bool);s=np.asarray(stoch_cross,bool);f=np.asarray(recent_floor,bool)
    k=np.asarray(k,float);d=np.asarray(d,float)
    if len({len(a),len(s),len(f),len(k),len(d)})!=1 or not 0<=arm<end<=len(a):raise ValueError('Causal vector sizes')
    for i in range(arm,end):
        if a[i] and f[i] and np.isfinite(k[i]) and np.isfinite(d[i]) and k[i]>=d[i]:
            j=max(arm,i-window+1)
            if np.any(s[j:i+1]):return i
    return None
def master_episodes(context,k,trigger,window=42,clear_n=10,start_i=0):
    return e.episodes(np.asarray(context,bool),np.asarray(k,float),np.asarray(trigger,bool),
                       window=window,clear_n=clear_n,start_i=start_i)
def fixed_event(d,arm,signal,horizon=126):
    z=arm+horizon
    if signal is not None and z<len(d) and signal+1>z:raise ValueError('Entry beyond fixed episode horizon')
    return e.event_outcome(d,arm,signal,horizon=horizon,fee=.0005)
def target_before_stop(d,event,target=.08,stop=.05):
    if event['status']!='FILLED':return 'NOT_ENTERED'
    entry_i=int(d.index.get_loc(pd.Timestamp(event['entry_date'])))
    end_i=int(d.index.get_loc(pd.Timestamp(event['exit_date'])))
    entry=float(d.open.iloc[entry_i])
    hi=entry*(1+target);lo=entry*(1-stop)
    for q in d.iloc[entry_i:end_i+1].itertuples():
        if q.open<=lo:return 'STOP'
        if q.open>=hi:return 'TARGET'
        if q.low<=lo:return 'STOP'
        if q.high>=hi:return 'TARGET'
    return 'TIMEOUT'
def summarize(g):
    complete=g[g.status!='INCOMPLETE'];filled=complete[complete.status=='FILLED'];skipped=complete[complete.status=='SKIPPED']
    wins=int((filled.net>0).sum())
    return {'episodes_total':len(g),'episodes_complete':len(complete),'episodes_incomplete':len(g)-len(complete),
      'filled':len(filled),'skipped':len(skipped),
      'trade_win_rate':float((filled.net>0).mean()) if len(filled) else None,
      'filled_mean':float(filled.net.mean()) if len(filled) else None,
      'all_episode_cash_or_trade_mean':float(complete.net.mean()) if len(complete) else None,
      'all_episode_baseline_immediate_mean':float(complete.baseline.mean()) if len(complete) else None,
      'all_episode_incremental':float(complete.incremental.mean()) if len(complete) else None,
      'avg_signal_delay':float(filled.delay.mean()) if len(filled) else None,
      'median_signal_delay':float(filled.delay.median()) if len(filled) else None,
      'target8_first_rate':float((filled.target8=='TARGET').mean()) if len(filled) else None,
      'stopped_first_count':int((filled.target8=='STOP').sum()),
      'missed_positive_immediate_watch':int((skipped.baseline>0).sum()),
      'rejected_negative_immediate_watch':int((skipped.baseline<=0).sum()),
      'stock_count_filled':int(filled.symbol.nunique()),
      'signal_calendar_quarters':int(pd.to_datetime(filled.signal_date).dt.to_period('Q').nunique()) if len(filled) else 0}
def run():
    frozen=pd.read_csv(ROOT/'results/frozen_watch_schedule.csv')
    assert len(frozen)==396
    original_sha=hashlib.sha256((ROOT/'results/frozen_watch_schedule.csv').read_bytes()).hexdigest()
    assert original_sha==json.loads((THIS/'SPEC.json').read_text())['original_watch_manifest_sha']
    records=[];base_reconciliation=[];watch_arms=0
    for sym in e.STOCKS:
        d=native.load_daily(sym);ix=d.index;cal=ix.append(pd.DatetimeIndex(native.CALENDAR_TAIL))
        week,two,context=e.feature_context(d,cal,mode='confirmed',phase=0,warmup=200)
        lo=e.snapshots(d.close,cal,'2D',mode='confirmed',phase=0)
        daily=e.snapshots(d.close,cal,'1D',mode='confirmed',phase=0)
        native_bull=lo.bull.to_numpy(bool);start=int(ix.searchsorted('2018-01-01'))
        watch=master_episodes(context,two.k.to_numpy(float),native_bull,start_i=start)
        reference=frozen[(frozen.symbol==sym)&(frozen.frame=='2D')].sort_values('episode')
        assert len(watch)==len(reference)
        for w,ref in zip(watch,reference.itertuples()):
            assert w['arm_i']==ref.arm_i
            if w['signal_i'] is None:assert np.isnan(ref.signal_i)
            else:assert int(w['signal_i'])==int(ref.signal_i)
            watch_arms+=1
        # Alternative Stoch cross is causally derived, no use of future RSI-MACD outcomes.
        st=v28.flags(daily.k,daily.d,window=5)
        stoch_bull=(daily.k.gt(daily.d)&daily.k.shift(1).le(daily.d.shift(1))).fillna(False).to_numpy(bool)
        pulse=stoch_bull & st.recent_washout.to_numpy(bool)
        for watch_id,w in enumerate(watch,1):
            arm=w['arm_i'];end=min(w['end_i'],len(d))
            raw_stoch=first_signal(pulse,arm,end) if arm<end else None
            eventual_2d=w['signal_i']
            seq=sequential(native_bull,stoch_bull,st.recent_washout.to_numpy(bool),
                           daily.k.to_numpy(float),daily.d.to_numpy(float),arm,end,window=5) if arm<end else None
            candidates={'WATCH_IMMEDIATE':arm,'FIRST_2D_MACDRSI':eventual_2d,
                        'FIRST_DAILY_STOCH':raw_stoch,'DAILY_STOCH_THEN_2D':seq}
            if eventual_2d is not None and (eventual_2d<arm or eventual_2d>=end):raise RuntimeError('Illegal 2D event')
            if seq is not None and eventual_2d is not None and seq<eventual_2d:
                raise RuntimeError('Sequential gate preceded original first 2D cross')
            for policy,signal in candidates.items():
                ev=fixed_event(d,arm,signal,horizon=126)
                if ev['status']=='FILLED':target=target_before_stop(d,ev)
                else:target='NOT_ENTERED'
                row={'symbol':sym,'panel':'CORE5' if sym in e.CORE else 'PEERS13',
                    'episode':watch_id,'arm_i':arm,'arm_date':str(ix[arm].date()),
                    'watch_end_i':end,'policy':policy,'status':ev['status'],
                    'signal_i':signal,'signal_date':str(ix[signal].date()) if signal is not None else None,
                    'target8':target,'beta_context_method':'W+2W confirmed phase0 200warmup',
                    'asof':'2026-10-08'}
                row.update({k:v for k,v in ev.items() if k in ['exit_date','baseline','net','incremental','delay','mae','mfe','entry_date','entry']})
                records.append(row)
                if policy=='FIRST_2D_MACDRSI':
                    # Reconciliation to original V11 frozen same-window market index.
                    base_reconciliation.append({'symbol':sym,'episode':watch_id,'arm_i':arm,
                                                 'signal_i':signal,'status':ev['status']})
        print('MASTER_WATCH_REPLAY',sym,flush=True)
    data=pd.DataFrame(records)
    assert len(data)==watch_arms*4 and watch_arms==198
    assert not data.duplicated(['symbol','episode','policy']).any()
    data.to_csv(THIS/'results/V30_FIXED_WATCH_EVENTS.csv',index=False)
    results=[]
    for (panel,policy),g in data.groupby(['panel','policy']):
        results.append({'panel':panel,'policy':policy,**summarize(g)})
    tbl=pd.DataFrame(results);tbl.to_csv(THIS/'results/V30_POLICY_SUMMARY.csv',index=False)
    full=[]
    for panel,g in data.groupby('panel'):
        base=g[g.policy=='FIRST_2D_MACDRSI']
        for policy in ['FIRST_DAILY_STOCH','DAILY_STOCH_THEN_2D']:
            other=g[g.policy==policy]
            pair=base[['symbol','episode','status','signal_i','net','baseline']].merge(other[['symbol','episode','status','signal_i','net','baseline']],on=['symbol','episode'],how='inner',validate='one_to_one',suffixes=('_2D','_'+policy))
            assert len(pair)==len(base)
            complete=pair[(pair.status_2D!='INCOMPLETE')&(pair['status_'+policy]!='INCOMPLETE')]
            # Equal-watch comparison, treating NO entry as cash, not missing.
            c=complete[['symbol','episode','net_2D','net_'+policy]].copy()
            c['delta']=c['net_'+policy]-c.net_2D
            c['alternative']=policy;c['panel']=panel
            full.append(c)
    pd.concat(full,ignore_index=True).to_csv(THIS/'results/V30_PAIRED_WATCH_DIFFERENCES.csv',index=False)
    receipt={'original_master_watch_rows_one_frame':watch_arms,
       'original_frozen_two_frame_rows':len(frozen),
       'policies':POLICIES,'event_rows':len(data),'unique_watches':watch_arms,
       'no_new_vendor_data':True,'no_change_to_original_2D_signals':True,
       'all_cash_on_skipped':True,'no_hindsight_only_successful_entries':True,
       'unobserved_future_endpoints_incomplete':True,
       'market_source_cutoff':'2026-10-08','source_vintage_already_reconciled':True,
       'original_user_chart_settings_unverified':True,'no_broker_orders':True}
    (THIS/'results/VERIFICATION.json').write_text(json.dumps(receipt,indent=2))
    print('V30_POLICY_CORE',tbl[tbl.panel=='CORE5'].round(6).to_json(orient='records'),flush=True)
    print('V30_POLICY_PEERS',tbl[tbl.panel=='PEERS13'].round(6).to_json(orient='records'),flush=True)
    print('V30_PROOF',json.dumps(receipt))
if __name__=='__main__':run()
