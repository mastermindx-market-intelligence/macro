"""V35 prospective-start, after-close paper freeze of W+2W long watch,
independent 1D StochRSI recovery and native 2D RSI-MACD confirmation.
Source: immutable V27 Oct13 19-symbol adjusted snapshot, no new data,
future outcomes or brokerage actions.
"""
from pathlib import Path
import sys,json,hashlib
from datetime import datetime,timezone
from zoneinfo import ZoneInfo
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parents[2]
THIS=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source'))
sys.path.insert(0,str(ROOT/'v11_published/source'))
sys.path.insert(0,str(ROOT/'v27/source'))
sys.path.insert(0,str(ROOT/'v28/source'))
sys.path.insert(0,str(ROOT/'v30/source'))
import v12_engine as prior
import empirical as e
import paper_asof as v27
import v28_daily_stoch as v28
import v30_master_watches as v30
ASOF='2026-10-13'
def state(active,trigger,last_i):
    if trigger is not None and (trigger<0 or trigger>last_i):raise ValueError('Future or invalid trigger')
    if not active:return {'status':'NO_ACTIVE_LONG_WATCH','broker_filled':False}
    if trigger is None:return {'status':'ACTIVE_WATCH_WAITING','broker_filled':False}
    if trigger==last_i:return {'status':'TODAY_CLOSED_SIGNAL_NEXT_OPEN_UNKNOWN','broker_filled':False}
    return {'status':'EARLIER_SIGNAL_NOT_POSITION','broker_filled':False}
def strict(bull,stoch_cross,recent_floor,k,d,arm,end,window=5):
    return v30.sequential(bull,stoch_cross,recent_floor,k,d,arm,end,window)
def do():
    frozen=json.loads((THIS/'SPEC.json').read_text())
    assert hashlib.sha256((ROOT/'v27/results/FREEZE_RECEIPT.json').read_bytes()).hexdigest()==frozen['original_v27_source_receipt_sha']
    assert hashlib.sha256((ROOT/'v27/results/NEW_VINTAGE_RECEIPT.json').read_bytes()).hexdigest()==frozen['original_v27_vendor_receipt_sha']
    assert hashlib.sha256((ROOT/'v30/SPEC.json').read_bytes()).hexdigest()==frozen['original_v30_spec_sha']
    provider=json.loads((ROOT/'v27/results/NEW_VINTAGE_RECEIPT.json').read_text())
    if not provider['all_expected_accepted'] or provider['stocks_accepted']!=19:raise RuntimeError('V27 vendor source not proven complete')
    now=datetime.now(timezone.utc)
    ny=now.astimezone(ZoneInfo('America/New_York'))
    if str(ny.date())!='2026-10-13':
        raise RuntimeError('Not October13 local anymore: cannot claim an October13 prospective freeze')
    original=prior.load_daily('SPY').index
    observed=original.append(pd.DatetimeIndex(prior.CALENDAR_TAIL[:3]))
    assert len(observed)==4220 and str(observed[-1].date())==ASOF
    tail=pd.DatetimeIndex(prior.CALENDAR_TAIL[3:])
    calendar=observed.append(tail)
    out=[];drift=[]
    for sym in e.STOCKS:
        px,meta=v27.load(sym,observed)
        close=px.close;ix=close.index
        daily=e.snapshots(close,calendar,'1D',mode='confirmed',phase=0)
        twod=e.snapshots(close,calendar,'2D',mode='confirmed',phase=0)
        stoch=v28.flags(daily.k,daily.d,window=5)
        daily_cross=(daily.k.gt(daily.d)&daily.k.shift(1).le(daily.d.shift(1))).fillna(False).to_numpy(bool)
        independent=daily_cross & stoch.recent_washout.to_numpy(bool)
        lower_bull=twod.bull.to_numpy(bool)
        for mode in ['confirmed','developing']:
            w,b,ctx=e.feature_context(px,calendar,mode=mode,phase=0,warmup=200)
            watches=v30.master_episodes(ctx,b.k.to_numpy(float),lower_bull,start_i=int(ix.searchsorted('2018-01-01')))
            last=watches[-1] if watches and watches[-1]['end_i']==len(ix) else None
            active=last is not None
            if active:
                arm=last['arm_i'];end=len(ix)
                first2D=last['signal_i']
                fstoch=v30.first_signal(independent,arm,end)
                seq=strict(lower_bull,daily_cross,stoch.recent_washout.to_numpy(bool),
                           daily.k.to_numpy(float),daily.d.to_numpy(float),arm,end,5)
            else:arm=None;first2D=None;fstoch=None;seq=None
            for policy,sig in [('FIRST_2D_MACDRSI',first2D),('FIRST_DAILY_STOCH',fstoch),('DAILY_STOCH_THEN_2D',seq)]:
                classification=state(active,sig,len(ix)-1)
                if sig is None:source_signal_date=None
                else:source_signal_date=str(ix[sig].date())
                out.append({'symbol':sym,'context_mode':mode,'policy':policy,'source_data_end':ASOF,
                  'source_vendor_status':'AFTER_CLOSE_VENDOR_UNATTESTED',
                  'freeze_utc':now.isoformat(),'freeze_eastern':ny.isoformat(),
                  'watch_active_at_cutoff':active,
                  'last_long_watch_arm':str(ix[arm].date()) if arm is not None else None,
                  'signal_date_in_active_watch':source_signal_date,
                  'signal_status':classification['status'],
                  'broker_filled':False,'live_recommendation':False,'actual_position_unknown':True,
                  'weekly_k':float(w.k.iloc[-1]) if pd.notna(w.k.iloc[-1]) else None,
                  'two_week_k':float(b.k.iloc[-1]) if pd.notna(b.k.iloc[-1]) else None,
                  'joint_context_now':bool(ctx[-1]),
                  'daily_stoch_k':float(daily.k.iloc[-1]) if pd.notna(daily.k.iloc[-1]) else None,
                  'daily_stoch_d':float(daily.d.iloc[-1]) if pd.notna(daily.d.iloc[-1]) else None,
                  'daily_recent_bottom_within_5_completed':bool(stoch.recent_washout.iloc[-1]),
                  'daily_kd_bull_recent5_inforce':bool(stoch.kd_cross_recent_inforce.iloc[-1]),
                  'daily_new_kd_bull_at_cutoff':bool(daily_cross[-1]),
                  'two_day_new_MACDRSI_bull_at_cutoff':bool(lower_bull[-1]),
                  'two_day_hist_at_cutoff':float(twod['hist'].iloc[-1]) if pd.notna(twod['hist'].iloc[-1]) else None,
                  'source_chart_parity':'NOT_PROVEN','next_session_open_from_Oct14':'NOT_OBSERVED'})
        drift.append({'symbol':sym,'new_snapshot_last_adjusted_close':meta['last_adjusted_close'],'date':meta['last']})
        print('PAPER_DUAL_PAIR',sym,flush=True)
    data=pd.DataFrame(out)
    assert len(data)==108 and not data.duplicated(['symbol','context_mode','policy']).any()
    assert not data.broker_filled.any() and not data.live_recommendation.any()
    data.to_csv(THIS/'results/V35_2026-10-13_DUAL_PAIR_PAPER_LEDGER.csv',index=False)
    data[(data.symbol.isin(e.CORE))].to_csv(THIS/'results/V35_CORE_PAPER_LEDGER.csv',index=False)
    status=data.groupby(['context_mode','policy','signal_status']).size().reset_index(name='count')
    status.to_csv(THIS/'results/V35_STATUS_COUNTS.csv',index=False)
    proof={'equity_data_cutoff':ASOF,'freeze_utc':now.isoformat(),'freeze_eastern':ny.isoformat(),
      'original_price_symbols':19,'stocks_scored':18,'lower_entry_rules':3,'long_context_modes':2,
      'total_paper_rows':len(data),'still_unknown_chart_parity':True,'future_Oct14_trading_outcome_observed':False,
      'source_vendor_finality':'AFTER_CLOSE_VENDOR_UNATTESTED',
      'source_v27_market_data_modified':False,'market_network_access':0,'broker_trades':0,'scheduled_monitor':False,
      'research_episode_model':'V30 master watches and flags as fixed before the first future outcome'}
    (THIS/'results/VERIFICATION.json').write_text(json.dumps(proof,indent=2))
    print('CORE_PAPER',data[(data.symbol.isin(e.CORE))&(data.context_mode=='confirmed')][['symbol','policy','watch_active_at_cutoff','signal_status','signal_date_in_active_watch','daily_recent_bottom_within_5_completed','daily_kd_bull_recent5_inforce','two_day_new_MACDRSI_bull_at_cutoff']].to_json(orient='records'))
    print('TOTAL_COUNTS',status.to_json(orient='records'))
    print('PAPER_FROZEN',json.dumps(proof))
if __name__=='__main__':do()
