"""V34 ex-ante SPY market-regime context for the ORIGINAL V30 master watches.
Market status observed at arm close only; subsequent stress labelled as future
outcome, never an entry gate. No raw data acquisition or live trading.
"""
from pathlib import Path
import json,hashlib,sys
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parents[2]
THIS=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source'))
sys.path.insert(0,str(ROOT/'v11_published/source'))
import v12_engine as native
import empirical as e
STATES=['SUPPORTED','TRANSITION','STRESS_REPAIR','STRESS_WORSENING']
def regimes(spy):
    return e.regimes(spy)
def spy_from_arm(d,arm,horizon=126,fee=.0005):
    if arm<0 or arm>=len(d):raise ValueError('Invalid event anchor')
    end=arm+horizon
    if end>=len(d):return None
    return float(d.close.iloc[end]/d.open.iloc[arm+1]*(1-fee)/(1+fee)-1)
def cash_or_trade_mean(g):
    ok=g[g.status!='INCOMPLETE']
    if not len(ok):return np.nan
    if ok.net.isna().any():raise ValueError('Incomplete net mislabeled complete')
    return float(ok.net.mean())
def future_stress_flag(regimes,arm,horizon=126):
    if arm<0 or arm+horizon>=len(regimes):raise ValueError('Unobserved future outcome')
    return bool(regimes.iloc[arm+1:arm+horizon+1].eq('STRESS_WORSENING').any())
def quarter_ci(group,rep=4000,block=4):
    if group.empty:return {'interval':None,'quarter_count':0}
    q=pd.to_datetime(group.arm_date).dt.to_period('Q')
    qs=pd.period_range(q.min(),q.max(),freq='Q')
    counts=group.assign(q=q).groupby('q').delta.agg(['sum','count']).reindex(qs,fill_value=0)
    active=int((counts['count']>0).sum())
    if active<8:return {'interval':None,'quarter_count':active}
    rng=np.random.default_rng(341013);n=len(qs)
    starts=rng.integers(0,n,size=(rep,int(np.ceil(n/block))))
    draw=((starts[:,:,None]+np.arange(block))%n).reshape(rep,-1)[:,:n]
    size=counts['count'].to_numpy()[draw].sum(axis=1)
    val=counts['sum'].to_numpy()[draw].sum(axis=1)
    good=size>0;x=val[good]/size[good]
    return {'interval':'exploratory_not_selected_adjusted','low':float(np.quantile(x,.025)),'high':float(np.quantile(x,.975)),'quarter_count':active}
def run():
    src=ROOT/'v30/results/V30_FIXED_WATCH_EVENTS.csv'
    assert hashlib.sha256(src.read_bytes()).hexdigest()==json.loads((THIS/'SPEC.json').read_text())['prior_event_sha256']
    d=pd.read_csv(src)
    assert len(d)==792
    px=native.load_daily('SPY');context=regimes(px)
    ix=px.index
    rows=[]
    for q in d.itertuples():
        i=int(q.arm_i)
        if str(ix[i].date())!=q.arm_date:raise ValueError('Arm date not aligned to SPY')
        state=context.market_regime.iloc[i]
        if state not in STATES:raise ValueError('Unknown market label')
        baseline=spy_from_arm(px,i,126)
        fully=baseline is not None
        if (q.status=='INCOMPLETE')!= (not fully):raise ValueError('Watch sample censoring differs by policy')
        future=future_stress_flag(context.market_regime,i,126) if fully else None
        rows.append({'symbol':q.symbol,'panel':q.panel,'episode':int(q.episode),
            'arm_i':i,'arm_date':q.arm_date,'entry_policy':q.policy,
            'arm_market_regime':state,'arm_spy126dd':float(context.market_drawdown.iloc[i]),
            'arm_spy20vol':float(context.market_vol.iloc[i]),
            'arm_spy10return':float(context.market_ret10.iloc[i]),
            'status':q.status,'net':q.net if fully else np.nan,
            'baseline_arm_spy126':baseline,'incremental_over_spy':float(q.net-baseline) if fully else np.nan,
            'stress_worsening_during_following126':future,'regime_is_entry_asof':True,
            'future_transition_is_outcome_only':True})
    data=pd.DataFrame(rows)
    assert not data.duplicated(['symbol','episode','entry_policy']).any()
    data.to_csv(THIS/'results/V34_REGIME_WATCH_EVENTS.csv',index=False)
    summary=[]
    for (panel,regime,policy),group in data.groupby(['panel','arm_market_regime','entry_policy']):
        complete=group[group.status!='INCOMPLETE'];filled=complete[complete.status=='FILLED'];skipped=complete[complete.status=='SKIPPED']
        summary.append({'panel':panel,'arm_market_regime':regime,'policy':policy,
            'watch_total':len(group),'watch_complete':len(complete),'watch_incomplete':len(group)-len(complete),
            'filled':len(filled),'skipped':len(skipped),
            'all_watch_mean_cash_trade':cash_or_trade_mean(group),
            'all_watch_mean_spy_baseline':float(complete.baseline_arm_spy126.mean()) if len(complete) else None,
            'all_watch_incremental_spy':float(complete.incremental_over_spy.mean()) if len(complete) else None,
            'filled_positive_rate':float(filled.net.gt(0).mean()) if len(filled) else None,
            'pct_future_stress_worsening':float(complete.stress_worsening_during_following126.mean()) if len(complete) else None,
            'complete_unique_quarters':pd.to_datetime(complete.arm_date).dt.to_period('Q').nunique() if len(complete) else 0,
            'NOTE':'DESCRIPTIVE; small cells not optimized as hard regime veto'})
    pd.DataFrame(summary).to_csv(THIS/'results/V34_REGIME_POLICY_SUMMARY.csv',index=False)
    paired=[]
    for panel in ['CORE5','PEERS13']:
        for regime in STATES:
            group=data[(data.panel==panel)&(data.arm_market_regime==regime)]
            ref=group[group.entry_policy=='FIRST_2D_MACDRSI'][['symbol','episode','arm_date','status','net']].rename(columns={'status':'status_2D','net':'net_2D'})
            for alt in ['WATCH_IMMEDIATE','FIRST_DAILY_STOCH','DAILY_STOCH_THEN_2D']:
                a=group[group.entry_policy==alt][['symbol','episode','arm_date','status','net']].rename(columns={'status':'status_alt','net':'net_alt'})
                x=ref.merge(a,on=['symbol','episode','arm_date'],how='outer',validate='one_to_one',indicator=True)
                if not x.empty and not x._merge.eq('both').all():raise ValueError('Regime mismatched original opportunity')
                y=x[(x.status_2D!='INCOMPLETE')&(x.status_alt!='INCOMPLETE')].copy()
                y['delta']=y.net_alt-y.net_2D
                ci=quarter_ci(y)
                paired.append({'panel':panel,'regime':regime,'entry_alternative':alt,
                    'n_original':len(group[group.entry_policy==alt]),'n_complete_paired':len(y),
                    'mean_alternative_minus_2D':float(y.delta.mean()) if len(y) else None,
                    'interval_low':ci.get('low'),'interval_high':ci.get('high'),
                    'interval_status':ci['interval'],'active_quarters':ci['quarter_count']})
    pd.DataFrame(paired).to_csv(THIS/'results/V34_PAIRED_CONTEXT.csv',index=False)
    audit={'source_master_episode_count':198,'duplicated_by_four_entry_policies':len(data),
           'source_regime_definition':'V11 trailing SPY drawdown/vol/direction, known at watch arm close',
           'fully_known_endpoint_count':int(data.status.ne('INCOMPLETE').sum()),
           'model_selection':'Not selected for prediction or sizing',
           'future_stress_not_input_to_entry':True,'no_new_data':True,'no_orders':True}
    (THIS/'results/VERIFICATION.json').write_text(json.dumps(audit,indent=2))
    out=pd.read_csv(THIS/'results/V34_REGIME_POLICY_SUMMARY.csv')
    v=pd.read_csv(THIS/'results/V34_PAIRED_CONTEXT.csv')
    print('CORE_REGIMES',out[(out.panel=='CORE5')&(out.policy.isin(['FIRST_2D_MACDRSI','FIRST_DAILY_STOCH','DAILY_STOCH_THEN_2D']))][['arm_market_regime','policy','watch_complete','filled','all_watch_mean_cash_trade','all_watch_mean_spy_baseline','all_watch_incremental_spy','pct_future_stress_worsening']].round(6).to_json(orient='records'))
    print('CORE_PAIRED',v[v.panel=='CORE5'].round(6).to_json(orient='records'))
    print('PROOF',json.dumps(audit))
if __name__=='__main__':run()
