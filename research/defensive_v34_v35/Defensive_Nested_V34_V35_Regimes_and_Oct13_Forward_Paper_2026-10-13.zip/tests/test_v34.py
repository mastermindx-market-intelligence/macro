"""V34 ex-ante market-regime grouping and common-end SPY benchmarks."""
import unittest,sys
from pathlib import Path
import pandas as pd,numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import v34_regime as m
class Regime(unittest.TestCase):
 def dates(self):
  return pd.bdate_range('2018-01-02',periods=260)
 def prices(self):
  ix=self.dates()
  c=100*np.exp(np.arange(260)*.001)
  return pd.DataFrame({'open':c,'high':c*1.01,'low':c*.99,'close':c},index=ix)
 def test_forward_prices_not_in_arm_regime(self):
  d=self.prices();x=m.regimes(d)
  old=x.market_regime.iloc[220]
  d.loc[d.index[221]:,'close']=1.
  self.assertEqual(m.regimes(d).market_regime.iloc[220],old)
 def test_asof_regime_provisional_cannot_use_tomorrow(self):
  d=self.prices()
  a=m.regimes(d).iloc[221].market_regime
  d.iloc[-1,d.columns.get_loc('close')]=1e5
  self.assertEqual(m.regimes(d).iloc[221].market_regime,a)
 def test_spy_same_arm_endpoint(self):
  d=self.prices()
  z=m.spy_from_arm(d,10,126)
  self.assertAlmostEqual(z,d.close.iloc[136]/d.open.iloc[11]*.9995/1.0005-1)
 def test_spy_incomplete_unknown(self):
  d=self.prices()
  self.assertIsNone(m.spy_from_arm(d,240,126))
 def test_immediate_cash_event_not_deleted(self):
  d=pd.DataFrame({'net':[.12,0.,-.08],'status':['FILLED','SKIPPED','FILLED']})
  self.assertAlmostEqual(m.cash_or_trade_mean(d),(.12+0-.08)/3)
 def test_event_unknown_not_loss(self):
  d=pd.DataFrame({'net':[.12,float('nan')],'status':['FILLED','INCOMPLETE']})
  self.assertAlmostEqual(m.cash_or_trade_mean(d),.12)
 def test_future_stress_is_not_contemporaneous_signal(self):
  d=self.prices();r=m.regimes(d)
  a=m.future_stress_flag(r.market_regime,10,30)
  self.assertIsInstance(a,bool)
  with self.assertRaises(ValueError):m.future_stress_flag(r.market_regime,10,300)
if __name__=='__main__':unittest.main(verbosity=2)