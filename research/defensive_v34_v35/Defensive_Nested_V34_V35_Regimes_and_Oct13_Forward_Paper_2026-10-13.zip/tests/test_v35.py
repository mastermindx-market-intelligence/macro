"""V35 paper snapshot classification—nothing is an executed trade."""
import unittest,sys
from pathlib import Path
import pandas as pd,numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import v35_snapshot as q
class V35(unittest.TestCase):
 def test_no_long_watch_cannot_have_new_order(self):
  self.assertEqual(q.state(False,None,4219)['status'],'NO_ACTIVE_LONG_WATCH')
 def test_no_short_confirmation(self):
  self.assertEqual(q.state(True,None,4219)['status'],'ACTIVE_WATCH_WAITING')
 def test_today_signal_requires_future_open(self):
  a=q.state(True,4219,4219)
  self.assertEqual(a['status'],'TODAY_CLOSED_SIGNAL_NEXT_OPEN_UNKNOWN');self.assertFalse(a['broker_filled'])
 def test_prior_signal_does_not_imply_position(self):
  a=q.state(True,4218,4219)
  self.assertEqual(a['status'],'EARLIER_SIGNAL_NOT_POSITION');self.assertFalse(a['broker_filled'])
 def test_future_signal_refused(self):
  with self.assertRaises(ValueError):q.state(True,4220,4219)
 def test_signal_on_day_still_uses_only_completed_native(self):
  b=np.array([False,True,False,True,False],bool)
  s=np.array([True,False,False,False,False],bool)
  floor=np.array([True]*5)
  k=np.array([10,30,40,50,60.])
  d=np.array([20,20,20,20,20.])
  self.assertIsNone(q.strict(b,s,floor,k,d,arm=1,end=5,window=5))
 def test_lookahead_other_daily_bars_cannot_create_prior_trigger(self):
  bull=np.array([False,False,True,False,False])
  cross=np.array([False,True,False,False,True])
  low=np.array([True]*5)
  k=np.array([10,20,30,30,45.]);d=np.array([30,30,30,30,30.])
  old=q.strict(bull,cross,low,k,d,arm=0,end=4,window=5)
  k[-1]=1000.
  self.assertEqual(old,q.strict(bull,cross,low,k,d,arm=0,end=4,window=5))
if __name__=='__main__':unittest.main(verbosity=2)