"""V19 posthoc comparison of early 20-session and intermediate 63-session excess.
No optimization: same frozen events and explicit time clusters.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
def paired(d,early=20,late=63):
    p=d[d.horizon.isin([early,late])].copy()
    keys=['symbol','frame','episode','signal_date']
    if p.duplicated(keys+['horizon']).any():raise ValueError('Duplicate event horizon')
    z=p.pivot(index=keys,columns='horizon',values=['relative_four','relative_spy'])
    if len(z)*2!=len(p) or z.isna().any().any():raise ValueError('Missing paired horizon')
    z.columns=[f'{f}_{"early" if int(h)==early else "late"}' for f,h in z.columns]
    z=z.reset_index()
    z['incremental_relative_four']=z['relative_four_late']-z['relative_four_early']
    z['incremental_relative_spy']=z['relative_spy_late']-z['relative_spy_early']
    return z
def block_ci(df,rep=4000,block=4):
    if df.empty:return {'interval':None,'active_quarters':0}
    q=pd.to_datetime(df.signal_date).dt.to_period('Q')
    full=pd.period_range(q.min(),q.max(),freq='Q')
    x=df.assign(q=q).groupby('q').incremental_relative_four.agg(['sum','count']).reindex(full,fill_value=0)
    active=int((x['count']>0).sum())
    if active<8:return {'interval':None,'active_quarters':active}
    rng=np.random.default_rng(191013);n=len(full);st=rng.integers(0,n,size=(rep,int(np.ceil(n/block))))
    ids=((st[:,:,None]+np.arange(block))%n).reshape(rep,-1)[:,:n]
    ct=x['count'].to_numpy()[ids].sum(axis=1);sm=x['sum'].to_numpy()[ids].sum(axis=1)
    samples=sm[ct>0]/ct[ct>0]
    return {'interval':'exploratory','active_quarters':active,'low':float(np.quantile(samples,.025)),'high':float(np.quantile(samples,.975)),'replicates':rep}
def run():
    d=pd.read_csv(ROOT/'results/v18_paths.csv')
    x=paired(d);x.to_csv(ROOT/'results/v19_events.csv',index=False)
    out=[]
    for frame,g in x.groupby('frame'):
        e=block_ci(g);year=pd.to_datetime(g.signal_date).dt.year
        leave=[float(g[year!=y].incremental_relative_four.mean()) for y in sorted(year.unique())]
        out.append({'frame':frame,'period':'ALL','n':len(g),'mean_relative_four20':float(g.relative_four_early.mean()),'mean_relative_four63':float(g.relative_four_late.mean()),'incremental_rel_four_mean':float(g.incremental_relative_four.mean()),'incremental_rel_spy_mean':float(g.incremental_relative_spy.mean()),'fraction_late_advantage_grows':float((g.incremental_relative_four>0).mean()),'leave_year_out_min':min(leave),'leave_year_out_max':max(leave),'interval_low':e.get('low'),'interval_high':e.get('high'),'active_quarters':e.get('active_quarters')})
        for group,gg in g.groupby(np.where(year<=2022,'2018_2022','2023_2026')):
            out.append({'frame':frame,'period':group,'n':len(gg),'mean_relative_four20':float(gg.relative_four_early.mean()),'mean_relative_four63':float(gg.relative_four_late.mean()),'incremental_rel_four_mean':float(gg.incremental_relative_four.mean()),'incremental_rel_spy_mean':float(gg.incremental_relative_spy.mean()),'fraction_late_advantage_grows':float((gg.incremental_relative_four>0).mean()),'active_quarters':pd.to_datetime(gg.signal_date).dt.to_period('Q').nunique()})
    pd.DataFrame(out).to_csv(ROOT/'results/v19_summary.csv',index=False)
    print('V19_RESULTS',pd.DataFrame(out).round(6).to_json(orient='records'))
    print('V19_META',json.dumps({'paired_events':len(x),'comparisons':[20,63],'preserve_frozen_signals':True,'no_network':True}))
if __name__=='__main__':run()
