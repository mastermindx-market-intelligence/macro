"""V16 deterministic counterfactuals using frozen V11 entry opportunities.
No network, broker, live sizing, or parameter fitting.
"""
from pathlib import Path
import sys,json
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[2]
THIS=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source'))
import v12_engine as original
import peer_control_v15 as peer
CORE=['MCD','WMT','WM','COST','PG']
FEES=.0005
def beta_before_signal(stock,spy,position,lookback=252,min_obs=200):
    if not stock.index.equals(spy.index):raise ValueError('Mismatched market dates')
    if position>=len(stock) or position<0:raise ValueError('Signal index invalid')
    a=np.log(stock.astype(float)).diff().iloc[max(0,position-lookback):position]
    b=np.log(spy.astype(float)).diff().iloc[max(0,position-lookback):position]
    valid=(np.isfinite(a)&np.isfinite(b))
    if int(valid.sum())<min_obs:return np.nan
    aa=a[valid].to_numpy(float);bb=b[valid].to_numpy(float);den=float(np.var(bb))
    if den<1e-12:return np.nan
    return float(np.cov(aa,bb,ddof=0)[0,1]/den)
def beta_adjusted_log(stock_log_net,beta,spy_log_gross):
    if not np.isfinite([stock_log_net,beta,spy_log_gross]).all():return np.nan
    return float(stock_log_net-beta*spy_log_gross)
def shuffle_lags(years,delays,rng):
    years=np.asarray(years);delays=np.asarray(delays,int)
    if len(years)!=len(delays):raise ValueError('Cohort size mismatch')
    out=delays.copy()
    for k in np.unique(years):
        ids=np.flatnonzero(years==k)
        out[ids]=rng.permutation(delays[ids])
    return out
def net_at_delay(d,arm_i,endpoint_i,delay,fee=FEES):
    entry_i=int(arm_i+delay+1)
    if delay<0 or arm_i<0 or endpoint_i>=len(d) or entry_i>endpoint_i or entry_i>=len(d):raise ValueError('Entry occurs outside allowed watch')
    return float(d.close.iloc[endpoint_i]/d.open.iloc[entry_i]*(1-fee)/(1+fee)-1)
def calc():
    path=ROOT/'v11_published/results/primary_labeled_events.csv'
    base=pd.read_csv(path)
    base=base[(base['mode']=='confirmed')&(base['warmup']==200)&(base['two_week_phase']==0)&(base['lower_phase']==0)&(base['horizon']==126)&base.symbol.isin(CORE)&base.frame.isin(['1D','2D'])]
    source=base[base.status=='FILLED'].copy()
    prices={s:original.load_daily(s) for s in CORE+['SPY']}
    ix=prices['SPY'].index
    for d in prices.values():
        assert d.index.equals(ix)
    rows=[]
    for t in source.itertuples():
        arm_i=int(ix.get_loc(pd.Timestamp(t.arm_date)));sig_i=int(ix.get_loc(pd.Timestamp(t.signal_date)));z=int(ix.get_loc(pd.Timestamp(t.exit_date)));lag=int(sig_i-arm_i)
        assert 0<=lag<42
        ent=ix[sig_i+1]
        assert str(ent.date())==t.entry_date
        r={s:net_at_delay(prices[s],arm_i,z,lag) for s in CORE}
        sel=float(r[t.symbol]);assert abs(sel-t.net)<1e-5
        spylog=float(np.log(prices['SPY'].close.iloc[z]/prices['SPY'].open.iloc[sig_i+1]))
        betas={s:beta_before_signal(prices[s].close,prices['SPY'].close,sig_i) for s in CORE}
        residuals={s:beta_adjusted_log(np.log1p(r[s]),betas[s],spylog) for s in CORE}
        selected=float(residuals[t.symbol]);others=float(np.mean([residuals[s] for s in CORE if s!=t.symbol]))
        rows.append({'symbol':t.symbol,'frame':t.frame,'episode':int(t.episode),'arm_date':t.arm_date,'signal_date':t.signal_date,'entry_date':t.entry_date,'exit_date':t.exit_date,'arm_i':arm_i,'signal_i':sig_i,'endpoint_i':z,'lag':lag,'arm_year':int(pd.Timestamp(t.arm_date).year),'net':sel,'original_v11_net_error':sel-t.net,'spy_log_gross':spylog,'beta_selected':betas[t.symbol],'beta_neutral_selected':selected,'beta_neutral_other_four':others,'beta_neutral_spread':selected-others,'raw_selected_vs_other_four':sel-np.mean([r[s] for s in CORE if s!=t.symbol])})
    events=pd.DataFrame(rows)
    assert len(events)==100 and events.original_v11_net_error.abs().max()<1e-5
    events.to_csv(THIS/'results/v16_frozen_events.csv',index=False)
    out=[];nulls=[]
    rng=np.random.default_rng(16013)
    for frame,g in events.groupby('frame'):
        g=g.reset_index(drop=True)
        yrs=g.arm_year.to_numpy(int);actual_delay=g.lag.to_numpy(int)
        names=g.symbol.to_numpy()
        # Precomputed common-endpoint payoff for each counterfactual delay, no re-arms.
        feasible=np.arange(42); matrix=np.empty((len(g),len(feasible)))
        for i,t in enumerate(g.itertuples()):
            d=prices[t.symbol]
            for delay in feasible:matrix[i,int(delay)]=net_at_delay(d,t.arm_i,t.endpoint_i,int(delay))
        actual=matrix[np.arange(len(g)),actual_delay]
        assert np.max(abs(actual-g.net.to_numpy()))<1e-12
        N=5000;dist=np.empty(N)
        for z in range(N):
            perm=shuffle_lags(yrs,actual_delay,rng)
            dist[z]=float(matrix[np.arange(len(g)),perm].mean())
        nulls.extend({'frame':frame,'replicate':z,'return_mean':float(x)} for z,x in enumerate(dist))
        gaps=actual.mean()-dist.mean()
        groups=pd.Series(yrs).value_counts()
        idx=g.groupby('arm_year').size()
        core_res=g.beta_neutral_selected.to_numpy()
        peer_res=g.beta_neutral_spread.to_numpy()
        cb=peer.block_ci(g.rename(columns={'beta_neutral_spread':'spread'}),rep=4000,block=4)
        row={'frame':frame,'events':len(g),'signal_first_mean':float(actual.mean()),'shuffled_delay_mean':float(dist.mean()),'signal_minus_shuffled_delay':float(gaps),'shuffle_low':float(np.quantile(dist,.025)),'shuffle_high':float(np.quantile(dist,.975)),'shuffle_better_fraction':float((dist>=actual.mean()).mean()),'years':int(len(idx)),'years_with_2plus':int((idx>=2).sum()),'year_blocks_variable':int(sum((len(gr)>1 and gr.lag.nunique()>1) for _,gr in g.groupby('arm_year'))),'median_actual_delay':float(np.median(actual_delay)),'avg_delay':float(np.mean(actual_delay)),'beta_neutral_selected_log_mean':float(np.mean(core_res)),'beta_neutral_other4_spread_log_mean':float(np.mean(peer_res)),'beta_neutral_spread_block_low':cb.get('low'),'beta_neutral_spread_block_high':cb.get('high'),'beta_ci_quarters':cb['active_quarters']}
        out.append(row)
    pd.DataFrame(out).to_csv(THIS/'results/v16_summary.csv',index=False)
    pd.DataFrame(nulls).to_csv(THIS/'results/v16_null_draws.csv',index=False)
    from collections import Counter
    m={'input_window':'Original V11 entries/arm endpoint and separately accepted V12 2010+ revised vintage','no_new_price_acquisition':True,'original_complete_entries':int(len(source)),'all_fixed_watch_rows':int(len(base)),'skipped':int((base.status=='SKIPPED').sum()),'incomplete':int((base.status=='INCOMPLETE').sum()),'v11_max_abs_reconcile':float(events.original_v11_net_error.abs().max()),'beta_lags':'252 preceding completed daily returns, no signal/future observation','shuffle':'within arm-year across core stocks, fixed exact watch and terminal dates; counterfactual not ex-ante trade','selection':'after V11–V15 inspected results; no inferential alpha claim','cross_stock_market_time':False}
    (THIS/'results/v16_verification.json').write_text(json.dumps(m,indent=2))
    print('V16_RESULTS',pd.DataFrame(out).round(6).to_json(orient='records'))
    print('V16_VERIFICATION',json.dumps(m))
if __name__=='__main__':calc()
