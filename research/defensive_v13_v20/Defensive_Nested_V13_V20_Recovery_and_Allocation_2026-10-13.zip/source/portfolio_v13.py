"""V13 equal-initial-capital sleeve aggregation; read-only research.
No parameter fitting, production change, or network fetch.
"""
from pathlib import Path
import json,hashlib
import pandas as pd
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
POLICIES=['HOLD','ATR3','ATR6','STRUCTURE_ATR6','STRUCTURE_MOMENTUM_ATR6','STAGED_ATR6']
CORE=['MCD','WMT','WM','COST','PG']
PEERS=['RSG','KO','PEP','CL','CHD','KMB','MDLZ','HSY','CLX','JNJ','ADP','CTAS','KR']
def combine(events,symbols):
    d=events[events.symbol.isin(symbols)].copy()
    if d.empty or set(d.symbol)!=set(symbols):raise ValueError('Missing required symbol(s)')
    try:d.date=pd.to_datetime(d.date,format='%Y-%m-%d',errors='raise')
    except Exception as e:raise ValueError('Invalid daily timestamp') from e
    if d.duplicated(['symbol','date']).any():raise ValueError('Duplicate symbol/date')
    q=d.pivot(index='date',columns='symbol',values='equity').sort_index()
    w=d.pivot(index='date',columns='symbol',values='exposure').sort_index()
    if not q.columns.equals(w.columns) or q.isna().any().any() or w.isna().any().any() or not (q>0).all().all():raise ValueError('Missing/nonpositive equity or exposure')
    if not ((w>=0)&(w<=1)).all().all():raise ValueError('Position fraction invalid')
    wealth=q.sum(axis=1)/len(symbols)
    exposure=(q*w).sum(axis=1)/q.sum(axis=1)
    return pd.DataFrame({'equity':wealth,'exposure':exposure},index=q.index)
def align_to_account_window(raw,index):
    ix=pd.DatetimeIndex(index)
    if not ix.is_unique or not ix.is_monotonic_increasing:raise ValueError('Bad account calendar')
    out=raw.reindex(ix)
    if out.isna().any():raise ValueError('Benchmark missing required account session')
    return out
def buyhold_for_account(d,index,fee=.0005):
    ix=pd.DatetimeIndex(index)
    if not ix.is_unique or not ix.is_monotonic_increasing:raise ValueError('Bad account calendar')
    if not ix.isin(d.index).all():raise ValueError('Missing benchmark session')
    sub=d.loc[ix]
    return buyhold_curve(sub,fee)
def cash_curve(index):
    return pd.Series(1.,index=index)
def buyhold_curve(d,fee=.0005):
    if len(d)<2 or d[['open','close']].isna().any().any() or (d[['open','close']]<=0).any().any():raise ValueError('Bad benchmark OHLC')
    return d.close.astype(float)/(float(d.open.iloc[0])*(1+fee))
def metrics(curve):
    eq=curve.equity if isinstance(curve,pd.DataFrame) else curve
    if len(eq)<2:raise ValueError('Too few dates')
    if (eq<=0).any() or eq.isna().any():raise ValueError('Invalid wealth')
    period=(eq.index[-1]-eq.index[0]).days/365.25
    # Capital starts at 1 immediately before first close; equity first close may include entry cost.
    total=float(eq.iloc[-1]);ret=eq.pct_change().dropna()
    out={'ending_equity':total,'cagr':total**(1/period)-1,'max_dd':float((eq/eq.cummax()-1).min()),'annualized_daily_vol':float(ret.std(ddof=1)*np.sqrt(252)),'daily_downside_fraction':float((ret<0).mean())}
    if isinstance(curve,pd.DataFrame) and 'exposure' in curve:out['time_avg_marked_exposure']=float(curve.exposure.mean())
    return out

def run():
    import sys
    sys.path.insert(0,str(ROOT/'source'))
    import v12_engine as v
    raw=ROOT/'results'/'account_daily.csv.gz'
    cols=['date','equity','exposure','symbol','panel','frame','policy','normalization','cost_bps']
    d=pd.read_csv(raw,usecols=cols)
    print('INPUT',len(d),'daily rows',flush=True)
    groups={'CORE5':CORE,'PEERS13':PEERS,'ALL18':CORE+PEERS}
    pairs=[];curves=[];ids=[]
    for name,syms in groups.items():
        idx=pd.DatetimeIndex(sorted(pd.to_datetime(d[(d.symbol==syms[0])&(d.frame=='1D')&(d.policy=='HOLD')&(d.normalization=='FULL_CAPITAL')&(d.cost_bps==10)].date.unique())))
        bench_cols=[]
        for s in syms:
            z=v.load_daily(s);base=buyhold_for_account(z,idx);bench_cols.append(base.rename(s))
        ref=pd.concat(bench_cols,axis=1)
        bh=ref.mean(axis=1);spy=buyhold_for_account(v.load_daily('SPY'),idx)
        reference={'BUYHOLD_EQUAL_INITIAL':bh,'SPY_BUYHOLD':spy,'CASH_ZERO_YIELD':cash_curve(bh.index)}
        for tag,series in reference.items():
            q=metrics(series)
            pairs.append({'panel':name,'frame':'ALL','policy':tag,'normalization':'FULL_CAPITAL',**q,'time_avg_marked_exposure':1. if tag!='CASH_ZERO_YIELD' else 0.})
        for frame in ['1D','2D']:
            for policy in POLICIES:
                for norm in (['FULL_CAPITAL'] if policy=='HOLD' else ['FULL_CAPITAL','STOP_RISK_1PCT']):
                    subset=d[(d.symbol.isin(syms))&(d.frame==frame)&(d.policy==policy)&(d.normalization==norm)&(d.cost_bps==10)]
                    comp=combine(subset,syms)
                    assert comp.index.equals(bh.index)
                    q=metrics(comp);q.update(panel=name,frame=frame,policy=policy,normalization=norm)
                    q['vs_same_stocks_buyhold_cagr_pp']=(q['cagr']-metrics(bh)['cagr'])*100
                    q['vs_same_stocks_buyhold_max_dd_pp']=(q['max_dd']-metrics(bh)['max_dd'])*100
                    pairs.append(q)
                    curves.append(pd.DataFrame({'date':comp.index.strftime('%Y-%m-%d'),'equity':comp.equity.values,'market_exposure':comp.exposure.values,'panel':name,'frame':frame,'policy':policy,'normalization':norm}))
    out=pd.DataFrame(pairs);out.to_csv(ROOT/'results'/'portfolio_v13_summary.csv',index=False)
    pd.concat(curves,ignore_index=True).to_csv(ROOT/'results'/'portfolio_v13_daily.csv.gz',index=False,compression='gzip')
    print('CORE_SUMMARY',out[(out.panel=='CORE5')&((out.frame=='1D')|(out.policy.isin(['BUYHOLD_EQUAL_INITIAL','SPY_BUYHOLD','CASH_ZERO_YIELD'])))][['policy','normalization','ending_equity','cagr','max_dd','time_avg_marked_exposure','vs_same_stocks_buyhold_cagr_pp']].round(5).to_json(orient='records'),flush=True)
    print('SUMMARY',json.dumps({'rows':len(out),'daily_curve_rows':sum(len(x) for x in curves),'original_v12_digest':hashlib.sha256(raw.read_bytes()).hexdigest(),'no_new_market_data':True},indent=2))
if __name__=='__main__':run()
