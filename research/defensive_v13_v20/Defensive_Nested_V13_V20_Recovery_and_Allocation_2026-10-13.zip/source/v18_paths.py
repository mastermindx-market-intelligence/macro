"""V18 bounded post-entry paths for frozen V11 entries; no fitted trades."""
from pathlib import Path
import sys,json
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[2];THIS=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'source'))
import v12_engine as original
CORE=['MCD','WMT','WM','COST','PG']
WINDOWS=[5,10,20,42,63]
def horizon(d,j,n,fee=.0005):
    if j<0 or j>=len(d):raise ValueError('Entry out of price history')
    last=j+n-1
    if last>=len(d):return {'status':'INCOMPLETE'}
    p=float(d.open.iloc[j]);segment=d.iloc[j:last+1];mn=segment.low.to_numpy(float);mx=segment.high.to_numpy(float)
    if p<=0 or not np.isfinite(p):raise ValueError('Entry price invalid')
    val=float(d.close.iloc[last]/p*(1-fee)/(1+fee)-1)
    return {'status':'COMPLETE','net':val,'mae':float(mn.min()/p-1),'mfe':float(mx.max()/p-1),'lowest_i':int(j+np.argmin(mn)),'days_until_min':int(np.argmin(mn)),'end_date':str(d.index[last].date())}
def run():
    e=pd.read_csv(THIS/'results/v16_frozen_events.csv')
    prices={s:original.load_daily(s) for s in CORE+['SPY']}
    rows=[]
    for t in e.itertuples():
        ix=prices[t.symbol].index;entry_i=int(ix.get_loc(pd.Timestamp(t.entry_date)))
        for h in WINDOWS:
            selected=horizon(prices[t.symbol],entry_i,h)
            peer=[horizon(prices[s],entry_i,h) for s in CORE if s!=t.symbol]
            spy=horizon(prices['SPY'],entry_i,h)
            assert selected['status']=='COMPLETE' and spy['status']=='COMPLETE' and all(x['status']=='COMPLETE' for x in peer)
            rows.append({'symbol':t.symbol,'frame':t.frame,'episode':t.episode,'signal_date':t.signal_date,'entry_date':t.entry_date,'horizon':h,'selected_net':selected['net'],'other_four_net_mean':float(np.mean([x['net'] for x in peer])),'spy_net':spy['net'],'relative_four':float(selected['net']-np.mean([x['net'] for x in peer])),'relative_spy':float(selected['net']-spy['net']),'selected_mae':selected['mae'],'selected_mfe':selected['mfe'],'selected_days_till_low':selected['days_until_min'],'selected_dipped_5pct':selected['mae']<=-.05,'end_date':selected['end_date']})
    d=pd.DataFrame(rows);assert len(d)==500
    d.to_csv(THIS/'results/v18_paths.csv',index=False)
    out=[]
    for (frame,h),g in d.groupby(['frame','horizon']):
        out.append({'frame':frame,'horizon':int(h),'n':len(g),'positive_fraction':float((g.selected_net>0).mean()),'mean_net':float(g.selected_net.mean()),'median_net':float(g.selected_net.median()),'other_four_mean':float(g.other_four_net_mean.mean()),'spy_mean':float(g.spy_net.mean()),'relative_four_mean':float(g.relative_four.mean()),'relative_spy_mean':float(g.relative_spy.mean()),'median_mae':float(g.selected_mae.median()),'dipped_5pct_fraction':float(g.selected_dipped_5pct.mean()),'median_days_to_min':float(g.selected_days_till_low.median())})
    summary=pd.DataFrame(out);summary.to_csv(THIS/'results/v18_summary.csv',index=False)
    # Stop risk versus subsequent closed recovery, without reselecting trades.
    early=d[d.horizon==20][['symbol','frame','episode','selected_dipped_5pct']]
    later=d[d.horizon==63][['symbol','frame','episode','selected_net']]
    joined=early.merge(later,on=['symbol','frame','episode'],validate='one_to_one')
    diag=[]
    for frame,g in joined.groupby('frame'):
        diag.append({'frame':frame,'n':len(g),'under5_first20':int(g.selected_dipped_5pct.sum()),'under5_then_positive63':int((g.selected_dipped_5pct&(g.selected_net>0)).sum()),'no_under5_then_positive63':int(((~g.selected_dipped_5pct)&(g.selected_net>0)).sum()),'fraction_eventual_positive_after_dip':float((g[g.selected_dipped_5pct].selected_net>0).mean())})
    pd.DataFrame(diag).to_csv(THIS/'results/v18_drawdown_then_recovery.csv',index=False)
    print('V18_PATHS',summary.round(5).to_json(orient='records'))
    print('V18_DIP_RECOVERY',pd.DataFrame(diag).to_json(orient='records'))
    print('V18_CHECK',json.dumps({'input_entries':len(e),'rows':len(d),'endpoints':WINDOWS,'no_new_acquisition':True,'same_entry_date_other_four_and_SPY':True}))
if __name__=='__main__':run()
