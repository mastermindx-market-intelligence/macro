"""V15 matched-date cross-sectional controls for frozen V11 first entries.
Uses already accepted V12 2010+ vendor snapshot and V11 derived outcomes only.
"""
from pathlib import Path
import sys,json
import numpy as np
import pandas as pd
import portfolio_v13 as p
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'source'))
import v12_engine as v
C=p.CORE
def net_interval(d,entry_date,exit_date,fee=.0005):
 s=pd.Timestamp(entry_date);z=pd.Timestamp(exit_date)
 if s>=z or s not in d.index or z not in d.index:raise ValueError('Invalid known session interval')
 return float(d.loc[z,'close']/d.loc[s,'open']*(1-fee)/(1+fee)-1)
def compare(per_stock,selected):
 if set(per_stock)!=set(C) or selected not in C:raise ValueError('Exactly five original symbols required')
 return float(per_stock[selected]-np.mean([per_stock[s] for s in C if s!=selected]))
def block_ci(df,rep=4000,block=4):
 if df.empty:return {'interval':None,'active_quarters':0}
 q=pd.to_datetime(df.signal_date).dt.to_period('Q')
 ix=pd.period_range(q.min(),q.max(),freq='Q')
 z=df.assign(quarter=q).groupby('quarter').spread.agg(['sum','count']).reindex(ix,fill_value=0)
 active=int((z['count']>0).sum())
 if active<8:return {'interval':None,'active_quarters':active}
 rng=np.random.default_rng(151013);n=len(ix)
 st=rng.integers(0,n,size=(rep,int(np.ceil(n/block))))
 draws=((st[:,:,None]+np.arange(block))%n).reshape(rep,-1)[:,:n]
 counts=z['count'].to_numpy()[draws].sum(axis=1);nums=z['sum'].to_numpy()[draws].sum(axis=1)
 vals=nums[counts>0]/counts[counts>0]
 return {'interval':'exploratory_paired_quarters','low':float(np.quantile(vals,.025)),'high':float(np.quantile(vals,.975)),'active_quarters':active,'rep':rep,'block_quarters':block}
def run():
 d=pd.read_csv(ROOT/'v11_published/results/primary_labeled_events.csv')
 events=d[(d['mode']=='confirmed')&(d['warmup']==200)&(d['two_week_phase']==0)&(d['lower_phase']==0)&(d['horizon']==126)&d.symbol.isin(C)&d.frame.isin(['1D','2D'])].copy()
 assert not events.duplicated(['symbol','frame','episode']).any()
 source=events[events.status=='FILLED'].copy()
 prices={s:v.load_daily(s) for s in C+['SPY']}
 rows=[]
 for t in source.itertuples():
  ret={s:net_interval(prices[s],t.entry_date,t.exit_date) for s in C}
  obs=float(ret[t.symbol]);others=float(np.mean([ret[s] for s in C if s!=t.symbol]))
  spy=net_interval(prices['SPY'],t.entry_date,t.exit_date)
  rows.append({'symbol':t.symbol,'frame':t.frame,'episode':t.episode,'arm_date':t.arm_date,'signal_date':t.signal_date,'entry_date':t.entry_date,'exit_date':t.exit_date,'selected_net':obs,'four_other_mean':others,'spy_net':spy,'spread':obs-others,'spread_vs_spy':obs-spy,'compared_v11_net_error':obs-float(t.net),'period':'2018_2022' if pd.Timestamp(t.signal_date).year<=2022 else '2023_2026'})
 x=pd.DataFrame(rows);assert len(x)==100 and x.compared_v11_net_error.abs().max()<1e-5
 x.to_csv(ROOT/'results'/'peer_control_v15_events.csv',index=False)
 summaries=[]
 for (frame,period),g in x.groupby(['frame','period']):
  summaries.append({'frame':frame,'period':period,'n':len(g),'mean_selected':float(g.selected_net.mean()),'mean_other_four':float(g.four_other_mean.mean()),'mean_spy':float(g.spy_net.mean()),'mean_spread_four':float(g.spread.mean()),'median_spread_four':float(g.spread.median()),'positive_stock_selection':float((g.spread>0).mean()),'mean_spread_vs_spy':float(g.spread_vs_spy.mean()),'unique_quarters':pd.to_datetime(g.signal_date).dt.to_period('Q').nunique()})
 for frame,g in x.groupby('frame'):
  k=block_ci(g)
  summaries.append({'frame':frame,'period':'ALL','n':len(g),'mean_selected':float(g.selected_net.mean()),'mean_other_four':float(g.four_other_mean.mean()),'mean_spy':float(g.spy_net.mean()),'mean_spread_four':float(g.spread.mean()),'median_spread_four':float(g.spread.median()),'positive_stock_selection':float((g.spread>0).mean()),'mean_spread_vs_spy':float(g.spread_vs_spy.mean()),'unique_quarters':pd.to_datetime(g.signal_date).dt.to_period('Q').nunique(),**{'bootstrap_low':k.get('low'), 'bootstrap_high':k.get('high'),'bootstrap_active_quarters':k.get('active_quarters')}})
 for (symbol,frame),g in x.groupby(['symbol','frame']):
  summaries.append({'symbol':symbol,'frame':frame,'period':'ALL','n':len(g),'mean_selected':float(g.selected_net.mean()),'mean_other_four':float(g.four_other_mean.mean()),'mean_spy':float(g.spy_net.mean()),'mean_spread_four':float(g.spread.mean()),'median_spread_four':float(g.spread.median()),'positive_stock_selection':float((g.spread>0).mean()),'mean_spread_vs_spy':float(g.spread_vs_spy.mean()),'unique_quarters':pd.to_datetime(g.signal_date).dt.to_period('Q').nunique()})
 pd.DataFrame(summaries).to_csv(ROOT/'results'/'peer_control_v15_summary.csv',index=False)
 meta={'core_only':C,'all_original_watches':len(events),'filled_events':len(source),'incomplete_watches':int((events.status=='INCOMPLETE').sum()),'skipped_watches':int((events.status=='SKIPPED').sum()),'max_v11_reconstruction_error':float(x.compared_v11_net_error.abs().max()),'run_source':'same V11 fixed entry dates, same V12 existing 2010+ adjusted prices, no network','test':'not independent future held-out data'}
 (ROOT/'results'/'peer_control_v15_meta.json').write_text(json.dumps(meta,indent=2))
 print('DAILY_PANEL',pd.DataFrame(summaries).query("frame=='1D' and period=='ALL'")[['symbol','n','mean_selected','mean_other_four','mean_spread_four','positive_stock_selection','bootstrap_low','bootstrap_high']].round(6).to_json(orient='records'))
 print('PERIODS',pd.DataFrame(summaries).query("frame=='1D' and period!='ALL'")[['period','n','mean_spread_four','positive_stock_selection','mean_spread_vs_spy']].round(6).to_json(orient='records'))
 print('RECONCILIATION',json.dumps(meta))
if __name__=='__main__':run()
