"""Exploratory V14 overlay robustness: leave-one-name, vintage split, and shared-quarter blocks.
No new triggers, no market-data network fetch, no trading, no sizing recommendation.
"""
import json,sys
from pathlib import Path
import numpy as np
import pandas as pd
import portfolio_v13 as p
import overlay_v14 as ov
ROOT=Path(__file__).resolve().parents[1];O=ROOT/'results'
def contrib(values,ref):
 return [(float(x)-float(ref))/len(values) for x in values]
def log_relative(equity,ref,start,end):
 if not equity.index.equals(ref.index):raise ValueError('Misaligned relative wealth')
 a=pd.Timestamp(start);b=pd.Timestamp(end)
 if a>=b or a not in equity.index or b not in equity.index:raise ValueError('Invalid observed period')
 return float(np.log(equity.loc[b]/equity.loc[a])-np.log(ref.loc[b]/ref.loc[a]))
def bootstrap_log_excess(excess,rep=4000,block=4,seed=102713):
 if not isinstance(excess.index,pd.DatetimeIndex) or excess.isna().any():raise ValueError('Timestamped finite log excess required')
 x=excess.to_frame('lr').assign(q=excess.index.to_period('Q'))
 stats=x.groupby('q').lr.agg(['sum','count']);q=pd.period_range(stats.index.min(),stats.index.max(),freq='Q');z=stats.reindex(q,fill_value=0)
 if (z['count']>0).sum()<8:return {'interval':None,'n_quarters':int((z['count']>0).sum())}
 rng=np.random.default_rng(seed);N=len(q)
 starts=rng.integers(0,N,size=(rep,int(np.ceil(N/block))))
 loc=((starts[:,:,None]+np.arange(block))%N).reshape(rep,-1)[:,:N]
 sums=z['sum'].to_numpy()[loc].sum(axis=1);days=z['count'].to_numpy()[loc].sum(axis=1)
 valid=days>0
 draw=sums[valid]/days[valid]*252
 return {'interval':'exploratory','low':float(np.quantile(draw,.025)),'high':float(np.quantile(draw,.975)),'mean':float(excess.sum()/len(excess)*252),'n_quarters':N,'rep':rep,'block':block,'valid':int(valid.sum())}
def run():
 sys.path.insert(0,str(ROOT/'source'))
 import v12_engine as v
 d=pd.read_csv(O/'overlay_v14_daily.csv.gz')
 d['date']=pd.to_datetime(d.date,format='%Y-%m-%d')
 ad=pd.read_csv(O/'account_daily.csv.gz',usecols=['date','equity','exposure','symbol','frame','policy','normalization','cost_bps'])
 ix=pd.DatetimeIndex(sorted(d.date.unique()))
 spy_full=v.load_daily('SPY');spy=spy_full.loc[ix]
 base_spy=p.buyhold_for_account(spy_full,ix,fee=.0005)
 names=p.CORE
 outs=[];leave=[];concentr=[];periods=[];fees=[]
 stock_end={}
 for frame in ['1D','2D']:
  for policy in p.POLICIES:
   sub=d[(d.symbol.isin(names))&(d.frame==frame)&(d.policy==policy)]
   comp=p.combine(sub[['date','symbol','equity','exposure']],names)
   sp=p.metrics(base_spy)
   for bs in [2,4,8]:
    excess=np.log(comp.equity).diff().fillna(0.)-np.log(base_spy).diff().fillna(0.)
    result=bootstrap_log_excess(excess,rep=4000,block=bs)
    outs.append({'frame':frame,'policy':policy,'block_quarters':bs,**result,'mean_cagr_delta_pp':(p.metrics(comp)['cagr']-sp['cagr'])*100})
   for y0,y1,label in [(ix[0],ix[ix.year<=2022][-1],'2018_2022'),(ix[ix.year<=2022][-1],ix[-1],'2023_2026')]:
    periods.append({'frame':frame,'policy':policy,'period':label,'log_overlay_vs_spy':log_relative(comp.equity,base_spy,y0,y1),'relative_wealth_change':float(np.exp(log_relative(comp.equity,base_spy,y0,y1))-1)})
   per=[]
   for sym in names:
    z=sub[sub.symbol==sym].sort_values('date');last=float(z.equity.iloc[-1]);per.append(last)
    concentr.append({'frame':frame,'policy':policy,'stock':sym,'overlay_end':last,'spy_end':float(base_spy.iloc[-1]),'ending_wealth_contribution':(last-float(base_spy.iloc[-1]))/len(names)})
   assert abs(sum(contrib(per,float(base_spy.iloc[-1])))-(float(comp.equity.iloc[-1])-float(base_spy.iloc[-1])))<1e-8
   for sym in names:
    remaining=[s for s in names if s!=sym]
    q=p.combine(sub[sub.symbol.isin(remaining)][['date','symbol','equity','exposure']],remaining)
    leave.append({'frame':frame,'policy':policy,'removed':sym,'remaining_n':len(remaining),'overlay_cagr':p.metrics(q)['cagr'],'spy_cagr':sp['cagr'],'delta_cagr_pp':(p.metrics(q)['cagr']-sp['cagr'])*100,'overlay_mdd':p.metrics(q)['max_dd']})
   for cbps in [10,30]:
    fee=cbps/20000
    qrows=[]
    for sym in names:
      raw=ad[(ad.symbol==sym)&(ad.frame==frame)&(ad.policy==policy)&(ad.normalization=='FULL_CAPITAL')&(ad.cost_bps==cbps)].copy()
      if raw.empty:raise ValueError('Missing cost path: '+sym+policy+str(cbps))
      raw.date=pd.to_datetime(raw.date,format='%Y-%m-%d')
      src=raw.set_index('date').sort_index()
      marked=ov.overlay(spy,src[['equity','exposure']],fee=fee)
      marked['symbol']=sym;qrows.append(marked.reset_index(names='date'))
    qq=p.combine(pd.concat(qrows)[['date','symbol','equity','exposure']],names)
    bb=p.buyhold_for_account(spy_full,ix,fee=fee)
    fees.append({'frame':frame,'policy':policy,'round_trip_cost_bps':cbps,'overlay_cagr':p.metrics(qq)['cagr'],'spy_cagr':p.metrics(bb)['cagr'],'delta_cagr_pp':(p.metrics(qq)['cagr']-p.metrics(bb)['cagr'])*100,'portfolio_max_dd':p.metrics(qq)['max_dd']})
 pd.DataFrame(outs).to_csv(O/'overlay_v14_block_intervals.csv',index=False)
 pd.DataFrame(leave).to_csv(O/'overlay_v14_leave_name_out.csv',index=False)
 pd.DataFrame(concentr).to_csv(O/'overlay_v14_name_contributions.csv',index=False)
 pd.DataFrame(periods).to_csv(O/'overlay_v14_periods.csv',index=False)
 pd.DataFrame(fees).to_csv(O/'overlay_v14_cost_sensitivity.csv',index=False)
 print('KEY_RESULTS_BLOCK',pd.DataFrame(outs).query("frame=='1D' and block_quarters==4")[['policy','mean_cagr_delta_pp','low','high','n_quarters']].round(5).to_json(orient='records'))
 print('LEAVE_OUT_HOLD',pd.DataFrame(leave).query("frame=='1D' and policy=='HOLD'")[['removed','delta_cagr_pp','overlay_mdd']].round(5).to_json(orient='records'))
 print('PERIOD_HOLD',pd.DataFrame(periods).query("frame=='1D' and policy=='HOLD'").to_json(orient='records'))
 print('COST_HOLD',pd.DataFrame(fees).query("frame=='1D' and policy=='HOLD'").to_json(orient='records'))
 print('NO_NEW_BARS_OR_SIGNALS')
if __name__=='__main__':run()
