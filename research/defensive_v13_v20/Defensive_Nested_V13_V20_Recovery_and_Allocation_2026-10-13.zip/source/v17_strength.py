"""V17 point-in-time relative-strength at the fixed V11/V16 crossover dates.
Historical, posthoc, not a fitted predictor. Original prices are already available.
"""
from pathlib import Path
import sys,json
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
ROOT=Path(__file__).resolve().parents[2];THIS=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source'))
import v12_engine as original
CORE=['MCD','WMT','WM','COST','PG']
def prior_relative(stock,reference,signal_i,window=63):
    if not stock.index.equals(reference.index):raise ValueError('Market calendar mismatch')
    p=signal_i-1-window;z=signal_i-1
    if p<0 or z>=len(stock):return np.nan
    a=np.array([stock.iloc[p],stock.iloc[z],reference.iloc[p],reference.iloc[z]],float)
    if not np.isfinite(a).all() or (a<=0).any():return np.nan
    return float(np.log(a[1]/a[0])-np.log(a[3]/a[2]))
def prior_drawdown(stock,signal_i,lookback=126):
    if signal_i<=lookback or signal_i>len(stock):return np.nan
    past=stock.iloc[signal_i-lookback:signal_i].to_numpy(float)
    if not np.isfinite(past).all() or (past<=0).any():return np.nan
    return float(past[-1]/past.max()-1)
def label(x):
    if not np.isfinite(x):return 'UNKNOWN'
    return 'LEADING' if x>0 else 'LAGGING'
def bootstrap_difference(df,metric='beta_neutral_spread',reps=3000,block=4):
    d=df.copy();d['q']=pd.to_datetime(d.signal_date).dt.to_period('Q')
    q=pd.period_range(d.q.min(),d.q.max(),freq='Q')
    vals={}
    for k in ['LEADING','LAGGING']:
        x=d[d.pre_state==k].groupby('q')[metric].agg(['sum','count']).reindex(q,fill_value=0)
        vals[k]=(x['sum'].to_numpy(),x['count'].to_numpy())
    active={k:int((v[1]>0).sum()) for k,v in vals.items()}
    if min(active.values())<8:return {'interval':None,'active':active}
    rng=np.random.default_rng(171013);n=len(q)
    idx=rng.integers(0,n,size=(reps,int(np.ceil(n/block))))
    blocks=((idx[:,:,None]+np.arange(block))%n).reshape(reps,-1)[:,:n]
    scores={}
    for k,(total,cnt) in vals.items():
        numer=total[blocks].sum(axis=1);denom=cnt[blocks].sum(axis=1)
        scores[k]=(numer,denom)
    ok=(scores['LEADING'][1]>0)&(scores['LAGGING'][1]>0)
    draws=(scores['LEADING'][0][ok]/scores['LEADING'][1][ok]-scores['LAGGING'][0][ok]/scores['LAGGING'][1][ok])
    return {'interval':'descriptive_not_selection_adjusted','low':float(np.quantile(draws,.025)),'high':float(np.quantile(draws,.975)),'active':active,'valid_draws':int(ok.sum())}
def run():
    src=pd.read_csv(THIS/'results/v16_frozen_events.csv');prices={s:original.load_daily(s).close for s in CORE+['SPY']}
    records=[]
    for t in src.itertuples():
        x=prices[t.symbol]
        ix=x.index;z=int(ix.get_loc(pd.Timestamp(t.signal_date)))
        peer_panel=pd.concat([prices[s] for s in CORE if s!=t.symbol],axis=1)
        # Pre-signal equal-weight raw log return of four other names; no future observations.
        names=[s for s in CORE if s!=t.symbol]
        vals=[]
        for s in names:
            a=prior_relative(x,prices[s],z,63)
            if not np.isfinite(a):raise ValueError('Missing pre-signal data')
            vals.append(a)
        relative=float(np.mean(vals))
        spyrelative=prior_relative(x,prices['SPY'],z,63)
        dd=prior_drawdown(x,z,126)
        records.append({'symbol':t.symbol,'frame':t.frame,'episode':t.episode,'signal_date':t.signal_date,'prior63_other4_rel':relative,'prior63_spy_rel':spyrelative,'prior126_drawdown':dd,'pre_state':label(relative),'future_raw_spread_other4':t.raw_selected_vs_other_four,'future_beta_neutral_log_spread':t.beta_neutral_spread,'future_v11_net':t.net})
    d=pd.DataFrame(records);assert len(d)==100 and not d.isna().any().any()
    d.to_csv(THIS/'results/v17_events.csv',index=False)
    out=[]
    for frame,g in d.groupby('frame'):
        corr=spearmanr(g.prior63_other4_rel,g.future_beta_neutral_log_spread)
        bc=bootstrap_difference(g,metric='future_beta_neutral_log_spread')
        for k,h in g.groupby('pre_state'):
            out.append({'frame':frame,'state':k,'n':len(h),'prior63_mean':float(h.prior63_other4_rel.mean()),'future_raw_spread_mean':float(h.future_raw_spread_other4.mean()),'future_beta_neutral_log_spread_mean':float(h.future_beta_neutral_log_spread.mean()),'future_selected_return_mean':float(h.future_v11_net.mean()),'positive_residual_spread':float((h.future_beta_neutral_log_spread>0).mean()),'quarters':pd.to_datetime(h.signal_date).dt.to_period('Q').nunique(),'full_sample_spearman_rho':float(corr.statistic),'full_sample_spearman_pvalue_unadjusted':float(corr.pvalue),'lead_lag_block_low':bc.get('low'),'lead_lag_block_high':bc.get('high'),'lead_lag_interval_status':bc.get('interval')})
    pd.DataFrame(out).to_csv(THIS/'results/v17_summary.csv',index=False)
    meta={'prior_price_clock':'63 completed daily observations ending t-1','prior_drawdown_clock':'126 completed days ending t-1','status':'posthoc exploratory, not alpha signal selection','max_input_event_count':len(d),'no_network_or_orders':True}
    (THIS/'results/v17_meta.json').write_text(json.dumps(meta,indent=2))
    print('V17_RESULTS',pd.DataFrame(out).round(6).to_json(orient='records'))
    print('V17_META',json.dumps(meta))
if __name__=='__main__':run()
