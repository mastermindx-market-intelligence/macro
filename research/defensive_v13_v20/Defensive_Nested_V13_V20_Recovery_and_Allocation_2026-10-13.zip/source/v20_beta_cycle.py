"""V20: trailing-beta-adjusted, same-episode, same-interval slow recovery
between day-20 close and day-63 close; research only, no network/live orders.
"""
from pathlib import Path
import sys,json
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[2]
THIS=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source'))
import v12_engine as inputs
import v16_engine as prior
from v17_strength import bootstrap_difference
CORE=['MCD','WMT','WM','COST','PG']
def trailing_beta(stock,spy,signal_i):
    return prior.beta_before_signal(stock,spy,signal_i,lookback=252,min_obs=200)
def segment_excess_log(stock,spy,signal_i,start_i,end_i,beta):
    if not stock.index.equals(spy.index):raise ValueError('Date alignment')
    if signal_i>=start_i or start_i>=end_i or end_i>=len(stock):raise ValueError('Future segment clock invalid')
    p=np.array([stock.iloc[start_i],stock.iloc[end_i],spy.iloc[start_i],spy.iloc[end_i]],float)
    if (p<=0).any() or not np.isfinite(p).all():raise ValueError('Bad future prices')
    if not np.isfinite(beta):return np.nan
    return float(np.log(p[1]/p[0])-beta*np.log(p[3]/p[2]))
def block_ci(df,rep=4000,block=4):
    if df.empty:return {'interval':None,'active_quarters':0}
    z=df.copy();z['q']=pd.to_datetime(z.signal_date).dt.to_period('Q')
    weeks=z.groupby('q').beta_spread.agg(['sum','count'])
    ix=pd.period_range(weeks.index.min(),weeks.index.max(),freq='Q')
    q=weeks.reindex(ix,fill_value=0)
    active=int((q['count']>0).sum())
    if active<8:return {'interval':None,'active_quarters':active}
    rng=np.random.default_rng(201013);n=len(ix)
    st=rng.integers(0,n,size=(rep,int(np.ceil(n/block))))
    loc=((st[:,:,None]+np.arange(block))%n).reshape(rep,-1)[:,:n]
    a=q['sum'].to_numpy()[loc].sum(axis=1);b=q['count'].to_numpy()[loc].sum(axis=1)
    x=a[b>0]/b[b>0]
    return {'interval':'exploratory_nonselectionadjusted','low':float(np.quantile(x,.025)),'high':float(np.quantile(x,.975)),'active_quarters':active,'replicates':len(x)}
def run():
    d=pd.read_csv(THIS/'results/v16_frozen_events.csv')
    px={s:inputs.load_daily(s).close for s in CORE+['SPY']}
    cal=px['SPY'].index
    assert all(x.index.equals(cal) for x in px.values())
    out=[]
    for t in d.itertuples():
        signal_i=int(cal.get_loc(pd.Timestamp(t.signal_date)))
        entry_i=int(cal.get_loc(pd.Timestamp(t.entry_date)))
        assert entry_i==signal_i+1
        start=entry_i+19;end=entry_i+62
        betas={s:trailing_beta(px[s],px['SPY'],signal_i) for s in CORE}
        residues={s:segment_excess_log(px[s],px['SPY'],signal_i,start,end,betas[s]) for s in CORE}
        raw={s:float(np.log(px[s].iloc[end]/px[s].iloc[start])) for s in CORE}
        chosen=t.symbol;others=[s for s in CORE if s!=chosen]
        row={'symbol':chosen,'frame':t.frame,'episode':int(t.episode),'signal_date':t.signal_date,'entry_date':t.entry_date,'horizon_start_date':str(cal[start].date()),'horizon_end_date':str(cal[end].date()),'beta':betas[chosen],'selected_beta_residual':residues[chosen],'other_four_beta_residual':float(np.mean([residues[s] for s in others])),'beta_spread':float(residues[chosen]-np.mean([residues[s] for s in others])),'raw_log_spread':float(raw[chosen]-np.mean([raw[s] for s in others])),'spy_segment_log':float(np.log(px['SPY'].iloc[end]/px['SPY'].iloc[start]))}
        out.append(row)
    o=pd.DataFrame(out);assert len(o)==100 and o[['beta','beta_spread','raw_log_spread']].notna().all().all()
    o.to_csv(THIS/'results/v20_events.csv',index=False)
    summary=[]
    for frame,g in o.groupby('frame'):
        b=block_ci(g)
        leave_year=[];leave_stock=[]
        yrs=pd.to_datetime(g.signal_date).dt.year
        for y in sorted(yrs.unique()):leave_year.append(float(g[yrs!=y].beta_spread.mean()))
        for s in CORE:leave_stock.append(float(g[g.symbol!=s].beta_spread.mean()))
        summary.append({'frame':frame,'period':'ALL','n':len(g),'raw_log_spread_mean':float(g.raw_log_spread.mean()),'beta_log_spread_mean':float(g.beta_spread.mean()),'fraction_positive':float((g.beta_spread>0).mean()),'leave_year_low':min(leave_year),'leave_year_high':max(leave_year),'leave_stock_low':min(leave_stock),'leave_stock_high':max(leave_stock),'block_low':b.get('low'),'block_high':b.get('high'),'active_quarters':b['active_quarters'],'mean_beta_selected':float(g.beta.mean())})
        for label,h in g.groupby(np.where(yrs<=2022,'2018_2022','2023_2026')):
            summary.append({'frame':frame,'period':label,'n':len(h),'raw_log_spread_mean':float(h.raw_log_spread.mean()),'beta_log_spread_mean':float(h.beta_spread.mean()),'fraction_positive':float((h.beta_spread>0).mean()),'active_quarters':pd.to_datetime(h.signal_date).dt.to_period('Q').nunique(),'mean_beta_selected':float(h.beta.mean())})
    sd=pd.DataFrame(summary);sd.to_csv(THIS/'results/v20_summary.csv',index=False)
    (THIS/'results/v20_receipt.json').write_text(json.dumps({'events':len(o),'beta_lookback':252,'beta_known_before_entry':True,'interval':'Close at entry + 19 through close at entry + 62','no_new_raw_market_data':True,'no_trade_order':True,'research_only':True},indent=2))
    print('V20_SUMMARY',sd.round(6).to_json(orient='records'))
    print('V20_RECEIPT',json.dumps(json.loads((THIS/'results/v20_receipt.json').read_text())))
if __name__=='__main__':run()
