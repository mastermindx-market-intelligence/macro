"""V14 research: park the uninvested V12 stock sleeve in SPY.
No new signals, no data acquisition. All swaps at daily open, costs explicit.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import portfolio_v13 as p
ROOT=Path(__file__).resolve().parents[1]
def overlay(spy,stock,fee=.0005):
    if not spy.index.equals(stock.index) or len(spy)<2:raise ValueError('Calendar mismatch')
    if (spy[['open','close']]<=0).any().any() or spy[['open','close']].isna().any().any():raise ValueError('Bad SPY prices')
    if stock[['equity','exposure']].isna().any().any() or not (stock.equity>0).all() or not stock.exposure.isin([0,1]).all():raise ValueError('Requires valid full-capital binary exposure')
    n=len(stock);eq=np.zeros(n,float);swaps=np.zeros(n,int)
    e=stock.equity.to_numpy(float);pos=stock.exposure.to_numpy(int);o=spy.open.to_numpy(float);c=spy.close.to_numpy(float)
    if pos[0]==1:eq[0]=e[0]
    else:eq[0]=c[0]/(o[0]*(1+fee));swaps[0]=1
    for i in range(1,n):
        if pos[i-1]==0 and pos[i]==0:
            factor=c[i]/c[i-1]
        elif pos[i-1]==0 and pos[i]==1:
            factor=(o[i]/c[i-1])*(1-fee)*(e[i]/e[i-1]);swaps[i]=1
        elif pos[i-1]==1 and pos[i]==0:
            # Stock exit may have occurred intraday: buy SPY only at today's close.
            # Crediting SPY open->close on the same day would use future knowledge.
            factor=(e[i]/e[i-1])/(1+fee);swaps[i]=1
        else:factor=e[i]/e[i-1]
        eq[i]=eq[i-1]*factor
    return pd.DataFrame({'equity':eq,'exposure':pos,'market_exposure':np.ones(n),'spy_switches':swaps},index=stock.index)
def run():
    import sys
    sys.path.insert(0,str(ROOT/'source'))
    import v12_engine as v
    d=pd.read_csv(ROOT/'results'/'account_daily.csv.gz',usecols=['date','equity','exposure','symbol','frame','policy','normalization','cost_bps'])
    all_syms=p.CORE+p.PEERS;spy_full=v.load_daily('SPY')
    raw=[];overall=[];details=[];idx=pd.DatetimeIndex(sorted(pd.to_datetime(d[(d.symbol==p.CORE[0])&(d.policy=='HOLD')&(d.frame=='1D')&(d.normalization=='FULL_CAPITAL')&(d.cost_bps==10)].date.unique())))
    spy=spy_full.loc[idx]
    spy_mark=p.buyhold_for_account(spy_full,idx)
    for frame in ['1D','2D']:
        for policy in p.POLICIES:
            selected=d[(d.frame==frame)&(d.policy==policy)&(d.normalization=='FULL_CAPITAL')&(d.cost_bps==10)]
            for sym in all_syms:
                s=selected[selected.symbol==sym].copy();s.date=pd.to_datetime(s.date,format='%Y-%m-%d')
                s=s.set_index('date').sort_index()
                if not s.index.equals(idx):raise ValueError('Mismatch on stock '+sym)
                x=overlay(spy,s[['equity','exposure']])
                x['symbol']=sym;x['frame']=frame;x['policy']=policy;raw.append(x.reset_index(names='date'))
                a=p.metrics(x);q=p.metrics(s)
                details.append({'symbol':sym,'frame':frame,'policy':policy,'overlay_cagr':a['cagr'],'original_stock_cash_cagr':q['cagr'],'overlay_max_dd':a['max_dd'],'original_max_dd':q['max_dd'],'spy_switch_count':int(x.spy_switches.sum()),'time_avg_stock_exposure':a['time_avg_marked_exposure']})
    all_days=pd.concat(raw,ignore_index=True)
    all_days['date']=pd.to_datetime(all_days['date'])
    for name,syms in [('CORE5',p.CORE),('PEERS13',p.PEERS),('ALL18',all_syms)]:
        stocks_ref=pd.concat([p.buyhold_for_account(v.load_daily(s),idx) for s in syms],axis=1).mean(axis=1)
        stock_ref_metrics=p.metrics(stocks_ref)
        spy_metrics=p.metrics(spy_mark)
        for frame in ['1D','2D']:
            for policy in p.POLICIES:
                x=all_days[(all_days.symbol.isin(syms))&(all_days.frame==frame)&(all_days.policy==policy)]
                q=p.combine(x[['date','symbol','equity','exposure']],syms)
                m=p.metrics(q)
                market_spy=p.metrics(p.combine(d[(d.symbol.isin(syms))&(d.frame==frame)&(d.policy==policy)&(d.normalization=='FULL_CAPITAL')&(d.cost_bps==10)][['date','symbol','equity','exposure']],syms))
                overall.append({'panel':name,'frame':frame,'policy':policy,**m,'stock_cash_cagr':market_spy['cagr'],'same_stock_buyhold_cagr':stock_ref_metrics['cagr'],'spy_buyhold_cagr':spy_metrics['cagr'],'incremental_vs_cash_pp':(m['cagr']-market_spy['cagr'])*100,'incremental_vs_spy_pp':(m['cagr']-spy_metrics['cagr'])*100,'incremental_vs_same_stock_buyhold_pp':(m['cagr']-stock_ref_metrics['cagr'])*100,'total_spy_trade_orders':int(x.spy_switches.sum())})
    pd.DataFrame(overall).to_csv(ROOT/'results'/'overlay_v14_summary.csv',index=False)
    pd.DataFrame(details).to_csv(ROOT/'results'/'overlay_v14_by_stock.csv',index=False)
    all_days.to_csv(ROOT/'results'/'overlay_v14_daily.csv.gz',index=False,compression='gzip')
    print('CORE_OVERLAY',pd.DataFrame(overall).query("panel=='CORE5' and frame=='1D'")[['policy','cagr','max_dd','stock_cash_cagr','spy_buyhold_cagr','same_stock_buyhold_cagr','total_spy_trade_orders']].round(5).to_json(orient='records'))
    print('VERIFICATION',json.dumps({'portfolio_rows':len(overall),'all_daily_rows':len(all_days),'fixed_signal':True,'no_market_download':True,'original_account_path_count':len(details)}))
if __name__=='__main__':run()
