"""Fixed-entry V12 exit and account comparison. Offline, no brokerage actions.
No raw-price acquisition; only separately admitted snapshot and V11 source inputs.
Stops are fixed at entry. Close decisions execute next open; terminal open
positions remain marked and do not receive a fabricated exit or exit fee.
"""
from pathlib import Path
import sys,json,hashlib
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parents[1]
V=R/'v11_published'
sys.path.insert(0,str(V/'source'))
import empirical as e
POLICIES=['HOLD','ATR3','ATR6','STRUCTURE_ATR6','STRUCTURE_MOMENTUM_ATR6','STAGED_ATR6']
CALENDAR_SHA='7eab0936874091b396f73d368a6aa27cef1a0a5737398f544a65f021e4dbb566'
CALENDAR_TAIL=['2026-10-09','2026-10-12','2026-10-13','2026-10-14','2026-10-15','2026-10-16','2026-10-19','2026-10-20','2026-10-21','2026-10-22','2026-10-23','2026-10-26','2026-10-27','2026-10-28','2026-10-29','2026-10-30','2026-11-02']

def load_daily(sym):
    x=json.loads((R/'inputs_20261013'/f'{sym}_1d.json').read_text())['chart']['result'][0]
    ix=pd.to_datetime(x['timestamp'],unit='s',utc=True).tz_convert('America/New_York').normalize().tz_localize(None)
    d=pd.DataFrame(x['indicators']['quote'][0],index=ix)
    factor=pd.Series(x['indicators']['adjclose'][0]['adjclose'],index=ix)/d.close
    d[['open','high','low','close']]=d[['open','high','low','close']].mul(factor,axis=0)
    assert len(d)==4217 and not d.index.duplicated().any() and d[['open','high','low','close']].notna().all().all()
    assert hashlib.sha256('\n'.join(ix.strftime('%Y-%m-%d')).encode()).hexdigest()==CALENDAR_SHA
    assert (d.low>0).all() and (d.high+1e-6>=d[['open','close']].max(axis=1)).all() and (d.low-1e-6<=d[['open','close']].min(axis=1)).all()
    return d

def features(d,frame):
    calendar=d.index.append(pd.DatetimeIndex(CALENDAR_TAIL))
    lo=e.snapshots(d.close,calendar,frame,'confirmed',0)
    w=e.snapshots(d.close,calendar,'1W','confirmed',0)
    tr=pd.concat([d.high-d.low,(d.high-d.close.shift()).abs(),(d.low-d.close.shift()).abs()],axis=1).max(axis=1)
    return pd.DataFrame({'atr':e.original.rma(tr,14),'lower_hist':lo['hist'],'weekly_fresh':w.fresh,'weekly_k':w.k,'weekly_stoch_bear':w.fresh&(w.k<w.d)&(w.k.shift()>=w.d.shift())},index=d.index)

def setup_floor(d,arm_i,signal_i,atr):
    if not 0<=arm_i<=signal_i<len(d) or not np.isfinite(atr) or atr<=0:raise ValueError('Known causal arm, signal and positive ATR required')
    return float(d.low.iloc[max(0,arm_i-20):signal_i+1].min()-.5*atr)

def simulate(d,f,signal_i,arm_i,endpoint_i,policy,fee=.0005,mark_open=False):
    if policy not in POLICIES:raise ValueError('Unknown policy')
    if not d.index.equals(f.index):raise ValueError('Misaligned features')
    if endpoint_i>=len(d) and not mark_open:return {'status':'INCOMPLETE'}
    if not 0<=arm_i<=signal_i<endpoint_i or signal_i+1>=len(d):raise ValueError('Invalid indices or unobserved entry')
    atr=float(f.atr.iloc[signal_i]);floor=setup_floor(d,arm_i,signal_i,atr)
    j=signal_i+1;entry=float(d.open.iloc[j]);shares=1/(entry*(1+fee));stop=0. if policy=='HOLD' else max(0.,entry-(3 if policy=='ATR3' else 6)*atr)
    pending=None;extended=False;minimum=entry;maximum=entry;marks=[];decision=None;status='CLOSED';end=min(endpoint_i,len(d)-1)
    bars=d[['open','high','low','close']].to_numpy(float)
    hist=f.lower_hist.to_numpy(float);fresh=f.weekly_fresh.to_numpy(bool);wk=f.weekly_k.to_numpy(float);wb=f.weekly_stoch_bear.to_numpy(bool)
    reason='ENDPOINT';price=float(d.close.iloc[end]);exit_i=end
    for i in range(j,end+1):
        op,hi,low,cl=bars[i]
        if op<=stop or pending is not None:
            price=op;reason='STOP_GAP' if op<=stop else pending;minimum=min(minimum,op);maximum=max(maximum,op)
            marks.append((i,shares*price*(1-fee),False));exit_i=i;pending=None;break
        if low<=stop:
            price=stop;reason='STOP_INTRADAY';minimum=min(minimum,stop);maximum=max(maximum,op)
            marks.append((i,shares*price*(1-fee),False));exit_i=i;break
        minimum=min(minimum,low);maximum=max(maximum,hi)
        if fresh[i] and np.isfinite(wk[i]) and wk[i]>=80:extended=True
        trigger=None
        if policy=='STRUCTURE_ATR6' and cl<floor:trigger='STRUCTURE_LOSS'
        elif policy in ['STRUCTURE_MOMENTUM_ATR6','STAGED_ATR6'] and cl<floor and np.isfinite(hist[i]) and hist[i]<0:trigger='STRUCTURE_MOMENTUM_LOSS'
        if trigger is None and policy=='STAGED_ATR6' and extended and fresh[i] and wb[i]:trigger='WEEKLY_CYCLE'
        if i==endpoint_i:
            price=cl;reason='ENDPOINT';marks.append((i,shares*price*(1-fee),False))
        elif i==end:
            price=cl;reason='OPEN_SAMPLE_END';status='OPEN';pending=trigger
            if trigger:decision=i
            marks.append((i,shares*price,True))
        else:
            marks.append((i,shares*cl,True))
            if trigger:pending=trigger;decision=i
    net=shares*price*(1-fee if status=='CLOSED' else 1)-1
    return dict(status=status,policy=policy,entry_i=j,exit_i=exit_i,decision_i=decision,entry_date=str(d.index[j].date()),exit_date=str(d.index[exit_i].date()) if status=='CLOSED' else None,entry_price=entry,exit_price=price if status=='CLOSED' else None,net=net,reason=reason,held_sessions=exit_i-j+1,mae=minimum/entry-1,mfe=maximum/entry-1,atr_pct=atr/entry,structure_floor=floor,structure_distance=1-floor/entry,stop_distance=None if policy=='HOLD' else 1-stop/entry,pending_reason=pending,marks=marks)

def risk_weight(stop_distance,risk_budget):
    if not np.isfinite(stop_distance) or stop_distance<=0 or not 0<risk_budget<=1:raise ValueError('Positive known stop distance and budget required')
    return min(1.,risk_budget/stop_distance)

def account(d,f,events,policy,start_i=0,risk_budget=None,fee=.0005):
    if policy=='HOLD' and risk_budget is not None:raise ValueError('HOLD has no declared stop-based risk')
    n=len(d);eq=np.ones(n);ex=np.zeros(n);capital=1.;last_end=start_i-1;cursor=start_i;trades=[];skipped=0
    for a in sorted(events,key=lambda z:(z['signal_i'],z['episode'])):
        s=int(a['signal_i'])
        if s<start_i or s+1>=n:continue
        if s<last_end:skipped+=1;continue
        z=simulate(d,f,s,int(a['arm_i']),int(a['endpoint_i']),policy,fee,True)
        weight=1. if risk_budget is None else risk_weight(z['stop_distance'],risk_budget)
        j=z['entry_i'];eq[cursor:j]=capital
        for k,rel,occupied in z['marks']:
            eq[k]=capital*(1-weight+weight*rel);ex[k]=weight if occupied else 0.
        before=capital;capital=float(eq[z['exit_i']]);cursor=z['exit_i']+1;last_end=z['exit_i']
        trades.append({k:v for k,v in z.items() if k!='marks'}|{'episode':a['episode'],'weight':weight,'capital_before':before,'capital_after':capital,'account_trade_return':capital/before-1})
    eq[cursor:]=capital
    q=pd.DataFrame({'equity':eq,'exposure':ex},index=d.index).iloc[start_i:];q['drawdown']=q.equity/q.equity.cummax().clip(lower=1.)-1
    years=(q.index[-1]-q.index[0]).days/365.25
    closed=[t for t in trades if t['status']=='CLOSED']
    out={'ending_equity':capital,'cagr':capital**(1/years)-1 if years>0 else np.nan,'max_dd':float(q.drawdown.min()),'entries':len(trades),'closed':len(closed),'open':sum(t['status']=='OPEN' for t in trades),'win':float(np.mean([t['net']>0 for t in closed])) if closed else np.nan,'mean_exposure':float(q.exposure.mean()),'overlap_skipped':skipped,'worst_account_trade':min((t['account_trade_return'] for t in closed),default=np.nan),'largest_weight':max((t['weight'] for t in trades),default=0.),'risk_budget':risk_budget,'cash_yield':0.}
    return {'summary':out,'curve':q,'trades':pd.DataFrame(trades)}
