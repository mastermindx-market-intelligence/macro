"""V14 robustness tests for paired SPY-relative wealth and time-block inference."""
import unittest
import numpy as np
import pandas as pd
import overlay_v14_audit as a
class AuditTests(unittest.TestCase):
 def test_contributions_sum_to_aggregate_advantage(self):
  c=a.contrib([1.5,3.,3.5],3.)
  self.assertAlmostEqual(sum(c),(np.mean([1.5,3.,3.5])-3.))
 def test_period_log_excess(self):
  ix=pd.to_datetime(['2018-01-02','2019-12-31','2020-01-02'])
  eq=pd.Series([1.,2.,4.],index=ix);sp=pd.Series([1.,2.,2.],index=ix)
  self.assertAlmostEqual(a.log_relative(eq,sp,ix[1],ix[2]),np.log(2.))
 def test_truncated_period_does_not_use_future(self):
  ix=pd.date_range('2018-01-01',periods=10,freq='D')
  eq=pd.Series(np.linspace(1,2,10),index=ix);sp=pd.Series(np.linspace(1,1.5,10),index=ix)
  first=a.log_relative(eq,sp,ix[1],ix[5]);eq.iloc[9]=100.;sp.iloc[9]=.2
  self.assertAlmostEqual(first,a.log_relative(eq,sp,ix[1],ix[5]))
 def test_too_few_quarters_no_interval(self):
  ix=pd.date_range('2018-01-01',periods=30,freq='B')
  x=pd.Series(np.zeros(len(ix)),index=ix)
  self.assertIsNone(a.bootstrap_log_excess(x,rep=200)['interval'])
 def test_identical_daily_stream_ci_zero(self):
  ix=pd.bdate_range('2018-01-01',periods=1500)
  x=pd.Series(np.zeros(len(ix)),index=ix)
  y=a.bootstrap_log_excess(x,rep=300)
  self.assertAlmostEqual(y['low'],0.);self.assertAlmostEqual(y['high'],0.)
 def test_one_positive_bad_neither_future_leakage(self):
  ix=pd.bdate_range('2018-01-01',periods=1500)
  x=pd.Series(np.full(len(ix),.0001),index=ix)
  y=a.bootstrap_log_excess(x,rep=200)
  self.assertGreater(y['low'],0.)
if __name__=='__main__':unittest.main()