"""V20 beta-neutral 20-to-63 horizon mechanics; tests first."""
import unittest,sys
from pathlib import Path
import pandas as pd,numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import v20_beta_cycle as m
class V20(unittest.TestCase):
 def fixture(self):
  ix=pd.bdate_range('2018-01-02',periods=400)
  p=pd.Series(np.exp(np.arange(400)*.001),index=ix)
  return p
 def test_equal_beta_paths_zero_residual(self):
  p=self.fixture()
  self.assertAlmostEqual(m.segment_excess_log(p,p,200,219,262,1.),0.,places=12)
 def test_different_beta_paths_zero_residual(self):
  p=self.fixture()
  q=pd.Series(np.exp(np.arange(400)*.002),index=p.index)
  self.assertAlmostEqual(m.segment_excess_log(q,p,200,219,262,2.),0.,places=12)
 def test_future_change_does_not_change_estimated_beta(self):
  ix=pd.bdate_range('2018-01-02',periods=400)
  r=np.random.default_rng(42).normal(0,.01,400)
  p=pd.Series(np.exp(np.cumsum(r)),index=ix)
  q=pd.Series(np.exp(np.cumsum(1.5*r)),index=ix)
  b=m.trailing_beta(q,p,320)
  self.assertTrue(np.isfinite(b))
  q.iloc[320:]*=np.linspace(1,10,80)
  self.assertAlmostEqual(m.trailing_beta(q,p,320),b)
 def test_segment_excludes_first_twenty_returns(self):
  p=self.fixture();q=p.copy()
  q.iloc[219:]=q.iloc[219:]*1.5
  self.assertAlmostEqual(m.segment_excess_log(q,p,200,219,262,1.),0.,places=12)
 def test_invalid_segment_clock(self):
  p=self.fixture()
  with self.assertRaises(ValueError):m.segment_excess_log(p,p,200,263,262,1.)
 def test_missing_warmup_returns_unknown(self):
  p=self.fixture()
  self.assertTrue(np.isnan(m.trailing_beta(p,p,150)))
 def test_common_quarter_nonindependent_threshold(self):
  df=pd.DataFrame({'signal_date':['2020-03-02','2020-03-03'],'beta_spread':[.1,.2]})
  self.assertIsNone(m.block_ci(df)['interval'])
if __name__=='__main__':unittest.main()