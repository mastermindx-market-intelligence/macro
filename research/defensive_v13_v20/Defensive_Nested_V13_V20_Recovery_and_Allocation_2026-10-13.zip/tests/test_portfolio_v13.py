"""Portfolio V13 unit tests; no vendor acquisition, external side effects or live sizing."""
import unittest
import pandas as pd
import numpy as np
import portfolio_v13 as p
class PortfolioTests(unittest.TestCase):
 def sample(self):
  days=pd.date_range('2020-01-02',periods=3,freq='B')
  return pd.DataFrame([
   (str(days[0].date()),1.,0.,'A'),(str(days[1].date()),1.2,1.,'A'),(str(days[2].date()),1.2,0.,'A'),
   (str(days[0].date()),1.,0.,'B'),(str(days[1].date()),.9,1.,'B'),(str(days[2].date()),.9,0.,'B')
  ],columns=['date','equity','exposure','symbol'])
 def test_equal_initial_cash_sleeves_without_rebalancing(self):
  d=p.combine(self.sample(),['A','B'])
  self.assertAlmostEqual(d.equity.iloc[-1],1.05)
  self.assertAlmostEqual(d.equity.iloc[1],1.05)
 def test_marked_market_fraction_weights_by_wealth(self):
  d=p.combine(self.sample(),['A','B'])
  self.assertAlmostEqual(d.exposure.iloc[1],1.)
  self.assertEqual(d.exposure.iloc[-1],0.)
 def test_only_cash_path(self):
  d=self.sample();d['equity']=1.;d['exposure']=0.
  q=p.metrics(p.combine(d,['A','B']))
  self.assertAlmostEqual(q['cagr'],0.);self.assertEqual(q['max_dd'],0.)
 def test_dd_on_combined_not_average_individual_dd(self):
  d=self.sample();d.loc[(d.symbol=='A')&(d.date==d.date.iloc[2]),'equity']=.5
  q=p.metrics(p.combine(d,['A','B']))
  self.assertLess(q['max_dd'],-.25)
 def test_missing_symbol_is_error(self):
  with self.assertRaises(ValueError):p.combine(self.sample(),['A','C'])
 def test_duplicate_symbol_date_is_error(self):
  a=self.sample();a=pd.concat([a,a.iloc[:1]])
  with self.assertRaises(ValueError):p.combine(a,['A','B'])
 def test_bad_dates_is_error(self):
  a=self.sample();a.loc[a.index[0],'date']='not-date'
  with self.assertRaises(ValueError):p.combine(a,['A','B'])
 def test_buyhold_no_fabricated_terminal_exit(self):
  d=pd.DataFrame({'open':[100.,120.],'close':[120.,110.]},index=pd.to_datetime(['2020-01-02','2020-01-03']))
  x=p.buyhold_curve(d,fee=.0005)
  self.assertAlmostEqual(x.iloc[-1],1.1/(1+.0005))
 def test_no_future_returns_in_previous_wealth(self):
  x=self.sample();a=p.combine(x,['A','B'])
  x.loc[(x.symbol=='A')&(x.date==x.date.iloc[2]),'equity']=100.
  b=p.combine(x,['A','B'])
  self.assertEqual(a.equity.iloc[1],b.equity.iloc[1])
 def test_cash_benchmark_constant(self):
  d=p.combine(self.sample(),['A','B'])
  c=p.cash_curve(d.index)
  self.assertTrue((c==1.).all())
 def test_benchmark_restrict_to_account_session_window(self):
  ix=pd.bdate_range('2017-12-29',periods=8)
  raw=pd.Series(range(8),index=ix,dtype=float)
  target=ix[2:6]
  got=p.align_to_account_window(raw,target)
  self.assertTrue(got.index.equals(target));self.assertEqual(got.tolist(),[2.,3.,4.,5.])
 def test_misaligned_benchmark_rejected(self):
  ix=pd.bdate_range('2018-01-02',periods=4);raw=pd.Series(range(4),index=ix)
  with self.assertRaises(ValueError):p.align_to_account_window(raw,ix.delete(2).append(pd.DatetimeIndex([pd.Timestamp('2018-02-01')])))
 def test_buyhold_rebases_to_account_start_not_vendor_start(self):
  ix=pd.to_datetime(['2010-01-04','2018-01-02','2018-01-03'])
  d=pd.DataFrame({'open':[10.,100.,101.],'close':[10.,101.,120.]},index=ix)
  got=p.buyhold_for_account(d,ix[1:],fee=.0005)
  self.assertAlmostEqual(got.iloc[-1],1.2/(1+.0005))
  d.iloc[0,0]=1.
  self.assertAlmostEqual(p.buyhold_for_account(d,ix[1:],fee=.0005).iloc[-1],got.iloc[-1])
if __name__=="__main__":unittest.main()