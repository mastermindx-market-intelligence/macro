"""V17 point-in-time strength and matched-strata checks."""
import sys,unittest
from pathlib import Path
import numpy as np
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import v17_strength as s
class PointInTime(unittest.TestCase):
 def fixture(self):
  ix=pd.bdate_range('2018-01-02',periods=320);return pd.Series(100*np.exp(np.arange(320)*.001),index=ix)
 def test_relative_pre_signal_known(self):
  x=self.fixture();y=x*1.
  self.assertAlmostEqual(s.prior_relative(x,y,250,63),0.)
 def test_prior_relative_ignores_signal_day_and_future(self):
  x=self.fixture();y=self.fixture()*.9
  a=s.prior_relative(x,y,250,63);x.iloc[250:]*=100.
  self.assertEqual(a,s.prior_relative(x,y,250,63))
 def test_prior_relative_missing_warmup(self):
  x=self.fixture();self.assertTrue(np.isnan(s.prior_relative(x,x,60,63)))
 def test_drawdown_future_invariant(self):
  x=self.fixture();a=s.prior_drawdown(x,240,126);x.iloc[240:]=1.;self.assertEqual(a,s.prior_drawdown(x,240,126))
 def test_drawdown_below_zero_at_decline(self):
  x=self.fixture();x.iloc[200:230]*=.5
  self.assertLess(s.prior_drawdown(x,230,126),0.)
 def test_independent_label_no_tail_fit(self):
  self.assertEqual(s.label(-.001),'LAGGING');self.assertEqual(s.label(.001),'LEADING');self.assertEqual(s.label(0.),'LAGGING')
 def test_missing_label_unknown(self):
  self.assertEqual(s.label(np.nan),'UNKNOWN')
if __name__=='__main__':unittest.main(verbosity=2)