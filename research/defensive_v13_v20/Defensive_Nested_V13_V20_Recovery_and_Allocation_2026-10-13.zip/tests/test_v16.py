"""V16 source and causal-clock mechanical tests."""
import sys,unittest
from pathlib import Path
import numpy as np
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import v16_engine as v
class V16Tests(unittest.TestCase):
 def test_beta_predictable_market_sensitivity(self):
  x=np.linspace(.001,.02,400);y=1.5*x
  ix=pd.date_range('2018-01-01',periods=400,freq='B')
  s=pd.Series(np.exp(np.cumsum(y)),index=ix);b=pd.Series(np.exp(np.cumsum(x)),index=ix)
  self.assertAlmostEqual(v.beta_before_signal(s,b,300),1.5,places=9)
 def test_beta_excludes_current_and_future(self):
  x=np.random.default_rng(42).normal(0,.01,450)
  ix=pd.date_range('2018-01-01',periods=450,freq='B')
  sp=pd.Series(np.exp(np.cumsum(x)),index=ix);a=pd.Series(np.exp(np.cumsum(1.3*x+.005*np.cos(np.arange(450)))),index=ix)
  fixed=v.beta_before_signal(a,sp,330)
  a.iloc[330:]*=np.linspace(1.,30.,len(a)-330);sp.iloc[330:]*=np.linspace(1.,.01,len(sp)-330)
  self.assertAlmostEqual(v.beta_before_signal(a,sp,330),fixed,places=10)
 def test_beta_no_future_history_returns_unknown(self):
  x=pd.Series(np.linspace(10,13,201))
  self.assertTrue(np.isnan(v.beta_before_signal(x,x,100)))
 def test_shuffling_retains_within_year_counts_and_values(self):
  years=np.array([2018,2018,2019,2019,2019]);delays=np.array([2,7,3,9,15])
  g=np.random.default_rng(5);out=v.shuffle_lags(years,delays,g)
  self.assertCountEqual(out[:2],delays[:2]);self.assertCountEqual(out[2:],delays[2:])
 def test_delay_price_has_following_open_and_common_endpoint(self):
  ix=pd.date_range('2019-01-02',periods=160,freq='B')
  d=pd.DataFrame({'open':np.arange(160)+100.,'close':np.arange(160)+101.},index=ix)
  result=v.net_at_delay(d,arm_i=15,endpoint_i=141,delay=9)
  self.assertAlmostEqual(result,(d.close.iloc[141]/d.open.iloc[25])*.9995/1.0005-1)
 def test_delay_does_not_choose_entry_after_endpoint(self):
  d=pd.DataFrame({'open':range(100,105),'close':range(100,105)})
  with self.assertRaises(ValueError):v.net_at_delay(d,0,3,3)
 def test_exact_zero_residual_for_beta_mirror(self):
  self.assertAlmostEqual(v.beta_adjusted_log(np.log(1.1**2),2.,np.log(1.1)),0.)
 def test_diff_in_market_neutral_returns(self):
  t=v.beta_adjusted_log(np.log(1.10),1.0,np.log(1.04))
  self.assertGreater(t,0.)
 def test_future_excluded_from_audit_group(self):
  y=np.array([2018,2018,2019,2019]);d=np.array([5,10,20,25]);r=np.random.default_rng(9)
  a=v.shuffle_lags(y,d,r);self.assertTrue((a>=0).all());self.assertEqual(len(a),len(y))
if __name__=="__main__":unittest.main(verbosity=2)
