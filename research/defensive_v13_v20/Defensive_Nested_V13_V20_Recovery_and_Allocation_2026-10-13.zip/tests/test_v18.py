"""V18 entry-path clock tests."""
import unittest,sys
from pathlib import Path
import pandas as pd
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import v18_paths as p
class PathTests(unittest.TestCase):
 def data(self):
  ix=pd.bdate_range('2018-01-02',periods=90)
  return pd.DataFrame({'open':100.,'high':105.,'low':95.,'close':101.},index=ix)
 def test_entry_day_included_and_next_open(self):
  d=self.data();d.loc[d.index[3],'open']=102.;x=p.horizon(d,3,5)
  self.assertAlmostEqual(x['net'],101/102*.9995/1.0005-1)
  self.assertEqual(x['end_date'],str(d.index[7].date()))
 def test_horizon_too_long_unknown(self):
  self.assertEqual(p.horizon(self.data(),85,10)['status'],'INCOMPLETE')
 def test_mean_adverse_uses_intraday_low(self):
  d=self.data();d.loc[d.index[4],'low']=80.
  x=p.horizon(d,3,10)
  self.assertAlmostEqual(x['mae'],-.20)
  self.assertEqual(x['lowest_i'],4)
 def test_later_bar_unchanged_earlier_horizon(self):
  d=self.data();a=p.horizon(d,3,5)
  d.loc[d.index[20]:,'close']=1000.;b=p.horizon(d,3,5)
  self.assertEqual(a,b)
 def test_cross_stocks_same_entry_and_end(self):
  x=self.data();y=self.data();y.close=110.
  self.assertEqual(p.horizon(x,3,10)['end_date'],p.horizon(y,3,10)['end_date'])
  self.assertGreater(p.horizon(y,3,10)['net'],p.horizon(x,3,10)['net'])
 def test_negative_adverse_not_absorbed_by_future_win(self):
  d=self.data();d.loc[d.index[3:10],'low']=80.;d.loc[d.index[20],'close']=140.
  r=p.horizon(d,3,20)
  self.assertLess(r['mae'],-.15);self.assertGreater(r['net'],0.)
if __name__=='__main__':unittest.main(verbosity=2)
