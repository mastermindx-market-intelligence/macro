"""V15 contemporaneous peer-control tests."""
import unittest
import pandas as pd
import numpy as np
import peer_control_v15 as q
class PeerControls(unittest.TestCase):
 def prices(self):
  ix=pd.to_datetime(['2018-01-02','2018-01-03','2018-01-04'])
  return pd.DataFrame({'open':[100.,101.,102.],'close':[101.,102.,110.]},index=ix)
 def test_same_interval_execution_fees(self):
  d=self.prices()
  self.assertAlmostEqual(q.net_interval(d,d.index[1],d.index[2]),110/101*.9995/1.0005-1)
 def test_no_exit_before_entry(self):
  d=self.prices()
  with self.assertRaises(ValueError):q.net_interval(d,d.index[-1],d.index[0])
 def test_selected_excludes_itself_from_control(self):
  x={'MCD':.10,'WMT':.0,'WM':.02,'COST':.04,'PG':.06}
  self.assertAlmostEqual(q.compare(x,'MCD'),.10-(0+.02+.04+.06)/4)
 def test_missing_core_name_not_ignored(self):
  x={'MCD':.10,'WMT':.00,'WM':.02,'COST':.04}
  with self.assertRaises(ValueError):q.compare(x,'MCD')
 def test_identical_returns_zero_effect(self):
  x=dict.fromkeys(['MCD','WMT','WM','COST','PG'],.15)
  self.assertAlmostEqual(q.compare(x,'MCD'),0.)
 def test_too_few_active_quarters_refuse_interval(self):
  a=pd.DataFrame({'signal_date':['2020-03-01']*5,'spread':[0.]*5})
  self.assertIsNone(q.block_ci(a)['interval'])
 def test_zero_effect_quarter_ci(self):
  ix=pd.date_range('2018-01-01',periods=900,freq='W')
  a=pd.DataFrame({'signal_date':ix.strftime('%Y-%m-%d'),'spread':np.zeros(len(ix))})
  k=q.block_ci(a,rep=400)
  self.assertAlmostEqual(k['low'],0.);self.assertAlmostEqual(k['high'],0.)
if __name__=='__main__':unittest.main()