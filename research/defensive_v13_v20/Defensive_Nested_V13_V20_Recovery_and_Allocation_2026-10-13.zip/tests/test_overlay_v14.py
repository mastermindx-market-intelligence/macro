"""Synthetic verification of always-SPY reserve overlay. No price acquisition."""
import unittest
import pandas as pd
import numpy as np
import overlay_v14 as ov
class OverlayTests(unittest.TestCase):
 def dates(self):return pd.bdate_range('2018-01-02',periods=4)
 def spy(self):
  ix=self.dates()
  return pd.DataFrame({'open':[100.,102.,105.,110.],'close':[101.,104.,107.,121.]},index=ix)
 def flat(self):
  ix=self.dates()
  return pd.DataFrame({'equity':[1.]*4,'exposure':[0.]*4},index=ix)
 def test_all_flat_equals_spy_hold(self):
  r=ov.overlay(self.spy(),self.flat())
  a=self.spy()
  for i in range(4):self.assertAlmostEqual(r.equity.iloc[i],a.close.iloc[i]/(a.open.iloc[0]*1.0005))
 def test_always_stock_equals_original_stock_path(self):
  x=self.flat();x.equity=[1.1,1.05,1.2,1.4];x.exposure=1.
  r=ov.overlay(self.spy(),x)
  np.testing.assert_allclose(r.equity.to_numpy(),x.equity.to_numpy(),atol=1e-10)
 def test_spy_gap_before_stock_entry(self):
  x=self.flat();x.loc[x.index[1]:,'equity']=1.05;x.loc[x.index[1]:,'exposure']=1.
  r=ov.overlay(self.spy(),x)
  expect=(101/(100*1.0005))*(102/101)*(.9995)*(1.05/1)
  self.assertAlmostEqual(r.equity.iloc[1],expect)
 def test_stock_sale_then_spy_bought_at_close(self):
  x=self.flat();x.loc[x.index[0],'exposure']=1.;x.loc[x.index[0],'equity']=1.
  x.loc[x.index[1]:,'equity']=.9
  r=ov.overlay(self.spy(),x)
  self.assertAlmostEqual(r.equity.iloc[1],.9/(1.0005))
 def test_sale_buys_spy_only_at_exit_day_close(self):
  x=self.flat();x.loc[x.index[0],'exposure']=1.;x.loc[x.index[1]:,'equity']=.9
  r=ov.overlay(self.spy(),x)
  self.assertAlmostEqual(r.equity.iloc[1],.9/(1+.0005))
  self.assertAlmostEqual(r.equity.iloc[2],r.equity.iloc[1]*(107/104))
 def test_no_lookahead(self):
  a=self.flat();first=ov.overlay(self.spy(),a)
  b=self.spy();b.loc[b.index[-1],'close']=1000.
  second=ov.overlay(b,a)
  np.testing.assert_allclose(first.equity.iloc[:-1],second.equity.iloc[:-1],atol=1e-10)
 def test_reject_partial_stock_fraction(self):
  x=self.flat();x.loc[x.index[2],'exposure']=.5
  with self.assertRaises(ValueError):ov.overlay(self.spy(),x)
 def test_reject_calendar_mismatch(self):
  x=self.flat().iloc[:-1]
  with self.assertRaises(ValueError):ov.overlay(self.spy(),x)
 def test_switch_cost_count(self):
  x=self.flat();x.exposure=[0,1,0,0];x.equity=[1,1.1,1.,1.]
  r=ov.overlay(self.spy(),x)
  self.assertEqual(int(r.spy_switches.sum()),3)
if __name__=='__main__':unittest.main()
