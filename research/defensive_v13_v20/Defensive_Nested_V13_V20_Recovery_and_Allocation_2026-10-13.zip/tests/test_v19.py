"""V19 horizon comparison invariants."""
import unittest,sys
from pathlib import Path
import pandas as pd
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import v19_horizon as q
class Horizons(unittest.TestCase):
 def fake(self):
  return pd.DataFrame({'symbol':['MCD','MCD','WM','WM'],'frame':['1D']*4,'episode':[1,1,1,1],'signal_date':['2020-01-03']*2+['2020-03-04']*2,'horizon':[20,63,20,63],'relative_four':[.01,.04,.02,.03],'relative_spy':[0.,.01,.01,.03]})
 def test_same_event_pairing(self):
  x=q.paired(self.fake(),20,63)
  self.assertEqual(len(x),2);self.assertAlmostEqual(x.iloc[0].incremental_relative_four,.03)
 def test_no_cross_episode_pairing(self):
  z=self.fake().drop(index=1)
  with self.assertRaises(ValueError):q.paired(z,20,63)
 def test_future_horizon_excludes_past_calcs(self):
  x=q.paired(self.fake(),20,63)
  self.assertAlmostEqual(x.iloc[0].relative_four_early,.01)
 def test_block_small_sample_no_interval(self):
  x=q.paired(self.fake(),20,63);self.assertIsNone(q.block_ci(x)['interval'])
 def test_constant_zero_effect(self):
  periods=pd.date_range('2018-01-01',periods=900,freq='W')
  x=pd.DataFrame({'signal_date':periods,'incremental_relative_four':np.zeros(len(periods))})
  z=q.block_ci(x,rep=400)
  self.assertAlmostEqual(z['low'],0.);self.assertAlmostEqual(z['high'],0.)
if __name__=='__main__':unittest.main(verbosity=2)
