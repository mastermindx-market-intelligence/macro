# PR #8711: independent assessment of archived test representation

**Finding: the proposed byte-preserving `.py` → `.py.txt` relocation is statically sufficient to remove the two identified filename-discovery findings under the existing law. This is not a repaired-candidate CI pass.** The original candidate remains associated with the actual failed contract-delta job and the incomplete CI observation recorded in this packet.

## Actual failure and observed source

The reviewed candidate is `9df735bbeaa8d0f4d4967296270bfb2246a5212f`. Run `37925499382`, attempt `1`, tested synthetic commit `c852221c2bc4d8275c11c686094ccbf472f82ad9`, whose parents are `c4cd21d597521603fb75fe7a4602424e088c6bfa` and the candidate, in that order.

The actual contract-delta job, `113803335510`, completed with `failure`. Its log lines 381–383 identify exactly two introduced suites and zero inherited findings:

- `research/theme_graph/economic_network_execution_20261009/continuation_pro_003/observation_implementation/v1/test_company_relationship_observations.py`
- `research/theme_graph/economic_network_execution_20261009/continuation_pro_003/observation_implementation/v2/test_company_relationship_observations.py`

The diagnostic is that these new pytest suites are named by no workflow run step. The complete 30,995-byte log was GET-read and hashed in memory as `85fe520d6cb4f29cafe4f990a792bb7c28218742ac72a54e17710f0858666334`. The selected diagnostic and checkout lines, with original line numbers, are retained in `artifact_read_001.json`; the raw log body was not retained.

The following full source bytes were independently read at the actual tested synthetic commit. They are preserved in `sources/` and verified by the accompanying artifact verifier.

| Source | Bytes | SHA-256 |
|---|---:|---|
| `scripts/audit_unrun_tests.py` | 50,447 | `e50ba44cb678761d55f1c5bb9828390bd7c21c1672760d6f52781ca194dd7d47` |
| `scripts/check_contract_delta.py` | 62,554 | `894f4e66dd323d5b17be2fe570bfd2fcb8456f92404d464a65b5b16f5c6a278f` |
| `.github/workflows/ci.yml` | 318,532 | `3f0e4df56a89b7b67cc0166e465c86aa90151b20d42e7e686c2772e9265c4f25` |

## Why the representation change addresses these findings

`audit_unrun_tests.py:140` declares the anchored filename expression `^(?:test_.+|.+_test)\.py$`. `_classify`, at lines 380–414, takes the repository candidate inventory, filters each basename through this expression, and only then reads the source and calls `defines_tests`. Discovery covers tracked suites throughout the repository, rather than only the top-level `tests/` directory. A file named `test_company_relationship_observations.py.txt` fails this existing anchored expression before its preserved Python text is inspected for test functions.

The shared `gated_unrun_suites` function, at lines 745–769, computes the actual census and the existing baseline/waiver filter. `check_contract_delta._head_findings`, at lines 250–263, calls this shared function. Its `compute_delta`, at lines 1055–1095, computes introduced suite identities as `head_suites - base_suites`. These are the same canonical functions used by the gate; this assessment does not propose a second discovery law, an exclusion, or a waiver.

The canonical runnable suite remains `tests/test_company_relationship_observations.py`. The actual tested owner manifest names this full path in the four-suite command, and the owner job's hosted log records **275 passed in 8.73 seconds**. The two archived version files are historical author evidence. Representing their unchanged bytes as text preserves that evidence without representing them as two additional runnable suites.

The standalone artifact verifier extracts the literal filename expression using Python's AST parser, without importing or executing repository source. It checks that both original basenames match, both proposed `.py.txt` basenames do not, and the canonical runnable suite basename still matches. The broader call-chain assessment above is a read-only source review, not execution of the gate against a repaired tree.

## Preservation map required for an honest relocation

Preserve the two exact byte sequences independently. A current path map should contain one row per version, with the version identifier, original full repository-relative logical path, full original checkpoint commit `6b58f15adae3b1d402d9993c52609d00083f1453`, last candidate commit `9df735bbeaa8d0f4d4967296270bfb2246a5212f`, current full archival path ending in `.py.txt`, byte length, and SHA-256. If Git blob IDs are retained, label them separately from SHA-256 hashes.

Keep the original frozen manifests and historical reports unchanged. Their authored logical paths continue to refer to their checkpoint; current readers should follow the explicit path map and verify the original length and digest. Do not silently rewrite those records to imply that the new paths existed at the old checkpoint. Include a correction record explaining the observed gate failure, the relocation-only change, and the fact that no application behavior or gate policy is changed by this representation repair.

Bind the canonical runnable suite separately in the map or correction record. This prevents a reader from treating v1 and v2 as interchangeable or from mistaking an archived source copy for the live test entrypoint. Source and proof references that are resolved from the current checkout must explicitly use the map; immutable historical-commit references remain valid on their own.

## Principal-reported application and independent limits

The principal subsequently reported applying the relocation in its native worktree, with PID `11730` completed and reconciled, while the branch HEAD was still the original candidate and the changes were unstaged. The reported preservation checks included all 53 application pins, the canonical test, and frozen checkpoint/proof manifests. This observer did not perform that relocation, read its native receipt, or independently verify the new current map. Those principal-reported facts and supplied hashes are retained separately in `PRINCIPAL_REPAIR_CONTEXT.json` and are not counted as this observer's evidence of a repaired runtime or CI pass.

There is no static reason to add two duplicate test runs or alter discovery policy to preserve these archival texts. The proposed filename representation removes exactly the two observed filename candidates. A new candidate may still have other defects, a different base, or different CI results; only its own exact-head checks can establish those facts. This packet retains the original failure and gives no release, merge, rights, history, fact, Graph1, production, or prediction authorization.

## Primary references

- [Actual contract-delta job](https://github.com/mastermindx-market-intelligence/macro/actions/runs/37925499382/job/113803335510)
- [Observed discovery law at the tested commit](https://github.com/mastermindx-market-intelligence/macro/blob/c852221c2bc4d8275c11c686094ccbf472f82ad9/scripts/audit_unrun_tests.py)
- [Observed contract-delta source at the tested commit](https://github.com/mastermindx-market-intelligence/macro/blob/c852221c2bc4d8275c11c686094ccbf472f82ad9/scripts/check_contract_delta.py)
- [Observed workflow at the tested commit](https://github.com/mastermindx-market-intelligence/macro/blob/c852221c2bc4d8275c11c686094ccbf472f82ad9/.github/workflows/ci.yml)
- Local preserved evidence: `artifact_read_001.json`, `source_and_owner_log_read_001.json`, `discovery_law_and_snapshot_002.json`, and `AVAILABLE_ARTIFACT_VERIFICATION.json`.
