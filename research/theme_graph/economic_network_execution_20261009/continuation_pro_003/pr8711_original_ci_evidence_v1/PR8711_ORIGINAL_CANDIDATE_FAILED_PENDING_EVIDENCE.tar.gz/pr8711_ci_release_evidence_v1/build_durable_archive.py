#!/usr/bin/env python3
"""Deterministic, scratch-only packaging of a frozen failed/pending CI record.

No network, Git, application imports or tests. The only executed audit is the
already-owned preserved-data verifier, from the safely extracted archive.
"""
import datetime
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import sys
import tarfile


ROOT = Path(__file__).resolve().parent
DESTINATION = ROOT / 'durable_archive'
PREFIX = 'pr8711_ci_release_evidence_v1'
ARCHIVE_NAME = 'PR8711_ORIGINAL_CANDIDATE_FAILED_PENDING_EVIDENCE.tar.gz'
MANIFEST_NAME = 'ARCHIVE_MANIFEST.json'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def safe(name):
    assert type(name) is str and name and not name.startswith('/') and '\\' not in name
    assert all(p not in {'', '.', '..'} for p in name.split('/'))
    assert str(PurePosixPath(name)) == name
    return name


def dump(path, value):
    raw = (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + '\n').encode()
    with path.open('xb') as handle:
        handle.write(raw)
    return {'name': path.name, 'bytes': len(raw), 'sha256': sha(raw)}


def main():
    # Enumerate only this bounded evidence directory. Exclude only the output
    # directory, never a source subtree. Reject links, caches and special files.
    assert not DESTINATION.exists(), 'archive output already exists; do not overwrite a frozen packet'
    rows = []
    for current, directories, files in os.walk(ROOT, followlinks=False):
        current = Path(current)
        for name in directories:
            node = current / name
            assert not node.is_symlink() and stat.S_ISDIR(node.lstat().st_mode), str(node)
            assert name not in {'__pycache__', '.git', '.pytest_cache', '.mypy_cache', '.ruff_cache'}, str(node)
        for name in files:
            node = current / name
            mode = node.lstat().st_mode
            assert stat.S_ISREG(mode) and not node.is_symlink(), str(node)
            relative = safe(node.relative_to(ROOT).as_posix())
            assert not relative.endswith(('.pyc', '.pyo', '.log')), relative
            raw = node.read_bytes()
            assert len(raw) <= 16 * 1024 * 1024, relative
            rows.append({'archive_name': safe(PREFIX + '/' + relative), 'source_relative_path': relative,
                         'bytes': len(raw), 'sha256': sha(raw)})
    rows.sort(key=lambda x: x['archive_name'])
    assert len(rows) == len({row['archive_name'] for row in rows})
    total = sum(row['bytes'] for row in rows)
    assert total <= 64 * 1024 * 1024
    original_verification = json.loads((ROOT / 'AVAILABLE_ARTIFACT_VERIFICATION.json').read_text())
    assert original_verification['denominators']['artifacts_observed_and_retained'] == 13
    assert original_verification['completeness']['all_planned_packs_observed'] is False
    assert original_verification['completeness']['final_semantic_aggregate_observed'] is False
    assert original_verification['contract_delta']['conclusion'] == 'failure'
    assert sum(row['source_relative_path'].endswith('/original.zip') for row in rows) == 13
    DESTINATION.mkdir()
    manifest = {'schema': 'gmi.pr8711.deterministic_evidence_archive_manifest/v1',
                'archive_name': ARCHIVE_NAME, 'archive_prefix': PREFIX,
                'frozen_head': original_verification['identity']['subject_head_sha'],
                'run_id': original_verification['identity']['workflow_run_id'], 'attempt': 1,
                'frozen_observation_completed_at_utc': original_verification['frozen_observation_completed_at_utc'],
                'disposition': original_verification['disposition'], 'regular_file_count': len(rows),
                'uncompressed_file_bytes': total, 'entries': rows,
                'normalized_metadata': {'archive_format': 'POSIX pax tar in gzip', 'gzip_mtime': 0,
                    'gzip_filename': '', 'tar_member_mtime': 0, 'uid': 0, 'gid': 0,
                    'uname': '', 'gname': '', 'mode_octal': '0644', 'entry_order': 'archive-name lexical'},
                'explicit_exclusions': ['durable_archive output directory created after input enumeration',
                    'raw job-log bodies were never retained', 'credentials and signed download URLs were never retained',
                    'unrelated sibling lanes and caches'],
                'manifest_is_external': True}
    manifest_record = dump(DESTINATION / MANIFEST_NAME, manifest)
    archive_path = DESTINATION / ARCHIVE_NAME
    with archive_path.open('xb') as destination:
        with gzip.GzipFile(filename='', fileobj=destination, mode='wb', compresslevel=9, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as archive:
                for row in rows:
                    raw = (ROOT / row['source_relative_path']).read_bytes()
                    assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
                    info = tarfile.TarInfo(row['archive_name'])
                    info.type = tarfile.REGTYPE
                    info.size = len(raw)
                    info.mode = 0o644
                    info.uid = info.gid = info.mtime = 0
                    info.uname = info.gname = ''
                    archive.addfile(info, io.BytesIO(raw))
    archive_raw = archive_path.read_bytes()
    archive_record = {'name': ARCHIVE_NAME, 'bytes': len(archive_raw), 'sha256': sha(archive_raw)}

    # Extract without extractall: every member is a declared regular file and
    # gets an exclusive safe write under the dedicated scratch extraction root.
    extracted = DESTINATION / 'verification_extract'
    extracted.mkdir()
    expected = {row['archive_name']: row for row in rows}
    with tarfile.open(archive_path, 'r:gz') as archive:
        members = archive.getmembers()
        assert len(members) == len(rows)
        assert [m.name for m in members] == [r['archive_name'] for r in rows]
        assert len({m.name for m in members}) == len(rows)
        for member in members:
            safe(member.name)
            assert member.name in expected and member.isreg() and not member.issym() and not member.islnk()
            assert member.mode == 0o644 and member.uid == member.gid == member.mtime == 0
            assert member.uname == member.gname == ''
            assert set(member.pax_headers).issubset({'path'})
            raw = archive.extractfile(member).read()
            row = expected[member.name]
            assert len(raw) == member.size == row['bytes'] and sha(raw) == row['sha256']
            target = extracted / member.name
            assert target.is_relative_to(extracted)
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as handle:
                handle.write(raw)
            assert target.read_bytes() == raw
    actual_names = sorted(p.relative_to(extracted).as_posix() for p in extracted.rglob('*') if p.is_file())
    assert actual_names == sorted(expected)
    extracted_root = extracted / PREFIX
    replay_name = 'ARCHIVE_REPLAY_AVAILABLE_ARTIFACT_VERIFICATION.json'
    command = [sys.executable, '-B', str(extracted_root / 'verify_available_artifacts.py'),
               '--snapshot', 'native_snapshot_003.json', '--output', replay_name]
    process = subprocess.run(command, cwd=extracted_root, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60,
                             env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
    assert process.returncode == 0, process.stderr.decode('utf-8', 'replace')[:2000]
    replay_path = extracted_root / replay_name
    replay = json.loads(replay_path.read_text())
    original_without_time = {k: v for k, v in original_verification.items() if k != 'created_at_utc'}
    replay_without_time = {k: v for k, v in replay.items() if k != 'created_at_utc'}
    assert original_without_time == replay_without_time
    for row in rows:
        for node in (ROOT / row['source_relative_path'], extracted / row['archive_name']):
            assert not node.is_symlink() and stat.S_ISREG(node.lstat().st_mode)
            raw = node.read_bytes()
            assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    after_names = sorted(p.relative_to(extracted).as_posix() for p in extracted.rglob('*') if p.is_file())
    assert after_names == sorted([*expected, PREFIX + '/' + replay_name])
    result = {'schema': 'gmi.pr8711.deterministic_evidence_archive_verification/v1',
              'verified_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'archive': archive_record, 'manifest': manifest_record, 'status': 'VERIFIED_FROZEN_FAILED_PENDING_PACKET',
              'regular_file_count': len(rows), 'uncompressed_file_bytes': total,
              'actual_artifact_zip_count': 13, 'actual_artifact_json_member_count': 13,
              'expected_complete_artifact_count': 15, 'missing_pack': 0, 'final_aggregate_observed': False,
              'contract_delta_conclusion': 'failure', 'workflow_conclusion_observed': False,
              'normalized_metadata_verified': True, 'unique_regular_files_only': True,
              'all_manifest_entries_extracted_and_verified': True,
              'original_files_unchanged_after_packaging': True,
              'all_preserved_extracted_files_unchanged_after_verifier': True,
              'replay_verifier': {'relative_command': ['python', '-B', PREFIX + '/verify_available_artifacts.py',
                  '--snapshot', 'native_snapshot_003.json', '--output', replay_name], 'exit_code': process.returncode,
                  'stdout_sha256': sha(process.stdout), 'stderr_bytes': len(process.stderr),
                  'output': {'path': PREFIX + '/' + replay_name, 'bytes': replay_path.stat().st_size,
                             'sha256': sha(replay_path.read_bytes())},
                  'matches_original_except_created_at_utc': True,
                  'assertions_passed': replay['verification']['assertions_passed']},
              'extra_extracted_output_accounted_for': PREFIX + '/' + replay_name,
              'authority': {'merge_authorized': False, 'ci_rerun': False, 'native_mutation': False,
                            'git_mutation': False, 'application_imports_or_tests': False}}
    verification_record = dump(DESTINATION / 'ARCHIVE_VERIFICATION.json', result)
    readme = f'''# PR8711 original-candidate failed/pending evidence archive

**Frozen original candidate; failed contract gate; incomplete overall CI proof.**

Observation bound: 2026-10-09 12:14:53.330798 UTC. Candidate: `9df735bbeaa8d0f4d4967296270bfb2246a5212f`. Run: `37925499382`, attempt `1`.

This archive preserves all **13/13 actually available artifacts**, comprising the plan, changed paths and packs 1–11, with original ZIPs and exact JSON members. Complete-run expectation was **15** artifacts; pack 0 and final semantic aggregate were missing. The available fragments contain **97/98 selected jobs and 300/316 planned proof steps**. All 300 observed steps passed. The missing 16 belong to `ci-control-plane-contracts`. The owner command actually logged **275 passed in 8.73s**. Contract-delta actually failed with **2 introduced, 0 inherited** findings. The workflow itself was still in progress with null conclusion.

## Transfer files

| File | Bytes | SHA-256 |
|---|---:|---|
| `{ARCHIVE_NAME}` | {archive_record['bytes']} | `{archive_record['sha256']}` |
| `{MANIFEST_NAME}` | {manifest_record['bytes']} | `{manifest_record['sha256']}` |
| `ARCHIVE_VERIFICATION.json` | {verification_record['bytes']} | `{verification_record['sha256']}` |

Keep this README with those three files. The archive contains **{len(rows)} regular files**, totaling **{total:,} uncompressed file bytes**, under `{PREFIX}/`. The external manifest explicitly enumerates every archive name, length and SHA-256. Archive metadata, gzip time/name and entry order are normalized. There are no links, duplicate names or traversal entries. Credentials, signed download URLs, raw log bodies, caches and unrelated work are excluded. The retained whole-log hashes were computed during actual in-memory GETs; only bounded sanitized excerpts remain.

Entry points inside the archive: `OBSERVATION_REPORT.md`, `FOCUSED_OBSERVATION.json`, `AVAILABLE_ARTIFACT_VERIFICATION.json`, `ARTIFACT_INVENTORY.json`, and `ARCHIVE_REPRESENTATION_ASSESSMENT.md`. `PACKAGING_NOTES.md` documents explicit context-copy paths and preparation adjustments. `native_read_scripts.json` contains exact GET scripts and all six reconciled native PIDs.

Extraction was checked against every manifest entry. The unchanged preserved-data verifier then ran successfully from that extracted layout, with a fresh output filename. All 2,672 assertions passed, and its result equals the original apart from `created_at_utc`. The extra replay output is separately accounted for in `ARCHIVE_VERIFICATION.json`; it was not added to or used to change this frozen archive. Every original and extracted preserved file remained byte-identical after replay.

With Python 3 and PyYAML, a reviewer can run from the extracted evidence directory:

```sh
PYTHONDONTWRITEBYTECODE=1 python -B verify_available_artifacts.py --snapshot native_snapshot_003.json --output FRESH_REPLAY.json
```

Use a new output name. This reads preserved observations without repository imports, application tests, Git, native operations or network. It cannot turn the missing pack/final aggregate into a pass and does not certify any repaired candidate. Root owns the subsequent material correction, new-head CI and release adjudication.
'''
    with (DESTINATION / 'ARCHIVE_README.md').open('x', encoding='utf-8') as handle:
        handle.write(readme)
    print(json.dumps({'archive_directory': str(DESTINATION), 'archive': archive_record, 'manifest': manifest_record,
                      'verification': verification_record, 'readme': {'name': 'ARCHIVE_README.md',
                          'bytes': (DESTINATION / 'ARCHIVE_README.md').stat().st_size,
                          'sha256': sha((DESTINATION / 'ARCHIVE_README.md').read_bytes())},
                      'regular_files': len(rows), 'uncompressed_file_bytes': total,
                      'replayed_assertions': replay['verification']['assertions_passed'],
                      'status': result['status']}, indent=2))


if __name__ == '__main__':
    main()
