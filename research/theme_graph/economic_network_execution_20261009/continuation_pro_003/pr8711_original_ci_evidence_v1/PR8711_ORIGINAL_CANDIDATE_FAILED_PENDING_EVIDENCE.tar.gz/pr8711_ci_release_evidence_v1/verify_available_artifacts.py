#!/usr/bin/env python3
"""Verify the frozen, incomplete PR8711 artifact record without app imports.

Reads preserved GET receipts, ZIP bytes, JSON members and source text only.
Uses stdlib plus PyYAML safe parsing. Does not run CI, the planner, repository
scripts, application imports, tests, network requests, Git or native commands.
The known failed contract gate and missing pack/final evidence remain separate
from successful verification of the bytes which were actually observed.
"""
import argparse
import ast
import base64
import collections
import datetime
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import stat
import unicodedata
import zipfile

import yaml


ROOT = Path(__file__).resolve().parent
REPO = 'mastermindx-market-intelligence/macro'
HEAD = '9df735bbeaa8d0f4d4967296270bfb2246a5212f'
BASE = 'c4cd21d597521603fb75fe7a4602424e088c6bfa'
TESTED = 'c852221c2bc4d8275c11c686094ccbf472f82ad9'
TREE = '3e047aedd939f52570d696f3b9ec721e0b5eb903'
RUN = '37925499382'
OWNER = 'company-relationship-candidates'
COMMAND = ('python -m pytest tests/test_company_relationship_candidates.py '
           'tests/test_company_pinned_relationship_candidates.py '
           'tests/test_company_relationship_review_set.py '
           'tests/test_company_relationship_observations.py -q')
OWNER_PROOF = 'File, pinned-source and immutable observation replay contracts'
MANIFEST_PIN = (1248681, 'e4bbeca16e38e8dd73efc2051ef0757b368afe65697f09e77b08a3a2b2746c7c')
MANIFEST_BLOB = '8b685ed536bcf1fb1600639a874b60e50f9cc148'
SOURCE_PINS = {
    'scripts/ci_semantic_proof.py': (73298, '9df4b9a9a8d68f7e9aa34a8eebe99e8d17e27f2ef0560eadcc050f3130359158'),
    'scripts/run_ci_pack.py': (223426, '65564916a55eb806d3d9fb0cd4e12726f05fec953f6e47ccd9240f5a141049df'),
    'scripts/check_contract_delta.py': (62554, '894f4e66dd323d5b17be2fe570bfd2fcb8456f92404d464a65b5b16f5c6a278f'),
    '.github/workflows/ci.yml': (318532, '3f0e4df56a89b7b67cc0166e465c86aa90151b20d42e7e686c2772e9265c4f25'),
    'scripts/audit_unrun_tests.py': (50447, 'e50ba44cb678761d55f1c5bb9828390bd7c21c1672760d6f52781ca194dd7d47'),
}
ARCHIVE_PREFIX = ('research/theme_graph/economic_network_execution_20261009/'
                  'continuation_pro_003/observation_implementation/')
FAILED_PATHS = [ARCHIVE_PREFIX + version + '/test_company_relationship_observations.py'
                for version in ('v1', 'v2')]


def canonical(value, *, ascii=False):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=ascii).encode('utf-8')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def digest(value):
    return sha(canonical(value))


def blob_sha(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def safe(name):
    assert type(name) is str and name and not name.startswith('/') and '\\' not in name
    assert all(part not in {'', '.', '..'} for part in name.split('/'))
    assert str(PurePosixPath(name)) == name
    return name


def read(relative):
    path = ROOT / safe(relative)
    for node in (path, *path.parents):
        if node.is_relative_to(ROOT):
            assert not node.is_symlink(), ('symlink', relative)
    assert stat.S_ISREG(path.lstat().st_mode), ('not regular', relative)
    raw = path.read_bytes()
    assert len(raw) <= 16 * 1024 * 1024
    return raw


def json_bytes(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            assert key not in result, ('duplicate JSON key', key)
            result[key] = value
        return result
    return json.loads(raw.decode('utf-8', 'strict'), object_pairs_hook=pairs)


def document(relative):
    return json_bytes(read(relative))


def file_record(relative):
    raw = read(relative)
    return {'path': relative, 'bytes': len(raw), 'sha256': sha(raw)}


class UniqueSafeLoader(yaml.SafeLoader):
    pass


def unique_mapping(loader, node, deep=False):
    loader.flatten_mapping(node)
    pairs = loader.construct_pairs(node, deep=deep)
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate YAML mapping key: ' + repr(key))
        result[key] = value
    return result


UniqueSafeLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, unique_mapping)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--snapshot', default='native_snapshot_003.json')
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    checks = {}

    def check(name, condition):
        assert name not in checks, ('duplicate assertion name', name)
        checks[name] = bool(condition)
        assert condition, name

    snap = document(args.snapshot)
    first = document('native_snapshot_001.json')
    second = document('discovery_law_and_snapshot_002.json')
    read_one = document('artifact_read_001.json')
    read_two = document('artifact_read_002.json')
    source_receipt = document('source_and_owner_log_read_001.json')
    check('snapshot_frozen_time', snap['completed_at_utc'] == '2026-10-09T12:14:53.330798+00:00')
    for label, capture in (('initial', first), ('second', second), ('final_observed', snap)):
        check('metadata_gets_succeeded_' + label, all(x['returncode'] == 0 for x in capture['operations']))
        check('metadata_pagination_complete_' + label,
              capture['jobs']['total_count'] == len(capture['jobs']['jobs']) < 100
              and capture['checks']['total_count'] == len(capture['checks']['check_runs']) < 100
              and capture['artifacts']['total_count'] == len(capture['artifacts']['artifacts']) < 100)
        run = capture['run']
        check('run_identity_' + label,
              (run['id'], run['run_attempt'], run['head_sha'], run['event'])
              == (int(RUN), 1, HEAD, 'pull_request'))
        check('check_subjects_' + label, all(c['head_sha'] == HEAD for c in capture['checks']['check_runs']))
    check('run_not_concluded_at_bound', (snap['run']['status'], snap['run']['conclusion']) == ('in_progress', None))
    check('pr_head_at_bound', snap['pr']['head']['sha'] == HEAD and snap['pr']['number'] == 8711)
    tested = first['tested_commit']
    check('synthetic_merge_exact_parents', tested['sha'] == TESTED
          and [p['sha'] for p in tested['parents']] == [BASE, HEAD] and tested['tree']['sha'] == TREE)

    artifact_meta = snap['artifacts']['artifacts']
    by_id = {row['id']: row for row in artifact_meta}
    check('unique_artifact_ids_and_names', len(by_id) == len(artifact_meta) == 13
          and len({row['name'] for row in artifact_meta}) == 13)
    expected_names = {f'ci-semantic-plan-{RUN}-1', 'ci-changed-files',
                      *(f'ci-semantic-pack-{RUN}-{i}' for i in range(1, 12))}
    check('exact_observed_artifact_name_set', {r['name'] for r in artifact_meta} == expected_names)
    check('two_expected_artifacts_not_observed',
          f'ci-semantic-pack-{RUN}-0' not in expected_names
          and f'ci-semantic-evidence-{RUN}' not in expected_names)
    for label, capture in (('initial', first), ('second', second)):
        for row in capture['artifacts']['artifacts']:
            latest = by_id[row['id']]
            check('artifact_metadata_stable_' + label + '_' + str(row['id']),
                  all(row[k] == latest[k] for k in ('name', 'size_in_bytes', 'digest', 'expired', 'workflow_run')))
    transfers = {}
    for name, capture in (('artifact_read_001.json', read_one), ('artifact_read_002.json', read_two)):
        check('artifact_capture_no_diagnostics_' + name, capture['diagnostics'] == [])
        for row in capture['artifacts']:
            aid = row['artifact_id']
            check('unique_download_' + str(aid), aid not in transfers)
            transfers[aid] = (name, row)
    check('download_census_matches_observed_inventory', set(transfers) == set(by_id))
    retained_dirs = sorted(p.name for p in (ROOT / 'artifacts').iterdir())
    check('retained_directory_census', retained_dirs == sorted(str(aid) for aid in by_id))
    inventories = []
    members_by_name = {}
    for aid in sorted(by_id):
        api = by_id[aid]
        receipt_name, transfer = transfers[aid]
        check('artifact_run_binding_' + str(aid),
              api['workflow_run']['id'] == int(RUN) and api['workflow_run']['head_sha'] == HEAD
              and api['expired'] is False and transfer['returncode'] == 0
              and transfer['name'] == api['name']
              and transfer['endpoint'] == f'repos/{REPO}/actions/artifacts/{aid}/zip')
        zip_path = f'artifacts/{aid}/original.zip'
        raw = read(zip_path)
        check('zip_bytes_api_and_transfer_binding_' + str(aid),
              len(raw) == api['size_in_bytes'] == transfer['zip_bytes']
              and 'sha256:' + sha(raw) == api['digest']
              and sha(raw) == transfer['zip_sha256']
              and raw == base64.b64decode(transfer['zip_base64'], validate=True))
        archive = zipfile.ZipFile(io.BytesIO(raw))
        infos = archive.infolist()
        check('unique_single_zip_member_' + str(aid),
              len(infos) == len({x.filename for x in infos}) == len(transfer['members']) == 1)
        entry = infos[0]
        expected = transfer['members'][0]
        safe(entry.filename)
        check('zip_member_safe_regular_' + str(aid), not entry.is_dir() and not entry.flag_bits & 1
              and stat.S_IFMT(entry.external_attr >> 16) in (0, stat.S_IFREG)
              and entry.file_size <= 8 * 1024 * 1024)
        payload = archive.read(entry)
        relative = f'artifacts/{aid}/' + entry.filename
        check('exact_json_member_bytes_' + str(aid),
              entry.filename == expected['name'] and len(payload) == expected['bytes'] == entry.file_size
              and sha(payload) == expected['sha256'] and read(relative) == payload)
        check('directory_has_only_original_zip_and_member_' + str(aid),
              sorted(p.name for p in (ROOT / f'artifacts/{aid}').iterdir())
              == sorted(['original.zip', entry.filename]))
        check('unique_member_across_artifacts_' + entry.filename, entry.filename not in members_by_name)
        members_by_name[entry.filename] = {'document': json_bytes(payload), 'path': relative, 'artifact_id': aid}
        inventories.append({'artifact_id': aid, 'artifact_name': api['name'], 'source_receipt': receipt_name,
                            'api_metadata': api, 'zip': file_record(zip_path),
                            'members': [{**file_record(relative), 'member_name': entry.filename,
                                         'crc32': entry.CRC, 'compressed_size': entry.compress_size,
                                         'external_attr': entry.external_attr, 'create_system': entry.create_system}]})

    source_inventory = []
    for capture in (source_receipt, second):
        check('source_capture_no_diagnostics_' + capture['schema'], capture.get('diagnostics') == [])
        for item in capture.get('sources', []):
            path = item['path']
            raw = read('sources/' + path)
            check('source_pin_' + path, (len(raw), sha(raw)) == SOURCE_PINS[path])
            check('source_transfer_git_blob_' + path,
                  item['ref'] == TESTED and item['returncode'] == 0
                  and item['endpoint'] == f'repos/{REPO}/contents/{path}?ref={TESTED}'
                  and item['bytes'] == len(raw) and item['sha256'] == sha(raw)
                  and blob_sha(raw) == item['git_blob_sha']
                  and gzip.decompress(base64.b64decode(item['content_gzip_base64'], validate=True)) == raw)
            source_inventory.append({**file_record('sources/' + path), 'ref': TESTED,
                                     'git_blob_sha': item['git_blob_sha'], 'endpoint': item['endpoint']})
    check('complete_source_law_inventory', len(source_inventory) == 5
          and {r['path'][len('sources/'):] for r in source_inventory} == set(SOURCE_PINS))
    manifest_raw = read('sources/merged_legacy_jobs.yml')
    blob = read_one['tested_manifest_blob']
    check('actual_full_composed_manifest_pin', (len(manifest_raw), sha(manifest_raw)) == MANIFEST_PIN
          and blob_sha(manifest_raw) == MANIFEST_BLOB)
    check('actual_full_composed_manifest_transfer', blob['returncode'] == 0
          and blob['git_blob_sha'] == MANIFEST_BLOB and blob['sha256'] == MANIFEST_PIN[1]
          and blob['bytes'] == MANIFEST_PIN[0]
          and gzip.decompress(base64.b64decode(blob['content_gzip_base64'], validate=True)) == manifest_raw
          and gzip.decompress(read('sources/merged_legacy_jobs.transfer.gz')) == manifest_raw)
    manifest = yaml.load(manifest_raw.decode('utf-8'), Loader=UniqueSafeLoader)
    check('manifest_root_shape', isinstance(manifest, dict) and set(manifest) == {'jobs'})
    definitions = manifest['jobs']
    code_ids = [jid for jid, definition in definitions.items() if definition.get('gate', 'code') == 'code']
    check('manifest_denominators', len(definitions) == 254 and len(code_ids) == 182)

    plan_path = members_by_name['ci-plan.json']['path']
    plan = members_by_name['ci-plan.json']['document']
    changed = members_by_name['changed-files.json']['document']
    check('raw_plan_pin', (len(read(plan_path)), sha(read(plan_path))) == (
        95459, 'bc745a5070ed7b39eab60114cf1d40223cd06ffc57a2b603b80de8fe9782eeb1'))
    check('plan_identity', (plan['workflow_run_id'], plan['workflow'], plan['event'], plan['role'],
          plan['subject_head_sha'], plan['base_sha'], plan['tested_tree_sha'])
          == (RUN, 'ci', 'pull_request', 'pr_head', HEAD, BASE, TESTED))
    check('plan_schema_and_scope', plan['schema'] == 'ci.pack_plan.v2'
          and plan['authority_changed'] is True and plan['changed_from'] == BASE and plan['scope_mode'] == 'active')
    identity = {key: plan[key] for key in ('workflow_run_id', 'workflow', 'event', 'role', 'tested_tree_sha',
                                          'subject_head_sha', 'base_sha', 'plan_sha256')}
    check('changed_files_complete_unique', isinstance(changed, list)
          and len(changed) == len(set(changed)) == plan['changed_files_count'] == snap['pr']['changed_files'] == 110)
    check('changed_files_digest', digest(changed) == plan['changed_files_sha256']
          == 'b3a170251b002d56f337fe9105eae5726cffa10d76aab882f7e7a01b1c394d3e')
    payload = {key: plan[key] for key in ('schema', 'workflow_run_id', 'workflow', 'event', 'role',
               'tested_tree_sha', 'subject_head_sha', 'base_sha', 'authority_changed', 'changed_from',
               'scope_mode', 'changed_files_sha256')}
    payload.update(pack_count=len(plan['packs']), eligible_job_ids=plan['eligible_jobs'],
                   pack_jobs=[p['jobs'] for p in plan['packs']], pack_weights=[p['weight'] for p in plan['packs']],
                   semantic_jobs=plan['semantic_jobs'])
    check('recomputed_logical_plan_digest', digest(payload) == plan['plan_sha256']
          == '5d5cb6561eb52f106148cf78196dce771e344b6a4d967e389ecc2d80917ba539')
    planned = {job['logical_job_id']: job for job in plan['semantic_jobs']}
    check('selected_job_order_unique', list(planned) == plan['eligible_jobs']
          and len(planned) == len(plan['semantic_jobs']) == plan['eligible_job_count'] == 98)
    check('excluded_job_order_unique', len(plan['skipped_jobs']) == len(set(plan['skipped_jobs']))
          == plan['skipped_job_count'] == 84)
    check('code_job_partition_from_actual_manifest', not set(planned) & set(plan['skipped_jobs'])
          and set(planned) | set(plan['skipped_jobs']) == set(code_ids) and plan['legacy_job_count'] == 182)
    check('full_twelve_pack_plan', [p['index'] for p in plan['packs']] == list(range(12))
          == plan['nonempty_pack_indices'] and plan['matrix'] == {'include': [{'pack': i} for i in range(12)]})
    partition = [jid for p in plan['packs'] for jid in p['jobs']]
    check('complete_unique_pack_job_partition', len(partition) == len(set(partition)) == 98
          and set(partition) == set(planned))
    check('q07_present_but_not_run_by_this_plan', 'quant-q07-fitted-har-vol' in definitions
          and 'quant-q07-fitted-har-vol' in plan['skipped_jobs'])

    # Reconstruct identities and digests from exact tested manifest bytes.
    # This validates the captured planner's output/source binding, not its
    # path-scoping algorithm and not the result of executing its commands.
    runner_source = read('sources/scripts/run_ci_pack.py').decode('utf-8')
    runner_tree = ast.parse(runner_source)
    runner_values = [ast.literal_eval(n.value) for n in runner_tree.body if isinstance(n, ast.Assign)
                     and any(isinstance(t, ast.Name) and t.id == 'RUNNER_CONTRACT' for t in n.targets)]
    check('runner_contract_literal_read_from_source', runner_values == ['ci-pack/linux-x86_64/python-3.12.13/node-20/v2'])
    allowed_actions = [{'uses': 'actions/checkout@v4', 'with': {}},
                       {'uses': 'actions/checkout@v4', 'with': {'fetch-depth': 0}},
                       {'uses': 'actions/setup-python@v5', 'with': {'python-version': '3.12'}},
                       {'uses': 'actions/setup-node@v4', 'with': {'node-version': '20'}}]
    source_semantics = []
    expected_units = {}
    for jid, job in planned.items():
        definition = definitions[jid]
        check('source_job_pack_' + jid, jid in plan['packs'][job['pack_index']]['jobs'])
        raw_steps = definition['steps']
        actions = [{'uses': s['uses'], 'with': s.get('with') or {}} for s in raw_steps if 'uses' in s]
        check('action_contract_supported_' + jid, all(action in allowed_actions for action in actions))
        installs = [str(s.get('run', '')) for s in raw_steps if 'pip install' in str(s.get('run', ''))]
        check('single_dependency_command_' + jid, len(installs) <= 1)
        action_digest = sha(canonical(actions, ascii=True))
        execution = {'dependency_install_command': installs[0] if installs else None,
                     'timeout_minutes': definition.get('timeout-minutes'),
                     'runner_contract': runner_values[0] + '/actions-' + action_digest}
        check('source_job_execution_digest_' + jid, digest(execution) == job['job_exec_sha256'])
        specs = []
        semantic_steps = []
        for index, step in enumerate(raw_steps):
            if 'run' not in step or 'pip install' in str(step.get('run', '')):
                continue
            proof = ' '.join(unicodedata.normalize('NFC', step.get('proof_id', step.get('name'))).split())
            check('source_proof_identity_' + jid + '_' + str(index),
                  0 < len(proof) <= 256 and not any(ord(ch) < 32 or ord(ch) == 127 for ch in proof))
            semantics = {'run': step['run']}
            semantics.update({key: step[key] for key in ('env', 'if', 'shell', 'timeout-minutes', 'working-directory')
                              if key in step})
            spec = {'proof_id': proof, 'step_spec_sha256': digest(semantics)}
            key = (jid, proof)
            check('unique_source_unit_' + repr(key), key not in expected_units)
            expected_units[key] = spec
            specs.append(spec)
            semantic_steps.append({**spec, 'manifest_step_index': index, 'execution_semantics': semantics})
        check('all_source_step_specs_match_plan_' + jid, specs == job['steps'])
        source_semantics.append({'logical_job_id': jid, 'pack_index': job['pack_index'],
                                 'job_exec_sha256': digest(execution), 'execution_contract_payload': execution,
                                 'action_contracts': actions, 'action_contract_sha256': action_digest,
                                 'steps': semantic_steps})
    check('complete_planned_source_proof_denominator', len(expected_units) == 316)

    observed_jobs = {}
    observed_units = {}
    fragment_inventory = []
    for i in range(1, 12):
        name = f'pack-{i}.json'
        member = members_by_name[name]
        fragment = member['document']
        check('fragment_closed_shape_' + str(i),
              set(fragment) == {'schema', *identity, 'pack_index', 'infrastructure', 'jobs'}
              and fragment['schema'] == 'ci.semantic_fragment.v1')
        check('fragment_exact_identity_' + str(i), all(fragment[k] == value for k, value in identity.items())
              and fragment['pack_index'] == i)
        check('fragment_no_infrastructure_findings_' + str(i), fragment['infrastructure'] == [])
        check('fragment_job_partition_' + str(i),
              sorted(j['logical_job_id'] for j in fragment['jobs']) == sorted(plan['packs'][i]['jobs']))
        count = 0
        for job in fragment['jobs']:
            jid = job['logical_job_id']
            check('fragment_job_closed_shape_' + jid,
                  set(job) == {'logical_job_id', 'job_exec_sha256', 'infrastructure', 'steps'})
            check('fragment_job_unique_source_binding_' + jid,
                  jid not in observed_jobs and planned[jid]['pack_index'] == i
                  and planned[jid]['job_exec_sha256'] == job['job_exec_sha256'])
            check('fragment_job_infrastructure_' + jid, job['infrastructure'] == {'outcome': 'passed'})
            check('fragment_job_step_order_' + jid,
                  [s['proof_id'] for s in job['steps']] == [s['proof_id'] for s in planned[jid]['steps']])
            observed_jobs[jid] = job
            for step in job['steps']:
                key = (jid, step['proof_id'])
                check('observed_unit_closed_shape_' + repr(key),
                      set(step) == {'proof_id', 'step_spec_sha256', 'outcome', 'failure_signature'})
                check('observed_unit_unique_exact_source_binding_' + repr(key), key not in observed_units
                      and step['step_spec_sha256'] == expected_units[key]['step_spec_sha256'])
                check('observed_unit_result_' + repr(key), step['outcome'] == 'passed' and step['failure_signature'] is None)
                observed_units[key] = step
                count += 1
        fragment_inventory.append({'pack_index': i, 'artifact_id': member['artifact_id'],
                                   **file_record(member['path']), 'jobs': len(fragment['jobs']),
                                   'proof_steps': count, 'logical_job_ids': [j['logical_job_id'] for j in fragment['jobs']],
                                   'result': 'all_observed_semantic_steps_passed'})
    missing_jobs = [jid for jid in planned if jid not in observed_jobs]
    missing_units = [{'logical_job_id': jid, **spec} for (jid, proof), spec in expected_units.items()
                     if (jid, proof) not in observed_units]
    check('exact_missing_pack_zero_job', missing_jobs == ['ci-control-plane-contracts']
          and plan['packs'][0]['jobs'] == missing_jobs)
    check('observed_semantic_accounting_complete_for_available_fragments',
          len(observed_jobs) + len(missing_jobs) == 98 and len(observed_units) + len(missing_units) == 316)
    check('final_aggregate_not_retained', 'ci-semantic-evidence.json' not in members_by_name)

    hosted = {job['name']: job for job in snap['jobs']['jobs']}
    check('unique_hosted_names', len(hosted) == len(snap['jobs']['jobs']) == 15)
    check('hosted_exact_pack_set', {name for name in hosted if name.startswith('ci-pack-')}
          == {f'ci-pack-{i}' for i in range(12)})
    for i in range(12):
        job = hosted[f'ci-pack-{i}']
        check('hosted_pack_state_' + str(i),
              (job['status'], job['conclusion']) == (('in_progress', None) if i == 0 else ('completed', 'success')))
    check('contract_gate_failed', hosted['contract-delta']['id'] == 113803335510
          and (hosted['contract-delta']['status'], hosted['contract-delta']['conclusion']) == ('completed', 'failure'))
    check('plan_succeeded_gate_not_yet_observed', hosted['ci-plan']['conclusion'] == 'success' and 'ci-gate' not in hosted)
    check('trusted_ci_skipped', hosted['trusted-ci']['conclusion'] == 'skipped')

    owner = next(s for s in source_semantics if s['logical_job_id'] == OWNER)
    check('owner_exact_four_suite_command', owner['pack_index'] == 11
          and len(owner['steps']) == 1 and owner['steps'][0]['proof_id'] == OWNER_PROOF
          and owner['steps'][0]['execution_semantics'] == {'run': COMMAND}
          and owner['steps'][0]['step_spec_sha256'] == '3f346c8660ce1278b5d782982c639324dfa4412faa4856e91d19d822a0481d70'
          and owner['job_exec_sha256'] == '5ff9e1dd799a76ff34ad59e95d95cafbc10cea6c6f4cb58da6922bb28801ff6f')
    owner_log = source_receipt['owner_log']
    contract_log = read_one['contract_delta_log']
    for label, log, job_id, length, log_hash in (
        ('owner', owner_log, 113804502836, 116708, 'd4743c146660c630e65b810dfb16e7123789d79ea4b0041335b69365affc1102'),
        ('contract_delta', contract_log, 113803335510, 30995, '85fe520d6cb4f29cafe4f990a792bb7c28218742ac72a54e17710f0858666334'),
    ):
        check('raw_log_read_receipt_' + label,
              (log['job_id'], log['returncode'], log['bytes'], log['sha256'], log['raw_body_retained'])
              == (job_id, 0, length, log_hash, False)
              and log['endpoint'] == f'repos/{REPO}/actions/jobs/{job_id}/logs')
        selected = {row['line']: row['text'] for row in log['selected_lines']}
        check('log_excerpt_line_numbers_' + label, len(selected) == len(log['selected_lines'])
              and all(type(n) is int and 1 <= n <= log['line_count'] for n in selected))
        check('actual_checkout_log_' + label, any(
              'git log -1 --format=%H' in text and selected.get(n + 1, '').endswith('Z ' + TESTED)
              for n, text in selected.items()))
    check('owner_log_hosted_job_binding', hosted['ci-pack-11']['id'] == owner_log['job_id'])
    groups = owner_log['owner_groups']
    check('owner_full_result_group', len(groups) == 1 and groups[0]['start_line'] == 1203
          and groups[0]['end_line'] == 1209
          and [r['line'] for r in groups[0]['lines']] == list(range(1203, 1210))
          and OWNER + ' — ' + OWNER_PROOF in groups[0]['lines'][0]['text']
          and groups[0]['lines'][5] == {'line': 1208, 'text': '2026-10-09T11:59:15.6736782Z 275 passed in 8.73s'}
          and '##[endgroup]' in groups[0]['lines'][-1]['text'])
    errors = [row for row in contract_log['selected_lines']
              if 'is a new pytest suite named by no run: step in any workflow' in row['text']]
    check('exact_two_introduced_archived_test_findings', len(errors) == 2
          and [row['line'] for row in errors] == [381, 382]
          and all(path + ' is a new pytest suite' in row['text'] for path, row in zip(FAILED_PATHS, errors)))
    delta_count_lines = [r for r in contract_log['selected_lines'] if 'contract-delta: 2 introduced, 0 inherited' in r['text']]
    check('actual_contract_delta_denominators', len(delta_count_lines) == 1
          and delta_count_lines[0]['line'] == 383 and '(base c4cd21d59752)' in delta_count_lines[0]['text'])
    check('actual_contract_delta_command', any(
          'python scripts/check_contract_delta.py --base ' + BASE in r['text'] for r in contract_log['selected_lines']))

    # Static representation assessment: extract a literal from the observed
    # source AST and apply its filename law. No code from that module executes.
    discovery_tree = ast.parse(read('sources/scripts/audit_unrun_tests.py').decode('utf-8'))
    assignments = [n for n in discovery_tree.body if isinstance(n, ast.Assign)
                   and any(isinstance(t, ast.Name) and t.id == '_SUITE_FILENAME' for t in n.targets)]
    check('discovery_single_filename_law', len(assignments) == 1)
    expr = assignments[0].value
    check('discovery_filename_law_literal_call', isinstance(expr, ast.Call)
          and isinstance(expr.func, ast.Attribute) and isinstance(expr.func.value, ast.Name)
          and expr.func.value.id == 're' and expr.func.attr == 'compile' and len(expr.args) == 1)
    pattern = ast.literal_eval(expr.args[0])
    check('anchored_discovery_law', pattern == r'^(?:test_.+|.+_test)\.py$')
    law = re.compile(pattern)
    check('static_two_representation_changes_remove_filename_candidates',
          all(law.match(Path(path).name) and not law.match(Path(path + '.txt').name) for path in FAILED_PATHS)
          and law.match('test_company_relationship_observations.py') is not None)

    processes = document('native_read_scripts.json')
    check('all_native_processes_reconciled', processes['total_started'] == processes['total_reconciled'] == 6
          and processes['unresolved_pids'] == []
          and [p['pid'] for p in processes['processes']] == [85752, 90893, 98043, 2744, 9986, 20474]
          and all(p['exit_code'] == 0 and p['status'] == 'completed_and_reconciled' for p in processes['processes']))

    inventory_all = [{'logical_job_id': jid, 'gate': definition.get('gate', 'code'),
                      'selected_by_observed_plan': jid in planned,
                      'explicitly_excluded_code_job': jid in plan['skipped_jobs']}
                     for jid, definition in definitions.items()]
    complete_units = [{'logical_job_id': jid, 'pack_index': planned[jid]['pack_index'],
                       'job_exec_sha256': planned[jid]['job_exec_sha256'], **unit}
                      for (jid, proof), unit in observed_units.items()]
    input_files = ['native_snapshot_001.json', 'discovery_law_and_snapshot_002.json', args.snapshot,
                   'artifact_read_001.json', 'artifact_read_002.json', 'source_and_owner_log_read_001.json',
                   'native_read_scripts.json', 'materialization_001.json', 'materialization_002.json',
                   'source_materialization_001.json', 'discovery_materialization_002.json']
    output = {
        'schema': 'gmi.pr8711.independent_available_ci_artifact_review/v1',
        'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'reviewer': '/root/ci_release_evidence', 'identity': identity,
        'tested_commit_parents': [BASE, HEAD], 'tested_commit_tree_sha': TREE,
        'disposition': 'CONTRACT_DELTA_FAILED__AVAILABLE_ARTIFACTS_VALID__RUN_AND_FULL_SEMANTIC_PROOF_INCOMPLETE',
        'frozen_observation_completed_at_utc': snap['completed_at_utc'],
        'verification': {'all_available_evidence_checks_passed': all(checks.values()),
                         'assertions_passed': sum(checks.values()), 'assertions_evaluated': len(checks),
                         'assertions': checks, 'repository_scripts_imported_or_executed': False,
                         'application_imports_or_tests_run': False, 'yaml_parser': 'PyYAML SafeLoader with duplicate-key rejection',
                         'yaml_version': yaml.__version__, 'verifier': file_record('verify_available_artifacts.py')},
        'denominators': {'artifact_names_expected_for_complete_run': 15, 'artifacts_observed_and_retained': 13,
                         'planned_packs': 12, 'observed_fragments': 11, 'manifest_all_logical_jobs': 254,
                         'manifest_code_jobs': 182, 'manifest_other_gate_jobs': 72, 'selected_logical_jobs': 98,
                         'explicitly_excluded_code_jobs': 84, 'observed_logical_jobs': len(observed_jobs),
                         'planned_proof_steps': 316, 'observed_proof_steps': len(observed_units),
                         'owner_four_suite_pytest_passed': 275, 'contract_introduced_findings': 2,
                         'contract_inherited_findings': 0, 'changed_paths': 110},
        'completeness': {'all_available_api_artifacts_retained': True, 'all_planned_packs_observed': False,
                         'final_semantic_aggregate_observed': False, 'workflow_run_conclusion_observed': False,
                         'missing_packs': [0], 'missing_logical_jobs': missing_jobs, 'missing_units': missing_units,
                         'missing_artifact_names': [f'ci-semantic-pack-{RUN}-0', f'ci-semantic-evidence-{RUN}']},
        'observed_outcomes': dict(collections.Counter(s['outcome'] for s in observed_units.values())),
        'artifact_inventory': inventories, 'fragment_inventory': fragment_inventory,
        'manifest': {**file_record('sources/merged_legacy_jobs.yml'), 'git_blob_sha': MANIFEST_BLOB,
                     'ref': TESTED, 'all_job_inventory': inventory_all, 'code_job_ids': code_ids,
                     'selected_job_ids': list(planned), 'excluded_code_job_ids': plan['skipped_jobs']},
        'source_law_inventory': source_inventory, 'input_receipts': [file_record(path) for path in input_files],
        'plan': {'raw': file_record(plan_path), 'logical_sha256': plan['plan_sha256'],
                 'changed_files_sha256': plan['changed_files_sha256'], 'changed_files': changed,
                 'packs': plan['packs'], 'source_semantics': source_semantics},
        'fully_enumerated_observed_units': complete_units,
        'observed_units_canonical_sha256': digest(complete_units),
        'owner': {**owner, 'scope_paths': definitions[OWNER]['paths'], 'actual_fragment_result': observed_jobs[OWNER],
                  'hosted_job_id': hosted['ci-pack-11']['id'], 'actual_result_group': groups[0],
                  'raw_log_read': {key: owner_log[key] for key in ('endpoint', 'bytes', 'sha256', 'line_count', 'raw_body_retained')},
                  'raw_log_offline_reconstruction_possible': False},
        'contract_delta': {'hosted_job_id': 113803335510, 'status': 'completed', 'conclusion': 'failure',
                           'base_sha': BASE, 'introduced': 2, 'inherited': 0, 'failed_suite_paths': FAILED_PATHS,
                           'actual_error_lines': errors, 'actual_count_line': delta_count_lines[0],
                           'raw_log_read': {key: contract_log[key] for key in ('endpoint', 'bytes', 'sha256', 'line_count', 'raw_body_retained')}},
        'archive_representation_static_assessment': {'result': 'STATICALLY_SUFFICIENT_FOR_TWO_IDENTIFIED_FILENAME_FINDINGS',
                  'filename_regex': pattern, 'original_paths': FAILED_PATHS,
                  'proposed_current_archival_paths': [path + '.txt' for path in FAILED_PATHS],
                  'original_checkpoint_commit': '6b58f15adae3b1d402d9993c52609d00083f1453',
                  'requirements': ['Preserve each exact original byte sequence and digest.',
                      'Bind full checkpoint commit and repository logical path to current archival path, length and SHA256.',
                      'Retain frozen historical manifests unchanged; resolve them through an explicit path map.',
                      'Keep canonical runnable suite distinct and unchanged; do not change gate policy or add a waiver.'],
                  'applied_repair_independently_verified_by_this_observer': False,
                  'repaired_candidate_runtime_or_ci_pass_claimed': False},
        'hosted_run': {key: snap['run'][key] for key in ('id', 'run_attempt', 'status', 'conclusion', 'head_sha', 'updated_at', 'html_url')},
        'hosted_jobs': [{'id': j['id'], 'name': j['name'], 'status': j['status'], 'conclusion': j['conclusion'],
                         'started_at': j['started_at'], 'completed_at': j['completed_at'], 'html_url': j['html_url']}
                        for j in snap['jobs']['jobs']],
        'exact_head_checks': [{'id': c['id'], 'name': c['name'], 'status': c['status'], 'conclusion': c['conclusion'],
                               'head_sha': c['head_sha'], 'details_url': c['details_url']}
                              for c in snap['checks']['check_runs']],
        'native_processes': [{'pid': p['pid'], 'purpose': p['purpose'], 'exit_code': p['exit_code'], 'status': p['status']}
                             for p in processes['processes']],
        'proof_limits': [
            'This is a frozen failed/pending observation, not a concluded-run audit or merge authorization.',
            'Pack0 and the final aggregate were absent at the observation bound; no outcome is inferred for their missing units.',
            'Successful source, identity and result binding for 11 fragments does not waive the failed contract-delta gate.',
            'The selected/excluded plan partition and source digests were checked; the full path-scoping planner was not rerun.',
            '275 is the owner command pytest count. Proof-step, logical-job, pack and artifact counts use distinct denominators.',
            'Whole job logs were hashed in memory during GET. Only bounded sanitized excerpts remain; raw-log hashing cannot be independently replayed from these excerpts alone.',
            'The source-composition review is independent prior work. This observer did not certify application-code correctness, later repairs, current main freshness, holds, policy or accepted-source/native postmerge proof.',
            'No rights, history, fact, Graph1, production or prediction promotion is asserted.',
        ],
        'authority': {'merge_authorized': False, 'gate_waiver': False, 'release_helper_adjudication': False,
                      'live_freshness_or_holds_certified': False, 'native_application_writes': False,
                      'git_or_api_mutations': False, 'workflow_dispatch_rerun_or_cancellation': False},
    }
    target = ROOT / safe(args.output)
    assert target.parent == ROOT and not target.exists()
    with target.open('x', encoding='utf-8') as handle:
        json.dump(output, handle, indent=2, sort_keys=True, ensure_ascii=False)
        handle.write('\n')
    print(json.dumps({'file': str(target), 'bytes': target.stat().st_size, 'sha256': sha(target.read_bytes()),
                      'disposition': output['disposition'], 'denominators': output['denominators'],
                      'missing_proof_steps': len(missing_units), 'verification_assertions': len(checks)}, indent=2))


if __name__ == '__main__':
    main()
