# PR #8711 — frozen original-candidate CI evidence

**Disposition: contract-delta failed. The 13 artifacts available at the observation bound are authentic to the recorded run and internally/source consistent. The run, pack 0, and final semantic aggregate were still incomplete or absent. This is not a concluded-run PASS or merge authorization.**

The observation is frozen at **2026-10-09 12:14:53.330798 UTC**, by principal instruction after the archive-representation repair was prepared. No later state, repaired candidate, current main state, or new-head CI result is represented by this packet. The original failure is retained rather than superseded by a proposed or principal-reported correction.

## Exact identities

| Item | Value |
|---|---|
| Repository / PR | `mastermindx-market-intelligence/macro` / `8711` |
| Candidate head | `9df735bbeaa8d0f4d4967296270bfb2246a5212f` |
| Workflow run / attempt | `37925499382` / `1` |
| Event / role | `pull_request` / `pr_head` |
| Actual tested synthetic commit | `c852221c2bc4d8275c11c686094ccbf472f82ad9` |
| First parent / tested base | `c4cd21d597521603fb75fe7a4602424e088c6bfa` |
| Second parent | Exact candidate head above |
| Tested commit's Git tree | `3e047aedd939f52570d696f3b9ec721e0b5eb903` |
| Composed CI manifest Git blob | `8b685ed536bcf1fb1600639a874b60e50f9cc148` |
| Composed CI manifest bytes / SHA-256 | 1,248,681 / `e4bbeca16e38e8dd73efc2051ef0757b368afe65697f09e77b08a3a2b2746c7c` |
| Logical plan SHA-256 | `5d5cb6561eb52f106148cf78196dce771e344b6a4d967e389ecc2d80917ba539` |
| Changed-path canonical SHA-256 | `b3a170251b002d56f337fe9105eae5726cffa10d76aab882f7e7a01b1c394d3e` |

The synthetic commit and ordered parents were independently GET-read from the immutable GitHub commit endpoint. The owner and contract-delta logs both contain the actual checkout command's adjacent `git log -1 --format=%H` result showing the same synthetic commit. The `tested_tree_sha` semantic field contains this tested **commit** SHA; it should not be confused with the Git tree SHA shown separately above. See `native_snapshot_001.json`, `artifact_read_001.json`, and `source_and_owner_log_read_001.json`.

## What is verified, and what remains missing

| Measurement | Observed / applicable denominator | Meaning |
|---|---:|---|
| Actual API-listed artifact ZIPs retained | 13 / 13 available | Every listed ZIP and its exact JSON member retained and hash checked |
| Artifact set for a complete run | 13 / 15 expected | Pack 0 and final aggregate absent at the bound |
| Semantic pack fragments | 11 / 12 planned | Available fragments are packs 1–11 |
| Logical jobs covered by available fragments | 97 / 98 selected | `ci-control-plane-contracts` is unobserved |
| Actual semantic proof-step outcomes | 300 / 316 planned | All 300 observed steps passed; 16 steps are unobserved |
| Code-job plan partition | 98 selected + 84 excluded = 182 | Exact partition against the actual tested manifest |
| Complete manifest inventory | 254 logical jobs | 182 code-gate jobs plus 72 other-gate jobs |
| Source execution digests recomputed | 98 / 98 selected jobs | Actions, dependencies, timeout and runner contract bound to source |
| Source step-spec digests recomputed | 316 / 316 planned steps | Full execution semantics and normalized proof identity bound to source |
| Owner four-suite pytest result | 275 passed | Actual logged test count for the owner command; not the semantic-step count |
| Introduced / inherited contract findings | 2 / 0 | Actual failure diagnostic against the tested base |
| Changed paths | 110 | Raw changed-file artifact, plan count and observed PR count agree |

`quant-q07-fitted-har-vol` exists in the composed manifest and is explicitly excluded from this scoped plan. Its presence is source-composition evidence, not evidence of execution in this run. The prior independent source-composition review is copied byte-for-byte under `context/` and attributed in `SOURCE_COMPOSITION_CONTEXT.json`; this CI observer does not independently certify that application's code.

The available-artifact verifier completed **2,672 assertions**. These are scratch evidence-validation assertions, not additional application tests. It checks ZIP lengths and SHA-256 against API digests and transferred bytes, ZIP CRC/member identity and safe regular-file layout, strict JSON uniqueness, exact workflow/run/head/base/plan binding, job/step partitions, complete source-semantic digests, actual fragment outcomes, checkout/result excerpts, and PID accounting. The source is parsed as data or AST; no repository source is imported or executed. The complete enumerated manifests, selected/excluded IDs, all 316 planned step semantics, all 300 observed units, and all 16 missing units are in `AVAILABLE_ARTIFACT_VERIFICATION.json`.

## Pack accounting

| Pack | Planned logical jobs | Planned proof steps | Observed disposition |
|---:|---:|---:|---|
| 0 | 1 | 16 | Not observed; hosted job running |
| 1 | 1 | 1 | Actual fragment retained; all steps passed |
| 2 | 5 | 7 | Actual fragment retained; all steps passed |
| 3 | 10 | 44 | Actual fragment retained; all steps passed |
| 4 | 11 | 41 | Actual fragment retained; all steps passed |
| 5 | 10 | 40 | Actual fragment retained; all steps passed |
| 6 | 10 | 27 | Actual fragment retained; all steps passed |
| 7 | 10 | 29 | Actual fragment retained; all steps passed |
| 8 | 10 | 31 | Actual fragment retained; all steps passed |
| 9 | 10 | 17 | Actual fragment retained; all steps passed |
| 10 | 10 | 37 | Actual fragment retained; all steps passed |
| 11 | 10 | 26 | Actual fragment retained; all steps passed |

The unavailable pack is hosted job `113804502733`. Its 16 planned proof identities are explicitly listed below so that “300 passed” cannot silently cover them.

| Unobserved proof identity in `ci-control-plane-contracts` | Planned step-spec SHA-256 |
|---|---|
| `ci-plan/ci-pack/ci-gate workflow structure contract` | `57e5cc036736d6037a86a63c1594f17ef499a7004270af2dc4a6e16e7099fcab` |
| `hosted-runner packing contract` | `43ff60b1039d5b1d668f9c7a9e2f34bcfcab122d52d2bcd5ebedaa0a0ae7421e` |
| `merge-gate reliability report contract` | `59ac9544621bca999e205b5bd692c1dcb5a8f520f637424cfb59155cfab74745` |
| `transitional self-hosted runner policy and canary contracts` | `741b9801ba1c65f945d16bd4811112f9f133e8bb4c6c9a0ff9a730fd3666f2f6` |
| `nightly backstop selftest (scripts/nightly_backstop.py)` | `3ba4beac591884db8169ac0c931a134ff922620c09be1b41e56f42c2f114ddd3` |
| `nightly backstop dispatch rule (must never fire over a live run)` | `eb953de03e2819aac95a3859ea2aa6c03da33dd07d3e9cc087aeb2f2cf02b0e7` |
| `audit_unrun_tests selftest` | `024b9029b284d3135f1f5896de4008f5781f21c7c3ae20195d1ea4d7b9d3d11a` |
| `no suite may be named by zero run: steps (baseline-gated)` | `2eb60823af6d79cb634254809e5f7704855833c5a18a0f8b131242eedeec15f3` |
| `unrun-census discovery unit tests` | `9f02fe3a0412cf3984a092cbb802c6697f753f39051474fd6ae44b272920eb97` |
| `differential contract-delta gate contract` | `85d2f026c0d2e9d39cb55ab936786f29db4b3f4ceba8aeaa50ab784993d74d2a` |
| `check_skip_only_suites selftest` | `664594606e39caf31e0fd3c621cf585acc993d8a28cefedcfd367e2d42cde31a` |
| `no suite may skip in every job that names it` | `b4710756665aa58aa70713bc0e97fa69d066705a8866886d262461351aeda57f` |
| `skip-only detector unit tests` | `af0feb1970d67d1c8740b82270e04d617286ba685f5cbfa061e14e5fbd7d5891` |
| `check_ci_trigger_closure selftest` | `c564111b0ffcee745aa17afa35d5105ed6fa0825e24c3eca411b0d4b27f314ab` |
| `every guarded suite's subjects must reach its own trigger paths` | `d0290a52ad7ad0e2ffd89002c1cd3d2922219ecbaf9318c055d9434c57fa9a14` |
| `trigger-closure guard unit tests` | `241ebaf82a64cf8d1ecf5a682615d7063ac436ddfe1636ff2344d0d537f2ee01` |

The final semantic evidence artifact `ci-semantic-evidence-37925499382` was not listed by the API and is not retained. No final aggregate was reconstructed and presented as producer evidence. At the bound, the workflow was `in_progress` with `conclusion: null`, and no `ci-gate` job had appeared in the attempt's complete 15-job inventory.

## Actual failed gate

Hosted job `113803335510`, `contract-delta`, was completed with **failure**. Its actual command was:

```text
python scripts/check_contract_delta.py --base c4cd21d597521603fb75fe7a4602424e088c6bfa
```

The two exact introduced findings are archived version files named:

- `research/theme_graph/economic_network_execution_20261009/continuation_pro_003/observation_implementation/v1/test_company_relationship_observations.py`
- `research/theme_graph/economic_network_execution_20261009/continuation_pro_003/observation_implementation/v2/test_company_relationship_observations.py`

Log lines 381–383 report both files as new pytest suites named by no run step, followed by `contract-delta: 2 introduced, 0 inherited (base c4cd21d59752)`. The 30,995-byte log SHA-256 is `85fe520d6cb4f29cafe4f990a792bb7c28218742ac72a54e17710f0858666334`. Three actual packing probes remained equal at head/base and below their recorded ceilings; they did not account for these two failures.

The actual workflow's `ci-gate` needs `ci-plan`, `ci-pack`, and `contract-delta`. Its “enforce contract-delta verdict” step fails when the upstream result is `failure`, independently of semantic-fragment reconciliation. This source rule explains why passing owner or fragment evidence cannot waive the observed gate. It is not a claim that this unfinished gate was already observed to conclude. The exact workflow bytes and shared discovery/delta sources are retained under `sources/`.

`ARCHIVE_REPRESENTATION_ASSESSMENT.md` explains the bounded static repair: retain both frozen byte sequences as `.py.txt`, with an explicit historical-commit/path/size/hash map and correction record; keep authored manifests and the canonical runnable test unchanged. The principal's report of applying that relocation is preserved separately and attributed in `PRINCIPAL_REPAIR_CONTEXT.json`. This observer has not reviewed a new repaired commit or its CI.

## Actual owner execution

Logical owner `company-relationship-candidates` ran in **pack 11**, hosted job **113804502836**. The actual tested manifest binds this command:

```text
python -m pytest tests/test_company_relationship_candidates.py tests/test_company_pinned_relationship_candidates.py tests/test_company_relationship_review_set.py tests/test_company_relationship_observations.py -q
```

The semantic proof identity is `File, pinned-source and immutable observation replay contracts`. Its step-spec SHA-256 is `3f346c8660ce1278b5d782982c639324dfa4412faa4856e91d19d822a0481d70`; its job-execution SHA-256 is `5ff9e1dd799a76ff34ad59e95d95cafbc10cea6c6f4cb58da6922bb28801ff6f`. The source action contract contains checkout v4 and setup-python v5 with Python `3.12`, and the dependency command is `pip install pytest pyyaml requests`. All 71 declared owner scope paths are enumerated in the full verification record.

The retained full owner result group spans log lines **1203–1209**, with line **1208** recording `2026-10-09T11:59:15.6736782Z 275 passed in 8.73s`. The full raw log was **116,708 bytes**, SHA-256 `d4743c146660c630e65b810dfb16e7123789d79ea4b0041335b69365affc1102`, read and hashed in memory. Only bounded sanitized excerpts are retained; a reader can recheck the excerpt's exact contents and endpoint/run binding offline, but cannot reconstruct the full raw log's digest from the excerpts alone.

## Exact artifact inventory

Every original ZIP below is retained unchanged in `artifacts/<artifact-id>/original.zip`; its one exact JSON member is alongside it. No duplicate ZIP members, encrypted members, links, traversal paths or extra directory files were accepted. `ARTIFACT_INVENTORY.json` also records every member's size, SHA-256, CRC, compressed size, API metadata and transfer receipt.

| Artifact ID | Exact member | ZIP bytes | ZIP SHA-256 |
|---:|---|---:|---|
| 11613619492 | `pack-4.json` | 4,356 | `f355bcd4752e882c88926229ebb4995d3849a2b66e160001bdb38908c1cf3d36` |
| 11613647919 | `ci-plan.json` | 30,406 | `8e154d8852da6ca7cb47f26086edd08abc78412fc8a1b3cbbeb9e09f0af97f35` |
| 11613677872 | `changed-files.json` | 1,731 | `a38c0f83e8b614407ca40f0fd171f312f8f3d808578e0aeff29fc987bc85c8df` |
| 11613699150 | `pack-1.json` | 645 | `f2588e056896bc6b97b15f715fc064dfe6d12d6225804ae2bbadf85819128f3d` |
| 11613784491 | `pack-11.json` | 3,047 | `b47697a6f0f1a5f76bdca80ae31335aa5b7da848a9bd127ea19e43280d4f87a8` |
| 11614204568 | `pack-10.json` | 3,872 | `ba809c75ad6bc57f6f15d9284e276785a30cda0b612ada0fd4746fe6e6e9171e` |
| 11614227879 | `pack-2.json` | 1,375 | `e82f8d07f5e502d17c184882cf4d5c089638f3eb52f250199197e3a6939d217b` |
| 11614282712 | `pack-8.json` | 3,338 | `48249cdff4a688c4815593dbb1ee59b1fc0cad48c63413b23bc3ef7ad0c8c739` |
| 11614372974 | `pack-9.json` | 2,382 | `4b40e8bb453d9d0ad5380a1289a76bbe65aaab3fc982adb14251a977edc2b0d5` |
| 11614431790 | `pack-7.json` | 3,182 | `6970c49b9185444a7feebb0f3915171d86fe34c7395132a6d0ccbf52dfde6f7b` |
| 11614613432 | `pack-6.json` | 3,175 | `b05315e4df00c8eb31e9fcb7f3b610f767393c5d21333e8ba0bd39b8f6181e03` |
| 11614668406 | `pack-5.json` | 4,224 | `a88fd92c69c5082deebc853d9b76574e758efc780d386de75f4f4cca8e635bdf` |
| 11614730096 | `pack-3.json` | 4,362 | `7a33f3114400826c00b3ea3e6fa0594ca39bd4a41508b37a4e5cfe01002ef75a` |

Total retained original ZIP bytes: **66,095**. Total exact JSON member bytes: **193,913**. These totals cover only the 13 available artifacts, not the two unavailable artifacts.

## Other check observations and authority boundaries

All exact-head check records are enumerated in the focused and full JSON files. The observed `ci-authority/main` check was successful, while `ci-authority/codex/merge-queue-pilot` was failed. Those statuses are retained without this lane deciding their release-policy authority. `trusted-ci` was skipped; it is not treated as an affirmative pass. No complete-run conclusion, live main freshness, hold clearance, merge eligibility, accepted-source comparison, or postmerge/native proof is certified by this packet.

The principal owns canonical release-helper adjudication, source repair, commit/push, new exact-head CI, merge and postmerge proof. This lane made no native file/source/store writes, Git mutation, workflow dispatch/rerun/cancellation, comment, label, policy waiver or merge. No rights, history, fact, Graph1, production or prediction promotion is asserted.

## Native read process accounting

All six native processes started by this observation lane completed with exit code 0 and were reconciled: **85752, 90893, 98043, 2744, 9986, 20474**. There are no unresolved native PIDs. The exact read-only scripts, purposes, source-receipt mapping and terminal completion evidence are in `native_read_scripts.json`. The principal-reported repair PID is separately attributed and is not one of these six observer processes.

## Reproduction and evidence limits

From the preserved evidence root, with Python 3 and PyYAML available, run:

```sh
PYTHONDONTWRITEBYTECODE=1 python -B verify_available_artifacts.py --snapshot native_snapshot_003.json --output REPRODUCED_AVAILABLE_ARTIFACT_VERIFICATION.json
```

Use a fresh output name; the verifier refuses overwriting. It verifies preserved observations, not current GitHub state. It does not import or execute the CI producer, planner, application, test modules, or source-acquisition code. Full run completeness remains false by design. The deterministic archive's external manifest records every regular file, length and SHA-256; extraction and unchanged-verifier replay are checked before handoff.

The verifier's source-binding recomputation is independent data processing from the exact observed manifest. It does not rerun the full path-scoping decision or establish missing results. The two whole-log digests are actual in-memory read receipts, with the explicit offline limitation described above. Package preparation notes distinguish local helper adjustments from actual CI findings.

## Primary references

- [PR #8711](https://github.com/mastermindx-market-intelligence/macro/pull/8711)
- [Frozen original run](https://github.com/mastermindx-market-intelligence/macro/actions/runs/37925499382)
- [Owner pack job](https://github.com/mastermindx-market-intelligence/macro/actions/runs/37925499382/job/113804502836)
- [Actual failed contract-delta job](https://github.com/mastermindx-market-intelligence/macro/actions/runs/37925499382/job/113803335510)
- [Actual composed manifest at tested commit](https://github.com/mastermindx-market-intelligence/macro/blob/c852221c2bc4d8275c11c686094ccbf472f82ad9/.github/ci/legacy-jobs.yml)
- [Actual shared semantic proof source](https://github.com/mastermindx-market-intelligence/macro/blob/c852221c2bc4d8275c11c686094ccbf472f82ad9/scripts/ci_semantic_proof.py)

The durable packet's canonical local entrypoints are this report, `FOCUSED_OBSERVATION.json`, `AVAILABLE_ARTIFACT_VERIFICATION.json`, `ARTIFACT_INVENTORY.json`, and `ARCHIVE_REPRESENTATION_ASSESSMENT.md`.
