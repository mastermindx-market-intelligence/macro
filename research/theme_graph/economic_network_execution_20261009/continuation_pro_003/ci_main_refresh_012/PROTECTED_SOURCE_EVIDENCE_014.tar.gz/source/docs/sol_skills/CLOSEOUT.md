---
schema: mastermind.sol_skillpack.v1
skillpack_version: 1.0.1
minimum_bootstrap_major: 1
skill: closeout
---

# CLOSEOUT — Make the Result Durable and Recoverable

Use after a substantive architecture ruling, accepted implementation, production proof, major
reconciliation or operator handoff.

## Mission

Leave the company in a state where a **brand-new Sol session can recover what became true,
what remains false, and the exact next action without this chat**, while leaving no watcher-enabled
counterpart indefinitely waiting for an inferred terminal state.

Closeout is not paperwork after the real work. Cross-session recoverability and clean dialogue
termination are part of the product.

Apply `docs/AGENT_DIALOGUE_SESSION_CLOSE_LAW.md` whenever a worker/COO/session counterpart is or
may still be on a reciprocal watch/wait path.

## Step 1 — State the capability delta

Write one precise before/after statement:

```text
Before: <what user/machine could not reliably do>
After:  <what can now be done and through what canonical path>
```

If the wave was records-only, say so. If implementation is built but not production-proven, say
`BUILT_NOT_PROVEN`. Do not inflate the capability because the team invested heavily in it.

## Step 2 — Re-run the completion law

Before marking anything done, answer:

* What did the commission say completion means?
* Was production/browser/machine-consumer proof required?
* Is the proof from the real path and exact accepted head/release?
* Did any degraded/negative state remain untested?
* Did a merge/Slack message/Linear automation accidentally advance projection farther than truth?

If proof is missing, keep the correct nonterminal capability state and name the proof owner/gate.

## Step 3 — Record immutable implementation evidence

For code/research work, preserve:

* repository;
* PR number;
* accepted/merge SHA;
* changed capability, not just changed files;
* CI/security/adversarial review receipt;
* production/release identity when owed;
* important negative proof (e.g. zero Attempts, no Wake, no second store).

Mutable branch heads are not closeout receipts.

## Step 4 — Update the correct durable homes

### Mastermind / owning repository research/docs
Update when architecture, source law, product contract or evaluation law changed.

### Agent OS
Update when cross-session organizational truth changed:

* workstream status/wave state;
* a decision/ruling;
* a discovery that future sessions must know;
* a continuation handoff.

Do not create an Agent OS workstream/program parent that the semantic registry does not support.

### Linear
Repair/selectively project the current portfolio state **after** canonical evidence is known.

Linear should expose action/gate/progress usefully; it need not duplicate the entire Agent OS or PR.

### Slack
Post bounded human/machine visibility/receipt where useful. Slack remains transport, not the durable
owner of the ruling.

### Shared Project
Do not rely on Project chat history as the durable closeout. It may remember the conversation, but
future correctness must not depend on it.

## Step 5 — Preserve supersession explicitly

When a new ruling replaces part of an older one, record:

* exact old source;
* exact new source;
* what clauses/assumptions are superseded;
* what old laws remain controlling.

Avoid “new doc replaces old doc” when only one narrow carrier/sequence assumption changed.

## Step 6 — Leave unresolveds visible

Record unresolved items with:

* concrete claim/gap;
* why it matters;
* current capability state;
* falsifier or evidence that would resolve it;
* named next owner/action.

Do not hide unresolveds inside “future work.”

Common Mastermind examples:

* production principal/credential not provisioned;
* natural-time proof still accruing;
* external entitlement unavailable;
* semantic registry gap prevents a lawful workstream;
* one platform capability unproven across all three Pro seats;
* user-facing producer exists but real consumer is not wired.

## Step 7 — Create the continuation handoff

A substantive handoff must declare whether the parent mission is complete rather than assuming it.
Use the current ACTIVE_EXECUTION finalization classification when that procedure applies.

```text
FINALIZATION_CLASSIFICATION: <current permitted class>
MISSION_COMPLETE: true | false
mission / bounded outcome at this boundary
state before
what changed
what was verified
what remains unverified
unresolved / danger areas
exact next actions in order
do-not-redo laws
return point / highest-authority sources
```

For `CHECKPOINTED_CONTINUATION`, `MISSION_COMPLETE` must be `false`; the handoff describes the
verified incomplete boundary and continuation, never "mission just completed". For a truly completed
parent mission, `MISSION_COMPLETE: true` is allowed only when the declared completion/proof law is
actually satisfied. A bounded child or research assignment may be complete while its parent mission
remains false; state both scopes explicitly when material.

Use exact PR/SHA/MAS/WS identities. Do not paste private reasoning or secrets.

## Step 7A — Verify the cumulative continuation boundary

For CHECKPOINTED_CONTINUATION, consume ACTIVE_EXECUTION as the sole finalization owner. Leave one
current cumulative checkpoint under the existing Agent OS/Runtime/artifact owners with a verified persistence receipt/readback,
exact committed revision/digest, mission explicitly incomplete, justified boundary, next action and
intended resume surface. A chat-only or local scratch note is not a durable checkpoint. Preserve
accepted work, rejected approaches, material hypotheses/falsifiers and all effects through this boundary.

A working snapshot is not an immutable transfer capsule. Existing owner versioning/fencing governs
updates; a prepared capsule for a target Attempt is not repeatedly overwritten. Do not create a second
latest-state directory, checkpoint table, lifecycle or authoritative Google Drive mirror.

If persistence is ambiguous, preserve EFFECT_UNKNOWN on the same write carrier and reconcile that
object/revision before any retry. A surviving older checkpoint does not prove a newer write failed.
No fresh chat inherits execution custody, and no resume pointer proves an automatic wake. Missing
persistent access requires an honest emergency note and actual platform/gate classification, not a
false verified checkpoint or parent completion. Project rollout follows protected source acceptance.

## Step 8 — Reconcile projections and transport

Before declaring closeout complete:

* compare Linear to canonical state;
* ensure architecture/docs merge did not auto-complete runtime/product issues;
* ensure Slack visibility does not imply execution/production acceptance;
* ensure no stale issue title still instructs a superseded sequence;
* ensure held downstream waves still list the correct predecessors.

Fix the projection, not the underlying truth, when the projection is wrong.

## Step 9 — Close every reciprocal watcher cycle explicitly

Before Sol or a worker session considers the current dialogue/child wave finished, answer:

* Is the latest dialogue state explicitly terminal or nonterminal?
* If nonterminal, did the counterpart receive the exact next action and continuation instruction?
* If terminal, did the counterpart receive explicit `STOP`, `ACCEPTED / STOP`, or `CLOSED / STOP`?
* Did the terminal message tell the counterpart to stop work and disarm its temporary watcher?
* Did this side disarm its own temporary watcher, or explicitly report `WATCH_STOP_FAILED` / the
  current accepted equivalent?
* Is any operator still saying or semantically indicating “awaiting your ruling/return”?
* Is an old watcher/thread/session accidentally being used to bridge into a new independent wave?

If any answer is unresolved, the watcher-enabled dialogue is **not cleanly closed** even if the
worker's implementation portion is complete.

If worker work is terminal but Sol still owes final CEO adjudication, send terminal STOP to the
worker first, then continue CEO-only work outside that child operation.

A parent program may remain active while a child operation is terminal. Any independent next child
operation requires fresh lawful operation identity, carrier reconciliation, commission/pickup and
reciprocal continuation setup; old watcher state grants no authority.

## Step 10 — Protect future cold starts

Ask:

> If a new Sol conversation starts tomorrow with only the Bootstrap Kernel and current repos/apps,
> what material thing from this session would it fail to know?

If the answer is a ruling, discovery, implementation status, proof requirement or exact next action,
put it in the appropriate durable source before closing.

Do not solve the question by expanding the Skillpack with live company state.

## Step 11 — State the next action precisely

End with exactly one primary continuation action and its gate, plus any independent parallel work.

Bad:

> Continue the integration.

Good:

> After implementation head `<sha>` closes the named release blocker and exact-head CI is green,
> Sol completes the required adversarial review; only on PASS may `<next gated wave>` start.
> `<independent wave>` may continue in parallel because its authority and changed paths are disjoint.

The example uses placeholders deliberately. Never teach live program state by embedding it in the
Skillpack.

## Closeout output

```text
FINALIZATION_CLASSIFICATION
MISSION_COMPLETE: true | false
Capability delta
Final capability state
Canonical receipts
Production proof status
Durable records updated
Projection/transport repairs
Dialogue edge / watcher shutdown state
Unresolveds / falsifiers
Exact next action
Independent parallel actions
```

## K4 pass criteria

A fresh session can recover the accepted result, its evidence, its limits and the exact continuation
without chat archaeology, no canonical/projection layer was advanced beyond what the evidence
supports, and no watcher-enabled counterpart was left waiting on silence after a terminal or
nonterminal return.
