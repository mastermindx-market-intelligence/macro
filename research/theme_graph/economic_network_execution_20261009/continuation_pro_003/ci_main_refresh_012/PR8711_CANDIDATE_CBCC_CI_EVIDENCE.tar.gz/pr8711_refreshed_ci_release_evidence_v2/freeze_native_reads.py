#!/usr/bin/env python3
"""Freeze existing bounded native read receipts; no native execution."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    data = json.loads((ROOT / 'native_read_record_inputs.json').read_text())
    assert data['schema'] == 'gmi.pr8711.refresh2_native_read_record_inputs/v1'
    processes = data['processes']
    count = len(processes)
    assert 7 <= count <= 16
    assert [row['sequence'] for row in processes] == list(range(1, count + 1))
    assert len({row['pid'] for row in processes}) == count
    for row in processes:
        assert row['exit_code'] == 0 and row['reconciled'] is True
        assert row['start_footer'].startswith(f"Process started with PID {row['pid']} ")
        assert row['completion_footer'].startswith('✅ Process completed with exit code 0 ')
        assert row['device_footer'] == '[executed on device: m2studio (3f5ce987-e3eb-40a3-af9f-4b0ae54919cc)]'
        receipt = ROOT / row['receipt']
        assert receipt.parent == ROOT and receipt.is_file() and not receipt.is_symlink()
        raw = receipt.read_bytes()
        row.update(receipt_bytes=len(raw), receipt_sha256=sha(raw))
        script = row['exact_python_script'].encode()
        compile(script, f"native_read_{row['sequence']:03d}", 'exec')
        row.update(script_bytes=len(script), script_sha256=sha(script))
    result = {
        **data,
        'schema': 'gmi.pr8711.refresh2_native_read_processes/v1',
        'managed_process_count': count, 'all_managed_processes_reconciled': True,
        'pending_processes': [],
        'authority': {
            'initial_read': 'Immutable native Git objects with lazy fetching and optional locks disabled',
            'subsequent_requests': 'GitHub GET only', 'native_file_writes': False,
            'git_mutations': False, 'application_imports_or_tests': False,
            'workflow_dispatch_rerun_or_cancellation': False,
        },
        'retention': 'Exact executed scripts and completion metadata. Captures preserve actual evidence. Raw tool wrappers are not duplicated.',
    }
    raw = (json.dumps(result, indent=2, sort_keys=True) + '\n').encode()
    destination = ROOT / 'native_read_scripts.json'
    with destination.open('xb') as handle:
        handle.write(raw)
    print(json.dumps({'path': str(destination), 'bytes': len(raw), 'sha256': sha(raw),
                      'managed_process_count': count, 'all_reconciled': True}))


if __name__ == '__main__':
    main()
