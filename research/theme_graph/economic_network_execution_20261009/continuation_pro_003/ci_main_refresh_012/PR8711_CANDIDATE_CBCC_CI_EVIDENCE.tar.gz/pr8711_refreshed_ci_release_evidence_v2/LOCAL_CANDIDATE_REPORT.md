# PR8711 second refresh: local committed-source observation

**Local committed-source reconciliation passed for `cbcc5ee143400af162a252e4faac0f06c7157e37`.** This observation was completed at **2026-10-09T15:00:25.357200+00:00**, before the principal confirmed publication. Its frozen disposition is `LOCAL_COMMITTED_SOURCE_RECONCILIATION_PASS__REMOTE_AND_CI_NOT_OBSERVED`. Subsequent remote and CI observations must be recorded separately.

The independent preserved-object verifier passed **970 assertions**. Full record: `LOCAL_CANDIDATE_VERIFICATION.json`, **959882 bytes**, SHA-256 `33b42ab2cbba3d3600455a85b5cacf4a09623b0fb832eb745d73983bbd744ad5`. Source bodies remain exact raw Git objects, losslessly retained with SHA-256 and Git object hashes in `local_git_objects_001.json`.

## Actual immutable identities

| Binding | Independently observed value |
|---|---|
| Local candidate | `cbcc5ee143400af162a252e4faac0f06c7157e37` |
| Candidate Git tree | `bd6fc812085ae66966529c39668de1f873471b76` |
| Candidate sole parent / integration | `3521765204903320db76ddd84d6a43539ded8e62` |
| Integration Git tree | `d4244da490987272940820ff14da515733e151cd` |
| Integration ordered parents | `693ee939c8a28920ef9de7bc32a9f47a7ba76b82` then `87b01101ef13aa20ded205f3a2b267b68d094def` |
| Supplied accepted upstream | `87b01101ef13aa20ded205f3a2b267b68d094def` |
| Prior accepted-main reference | `3bb1ee47939d9caa1db10a4e764365d3a2ee5b77` |
| CI-definition commit | `ff652de571523466dea4d4d7f9644022198c3465` |
| CI-definition commit's sole parent | `aee2725637d9fa66dd75ea24c4b2693b8bcf3a85` |

The verifier reconstructs the complete **13-commit** upstream ancestry from actual raw commit objects. The candidate changes exactly **22 paths** relative to its sole integration parent, all within the existing `continuation_pro_003` evidence directory. Complete paths and before/after tree entries are enumerated in the full verification record.

## Source preservation and owner enrollment

All **53/53 accepted engine/lib byte pins**, totaling **1,483,905 bytes**, match the original accepted reference at checkpoint `6b58f15adae3b1d402d9993c52609d00083f1453`. The whole owner definition and all **71 enrolled owner paths** are byte-identical across the prior candidate, integration and new local candidate. The canonical observation suite remains SHA-256 `a73700e639c8e97a4ff84951b48358abe63b1f5048560d03b0e40f2310ac44da`.

The exact enrolled four-suite command remains:

```sh
python -m pytest tests/test_company_relationship_candidates.py tests/test_company_pinned_relationship_candidates.py tests/test_company_relationship_review_set.py tests/test_company_relationship_observations.py -q
```

This is actual source enrollment. No new hosted execution result, test count or pack assignment is supplied by this local observation.

The current candidate manifest is **1249336 bytes**, Git blob `2265e5ccc3d408d6679bdfba5ac22ab959aaaccf`, SHA-256 `5cc24c46e7c4ed8b0b9525366a7069e86f546b32849c72cb8518320842d860cd`. Its bytes exactly match the integration's manifest. The candidate preserves all **253 other accepted job definitions** and all top-level manifest fields from the supplied accepted upstream. The remaining owner definition exactly matches the previously accepted candidate.

## Exact CI-definition change

Full manifest comparisons independently establish the same six changes in three places: the definition commit, the accepted-main range, and the candidate's normal source refresh. No job identifier, command, runner, conditional or other non-path job field changes. Each listed job receives exactly one additional scope path, preserving the previous path order.

| Existing job | Added scope path | All non-path fields |
|---|---|---|
| `biocatalyst-history` | `engine/risk_envelope.py` | unchanged |
| `conviction-profile` | `engine/risk_envelope.py` | unchanged |
| `flow-surface` | `engine/risk_envelope.py` | unchanged |
| `ticker-news-qbus` | `engine/risk_envelope.py` | unchanged |
| `unrun-government-revenue-candidate-projection` | `engine/risk_envelope.py` | unchanged |
| `unrun-government-revenue-grader` | `engine/risk_envelope.py` | unchanged |

All manifests contain **254 job definitions**. Full old/new path inventories and raw manifest diffs are preserved in the JSON. The semantic reconciler, pack runner, differential contract checker, workflow and discovery source files are all exact against the previously observed pins and the supplied upstream.

## Raw evidence and process accounting

The capture retains **137 raw Git objects**, totaling **8,685,410 bytes**, and **230 reconstructed source bindings**. Every object is checked against its native Git object ID and SHA-256; every file binding is independently traversed through raw tree entries. Files must have regular Git modes. All read operations are reconciled with their exact output lengths and hashes.

The sole local source-read process was **PID 21862**, completed **exit 0** in **6.46 seconds** on the authorized m2studio workspace. Its exact script and completion metadata are retained. Git was invoked with `--no-lazy-fetch`, `--no-optional-locks` and `--no-replace-objects`. No checkout, fetch, working-tree read, application import/test, configuration change or native/Git write was performed.

RDC inserted three framing line breaks in the single compact JSON stdout body. Joining that transport framing recovered the full capture; the independent verifier then checked every embedded raw object. No missing source body was inferred.

The five previous packet transfer objects—the frozen archive, external manifest, archive verification, README and readable report—remain exact and match their actual Git blob identities in this candidate. `PRIOR_V1_PACKET_PRESERVATION.json` records the bindings. The earlier 98-member archive and its verifiers were not rerun or modified.

## Publication and proof limits

`PUBLICATION_STATUS_PRINCIPAL_001.json` preserves the principal's failed-push account as attributed provenance: exit 1, remote still at the prior candidate, and a missing promisor object with lazy fetching disabled. This lane neither executed nor independently certified that push. The local source observation remains valid independently of that publication event.

Later publication and hosted-CI evidence belong to their actual observation times and must use the actual tested merge, base, plan, fragments and logs. They cannot reuse a historical pack assignment or pass result. The principal retains release freshness, protected-source reconciliation, holds, functional acceptance and the native C01 witness.

No rights, historical availability, factual admission, Graph1, production or predictive promotion is made. The 13-commit ancestry and CI/source preservation review do not certify the broader generated-data/site changes.

## Complete owner path inventory

Every row below matches both the integration and prior candidate, including its Git mode, blob identity, length and SHA-256.

| Owner-enrolled path | Bytes | SHA-256 |
|---|---:|---|
| `collectors/__init__.py` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `collectors/edgar_forensics.py` | 27625 | `8e153f35b1d9f243790c2df16749207243168c42676802f1f0e5a886537a9a29` |
| `collectors/fundamental_forensics_acquisition.py` | 44318 | `fba28cca50d8f8fe249c12bb8f6b9d29dd7e41dd439f32210908fb7869d97216` |
| `collectors/fundamental_forensics_companyfacts.py` | 99526 | `024fcace6c21ca84e6a262aa8ecd434955877ec2db19ce47ee190bbc9a4e989a` |
| `collectors/sec_document_spine.py` | 42289 | `1c6fec647373372858f4ad5fc0b6a88d9da84d605f5d14e8e148ac2ee7e8a3e5` |
| `collectors/sec_filing_parser.py` | 123233 | `37622fc108944e65fa1ca4cb80497633e6b1157348b9aa029afd990d28225090` |
| `config/dataset_registry.yml` | 50632 | `bb9b6975eeabebf630f73e632d307d280ea1d9e34f30953ac3989c65fc90f0a7` |
| `config/fundamental_forensics_disclosure_diff.v1.json` | 7364 | `e530774b66de375f88f7ae64aace5127c8c15ba5e131b43cf9bc443de677f8e6` |
| `engine/__init__.py` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `engine/basket_breadth_divergence.py` | 16985 | `f073f778f43f9e040b5b3b76cfb66fe5085940ca00b92e7ae2fac359d1d68be6` |
| `engine/catalyst_tone.py` | 31503 | `1856dc10ea0c9fc480517d50b1b8488303ea29dbc18c7b86cd11d29ea0e7dbb0` |
| `engine/company_intelligence/__init__.py` | 832 | `09e8425cdca490d03bece9462af575fddd25802e0ca2aa12be7d24f6ded8b347` |
| `engine/company_intelligence/contracts.py` | 34222 | `a9ab0b648e72b7537fc812618adab8325bd9f88410ba1169103929ddccc276ad` |
| `engine/company_intelligence/health.py` | 7219 | `db924871e9a49446ebbe6e84c2c9c57a361b903fb8764a5a891a531cdb449210` |
| `engine/company_intelligence/pinned_relationship_candidates.py` | 11962 | `afafacb978face2775c769844a2773e04a5cb5b755aacd6c9724d7e51eb07cb7` |
| `engine/company_intelligence/relationship_candidates.py` | 45473 | `a558922c0586a5532f3912524b48f3cf592c3c6c9c21f689e3d416976e9cae55` |
| `engine/company_intelligence/relationship_observations.py` | 42756 | `85c07b309ff7b7220ec12f2b3f25c924a2ef4c9ab495ce9030f61038cbb9e8c7` |
| `engine/company_intelligence/views.py` | 36392 | `b5cc18f5722305f841a18b94867edcdd36e6797889136bd807e6a5161cef70f4` |
| `engine/desk_ledger.py` | 6683 | `9e079f7d26e3a60e75ee651140612c2efd6a9d00a9405ac5c424fe219600dbc2` |
| `engine/earnings_release/__init__.py` | 1009 | `efb8ea9960f8fe2e5e6ab79eff5bef7abde6b7d7fa63f7b5faca17081a9bbe85` |
| `engine/earnings_release/receipts.py` | 12010 | `463c97d12c74baaf76fe1abab359b38d2b89a2958f455e5d541caa8fa580fb84` |
| `engine/fundamental_forensics/__init__.py` | 1854 | `c4c6084411d11e5b07bfd0e4600880ccbbc60309712262bdd266657c120ad5fb` |
| `engine/fundamental_forensics/detectors.py` | 17295 | `3a5b3ceb58cbfd21253052676c4ef38b3125b45799f44c799a8977c3685f522a` |
| `engine/fundamental_forensics/disclosure_diff.py` | 118522 | `a266960ac1c3d48b7ebedbe1141d50e1ed3cbfd617d27d01aa6e1554fce389ba` |
| `engine/fundamental_forensics/filing_attestation.py` | 76795 | `1b2693a9bbff66761a573a8c1bd5d32b352a2d43719407e2864fda6e725d0a47` |
| `engine/fundamental_forensics/filing_package.py` | 57231 | `929de48d3391844f71dc0875d97eddd4372524133de41de90953819a7d5da4d9` |
| `engine/fundamental_forensics/ixbrl_extraction.py` | 77632 | `e9a3ad540b154d37f2a8724ac4bd523d6aa951c70d500f9fed80295fc60b6e58` |
| `engine/fundamental_forensics/models.py` | 14519 | `cd8e5e62d4e29378453b89ea6b2f5cfd4028ed5ea4502a9d43f98f0819c3aa97` |
| `engine/fundamental_forensics/normalize.py` | 12032 | `b23163c565ad0bd5bc079542538725c56d747a1212346ba74f8f6f9f3ea80487` |
| `engine/fundamental_forensics/pipeline.py` | 5086 | `ecb8d2ebe9da231a70b9edcfea654f0bfee00e01570fbfd596106e5fe528817b` |
| `engine/fundamental_forensics/sec_companyfacts.py` | 7430 | `bf575fdcb307e12efdf9e281697e0fe143e7a373282efde6f1799e2582c89170` |
| `engine/fundamental_forensics/sec_document_spine.py` | 48206 | `ee240863943823e598083f45164c6a288e9098292a47a454cc70898c2bdf8366` |
| `engine/fundamental_forensics/source_sync.py` | 54924 | `73ddb5ac6ed910b1f4d9a7d76a944063f3251011e7b2af96d7fbb8306f46776a` |
| `engine/gdelt_client.py` | 17148 | `9282e05655b3de93da3046c0fe36d17e6b682d5825237fd68a16017ae788ab6a` |
| `engine/marketing/__init__.py` | 660 | `6c9056208c0a9c0115eb54b9f8abfd01b36fd168e843b0d5235c9291240bfa5c` |
| `engine/marketing/accounts.py` | 5038 | `868a6f728f177009808c9321416d08a9a8e610ff2c6aa3733bf3cb1c0adcc40f` |
| `engine/marketing/authority.py` | 5355 | `0d73e0cdd1bc36b24a6ea45658e63c254094bd3b8ef8878b092020afd1a27368` |
| `engine/marketing/chart_render.py` | 287289 | `2d8d596c39545c9c0b064a56ec8508b41fb7845ff8fb124902a956896668fbcd` |
| `engine/marketing/charter.py` | 3628 | `af4bef84e91e4631534e7da7508c4c6eae9b0529272365228339fe7b48ec4f1f` |
| `engine/marketing/claims.py` | 4436 | `ad6667e71d23ddb4cda28cf5b8d79fc7328a80f94f415540063822c6dd0d9d0b` |
| `engine/marketing/cmo.py` | 10714 | `f2b124754fb808d1935fcde19bdad3d66f334ada97b1f292fbfc9af0686974f9` |
| `engine/marketing/departments.py` | 45779 | `f42be96b317a040bf28c6dcdb4343aa9d8b83fce0133ef77121448f2015f889f` |
| `engine/marketing/economics.py` | 4797 | `bb4e78bb1251366d536a79aa789a357ce6ece47c32ca4534e920e8ee4d24b3d9` |
| `engine/marketing/events.py` | 2136 | `f940ba236256f56841cc944fdab5914ee4c5a85a5b9ce774137bcede7c5caace` |
| `engine/marketing/ledgers.py` | 1686 | `a94a60f25914ff67328c3b54eb46befa81c1b3910a9a0f72c260fb0609c7a3e8` |
| `engine/marketing/logo_cache.py` | 14389 | `afc70743c63ba6c7ddc732914876baa38ef0eff384b296b42f249fe09510d0c6` |
| `engine/marketing/opportunity_bus.py` | 5350 | `09f0ce3e55bcbda2e83051c396ba78bdc68d9e7d0fdfb093fdb4b09197f94df2` |
| `engine/marketing/publication.py` | 7182 | `9904f90241f1b236dd88094aa6b388fdf43d627c6117900a3b36ededb6f4beb2` |
| `engine/marketing/state.py` | 18901 | `1b933891c7c3c1d22018ea6b49fbb370a7f6cd5f9e5e9123912405081b81c15b` |
| `engine/master_brain.py` | 142755 | `9d58cfe754f365206be998d95b29a60cf2a54df46a1cad8ac7788fae66a16b70` |
| `engine/research_vault/__init__.py` | 1175 | `5b35706ac8760796f9ac445b8c1fceda53a058aa64ea46cf6c79d19e420a97f8` |
| `engine/research_vault/r2_store.py` | 47498 | `7ba42eb8f74c034413997707a35156e67342fb9a30ca2b80dde0f11d1dc7e2bd` |
| `lib/__init__.py` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `lib/config.py` | 1131 | `fa22ec934ec5294072b6bb4bf081d787f3f8ad5da4702ce3f4818b1674dbd53f` |
| `lib/dataos/__init__.py` | 5496 | `0d8df3c0c127df3ec7a5b7148dd32dfed66dbd4c22e5fa496b77ec15377213a7` |
| `lib/dataos/identity.py` | 49306 | `8baefdf03e29afb59b4bc70805327e88e0e4e96e0a720727ffa695ba1775ad6f` |
| `lib/dataos/nulls.py` | 7737 | `2556e7d0b2ac609306e512a61071a024b7b0b7eb0ec4ef3efaf22ce9f4387d49` |
| `lib/dataos/price.py` | 10509 | `40aad993988e03f3c9ff4c2a221cdaeecc3569054d4a93fc0565657fce109e15` |
| `lib/dataos/quality.py` | 15792 | `e56dfb5baa8f53ccf8141dbfa357d266faed519043e258a56d657abe264f9706` |
| `lib/dataos/registry.py` | 16599 | `b57ec16a61086b8d35beb2f81af30efc4af55f1ac07ec95cfcfd87beefeef0a5` |
| `lib/dataos/temporal.py` | 12847 | `4415404186f0b0d2870f42d9e4a0b95be87937863adf30cf015ed34e8bf92b67` |
| `research/theme_graph/economic_network_execution_20261009/MICRON_SOURCE_CASE.json` | 1588 | `dd72d31afce12ca727a171e6f635d7085c8c2d6bff6bea2750f9c29a04fe101b` |
| `research/theme_graph/economic_network_execution_20261009/replay_micron_witness.py` | 5231 | `69da2f393711923be68f05b1da563dbbcb736761fa60a8bf5ea4aa6cbf9f1830` |
| `scripts/__init__.py` | 2217 | `099b906ef95aec83bbfc4d84b5ceb4f050e57a5fd2840e99faa9dc202e90c378` |
| `scripts/worktree_sparse.py` | 88324 | `08a6c23c75569c7acb6c8e1ef028bd7d752d283bbb37d540d666c25ab117657f` |
| `tests/__init__.py` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `tests/conftest.py` | 34456 | `ad0b342a4303b5dc098d203530e8e8a83d4b5c3cbc38730309448cac14570425` |
| `tests/test_company_pinned_relationship_candidates.py` | 27799 | `08fa9e22f7c35681b2fd97ccd97796a01a98988b05b8d047c8368ff24f6eb669` |
| `tests/test_company_relationship_candidates.py` | 29602 | `0a8c73d5e5b968fd3795fed1e08305597f9c254cc5702b9946b702b8f31bdbd4` |
| `tests/test_company_relationship_observations.py` | 49406 | `a73700e639c8e97a4ff84951b48358abe63b1f5048560d03b0e40f2310ac44da` |
| `tests/test_company_relationship_review_set.py` | 35165 | `67636cc6eca4f9be84b383bb44b4835a3dc8447f6b288e2e99073f61182ce212` |

## Offline verification

With Python 3 and PyYAML, from this evidence directory, use a fresh output filename:

```sh
PYTHONDONTWRITEBYTECODE=1 python -B verify_local_candidate_objects.py --output FRESH_LOCAL_CANDIDATE_VERIFICATION.json
```

This verifier reads preserved evidence without Git, network, native operations or repository application execution.
