import base64,datetime,gzip,hashlib,io,json,re,shutil,stat,subprocess,zipfile
REPO="mastermindx-market-intelligence/macro";HEAD="cbcc5ee143400af162a252e4faac0f06c7157e37";RUN=37949036732
known_artifact_ids={11625610959,11625495919};known_log_ids=set()
gh=shutil.which("gh") or "/opt/homebrew/bin/gh"
out={"schema":"gmi.pr8711.refresh2_snapshot_artifact_log_get/v1","observed_at_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"operations":[],"artifacts":[],"logs":[],"diagnostics":[]}
def rawget(ep,log=False):
 args=[gh,"api"]
 if log:args+=["--allow-escape-sequences"]
 args+=["--method","GET",ep]
 p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45)
 row={"endpoint":ep,"returncode":p.returncode,"bytes":len(p.stdout),"sha256":hashlib.sha256(p.stdout).hexdigest()}
 if p.returncode:row["stderr"]=re.sub(r"https?://[^ ]+","[URL omitted]",p.stderr.decode("utf8",errors="replace")[:1000]);out["diagnostics"].append(row);return None,row
 return p.stdout,row
for label,ep in [
("run",f"repos/{REPO}/actions/runs/{RUN}"),
("jobs",f"repos/{REPO}/actions/runs/{RUN}/attempts/1/jobs?per_page=100"),
("checks",f"repos/{REPO}/commits/{HEAD}/check-runs?per_page=100"),
("artifact_inventory",f"repos/{REPO}/actions/runs/{RUN}/artifacts?per_page=100"),
("pr",f"repos/{REPO}/pulls/8711")]:
 raw,row=rawget(ep);out["operations"].append(row)
 if raw is not None:out[label]=json.loads(raw)
for item in out.get("artifact_inventory",{}).get("artifacts",[]):
 if item["id"] in known_artifact_ids:continue
 ep=f"repos/{REPO}/actions/artifacts/{item['id']}/zip";raw,apirow=rawget(ep)
 if raw is None:continue
 dig=hashlib.sha256(raw).hexdigest();assert len(raw)==item["size_in_bytes"] and "sha256:"+dig==item["digest"]
 z=zipfile.ZipFile(io.BytesIO(raw));info=z.infolist();assert len(info)==len({i.filename for i in info})==1
 members=[]
 for entry in info:
  assert not entry.is_dir() and not entry.filename.startswith("/") and chr(92) not in entry.filename and all(x not in ("",".","..") for x in entry.filename.split("/"))
  assert stat.S_IFMT(entry.external_attr>>16) in (0,stat.S_IFREG) and entry.file_size<=8*1024*1024
  content=z.read(entry);json.loads(content.decode("utf8"))
  members.append({"name":entry.filename,"bytes":len(content),"sha256":hashlib.sha256(content).hexdigest(),"crc32":entry.CRC,"external_attr":entry.external_attr,"create_system":entry.create_system})
 out["artifacts"].append({"artifact_id":item["id"],"name":item["name"],"endpoint":ep,"returncode":0,"zip_bytes":len(raw),"zip_sha256":dig,"zip_base64":base64.b64encode(raw).decode("ascii"),"members":members})
ansi=re.compile(re.escape(chr(27)+chr(91))+r"[0-?]*[ -/]*[@-~]")
for job in out.get("jobs",{}).get("jobs",[]):
 role={"contract-delta":"contract_delta","ci-pack-6":"owner","ci-gate":"ci_gate"}.get(job["name"])
 if role is None or job["status"]!="completed" or job["id"] in known_log_ids:continue
 ep=f"repos/{REPO}/actions/jobs/{job['id']}/logs";raw,row=rawget(ep,True)
 if raw is None:continue
 assert len(raw)<=8*1024*1024
 lines=raw.decode("utf8",errors="replace").splitlines();clean=[ansi.sub("",line) for line in lines];groups=[]
 if role=="owner":
  for index,line in enumerate(clean):
   if "##[group]company-relationship-candidates" in line:
    stop=next((i for i in range(index+1,len(clean)) if "##[endgroup]" in clean[i]),None)
    assert stop is not None
    groups.append({"start_line":index+1,"end_line":stop+1,"lines":[{"line":i+1,"text":clean[i]} for i in range(index,stop+1)]})
 selected=set()
 terms=("git log -1 --format=%H","HEAD is now","TESTED_TREE_SHA","SUBJECT_HEAD_SHA","BASE_SHA","PLAN_SHA","contract-delta","company-relationship-candidates","semantic proof","classifications:","infrastructure findings","##[error]","passed in","failed in")
 for index,line in enumerate(clean):
  if any(term in line for term in terms):selected.add(index);selected.update(i for i in (index-1,index+1) if 0<=i<len(clean))
 for group in groups:selected.update(range(group["start_line"]-1,group["end_line"]))
 ordered=sorted(selected);truncated=len(ordered)>600
 if truncated:ordered=ordered[:300]+ordered[-300:]
 out["logs"].append({"role":role,"job_id":job["id"],"job_name":job["name"],"job_conclusion":job["conclusion"],"endpoint":ep,"returncode":0,"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"raw_body_retained":True,"raw_base64":base64.b64encode(raw).decode("ascii"),"line_count":len(lines),"selected_lines":[{"line":i+1,"text":clean[i]} for i in ordered],"selected_excerpt_truncated":truncated,"owner_groups":groups})
out["owner_plan_binding"]={"workflow_run_id":str(RUN),"head":HEAD,"plan_sha256":"40fcf0771c17114af3dd85f03a81bd2c81b55d463fcf4feeda816b073bfff5f9","logical_job_id":"company-relationship-candidates","pack_index":6,"source":"Actual independently retained ci-plan.json, artifact11625495919"}
out["principal_context_sources"]=[]
prefix="research/theme_graph/economic_network_execution_20261009/continuation_pro_003/"
for name in ["CI_REFRESH_ADJUDICATION_004.md","CI_REFRESH_CHECKPOINT_MANIFEST_004.json"]:
 path=prefix+name;ep=f"repos/{REPO}/contents/{path}?ref={HEAD}";api,row=rawget(ep);out["operations"].append(row)
 if api is None:continue
 body=json.loads(api);assert body["encoding"]=="base64"
 raw=base64.b64decode(body["content"])
 assert len(raw)==body["size"] and hashlib.sha1(b"blob "+str(len(raw)).encode()+bytes([0])+raw).hexdigest()==body["sha"]
 out["principal_context_sources"].append({"name":name,"repository_path":path,"ref":HEAD,"endpoint":ep,"returncode":0,"git_blob_sha":body["sha"],"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"content_gzip_base64":base64.b64encode(gzip.compress(raw,mtime=0)).decode("ascii"),"contents_api_read":row})

out["completed_at_utc"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
print(json.dumps(out,separators=(",",":"),ensure_ascii=True))

