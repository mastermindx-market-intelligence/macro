import base64,datetime,gzip,hashlib,io,json,re,shutil,stat,subprocess,zipfile
REPO="mastermindx-market-intelligence/macro";HEAD="cbcc5ee143400af162a252e4faac0f06c7157e37";OLD="3521765204903320db76ddd84d6a43539ded8e62";TESTED="";RUN=37949036732
gh=shutil.which("gh") or "/opt/homebrew/bin/gh"
out={"schema":"gmi.pr8711.refresh2_run_and_sources/v1","observed_at_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"sources":[],"diagnostics":[],"operations":[],"artifacts":[],"logs":[]}
def get(ep):
 p=subprocess.run([gh,"api","--method","GET",ep],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45)
 row={"endpoint":ep,"returncode":p.returncode,"bytes":len(p.stdout),"sha256":hashlib.sha256(p.stdout).hexdigest()}
 if p.returncode:row["stderr"]=re.sub(r"https?://[^ ]+","[URL omitted]",p.stderr.decode("utf8",errors="replace")[:1000]);out["diagnostics"].append(row);return None,row
 return json.loads(p.stdout),row
for label,ep in [
("run",f"repos/{REPO}/actions/runs/{RUN}"),
("jobs",f"repos/{REPO}/actions/runs/{RUN}/attempts/1/jobs?per_page=100"),
("artifact_inventory",f"repos/{REPO}/actions/runs/{RUN}/artifacts?per_page=100"),
("checks",f"repos/{REPO}/commits/{HEAD}/check-runs?per_page=100"),
("pr",f"repos/{REPO}/pulls/8711")]:
 value,row=get(ep);out["operations"].append(row)
 if value is not None:out[label]=value
ep=f"repos/{REPO}/compare/{OLD}...{HEAD}?per_page=100"
value,row=get(ep);out["operations"].append(row)
if value is not None:
 out["evidence_commit_compare"]={key:value[key] for key in ["status","ahead_by","behind_by","total_commits"]}
 out["evidence_commit_compare"]["base_commit"]=value["base_commit"]["sha"];out["evidence_commit_compare"]["merge_base_commit"]=value["merge_base_commit"]["sha"]
 out["evidence_commit_compare"]["commits"]=[{"sha":c["sha"],"parents":[p["sha"] for p in c["parents"]]} for c in value["commits"]]
 out["evidence_commit_compare"]["files"]=[{k:f[k] for k in ["filename","status","sha","previous_filename","additions","deletions","changes","blob_url","raw_url"] if k in f} for f in value["files"]]
known_artifact_ids=set();known_log_ids=set();captured_plan=None;owner_job_name=None
def rawget(ep,log=False):
 args=[gh,"api"]
 if log:args+=["--allow-escape-sequences"]
 args+=["--method","GET",ep]
 p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45)
 row={"endpoint":ep,"returncode":p.returncode,"bytes":len(p.stdout),"sha256":hashlib.sha256(p.stdout).hexdigest()}
 if p.returncode:row["stderr"]=re.sub(r"https?://[^ ]+","[URL omitted]",p.stderr.decode("utf8",errors="replace")[:1000]);out["diagnostics"].append(row);return None,row
 return p.stdout,row
for item in out.get("artifact_inventory",{}).get("artifacts",[]):
 if item["id"] in known_artifact_ids:continue
 ep=f"repos/{REPO}/actions/artifacts/{item['id']}/zip";raw,apirow=rawget(ep)
 if raw is None:continue
 dig=hashlib.sha256(raw).hexdigest();assert len(raw)==item["size_in_bytes"] and "sha256:"+dig==item["digest"]
 z=zipfile.ZipFile(io.BytesIO(raw));info=z.infolist();assert len(info)==len({i.filename for i in info})==1
 members=[]
 for entry in info:
  assert not entry.is_dir() and not entry.filename.startswith("/") and chr(92) not in entry.filename and all(x not in ("",".","..") for x in entry.filename.split("/"))
  assert stat.S_IFMT(entry.external_attr>>16) in (0,stat.S_IFREG) and entry.file_size<=8*1024*1024
  content=z.read(entry);parsed=json.loads(content.decode("utf8"))
  if entry.filename=="ci-plan.json":
   assert captured_plan is None
   captured_plan=parsed
  members.append({"name":entry.filename,"bytes":len(content),"sha256":hashlib.sha256(content).hexdigest(),"crc32":entry.CRC,"external_attr":entry.external_attr,"create_system":entry.create_system})
 out["artifacts"].append({"artifact_id":item["id"],"name":item["name"],"endpoint":ep,"returncode":0,"zip_bytes":len(raw),"zip_sha256":dig,"zip_base64":base64.b64encode(raw).decode("ascii"),"members":members})
if captured_plan is not None:
 assert captured_plan["subject_head_sha"]==HEAD and str(captured_plan["workflow_run_id"])==str(RUN)
 TESTED=captured_plan["tested_tree_sha"]
 for label,ep in [("tested_commit",f"repos/{REPO}/git/commits/{TESTED}"),("actual_base_commit",f"repos/{REPO}/git/commits/{captured_plan['base_sha']}")]:
  value,row=get(ep);out["operations"].append(row)
  if value is not None:out[label]=value
 owners=[job for job in captured_plan["semantic_jobs"] if job["logical_job_id"]=="company-relationship-candidates"]
 if len(owners)==1:owner_job_name="ci-pack-"+str(owners[0]["pack_index"])
 out["observed_plan_summary"]={key:captured_plan[key] for key in ("subject_head_sha","tested_tree_sha","base_sha","plan_sha256","changed_files_sha256","changed_files_count","eligible_job_count","skipped_job_count","nonempty_pack_indices")}
 out["observed_plan_summary"]["owner_plan_rows"]=owners
 out["tested_source_binding"]="ACTUAL_RETAINED_PLAN"
 for path in [".github/ci/legacy-jobs.yml","scripts/ci_semantic_proof.py","scripts/run_ci_pack.py","scripts/check_contract_delta.py",".github/workflows/ci.yml","scripts/audit_unrun_tests.py"]:
  ep=f"repos/{REPO}/contents/{path}?ref={TESTED}";value,row=get(ep)
  if value is None:continue
  record={"path":path,"ref":TESTED,"endpoint":ep,"returncode":0,"git_blob_sha":value["sha"],"contents_api_read":row}
  body=value
  if value.get("encoding")!="base64" or not value.get("content"):
   blobep=f"repos/{REPO}/git/blobs/{value['sha']}";body,blobrow=get(blobep);record["blob_api_read"]=blobrow
   if body is None:continue
  assert body["encoding"]=="base64"
  raw=base64.b64decode(body["content"]);actual=hashlib.sha1(b"blob "+str(len(raw)).encode()+bytes([0])+raw).hexdigest()
  assert actual==value["sha"]
  record.update(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),content_gzip_base64=base64.b64encode(gzip.compress(raw,mtime=0)).decode("ascii"))
  if path==".github/ci/legacy-jobs.yml":out["tested_manifest_blob"]=record
  else:out["sources"].append(record)
else:
 out["tested_source_binding"]="PLAN_NOT_AVAILABLE__NO_TESTED_SOURCE_READ"

ansi=re.compile(re.escape(chr(27)+chr(91))+r"[0-?]*[ -/]*[@-~]")
for job in out.get("jobs",{}).get("jobs",[]):
 role={"contract-delta":"contract_delta","ci-gate":"ci_gate"}.get(job["name"])
 if owner_job_name is not None and job["name"]==owner_job_name:role="owner"
 if role is None or job["status"]!="completed" or job["id"] in known_log_ids:continue
 ep=f"repos/{REPO}/actions/jobs/{job['id']}/logs";raw,row=rawget(ep,True)
 if raw is None:continue
 assert len(raw)<=8*1024*1024
 lines=raw.decode("utf8",errors="replace").splitlines();clean=[ansi.sub("",line) for line in lines];groups=[]
 if role=="owner":
  for index,line in enumerate(clean):
   if "##[group]company-relationship-candidates" in line:
    stop=next((i for i in range(index+1,len(clean)) if "##[endgroup]" in clean[i]),None)
    assert stop is not None
    groups.append({"start_line":index+1,"end_line":stop+1,"lines":[{"line":i+1,"text":clean[i]} for i in range(index,stop+1)]})
 selected=set()
 terms=("git log -1 --format=%H","HEAD is now","TESTED_TREE_SHA","SUBJECT_HEAD_SHA","BASE_SHA","PLAN_SHA","contract-delta","company-relationship-candidates","semantic proof","classifications:","infrastructure findings","##[error]","passed in","failed in")
 for index,line in enumerate(clean):
  if any(term in line for term in terms):selected.add(index);selected.update(i for i in (index-1,index+1) if 0<=i<len(clean))
 for group in groups:selected.update(range(group["start_line"]-1,group["end_line"]))
 ordered=sorted(selected);truncated=len(ordered)>600
 if truncated:ordered=ordered[:300]+ordered[-300:]
 out["logs"].append({"role":role,"job_id":job["id"],"job_name":job["name"],"job_conclusion":job["conclusion"],"endpoint":ep,"returncode":0,"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"raw_body_retained":True,"raw_base64":base64.b64encode(raw).decode("ascii"),"line_count":len(lines),"selected_lines":[{"line":i+1,"text":clean[i]} for i in ordered],"selected_excerpt_truncated":truncated,"owner_groups":groups})
out["completed_at_utc"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
print(json.dumps(out,separators=(",",":"),ensure_ascii=True))

