#!/usr/bin/env python3
"""Compare actual retained source/plans for the second normal main refresh."""
import argparse
import copy
import difflib
import hashlib
import json
from pathlib import Path
import yaml

ROOT=Path(__file__).resolve().parent
OWNER='company-relationship-candidates'
CHANGED_JOBS=['biocatalyst-history','conviction-profile','flow-surface','ticker-news-qbus',
              'unrun-government-revenue-candidate-projection','unrun-government-revenue-grader']
HEAD='cbcc5ee143400af162a252e4faac0f06c7157e37'
TESTED='ecd49338799e419055737a20f3fb462c4b97bdd8'
BASE='6ced30b9d69f7e5644d74f1f4648def0ac357c42'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def digest(value):
    return sha(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())


def record(relative):
    path=ROOT/relative
    assert not path.is_symlink() and path.is_file()
    raw=path.read_bytes()
    return {'path':relative,'bytes':len(raw),'sha256':sha(raw)}


class Loader(yaml.SafeLoader):
    pass


def unique(loader,node,deep=False):
    loader.flatten_mapping(node)
    result={}
    for key,value in loader.construct_pairs(node,deep=deep):
        assert key not in result,('duplicate YAML key',key)
        result[key]=value
    return result


Loader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,unique)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',required=True)
    args=parser.parse_args()
    assert Path(args.output).name==args.output and not (ROOT/args.output).exists()
    old_manifest='context/prior_7d5fd_legacy_jobs.yml'
    new_manifest='sources/merged_legacy_jobs.yml'
    old_plan_path='context/prior_7d5fd_ci_plan.json'
    new_plan_path='artifacts/11625495919/ci-plan.json'
    expected_pins={
        old_manifest:'e76d0e54e8401c56016447e8542c750fae02e78c7f160943b1d6a986b8a979aa',
        new_manifest:'5cc24c46e7c4ed8b0b9525366a7069e86f546b32849c72cb8518320842d860cd',
        old_plan_path:'869dca9067e433a7041c9dba35468bb61f21c062454a3f798f15632e41bbb6df',
        new_plan_path:'363332833fb80b962083850a17cc455bf279d33488ef1804b80ffe02888e995e',
        'LOCAL_CANDIDATE_VERIFICATION.json':'33b42ab2cbba3d3600455a85b5cacf4a09623b0fb832eb745d73983bbd744ad5',
    }
    for name,pin in expected_pins.items():
        assert record(name)['sha256']==pin
    old=yaml.load((ROOT/old_manifest).read_text(),Loader=Loader)
    new=yaml.load((ROOT/new_manifest).read_text(),Loader=Loader)
    old_jobs,new_jobs=old['jobs'],new['jobs']
    assert set(old_jobs)==set(new_jobs) and len(new_jobs)==254
    assert {k:v for k,v in old.items() if k!='jobs'}=={k:v for k,v in new.items() if k!='jobs'}
    changed=sorted(job for job in old_jobs if old_jobs[job]!=new_jobs[job])
    assert changed==CHANGED_JOBS
    changes=[]
    for job in changed:
        a,b=old_jobs[job],new_jobs[job]
        assert 'engine/risk_envelope.py' not in a['paths']
        assert b['paths'].count('engine/risk_envelope.py')==1
        assert [p for p in b['paths'] if p!='engine/risk_envelope.py']==a['paths']
        assert {k:v for k,v in a.items() if k!='paths'}=={k:v for k,v in b.items() if k!='paths'}
        changes.append({'logical_job_id':job,'old_paths':a['paths'],'new_paths':b['paths'],
                        'added_path':'engine/risk_envelope.py','all_non_path_fields_identical':True})
    assert old_jobs[OWNER]==new_jobs[OWNER] and len(new_jobs[OWNER]['paths'])==71
    old_plan=json.loads((ROOT/old_plan_path).read_text())
    new_plan=json.loads((ROOT/new_plan_path).read_text())
    assert old_plan['subject_head_sha']=='693ee939c8a28920ef9de7bc32a9f47a7ba76b82'
    assert old_plan['tested_tree_sha']=='7d5fd7428fa91567db755117657f856e1347c5f9'
    assert new_plan['subject_head_sha']==HEAD and new_plan['tested_tree_sha']==TESTED
    assert new_plan['base_sha']==BASE and str(new_plan['workflow_run_id'])=='37949036732'
    assert old_plan['eligible_jobs']==new_plan['eligible_jobs'] and len(new_plan['eligible_jobs'])==98
    assert old_plan['skipped_jobs']==new_plan['skipped_jobs'] and len(new_plan['skipped_jobs'])==84
    before={job['logical_job_id']:job for job in old_plan['semantic_jobs']}
    after={job['logical_job_id']:job for job in new_plan['semantic_jobs']}
    assert set(before)==set(after) and len(after)==98
    placement=[{'logical_job_id':job,'prior_pack':before[job]['pack_index'],'current_pack':after[job]['pack_index']}
               for job in before if before[job]['pack_index']!=after[job]['pack_index']]
    executions=[job for job in before if before[job]['job_exec_sha256']!=after[job]['job_exec_sha256']]
    steps=[{'logical_job_id':job,'prior':before[job]['steps'],'current':after[job]['steps']}
           for job in before if before[job]['steps']!=after[job]['steps']]
    assert placement==[] and executions==[] and steps==[]
    assert sum(len(row['steps']) for row in after.values())==316
    local=json.loads((ROOT/'LOCAL_CANDIDATE_VERIFICATION.json').read_text())
    assert local['identity']['candidate']==HEAD
    assert local['disposition']=='LOCAL_COMMITTED_SOURCE_RECONCILIATION_PASS__REMOTE_AND_CI_NOT_OBSERVED'
    assert local['all_253_other_accepted_jobs_and_top_fields_preserved'] is True
    assert local['owner']['whole_definition']==new_jobs[OWNER]
    local_manifest=next(row for row in local['manifest_inventory'] if row['ref']==HEAD)
    assert local_manifest['bytes']==record(new_manifest)['bytes']
    assert local_manifest['sha256']==record(new_manifest)['sha256']
    source=json.loads((ROOT/'artifact_read_001_and_source_snapshot_001.json').read_text())
    assert source['tested_source_binding']=='ACTUAL_RETAINED_PLAN'
    assert source['tested_commit']['sha']==TESTED
    assert [p['sha'] for p in source['tested_commit']['parents']]==[BASE,HEAD]
    assert source['tested_manifest_blob']['git_blob_sha']==local_manifest['blob_oid']
    assert source['tested_manifest_blob']['sha256']==record(new_manifest)['sha256']
    assert source['tested_manifest_blob']['ref']==TESTED
    laws=[]
    for row in local['ci_law_inventory']:
        current=record('sources/'+row['path'])
        assert current['bytes']==row['bytes'] and current['sha256']==row['sha256']
        laws.append(current)
    diff=''.join(difflib.unified_diff((ROOT/old_manifest).read_text().splitlines(keepends=True),
                                    (ROOT/new_manifest).read_text().splitlines(keepends=True),
                                    fromfile='prior7d/'+old_manifest,tofile='testedecd/'+new_manifest))
    assert (ROOT/'UPSTREAM_MERGED_MANIFEST_DELTA.diff').read_text()==diff
    discovery=json.loads((ROOT/'candidate_discovery_001.json').read_text())
    result={
        'schema':'gmi.pr8711.refresh2_source_assessment/v1','candidate':HEAD,
        'prior_tested_commit':'7d5fd7428fa91567db755117657f856e1347c5f9','tested_commit':TESTED,
        'actual_tested_base':BASE,'candidate_integration_upstream':'87b01101ef13aa20ded205f3a2b267b68d094def',
        'discovery_pr_base_field':discovery['pr']['base']['sha'],
        'discovery_pr_base_field_differs_from_actual_tested_base':discovery['pr']['base']['sha']!=BASE,
        'prior_manifest':record(old_manifest),'current_manifest':record(new_manifest),
        'prior_plan':record(old_plan_path),'current_plan':record(new_plan_path),
        'manifest_diff':record('UPSTREAM_MERGED_MANIFEST_DELTA.diff'),
        'local_source_verification':record('LOCAL_CANDIDATE_VERIFICATION.json'),
        'actual_tested_source_receipt':record('artifact_read_001_and_source_snapshot_001.json'),
        'all_manifest_jobs':254,'added_jobs':[],'removed_jobs':[],
        'changed_job_ids':changed,'scope_changes':changes,'changed_proof_ids':[],'changed_proof_specs':[],
        'all_other_parsed_manifest_fields_identical':True,
        'eligible_inventory_identical':True,'excluded_inventory_identical':True,
        'pack_assignments_identical':True,'pack_assignment_changes':placement,
        'job_execution_context_digest_changes':executions,
        'all_98_execution_contexts_and_316_proof_specs_identical':True,
        'ci_change_limited_to_six_scope_insertions':True,
        'actual_tested_manifest_matches_local_candidate_manifest':True,
        'actual_five_ci_law_sources_match_local_and_previous_pins':laws,
        'owner':{'logical_job_id':OWNER,'definition_identical':True,
                 'definition_canonical_sha256':digest(new_jobs[OWNER]),'scope_path_count':71,
                 'prior_planned_job':before[OWNER],'current_planned_job':after[OWNER],
                 'full_definition':new_jobs[OWNER]},
        'proof_limit':'Structural source/plan comparison only. Hosted pack assignment is read from the actual current plan; prior execution outcomes supply no current-head proof.',
        'application_imports_or_tests':False,'network_or_native_or_git_operations':False,
    }
    raw=(json.dumps(result,indent=2,sort_keys=True)+'\n').encode()
    with (ROOT/args.output).open('xb') as handle:
        handle.write(raw)
    print(json.dumps({'output':record(args.output),'changed_jobs':changed,
                      'changed_proofs':[],'pack_assignment_changes':placement,
                      'owner_current_pack':after[OWNER]['pack_index'],
                      'actual_tested_base':BASE,'local_tested_manifest_match':True},indent=2))


if __name__=='__main__':
    main()

