#!/usr/bin/env python3
"""Write the frozen prepublication source observation from preserved evidence."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def record(name):
    raw=(ROOT/name).read_bytes()
    return {'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def main():
    v=json.loads((ROOT/'LOCAL_CANDIDATE_VERIFICATION.json').read_text())
    assert v['disposition']=='LOCAL_COMMITTED_SOURCE_RECONCILIATION_PASS__REMOTE_AND_CI_NOT_OBSERVED'
    n=v['denominators'];i=v['identity'];full=record('LOCAL_CANDIDATE_VERIFICATION.json')
    source=next(row for row in v['manifest_inventory'] if row['ref']==i['candidate'])
    scope_rows='\n'.join('| `'+row['logical_job_id']+'` | `engine/risk_envelope.py` | unchanged |'
                         for row in v['scope_comparisons'][0]['changes'])
    owner_rows='\n'.join('| `'+row['path']+'` | '+str(row['bytes'])+' | `'+row['sha256']+'` |'
                         for row in v['owner']['enrolled_paths'])
    text=f'''# PR8711 second refresh: local committed-source observation

**Local committed-source reconciliation passed for `{i['candidate']}`.** This observation was completed at **{v['observation_completed_at_utc']}**, before the principal confirmed publication. Its frozen disposition is `{v['disposition']}`. Subsequent remote and CI observations must be recorded separately.

The independent preserved-object verifier passed **{v['verification']['assertions_passed']} assertions**. Full record: `{full['path']}`, **{full['bytes']} bytes**, SHA-256 `{full['sha256']}`. Source bodies remain exact raw Git objects, losslessly retained with SHA-256 and Git object hashes in `local_git_objects_001.json`.

## Actual immutable identities

| Binding | Independently observed value |
|---|---|
| Local candidate | `{i['candidate']}` |
| Candidate Git tree | `{i['candidate_tree']}` |
| Candidate sole parent / integration | `{i['integration']}` |
| Integration Git tree | `{i['integration_tree']}` |
| Integration ordered parents | `{i['integration_ordered_parents'][0]}` then `{i['integration_ordered_parents'][1]}` |
| Supplied accepted upstream | `{i['upstream']}` |
| Prior accepted-main reference | `{i['prior_base']}` |
| CI-definition commit | `{i['ci_definition_commit']}` |
| CI-definition commit's sole parent | `{i['ci_definition_parent']}` |

The verifier reconstructs the complete **13-commit** upstream ancestry from actual raw commit objects. The candidate changes exactly **22 paths** relative to its sole integration parent, all within the existing `continuation_pro_003` evidence directory. Complete paths and before/after tree entries are enumerated in the full verification record.

## Source preservation and owner enrollment

All **53/53 accepted engine/lib byte pins**, totaling **1,483,905 bytes**, match the original accepted reference at checkpoint `6b58f15adae3b1d402d9993c52609d00083f1453`. The whole owner definition and all **71 enrolled owner paths** are byte-identical across the prior candidate, integration and new local candidate. The canonical observation suite remains SHA-256 `a73700e639c8e97a4ff84951b48358abe63b1f5048560d03b0e40f2310ac44da`.

The exact enrolled four-suite command remains:

```sh
{v['owner']['actual_four_suite_command']}
```

This is actual source enrollment. No new hosted execution result, test count or pack assignment is supplied by this local observation.

The current candidate manifest is **{source['bytes']} bytes**, Git blob `{source['blob_oid']}`, SHA-256 `{source['sha256']}`. Its bytes exactly match the integration's manifest. The candidate preserves all **253 other accepted job definitions** and all top-level manifest fields from the supplied accepted upstream. The remaining owner definition exactly matches the previously accepted candidate.

## Exact CI-definition change

Full manifest comparisons independently establish the same six changes in three places: the definition commit, the accepted-main range, and the candidate's normal source refresh. No job identifier, command, runner, conditional or other non-path job field changes. Each listed job receives exactly one additional scope path, preserving the previous path order.

| Existing job | Added scope path | All non-path fields |
|---|---|---|
{scope_rows}

All manifests contain **254 job definitions**. Full old/new path inventories and raw manifest diffs are preserved in the JSON. The semantic reconciler, pack runner, differential contract checker, workflow and discovery source files are all exact against the previously observed pins and the supplied upstream.

## Raw evidence and process accounting

The capture retains **137 raw Git objects**, totaling **8,685,410 bytes**, and **230 reconstructed source bindings**. Every object is checked against its native Git object ID and SHA-256; every file binding is independently traversed through raw tree entries. Files must have regular Git modes. All read operations are reconciled with their exact output lengths and hashes.

The sole local source-read process was **PID 21862**, completed **exit 0** in **6.46 seconds** on the authorized m2studio workspace. Its exact script and completion metadata are retained. Git was invoked with `--no-lazy-fetch`, `--no-optional-locks` and `--no-replace-objects`. No checkout, fetch, working-tree read, application import/test, configuration change or native/Git write was performed.

RDC inserted three framing line breaks in the single compact JSON stdout body. Joining that transport framing recovered the full capture; the independent verifier then checked every embedded raw object. No missing source body was inferred.

The five previous packet transfer objects—the frozen archive, external manifest, archive verification, README and readable report—remain exact and match their actual Git blob identities in this candidate. `PRIOR_V1_PACKET_PRESERVATION.json` records the bindings. The earlier 98-member archive and its verifiers were not rerun or modified.

## Publication and proof limits

`PUBLICATION_STATUS_PRINCIPAL_001.json` preserves the principal's failed-push account as attributed provenance: exit 1, remote still at the prior candidate, and a missing promisor object with lazy fetching disabled. This lane neither executed nor independently certified that push. The local source observation remains valid independently of that publication event.

Later publication and hosted-CI evidence belong to their actual observation times and must use the actual tested merge, base, plan, fragments and logs. They cannot reuse a historical pack assignment or pass result. The principal retains release freshness, protected-source reconciliation, holds, functional acceptance and the native C01 witness.

No rights, historical availability, factual admission, Graph1, production or predictive promotion is made. The 13-commit ancestry and CI/source preservation review do not certify the broader generated-data/site changes.

## Complete owner path inventory

Every row below matches both the integration and prior candidate, including its Git mode, blob identity, length and SHA-256.

| Owner-enrolled path | Bytes | SHA-256 |
|---|---:|---|
{owner_rows}

## Offline verification

With Python 3 and PyYAML, from this evidence directory, use a fresh output filename:

```sh
PYTHONDONTWRITEBYTECODE=1 python -B verify_local_candidate_objects.py --output FRESH_LOCAL_CANDIDATE_VERIFICATION.json
```

This verifier reads preserved evidence without Git, network, native operations or repository application execution.
'''
    raw=text.encode()
    target=ROOT/'LOCAL_CANDIDATE_REPORT.md'
    with target.open('xb') as f:f.write(raw)
    print(json.dumps(record(target.name),indent=2))


if __name__=='__main__':
    main()

