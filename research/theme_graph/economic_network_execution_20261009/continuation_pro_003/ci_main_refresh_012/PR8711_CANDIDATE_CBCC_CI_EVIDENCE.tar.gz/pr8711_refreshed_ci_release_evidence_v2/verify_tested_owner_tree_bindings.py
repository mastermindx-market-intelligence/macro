#!/usr/bin/env python3
"""Bind the 71 preserved owner files to the actual tested tree through Git objects."""
import argparse
import base64
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import stat

ROOT=Path(__file__).resolve().parent
HEAD='cbcc5ee143400af162a252e4faac0f06c7157e37'
TESTED='ecd49338799e419055737a20f3fb462c4b97bdd8'
TREE='cbf9097804ffa9e094ec700bfc8a044e8ed7ee8d'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(name):
    path=ROOT/name
    assert path.is_relative_to(ROOT) and '..' not in Path(name).parts
    assert not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode)
    raw=path.read_bytes()
    assert len(raw)<=16*1024*1024
    return raw


def record(name):
    raw=read(name)
    return {'path':name,'bytes':len(raw),'sha256':sha(raw)}


def loads(raw):
    def unique(items):
        out={}
        for key,value in items:
            assert key not in out
            out[key]=value
        return out
    return json.loads(raw.decode('utf8'),object_pairs_hook=unique)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',required=True)
    args=parser.parse_args()
    assert Path(args.output).name==args.output and not (ROOT/args.output).exists()
    assert record('LOCAL_CANDIDATE_VERIFICATION.json')['sha256']=='33b42ab2cbba3d3600455a85b5cacf4a09623b0fb832eb745d73983bbd744ad5'
    assert record('SOURCE_PIN_VERIFICATION.json')['sha256']=='4fa42b3739aa87f8757935b74053d96b19846c0fa7eda24fa4a4c660054deef1'
    local=loads(read('LOCAL_CANDIDATE_VERIFICATION.json'))
    local_capture=loads(read('local_git_objects_001.json'))
    direct=loads(read('SOURCE_PIN_VERIFICATION.json'))
    remote_capture=loads(read('tested_source_pin_read_001.json'))
    assert local['capture']==record('local_git_objects_001.json')
    assert direct['source_read_receipt']==record('tested_source_pin_read_001.json')
    assert local['identity']['candidate']==direct['head']==remote_capture['head']==HEAD
    assert direct['tested_commit']==remote_capture['tested_commit']==TESTED
    assert direct['tested_git_tree']==remote_capture['tree_sha']==TREE
    objects={row['oid']:row for row in local_capture['objects']}
    assert len(objects)==len(local_capture['objects'])==137
    verified={}

    def obj(oid,kind):
        if oid not in verified:
            row=objects[oid]
            raw=gzip.decompress(base64.b64decode(row['gzip_base64'],validate=True))
            assert row['kind']==kind and len(raw)==row['bytes'] and sha(raw)==row['sha256']
            assert hashlib.sha1(kind.encode()+b' '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==oid
            verified[oid]=(kind,raw)
        assert verified[oid][0]==kind
        return verified[oid][1]

    trees={}

    def tree(oid):
        if oid not in trees:
            raw=obj(oid,'tree');index=0;entries={}
            while index<len(raw):
                space=raw.index(b' ',index);end=raw.index(b'\0',space+1)
                mode=raw[index:space].decode('ascii');name=raw[space+1:end].decode('utf8')
                assert name and name not in {'.','..'} and '/' not in name and '\\' not in name
                assert name not in entries and end+21<=len(raw)
                entries[name]={'mode':mode,'oid':raw[end+1:end+21].hex()}
                index=end+21
            assert index==len(raw)
            trees[oid]=entries
        return trees[oid]

    commit=obj(HEAD,'commit')
    roots=[line[5:].decode('ascii') for line in commit.split(b'\n\n',1)[0].splitlines()
           if line.startswith(b'tree ')]
    assert roots==[local['identity']['candidate_tree']]
    local_root=tree(roots[0])

    root_reads=[row for row in remote_capture['tree_reads'] if row['scope']=='root']
    assert len(root_reads)==1
    root_read=root_reads[0]
    assert root_read['returncode']==0 and root_read['endpoint']==f'repos/mastermindx-market-intelligence/macro/git/trees/{TREE}'
    api_raw=gzip.decompress(base64.b64decode(root_read['raw_json_gzip_base64'],validate=True))
    assert len(api_raw)==root_read['bytes'] and sha(api_raw)==root_read['sha256']
    remote=loads(api_raw)
    assert remote['sha']==TREE and remote['truncated'] is False
    remote_entries={entry['path']:entry for entry in remote['tree']}
    assert len(remote_entries)==len(remote['tree'])
    for name,entry in remote_entries.items():
        assert name and name not in {'.','..'} and '/' not in name and '\\' not in name and '\0' not in name
        assert entry['mode'] in {'040000','100644','100755','120000','160000'}
    ordered=sorted(remote['tree'],key=lambda e:e['path'].encode('utf8')+(b'/' if e['mode']=='040000' else b''))
    root_bytes=b''.join(entry['mode'].lstrip('0').encode()+b' '+entry['path'].encode('utf8')
                        +b'\0'+bytes.fromhex(entry['sha']) for entry in ordered)
    assert hashlib.sha1(b'tree '+str(len(root_bytes)).encode()+b'\0'+root_bytes).hexdigest()==TREE

    paths=local['owner']['enrolled_paths']
    assert len(paths)==len({row['path'] for row in paths})==71
    scopes=sorted({row['path'].split('/',1)[0] for row in paths})
    assert scopes==['collectors','config','engine','lib','research','scripts','tests']
    scope_rows=[]
    for scope in scopes:
        a,b=local_root[scope],remote_entries[scope]
        assert a['mode']=='40000' and b['mode']=='040000' and b['type']=='tree'
        assert a['oid']==b['sha']
        scope_rows.append({'scope':scope,'candidate_subtree_oid':a['oid'],
                           'actual_tested_subtree_oid':b['sha'],'exact_identity':True})
    files=[]
    for expected in paths:
        parts=expected['path'].split('/');root=roots[0]
        for index,name in enumerate(parts):
            entry=tree(root)[name]
            if index<len(parts)-1:
                assert entry['mode']=='40000'
                root=entry['oid']
            else:
                assert entry['mode'] in {'100644','100755'}
                raw=obj(entry['oid'],'blob')
                assert expected['ref']==HEAD and expected['mode']==entry['mode']
                assert expected['blob_oid']==entry['oid'] and expected['bytes']==len(raw)
                assert expected['sha256']==sha(raw)
                files.append({'path':expected['path'],'mode':entry['mode'],'git_blob_oid':entry['oid'],
                              'bytes':len(raw),'sha256':sha(raw),'scope':parts[0],
                              'same_bytes_reachable_from_actual_tested_root':True,
                              'same_as_local_candidate_integration_and_prior_candidate':True})
    actual_by_path={row['path']:row for row in files}
    for row in direct['files']:
        bound=actual_by_path[row['path']]
        assert all(bound[key]==row[key] for key in ('bytes','sha256','mode'))
        assert bound['git_blob_oid']==row['git_blob_sha']
    result={
        'schema':'gmi.pr8711.refresh2_tested_owner_subtree_binding/v1',
        'created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'status':'ALL_71_OWNER_FILE_BYTE_IDENTITIES_BOUND_TO_ACTUAL_TESTED_TREE',
        'head':HEAD,'tested_commit':TESTED,'tested_git_tree':TREE,
        'observed_at_utc':remote_capture['observed_at_utc'],
        'observation_completed_at_utc':remote_capture['completed_at_utc'],
        'local_candidate_git_tree':roots[0],'owner_enrolled_file_count':71,
        'owner_subtree_count':len(scopes),'subtree_bindings':scope_rows,
        'verified_local_git_objects_used':len(verified),
        'source_files':files,'owner_file_bytes':sum(row['bytes'] for row in files),
        'fresh_direct_api_byte_pin_count':53,
        'actual_tested_root_reconstructed_and_git_object_hash_verified':True,
        'actual_root_git_bytes':len(root_bytes),'actual_root_sha256':sha(root_bytes),
        'inputs':{name:record(name) for name in [
            'LOCAL_CANDIDATE_VERIFICATION.json','local_git_objects_001.json',
            'SOURCE_PIN_VERIFICATION.json','tested_source_pin_read_001.json']},
        'verifier':record(Path(__file__).name),
        'proof_limits':[
            'Uses the already captured actual tested root and preserved local raw Git-object closure; no new native or network read.',
            'All 71 bytes are bound through identical committed owner subtrees; the 53 engine/lib bytes also have independent fresh GitHub blob reads.',
            'The other 18 paths are established by the Git object chain, not falsely described as 18 fresh GitHub blob downloads.',
            'Byte compatibility only. No functional source admission, hosted test result, current freshness/hold ruling, merge or native C01 authority.',
        ],
        'application_imports_or_tests':False,'native_or_git_mutations':False,
        'new_network_or_native_operations':False,
    }
    raw=(json.dumps(result,indent=2,sort_keys=True)+'\n').encode()
    with (ROOT/args.output).open('xb') as f:f.write(raw)
    print(json.dumps({'output':record(args.output),'status':result['status'],
                      'owner_files':71,'subtree_bindings':7,'owner_file_bytes':result['owner_file_bytes'],
                      'verified_local_git_objects_used':len(verified)},indent=2))


if __name__=='__main__':
    main()

