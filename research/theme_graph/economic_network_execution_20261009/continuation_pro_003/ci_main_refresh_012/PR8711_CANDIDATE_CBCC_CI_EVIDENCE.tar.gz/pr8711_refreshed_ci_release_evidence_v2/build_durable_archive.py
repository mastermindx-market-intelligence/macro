#!/usr/bin/env python3
"""Deterministic scratch-only archive and unchanged preserved-data replays.

No network, Git, native device operation, repository imports or application
tests. Only the five current-generation preserved-data verifiers are executed.
"""
import datetime
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parent
DESTINATION = ROOT / 'durable_archive'
PREFIX = 'pr8711_refreshed_ci_release_evidence_v2'
ARCHIVE_NAME = 'PR8711_REFRESHED_V2_CANDIDATE_CI_EVIDENCE.tar.gz'
MANIFEST_NAME = 'ARCHIVE_MANIFEST.json'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def safe(name):
    assert type(name) is str and name and not name.startswith('/') and '\\' not in name
    assert all(part not in {'', '.', '..'} for part in name.split('/'))
    assert str(PurePosixPath(name)) == name
    return name


def record(path):
    raw = path.read_bytes()
    return {'name': path.name, 'bytes': len(raw), 'sha256': sha(raw)}


def dump(path, value):
    raw = (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + '\n').encode()
    with path.open('xb') as handle:
        handle.write(raw)
    return record(path)


def load(path):
    return json.loads(path.read_text())


def main():
    assert not DESTINATION.exists(), 'Do not overwrite a frozen archive.'
    review = load(ROOT / 'CI_EVIDENCE_VERIFICATION.json')
    source_proof = load(ROOT / 'SOURCE_PIN_VERIFICATION.json')
    source_assessment = load(ROOT / 'SOURCE_REFRESH_ASSESSMENT.json')
    processes = load(ROOT / 'native_read_scripts.json')
    local_proof = load(ROOT / 'LOCAL_CANDIDATE_VERIFICATION.json')
    owner_tree_proof = load(ROOT / 'TESTED_OWNER71_BINDING_VERIFICATION.json')
    assert source_assessment['tested_commit'] == 'ecd49338799e419055737a20f3fb462c4b97bdd8'
    assert source_assessment['actual_tested_base'] == '6ced30b9d69f7e5644d74f1f4648def0ac357c42'
    assert source_assessment['pack_assignment_changes'] == []
    assert source_assessment['all_98_execution_contexts_and_316_proof_specs_identical'] is True
    assert source_assessment['changed_job_ids'] == [
        'biocatalyst-history', 'conviction-profile', 'flow-surface', 'ticker-news-qbus',
        'unrun-government-revenue-candidate-projection', 'unrun-government-revenue-grader']
    assert sha((ROOT / 'assess_source_refresh.py').read_bytes()) == '42ab06944f365332ae460fd1eb766d6c88854f05b0f29c52d492b95f75c6e454'
    assert review['identity']['subject_head_sha'] == 'cbcc5ee143400af162a252e4faac0f06c7157e37'
    assert review['identity']['workflow_run_id'] == '37949036732'
    assert local_proof['all_53_accepted_code_pins_match'] is True
    assert local_proof['denominators']['owner_paths_byte_identical_to_prior_and_integration'] == 71
    assert owner_tree_proof['owner_enrolled_file_count'] == 71
    assert owner_tree_proof['status'] == 'ALL_71_OWNER_FILE_BYTE_IDENTITIES_BOUND_TO_ACTUAL_TESTED_TREE'
    assert owner_tree_proof['tested_commit'] == source_assessment['tested_commit']
    assert review['completeness']['complete_ci_pass_evidence'] is True
    assert review['denominators']['observed_retained_artifacts'] == 15
    assert review['denominators']['observed_fragments'] == 12
    assert review['denominators']['observed_jobs'] == 98
    assert review['denominators']['observed_proof_steps'] == 316
    assert review['aggregate']['classifications'] == {'passed': 316}
    assert source_proof['all_matches'] is True and source_proof['pinned_file_count'] == 53
    assert load(ROOT / 'native_read_scripts.json')['all_managed_processes_reconciled'] is True
    required_logs = {row['path']: row for row in review['whole_log_inventory']}
    assert len(required_logs) == 3

    # Reproduce the bounded exact raw-log packaging scan. False positives would
    # stop packaging for inspection; this does not alter any retained log.
    patterns = {
        'signed_s3_query': rb'(?i)[?&]X-Amz-(?:Signature|Credential)=',
        'signed_azure_query': rb'(?i)https?://[^\s"<>]*[?&]sig=',
        'github_pat': rb'github_pat_[A-Za-z0-9_]{40,}',
        'github_token': rb'gh[pousr]_[A-Za-z0-9]{30,}',
        'private_key_header': rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
    }
    log_scan = []
    for relative, row in required_logs.items():
        raw = (ROOT / relative).read_bytes()
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
        findings = {name: len(re.findall(pattern, raw)) for name, pattern in patterns.items()}
        assert all(count == 0 for count in findings.values()), (relative, findings)
        log_scan.append({'path': relative, 'bytes': len(raw), 'sha256': sha(raw), 'findings': findings})
    dump(ROOT / 'RAW_LOG_PACKAGING_CHECK.json', {
        'schema': 'gmi.pr8711.refresh2_raw_log_packaging_scan/v1',
        'patterns': {name: pattern.decode('ascii') for name, pattern in patterns.items()},
        'whole_logs': log_scan, 'all_pattern_counts_zero': True,
        'raw_log_bytes_unchanged': True,
        'limit': 'Bounded common credential/signed-URL patterns, not a universal secret-detection guarantee.'})

    rows = []
    original_mtimes = {}
    for current, directories, files in os.walk(ROOT, followlinks=False):
        current = Path(current)
        for name in directories:
            node = current / name
            assert not node.is_symlink() and stat.S_ISDIR(node.lstat().st_mode), str(node)
            assert name not in {'__pycache__', '.git', '.pytest_cache', '.mypy_cache', '.ruff_cache'}, str(node)
        for name in files:
            node = current / name
            assert not node.is_symlink() and stat.S_ISREG(node.lstat().st_mode), str(node)
            relative = safe(node.relative_to(ROOT).as_posix())
            assert not relative.endswith(('.pyc', '.pyo')), relative
            if relative.endswith('.log'):
                assert relative in required_logs, relative
            raw = node.read_bytes()
            assert len(raw) <= 16 * 1024 * 1024
            rows.append({'archive_name': safe(PREFIX + '/' + relative), 'source_relative_path': relative,
                         'bytes': len(raw), 'sha256': sha(raw)})
            original_mtimes[relative] = node.stat().st_mtime_ns
    rows.sort(key=lambda row: row['archive_name'])
    assert len(rows) == len({row['archive_name'] for row in rows})
    total = sum(row['bytes'] for row in rows)
    assert len(rows) < 512 and total <= 64 * 1024 * 1024
    relative_names = {row['source_relative_path'] for row in rows}
    required_artifact_files = set()
    for artifact in review['artifact_inventory']:
        required_artifact_files.add(artifact['zip']['path'])
        assert len(artifact['members']) == 1
        required_artifact_files.add(artifact['members'][0]['path'])
    actual_artifact_files = {name for name in relative_names if name.startswith('artifacts/')}
    assert len(required_artifact_files) == 30 and actual_artifact_files == required_artifact_files
    assert sum(name.endswith('/original.zip') for name in actual_artifact_files) == 15
    assert sum(name.endswith('.json') for name in actual_artifact_files) == 15
    assert review['verification']['verifier']['sha256'] == sha((ROOT / 'verify_refreshed_artifacts.py').read_bytes())
    assert source_proof['verifier']['sha256'] == sha((ROOT / 'verify_tested_code_pins.py').read_bytes())
    assert local_proof['verifier']['sha256'] == sha((ROOT / 'verify_local_candidate_objects.py').read_bytes())
    assert owner_tree_proof['verifier']['sha256'] == sha((ROOT / 'verify_tested_owner_tree_bindings.py').read_bytes())

    DESTINATION.mkdir()
    manifest = {
        'schema': 'gmi.pr8711.refresh2_deterministic_evidence_archive_manifest/v1',
        'archive_name': ARCHIVE_NAME, 'archive_prefix': PREFIX,
        'identity': review['identity'], 'attempt': 1,
        'frozen_observation_completed_at_utc': review['observation_completed_at_utc'],
        'disposition': review['disposition'],
        'regular_file_count': len(rows), 'uncompressed_file_bytes': total, 'entries': rows,
        'actual_artifact_zip_count': 15, 'actual_artifact_json_member_count': 15,
        'whole_raw_log_count': 3, 'accepted_source_byte_pin_count': 53,
        'actual_tested_owner_file_byte_binding_count': 71,
        'local_raw_git_object_count': 137, 'local_resolved_source_bindings': 230,
        'normalized_metadata': {'archive_format': 'POSIX pax tar in gzip',
            'gzip_mtime': 0, 'gzip_filename': '', 'tar_member_mtime': 0,
            'uid': 0, 'gid': 0, 'uname': '', 'gname': '', 'mode_octal': '0644',
            'entry_order': 'archive-name lexical'},
        'explicit_exclusions': ['durable_archive outputs created after input enumeration',
            'credentials and signed artifact redirect URLs were not retained',
            'caches, unrelated sibling lanes and prior already-committed candidate archives'],
        'manifest_is_external': True,
    }
    manifest_record = dump(DESTINATION / MANIFEST_NAME, manifest)

    def build_archive(destination):
        with gzip.GzipFile(filename='', fileobj=destination, mode='wb', compresslevel=9, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as archive:
                for row in rows:
                    raw = (ROOT / row['source_relative_path']).read_bytes()
                    assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
                    info = tarfile.TarInfo(row['archive_name'])
                    info.type = tarfile.REGTYPE
                    info.size = len(raw)
                    info.mode = 0o644
                    info.uid = info.gid = info.mtime = 0
                    info.uname = info.gname = ''
                    archive.addfile(info, io.BytesIO(raw))

    archive_path = DESTINATION / ARCHIVE_NAME
    with archive_path.open('xb') as handle:
        build_archive(handle)
    archive_record = record(archive_path)
    second_encoding = io.BytesIO()
    build_archive(second_encoding)
    assert second_encoding.getvalue() == archive_path.read_bytes()

    extracted = DESTINATION / 'verification_extract'
    extracted.mkdir()
    expected = {row['archive_name']: row for row in rows}
    with tarfile.open(archive_path, 'r:gz') as archive:
        members = archive.getmembers()
        assert len(members) == len(rows)
        assert [member.name for member in members] == [row['archive_name'] for row in rows]
        assert len({member.name for member in members}) == len(rows)
        for member in members:
            safe(member.name)
            assert member.name in expected and member.isreg() and not member.issym() and not member.islnk()
            assert member.mode == 0o644 and member.uid == member.gid == member.mtime == 0
            assert member.uname == member.gname == '' and set(member.pax_headers).issubset({'path'})
            raw = archive.extractfile(member).read()
            row = expected[member.name]
            assert len(raw) == member.size == row['bytes'] and sha(raw) == row['sha256']
            target = extracted / member.name
            assert target.is_relative_to(extracted)
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as handle:
                handle.write(raw)
            assert target.read_bytes() == raw
    actual_names = sorted(path.relative_to(extracted).as_posix() for path in extracted.rglob('*') if path.is_file())
    assert actual_names == sorted(expected)
    extracted_root = extracted / PREFIX

    replay_records = []
    replay_specs = [
        ('verify_local_candidate_objects.py', [], 'LOCAL_CANDIDATE_VERIFICATION.json',
         'ARCHIVE_REPLAY_LOCAL_CANDIDATE_VERIFICATION.json'),
        ('verify_tested_code_pins.py', [], 'SOURCE_PIN_VERIFICATION.json',
         'ARCHIVE_REPLAY_SOURCE_PIN_VERIFICATION.json'),
        ('verify_tested_owner_tree_bindings.py', [], 'TESTED_OWNER71_BINDING_VERIFICATION.json',
         'ARCHIVE_REPLAY_TESTED_OWNER71_BINDING_VERIFICATION.json'),
        ('assess_source_refresh.py', [], 'SOURCE_REFRESH_ASSESSMENT.json',
         'ARCHIVE_REPLAY_SOURCE_REFRESH_ASSESSMENT.json'),
        ('verify_refreshed_artifacts.py', ['--snapshot', review['snapshot_file']], 'CI_EVIDENCE_VERIFICATION.json',
         'ARCHIVE_REPLAY_CI_EVIDENCE_VERIFICATION.json'),
    ]
    for script, arguments, original_name, replay_name in replay_specs:
        command = [sys.executable, '-B', str(extracted_root / script), *arguments, '--output', replay_name]
        process = subprocess.run(command, cwd=extracted_root, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                 timeout=60, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
        assert process.returncode == 0, process.stderr.decode('utf8', 'replace')[:2000]
        original = load(ROOT / original_name)
        replay_path = extracted_root / replay_name
        replay = load(replay_path)
        byte_identical = replay_path.read_bytes() == (ROOT / original_name).read_bytes()
        if script == 'assess_source_refresh.py':
            assert byte_identical
        assert {k: v for k, v in original.items() if k != 'created_at_utc'} == {
            k: v for k, v in replay.items() if k != 'created_at_utc'}
        replay_records.append({'relative_command': ['python', '-B', PREFIX + '/' + script,
                                                   *arguments, '--output', replay_name],
                               'exit_code': process.returncode, 'stdout_bytes': len(process.stdout),
                               'stdout_sha256': sha(process.stdout), 'stderr_bytes': len(process.stderr),
                               'stderr_sha256': sha(process.stderr),
                               'output': {'archive_relative_path': PREFIX + '/' + replay_name,
                                          **record(replay_path)},
                               'matches_original_except_created_at_utc': True,
                               'matches_original_bytes': byte_identical,
                               'original_preserved_report': PREFIX + '/' + original_name})
    for row in rows:
        for node in (ROOT / row['source_relative_path'], extracted / row['archive_name']):
            assert not node.is_symlink() and stat.S_ISREG(node.lstat().st_mode)
            raw = node.read_bytes()
            assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
        assert (ROOT / row['source_relative_path']).stat().st_mtime_ns == original_mtimes[row['source_relative_path']]
    extra_outputs = [PREFIX + '/' + spec[3] for spec in replay_specs]
    after_names = sorted(path.relative_to(extracted).as_posix() for path in extracted.rglob('*') if path.is_file())
    assert after_names == sorted([*expected, *extra_outputs])
    result = {
        'schema': 'gmi.pr8711.refresh2_deterministic_evidence_archive_verification/v1',
        'verified_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'archive': archive_record, 'manifest': manifest_record,
        'status': 'VERIFIED_FROZEN_REFRESHED_CANDIDATE_COMPLETE_CI_EVIDENCE',
        'identity': review['identity'], 'attempt': 1, 'disposition': review['disposition'],
        'regular_file_count': len(rows), 'uncompressed_file_bytes': total,
        'actual_artifact_zip_count': 15, 'actual_artifact_json_member_count': 15,
        'observed_fragments': 12, 'selected_jobs': 98, 'proof_steps': 316,
        'step_classifications': {'passed': 316}, 'whole_raw_log_count': 3,
        'accepted_code_pins_verified': 53, 'actual_tested_owner_inputs_bound': 71,
        'local_source_assertions_passed': local_proof['verification']['assertions_passed'],
        'ci_verifier_assertions_passed': review['verification']['assertions_passed'],
        'all_manifest_entries_extracted_and_verified': True,
        'normalized_metadata_verified': True, 'unique_regular_files_only': True,
        'deterministic_reencode_byte_identical': True,
        'original_files_unchanged_after_packaging': True, 'original_file_mtimes_unchanged': True,
        'all_preserved_extracted_files_unchanged_after_verifiers': True,
        'replay_verifiers': replay_records, 'executed_verifier_count': 5,
        'source_refresh_assessment_replay_byte_identical': True,
        'extra_extracted_outputs_accounted_for': extra_outputs,
        'authority': {'merge_authorized': False, 'policy_waiver': False, 'ci_rerun': False,
                      'native_mutation': False, 'git_mutation': False, 'application_imports_or_tests': False},
    }
    verification_record = dump(DESTINATION / 'ARCHIVE_VERIFICATION.json', result)
    readme = f'''# PR8711 refreshed candidate v2 CI evidence archive

**Complete observed CI evidence for candidate `cbcc5ee143400af162a252e4faac0f06c7157e37`. Canonical release adjudication remains with the principal.**

The frozen observation completed at **{review['observation_completed_at_utc']}**. Run **37949036732**, attempt **1**, concluded **success**. Actual tested synthetic commit: `ecd49338799e419055737a20f3fb462c4b97bdd8`. Ordered parents: `6ced30b9d69f7e5644d74f1f4648def0ac357c42` then the exact candidate head. Distinct Git tree: `cbf9097804ffa9e094ec700bfc8a044e8ed7ee8d`. The integrated upstream and initial PR base field `87b01101` are separately retained; neither substitutes for the actual tested base.

The archive preserves all **15 original artifact ZIPs and 15 exact JSON members**: plan, changed paths, **12 raw pack fragments** and final aggregate. The independent verifier accounts for **98/98 selected logical jobs and 316/316 proof steps**, all passed. It recomputes the 98 execution-context and 316 step-specification source digests and reconstructs the complete all-pass aggregate. Its logical SHA-256 is `{review['aggregate']['evidence_sha256']}`. Full final-gate JSON stdout, summary and notices match the retained aggregate. The 254 manifest jobs comprise 182 code jobs (98 selected, 84 explicitly excluded) and 72 other gate jobs; those larger sets are not test-pass denominators.

The actual current relationship owner belongs to **pack {review['owner']['pack_index']}**, with **275 passed in {review['owner']['actual_result']['seconds']}s**. The actual current differential contract gate reports **0 introduced, 0 inherited** against 6ced30. Whole raw owner, contract and final-gate logs are unchanged and have exact byte hashes and line references.

The new direct API proof verifies **53 accepted engine/lib byte pins, 1,483,905 bytes**, from 3 complete Git trees and 52 unique blobs. A separate Git-object-chain proof binds **all 71 owner inputs, 2,152,680 bytes**, to the actual tested root, using 85 already-retained local Git objects and 7 exact subtree identities. It does not claim 18 additional fresh blob downloads or a new functional review.

The frozen prepublication source proof verifies 137 raw local Git objects, 230 source bindings, all 71 owner files at prior candidate/integration/new candidate, 13 accepted upstream commits, and 22 evidence-only candidate paths. Its historical remote/CI-not-observed status remains unchanged. Later captures independently establish publication and the natural new run. The actual CI-definition comparison finds exactly six existing-job scope insertions of engine/risk_envelope.py, with no command or ID change. All 98 execution digests, 316 proof specifications and pack assignments remain identical across the actual plans. Five actual CI-law files remain byte-identical to their prior pins.

## Transfer files

| File | Bytes | SHA-256 |
|---|---:|---|
| `{ARCHIVE_NAME}` | {archive_record['bytes']} | `{archive_record['sha256']}` |
| `{MANIFEST_NAME}` | {manifest_record['bytes']} | `{manifest_record['sha256']}` |
| `ARCHIVE_VERIFICATION.json` | {verification_record['bytes']} | `{verification_record['sha256']}` |

Keep this README with those three files. The archive has **{len(rows)} regular files** totaling **{total:,} uncompressed file bytes**, under `{PREFIX}/`. The external manifest lists every relative name, byte length and SHA-256. Outer metadata, ownership, times, modes and ordering are normalized. An independent second in-memory encoding was byte-identical. Every original GitHub ZIP retains its internal metadata. No links, duplicate names, traversal entries, caches, unrelated lanes or previous already-committed archives are included. No credentials or signed redirect URLs were retained. A bounded common-pattern scan of all 3 whole logs passed without modifying them.

Entry points: `OBSERVATION_REPORT.md`, `CI_EVIDENCE_VERIFICATION.json`, `FOCUSED_OBSERVATION.json`, `ARTIFACT_INVENTORY.json`, `LOCAL_CANDIDATE_VERIFICATION.json`, `SOURCE_PIN_VERIFICATION.json`, `TESTED_OWNER71_BINDING_VERIFICATION.json`, `SOURCE_REFRESH_ASSESSMENT.json`, `READ_TIMELINE.json`, `PACKAGING_NOTES.md` and `native_read_scripts.json`.

All **{processes['managed_process_count']} observer-managed native PIDs** are reconciled. Exact scripts and process metadata are preserved. Prior partial observations and initial publication/prepublication status are preserved, not relabelled. Principal004 adjudication/checkpoint and prior 693 five-object transfer binding are retained as attributed provenance. The prior 98-file successful packet remains separate and was not replayed. The archive builder's original source, exact diff and derivation record are included.

Every manifest entry was safely extracted and independently verified. All **five unchanged current-generation preserved-data verifiers** then ran from the extracted layout with fresh output names. The source assessment replay is byte-identical. The local-source, 53-pin, 71-owner and final CI reports match their originals except created_at_utc; all **{review['verification']['assertions_passed']:,} CI assertions** passed again. The 5 new replay outputs are separately accounted for and are not inserted into the archive. All original and extracted preserved bytes remain unchanged; original input mtimes are also unchanged.

From the extracted evidence directory, with Python 3 and PyYAML:

```sh
PYTHONDONTWRITEBYTECODE=1 python -B verify_local_candidate_objects.py --output FRESH_LOCAL_CANDIDATE_VERIFICATION.json
PYTHONDONTWRITEBYTECODE=1 python -B verify_tested_code_pins.py --output FRESH_SOURCE_PIN_VERIFICATION.json
PYTHONDONTWRITEBYTECODE=1 python -B verify_tested_owner_tree_bindings.py --output FRESH_TESTED_OWNER71_BINDING_VERIFICATION.json
PYTHONDONTWRITEBYTECODE=1 python -B assess_source_refresh.py --output FRESH_SOURCE_REFRESH_ASSESSMENT.json
PYTHONDONTWRITEBYTECODE=1 python -B verify_refreshed_artifacts.py --snapshot {review['snapshot_file']} --output FRESH_CI_EVIDENCE_VERIFICATION.json
```

Use fresh output names. These operations use preserved data only, without GitHub/network, native operations, Git mutation, repository application imports or application tests. Final replay uses the selected final snapshot and all captures. Earlier partial snapshots retain their original observation bounds.

The exact-head census keeps the observed ci-authority/codex/merge-queue-pilot failure explicit. This packet does not waive any check or determine current policy binding. Root retains protected procedures, current main freshness and holds, expected-head merge, accepted-source verification and the actual native C01 witness. No rights, history, factual, Graph1, production or predictive promotion is made.
'''
    with (DESTINATION / 'ARCHIVE_README.md').open('x', encoding='utf8') as handle:
        handle.write(readme)
    print(json.dumps({'archive_directory': str(DESTINATION), 'archive': archive_record,
                      'manifest': manifest_record, 'verification': verification_record,
                      'readme': record(DESTINATION / 'ARCHIVE_README.md'),
                      'regular_files': len(rows), 'uncompressed_file_bytes': total,
                      'all_five_unchanged_verifier_replays_passed': True,
                      'status': result['status']}, indent=2))


if __name__ == '__main__':
    main()
