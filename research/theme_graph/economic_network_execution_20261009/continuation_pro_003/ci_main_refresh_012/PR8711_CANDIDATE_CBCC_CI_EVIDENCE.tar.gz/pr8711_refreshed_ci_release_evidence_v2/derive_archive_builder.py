#!/usr/bin/env python3
"""Derive the v2 packaging helper from the retained v1 source, without running it."""
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ORIGIN = 'verifier_origin/build_refreshed_v1_archive.py.txt'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write(name, raw):
    with (ROOT / name).open('xb') as handle:
        handle.write(raw)
    return {'path': name, 'bytes': len(raw), 'sha256': sha(raw)}


def replace_one(source, old, new):
    assert source.count(old) == 1, old[:100]
    return source.replace(old, new, 1)


def main():
    raw = (ROOT / ORIGIN).read_bytes()
    source = raw.decode()
    source = source.replace('Only the three already-owned preserved-data verifiers are executed.',
                            'Only the five current-generation preserved-data verifiers are executed.')
    source = replace_one(source, "PREFIX = 'pr8711_refreshed_ci_release_evidence_v1'",
                         "PREFIX = 'pr8711_refreshed_ci_release_evidence_v2'")
    source = replace_one(source, "ARCHIVE_NAME = 'PR8711_REFRESHED_CANDIDATE_CI_EVIDENCE.tar.gz'",
                         "ARCHIVE_NAME = 'PR8711_REFRESHED_V2_CANDIDATE_CI_EVIDENCE.tar.gz'")
    source = source.replace('gmi.pr8711.refreshed_', 'gmi.pr8711.refresh2_')
    source = replace_one(source,
        "    processes = load(ROOT / 'native_read_scripts.json')\n",
        "    processes = load(ROOT / 'native_read_scripts.json')\n"
        "    local_proof = load(ROOT / 'LOCAL_CANDIDATE_VERIFICATION.json')\n"
        "    owner_tree_proof = load(ROOT / 'TESTED_OWNER71_BINDING_VERIFICATION.json')\n")
    start = source.index("    assert source_assessment['tested_commit']")
    end = source.index("    assert review['completeness']", start)
    source = source[:start] + """    assert source_assessment['tested_commit'] == 'ecd49338799e419055737a20f3fb462c4b97bdd8'
    assert source_assessment['actual_tested_base'] == '6ced30b9d69f7e5644d74f1f4648def0ac357c42'
    assert source_assessment['pack_assignment_changes'] == []
    assert source_assessment['all_98_execution_contexts_and_316_proof_specs_identical'] is True
    assert source_assessment['changed_job_ids'] == [
        'biocatalyst-history', 'conviction-profile', 'flow-surface', 'ticker-news-qbus',
        'unrun-government-revenue-candidate-projection', 'unrun-government-revenue-grader']
    assert sha((ROOT / 'assess_source_refresh.py').read_bytes()) == '42ab06944f365332ae460fd1eb766d6c88854f05b0f29c52d492b95f75c6e454'
    assert review['identity']['subject_head_sha'] == 'cbcc5ee143400af162a252e4faac0f06c7157e37'
    assert review['identity']['workflow_run_id'] == '37949036732'
    assert local_proof['all_53_accepted_code_pins_match'] is True
    assert local_proof['denominators']['owner_paths_byte_identical_to_prior_and_integration'] == 71
    assert owner_tree_proof['owner_enrolled_file_count'] == 71
    assert owner_tree_proof['status'] == 'ALL_71_OWNER_FILE_BYTE_IDENTITIES_BOUND_TO_ACTUAL_TESTED_TREE'
    assert owner_tree_proof['tested_commit'] == source_assessment['tested_commit']
""" + source[end:]
    source = replace_one(source,
        "    assert source_proof['verifier']['sha256'] == sha((ROOT / 'verify_tested_code_pins.py').read_bytes())\n",
        "    assert source_proof['verifier']['sha256'] == sha((ROOT / 'verify_tested_code_pins.py').read_bytes())\n"
        "    assert local_proof['verifier']['sha256'] == sha((ROOT / 'verify_local_candidate_objects.py').read_bytes())\n"
        "    assert owner_tree_proof['verifier']['sha256'] == sha((ROOT / 'verify_tested_owner_tree_bindings.py').read_bytes())\n")
    source = replace_one(source,
        "        'whole_raw_log_count': 3, 'accepted_source_byte_pin_count': 53,\n",
        "        'whole_raw_log_count': 3, 'accepted_source_byte_pin_count': 53,\n"
        "        'actual_tested_owner_file_byte_binding_count': 71,\n"
        "        'local_raw_git_object_count': 137, 'local_resolved_source_bindings': 230,\n")
    start = source.index('    replay_specs = [\n')
    end = source.index('    for script, arguments, original_name, replay_name in replay_specs:', start)
    source = source[:start] + """    replay_specs = [
        ('verify_local_candidate_objects.py', [], 'LOCAL_CANDIDATE_VERIFICATION.json',
         'ARCHIVE_REPLAY_LOCAL_CANDIDATE_VERIFICATION.json'),
        ('verify_tested_code_pins.py', [], 'SOURCE_PIN_VERIFICATION.json',
         'ARCHIVE_REPLAY_SOURCE_PIN_VERIFICATION.json'),
        ('verify_tested_owner_tree_bindings.py', [], 'TESTED_OWNER71_BINDING_VERIFICATION.json',
         'ARCHIVE_REPLAY_TESTED_OWNER71_BINDING_VERIFICATION.json'),
        ('assess_source_refresh.py', [], 'SOURCE_REFRESH_ASSESSMENT.json',
         'ARCHIVE_REPLAY_SOURCE_REFRESH_ASSESSMENT.json'),
        ('verify_refreshed_artifacts.py', ['--snapshot', review['snapshot_file']], 'CI_EVIDENCE_VERIFICATION.json',
         'ARCHIVE_REPLAY_CI_EVIDENCE_VERIFICATION.json'),
    ]
""" + source[end:]
    source = replace_one(source, "'executed_verifier_count': 3,", "'executed_verifier_count': 5,")
    source = replace_one(source,
        "        'accepted_code_pins_verified': 53, 'ci_verifier_assertions_passed': review['verification']['assertions_passed'],",
        "        'accepted_code_pins_verified': 53, 'actual_tested_owner_inputs_bound': 71,\n"
        "        'local_source_assertions_passed': local_proof['verification']['assertions_passed'],\n"
        "        'ci_verifier_assertions_passed': review['verification']['assertions_passed'],")
    start = source.index("    readme = f'''")
    end = source.index("    with (DESTINATION / 'ARCHIVE_README.md').open", start)
    source = source[:start] + """    readme = f'''# PR8711 refreshed candidate v2 CI evidence archive

**Complete observed CI evidence for candidate `cbcc5ee143400af162a252e4faac0f06c7157e37`. Canonical release adjudication remains with the principal.**

The frozen observation completed at **{review['observation_completed_at_utc']}**. Run **37949036732**, attempt **1**, concluded **success**. Actual tested synthetic commit: `ecd49338799e419055737a20f3fb462c4b97bdd8`. Ordered parents: `6ced30b9d69f7e5644d74f1f4648def0ac357c42` then the exact candidate head. Distinct Git tree: `cbf9097804ffa9e094ec700bfc8a044e8ed7ee8d`. The integrated upstream and initial PR base field `87b01101` are separately retained; neither substitutes for the actual tested base.

The archive preserves all **15 original artifact ZIPs and 15 exact JSON members**: plan, changed paths, **12 raw pack fragments** and final aggregate. The independent verifier accounts for **98/98 selected logical jobs and 316/316 proof steps**, all passed. It recomputes the 98 execution-context and 316 step-specification source digests and reconstructs the complete all-pass aggregate. Its logical SHA-256 is `{review['aggregate']['evidence_sha256']}`. Full final-gate JSON stdout, summary and notices match the retained aggregate. The 254 manifest jobs comprise 182 code jobs (98 selected, 84 explicitly excluded) and 72 other gate jobs; those larger sets are not test-pass denominators.

The actual current relationship owner belongs to **pack {review['owner']['pack_index']}**, with **275 passed in {review['owner']['actual_result']['seconds']}s**. The actual current differential contract gate reports **0 introduced, 0 inherited** against 6ced30. Whole raw owner, contract and final-gate logs are unchanged and have exact byte hashes and line references.

The new direct API proof verifies **53 accepted engine/lib byte pins, 1,483,905 bytes**, from 3 complete Git trees and 52 unique blobs. A separate Git-object-chain proof binds **all 71 owner inputs, 2,152,680 bytes**, to the actual tested root, using 85 already-retained local Git objects and 7 exact subtree identities. It does not claim 18 additional fresh blob downloads or a new functional review.

The frozen prepublication source proof verifies 137 raw local Git objects, 230 source bindings, all 71 owner files at prior candidate/integration/new candidate, 13 accepted upstream commits, and 22 evidence-only candidate paths. Its historical remote/CI-not-observed status remains unchanged. Later captures independently establish publication and the natural new run. The actual CI-definition comparison finds exactly six existing-job scope insertions of engine/risk_envelope.py, with no command or ID change. All 98 execution digests, 316 proof specifications and pack assignments remain identical across the actual plans. Five actual CI-law files remain byte-identical to their prior pins.

## Transfer files

| File | Bytes | SHA-256 |
|---|---:|---|
| `{ARCHIVE_NAME}` | {archive_record['bytes']} | `{archive_record['sha256']}` |
| `{MANIFEST_NAME}` | {manifest_record['bytes']} | `{manifest_record['sha256']}` |
| `ARCHIVE_VERIFICATION.json` | {verification_record['bytes']} | `{verification_record['sha256']}` |

Keep this README with those three files. The archive has **{len(rows)} regular files** totaling **{total:,} uncompressed file bytes**, under `{PREFIX}/`. The external manifest lists every relative name, byte length and SHA-256. Outer metadata, ownership, times, modes and ordering are normalized. An independent second in-memory encoding was byte-identical. Every original GitHub ZIP retains its internal metadata. No links, duplicate names, traversal entries, caches, unrelated lanes or previous already-committed archives are included. No credentials or signed redirect URLs were retained. A bounded common-pattern scan of all 3 whole logs passed without modifying them.

Entry points: `OBSERVATION_REPORT.md`, `CI_EVIDENCE_VERIFICATION.json`, `FOCUSED_OBSERVATION.json`, `ARTIFACT_INVENTORY.json`, `LOCAL_CANDIDATE_VERIFICATION.json`, `SOURCE_PIN_VERIFICATION.json`, `TESTED_OWNER71_BINDING_VERIFICATION.json`, `SOURCE_REFRESH_ASSESSMENT.json`, `READ_TIMELINE.json`, `PACKAGING_NOTES.md` and `native_read_scripts.json`.

All **{processes['managed_process_count']} observer-managed native PIDs** are reconciled. Exact scripts and process metadata are preserved. Prior partial observations and initial publication/prepublication status are preserved, not relabelled. Principal004 adjudication/checkpoint and prior 693 five-object transfer binding are retained as attributed provenance. The prior 98-file successful packet remains separate and was not replayed. The archive builder's original source, exact diff and derivation record are included.

Every manifest entry was safely extracted and independently verified. All **five unchanged current-generation preserved-data verifiers** then ran from the extracted layout with fresh output names. The source assessment replay is byte-identical. The local-source, 53-pin, 71-owner and final CI reports match their originals except created_at_utc; all **{review['verification']['assertions_passed']:,} CI assertions** passed again. The 5 new replay outputs are separately accounted for and are not inserted into the archive. All original and extracted preserved bytes remain unchanged; original input mtimes are also unchanged.

From the extracted evidence directory, with Python 3 and PyYAML:

```sh
PYTHONDONTWRITEBYTECODE=1 python -B verify_local_candidate_objects.py --output FRESH_LOCAL_CANDIDATE_VERIFICATION.json
PYTHONDONTWRITEBYTECODE=1 python -B verify_tested_code_pins.py --output FRESH_SOURCE_PIN_VERIFICATION.json
PYTHONDONTWRITEBYTECODE=1 python -B verify_tested_owner_tree_bindings.py --output FRESH_TESTED_OWNER71_BINDING_VERIFICATION.json
PYTHONDONTWRITEBYTECODE=1 python -B assess_source_refresh.py --output FRESH_SOURCE_REFRESH_ASSESSMENT.json
PYTHONDONTWRITEBYTECODE=1 python -B verify_refreshed_artifacts.py --snapshot {review['snapshot_file']} --output FRESH_CI_EVIDENCE_VERIFICATION.json
```

Use fresh output names. These operations use preserved data only, without GitHub/network, native operations, Git mutation, repository application imports or application tests. Final replay uses the selected final snapshot and all captures. Earlier partial snapshots retain their original observation bounds.

The exact-head census keeps the observed ci-authority/codex/merge-queue-pilot failure explicit. This packet does not waive any check or determine current policy binding. Root retains protected procedures, current main freshness and holds, expected-head merge, accepted-source verification and the actual native C01 witness. No rights, history, factual, Graph1, production or predictive promotion is made.
'''
""" + source[end:]
    source = replace_one(source, "'all_three_unchanged_verifier_replays_passed': True,",
                         "'all_five_unchanged_verifier_replays_passed': True,")
    compile(source, 'build_durable_archive.py', 'exec')
    outputs = [write('build_durable_archive.py', source.encode())]
    diff = ''.join(difflib.unified_diff(raw.decode().splitlines(keepends=True),
                                      source.splitlines(keepends=True),
                                      fromfile=ORIGIN, tofile='build_durable_archive.py'))
    outputs.append(write('ARCHIVE_BUILDER_REVISION.diff', diff.encode()))
    result = {
        'schema': 'gmi.pr8711.refresh2_archive_builder_derivation/v1',
        'origin': {'path': ORIGIN, 'bytes': len(raw), 'sha256': sha(raw)},
        'derived': outputs[0], 'exact_source_diff': outputs[1],
        'changes': [
            'Bind current cbcc/run 37949036732/testedecd/base6ced generation and separate upstream87b.',
            'Require six scope-only changes and zero job execution, proof specification or placement changes.',
            'Require frozen local source and actual tested71-owner byte binding proofs.',
            'Replay five unchanged current-generation preserved-data verifiers with fresh output names.',
            'Current README, inventory schema and proof limits; no prior verifier executed.'],
        'preserved_algorithms': [
            'Bounded unchanged raw-log scan, explicit regular-only enumeration and file hashes.',
            'Normalized deterministic tar.gz and exact in-memory reencoding.',
            'Safe exact-member extraction and every byte hash check.',
            'Fresh preserved-data replays and comparison except created_at_utc.',
            'Unchanged original bytes/mtimes, extracted preserved bytes and explicit extra-output accounting.'],
        'compile_only': True, 'archive_execution_performed_by_deriver': False,
        'native_or_git_or_network_or_application_operations': False,
    }
    outputs.append(write('ARCHIVE_BUILDER_DERIVATION.json',
                         (json.dumps(result, indent=2, sort_keys=True) + '\n').encode()))
    print(json.dumps({'outputs': outputs, 'compile_only': True}, indent=2))


if __name__ == '__main__':
    main()
