#!/usr/bin/env python3
"""Derive the new exact-generation verifier while retaining its frozen origin."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write(name,raw):
    with (ROOT/name).open('xb') as f:
        f.write(raw)
    return {'path':name,'bytes':len(raw),'sha256':sha(raw)}


def main():
    origin=ROOT/'verifier_origin/verify_refreshed_v1_artifacts.py.txt'
    raw=origin.read_bytes()
    assert sha(raw)=='faeb5f20a0b455427a241b750935ce6c3a14c033744dd3cfe3f45e2e9688035c'
    s=raw.decode()
    for before,after in [
        ('refreshed head 693ee939','second refreshed head cbcc5ee1'),
        ('693ee939c8a28920ef9de7bc32a9f47a7ba76b82','cbcc5ee143400af162a252e4faac0f06c7157e37'),
        ('1a1f4a2db62afd5d943a86a391e104f9dad560a1','3521765204903320db76ddd84d6a43539ded8e62'),
        ('3bb1ee47939d9caa1db10a4e764365d3a2ee5b77','6ced30b9d69f7e5644d74f1f4648def0ac357c42'),
        ('7d5fd7428fa91567db755117657f856e1347c5f9','ecd49338799e419055737a20f3fb462c4b97bdd8'),
        ("RUN = '37938576895'","RUN = '37949036732'"),
        ("MANIFEST_PIN = (1249132, 'e76d0e54e8401c56016447e8542c750fae02e78c7f160943b1d6a986b8a979aa')",
         "MANIFEST_PIN = (1249336, '5cc24c46e7c4ed8b0b9525366a7069e86f546b32849c72cb8518320842d860cd')"),
        ("MANIFEST_BLOB = '07a8f2eb51f852e4da38142b00d862473889adcc'",
         "MANIFEST_BLOB = '2265e5ccc3d408d6679bdfba5ac22ab959aaaccf'"),
        ("PLAN_PIN = (95459, '869dca9067e433a7041c9dba35468bb61f21c062454a3f798f15632e41bbb6df')",
         "PLAN_PIN = (95459, '363332833fb80b962083850a17cc455bf279d33488ef1804b80ffe02888e995e')"),
        ('5545065ee276bfda077d80ab6ce243eff0142223066378eb3ed2d36ccd05d0e0',
         '40fcf0771c17114af3dd85f03a81bd2c81b55d463fcf4feeda816b073bfff5f9'),
        ('8300e2c6dc44f2afd29c6a011a5f1d6daa272bd79959a0904fe47e8e416a2cdd',
         '26766bdbca14f10ef37706adecacb586f65e183ffdd62fe1b54eb435c4fac747'),
        ("== ['42174563149254d2399e23e101baafd8b06f9b1e', BASE]", "== [PRIOR, UPSTREAM]"),
        ("'integration_ordered_parents': ['42174563149254d2399e23e101baafd8b06f9b1e', BASE]",
         "'integration_ordered_parents': [PRIOR, UPSTREAM]"),
        ("and len(evidence_commit['files']) == 13","and len(evidence_commit['files']) == 22"),
        ("and len({row['filename'] for row in evidence_commit['files']}) == 13",
         "and len({row['filename'] for row in evidence_commit['files']}) == 22"),
        ("== plan['changed_files_count'] == 137","== plan['changed_files_count'] == 158"),
        ("'changed_paths': 137","'changed_paths': 158"),
        ("'gmi.pr8711.refreshed_independent_ci_evidence_review/v1'",
         "'gmi.pr8711.refresh2_independent_ci_evidence_review/v1'"),
    ]:
        assert before in s,before
        s=s.replace(before,after)
    s=s.replace("INTEGRATION = '3521765204903320db76ddd84d6a43539ded8e62'\n",
                "INTEGRATION = '3521765204903320db76ddd84d6a43539ded8e62'\n"
                "PRIOR = '693ee939c8a28920ef9de7bc32a9f47a7ba76b82'\n"
                "UPSTREAM = '87b01101ef13aa20ded205f3a2b267b68d094def'\n")
    first=s.index('    # The prior source and plan supply structural comparisons')
    last=s.index('    # The separate preserved-data verifier independently checks',first)
    s=s[:first]+(ROOT/'verifier_source_refresh_block.py.txt').read_text()+s[last:]
    s=s.replace("'path': 'SOURCE_PIN_VERIFICATION.json', 'bytes': 17458,\n"
                "        'sha256': 'b2141ef10a9383ff9c7104617e4ebbb2b7159beefa1731c4a14712b3d52d789c'",
                "'path': 'SOURCE_PIN_VERIFICATION.json', 'bytes': 17457,\n"
                "        'sha256': '4fa42b3739aa87f8757935b74053d96b19846c0fa7eda24fa4a4c660054deef1'")
    s=s.replace("    check('owner_source_contract', planned[OWNER]['pack_index'] == 6\n",
                "    owner_pack = planned[OWNER]['pack_index']\n"
                "    check('owner_source_contract', owner_pack == refresh_assessment['owner']['current_planned_job']['pack_index']\n")
    s=s.replace("'logical_job_id': OWNER, 'pack_index': 6,", "'logical_job_id': OWNER, 'pack_index': owner_pack,")
    s=s.replace("hosted['ci-pack-6']['id']", "hosted[f'ci-pack-{owner_pack}']['id']")
    s=s.replace("'owner_definition_identical': True, 'owner_current_pack': 6,",
                "'owner_definition_identical': True, 'owner_current_pack': owner_pack,")
    s=s.replace("            role = log['role']\n",
                "            role = log['role']\n"
                "            expected_role_job = {'contract_delta': 'contract-delta', 'ci_gate': 'ci-gate', 'owner': f'ci-pack-{owner_pack}'}\n"
                "            check('log_role_matches_actual_plan_job_' + role, role in expected_role_job and log['job_name'] == expected_role_job[role])\n")
    s=s.replace("    run = snapshot['run']\n",
                "    check('source_binding_uses_actual_retained_plan', source_capture['tested_source_binding'] == 'ACTUAL_RETAINED_PLAN'\n"
                "          and source_capture['actual_base_commit']['sha'] == BASE)\n"
                "    run = snapshot['run']\n")
    s=s.replace("'prior_source_manifest': record('context/prior_04b708_legacy_jobs.yml')",
                "'prior_source_manifest': record('context/prior_7d5fd_legacy_jobs.yml')")
    s=s.replace("'prior_plan': record('context/prior_04b708_ci_plan.json')",
                "'prior_plan': record('context/prior_7d5fd_ci_plan.json')")
    s=s.replace("'prior_packet_preservation': record('PRIOR_SUCCESS_PACKET_PRESERVATION.json')",
                "'prior_packet_preservation': record('PRIOR_V1_PACKET_PRESERVATION.json'),\n"
                "                'local_source_verification': record('LOCAL_CANDIDATE_VERIFICATION.json'),\n"
                "                'ci_scope_changes': refresh_assessment['scope_changes'],\n"
                "                'actual_tested_base': BASE,\n"
                "                'discovery_pr_base_field': discovery['pr']['base']['sha'],\n"
                "                'selected_snapshot_pr_base_field': snapshot['pr']['base']['sha'],\n"
                "                'integration_upstream_distinct_from_tested_base': UPSTREAM != BASE")
    s=s.replace("           'input_receipts': [record(name) for name in dict.fromkeys([\n",
                "           'accepted_owner_input_byte_bindings': {\n"
                "                'receipt': record('TESTED_OWNER71_BINDING_VERIFICATION.json'),\n"
                "                'verifier': record('verify_tested_owner_tree_bindings.py'),\n"
                "                'owner_file_count': 71, 'owner_file_bytes': 2152680,\n"
                "                'subtree_count': 7, 'tested_commit': TESTED,\n"
                "                'tested_git_tree': tested['tree']['sha'],\n"
                "                'files': owner_tree_proof['source_files'],\n"
                "                'subtree_bindings': owner_tree_proof['subtree_bindings'],\n"
                "                'proof_limits': owner_tree_proof['proof_limits']},\n"
                "           'input_receipts': [record(name) for name in dict.fromkeys([\n")
    s=s.replace("'PRIOR_SUCCESS_PACKET_PRESERVATION.json', 'SOURCE_PIN_VERIFICATION.json',",
                "'PRIOR_V1_PACKET_PRESERVATION.json', 'SOURCE_PIN_VERIFICATION.json',\n"
                "                'LOCAL_CANDIDATE_VERIFICATION.json', 'local_git_objects_001.json',\n"
                "                'TESTED_OWNER71_BINDING_VERIFICATION.json',")
    s=s.replace('This is byte compatibility, not a new functional review or certification of the other 18 owner scope paths.',
                'A separate Git-object-chain proof binds all 71 owner input bytes, including the other 18 paths, to the actual tested tree. Neither is a new functional review.')
    s=s.replace("'The actual new plan, immutable tested commit and hosted checkout logs bind this generation to its own tested base.',",
                "'The actual new plan, immutable tested commit and hosted checkout logs bind this generation to its own tested base; stale PR base fields are retained separately.',")
    for prohibited in ['prior_04b708', 'PRIOR_SUCCESS_PACKET_PRESERVATION.json',
                       "'ci-pack-6'", "'pack_index': 6", 'len(placement_changes) == 51',
                       'changed_steps[0]', 'b2141ef10a9383ff9']:
        assert prohibited not in s,prohibited
    compile(s,'verify_refreshed_artifacts.py','exec')
    original_ast=ast.parse(raw)
    current_ast=ast.parse(s)
    old_helpers={node.name:ast.dump(node,include_attributes=False) for node in original_ast.body
                 if isinstance(node,(ast.FunctionDef,ast.ClassDef)) and node.name!='main'}
    new_helpers={node.name:ast.dump(node,include_attributes=False) for node in current_ast.body
                 if isinstance(node,(ast.FunctionDef,ast.ClassDef)) and node.name!='main'}
    assert old_helpers==new_helpers
    result=write('verify_refreshed_artifacts.py',s.encode())
    difference=write('CI_VERIFIER_REVISION.diff',''.join(difflib.unified_diff(
        raw.decode().splitlines(keepends=True),s.splitlines(keepends=True),
        fromfile='verifier_origin/verify_refreshed_v1_artifacts.py.txt',
        tofile='verify_refreshed_artifacts.py')).encode())
    description={
        'schema':'gmi.pr8711.refresh2_ci_verifier_derivation/v1',
        'origin':{'path':str(origin.relative_to(ROOT)),'bytes':len(raw),'sha256':sha(raw)},
        'current':result,'diff':difference,'unchanged_helper_ast_names':sorted(old_helpers),
        'changes':[
            'Bind exact cbcc/run37949036732/testedecd/base6ced identities and current manifest/plan pins.',
            'Distinguish actual tested base6ced from integration upstream87b and stale PR base fields.',
            'Bind actual 158 changed paths and the 22-path evidence-only candidate commit.',
            'Compare exact six scope insertions; all 98 execution digests,316 proof specs and pack assignments stay identical by actual new-plan comparison.',
            'Derive owner pack and log-role/job binding from actual current plan rather than a historical pack literal.',
            'Bind fresh 53-pin API proof plus 71-owner-file tested-tree Git-object-chain proof.',
            'Preserve local prepublication observation and old98-file packet identities without rewriting their temporal claims.',
            'Read current principal004 context as attributed provenance; canonical release remains root-owned.',
        ],
        'retained_algorithms':['Strict original ZIP/member and API inventory verification.',
            'Canonical plan digest, selected/excluded partition and source execution/spec recomputation.',
            'Fragment identity, unique job/proof order, outcome and completeness accounting.',
            'Full actual owner/contract/gate log bindings and complete all-pass aggregate reconstruction.'],
        'prior_verifiers_executed':False,'application_imports_or_tests':False,
        'native_or_git_mutations':False,'compile_and_helper_ast_comparison_passed':True,
    }
    metadata=write('VERIFIER_DERIVATION.json',(json.dumps(description,indent=2,sort_keys=True)+'\n').encode())
    print(json.dumps({'verifier':result,'diff':difference,'derivation':metadata,
                      'unchanged_helper_ast_names':sorted(old_helpers)},indent=2))


if __name__=='__main__':
    main()

