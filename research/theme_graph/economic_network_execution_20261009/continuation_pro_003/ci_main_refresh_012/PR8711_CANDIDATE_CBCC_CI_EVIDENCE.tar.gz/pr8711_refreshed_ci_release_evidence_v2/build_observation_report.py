#!/usr/bin/env python3
"""Freeze reviewable summaries only after the new exact-source CI is complete."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = 'https://github.com/mastermindx-market-intelligence/macro'
HEAD = 'cbcc5ee143400af162a252e4faac0f06c7157e37'
TESTED = 'ecd49338799e419055737a20f3fb462c4b97bdd8'
BASE = '6ced30b9d69f7e5644d74f1f4648def0ac357c42'
UPSTREAM = '87b01101ef13aa20ded205f3a2b267b68d094def'


def load(name):
    return json.loads((ROOT / name).read_text())


def record(name):
    raw = (ROOT / name).read_bytes()
    return {'path': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def write(name, value):
    raw = value.encode() if isinstance(value, str) else (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    with (ROOT / name).open('xb') as handle:
        handle.write(raw)
    return record(name)


def cell(value):
    return str(value).replace('|', '\\|').replace('\n', ' ')


def main():
    r = load('CI_EVIDENCE_VERIFICATION.json')
    assert r['completeness']['complete_ci_pass_evidence'] is True
    assert r['identity']['subject_head_sha'] == HEAD
    assert r['identity']['tested_tree_sha'] == TESTED and r['identity']['base_sha'] == BASE
    assert r['identity']['workflow_run_id'] == '37949036732'
    processes = load('native_read_scripts.json')
    assert processes['all_managed_processes_reconciled'] is True
    source = load('SOURCE_REFRESH_ASSESSMENT.json')
    local = load('LOCAL_CANDIDATE_VERIFICATION.json')
    tree = load('TESTED_OWNER71_BINDING_VERIFICATION.json')
    assert source['all_98_execution_contexts_and_316_proof_specs_identical'] is True
    assert source['pack_assignment_changes'] == [] and len(source['changed_job_ids']) == 6
    assert tree['owner_enrolled_file_count'] == 71
    i, n = r['identity'], r['denominators']
    owner, contract, aggregate = r['owner'], r['contract_delta'], r['aggregate']
    assert owner['pack_index'] == source['owner']['current_planned_job']['pack_index']
    assert owner['actual_result']['passed'] == 275
    assert n['observed_jobs'] == n['selected_jobs'] == 98
    assert n['observed_proof_steps'] == n['planned_proof_steps'] == 316
    assert n['changed_paths'] == 158
    assert aggregate['classifications'] == {'passed': 316}
    outputs = []
    focused = {key: r[key] for key in (
        'identity', 'candidate_parent', 'tested_commit_parents', 'tested_commit_tree_sha',
        'observation_completed_at_utc', 'disposition', 'denominators', 'completeness',
        'observed_outcomes', 'aggregate', 'owner', 'contract_delta', 'ci_gate',
        'hosted_run', 'hosted_jobs', 'exact_head_checks', 'source_refresh',
        'accepted_application_byte_pins', 'accepted_owner_input_byte_bindings', 'proof_limits', 'authority')}
    focused.update(
        schema='gmi.pr8711.refresh2_focused_observation/v1',
        full_verification=record('CI_EVIDENCE_VERIFICATION.json'),
        local_committed_source_verification=record('LOCAL_CANDIDATE_VERIFICATION.json'),
        actual_tested_owner71_binding=record('TESTED_OWNER71_BINDING_VERIFICATION.json'),
        native_processes=[{key: row[key] for key in (
            'pid', 'exit_code', 'runtime_seconds', 'purpose', 'receipt', 'reconciled')}
            for row in processes['processes']])
    outputs.append(write('FOCUSED_OBSERVATION.json', focused))
    outputs.append(write('ARTIFACT_INVENTORY.json', {
        'schema': 'gmi.pr8711.refresh2_actual_artifact_inventory/v1', 'identity': i,
        'observation_completed_at_utc': r['observation_completed_at_utc'],
        'original_zip_count': 15, 'exact_json_member_count': 15,
        'original_zip_and_member_inventory': r['artifact_inventory'],
        'fragment_inventory': r['fragment_inventory'], 'plan': r['plan']['raw'],
        'final_aggregate': aggregate, 'manifest': r['manifest'],
        'source_law_inventory': r['source_law_inventory'], 'whole_raw_logs': r['whole_log_inventory'],
        'accepted_application_byte_pins': r['accepted_application_byte_pins'],
        'accepted_owner_input_byte_bindings': r['accepted_owner_input_byte_bindings'],
        'source_refresh_assessment': record('SOURCE_REFRESH_ASSESSMENT.json'),
    }))
    timeline = []
    for path in sorted(ROOT.glob('artifact_read_*.json')):
        d = load(path.name)
        if 'run' in d and 'jobs' in d:
            timeline.append({
                'receipt': record(path.name), 'observed_at_utc': d['observed_at_utc'],
                'completed_at_utc': d['completed_at_utc'],
                'run_status': d['run']['status'], 'run_conclusion': d['run']['conclusion'],
                'run_attempt': d['run']['run_attempt'],
                'available_artifact_count': d['artifact_inventory']['total_count'],
                'jobs': [{key: job[key] for key in ('id', 'name', 'status', 'conclusion')}
                         for job in d['jobs']['jobs']]})
    outputs.append(write('READ_TIMELINE.json', {
        'schema': 'gmi.pr8711.refresh2_observation_timeline/v1', 'identity': i,
        'snapshots': timeline, 'all_earlier_observations_preserved': True,
        'initial_prepublication_preparation': record('GENERATION_PREPARATION.json'),
        'local_source_observation': record('LOCAL_CANDIDATE_VERIFICATION.json'),
        'principal_failed_publication_account': record('PUBLICATION_STATUS_PRINCIPAL_001.json'),
        'first_independent_publication_and_run_observation': record('candidate_discovery_001.json'),
    }))
    fragments = {f['pack_index']: f for f in r['fragment_inventory']}
    hosted = {j['name']: j for j in r['hosted_jobs']}
    pack_rows = '\n'.join(
        f"| {index} | {hosted[f'ci-pack-{index}']['id']} | {hosted[f'ci-pack-{index}']['conclusion']} | "
        f"{fragments[index]['logical_jobs']} | {fragments[index]['proof_steps']} |"
        for index in range(12))
    artifact_rows = '\n'.join(
        f"| {a['artifact_id']} | `{a['artifact_name']}` | {a['zip']['bytes']:,} | `{a['zip']['sha256']}` |"
        for a in r['artifact_inventory'])
    source_rows = '\n'.join(
        f"| `{s['path']}` | {s['bytes']:,} | `{s['sha256']}` |"
        for s in [r['manifest'], *r['source_law_inventory']])
    log_rows = '\n'.join(
        f"| {l['role']} | {l['job_id']} | {l['bytes']:,} | `{l['sha256']}` |"
        for l in r['whole_log_inventory'])
    check_rows = '\n'.join(
        f"| `{cell(c['name'])}` | {c['id']} | {c['status']} | {c['conclusion']} |"
        for c in r['exact_head_checks'])
    process_rows = '\n'.join(
        f"| {p['pid']} | {cell(p['purpose'])} | {p['exit_code']} | {p['runtime_seconds']} |"
        for p in processes['processes'])
    scope_rows = '\n'.join(
        f"| `{job}` | `engine/risk_envelope.py` |"
        for job in source['changed_job_ids'])
    evidence_records = [record(name) for name in (
        'CI_EVIDENCE_VERIFICATION.json', 'SOURCE_REFRESH_ASSESSMENT.json',
        'SOURCE_PIN_VERIFICATION.json', 'TESTED_OWNER71_BINDING_VERIFICATION.json',
        'LOCAL_CANDIDATE_VERIFICATION.json', 'PRIOR_V1_PACKET_PRESERVATION.json',
        'principal_context/CI_REFRESH_ADJUDICATION_004.md',
        'principal_context/CI_REFRESH_CHECKPOINT_MANIFEST_004.json')]
    evidence_rows = '\n'.join(
        f"| `{row['path']}` | {row['bytes']:,} | `{row['sha256']}` |"
        for row in evidence_records)
    report = f'''# PR8711 refreshed candidate v2: independent CI evidence

**The exact new-source CI run concluded successfully. All planned semantic evidence independently reconciles against the actual tested source.** The frozen disposition is `{r['disposition']}`. This is a bounded CI evidence conclusion. The principal retains canonical release adjudication, current freshness and holds, expected-head merge, accepted-source comparison and the actual native C01 witness.

Observation completed: **{r['observation_completed_at_utc']}**. Reviewer: `/root/ci_release_evidence`. The complete machine-readable record is `CI_EVIDENCE_VERIFICATION.json`, with **{r['verification']['assertions_passed']:,} assertions passed**. This observer read repository source as bytes, YAML and AST. It did not import or test a repository application.

## Exact candidate, actual tested merge and plan

| Binding | Actual observed value |
|---|---|
| Candidate head | `{i['subject_head_sha']}` |
| Candidate sole parent | `{r['candidate_parent']}` |
| Normal integration first parent | `693ee939c8a28920ef9de7bc32a9f47a7ba76b82` |
| Normal integration second parent | `{UPSTREAM}` |
| Run / attempt / event | `{i['workflow_run_id']}` / `1` / `{i['event']}` |
| Actual tested synthetic commit | `{i['tested_tree_sha']}` |
| Tested commit ordered first parent | `{r['tested_commit_parents'][0]}` |
| Tested commit ordered second parent | `{r['tested_commit_parents'][1]}` |
| Distinct actual Git tree object | `{r['tested_commit_tree_sha']}` |
| Plan logical SHA-256 | `{r['plan']['logical_sha256']}` |
| Changed-path canonical SHA-256 | `{r['plan']['changed_files_sha256']}` |
| Actual tested manifest Git blob | `{r['manifest']['git_blob_sha']}` |
| Hosted run status / conclusion | `{r['hosted_run']['status']}` / `{r['hosted_run']['conclusion']}` |

The retained actual plan, immutable tested commit and hosted checkout logs independently bind this run to **base `6ced30` and candidate `cbcc5ee`**. The earlier integrated upstream is `87b01101`; the initial PR metadata base field also reported `87b01101`. Those values are retained separately and are not substituted for the actual tested first parent. The workflow field named `tested_tree_sha` holds a commit SHA; this review records the distinct Git tree object separately.

Primary references: [PR8711]({REPO}/pull/8711), [exact run]({REPO}/actions/runs/{i['workflow_run_id']}), [candidate]({REPO}/commit/{HEAD}), [tested merge]({REPO}/commit/{TESTED}), [actual tested manifest]({REPO}/blob/{TESTED}/.github/ci/legacy-jobs.yml), [actual tested base]({REPO}/commit/{BASE}), and [integration upstream]({REPO}/commit/{UPSTREAM}). Retained capture receipts enumerate actual GET endpoints, Git object identities, lengths and hashes.

## Complete accounting and independent semantic reconciliation

| Evidence dimension | Observed | Exact denominator |
|---|---:|---:|
| Original artifact ZIPs | 15 | 15 |
| Exact original JSON members | 15 | 15 |
| Raw pack fragments | 12 | 12 |
| Selected logical jobs represented | 98 | 98 |
| Proof steps represented | 316 | 316 |
| Selected code jobs | 98 | 182 code jobs |
| Explicitly excluded code jobs | 84 | 182 code jobs |
| Other manifest gate jobs | 72 | 254 total manifest jobs |
| Changed paths in this plan | 158 | 158 |
| Accepted engine/lib byte pins | 53 | 53 |
| Enrolled owner-file byte identities bound to actual tested tree | 71 | 71 |

All **316 observed proof steps passed**. No planned pack, job, step, final aggregate or required actual owner/contract/final-gate log is missing. The 254 manifest jobs are not a test-pass denominator. The full 98-job selected and 84-job excluded inventories exhaust the 182 code jobs. Q07 is present and explicitly excluded; this packet does not claim that it ran.

The verifier recomputes all **98 execution-context digests** and **316 planned step specification digests** from actual tested source. It checks complete plan and changed-path digests, run/head/base/source bindings, selected/excluded and pack partitions, unique fragment jobs and ordered proof steps, outcomes and final aggregate. It does not rerun the scope-selection planner or infer semantic success from hosted job names.

| Pack | Hosted job ID | Hosted conclusion | Logical jobs | Proof steps |
|---:|---:|---|---:|---:|
{pack_rows}

The final aggregate is **`{aggregate['status']}`**, with **98 jobs**, **316 proof steps**, classification counts **`{json.dumps(aggregate['classifications'], sort_keys=True)}`**, and zero infrastructure findings. Its logical evidence SHA-256 is **`{aggregate['evidence_sha256']}`**. The verifier independently reconstructs the complete all-pass aggregate and compares the whole document. Actual final-gate JSON stdout, summary values and clear notices match the retained aggregate. This all-pass reconstruction makes no claim to validate a hypothetical non-all-pass aggregate.

## Actual current owner and differential contract results

The actual new plan places `company-relationship-candidates` in **pack {owner['pack_index']}**, hosted job **{owner['hosted_job_id']}**. The logical proof is `File, pinned-source and immutable observation replay contracts`.

```sh
{owner['command']}
```

The actual current owner log reports **{owner['actual_result']['passed']} passed in {owner['actual_result']['seconds']}s**, at line **{owner['actual_result']['line']}**. Its entire result group, whole raw log, source command, execution context and step specification bind to the current fragment and actual tested commit. Execution-context SHA-256: `{owner['job_exec_sha256']}`. Step specification SHA-256: `{owner['step_spec_sha256']}`.

The current contract-delta job **{contract['hosted']['id']}** concluded **{contract['hosted']['conclusion']}**. Its actual full log reports **{contract['actual_counts']['introduced']} introduced and {contract['actual_counts']['inherited']} inherited** findings against base `{contract['actual_counts']['base_prefix']}`, at line **{contract['actual_counts']['line']}**. The actual `--base` command, checkout and counts are verified from this run. No error line is observed in that complete contract log. The actual final CI gate enforced the current semantic and contract results.

| Whole raw log | Hosted job ID | Bytes | SHA-256 |
|---|---:|---:|---|
{log_rows}

The complete new log bodies are retained unchanged. Earlier runs' owner timings, fragments and gate results do not provide current-head execution evidence.

## What the normal source refresh changed

The independently verified normal integration commit `35217652` has ordered parents `693ee939` then `87b01101`. The candidate adds **22 evidence-only paths** under the principal continuation directory relative to that integration. Actual local raw Git tree comparison and current immutable GitHub commit comparison both retain the complete 22-path inventory.

Before publication completed, this observer read **137 immutable local Git objects**, totaling **8,685,410 raw bytes**, and verified **230 resolved source bindings**. All **71 enrolled owner files** were byte-identical at the previous candidate, normal integration and new candidate. All **53 accepted application pins**, the canonical observation suite, the owner definition and the **253 other accepted job definitions and top-level fields** were preserved against the integrated upstream. The local proof passed **{local['verification']['assertions_passed']} assertions**. Its original status, `LOCAL_COMMITTED_SOURCE_RECONCILIATION_PASS__REMOTE_AND_CI_NOT_OBSERVED`, remains frozen and accurate for that observation time. Later publication and actual CI identity are established by separate captures.

The verified accepted-upstream range contains **13 commits after `3bb1ee4`**. The CI-definition commit is `ff652de571523466dea4d4d7f9644022198c3465`, with sole parent `aee2725637d9fa66dd75ea24c4b2693b8bcf3a85`. Its sole parsed CI manifest effect is one scope insertion into each of six existing jobs:

| Existing logical job | Added scope path |
|---|---|
{scope_rows}

All prior scope paths preserve their order. There are **no command, job-ID or non-path-field changes** in that CI-definition comparison. Three complete comparisons independently establish the same six changes: the definition commit's parent to that commit, prior main `3bb1ee4` to integrated upstream `87b01101`, and prior candidate `693ee939` to current candidate `cbcc5ee`. The actual tested `ecd493` manifest is byte-identical to the current candidate's manifest. This bounded comparison is not a functional review of unrelated accepted upstream changes.

The complete current and previous manifests each have **254 jobs**. All selected/excluded inventories, **98 job execution-context digests**, **316 proof specifications**, and **all pack assignments** are identical across these actual plans. The current owner pack 6 was independently read from the new plan. No historical placement was assumed. The actual semantic reconciler, pack runner, differential contract checker, workflow and discovery law files are all byte-identical to their previously verified pins.

## Actual tested source and owner-file binding

A separate fresh GET capture retained **three complete Git trees and 52 unique Git blobs** from the actual tested tree. All **53 accepted engine/lib files**, totaling **1,483,905 bytes**, match their accepted reference pins. Raw tree/blob API response bytes and actual source byte sequences are retained losslessly. The accepted reference manifest remains checkpoint `6b58f15adae3b1d402d9993c52609d00083f1453`.

A second independent preserved-data proof binds **all 71 enrolled owner-file byte identities**, totaling **2,152,680 bytes**, to the actual tested Git tree. It reconstructs the actual GitHub root tree in Git's binary representation and verifies its object hash, then verifies the seven shared owner-subtree identities and traverses **85 already-retained local Git objects** to each enrolled file. This extends the actual tested-tree binding to the other 18 owner inputs without claiming 18 additional fresh GitHub blob downloads. The canonical observation test SHA-256 remains `a73700e639c8e97a4ff84951b48358abe63b1f5048560d03b0e40f2310ac44da`.

These proofs establish named byte identities and actual tested-tree reachability. They do not create a new functional code review, source authorship guarantee, rights decision or native accepted-source witness. The two mechanisms and full inventories are recorded separately.

| Exact actual CI source preserved as data | Bytes | SHA-256 |
|---|---:|---|
{source_rows}

## Historical proof, publication and canonical release boundary

The previous `693ee939` candidate retains its own complete successful run `37938576895`, tested at `7d5fd742` on base `3bb1ee4`. Its **98-file frozen packet** remains unchanged. This generation checked the current committed Git-blob identity and exact unchanged scratch bytes of the five transferred archive/report objects. The old archive was not replayed, rewritten or nested inside this archive.

The actual committed principal `CI_REFRESH_ADJUDICATION_004.md` and checkpoint manifest were read in full and retained. They attribute gate002's refusal to a stale protected Mastermind source pin, the atomic source reconciliation to `8d838c8d` with INDEX1.0.1 and ten unchanged companion blobs, and gate003's refusal to new `ff652` CI-definition freshness. Those refusals did not invalidate the earlier complete historical CI proof. The principal records no merge or waiver and then a normal accepted-main integration. These are principal provenance, not this observer's independent ruling on live policy.

This lane's early preparation also preserves the principal's report of the initial normal push failing: PID50875 exit1, missing promisor object with no-lazy-fetch protection retained, and remote still at `693ee939`. The principal subsequently reported ordinary supported publication using command-scoped `push.negotiate=true`, PID30522 exit0, with exact `cbcc5ee` readback. This observer did not operate or independently audit that recovery command; it independently observed the published exact candidate and its natural new run. Native process records below include only this observer's reads.

The current exact-head check census is retained in full:

| Check name | Check ID | Status | Conclusion |
|---|---:|---|---|
{check_rows}

The observed `ci-authority/codex/merge-queue-pilot` failure remains explicit. The observer grants no exclusion or waiver and makes no current required-check policy ruling. Root owns canonical protected-procedure checks, live main freshness and holds. This packet cannot authorize merge on its own.

## Complete retained artifacts, receipts and process reconciliation

| Artifact ID | Exact artifact name | Original ZIP bytes | Original ZIP SHA-256 |
|---:|---|---:|---|
{artifact_rows}

Every ZIP retains its original byte sequence and its one exact JSON member under `artifacts/<actual-id>/`. ZIP length, SHA-256, API inventory digest, unique member name, CRC, metadata, path/type safety and decoded semantic content are checked. The full artifact and selected/excluded inventories are in `ARTIFACT_INVENTORY.json` and the complete verification JSON.

| Frozen evidence entry point | Bytes | SHA-256 |
|---|---:|---|
{evidence_rows}

| Observer-managed native PID | Purpose | Exit | Runtime seconds |
|---:|---|---:|---:|
{process_rows}

All **{processes['managed_process_count']} observer-managed native processes completed and were reconciled**. Exact executed scripts and completion receipts are retained in `native_read_scripts.json`. The initial source read used immutable native Git-object reads with lazy fetching and optional locks disabled; all subsequent native acquisition was GitHub GET. This observer performed no native write, Git mutation, CI dispatch/rerun/cancellation, application import/test, policy change or merge.

## Reproducibility and limits

`VERIFIER_DERIVATION.json` and `CI_VERIFIER_REVISION.diff` record the new exact identity, source and provenance bindings. Existing pure ZIP, plan, source digest, raw fragment, full-log and all-pass aggregate verification algorithms were retained. The new verifier additionally binds the current local source reconciliation, distinct integrated upstream and actual tested base, six scope changes, 71-owner Git-object proof, prior 98-file packet transfer objects, and actual current owner-log role.

The completed deterministic archive has a separate regular-file-only manifest, verification receipt and README. It preserves every actual ZIP/member, source capture, raw Git object capture, full selected/excluded inventory, whole log, read script, partial observation and verification report. Five unchanged current-generation preserved-data verifiers are replayed from the extracted layout with fresh filenames:

```sh
PYTHONDONTWRITEBYTECODE=1 python -B verify_local_candidate_objects.py --output FRESH_LOCAL_CANDIDATE_VERIFICATION.json
PYTHONDONTWRITEBYTECODE=1 python -B verify_tested_code_pins.py --output FRESH_SOURCE_PIN_VERIFICATION.json
PYTHONDONTWRITEBYTECODE=1 python -B verify_tested_owner_tree_bindings.py --output FRESH_TESTED_OWNER71_BINDING_VERIFICATION.json
PYTHONDONTWRITEBYTECODE=1 python -B assess_source_refresh.py --output FRESH_SOURCE_REFRESH_ASSESSMENT.json
PYTHONDONTWRITEBYTECODE=1 python -B verify_refreshed_artifacts.py --snapshot {r['snapshot_file']} --output FRESH_CI_EVIDENCE_VERIFICATION.json
```

These commands read preserved evidence without Git, network, native operations or repository application imports/tests. Final replay uses the final selected snapshot and all retained transfers; historical partial reports retain their own observed denominators and are not relabelled complete.

This packet supplies no live release freshness or hold certification, merge authorization, waiver, source-rights permission, custody/authorship guarantee, historical availability, factual admission, Graph1 admission, production acceptance or predictive promotion. Functional code review, the actual accepted-source native C01 proof and broader research completion retain their existing owners.
'''
    outputs.append(write('OBSERVATION_REPORT.md', report))
    notes = '''# Refreshed candidate v2 evidence packaging notes

This independent generation binds candidate cbcc5ee143400af162a252e4faac0f06c7157e37, run 37949036732 attempt 1, actual tested merge ecd49338799e419055737a20f3fb462c4b97bdd8 and actual first parent 6ced30b9d69f7e5644d74f1f4648def0ac357c42. The integrated upstream 87b01101 and stale initial PR base field remain separately recorded. Earlier successful and failed/pending packets remain unchanged. Previous manifests and plans support structural comparison only; prior execution outcomes do not provide current-head proof.

## Preserved layout and provenance

Actual current CI source is under sources/, including sources/.github/workflows/ci.yml. The original candidate and actual tested source captures preserve exact source bodies. principal_context/ holds the actual committed principal004 adjudication and checkpoint. Each artifact uses artifacts/<actual-id>/original.zip and its original JSON member. Whole current owner, contract and final-gate logs are under logs/.

The local immutable Git-object capture retains 137 exact raw objects and 230 resolved bindings. The independent local proof's prepublication status remains frozen at its original observation time. The separate new-run capture establishes actual publication and CI identity. The 53 direct API source pins and 71-owner Git-object-chain proof remain distinct. The latter uses the independently reconstructed actual root tree and 85 already-retained local Git objects, without additional source acquisition.

PRIOR_V1_PACKET_PRESERVATION.json records the exact prior 693 packet's five transfer objects and current committed Git-blob identity. Its absolute prior scratch paths are provenance; extraction replay does not dereference them. The old98-file archive is already committed and is not recursively included or rerun. Its original SHA-256 remains 9c6baa4681447f390cb176ebbe18ae39b6362daee64884799a0fec9bf42b00ce.

## Transport, raw bytes and metadata

RDC may insert a framing line break at its 1 MiB output boundary. Each affected process record reports the exact framing reconstruction. The compact JSON was recovered by joining only those provider-added breaks; embedded raw API/source bytes, Git object lengths and hashes were subsequently verified independently. No second read or inferred source-body reconstruction supplied missing data.

Artifact ZIPs, JSON members, source bodies, raw Git objects and whole new-run logs retain exact bytes. Metadata snapshots retain full decoded JSON objects and GET length/hash receipts; this does not claim every metadata response's original serialization was retained. The fresh tree/blob source capture additionally retains the original API response bytes losslessly. Selected log excerpts are secondary, ANSI-stripped exact-line views; full raw log bodies are authoritative.

All new native log captures use the corrected ANSI sanitizer. Historical partial verifications describe their own snapshots. Later transfers are not imputed to those earlier observations, and final replay uses the final selected snapshot.

## Deterministic packaging and safe replay

The outer archive normalizes only its own metadata and ordering. Exact original GitHub ZIP bytes and their internal metadata remain unchanged. The explicit external manifest lists regular files only. There are no links, duplicate archive names, traversal entries, caches, unrelated sibling lanes or recursively embedded prior packets. Credentials and signed download redirect URLs were not retained. Whole current CI logs are included because actual full-log evidence is required; a bounded common credential/signed-URL scan is recorded without modifying them.

The current archive builder's exact predecessor is retained as inert .py.txt evidence. Its derivation and diff document generation identities, current six-scope comparison, local/71-owner proofs and five current-generation preserved-data replay entries. Prior verifiers are not executed.

All extraction uses safe normalized regular-file paths and verifies each expected length/hash. Replay uses fresh output names only under the extraction directory. The five additional replay results are separately accounted for and are not inserted into the frozen archive. Original files' hashes and mtimes and all preserved extracted bytes remain unchanged. Packaging does not import repository applications, run application tests, mutate native or Git state, rerun hosted CI, grant waivers or authorize merge.
'''
    outputs.append(write('PACKAGING_NOTES.md', notes))
    print(json.dumps({'outputs': outputs, 'disposition': r['disposition']}, indent=2))


if __name__ == '__main__':
    main()
