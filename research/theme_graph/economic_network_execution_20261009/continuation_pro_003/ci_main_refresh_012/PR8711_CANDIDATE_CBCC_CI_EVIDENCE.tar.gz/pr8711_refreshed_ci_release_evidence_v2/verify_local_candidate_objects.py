#!/usr/bin/env python3
"""Verify preserved actual local Git objects without Git, network or app execution."""
import argparse
import base64
import copy
import datetime
import difflib
import gzip
import hashlib
import json
from pathlib import Path
import re
import stat
import yaml

ROOT = Path(__file__).resolve().parent
CANDIDATE = 'cbcc5ee143400af162a252e4faac0f06c7157e37'
INTEGRATION = '3521765204903320db76ddd84d6a43539ded8e62'
UPSTREAM = '87b01101ef13aa20ded205f3a2b267b68d094def'
PRIOR = '693ee939c8a28920ef9de7bc32a9f47a7ba76b82'
PRIOR_BASE = '3bb1ee47939d9caa1db10a4e764365d3a2ee5b77'
CI_CHANGE = 'ff652de571523466dea4d4d7f9644022198c3465'
OWNER = 'company-relationship-candidates'
MANIFEST = '.github/ci/legacy-jobs.yml'
EXPECTED_SCOPE_JOBS = [
    'biocatalyst-history', 'conviction-profile', 'flow-surface', 'ticker-news-qbus',
    'unrun-government-revenue-candidate-projection', 'unrun-government-revenue-grader',
]
COMMAND = ('python -m pytest tests/test_company_relationship_candidates.py '
           'tests/test_company_pinned_relationship_candidates.py '
           'tests/test_company_relationship_review_set.py '
           'tests/test_company_relationship_observations.py -q')
LAW_PINS = {
    'scripts/ci_semantic_proof.py': '9df4b9a9a8d68f7e9aa34a8eebe99e8d17e27f2ef0560eadcc050f3130359158',
    'scripts/run_ci_pack.py': '65564916a55eb806d3d9fb0cd4e12726f05fec953f6e47ccd9240f5a141049df',
    'scripts/check_contract_delta.py': '894f4e66dd323d5b17be2fe570bfd2fcb8456f92404d464a65b5b16f5c6a278f',
    '.github/workflows/ci.yml': 'ef9cd98724e4c545e4cb55420d0a6e5c9fc36b9d4efde449416b560cd8d255a9',
    'scripts/audit_unrun_tests.py': 'e50ba44cb678761d55f1c5bb9828390bd7c21c1672760d6f52781ca194dd7d47',
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def logical(value):
    return sha(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode())


def record(relative):
    path = ROOT / relative
    assert path.is_file() and not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode)
    raw = path.read_bytes()
    return {'path': relative, 'bytes': len(raw), 'sha256': sha(raw)}


class Loader(yaml.SafeLoader):
    pass


def unique(loader, node, deep=False):
    loader.flatten_mapping(node)
    out = {}
    for key, value in loader.construct_pairs(node, deep=deep):
        assert key not in out, ('duplicate YAML key', key)
        out[key] = value
    return out


Loader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, unique)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    assert Path(args.output).name == args.output
    destination = ROOT / args.output
    assert not destination.exists(), 'Use a fresh output filename.'
    assertions = {}

    def check(name, condition):
        assert name not in assertions
        assert condition, name
        assertions[name] = True

    capture_name = 'local_git_objects_001.json'
    d = json.loads((ROOT / capture_name).read_text())
    check('capture_identity', d['schema'] == 'gmi.pr8711.refresh2_local_git_object_capture/v1'
          and d['candidate'] == CANDIDATE and d['integration'] == INTEGRATION
          and d['upstream'] == UPSTREAM and d['prior_candidate'] == PRIOR
          and d['prior_base'] == PRIOR_BASE and d['ci_definition_commit'] == CI_CHANGE)
    check('local_read_complete', d['status'] == 'LOCAL_IMMUTABLE_OBJECT_READ_COMPLETE'
          and not d['diagnostics'])
    check('no_remote_or_ci_claim', d['remote_publication'] == d['hosted_ci_run'] == 'NOT_OBSERVED')
    check('native_workspace', d['workspace'] ==
          '/Volumes/Mastermind/agent-workspaces/macro/web/gmi-economic-observations-20261009-pro-003')
    objects = {}
    inventories = []
    for row in d['objects']:
        oid, kind = row['oid'], row['kind']
        check('unique_object_' + oid, oid not in objects and re.fullmatch('[0-9a-f]{40}', oid)
              and kind in {'commit', 'tree', 'blob'} and row['encoding'] == 'gzip-base64')
        raw = gzip.decompress(base64.b64decode(row['gzip_base64'], validate=True))
        check('raw_object_' + oid, len(raw) == row['bytes'] <= 16 * 1024 * 1024
              and sha(raw) == row['sha256']
              and hashlib.sha1(kind.encode() + b' ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == oid)
        objects[oid] = (kind, raw)
        inventories.append({key: row[key] for key in ('kind', 'oid', 'bytes', 'sha256')})
    check('object_count_and_bytes', len(objects) == d['object_count'] == 137
          and sum(len(raw) for _, raw in objects.values()) == d['raw_object_bytes'] == 8685410)

    commits = {}
    trees = {}

    def commit(oid):
        if oid not in commits:
            kind, raw = objects[oid]
            assert kind == 'commit'
            headers = raw.split(b'\n\n', 1)[0].splitlines()
            roots = [line[5:].decode('ascii') for line in headers if line.startswith(b'tree ')]
            parents = [line[7:].decode('ascii') for line in headers if line.startswith(b'parent ')]
            assert len(roots) == 1
            commits[oid] = {'oid': oid, 'tree': roots[0], 'parents': parents}
        return commits[oid]

    for oid, (kind, _) in objects.items():
        if kind == 'commit':
            commit(oid)
    check('commit_metadata_reconstructed', commits == d['commits'])
    check('candidate_sole_parent', commits[CANDIDATE]['parents'] == [INTEGRATION])
    check('integration_ordered_parents', commits[INTEGRATION]['parents'] == [PRIOR, UPSTREAM])
    check('candidate_tree', commits[CANDIDATE]['tree'] == 'bd6fc812085ae66966529c39668de1f873471b76')
    check('integration_tree', commits[INTEGRATION]['tree'] == 'd4244da490987272940820ff14da515733e151cd')
    check('ci_change_single_parent', commits[CI_CHANGE]['parents'] ==
          ['aee2725637d9fa66dd75ea24c4b2693b8bcf3a85'])
    before_ci = commits[CI_CHANGE]['parents'][0]

    reachable = set()

    def walk_new(oid):
        if oid == PRIOR_BASE or oid in reachable:
            return
        assert oid in commits
        reachable.add(oid)
        for parent in commits[oid]['parents']:
            walk_new(parent)

    walk_new(UPSTREAM)
    range_ids = d['upstream_range_commit_ids']
    check('complete_13_commit_upstream_range', len(range_ids) == len(set(range_ids)) == 13
          and set(range_ids) == reachable and CI_CHANGE in reachable)
    positions = {oid: index for index, oid in enumerate(range_ids)}
    check('upstream_range_topology', all(parent == PRIOR_BASE or positions[parent] < positions[oid]
          for oid in range_ids for parent in commits[oid]['parents']))

    def tree(oid):
        if oid not in trees:
            kind, raw = objects[oid]
            assert kind == 'tree'
            index = 0
            entries = {}
            while index < len(raw):
                space = raw.index(b' ', index)
                end = raw.index(b'\0', space + 1)
                mode = raw[index:space].decode('ascii')
                name = raw[space + 1:end].decode('utf8')
                assert name and name not in {'.', '..'} and '/' not in name and '\\' not in name
                assert name not in entries and end + 21 <= len(raw)
                entries[name] = {'mode': mode, 'oid': raw[end + 1:end + 21].hex()}
                index = end + 21
            assert index == len(raw)
            trees[oid] = entries
        return trees[oid]

    def resolve(ref, path):
        parts = path.split('/')
        assert not path.startswith('/') and all(part not in {'', '.', '..'} for part in parts)
        root = commits[ref]['tree']
        for index, name in enumerate(parts):
            entry = tree(root)[name]
            if index < len(parts) - 1:
                assert entry['mode'] == '40000'
                root = entry['oid']
            else:
                assert entry['mode'] in {'100644', '100755'}
                kind, raw = objects[entry['oid']]
                assert kind == 'blob'
                return {'ref': ref, 'path': path, 'mode': entry['mode'], 'blob_oid': entry['oid'],
                        'bytes': len(raw), 'sha256': sha(raw)}

    bindings = {}
    for index, row in enumerate(d['resolved_files']):
        key = (row['ref'], row['path'])
        check('resolved_binding_' + str(index), key not in bindings and resolve(*key) == row)
        bindings[key] = row
    check('resolved_binding_count', len(bindings) == 230)
    check('complete_read_operation_count', len(d['operations']) == len(objects) + 1)
    seen_objects = set()
    range_operations = 0
    for index, operation in enumerate(d['operations']):
        check('read_operation_scope_' + str(index),
              operation['returncode'] == 0 and operation['stderr_bytes'] == 0
              and operation['stderr_sha256'] == sha(b'')
              and operation['read_only_global_arguments'] ==
              ['--no-lazy-fetch', '--no-optional-locks', '--no-replace-objects'])
        arguments = operation['arguments']
        if arguments[0] == 'cat-file':
            kind, oid = arguments[1:]
            assert oid not in seen_objects and objects[oid][0] == kind
            seen_objects.add(oid)
            raw = objects[oid][1]
        else:
            assert arguments == ['rev-list', '--reverse', '--topo-order', '--max-count=65',
                                 PRIOR_BASE + '..' + UPSTREAM]
            raw = ('\n'.join(range_ids) + '\n').encode()
            range_operations += 1
        check('read_operation_raw_' + str(index), len(raw) == operation['stdout_bytes']
              and sha(raw) == operation['stdout_sha256'])
    check('all_objects_read_once', seen_objects == set(objects) and range_operations == 1)

    manifests = {}
    raw_manifests = {}
    manifest_rows = []
    for ref in [CANDIDATE, INTEGRATION, UPSTREAM, PRIOR, PRIOR_BASE, CI_CHANGE, before_ci]:
        row = bindings[(ref, MANIFEST)]
        raw = objects[row['blob_oid']][1]
        raw_manifests[ref] = raw
        manifests[ref] = yaml.load(raw.decode('utf8'), Loader=Loader)
        manifest_rows.append(row)
        check('manifest_' + ref, len(manifests[ref]['jobs']) == 254)
    check('current_local_manifest_pin',
          bindings[(CANDIDATE, MANIFEST)]['blob_oid'] == '2265e5ccc3d408d6679bdfba5ac22ab959aaaccf'
          and len(raw_manifests[CANDIDATE]) == 1249336
          and sha(raw_manifests[CANDIDATE]) == '5cc24c46e7c4ed8b0b9525366a7069e86f546b32849c72cb8518320842d860cd')
    check('integration_manifest_exact', raw_manifests[CANDIDATE] == raw_manifests[INTEGRATION])
    check('prior_candidate_source_exact', raw_manifests[PRIOR] ==
          (ROOT / 'context/prior_7d5fd_legacy_jobs.yml').read_bytes())
    check('ci_change_is_entire_accepted_main_manifest_delta',
          raw_manifests[UPSTREAM] == raw_manifests[CI_CHANGE]
          and raw_manifests[PRIOR_BASE] == raw_manifests[before_ci])

    scope_comparisons = []
    for label, earlier, later in [
        ('definition_commit', before_ci, CI_CHANGE),
        ('accepted_main_range', PRIOR_BASE, UPSTREAM),
        ('candidate_refresh', PRIOR, CANDIDATE),
    ]:
        a, b = manifests[earlier], manifests[later]
        check(label + '_job_ids_and_top_fields', set(a['jobs']) == set(b['jobs'])
              and {key: value for key, value in a.items() if key != 'jobs'} ==
              {key: value for key, value in b.items() if key != 'jobs'})
        changed = sorted(job for job in a['jobs'] if a['jobs'][job] != b['jobs'][job])
        check(label + '_exact_six_jobs', changed == EXPECTED_SCOPE_JOBS)
        rows = []
        for job in changed:
            aa, bb = a['jobs'][job], b['jobs'][job]
            check(label + '_only_scope_insertion_' + job,
                  'engine/risk_envelope.py' not in aa['paths']
                  and bb['paths'].count('engine/risk_envelope.py') == 1
                  and [path for path in bb['paths'] if path != 'engine/risk_envelope.py'] == aa['paths']
                  and {key: value for key, value in aa.items() if key != 'paths'} ==
                  {key: value for key, value in bb.items() if key != 'paths'})
            rows.append({'logical_job_id': job, 'old_paths': aa['paths'], 'new_paths': bb['paths'],
                         'added_path': 'engine/risk_envelope.py',
                         'all_non_path_definition_fields_identical': True})
        scope_comparisons.append({'comparison': label, 'before': earlier, 'after': later, 'changes': rows})

    current, previous, upstream = manifests[CANDIDATE], manifests[PRIOR], manifests[UPSTREAM]
    owner = current['jobs'][OWNER]
    owner_paths = owner['paths']
    request = json.loads((ROOT / 'LOCAL_CANDIDATE_READ_REQUEST.json').read_text())
    check('owner_definition_unchanged', owner == previous['jobs'][OWNER])
    check('owner_71_enrollment_exact', owner_paths == request['owner_paths']
          and len(owner_paths) == len(set(owner_paths)) == 71)
    check('actual_owner_four_suite_command', owner['steps'][-1]['run'] == COMMAND)
    expected = copy.deepcopy(upstream)
    expected['jobs'][OWNER] = previous['jobs'][OWNER]
    check('all_253_other_accepted_jobs_and_top_fields_preserved', current == expected)
    owner_rows = []
    for index, path in enumerate(owner_paths):
        now = bindings[(CANDIDATE, path)]
        integration = bindings[(INTEGRATION, path)]
        before = bindings[(PRIOR, path)]
        check('owner_input_preserved_' + str(index),
              all({key: value for key, value in row.items() if key != 'ref'} ==
                  {key: value for key, value in now.items() if key != 'ref'}
                  for row in (integration, before)))
        owner_rows.append({**now, 'integration_and_prior_candidate_byte_identity': True})
    check('canonical_observation_suite_pin',
          bindings[(CANDIDATE, 'tests/test_company_relationship_observations.py')]['sha256'] ==
          'a73700e639c8e97a4ff84951b48358abe63b1f5048560d03b0e40f2310ac44da')

    pin_record = record('context/EXPECTED_53_CODE_PINS.json')
    check('accepted_reference_pin_manifest', pin_record['sha256'] ==
          'e955ec0f462369f42b0d3689360682d1a30dcbcea63bf090d935db73b2c9d293')
    pins = json.loads((ROOT / pin_record['path']).read_text())
    check('reference_revision_and_count', pins['reviewed_head'] ==
          '6b58f15adae3b1d402d9993c52609d00083f1453'
          and len(pins['files']) == len({row['path'] for row in pins['files']}) == 53
          and pins['files'] == request['pins53'])
    pin_rows = []
    for index, expected_pin in enumerate(pins['files']):
        row = bindings[(CANDIDATE, expected_pin['path'])]
        check('accepted_code_pin_' + str(index),
              row['bytes'] == expected_pin['byte_length'] and row['sha256'] == expected_pin['sha256']
              and row['path'] in owner_paths)
        pin_rows.append({**row, 'matches_accepted_reference_pin': True})
    check('all_53_code_pin_bytes', sum(row['bytes'] for row in pin_rows) == 1483905)

    law_rows = []
    for path, expected_sha in LAW_PINS.items():
        now, main_row = bindings[(CANDIDATE, path)], bindings[(UPSTREAM, path)]
        check('ci_law_preserved_' + path, now['sha256'] == main_row['sha256'] == expected_sha
              and now['blob_oid'] == main_row['blob_oid'])
        law_rows.append(now)

    changes = []

    def diff(before, after, prefix=''):
        if before == after:
            return
        a = tree(before) if before else {}
        b = tree(after) if after else {}
        for name in sorted(set(a) | set(b)):
            aa, bb = a.get(name), b.get(name)
            if aa == bb:
                continue
            path = prefix + name
            if (aa is None or aa['mode'] == '40000') and (bb is None or bb['mode'] == '40000'):
                diff(aa['oid'] if aa else None, bb['oid'] if bb else None, path + '/')
            else:
                assert aa is None or aa['mode'] in {'100644', '100755'}
                assert bb is None or bb['mode'] in {'100644', '100755'}
                changes.append({'path': path, 'before': aa, 'after': bb})

    diff(commits[INTEGRATION]['tree'], commits[CANDIDATE]['tree'])
    check('exact_22_path_evidence_commit', changes == d['candidate_commit_changes']
          and len(changes) == 22 and all(row['path'].startswith(
              'research/theme_graph/economic_network_execution_20261009/continuation_pro_003/')
              for row in changes))
    process = json.loads((ROOT / 'LOCAL_READ_PROCESS_001.json').read_text())
    check('native_process_reconciled', process['pid'] == 21862 and process['exit_code'] == 0
          and process['reconciled'] is True and process['pending'] is False)
    result = {
        'schema': 'gmi.pr8711.refresh2_local_candidate_verification/v1',
        'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'observed_at_utc': d['observed_at_utc'], 'observation_completed_at_utc': d['completed_at_utc'],
        'disposition': 'LOCAL_COMMITTED_SOURCE_RECONCILIATION_PASS__REMOTE_AND_CI_NOT_OBSERVED',
        'identity': {'candidate': CANDIDATE, 'candidate_tree': commits[CANDIDATE]['tree'],
                     'integration': INTEGRATION, 'integration_tree': commits[INTEGRATION]['tree'],
                     'integration_ordered_parents': commits[INTEGRATION]['parents'],
                     'upstream': UPSTREAM, 'prior_candidate': PRIOR, 'prior_base': PRIOR_BASE,
                     'ci_definition_commit': CI_CHANGE, 'ci_definition_parent': before_ci},
        'capture': record(capture_name), 'verifier': record(Path(__file__).name),
        'native_script': record('native_local_git_read_001.py'), 'native_process': process,
        'accepted_reference': pin_record,
        'denominators': {'raw_git_objects': len(objects), 'raw_git_object_bytes': d['raw_object_bytes'],
                         'resolved_source_bindings': len(bindings), 'accepted_upstream_commits': len(range_ids),
                         'manifest_jobs': 254, 'other_accepted_jobs_preserved': 253,
                         'changed_job_scopes': 6, 'owner_enrolled_paths': 71,
                         'owner_paths_byte_identical_to_prior_and_integration': len(owner_rows),
                         'accepted_engine_lib_pins': len(pin_rows), 'accepted_code_bytes': 1483905,
                         'candidate_evidence_commit_changed_paths': len(changes), 'ci_law_sources': 5},
        'source_object_inventory': inventories, 'commit_inventory': commits,
        'accepted_upstream_range': range_ids, 'source_binding_inventory': list(bindings.values()),
        'manifest_inventory': manifest_rows, 'scope_comparisons': scope_comparisons,
        'owner': {'logical_job_id': OWNER, 'whole_definition_unchanged': True,
                  'whole_definition': owner, 'definition_sha256': logical(owner),
                  'actual_four_suite_command': COMMAND, 'enrolled_paths': owner_rows,
                  'hosted_pack_assignment': 'NOT_OBSERVED',
                  'hosted_execution_or_test_result': 'NOT_OBSERVED'},
        'all_253_other_accepted_jobs_and_top_fields_preserved': True,
        'accepted_code_pins': pin_rows, 'all_53_accepted_code_pins_match': True,
        'ci_law_inventory': law_rows, 'candidate_commit_changes': changes,
        'raw_ci_definition_diff': ''.join(difflib.unified_diff(
            raw_manifests[before_ci].decode().splitlines(keepends=True),
            raw_manifests[CI_CHANGE].decode().splitlines(keepends=True),
            fromfile=before_ci + '/' + MANIFEST, tofile=CI_CHANGE + '/' + MANIFEST)),
        'raw_candidate_manifest_diff': ''.join(difflib.unified_diff(
            raw_manifests[PRIOR].decode().splitlines(keepends=True),
            raw_manifests[CANDIDATE].decode().splitlines(keepends=True),
            fromfile=PRIOR + '/' + MANIFEST, tofile=CANDIDATE + '/' + MANIFEST)),
        'publication_status': {'candidate_remote_publication': 'NOT_OBSERVED',
                               'new_ci_run_or_tested_commit': 'NOT_OBSERVED',
                               'separate_attributed_principal_update': record('PUBLICATION_STATUS_PRINCIPAL_001.json')},
        'verification': {'assertions_passed': len(assertions), 'assertions': assertions},
        'authority': {'local_immutable_git_reads_only': True, 'native_or_git_writes': False,
                      'network_fetch_or_github_calls': False, 'application_imports_or_tests': False,
                      'prior_verifier_rerun': False, 'workflow_dispatch_or_rerun': False, 'merge_authorized': False},
        'proof_limits': [
            'Local committed object/source compatibility only; remote publication and hosted CI are not observed.',
            '53 accepted engine/lib pins are byte identity, not a new functional review or source admission.',
            '71 enrolled owner paths are compared to the prior candidate and integration; current policy admission remains principal-owned.',
            '253 other accepted CI job definitions and top fields are preserved; no claim that those jobs ran.',
            'The 13 supplied-upstream commit graph is independently verified; broader repository functionality and data/site contents are not reviewed.',
            'No current protected-source, live hold, freshness, native C01, rights, history, fact, Graph1, production or prediction promotion.',
        ],
    }
    raw = (json.dumps(result, indent=2, sort_keys=True) + '\n').encode()
    with destination.open('xb') as handle:
        handle.write(raw)
    print(json.dumps({'path': str(destination), 'bytes': len(raw), 'sha256': sha(raw),
                      'disposition': result['disposition'], 'assertions_passed': len(assertions),
                      'denominators': result['denominators'],
                      'candidate_manifest': bindings[(CANDIDATE, MANIFEST)]}, indent=2))


if __name__ == '__main__':
    main()

