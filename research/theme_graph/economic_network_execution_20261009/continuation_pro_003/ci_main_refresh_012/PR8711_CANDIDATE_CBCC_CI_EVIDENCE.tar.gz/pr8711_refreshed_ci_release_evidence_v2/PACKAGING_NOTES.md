# Refreshed candidate v2 evidence packaging notes

This independent generation binds candidate cbcc5ee143400af162a252e4faac0f06c7157e37, run 37949036732 attempt 1, actual tested merge ecd49338799e419055737a20f3fb462c4b97bdd8 and actual first parent 6ced30b9d69f7e5644d74f1f4648def0ac357c42. The integrated upstream 87b01101 and stale initial PR base field remain separately recorded. Earlier successful and failed/pending packets remain unchanged. Previous manifests and plans support structural comparison only; prior execution outcomes do not provide current-head proof.

## Preserved layout and provenance

Actual current CI source is under sources/, including sources/.github/workflows/ci.yml. The original candidate and actual tested source captures preserve exact source bodies. principal_context/ holds the actual committed principal004 adjudication and checkpoint. Each artifact uses artifacts/<actual-id>/original.zip and its original JSON member. Whole current owner, contract and final-gate logs are under logs/.

The local immutable Git-object capture retains 137 exact raw objects and 230 resolved bindings. The independent local proof's prepublication status remains frozen at its original observation time. The separate new-run capture establishes actual publication and CI identity. The 53 direct API source pins and 71-owner Git-object-chain proof remain distinct. The latter uses the independently reconstructed actual root tree and 85 already-retained local Git objects, without additional source acquisition.

PRIOR_V1_PACKET_PRESERVATION.json records the exact prior 693 packet's five transfer objects and current committed Git-blob identity. Its absolute prior scratch paths are provenance; extraction replay does not dereference them. The old98-file archive is already committed and is not recursively included or rerun. Its original SHA-256 remains 9c6baa4681447f390cb176ebbe18ae39b6362daee64884799a0fec9bf42b00ce.

## Transport, raw bytes and metadata

RDC may insert a framing line break at its 1 MiB output boundary. Each affected process record reports the exact framing reconstruction. The compact JSON was recovered by joining only those provider-added breaks; embedded raw API/source bytes, Git object lengths and hashes were subsequently verified independently. No second read or inferred source-body reconstruction supplied missing data.

Artifact ZIPs, JSON members, source bodies, raw Git objects and whole new-run logs retain exact bytes. Metadata snapshots retain full decoded JSON objects and GET length/hash receipts; this does not claim every metadata response's original serialization was retained. The fresh tree/blob source capture additionally retains the original API response bytes losslessly. Selected log excerpts are secondary, ANSI-stripped exact-line views; full raw log bodies are authoritative.

All new native log captures use the corrected ANSI sanitizer. Historical partial verifications describe their own snapshots. Later transfers are not imputed to those earlier observations, and final replay uses the final selected snapshot.

## Deterministic packaging and safe replay

The outer archive normalizes only its own metadata and ordering. Exact original GitHub ZIP bytes and their internal metadata remain unchanged. The explicit external manifest lists regular files only. There are no links, duplicate archive names, traversal entries, caches, unrelated sibling lanes or recursively embedded prior packets. Credentials and signed download redirect URLs were not retained. Whole current CI logs are included because actual full-log evidence is required; a bounded common credential/signed-URL scan is recorded without modifying them.

The current archive builder's exact predecessor is retained as inert .py.txt evidence. Its derivation and diff document generation identities, current six-scope comparison, local/71-owner proofs and five current-generation preserved-data replay entries. Prior verifiers are not executed.

All extraction uses safe normalized regular-file paths and verifies each expected length/hash. Replay uses fresh output names only under the extraction directory. The five additional replay results are separately accounted for and are not inserted into the frozen archive. Original files' hashes and mtimes and all preserved extracted bytes remain unchanged. Packaging does not import repository applications, run application tests, mutate native or Git state, rerun hosted CI, grant waivers or authorize merge.
