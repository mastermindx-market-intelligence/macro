import pathlib,subprocess,json,hashlib,datetime,os,re
ROOT=pathlib.Path('/Volumes/Mastermind/agent-workspaces/macro/web/gmi-economic-observations-20261009-pro-003')
CACHE=pathlib.Path('/Users/chriswong/Library/Caches/Mastermind/economic-network-20261009')
HEAD='cbcc5ee143400af162a252e4faac0f06c7157e37';TIP='60bca2ae6c5085db5b5ecc932523d68d38082c59';OID='3be9023f8b347603a6973f21c152aa77ad3c1f9e'
BRANCH='sol/web-gmi-economic-observations-20261009-pro-003'
OUT=CACHE/'pro003-explicit-required-blob-fetch-009.json'
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def sha(b):return hashlib.sha256(b).hexdigest()
def run(*a,input=None):return subprocess.run(['git','--no-lazy-fetch','--no-optional-locks','-C',str(ROOT),*a],input=input,capture_output=True,env=env)
def get(*a):
 p=run(*a);assert p.returncode==0,(a,p.returncode,p.stderr.decode(errors='replace')[:300]);return p.stdout
def fid(p):
 return {'exists':False} if not p.exists() else {'exists':True,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
def gitpath(name):
 p=pathlib.Path(get('rev-parse','--git-path',name).decode().strip());return p if p.is_absolute() else ROOT/p
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert not OUT.exists()
r={'schema':'economic_network.explicit_required_blob_fetch/v1','started_at':now(),'candidate':HEAD,'accepted_target':TIP,'requested_oids':[OID],'fetch_attempted':False,'fetch_exit_code':None,'pass':False,'automatic_lazy_fetch':False,'configuration_mutation':False,'index_or_worktree_mutation_requested':False,'broad_refetch':False,'force_reset_abort':False}
exit_code=2
try:
 raw=(CACHE/'pro003-integration-refusal-reconciliation-008.json').read_bytes()
 assert len(raw)==5131746 and sha(raw)=='0d18207ebba7973c7e3d3ac2a85aab068872772b67cd4bb20b459f47b99a081b'
 rec=json.loads(raw);assert rec['pass'] is True and rec['candidate']==HEAD and rec['target']==TIP and rec['original_missing_oid']==OID
 r['reconciliation_sha256']=sha(raw)
 pb=(CACHE/'pro003-main-refresh-preflight-006.json').read_bytes();assert sha(pb)=='e3e8aa9112ccd1fd7c3ce107f83c7b2834afb6c0f5afaf8c69057de78457c6b8';pre=json.loads(pb)
 assert pre['incoming_owner_path_overlap']==[] and pre['non_data_site_changed_paths']==['reports/signal-sanity.md']
 cfg=rec['selected_git_configuration']
 assert cfg['core.sparseCheckout']=='true' and cfg['core.sparseCheckoutCone']=='true' and cfg['index.sparse']=='false' and cfg['remote.origin.promisor']=='true' and cfg['remote.origin.partialclonefilter']=='blob:none'
 for key,value in cfg.items():
  p=run('config','--get',key);assert p.returncode in [0,1]
  assert (p.stdout.decode().strip() if p.returncode==0 else None)==value
 sparse=gitpath('info/sparse-checkout');assert sparse.is_file() and not sparse.is_symlink()
 sb=sparse.read_bytes();assert len(sb)==338 and sha(sb)=='33e15130ac2f7517bbb9260b36f8ab3abb21f3028ca3bb744c1cbd23dbd5495e' and sb.decode()==rec['sparse_patterns']['text']
 lines=sb.decode().splitlines();assert lines[:2]==['/*','!/*/'] and all(re.fullmatch(r'/[A-Za-z0-9._-]+/',x) for x in lines[2:])
 roots={x[1:-1] for x in lines[2:]};assert 'reports' in roots and not {'data','site'}&roots
 changes=rec['incoming_paths_with_index_flag'];assert len(changes)==17206
 def in_cone(path):return '/' not in path or path.split('/',1)[0] in roots
 assert [x['path'] for x in changes if x['path'].split('/',1)[0] not in {'data','site'}]==['reports/signal-sanity.md']
 assert all(not in_cone(x['path']) for x in changes if x['index_flag'] is None)
 selected=[x for x in changes if in_cone(x['path']) and x['new_mode']!='000000']
 expected={'old_mode':'100644','new_mode':'100644','old_oid':'fa9804b75ad3f14bc5408a4eed2da3c4ce9ddb03','new_oid':OID,'status':'M','path':'reports/signal-sanity.md','index_flag':'H'}
 assert selected==[expected]
 assert get('rev-parse',TIP+':reports/signal-sanity.md').decode().strip()==OID
 r['selection']={'complete_incoming_path_count':len(changes),'selected_path_rows':selected,'absent_prior_index_paths':sum(x['index_flag'] is None for x in changes),'all_absent_paths_proved_outside_unchanged_cone':True,'sparse_patterns_sha256':sha(sb),'selection_method':'Complete incoming old/new path-mode-OID census plus exact simple top-level cone membership; original missing-object error independently names selected OID'}
 assert get('rev-parse','HEAD').decode().strip()==HEAD and get('branch','--show-current').decode().strip()==BRANCH
 assert not get('status','--porcelain=v1','--untracked-files=all').strip() and not get('ls-files','--others','--ignored','--exclude-standard').strip() and not get('ls-files','-u').strip()
 assert not get('diff','--cached','--raw','--no-renames').strip() and not get('diff','--raw','--no-renames').strip()
 assert all(not gitpath(x).exists() for x in ['MERGE_HEAD','MERGE_MSG','MERGE_MODE','AUTO_MERGE','index.lock','MERGE_AUTOSTASH'])
 for x in pre['source_pins']+pre['owner_pins']:
  p=ROOT/x['path'];assert p.is_file() and not p.is_symlink() and sha(p.read_bytes())==x['sha256'] and get('show',HEAD+':'+x['path'])==p.read_bytes()
 for x in pre['controls']:assert get('show',HEAD+':'+x['path'])==(ROOT/x['path']).read_bytes()
 r['immediate_preflight_53_source_71_owner_9_controls_preserved']=True
 origin=get('remote','get-url','origin').decode().strip()
 assert origin in ['https://github.com/mastermindx-market-intelligence/macro.git','https://github.com/mastermindx-market-intelligence/macro','git@github.com:mastermindx-market-intelligence/macro.git','git@github.com:mastermindx-market-intelligence/macro','ssh://git@github.com/mastermindx-market-intelligence/macro.git']
 r['approved_origin_exact_match']=True;r['origin_value_sha256']=sha(origin.encode())
 fetch_head=gitpath('FETCH_HEAD');r['fetch_head_before']=fid(fetch_head)
 r['own_branch_before']=get('rev-parse','refs/heads/'+BRANCH).decode().strip()
 args=['-c','fetch.negotiationAlgorithm=noop','fetch','origin','--no-tags','--no-write-fetch-head','--recurse-submodules=no','--filter=blob:none','--refmap=','--no-auto-maintenance','--no-write-commit-graph','--stdin']
 r['fetch_argv_after_standard_git_guards']=args;r['stdin_sha256']=sha((OID+'\n').encode());r['fetch_attempted']=True
 p=run(*args,input=(OID+'\n').encode());r['fetch_exit_code']=p.returncode;r['fetch_stdout']=p.stdout.decode(errors='replace');r['fetch_stderr']=p.stderr.decode(errors='replace')
 assert p.returncode==0
 assert get('cat-file','-t',OID).decode().strip()=='blob'
 blob=get('cat-file','blob',OID);assert hashlib.sha1(b'blob '+str(len(blob)).encode()+b'\0'+blob).hexdigest()==OID
 r['verified_local_blob']={'git_blob_sha1':OID,'byte_length':len(blob),'sha256':sha(blob),'type':'blob','read_with_lazy_fetch_disabled':True}
 assert get('rev-parse','HEAD').decode().strip()==HEAD and get('rev-parse','refs/heads/'+BRANCH).decode().strip()==r['own_branch_before']
 assert not get('status','--porcelain=v1','--untracked-files=all').strip() and not get('ls-files','--others','--ignored','--exclude-standard').strip()
 assert sparse.read_bytes()==sb
 for x in pre['source_pins']+pre['owner_pins']:assert sha((ROOT/x['path']).read_bytes())==x['sha256']
 for x in pre['controls']:assert get('show',HEAD+':'+x['path'])==(ROOT/x['path']).read_bytes()
 r['postflight_53_source_71_owner_9_controls_preserved']=True
 r['fetch_head_after']=fid(fetch_head);assert r['fetch_head_after']==r['fetch_head_before']
 r['workspace_and_own_ref_unchanged']=True;r['pass']=True;exit_code=0
except BaseException as exc:
 r['error_type']=type(exc).__name__;r['error_detail']='Bounded explicit action or validation failed; exact fetch stdout/stderr retained when attempted. Reconcile actual effects before another action.'
finally:
 r['finished_at']=now()
 b=(json.dumps(r,indent=2,sort_keys=True)+'\n').encode()
 with OUT.open('xb') as f:f.write(b)
 print(json.dumps({k:r.get(k) for k in ['pass','fetch_attempted','fetch_exit_code','selection','approved_origin_exact_match','verified_local_blob','workspace_and_own_ref_unchanged','error_type','fetch_stdout','fetch_stderr']}|{'receipt_path':str(OUT),'receipt_bytes':len(b),'receipt_sha256':sha(b)}),flush=True)
raise SystemExit(exit_code)
