import pathlib,subprocess,json,hashlib,datetime,os
ROOT=pathlib.Path('/Volumes/Mastermind/agent-workspaces/macro/web/gmi-economic-observations-20261009-pro-003');CACHE=pathlib.Path('/Users/chriswong/Library/Caches/Mastermind/economic-network-20261009')
HEAD='cbcc5ee143400af162a252e4faac0f06c7157e37';TIP='60bca2ae6c5085db5b5ecc932523d68d38082c59';BRANCH='sol/web-gmi-economic-observations-20261009-pro-003'
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
OUT=CACHE/'pro003-main-refresh-integration-011.json';assert not OUT.exists()
def sha(b):return hashlib.sha256(b).hexdigest()
def run(*a):return subprocess.run(['git','--no-lazy-fetch','--no-optional-locks','-C',str(ROOT),*a],capture_output=True,env=env)
def get(*a):
 p=run(*a);assert p.returncode==0,(a,p.returncode,p.stderr.decode(errors='replace')[:500]);return p.stdout
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
b=(CACHE/'pro003-main-refresh-preflight-006.json').read_bytes();assert len(b)==916286 and sha(b)=='e3e8aa9112ccd1fd7c3ce107f83c7b2834afb6c0f5afaf8c69057de78457c6b8'
pre=json.loads(b);assert pre['status']=='PREFLIGHT_COMPLETE_AWAITING_SOURCE_REVIEW' and pre['fetched_main']==TIP
assert pre['incoming_owner_path_overlap']==[] and pre['non_data_site_changed_paths']==['reports/signal-sanity.md']
assert all(x['same'] for x in pre['controls'])
assert get('rev-parse','HEAD').decode().strip()==HEAD and get('branch','--show-current').decode().strip()==BRANCH
assert not get('status','--porcelain=v1','--untracked-files=all').strip() and not get('ls-files','--others','--ignored','--exclude-standard').strip()
assert get('ls-remote','--exit-code','origin','refs/heads/'+BRANCH).decode().split()[0]==HEAD
assert run('merge-base','--is-ancestor',pre['old_integrated_main'],TIP).returncode==0
for row in pre['owner_pins']:
 assert sha((ROOT/row['path']).read_bytes())==row['sha256']
for row in pre['controls']:
 assert sha(get('show',TIP+':'+row['path']))==row['new_sha256']
fb=(CACHE/'pro003-explicit-required-blob-fetch-010.json').read_bytes();assert len(fb)==2902 and sha(fb)=='cdd3c6c9ea3c5dcd6e585d4cdb7639a236ac52738b486c9d79a37441358c94ae'
fr=json.loads(fb);assert fr['pass'] is True and fr['fetch_exit_code']==0 and fr['requested_oids']==['3be9023f8b347603a6973f21c152aa77ad3c1f9e'] and fr['workspace_and_own_ref_unchanged'] is True
assert get('cat-file','-t','3be9023f8b347603a6973f21c152aa77ad3c1f9e').decode().strip()=='blob'
assert sha(get('cat-file','blob','3be9023f8b347603a6973f21c152aa77ad3c1f9e'))=='379eb0659e6db4cd182894a35dc7530dca55c119b5fd7773b77e1bcecbf21c37'
r={'schema':'economic_network.normal_main_integration/v4','started_at':now(),'preflight_receipt_sha256':sha(b),'candidate_before':HEAD,'accepted_upstream':TIP,'merge_method':'normal_no_ff_no_edit_no_stat','source_changes_reviewed':['reports/signal-sanity.md'],'protected_source_reconciled':pre['protected_source'],'expected_file_list_truncation_refusal_preserved':True,'ci_definitions_changed':False,'native_275_suite_repeated':False,'force_reset_abort_or_policy_override':False,'prior_failed_integration_receipt_sha256':'23d2841738a1d34f0119709779fd4b244dc253a1b74aba695f5c33917519771a','explicit_required_blob_fetch_receipt_sha256':sha(fb),'complete_terminal_reconciliation_sha256':'0d18207ebba7973c7e3d3ac2a85aab068872772b67cd4bb20b459f47b99a081b'}
p=run('merge','--no-ff','--no-edit','--no-stat',TIP);after=get('rev-parse','HEAD').decode().strip()
r.update({'merge_exit_code':p.returncode,'stdout':p.stdout.decode(errors='replace'),'stderr':p.stderr.decode(errors='replace'),'head_after':after,'parents':get('rev-list','--parents','-n','1','HEAD').decode().split(),'status_after':get('status','--porcelain=v1','--untracked-files=all').decode(),'ignored_after':get('ls-files','--others','--ignored','--exclude-standard').decode()})
if p.returncode==0:
 r['all_53_source_pins_preserved']=all(sha((ROOT/x['path']).read_bytes())==x['sha256'] and get('show',after+':'+x['path'])==(ROOT/x['path']).read_bytes() for x in pre['source_pins'])
 r['all_71_owner_pins_preserved']=all(sha((ROOT/x['path']).read_bytes())==x['sha256'] and get('show',after+':'+x['path'])==(ROOT/x['path']).read_bytes() for x in pre['owner_pins'])
 r['all_existing_control_bytes_preserved']=all(get('show',HEAD+':'+x['path'])==(ROOT/x['path']).read_bytes() for x in pre['controls'])
 r['pass']=r['parents']==[after,HEAD,TIP] and not r['status_after'] and not r['ignored_after'] and r['all_53_source_pins_preserved'] and r['all_71_owner_pins_preserved'] and r['all_existing_control_bytes_preserved']
else:r['pass']=False
r['finished_at']=now();rb=(json.dumps(r,indent=2,sort_keys=True)+'\n').encode()
with OUT.open('xb') as f:f.write(rb)
print(json.dumps({k:r.get(k) for k in ['pass','merge_exit_code','head_after','parents','status_after','ignored_after','all_53_source_pins_preserved','all_71_owner_pins_preserved','all_existing_control_bytes_preserved']}|{'receipt_sha256':sha(rb),'receipt_bytes':len(rb)}))
raise SystemExit(0 if r['pass'] else 2)
