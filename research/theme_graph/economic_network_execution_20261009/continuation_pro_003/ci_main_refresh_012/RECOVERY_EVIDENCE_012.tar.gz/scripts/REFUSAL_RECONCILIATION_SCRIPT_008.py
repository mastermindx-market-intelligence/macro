import pathlib,subprocess,json,hashlib,datetime,os,stat
ROOT=pathlib.Path('/Volumes/Mastermind/agent-workspaces/macro/web/gmi-economic-observations-20261009-pro-003')
CACHE=pathlib.Path('/Users/chriswong/Library/Caches/Mastermind/economic-network-20261009')
HEAD='cbcc5ee143400af162a252e4faac0f06c7157e37';TIP='60bca2ae6c5085db5b5ecc932523d68d38082c59';OLD='87b01101ef13aa20ded205f3a2b267b68d094def';MISSING='3be9023f8b347603a6973f21c152aa77ad3c1f9e'
OUT=CACHE/'pro003-integration-refusal-reconciliation-008.json'
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def sha(b):return hashlib.sha256(b).hexdigest()
def run(*a,input=None):return subprocess.run(['git','--no-lazy-fetch','--no-optional-locks','-C',str(ROOT),*a],input=input,capture_output=True,env=env)
def get(*a):
 p=run(*a);assert p.returncode==0,(a,p.returncode,p.stderr.decode(errors='replace')[:300]);return p.stdout
assert not OUT.exists()
raw=(CACHE/'pro003-main-refresh-integration-006.json').read_bytes();assert len(raw)==1222 and sha(raw)=='23d2841738a1d34f0119709779fd4b244dc253a1b74aba695f5c33917519771a'
old=json.loads(raw);assert old['merge_exit_code']==128 and old['head_after']==HEAD and MISSING in old['stderr']
pre=json.loads((CACHE/'pro003-main-refresh-preflight-006.json').read_bytes())
r={'schema':'economic_network.merge_refusal_reconciliation/v1','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'prior_result_sha256':sha(raw),'original_native_parent_pid':36227,'original_git_pid':36293,'original_missing_oid':MISSING,'candidate':HEAD,'target':TIP,'git_mutation':False,'prior_readonly_inspector_007':'PID18241 exit1 after all reads at JSON serialization (mixed None/string map keys); no receipt was written; original failure preserved'}
r['head']=get('rev-parse','HEAD').decode().strip();assert r['head']==HEAD
r['branch']=get('branch','--show-current').decode().strip();assert r['branch']=='sol/web-gmi-economic-observations-20261009-pro-003'
r['status']=get('status','--porcelain=v1','--untracked-files=all').decode();r['ignored']=get('ls-files','--others','--ignored','--exclude-standard').decode()
r['unmerged_index']=get('ls-files','-u').decode()
r['head_tree']=get('rev-parse','HEAD^{tree}').decode().strip()
r['cached_diff']=get('diff','--cached','--raw','--no-renames','--no-abbrev').decode()
r['worktree_diff']=get('diff','--raw','--no-renames','--no-abbrev').decode()
r['git_state_files']={}
for name in ['MERGE_HEAD','MERGE_MSG','MERGE_MODE','AUTO_MERGE','index.lock','MERGE_AUTOSTASH']:
 p=pathlib.Path(get('rev-parse','--git-path',name).decode().strip())
 if not p.is_absolute():p=ROOT/p
 r['git_state_files'][name]={'exists':p.exists(),'symlink':p.is_symlink()}
 if p.is_file() and not p.is_symlink() and p.stat().st_size<1024*1024:r['git_state_files'][name].update({'byte_length':p.stat().st_size,'sha256':sha(p.read_bytes())})
r['source_pin_checks']=[]
for x in pre['source_pins']:
 p=ROOT/x['path'];ok=p.is_file() and not p.is_symlink() and sha(p.read_bytes())==x['sha256'] and get('show',HEAD+':'+x['path'])==p.read_bytes()
 r['source_pin_checks'].append({'path':x['path'],'same':ok})
r['owner_pin_checks']=[]
for x in pre['owner_pins']:
 p=ROOT/x['path'];ok=p.is_file() and not p.is_symlink() and sha(p.read_bytes())==x['sha256'] and get('show',HEAD+':'+x['path'])==p.read_bytes()
 r['owner_pin_checks'].append({'path':x['path'],'same':ok})
r['control_checks']=[]
for x in pre['controls']:
 p=ROOT/x['path'];r['control_checks'].append({'path':x['path'],'same':get('show',HEAD+':'+x['path'])==p.read_bytes()})
r['selected_git_configuration']={}
for name in ['core.sparseCheckout','core.sparseCheckoutCone','index.sparse','extensions.partialClone','remote.origin.promisor','remote.origin.partialclonefilter']:
 p=run('config','--get',name);assert p.returncode in [0,1];r['selected_git_configuration'][name]=p.stdout.decode().strip() if p.returncode==0 else None
sp=pathlib.Path(get('rev-parse','--git-path','info/sparse-checkout').decode().strip())
if not sp.is_absolute():sp=ROOT/sp
r['sparse_patterns']={'exists':sp.exists()}
if sp.exists():
 assert sp.is_file() and not sp.is_symlink() and sp.stat().st_size<65536
 sb=sp.read_bytes();r['sparse_patterns'].update({'text':sb.decode(),'byte_length':len(sb),'sha256':sha(sb)})
chunks=get('diff-tree','-r','--no-commit-id','--raw','--no-renames','--no-abbrev','-z',OLD,TIP).split(b'\0');assert chunks[-1]==b'';chunks.pop();assert len(chunks)%2==0
changes=[]
for i in range(0,len(chunks),2):
 meta=chunks[i].decode().split();path=chunks[i+1].decode();assert len(meta)==5
 changes.append({'old_mode':meta[0][1:],'new_mode':meta[1],'old_oid':meta[2],'new_oid':meta[3],'status':meta[4],'path':path})
r['incoming_change_count']=len(changes)
r['missing_oid_path_matches']=[x for x in changes if x['new_oid']==MISSING or x['old_oid']==MISSING]
index={}
for line in get('ls-files','-t','-z').split(b'\0'):
 if line:index[line[2:].decode()]=line[:1].decode()
r['incoming_paths_with_index_flag']=[dict(x,index_flag=index.get(x['path'])) for x in changes]
r['incoming_index_flag_counts']={('ABSENT_FROM_PRIOR_INDEX' if k is None else k):sum(index.get(x['path'])==k for x in changes) for k in sorted(set(index.get(x['path']) for x in changes),key=str)}
r['all_53_source_pins_preserved']=len(r['source_pin_checks'])==53 and all(x['same'] for x in r['source_pin_checks'])
r['all_71_owner_pins_preserved']=len(r['owner_pin_checks'])==71 and all(x['same'] for x in r['owner_pin_checks'])
r['all_controls_preserved']=all(x['same'] for x in r['control_checks'])
r['clean_index_and_worktree']=not any(r[x] for x in ['status','ignored','unmerged_index','cached_diff','worktree_diff'])
r['no_merge_head_or_lock']=not any(r['git_state_files'][x]['exists'] for x in ['MERGE_HEAD','index.lock','MERGE_AUTOSTASH'])
r['pass']=all(r[x] for x in ['all_53_source_pins_preserved','all_71_owner_pins_preserved','all_controls_preserved','clean_index_and_worktree','no_merge_head_or_lock'])
r['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
b=(json.dumps(r,indent=2,sort_keys=True)+'\n').encode()
with OUT.open('xb') as f:f.write(b)
print(json.dumps({k:r[k] for k in ['pass','head','status','ignored','unmerged_index','cached_diff','worktree_diff','git_state_files','selected_git_configuration','sparse_patterns','incoming_change_count','missing_oid_path_matches','incoming_index_flag_counts','all_53_source_pins_preserved','all_71_owner_pins_preserved','all_controls_preserved','clean_index_and_worktree','no_merge_head_or_lock']}|{'receipt_path':str(OUT),'receipt_bytes':len(b),'receipt_sha256':sha(b)}),flush=True)
raise SystemExit(0 if r['pass'] else 2)
