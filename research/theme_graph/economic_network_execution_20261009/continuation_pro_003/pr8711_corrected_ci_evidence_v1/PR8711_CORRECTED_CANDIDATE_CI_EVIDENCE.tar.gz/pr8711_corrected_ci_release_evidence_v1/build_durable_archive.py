#!/usr/bin/env python3
"""Deterministic scratch-only archive and unchanged preserved-data replays.

No network, Git, native device operation, repository imports or application
tests. Only the two already-owned preserved-data verifiers are executed.
"""
import datetime
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parent
DESTINATION = ROOT / 'durable_archive'
PREFIX = 'pr8711_corrected_ci_release_evidence_v1'
ARCHIVE_NAME = 'PR8711_CORRECTED_CANDIDATE_CI_EVIDENCE.tar.gz'
MANIFEST_NAME = 'ARCHIVE_MANIFEST.json'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def safe(name):
    assert type(name) is str and name and not name.startswith('/') and '\\' not in name
    assert all(part not in {'', '.', '..'} for part in name.split('/'))
    assert str(PurePosixPath(name)) == name
    return name


def record(path):
    raw = path.read_bytes()
    return {'name': path.name, 'bytes': len(raw), 'sha256': sha(raw)}


def dump(path, value):
    raw = (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + '\n').encode()
    with path.open('xb') as handle:
        handle.write(raw)
    return record(path)


def load(path):
    return json.loads(path.read_text())


def main():
    assert not DESTINATION.exists(), 'Do not overwrite a frozen archive.'
    review = load(ROOT / 'CI_EVIDENCE_VERIFICATION.json')
    source_proof = load(ROOT / 'SOURCE_PIN_VERIFICATION.json')
    assert review['identity']['subject_head_sha'] == '42174563149254d2399e23e101baafd8b06f9b1e'
    assert review['identity']['workflow_run_id'] == '37932039980'
    assert review['completeness']['complete_ci_pass_evidence'] is True
    assert review['denominators']['observed_retained_artifacts'] == 15
    assert review['denominators']['observed_fragments'] == 12
    assert review['denominators']['observed_jobs'] == 98
    assert review['denominators']['observed_proof_steps'] == 316
    assert review['aggregate']['classifications'] == {'passed': 316}
    assert source_proof['all_matches'] is True and source_proof['pinned_file_count'] == 53
    assert load(ROOT / 'native_read_scripts.json')['all_managed_processes_reconciled'] is True
    required_logs = {row['path']: row for row in review['whole_log_inventory']}
    assert len(required_logs) == 3

    # Reproduce the bounded exact raw-log packaging scan. False positives would
    # stop packaging for inspection; this does not alter any retained log.
    patterns = {
        'signed_s3_query': rb'(?i)[?&]X-Amz-(?:Signature|Credential)=',
        'signed_azure_query': rb'(?i)https?://[^\s"<>]*[?&]sig=',
        'github_pat': rb'github_pat_[A-Za-z0-9_]{40,}',
        'github_token': rb'gh[pousr]_[A-Za-z0-9]{30,}',
        'private_key_header': rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
    }
    for relative, row in required_logs.items():
        raw = (ROOT / relative).read_bytes()
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
        assert all(not re.search(pattern, raw) for pattern in patterns.values())

    rows = []
    original_mtimes = {}
    for current, directories, files in os.walk(ROOT, followlinks=False):
        current = Path(current)
        for name in directories:
            node = current / name
            assert not node.is_symlink() and stat.S_ISDIR(node.lstat().st_mode), str(node)
            assert name not in {'__pycache__', '.git', '.pytest_cache', '.mypy_cache', '.ruff_cache'}, str(node)
        for name in files:
            node = current / name
            assert not node.is_symlink() and stat.S_ISREG(node.lstat().st_mode), str(node)
            relative = safe(node.relative_to(ROOT).as_posix())
            assert not relative.endswith(('.pyc', '.pyo')), relative
            if relative.endswith('.log'):
                assert relative in required_logs, relative
            raw = node.read_bytes()
            assert len(raw) <= 16 * 1024 * 1024
            rows.append({'archive_name': safe(PREFIX + '/' + relative), 'source_relative_path': relative,
                         'bytes': len(raw), 'sha256': sha(raw)})
            original_mtimes[relative] = node.stat().st_mtime_ns
    rows.sort(key=lambda row: row['archive_name'])
    assert len(rows) == len({row['archive_name'] for row in rows})
    total = sum(row['bytes'] for row in rows)
    assert len(rows) < 512 and total <= 64 * 1024 * 1024
    relative_names = {row['source_relative_path'] for row in rows}
    required_artifact_files = set()
    for artifact in review['artifact_inventory']:
        required_artifact_files.add(artifact['zip']['path'])
        assert len(artifact['members']) == 1
        required_artifact_files.add(artifact['members'][0]['path'])
    actual_artifact_files = {name for name in relative_names if name.startswith('artifacts/')}
    assert len(required_artifact_files) == 30 and actual_artifact_files == required_artifact_files
    assert sum(name.endswith('/original.zip') for name in actual_artifact_files) == 15
    assert sum(name.endswith('.json') for name in actual_artifact_files) == 15
    assert review['verification']['verifier']['sha256'] == sha((ROOT / 'verify_corrected_artifacts.py').read_bytes())
    assert source_proof['verifier']['sha256'] == sha((ROOT / 'verify_tested_code_pins.py').read_bytes())

    DESTINATION.mkdir()
    manifest = {
        'schema': 'gmi.pr8711.corrected_deterministic_evidence_archive_manifest/v1',
        'archive_name': ARCHIVE_NAME, 'archive_prefix': PREFIX,
        'identity': review['identity'], 'attempt': 1,
        'frozen_observation_completed_at_utc': review['observation_completed_at_utc'],
        'disposition': review['disposition'],
        'regular_file_count': len(rows), 'uncompressed_file_bytes': total, 'entries': rows,
        'actual_artifact_zip_count': 15, 'actual_artifact_json_member_count': 15,
        'whole_raw_log_count': 3, 'accepted_source_byte_pin_count': 53,
        'normalized_metadata': {'archive_format': 'POSIX pax tar in gzip',
            'gzip_mtime': 0, 'gzip_filename': '', 'tar_member_mtime': 0,
            'uid': 0, 'gid': 0, 'uname': '', 'gname': '', 'mode_octal': '0644',
            'entry_order': 'archive-name lexical'},
        'explicit_exclusions': ['durable_archive outputs created after input enumeration',
            'credentials and signed artifact redirect URLs were not retained',
            'caches, unrelated sibling lanes and prior already-committed failed-candidate archive'],
        'manifest_is_external': True,
    }
    manifest_record = dump(DESTINATION / MANIFEST_NAME, manifest)

    def build_archive(destination):
        with gzip.GzipFile(filename='', fileobj=destination, mode='wb', compresslevel=9, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as archive:
                for row in rows:
                    raw = (ROOT / row['source_relative_path']).read_bytes()
                    assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
                    info = tarfile.TarInfo(row['archive_name'])
                    info.type = tarfile.REGTYPE
                    info.size = len(raw)
                    info.mode = 0o644
                    info.uid = info.gid = info.mtime = 0
                    info.uname = info.gname = ''
                    archive.addfile(info, io.BytesIO(raw))

    archive_path = DESTINATION / ARCHIVE_NAME
    with archive_path.open('xb') as handle:
        build_archive(handle)
    archive_record = record(archive_path)
    second_encoding = io.BytesIO()
    build_archive(second_encoding)
    assert second_encoding.getvalue() == archive_path.read_bytes()

    extracted = DESTINATION / 'verification_extract'
    extracted.mkdir()
    expected = {row['archive_name']: row for row in rows}
    with tarfile.open(archive_path, 'r:gz') as archive:
        members = archive.getmembers()
        assert len(members) == len(rows)
        assert [member.name for member in members] == [row['archive_name'] for row in rows]
        assert len({member.name for member in members}) == len(rows)
        for member in members:
            safe(member.name)
            assert member.name in expected and member.isreg() and not member.issym() and not member.islnk()
            assert member.mode == 0o644 and member.uid == member.gid == member.mtime == 0
            assert member.uname == member.gname == '' and set(member.pax_headers).issubset({'path'})
            raw = archive.extractfile(member).read()
            row = expected[member.name]
            assert len(raw) == member.size == row['bytes'] and sha(raw) == row['sha256']
            target = extracted / member.name
            assert target.is_relative_to(extracted)
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as handle:
                handle.write(raw)
            assert target.read_bytes() == raw
    actual_names = sorted(path.relative_to(extracted).as_posix() for path in extracted.rglob('*') if path.is_file())
    assert actual_names == sorted(expected)
    extracted_root = extracted / PREFIX

    replay_records = []
    replay_specs = [
        ('verify_tested_code_pins.py', [], 'SOURCE_PIN_VERIFICATION.json', 'ARCHIVE_REPLAY_SOURCE_PIN_VERIFICATION.json'),
        ('verify_corrected_artifacts.py', ['--snapshot', review['snapshot_file']], 'CI_EVIDENCE_VERIFICATION.json',
         'ARCHIVE_REPLAY_CI_EVIDENCE_VERIFICATION.json'),
    ]
    for script, arguments, original_name, replay_name in replay_specs:
        command = [sys.executable, '-B', str(extracted_root / script), *arguments, '--output', replay_name]
        process = subprocess.run(command, cwd=extracted_root, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                 timeout=60, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
        assert process.returncode == 0, process.stderr.decode('utf8', 'replace')[:2000]
        original = load(ROOT / original_name)
        replay_path = extracted_root / replay_name
        replay = load(replay_path)
        assert {k: v for k, v in original.items() if k != 'created_at_utc'} == {
            k: v for k, v in replay.items() if k != 'created_at_utc'}
        replay_records.append({'relative_command': ['python', '-B', PREFIX + '/' + script,
                                                   *arguments, '--output', replay_name],
                               'exit_code': process.returncode, 'stdout_bytes': len(process.stdout),
                               'stdout_sha256': sha(process.stdout), 'stderr_bytes': len(process.stderr),
                               'stderr_sha256': sha(process.stderr),
                               'output': {'archive_relative_path': PREFIX + '/' + replay_name,
                                          **record(replay_path)},
                               'matches_original_except_created_at_utc': True,
                               'original_preserved_report': PREFIX + '/' + original_name})
    for row in rows:
        for node in (ROOT / row['source_relative_path'], extracted / row['archive_name']):
            assert not node.is_symlink() and stat.S_ISREG(node.lstat().st_mode)
            raw = node.read_bytes()
            assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
        assert (ROOT / row['source_relative_path']).stat().st_mtime_ns == original_mtimes[row['source_relative_path']]
    extra_outputs = [PREFIX + '/' + spec[3] for spec in replay_specs]
    after_names = sorted(path.relative_to(extracted).as_posix() for path in extracted.rglob('*') if path.is_file())
    assert after_names == sorted([*expected, *extra_outputs])
    result = {
        'schema': 'gmi.pr8711.corrected_deterministic_evidence_archive_verification/v1',
        'verified_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'archive': archive_record, 'manifest': manifest_record,
        'status': 'VERIFIED_FROZEN_CORRECTED_CANDIDATE_COMPLETE_CI_EVIDENCE',
        'identity': review['identity'], 'attempt': 1, 'disposition': review['disposition'],
        'regular_file_count': len(rows), 'uncompressed_file_bytes': total,
        'actual_artifact_zip_count': 15, 'actual_artifact_json_member_count': 15,
        'observed_fragments': 12, 'selected_jobs': 98, 'proof_steps': 316,
        'step_classifications': {'passed': 316}, 'whole_raw_log_count': 3,
        'accepted_code_pins_verified': 53, 'ci_verifier_assertions_passed': review['verification']['assertions_passed'],
        'all_manifest_entries_extracted_and_verified': True,
        'normalized_metadata_verified': True, 'unique_regular_files_only': True,
        'deterministic_reencode_byte_identical': True,
        'original_files_unchanged_after_packaging': True, 'original_file_mtimes_unchanged': True,
        'all_preserved_extracted_files_unchanged_after_verifiers': True,
        'replay_verifiers': replay_records, 'extra_extracted_outputs_accounted_for': extra_outputs,
        'authority': {'merge_authorized': False, 'policy_waiver': False, 'ci_rerun': False,
                      'native_mutation': False, 'git_mutation': False, 'application_imports_or_tests': False},
    }
    verification_record = dump(DESTINATION / 'ARCHIVE_VERIFICATION.json', result)
    readme = f'''# PR8711 corrected-candidate CI evidence archive

**Complete observed CI evidence for candidate `42174563149254d2399e23e101baafd8b06f9b1e`; no merge authorization.**

The frozen observation completed at **{review['observation_completed_at_utc']}**. Run **37932039980**, attempt **1**, concluded **success**. Actual tested synthetic commit: `04b70807e6b0a7d48091997eb405f9cc53ade9ad`; ordered parents: `40ebaebdbcd57eedaa627623f1cfd1860ff3ee3a` then the exact candidate head. Git tree: `0c5bd664aec83fe9a9d456b2f35e1e870fc0b3e8`.

The archive contains all **15 original artifact ZIPs and 15 exact JSON members**: the plan, changed paths, all **12** raw pack fragments and final semantic aggregate. The independent verifier accounts for **98/98 selected jobs** and **316/316 proof steps**, all passed. It recomputes the 98 job execution and 316 step specification source digests and reconstructs the exact complete all-pass aggregate. That aggregate’s logical SHA-256 is `{review['aggregate']['evidence_sha256']}`. The final gate’s complete JSON stdout and summary also match it exactly.

Actual new owner result: **275 passed in 9.25s**. Actual new contract gate: **0 introduced, 0 inherited**, using the actual tested base. Whole raw owner, contract-delta and final gate logs are preserved unchanged, with lengths, hashes and line references. The separate source verifier proves **53/53 accepted engine/lib byte pins**, **1,483,905 bytes**, from three complete tree responses and 52 unique blob responses at the actual tested tree. This is byte compatibility, not a new functional code review.

## Transfer files

| File | Bytes | SHA-256 |
|---|---:|---|
| `{ARCHIVE_NAME}` | {archive_record['bytes']} | `{archive_record['sha256']}` |
| `{MANIFEST_NAME}` | {manifest_record['bytes']} | `{manifest_record['sha256']}` |
| `ARCHIVE_VERIFICATION.json` | {verification_record['bytes']} | `{verification_record['sha256']}` |

Keep this README with those three files. The archive has **{len(rows)} regular files**, totaling **{total:,} uncompressed file bytes**, under `{PREFIX}/`. The external manifest explicitly enumerates every relative name, length and SHA-256. The outer archive has normalized time, ownership, modes and ordering. A second in-memory encoding was byte-identical. The original GitHub ZIPs retain their own exact original bytes and metadata. There are no links, duplicate names, traversal entries, caches, credentials or retained signed artifact redirect URLs.

Entry points: `OBSERVATION_REPORT.md`, `CI_EVIDENCE_VERIFICATION.json`, `FOCUSED_OBSERVATION.json`, `ARTIFACT_INVENTORY.json`, `SOURCE_PIN_VERIFICATION.json`, `READ_TIMELINE.json`, `PACKAGING_NOTES.md`, and `native_read_scripts.json`. Exact read scripts and all **nine** reconciled native PIDs are preserved. Historical partial observations and their exact verifier versions remain unchanged. The original failed/pending candidate packet is already committed separately and is referenced without rewriting it or attributing its results to this candidate.

Every manifest entry was safely extracted and verified. Both unchanged preserved-data verifiers then executed from the extracted layout, each using a fresh output filename. The 53-pin result and the complete CI result both matched their original preserved reports exactly apart from `created_at_utc`. All **{review['verification']['assertions_passed']:,} CI assertions** passed again. The two additional replay outputs are separately accounted for in `ARCHIVE_VERIFICATION.json` and do not alter the frozen archive. Original and extracted preserved files remained byte-identical; original input mtimes also remained unchanged.

From the extracted evidence directory, with Python 3 and PyYAML:

```sh
PYTHONDONTWRITEBYTECODE=1 python -B verify_tested_code_pins.py --output FRESH_SOURCE_PIN_VERIFICATION.json
PYTHONDONTWRITEBYTECODE=1 python -B verify_corrected_artifacts.py --snapshot {review['snapshot_file']} --output FRESH_CI_EVIDENCE_VERIFICATION.json
```

Use new output names. These commands read preserved evidence; they do not contact GitHub, operate on a native device, mutate Git, import repository applications or run application tests.

The exact-head check census retains `ci-authority/codex/merge-queue-pilot` as failure and `ci-authority/main` as success. This packet neither waives nor rules on the policy binding of those checks. Root owns current protected procedure, live freshness/holds, accepted-source verification, merge and the native C01 witness. There is no rights, custody, historical, factual, Graph1, production or predictive promotion.
'''
    with (DESTINATION / 'ARCHIVE_README.md').open('x', encoding='utf8') as handle:
        handle.write(readme)
    print(json.dumps({'archive_directory': str(DESTINATION), 'archive': archive_record,
                      'manifest': manifest_record, 'verification': verification_record,
                      'readme': record(DESTINATION / 'ARCHIVE_README.md'),
                      'regular_files': len(rows), 'uncompressed_file_bytes': total,
                      'both_unchanged_verifier_replays_passed': True,
                      'status': result['status']}, indent=2))


if __name__ == '__main__':
    main()
