#!/usr/bin/env python3
"""Write a bounded report from the independent preserved-data verifier output.

Scratch only. Does not import repository code, execute application tests, read
native files, contact a network, or alter any prior observation.
"""
import argparse
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO_URL = 'https://github.com/mastermindx-market-intelligence/macro'


def load(name):
    return json.loads((ROOT / name).read_text())


def record(name):
    raw = (ROOT / name).read_bytes()
    return {'path': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def write(name, content):
    raw = content.encode() if isinstance(content, str) else (json.dumps(content, indent=2, sort_keys=True) + '\n').encode()
    with (ROOT / name).open('xb') as handle:
        handle.write(raw)
    return record(name)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--verification', required=True)
    args = parser.parse_args()
    review = load(args.verification)
    assert review['identity']['subject_head_sha'] == '42174563149254d2399e23e101baafd8b06f9b1e'
    assert review['verification']['all_observed_byte_identity_inventory_and_source_checks_passed'] is True
    process_record = load('native_read_scripts.json')
    assert process_record['all_managed_processes_reconciled'] is True
    identity = review['identity']
    counts = review['denominators']
    complete = review['completeness']['complete_ci_pass_evidence']
    owner = review['owner']
    contract = review['contract_delta']
    aggregate = review['aggregate']
    hosted = {job['name']: job for job in review['hosted_jobs']}
    fragments = {row['pack_index']: row for row in review['fragment_inventory']}
    source_pins = review['accepted_application_byte_pins']
    focused = {
        'schema': 'gmi.pr8711.corrected_focused_observation/v1',
        'reviewer': '/root/ci_release_evidence', 'disposition': review['disposition'],
        'frozen_observation_completed_at_utc': review['observation_completed_at_utc'],
        'full_verification': record(args.verification),
        'identity': identity, 'candidate_parent': review['candidate_parent'],
        'tested_commit_parents': review['tested_commit_parents'],
        'tested_commit_tree_sha': review['tested_commit_tree_sha'],
        'denominators': counts, 'completeness': review['completeness'],
        'observed_outcomes': review['observed_outcomes'], 'aggregate': aggregate,
        'owner': owner, 'contract_delta': contract, 'ci_gate': review['ci_gate'],
        'hosted_run': review['hosted_run'], 'hosted_jobs': review['hosted_jobs'],
        'exact_head_checks': review['exact_head_checks'],
        'accepted_application_byte_pins': source_pins,
        'native_processes': [{k: row[k] for k in ('pid', 'exit_code', 'runtime_seconds', 'purpose', 'receipt', 'reconciled')}
                             for row in process_record['processes']],
        'proof_limits': review['proof_limits'], 'authority': review['authority'],
    }
    outputs = [write('FOCUSED_OBSERVATION.json', focused)]
    inventory = {
        'schema': 'gmi.pr8711.corrected_actual_artifact_inventory/v1',
        'identity': identity, 'frozen_observation_completed_at_utc': review['observation_completed_at_utc'],
        'expected_complete_artifact_count': 15,
        'observed_retained_artifact_count': counts['observed_retained_artifacts'],
        'all_available_api_artifacts_retained': True,
        'missing_artifact_names': review['completeness']['missing_artifact_names'],
        'original_zip_and_json_member_inventory': review['artifact_inventory'],
        'fragment_inventory': review['fragment_inventory'],
        'full_source_inventory': [review['manifest'], *review['source_law_inventory']],
        'whole_log_inventory': review['whole_log_inventory'],
        'accepted_application_byte_pins': source_pins,
    }
    outputs.append(write('ARTIFACT_INVENTORY.json', inventory))
    timeline = []
    for path in ROOT.glob('*.json'):
        if path.name.startswith(('artifact_read_', 'run_snapshot_', 'mapping_and_snapshot_')):
            doc = load(path.name)
            if not isinstance(doc.get('run'), dict) or 'jobs' not in doc:
                continue
            artifacts = doc.get('artifact_inventory', doc.get('artifacts'))
            artifact_count = artifacts.get('total_count') if isinstance(artifacts, dict) else None
            timeline.append({'receipt': record(path.name), 'observed_at_utc': doc['observed_at_utc'],
                             'completed_at_utc': doc['completed_at_utc'],
                             'run_id': doc['run']['id'], 'attempt': doc['run']['run_attempt'],
                             'run_status': doc['run']['status'], 'run_conclusion': doc['run']['conclusion'],
                             'artifact_count': artifact_count,
                             'jobs': [{k: job[k] for k in ('id', 'name', 'status', 'conclusion')}
                                      for job in doc['jobs']['jobs']]})
    timeline.sort(key=lambda row: row['observed_at_utc'])
    outputs.append(write('READ_TIMELINE.json', {
        'schema': 'gmi.pr8711.corrected_observation_timeline/v1',
        'candidate': identity['subject_head_sha'], 'run_id': identity['workflow_run_id'],
        'attempt': 1, 'snapshots': timeline,
        'earlier_observations_preserved_unchanged': True,
        'old_failed_candidate_packet': record('OLD_PACKET_PRESERVATION.json')}))

    pack_rows = []
    for index in range(12):
        job = hosted[f'ci-pack-{index}']
        fragment = fragments.get(index)
        pack_rows.append(f"| {index} | {job['id']} | {job['status']} / {job['conclusion'] or 'null'} | "
                         + (f"{fragment['logical_jobs']} | {fragment['proof_steps']} | `{json.dumps(fragment['outcomes'], sort_keys=True)}` |"
                            if fragment else 'not observed | not observed | not observed |'))
    log_rows = [f"| {row['role']} | {row['job_id']} | {row['bytes']:,} | `{row['sha256']}` |"
                for row in review['whole_log_inventory']]
    sources = [review['manifest'], *review['source_law_inventory']]
    source_rows = [f"| `{row['path']}` | {row['bytes']:,} | `{row['sha256']}` |" for row in sources]
    artifact_rows = []
    for row in review['artifact_inventory']:
        artifact_rows.append(f"| {row['artifact_id']} | `{row['artifact_name']}` | {row['zip']['bytes']:,} | `{row['zip']['sha256']}` |")
    check_rows = [f"| `{row['name']}` | {row['id']} | {row['status']} | {row['conclusion'] or 'null'} |"
                  for row in review['exact_head_checks']]
    process_rows = [f"| {row['pid']} | {row['purpose']} | {row['exit_code']} | {row['runtime_seconds']} |"
                    for row in process_record['processes']]
    if complete:
        conclusion = ('**The corrected candidate’s observed CI run concluded successfully, and its complete all-pass semantic evidence reconciles independently against the actual tested source.** '
                      'This is a bounded CI evidence conclusion. It does not authorize merge or replace the principal’s canonical release procedure, current freshness/holds checks, accepted-source review or native C01 witness.')
    else:
        conclusion = ('**The retained observed evidence verifies, but this packet does not establish a complete successful CI run.** '
                      f"Disposition: `{review['disposition']}`. Actual missing or failed evidence remains explicit below; no prior candidate result substitutes for it.")
    owner_text = (f"The new owner group reports **{owner['actual_result']['passed']} passed in {owner['actual_result']['seconds']}s** "
                  f"at line {owner['actual_result']['line']} of job `{owner['hosted_job_id']}`. "
                  'The actual new fragment, logical job, proof ID, execution digest and step digest are bound to the same source command. '
                  'No old-run test result is an input to this conclusion.' if owner else 'The new owner result was not observed.')
    aggregate_text = (f"The retained aggregate is `{aggregate['status']}`, has {aggregate['jobs']} jobs and {aggregate['proof_steps']} proof steps, "
                      f"and reports `{json.dumps(aggregate['classifications'], sort_keys=True)}`. Its logical evidence SHA-256 is "
                      f"`{aggregate['evidence_sha256']}`. Independent exact aggregate reconciliation: **{aggregate['exact_independent_reconciliation']}**."
                      if aggregate else 'No final semantic aggregate was observed; no final aggregate PASS is claimed.')
    report = f'''# PR8711 corrected-candidate independent CI evidence review

{conclusion}

Frozen observation completed: **{review['observation_completed_at_utc']}**. Reviewer: `/root/ci_release_evidence`. The full machine-readable record is `{args.verification}`, with **{review['verification']['assertions_passed']:,} assertions passed**. The verifier treats source as bytes, YAML data and AST; it does not import or execute repository application code.

## Exact identity and tested source

| Binding | Observed value |
|---|---|
| Candidate head | `{identity['subject_head_sha']}` |
| Candidate’s sole parent | `{review['candidate_parent']}` |
| Run / attempt | `{identity['workflow_run_id']}` / `1` |
| Event | `{identity['event']}` |
| Actual tested synthetic commit | `{identity['tested_tree_sha']}` |
| Ordered first parent / actual tested base | `{review['tested_commit_parents'][0]}` |
| Ordered second parent | `{review['tested_commit_parents'][1]}` |
| Actual Git tree object | `{review['tested_commit_tree_sha']}` |
| Plan logical SHA-256 | `{review['plan']['logical_sha256']}` |
| Changed-path canonical SHA-256 | `{review['plan']['changed_files_sha256']}` |
| Merged manifest Git blob | `{review['manifest']['git_blob_sha']}` |
| Hosted run status / conclusion | `{review['hosted_run']['status']}` / `{review['hosted_run']['conclusion']}` |

The PR API’s `base.sha` field lagged at `c4cd21d597521603fb75fe7a4602424e088c6bfa`. It is not the tested base. The immutable synthetic commit’s ordered parents, the actual retained plan, and the actual hosted checkout logs establish `40ebaebdbcd57eedaa627623f1cfd1860ff3ee3a` as the tested base. The workflow’s `tested_tree_sha` field names a commit; the distinct Git tree object is recorded separately above.

Primary references: [PR8711]({REPO_URL}/pull/8711), [exact run]({REPO_URL}/actions/runs/{identity['workflow_run_id']}), [tested commit]({REPO_URL}/commit/{identity['tested_tree_sha']}), [candidate]({REPO_URL}/commit/{identity['subject_head_sha']}), and [actual merged manifest]({REPO_URL}/blob/{identity['tested_tree_sha']}/.github/ci/legacy-jobs.yml). Original artifact IDs, GET endpoints and response receipts are enumerated in `ARTIFACT_INVENTORY.json` and the full verifier record.

## Completeness and exact denominators

| Evidence dimension | Observed | Complete expectation / denominator |
|---|---:|---:|
| Original artifact ZIPs and exact JSON members | {counts['observed_retained_artifacts']} | 15 |
| Raw pack fragments | {counts['observed_fragments']} | 12 |
| Selected logical jobs represented in fragments | {counts['observed_jobs']} | 98 |
| Proof steps represented in fragments | {counts['observed_proof_steps']} | 316 |
| Selected code jobs | 98 | 182 code jobs |
| Explicitly excluded code jobs | 84 | 182 code jobs |
| Other manifest gate jobs | 72 | 254 total manifest jobs |
| Changed repository paths in plan | 125 | 125 |
| Accepted engine/lib byte pins | 53 | 53 |

Observed step outcomes: `{json.dumps(review['observed_outcomes'], sort_keys=True)}`. Missing packs: `{review['completeness']['missing_packs']}`. Missing artifact names: `{review['completeness']['missing_artifact_names']}`. The full manifest’s 254 jobs are not a test-pass denominator. The selected and explicitly excluded code inventories exhaust the 182 code jobs. Q07 is present in the manifest and explicitly excluded; this review does not claim it ran.

The verifier recomputes all **98 selected job execution digests** and **316 planned step specification digests** from the exact actual merged manifest. It checks complete observed-plus-missing accounting, fragment identities, pack assignment, proof order, source hashes and every result. It does not rerun the scope-selection planner. A successful hosted job name alone is never treated as semantic proof.

| Pack | Hosted job ID | Hosted status / conclusion | Logical jobs in fragment | Proof steps | Actual fragment outcomes |
|---:|---:|---|---:|---:|---|
{chr(10).join(pack_rows)}

{aggregate_text}

## Actual owner command and required gates

Logical owner: `company-relationship-candidates`, pack **11**. Proof ID: `File, pinned-source and immutable observation replay contracts`.

```sh
{owner['command'] if owner else 'Owner command/result unavailable in this observation.'}
```

{owner_text}

The owner step specification SHA-256 is `3f346c8660ce1278b5d782982c639324dfa4412faa4856e91d19d822a0481d70`; its job execution SHA-256 is `5ff9e1dd799a76ff34ad59e95d95cafbc10cea6c6f4cb58da6922bb28801ff6f`.

The corrected candidate’s actual contract-delta job `{contract['hosted']['id']}` is `{contract['hosted']['conclusion']}`. Its full raw log reports **{contract.get('actual_counts', {}).get('introduced', 'unobserved')} introduced, {contract.get('actual_counts', {}).get('inherited', 'unobserved')} inherited**, using the actual tested base. This is a new exact-head gate result. The former 2/0 finding on the old candidate remains preserved as a failed result.

The actual final `ci-gate` log, when present, is checked against the retained aggregate’s exact status, logical evidence digest, classification counts and infrastructure count. Actual semantic-clear and successful-contract notices are required before this verifier reports complete successful CI evidence. Hosted gate step outcomes and exact log line references are retained in the `ci_gate` field of the full and focused records.

| Full raw hosted log | Job ID | Bytes | SHA-256 |
|---|---:|---:|---|
{chr(10).join(log_rows)}

Raw log bodies are preserved unchanged. The receipts also retain bounded exact raw or ANSI-stripped excerpts and line numbers. This corrected packet does not inherit the old packet’s excerpt-only retention limit.

## Actual source composition and material correction

The full actual merged CI manifest differs from the prior merged source only in the existing `unrun-builders-stores` job: the backup owner command adds the PostgreSQL binaries to its PATH, verifies `psql`, `initdb` and `pg_ctl`, rejects root execution, and runs `tests/test_backup_user_tables.py` plus `tests/test_backup_iw2_snapshot.py`. The workflow adds the corresponding test and fixture triggers. The owner’s 71 scope paths and four-suite command remain unchanged. `UPSTREAM_MERGED_MANIFEST_DELTA.diff` and `UPSTREAM_WORKFLOW_DELTA.diff` preserve the exact comparisons.

The broad GitHub upstream compare reached its 300-file cap; it is not represented as a complete repository overlap census. The separate source verifier closes the relevant 53-file byte question directly: **three complete Git tree responses and 52 unique blob responses** establish all **53 accepted engine/lib paths**, totaling **1,483,905 bytes**, at the actual tested Git tree. Each raw tree/blob API response and exact source byte sequence is losslessly retained in `tested_source_pin_read_001.json`. The reference manifest was accepted at checkpoint `6b58f15adae3b1d402d9993c52609d00083f1453`. Its later preservation in a review at 9df does not change that underlying reference revision.

This source result is byte compatibility for the 53 named paths. It is not an independent new functional review of those modules or certification of the other 18 owner scope paths. The principal retains responsibility for accepted-source verification and the native proof.

The correction commit is exactly one commit ahead of 9df, with an 18-path bounded comparison. The two frozen archived test-shaped files were renamed to `.py.txt`, preserving their exact bytes, not converted into extra runnable suites or hidden through a policy exclusion. The committed path map binds their original logical filenames, checkpoint 6b58, last original-path checkpoint 9df, current archive paths, lengths, hashes and the canonical runtime suite separately. Original and renamed v1/v2 source bodies were independently read at their immutable refs and compared byte-for-byte. The actual discovery law identifies runnable test basenames ending in `.py`; the archival representations no longer meet that discovery condition. The actual new 0/0 contract result verifies the material correction in hosted CI.

V1 archive: **43,659 bytes**, SHA-256 `80acae7aadcecec3214fe86d77c99da841d2544629d35380ec11b5d9cc94d67e`. V2 archive: **49,406 bytes**, SHA-256 `a73700e639c8e97a4ff84951b48358abe63b1f5048560d03b0e40f2310ac44da`. The committed map’s exact SHA-256 is `e79558bf8466b6f0b10faa281cb5164e9d4d39cf8e8be331193758acb006f75f`.

The prior failed/pending archive remains unchanged. Its 57 original manifest members were checked, and its Git blob matches the archive carried by the correction commit. `OLD_PACKET_PRESERVATION.json` records this check; the old archive and its already-frozen reports were not rewritten or inserted as new-run proof.

| Exact source file preserved as data | Bytes | SHA-256 |
|---|---:|---|
{chr(10).join(source_rows)}

## Artifact byte inventory

Every listed ZIP was downloaded through its actual GitHub artifact GET endpoint, matched to API length/digest, checked for a unique safe regular JSON member, and retained with that exact member. API and transferred artifact inventories must match exactly at the selected observation. Full member lengths and SHA-256 hashes, CRCs, source bindings, fragment job IDs and step inventories are in the machine-readable inventory; the table below lists every original ZIP.

| Artifact ID | Artifact name | ZIP bytes | ZIP SHA-256 |
|---:|---|---:|---|
{chr(10).join(artifact_rows)}

## Exact-head check census and process accounting

These are actual observations, not a release-policy ruling. In particular, any merge-queue authority check failure is retained without silently turning it into a successful check or waiving it. The principal decides which current protected procedure applies.

| Exact-head check | Check ID | Status | Conclusion |
|---|---:|---|---|
{chr(10).join(check_rows)}

Every managed read process in this corrected-candidate audit completed with exit code 0 and was reconciled. Native commands use GitHub GET operations and in-memory processing; there are no native writes, Git mutations, application imports/tests, workflow dispatches, reruns, cancellations or release changes. `native_read_scripts.json` preserves the exact read scripts, purposes, process footer evidence and associated receipts.

| Native PID | Purpose | Exit code | Runtime seconds |
|---:|---|---:|---:|
{chr(10).join(process_rows)}

## Reproduction and proof limits

The durable archive contains these observations, the exact artifact ZIPs and members, full raw new logs, exact CI source data, all retained source-pin API/blob bytes, both independent verifiers, historical verifier versions and bounded read/materialization scripts. `PACKAGING_NOTES.md` records representation and transport adjustments. Extraction and verifier replay are accounted for separately in the archive verification receipt; fresh replay outputs never alter the frozen originals.

With Python 3 and PyYAML, run from the extracted evidence directory using fresh output names:

```sh
PYTHONDONTWRITEBYTECODE=1 python -B verify_tested_code_pins.py --output FRESH_SOURCE_PIN_VERIFICATION.json
PYTHONDONTWRITEBYTECODE=1 python -B verify_corrected_artifacts.py --snapshot {review['snapshot_file']} --output FRESH_CI_EVIDENCE_VERIFICATION.json
```

The 53-pin verifier uses Python’s standard library. The CI verifier reads preserved YAML with PyYAML {review['verification']['yaml_version']}; repository source is treated only as data and AST. Replays perform no network, Git, native device operation, application import or application test.

No current main freshness, live hold, licensing right, evidence custody, source truth, historical availability, Graph1 admission, production acceptance or predictive promotion is certified here. Independent source composition review belongs to its named owner; this observer does not claim to have authored or functionally reviewed those modules. The principal owns canonical release adjudication, expected-head merge, accepted-source verification and the actual native C01 witness.
'''
    outputs.append(write('OBSERVATION_REPORT.md', report))
    notes = '''# Corrected-candidate evidence packaging and preparation notes

All observed artifact ZIPs, exact JSON members, source bodies, whole new-candidate logs, captures and earlier reports remain unchanged. An outer deterministic archive normalizes its own metadata; it does not rewrite the original GitHub ZIP metadata or member bodies.

## Explicit path preservation

- `context/EXPECTED_53_CODE_PINS.json` is an unchanged copy of the accepted 53-path reference manifest, with its actual reference revision 6b58 retained. Its SHA-256 is `e955ec0f462369f42b0d3689360682d1a30dcbcea63bf090d935db73b2c9d293`.
- Immutable repository source is materialized under `sources/`; the repository workflow path remains `sources/.github/workflows/ci.yml`. `source_materialization_001.json` records that path mapping and exact lengths/hashes.
- Original and corrected archived source bodies use explicit local data names in `correction_sources/`. `correction_materialization_001.json` binds each local path to its immutable repository path/ref and exact bytes. This local packaging choice is separate from the principal’s committed `.py` to `.py.txt` repair.
- `verifier_versions/VERSION_MAP.json` preserves the exact earlier verifier bytes referenced by the two historical partial reports. The first was recovered by reversing the later documented patch and matching its original exact length and SHA-256; the second was snapshotted directly. These historical observations preceded later artifact receipts. The final unchanged verifier and final selected snapshot are the offline replay entry point.
- The old failed/pending archive is not recopied into this new packet. Its own durable archive is already committed by the principal. `OLD_PACKET_PRESERVATION.json` binds the prior 57-member verification and the committed archive Git blob. No old packet file was altered.

## Preparation-only observations

The first corrected contract-log capture (native PID 31546) emitted a Python regex FutureWarning because its optional ANSI excerpt sanitizer was overescaped. Some selected excerpt strings therefore retain exact raw ANSI escapes. The whole 30,334-byte log was preserved unchanged and hashes to `a22f7871b0b85b32caad86d096502e1650b04340cb4d2ab4f3834d49130dad04`. The offline verifier accepts an excerpt only if it equals that exact raw line or the correctly ANSI-stripped line from the whole preserved log. Subsequent native read scripts use the corrected sanitizer. This is not a hosted CI failure and does not change a result.

The native 53-pin source read (PID 50553) returned a single compact JSON stdout body that the RDC provider wrapped at 1 MiB. Initial parsing of the first provider line failed; inspecting the full tool content showed the complete tail. Joining exactly the one provider-inserted newline recovered the full JSON without another source read. All decoded API response and source lengths, SHA-256 hashes, Git blob hashes and path bindings subsequently passed the independent offline verifier. Raw response/source byte bodies are losslessly retained inside that JSON capture. No source body was reconstructed from inference.

The API metadata snapshots preserve their decoded full JSON objects and the actual GET length/hash receipts. Artifact ZIPs, JSON members, source bodies and whole new-candidate logs preserve their exact raw bytes. Do not mistake the decoded metadata serialization for a claim that every original metadata response serialization was retained byte-for-byte.

The final archive includes raw new-candidate CI logs because this task explicitly requires full actual logs. It excludes credentials, signed download URLs, caches and unrelated lanes. Metadata URL fields are GitHub source/API references, not signed artifact redirects. The exact bounded GET scripts capture download bodies in memory and do not retain signed redirect URLs. An explicit regular-file manifest lists every archived path, byte count and SHA-256.

No packaging step reruns hosted CI, executes repository applications/tests, changes native files, changes Git, approves a policy waiver or authorizes merge.
'''
    outputs.append(write('PACKAGING_NOTES.md', notes))
    print(json.dumps({'outputs': outputs, 'disposition': review['disposition']}, indent=2))


if __name__ == '__main__':
    main()
