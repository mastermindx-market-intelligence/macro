# Corrected-candidate evidence packaging and preparation notes

All observed artifact ZIPs, exact JSON members, source bodies, whole new-candidate logs, captures and earlier reports remain unchanged. An outer deterministic archive normalizes its own metadata; it does not rewrite the original GitHub ZIP metadata or member bodies.

## Explicit path preservation

- `context/EXPECTED_53_CODE_PINS.json` is an unchanged copy of the accepted 53-path reference manifest, with its actual reference revision 6b58 retained. Its SHA-256 is `e955ec0f462369f42b0d3689360682d1a30dcbcea63bf090d935db73b2c9d293`.
- Immutable repository source is materialized under `sources/`; the repository workflow path remains `sources/.github/workflows/ci.yml`. `source_materialization_001.json` records that path mapping and exact lengths/hashes.
- Original and corrected archived source bodies use explicit local data names in `correction_sources/`. `correction_materialization_001.json` binds each local path to its immutable repository path/ref and exact bytes. This local packaging choice is separate from the principal’s committed `.py` to `.py.txt` repair.
- `verifier_versions/VERSION_MAP.json` preserves the exact earlier verifier bytes referenced by the two historical partial reports. The first was recovered by reversing the later documented patch and matching its original exact length and SHA-256; the second was snapshotted directly. These historical observations preceded later artifact receipts. The final unchanged verifier and final selected snapshot are the offline replay entry point.
- The old failed/pending archive is not recopied into this new packet. Its own durable archive is already committed by the principal. `OLD_PACKET_PRESERVATION.json` binds the prior 57-member verification and the committed archive Git blob. No old packet file was altered.

## Preparation-only observations

The first corrected contract-log capture (native PID 31546) emitted a Python regex FutureWarning because its optional ANSI excerpt sanitizer was overescaped. Some selected excerpt strings therefore retain exact raw ANSI escapes. The whole 30,334-byte log was preserved unchanged and hashes to `a22f7871b0b85b32caad86d096502e1650b04340cb4d2ab4f3834d49130dad04`. The offline verifier accepts an excerpt only if it equals that exact raw line or the correctly ANSI-stripped line from the whole preserved log. Subsequent native read scripts use the corrected sanitizer. This is not a hosted CI failure and does not change a result.

The native 53-pin source read (PID 50553) returned a single compact JSON stdout body that the RDC provider wrapped at 1 MiB. Initial parsing of the first provider line failed; inspecting the full tool content showed the complete tail. Joining exactly the one provider-inserted newline recovered the full JSON without another source read. All decoded API response and source lengths, SHA-256 hashes, Git blob hashes and path bindings subsequently passed the independent offline verifier. Raw response/source byte bodies are losslessly retained inside that JSON capture. No source body was reconstructed from inference.

The API metadata snapshots preserve their decoded full JSON objects and the actual GET length/hash receipts. Artifact ZIPs, JSON members, source bodies and whole new-candidate logs preserve their exact raw bytes. Do not mistake the decoded metadata serialization for a claim that every original metadata response serialization was retained byte-for-byte.

The final archive includes raw new-candidate CI logs because this task explicitly requires full actual logs. It excludes credentials, signed download URLs, caches and unrelated lanes. Metadata URL fields are GitHub source/API references, not signed artifact redirects. The exact bounded GET scripts capture download bodies in memory and do not retain signed redirect URLs. An explicit regular-file manifest lists every archived path, byte count and SHA-256.

No packaging step reruns hosted CI, executes repository applications/tests, changes native files, changes Git, approves a policy waiver or authorizes merge.
