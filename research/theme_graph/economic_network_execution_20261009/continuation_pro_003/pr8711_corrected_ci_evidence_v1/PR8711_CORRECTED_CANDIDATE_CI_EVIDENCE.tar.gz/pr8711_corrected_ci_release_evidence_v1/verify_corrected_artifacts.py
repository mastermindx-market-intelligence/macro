#!/usr/bin/env python3
"""Independent preserved-data audit for PR8711 corrected head 4217456.

Reuses the prior byte/inventory/source-digest and all-pass reconciliation method
with independently read NEW head, run, plan and merged-source pins. Repository
source is data/AST only. No app imports, tests, network, Git or native actions.
Missing data and non-all-pass semantic evidence stay explicit and cannot promote
this audit to a release authorization.
"""
import argparse
import ast
import base64
import collections
import datetime
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import stat
import unicodedata
import zipfile

import yaml

ROOT = Path(__file__).resolve().parent
HEAD = '42174563149254d2399e23e101baafd8b06f9b1e'
OLD = '9df735bbeaa8d0f4d4967296270bfb2246a5212f'
BASE = '40ebaebdbcd57eedaa627623f1cfd1860ff3ee3a'
TESTED = '04b70807e6b0a7d48091997eb405f9cc53ade9ad'
RUN = '37932039980'
REPO = 'mastermindx-market-intelligence/macro'
OWNER = 'company-relationship-candidates'
OWNER_PROOF = 'File, pinned-source and immutable observation replay contracts'
COMMAND = ('python -m pytest tests/test_company_relationship_candidates.py '
           'tests/test_company_pinned_relationship_candidates.py '
           'tests/test_company_relationship_review_set.py '
           'tests/test_company_relationship_observations.py -q')
MANIFEST_PIN = (1248919, '6659e06968a347a6ccba8a35d07bdc7bb601e32acd84d410ad66ad238eed08cd')
MANIFEST_BLOB = 'a5cfd271fe02ad22458cab56cc29e878de8a8fc9'
PLAN_PIN = (95459, '7e2749004b694f74e9e111bbc292b2c0c3b42fb2cabe5c69a70b36397771ac11')
PLAN_LOGICAL_SHA = 'e637d0f4907e040b1a4069d7c14748fba81137387e83ea6ec255bf0d53c5ce88'
SOURCE_PINS = {
    'scripts/ci_semantic_proof.py': (73298, '9df4b9a9a8d68f7e9aa34a8eebe99e8d17e27f2ef0560eadcc050f3130359158'),
    'scripts/run_ci_pack.py': (223426, '65564916a55eb806d3d9fb0cd4e12726f05fec953f6e47ccd9240f5a141049df'),
    'scripts/check_contract_delta.py': (62554, '894f4e66dd323d5b17be2fe570bfd2fcb8456f92404d464a65b5b16f5c6a278f'),
    '.github/workflows/ci.yml': (318629, 'ef9cd98724e4c545e4cb55420d0a6e5c9fc36b9d4efde449416b560cd8d255a9'),
    'scripts/audit_unrun_tests.py': (50447, 'e50ba44cb678761d55f1c5bb9828390bd7c21c1672760d6f52781ca194dd7d47'),
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value, *, ascii=False):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=ascii).encode('utf8')


def digest(value):
    return sha(canonical(value))


def git_blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + bytes([0]) + raw).hexdigest()


def safe(name):
    assert type(name) is str and name and not name.startswith('/') and '\\' not in name
    assert all(part not in {'', '.', '..'} for part in name.split('/'))
    assert str(PurePosixPath(name)) == name
    return name


def read(name):
    path = ROOT / safe(name)
    for node in (path, *path.parents):
        if node.is_relative_to(ROOT):
            assert not node.is_symlink(), name
    assert stat.S_ISREG(path.lstat().st_mode), name
    raw = path.read_bytes()
    assert len(raw) <= 16 * 1024 * 1024, name
    return raw


def loads(raw):
    def pairs(items):
        out = {}
        for key, value in items:
            assert key not in out, ('duplicate JSON key', key)
            out[key] = value
        return out
    return json.loads(raw.decode('utf8', 'strict'), object_pairs_hook=pairs)


def doc(name):
    return loads(read(name))


def record(name):
    raw = read(name)
    return {'path': name, 'bytes': len(raw), 'sha256': sha(raw)}


class UniqueSafeLoader(yaml.SafeLoader):
    pass


def unique_mapping(loader, node, deep=False):
    loader.flatten_mapping(node)
    out = {}
    for key, value in loader.construct_pairs(node, deep=deep):
        if key in out:
            raise ValueError('duplicate YAML key: ' + repr(key))
        out[key] = value
    return out


UniqueSafeLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, unique_mapping)


def inventory(snapshot):
    value = snapshot.get('artifact_inventory', snapshot.get('artifacts'))
    assert isinstance(value, dict) and set(value) == {'total_count', 'artifacts'}
    return value


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--snapshot', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    checks = {}

    def check(name, condition):
        assert name not in checks, ('duplicate assertion', name)
        checks[name] = bool(condition)
        assert condition, name

    discovery = doc('candidate_discovery_001.json')
    source_capture = doc('run_snapshot_and_sources_001.json')
    mapping_capture = doc('mapping_and_snapshot_002.json')
    snapshot = doc(args.snapshot)
    check('candidate_parent_is_original_failed_head', discovery['candidate_commit']['sha'] == HEAD
          and [p['sha'] for p in discovery['candidate_commit']['parents']] == [OLD])
    tested = source_capture['tested_commit']
    check('new_synthetic_ordered_parents', tested['sha'] == TESTED
          and [p['sha'] for p in tested['parents']] == [BASE, HEAD])
    run = snapshot['run']
    check('new_run_identity_and_attempt', (run['id'], run['run_attempt'], run['head_sha'], run['event'])
          == (int(RUN), 1, HEAD, 'pull_request'))
    check('new_exact_head_checks', all(c['head_sha'] == HEAD for c in snapshot['checks']['check_runs']))
    check('latest_observed_pr_head', snapshot['pr']['head']['sha'] == HEAD and snapshot['pr']['number'] == 8711)
    check('metadata_pagination_complete', snapshot['jobs']['total_count'] == len(snapshot['jobs']['jobs']) < 100
          and snapshot['checks']['total_count'] == len(snapshot['checks']['check_runs']) < 100)
    check('latest_metadata_gets_successful', all(x['returncode'] == 0 for x in snapshot['operations']))

    # Every transferred ZIP must be present in the selected snapshot's API
    # inventory. The API inventory may be incomplete relative to the final plan.
    metadata = inventory(snapshot)
    check('artifact_api_page_complete', metadata['total_count'] == len(metadata['artifacts']) < 100)
    by_id = {r['id']: r for r in metadata['artifacts']}
    check('artifact_ids_names_unique', len(by_id) == len(metadata['artifacts'])
          and len({r['name'] for r in metadata['artifacts']}) == len(by_id))
    expected_names = {f'ci-semantic-plan-{RUN}-1', 'ci-changed-files',
                      *(f'ci-semantic-pack-{RUN}-{i}' for i in range(12)), f'ci-semantic-evidence-{RUN}'}
    check('observed_artifact_names_belong_to_new_run', {r['name'] for r in by_id.values()} <= expected_names)
    transfers = {}
    captures = []
    for path in sorted(ROOT.glob('artifact_read_*.json')):
        name = path.name
        capture = doc(name)
        captures.append((name, capture))
        for row in capture.get('artifacts', []):
            check('unique_download_' + str(row['artifact_id']), row['artifact_id'] not in transfers)
            transfers[row['artifact_id']] = (name, row)
    check('all_snapshot_artifacts_downloaded', set(transfers) == set(by_id))
    check('retained_artifact_directory_census',
          {p.name for p in (ROOT / 'artifacts').iterdir()} == {str(aid) for aid in by_id})
    member_documents = {}
    artifact_rows = []
    for aid in sorted(by_id):
        api = by_id[aid]
        receipt_name, transfer = transfers[aid]
        check('artifact_new_run_binding_' + str(aid), api['workflow_run']['id'] == int(RUN)
              and api['workflow_run']['head_sha'] == HEAD and api['expired'] is False
              and transfer['returncode'] == 0 and transfer['name'] == api['name']
              and transfer['endpoint'] == f'repos/{REPO}/actions/artifacts/{aid}/zip')
        zip_path = f'artifacts/{aid}/original.zip'
        raw = read(zip_path)
        check('zip_exact_bytes_api_and_transfer_' + str(aid), len(raw) == api['size_in_bytes'] == transfer['zip_bytes']
              and 'sha256:' + sha(raw) == api['digest'] and sha(raw) == transfer['zip_sha256']
              and raw == base64.b64decode(transfer['zip_base64'], validate=True))
        archive = zipfile.ZipFile(io.BytesIO(raw))
        entries = archive.infolist()
        check('single_unique_zip_member_' + str(aid), len(entries) == len({e.filename for e in entries})
              == len(transfer['members']) == 1)
        entry = entries[0]
        safe(entry.filename)
        check('regular_unencrypted_bounded_zip_member_' + str(aid), not entry.is_dir() and not entry.flag_bits & 1
              and stat.S_IFMT(entry.external_attr >> 16) in (0, stat.S_IFREG) and entry.file_size <= 8 * 1024 * 1024)
        raw_member = archive.read(entry)
        expected = transfer['members'][0]
        relative = f'artifacts/{aid}/' + entry.filename
        check('member_exact_transferred_and_retained_bytes_' + str(aid), entry.filename == expected['name']
              and len(raw_member) == entry.file_size == expected['bytes'] and sha(raw_member) == expected['sha256']
              and raw_member == read(relative))
        check('unique_member_across_artifacts_' + entry.filename, entry.filename not in member_documents)
        member_documents[entry.filename] = {'document': loads(raw_member), 'path': relative, 'artifact_id': aid}
        check('artifact_directory_closed_' + str(aid),
              {p.name for p in (ROOT / f'artifacts/{aid}').iterdir()} == {'original.zip', entry.filename})
        artifact_rows.append({'artifact_id': aid, 'artifact_name': api['name'], 'api_metadata': api,
                              'source_receipt': receipt_name, 'zip': record(zip_path),
                              'members': [{**record(relative), 'member_name': entry.filename, 'crc32': entry.CRC,
                                           'compressed_size': entry.compress_size, 'external_attr': entry.external_attr}]})

    # New immutable merged source, including upstream backup-owner changes.
    source_rows = []
    check('source_gets_no_diagnostics', source_capture['diagnostics'] == [])
    for row in source_capture['sources']:
        path = row['path']
        raw = read('sources/' + path)
        check('source_pin_' + path, (len(raw), sha(raw)) == SOURCE_PINS[path])
        check('source_new_ref_and_actual_bytes_' + path, row['ref'] == TESTED and row['returncode'] == 0
              and row['endpoint'] == f'repos/{REPO}/contents/{path}?ref={TESTED}'
              and row['bytes'] == len(raw) and row['sha256'] == sha(raw) and row['git_blob_sha'] == git_blob(raw)
              and gzip.decompress(base64.b64decode(row['content_gzip_base64'], validate=True)) == raw)
        source_rows.append({**record('sources/' + path), 'ref': TESTED, 'git_blob_sha': row['git_blob_sha']})
    check('all_five_ci_law_sources_read', len(source_rows) == 5
          and {r['path'][len('sources/'):] for r in source_rows} == set(SOURCE_PINS))
    raw_manifest = read('sources/merged_legacy_jobs.yml')
    transfer = source_capture['tested_manifest_blob']
    check('actual_new_merged_manifest_pin', (len(raw_manifest), sha(raw_manifest)) == MANIFEST_PIN
          and git_blob(raw_manifest) == MANIFEST_BLOB)
    check('actual_new_merged_manifest_ref_transfer', transfer['ref'] == TESTED
          and transfer['path'] == '.github/ci/legacy-jobs.yml' and transfer['git_blob_sha'] == MANIFEST_BLOB
          and transfer['sha256'] == MANIFEST_PIN[1] and transfer['bytes'] == MANIFEST_PIN[0]
          and gzip.decompress(base64.b64decode(transfer['content_gzip_base64'], validate=True)) == raw_manifest
          and gzip.decompress(read('sources/merged_legacy_jobs.transfer.gz')) == raw_manifest)
    manifest = yaml.load(raw_manifest.decode('utf8'), Loader=UniqueSafeLoader)
    check('manifest_root_shape', set(manifest) == {'jobs'})
    definitions = manifest['jobs']
    code_ids = [jid for jid, definition in definitions.items() if definition.get('gate', 'code') == 'code']
    check('actual_manifest_denominators', len(definitions) == 254 and len(code_ids) == 182)

    plan_entry = member_documents['ci-plan.json']
    plan = plan_entry['document']
    changed = member_documents['changed-files.json']['document']
    check('new_raw_plan_pin', (len(read(plan_entry['path'])), sha(read(plan_entry['path']))) == PLAN_PIN)
    check('new_plan_identity', (plan['workflow_run_id'], plan['workflow'], plan['event'], plan['role'],
          plan['subject_head_sha'], plan['base_sha'], plan['tested_tree_sha'])
          == (RUN, 'ci', 'pull_request', 'pr_head', HEAD, BASE, TESTED))
    identity = {k: plan[k] for k in ('workflow_run_id', 'workflow', 'event', 'role', 'tested_tree_sha',
                                    'subject_head_sha', 'base_sha', 'plan_sha256')}
    check('plan_schema_authority_and_actual_base', plan['schema'] == 'ci.pack_plan.v2'
          and plan['authority_changed'] is True and plan['changed_from'] == BASE and plan['scope_mode'] == 'active')
    check('changed_files_count_and_digest', isinstance(changed, list) and len(changed) == len(set(changed))
          == plan['changed_files_count'] == 125 and digest(changed) == plan['changed_files_sha256']
          == '5f2a89d5b23b7b307df3fbfd53bff817d26a7cedac3cf0937006ccc925b34ce4')
    payload = {k: plan[k] for k in ('schema', 'workflow_run_id', 'workflow', 'event', 'role', 'tested_tree_sha',
               'subject_head_sha', 'base_sha', 'authority_changed', 'changed_from', 'scope_mode', 'changed_files_sha256')}
    payload.update(pack_count=len(plan['packs']), eligible_job_ids=plan['eligible_jobs'],
                   pack_jobs=[p['jobs'] for p in plan['packs']], pack_weights=[p['weight'] for p in plan['packs']],
                   semantic_jobs=plan['semantic_jobs'])
    check('recomputed_new_plan_digest', digest(payload) == plan['plan_sha256'] == PLAN_LOGICAL_SHA)
    planned = {j['logical_job_id']: j for j in plan['semantic_jobs']}
    check('selected_order_unique', list(planned) == plan['eligible_jobs']
          and len(planned) == len(plan['semantic_jobs']) == plan['eligible_job_count'] == 98)
    check('excluded_unique', len(plan['skipped_jobs']) == len(set(plan['skipped_jobs'])) == plan['skipped_job_count'] == 84)
    check('actual_code_inventory_partition', not set(planned) & set(plan['skipped_jobs'])
          and set(planned) | set(plan['skipped_jobs']) == set(code_ids) and plan['legacy_job_count'] == 182)
    check('exact_twelve_pack_plan', [p['index'] for p in plan['packs']] == list(range(12))
          == plan['nonempty_pack_indices'] and plan['matrix'] == {'include': [{'pack': i} for i in range(12)]})
    partition = [jid for pack in plan['packs'] for jid in pack['jobs']]
    check('complete_unique_job_partition', len(partition) == len(set(partition)) == 98 and set(partition) == set(planned))
    check('q07_present_and_excluded', 'quant-q07-fitted-har-vol' in definitions
          and 'quant-q07-fitted-har-vol' in plan['skipped_jobs'])

    runner_ast = ast.parse(read('sources/scripts/run_ci_pack.py').decode('utf8'))
    runner_values = [ast.literal_eval(n.value) for n in runner_ast.body if isinstance(n, ast.Assign)
                     and any(isinstance(t, ast.Name) and t.id == 'RUNNER_CONTRACT' for t in n.targets)]
    check('actual_runner_contract', runner_values == ['ci-pack/linux-x86_64/python-3.12.13/node-20/v2'])
    allowed_actions = [{'uses': 'actions/checkout@v4', 'with': {}},
                       {'uses': 'actions/checkout@v4', 'with': {'fetch-depth': 0}},
                       {'uses': 'actions/setup-python@v5', 'with': {'python-version': '3.12'}},
                       {'uses': 'actions/setup-node@v4', 'with': {'node-version': '20'}}]
    expected_units = {}
    source_semantics = []
    for jid, job in planned.items():
        definition = definitions[jid]
        check('planned_pack_' + jid, jid in plan['packs'][job['pack_index']]['jobs'])
        actions = [{'uses': s['uses'], 'with': s.get('with') or {}} for s in definition['steps'] if 'uses' in s]
        check('supported_action_contract_' + jid, all(action in allowed_actions for action in actions))
        installs = [s['run'] for s in definition['steps'] if 'pip install' in str(s.get('run', ''))]
        check('single_dependency_command_' + jid, len(installs) <= 1)
        execution = {'dependency_install_command': installs[0] if installs else None,
                     'timeout_minutes': definition.get('timeout-minutes'),
                     'runner_contract': runner_values[0] + '/actions-' + sha(canonical(actions, ascii=True))}
        check('new_source_job_execution_digest_' + jid, digest(execution) == job['job_exec_sha256'])
        specs = []
        detailed_steps = []
        for index, step in enumerate(definition['steps']):
            if 'run' not in step or 'pip install' in str(step.get('run', '')):
                continue
            proof = ' '.join(unicodedata.normalize('NFC', step.get('proof_id', step.get('name'))).split())
            check('proof_identity_' + jid + '_' + str(index),
                  0 < len(proof) <= 256 and not any(ord(c) < 32 or ord(c) == 127 for c in proof))
            semantics = {'run': step['run']}
            semantics.update({k: step[k] for k in ('env', 'if', 'shell', 'timeout-minutes', 'working-directory') if k in step})
            spec = {'proof_id': proof, 'step_spec_sha256': digest(semantics)}
            check('unique_source_proof_' + repr((jid, proof)), (jid, proof) not in expected_units)
            expected_units[(jid, proof)] = spec
            specs.append(spec)
            detailed_steps.append({**spec, 'manifest_step_index': index, 'execution_semantics': semantics})
        check('all_new_source_step_specs_match_plan_' + jid, specs == job['steps'])
        source_semantics.append({'logical_job_id': jid, 'pack_index': job['pack_index'],
                                 'job_exec_sha256': job['job_exec_sha256'], 'execution_contract_payload': execution,
                                 'action_contracts': actions, 'steps': detailed_steps})
    check('full_planned_proof_denominator', len(expected_units) == 316)

    observed_jobs = {}
    observed_units = {}
    fragment_rows = []
    infrastructure = []
    all_observed_passed = True
    observed_packs = []
    for index in range(12):
        name = f'pack-{index}.json'
        if name not in member_documents:
            continue
        entry = member_documents[name]
        fragment = entry['document']
        check('fragment_closed_shape_' + str(index), set(fragment) == {'schema', *identity, 'pack_index', 'infrastructure', 'jobs'}
              and fragment['schema'] == 'ci.semantic_fragment.v1')
        check('fragment_new_identity_' + str(index), all(fragment[k] == v for k, v in identity.items())
              and fragment['pack_index'] == index)
        check('fragment_job_partition_' + str(index),
              sorted(j['logical_job_id'] for j in fragment['jobs']) == sorted(plan['packs'][index]['jobs']))
        observed_packs.append(index)
        if fragment['infrastructure']:
            all_observed_passed = False
            infrastructure.append({'pack_index': index, 'findings': fragment['infrastructure']})
        step_count = 0
        for job in fragment['jobs']:
            jid = job['logical_job_id']
            check('fragment_job_closed_shape_' + jid,
                  set(job) == {'logical_job_id', 'job_exec_sha256', 'infrastructure', 'steps'})
            check('fragment_job_source_binding_' + jid, jid not in observed_jobs and planned[jid]['pack_index'] == index
                  and job['job_exec_sha256'] == planned[jid]['job_exec_sha256'])
            check('fragment_proof_order_' + jid,
                  [s['proof_id'] for s in job['steps']] == [s['proof_id'] for s in planned[jid]['steps']])
            observed_jobs[jid] = job
            if job['infrastructure'] != {'outcome': 'passed'}:
                all_observed_passed = False
                infrastructure.append({'logical_job_id': jid, 'finding': job['infrastructure']})
            for step in job['steps']:
                key = (jid, step['proof_id'])
                check('step_closed_allowed_shape_' + repr(key),
                      {'proof_id', 'step_spec_sha256', 'outcome', 'failure_signature'} <= set(step)
                      <= {'proof_id', 'step_spec_sha256', 'outcome', 'failure_signature', 'detail', 'base_replay'})
                check('step_unique_exact_source_binding_' + repr(key), key not in observed_units
                      and step['step_spec_sha256'] == expected_units[key]['step_spec_sha256'])
                observed_units[key] = step
                step_count += 1
                if step['outcome'] != 'passed' or step['failure_signature'] is not None:
                    all_observed_passed = False
        fragment_rows.append({'pack_index': index, 'artifact_id': entry['artifact_id'], **record(entry['path']),
                              'logical_job_ids': [j['logical_job_id'] for j in fragment['jobs']],
                              'logical_jobs': len(fragment['jobs']), 'proof_steps': step_count,
                              'outcomes': dict(collections.Counter(s['outcome'] for j in fragment['jobs'] for s in j['steps']))})
    missing_packs = sorted(set(range(12)) - set(observed_packs))
    missing_jobs = [jid for jid in planned if jid not in observed_jobs]
    missing_units = [{'logical_job_id': jid, **spec} for (jid, proof), spec in expected_units.items()
                     if (jid, proof) not in observed_units]
    check('available_plus_missing_job_and_unit_accounting', len(observed_jobs) + len(missing_jobs) == 98
          and len(observed_units) + len(missing_units) == 316)

    aggregate = None
    aggregate_reconciled = False
    if 'ci-semantic-evidence.json' in member_documents:
        entry = member_documents['ci-semantic-evidence.json']
        evidence = entry['document']
        check('aggregate_identity', all(evidence[k] == v for k, v in identity.items())
              and evidence['schema'] == 'ci.semantic_evidence.v1' and evidence['authority_changed'] is True)
        check('aggregate_own_digest', digest({k: v for k, v in evidence.items() if k != 'evidence_sha256'})
              == evidence['evidence_sha256'])
        if not missing_packs and all_observed_passed:
            expected_jobs = []
            for jid, job in planned.items():
                observed = observed_jobs[jid]
                expected_jobs.append({'logical_job_id': jid, 'pack_index': job['pack_index'],
                                      'job_exec_sha256': job['job_exec_sha256'], 'infrastructure': observed['infrastructure'],
                                      'steps': [dict(step, classification='passed') for step in observed['steps']]})
            expected = {'schema': 'ci.semantic_evidence.v1', **identity, 'authority_changed': True,
                        'status': 'clear', 'jobs': expected_jobs, 'infrastructure': []}
            expected['evidence_sha256'] = digest(expected)
            check('complete_all_pass_aggregate_exact_reconciliation', evidence == expected)
            aggregate_reconciled = True
        aggregate = {**record(entry['path']), 'artifact_id': entry['artifact_id'],
                     'evidence_sha256': evidence['evidence_sha256'], 'status': evidence['status'],
                     'jobs': len(evidence['jobs']), 'proof_steps': sum(len(j['steps']) for j in evidence['jobs']),
                     'classifications': dict(collections.Counter(s['classification'] for j in evidence['jobs'] for s in j['steps'])),
                     'exact_independent_reconciliation': aggregate_reconciled,
                     'non_all_pass_reconciliation_if_needed': 'not claimed by this all-pass verifier' if not aggregate_reconciled else None}

    hosted = {job['name']: job for job in snapshot['jobs']['jobs']}
    check('hosted_job_names_unique', len(hosted) == len(snapshot['jobs']['jobs']))
    check('hosted_exact_scheduled_pack_set', {name for name in hosted if name.startswith('ci-pack-')}
          == {f'ci-pack-{i}' for i in range(12)})
    check('owner_source_contract', planned[OWNER]['pack_index'] == 11
          and planned[OWNER]['steps'] == [{'proof_id': OWNER_PROOF,
              'step_spec_sha256': '3f346c8660ce1278b5d782982c639324dfa4412faa4856e91d19d822a0481d70'}]
          and planned[OWNER]['job_exec_sha256'] == '5ff9e1dd799a76ff34ad59e95d95cafbc10cea6c6f4cb58da6922bb28801ff6f'
          and next(j for j in source_semantics if j['logical_job_id'] == OWNER)['steps'][0]['execution_semantics'] == {'run': COMMAND})

    # Raw logs are retained for this new candidate. Hashes and selected lines
    # can be independently recomputed offline; old-run results are never inputs.
    logs_by_role = {}
    log_rows = []
    ansi = re.compile(chr(27) + r'\[[0-?]*[ -/]*[@-~]')
    for name, capture in captures:
        for log in capture.get('logs', []):
            role = log['role']
            check('unique_new_log_role_' + role, role not in logs_by_role)
            job = hosted[log['job_name']]
            check('log_exact_new_job_binding_' + role, log['job_id'] == job['id']
                  and log['job_conclusion'] == job['conclusion'] and job['status'] == 'completed'
                  and log['endpoint'] == f"repos/{REPO}/actions/jobs/{job['id']}/logs" and log['returncode'] == 0)
            relative = f"logs/{log['job_id']}.log"
            raw = read(relative)
            check('whole_new_log_exact_hash_and_bytes_' + role, log['raw_body_retained'] is True
                  and len(raw) == log['bytes'] and sha(raw) == log['sha256']
                  and raw == base64.b64decode(log['raw_base64'], validate=True))
            raw_lines = raw.decode('utf8', 'replace').splitlines()
            clean = [ansi.sub('', line) for line in raw_lines]
            check('whole_new_log_line_count_' + role, len(clean) == log['line_count'])
            check('retained_log_excerpt_exact_' + role,
                  all(row['text'] in (raw_lines[row['line'] - 1], clean[row['line'] - 1])
                      for row in log['selected_lines']))
            checkout = any('git log -1 --format=%H' in line and i + 1 < len(clean)
                           and clean[i + 1].endswith('Z ' + TESTED) for i, line in enumerate(clean))
            check('actual_new_log_checkout_' + role, checkout)
            groups = []
            if role == 'owner':
                for index, line in enumerate(clean):
                    if '##[group]' + OWNER + ' — ' + OWNER_PROOF in line:
                        stop = next(i for i in range(index + 1, len(clean)) if '##[endgroup]' in clean[i])
                        groups.append({'start_line': index + 1, 'end_line': stop + 1,
                                       'lines': [{'line': i + 1, 'text': clean[i]} for i in range(index, stop + 1)]})
                check('actual_owner_group_matches_whole_new_log', groups == log['owner_groups'] and len(groups) == 1)
            log_rows.append({**record(relative), 'role': role, 'job_id': job['id'], 'job_name': job['name'],
                             'job_conclusion': job['conclusion'], 'endpoint': log['endpoint'], 'source_receipt': name,
                             'whole_raw_body_retained': True, 'line_count': len(clean), 'owner_groups': groups,
                             'selected_excerpt_representation': 'ANSI-stripped exact lines' if all(
                                 row['text'] == clean[row['line'] - 1] for row in log['selected_lines'])
                                 else 'Exact raw or ANSI-stripped lines; original JSON escapes retained'})
            logs_by_role[role] = {'metadata': log_rows[-1], 'clean_lines': clean, 'groups': groups}
    owner_result = None
    if 'owner' in logs_by_role:
        group = logs_by_role['owner']['groups'][0]
        results = []
        for row in group['lines']:
            match = re.search(r'\b(\d+) passed in ([0-9.]+)s\b', row['text'])
            if match:
                results.append({'passed': int(match.group(1)), 'seconds': match.group(2), **row})
        check('actual_owner_275_result_from_new_log', len(results) == 1 and results[0]['passed'] == 275)
        owner_result = {'command': COMMAND, 'proof_id': OWNER_PROOF, 'logical_job_id': OWNER, 'pack_index': 11,
                        'job_exec_sha256': planned[OWNER]['job_exec_sha256'], 'step_spec_sha256': planned[OWNER]['steps'][0]['step_spec_sha256'],
                        'hosted_job_id': hosted['ci-pack-11']['id'], 'actual_result': results[0], 'actual_result_group': group,
                        'actual_fragment_result': observed_jobs.get(OWNER), 'raw_log': logs_by_role['owner']['metadata']}
    contract_result = {'hosted': {k: hosted['contract-delta'][k] for k in ('id', 'status', 'conclusion')}}
    if 'contract_delta' in logs_by_role:
        log = logs_by_role['contract_delta']
        counts = []
        for index, line in enumerate(log['clean_lines']):
            match = re.search(r'contract-delta: (\d+) introduced, (\d+) inherited \(base ([0-9a-f]+)\)', line)
            if match:
                counts.append({'introduced': int(match.group(1)), 'inherited': int(match.group(2)),
                               'base_prefix': match.group(3), 'line': index + 1, 'text': line})
        check('actual_new_contract_count_and_base', len(counts) == 1 and BASE.startswith(counts[0]['base_prefix']))
        check('actual_new_contract_command', any('python scripts/check_contract_delta.py --base ' + BASE in line
                                                for line in log['clean_lines']))
        contract_result.update(actual_counts=counts[0], raw_log=log['metadata'],
                               actual_error_lines=[{'line': i + 1, 'text': line} for i, line in enumerate(log['clean_lines']) if '##[error]' in line])

    ci_gate_result = None
    if 'ci_gate' in logs_by_role:
        log = logs_by_role['ci_gate']
        summary_fields = {}
        for label in ('status', 'evidence', 'classifications', 'infrastructure findings'):
            pattern = re.compile(r'^\d{4}-\d\d-\d\dT[^ ]+Z - ' + re.escape(label) + r': `([^`]*)`$')
            matched = [{'line': i + 1, 'text': line, 'value': match.group(1)}
                       for i, line in enumerate(log['clean_lines']) if (match := pattern.fullmatch(line))]
            check('actual_ci_gate_single_summary_' + label, len(matched) == 1)
            summary_fields[label] = matched[0]
        check('actual_ci_gate_summary_matches_retained_aggregate', aggregate is not None
              and summary_fields['status']['value'] == aggregate['status']
              and summary_fields['evidence']['value'] == aggregate['evidence_sha256']
              and json.loads(summary_fields['classifications']['value']) == aggregate['classifications']
              and int(summary_fields['infrastructure findings']['value'])
                  == len(member_documents['ci-semantic-evidence.json']['document']['infrastructure']))
        check('actual_ci_gate_reconciler_command_observed', any(
            'python3 scripts/ci_semantic_proof.py reconcile' in line for line in log['clean_lines']))
        evidence_stdout = []
        for i, line in enumerate(log['clean_lines']):
            payload = line.partition('Z ')[2]
            if payload.startswith('{"authority_changed":'):
                parsed = loads(payload.encode('utf8'))
                if parsed.get('schema') == 'ci.semantic_evidence.v1':
                    evidence_stdout.append({'line': i + 1, 'payload': parsed,
                                            'stdout_json_bytes': len(payload.encode('utf8')),
                                            'stdout_json_sha256': sha(payload.encode('utf8'))})
        check('actual_ci_gate_full_stdout_equals_retained_aggregate', len(evidence_stdout) == 1
              and evidence_stdout[0]['payload'] == member_documents['ci-semantic-evidence.json']['document'])
        notices = [{'line': i + 1, 'text': line} for i, line in enumerate(log['clean_lines'])
                   if re.match(r'^\d{4}-\d\d-\d\dT[^ ]+Z ##\[notice\]', line)]
        clear_semantic = any(row['text'].endswith('complete semantic proof is clear') for row in notices)
        clear_contract = any(row['text'].endswith('contract-delta clear (result=success)') for row in notices)
        ci_gate_result = {'hosted_job_id': hosted['ci-gate']['id'],
                          'hosted_conclusion': hosted['ci-gate']['conclusion'],
                          'raw_log': log['metadata'], 'actual_summary_fields': summary_fields,
                          'actual_full_evidence_stdout': {key: value for key, value in evidence_stdout[0].items()
                                                          if key != 'payload'},
                          'actual_notice_lines': notices,
                          'actual_clear_semantic_notice': clear_semantic,
                          'actual_successful_contract_notice': clear_contract,
                          'hosted_steps': [{key: step[key] for key in ('name', 'status', 'conclusion', 'number')}
                                           for step in hosted['ci-gate']['steps']]}

    # Independently retain and verify the exact archival representation repair.
    correction_sources = []
    for item in mapping_capture['correction_sources']:
        path = 'correction_sources/' + item['local_name']
        raw = read(path)
        check('corrected_archive_source_transfer_' + item['local_name'],
              len(raw) == item['bytes'] and sha(raw) == item['sha256'] and git_blob(raw) == item['git_blob_sha']
              and gzip.decompress(base64.b64decode(item['content_gzip_base64'], validate=True)) == raw
              and item['ref'] in {HEAD, OLD} and item['returncode'] == 0)
        correction_sources.append({**record(path), 'ref': item['ref'], 'repository_path': item['repository_path'],
                                   'git_blob_sha': item['git_blob_sha']})
    mapping = doc('correction_sources/ARCHIVED_TEST_SOURCE_MAP.json')
    check('correction_map_original_checkpoint', mapping['observed_failed_candidate'] == OLD
          and mapping['original_checkpoint_commit'] == '6b58f15adae3b1d402d9993c52609d00083f1453'
          and len(mapping['records']) == 2)
    for number in (1, 2):
        old_raw = read(f'correction_sources/v{number}_old_test_source.py.txt')
        new_raw = read(f'correction_sources/v{number}_corrected_test_source.py.txt')
        row = next(r for r in mapping['records'] if r['version'] == number)
        check('v' + str(number) + '_exact_archival_bytes_and_map', old_raw == new_raw
              and row['byte_length'] == len(new_raw) and row['sha256'] == sha(new_raw)
              and row['archive_repo_path'] == row['original_logical_repo_path'] + '.txt'
              and row['last_original_path_checkpoint'] == OLD and row['relocation_only'] is True
              and row['current_executable_suite'] is False)
    check('canonical_suite_separately_bound', mapping['canonical_runtime_suite']['path'] == 'tests/test_company_relationship_observations.py'
          and mapping['canonical_runtime_suite']['sha256'] == 'a73700e639c8e97a4ff84951b48358abe63b1f5048560d03b0e40f2310ac44da'
          and mapping['canonical_runtime_suite']['path'] in COMMAND)

    # The separate preserved-data verifier independently checks the actual
    # complete Git trees, raw blob responses and all 53 selected source bytes.
    # Bind its frozen receipt here without importing application source.
    code_pin_proof = doc('SOURCE_PIN_VERIFICATION.json')
    check('separate_53_code_pin_receipt_frozen', record('SOURCE_PIN_VERIFICATION.json') == {
        'path': 'SOURCE_PIN_VERIFICATION.json', 'bytes': 17455,
        'sha256': 'f512c883f14d31565b249ebff8f653cae2f7969c91975d4d0eae2358b5821675'})
    check('separate_53_code_pin_exact_tested_identity', code_pin_proof['head'] == HEAD
          and code_pin_proof['tested_commit'] == TESTED
          and code_pin_proof['tested_git_tree'] == tested['tree']['sha'])
    check('separate_53_code_pin_exact_inputs',
          code_pin_proof['source_read_receipt'] == record('tested_source_pin_read_001.json')
          and code_pin_proof['verifier']['sha256'] == record('verify_tested_code_pins.py')['sha256']
          and all(code_pin_proof['reference_manifest'][key] == value
                  for key, value in record('context/EXPECTED_53_CODE_PINS.json').items()))
    check('separate_53_code_pin_success_and_scope', code_pin_proof['all_matches'] is True
          and code_pin_proof['status'] == 'ALL_53_ACCEPTED_CODE_BYTE_PINS_MATCH_ACTUAL_TESTED_TREE'
          and code_pin_proof['pinned_file_count'] == len(code_pin_proof['files']) == 53
          and code_pin_proof['unique_git_blob_count'] == 52
          and code_pin_proof['total_pinned_file_bytes'] == 1483905
          and all(row['matches_accepted_pin'] is True for row in code_pin_proof['files'])
          and code_pin_proof['application_imports_or_tests'] is False)

    run_completed = run['status'] == 'completed'
    contract_success = hosted['contract-delta']['conclusion'] == 'success'
    gate_success = hosted.get('ci-gate', {}).get('conclusion') == 'success'
    all_packs_success = all(hosted[f'ci-pack-{i}']['conclusion'] == 'success' for i in range(12))
    complete_pass = (run_completed and run['conclusion'] == 'success' and contract_success and gate_success
                     and all_packs_success and aggregate_reconciled and owner_result is not None
                     and 'contract_delta' in logs_by_role and ci_gate_result is not None
                     and ci_gate_result['actual_clear_semantic_notice']
                     and ci_gate_result['actual_successful_contract_notice'])
    disposition = ('CONCLUDED_RUN_PASS__COMPLETE_ALL_PASS_SEMANTIC_RECONCILIATION_VALID' if complete_pass else
                   'OBSERVED_EVIDENCE_VALID__WORKFLOW_OR_REQUIRED_PROOF_INCOMPLETE')
    if hosted['contract-delta']['conclusion'] == 'failure' or (run_completed and run['conclusion'] != 'success'):
        disposition = 'OBSERVED_CI_FAILURE__NO_PROMOTION'
    observed_inventory = [{'logical_job_id': jid, 'pack_index': planned[jid]['pack_index'],
                           'job_exec_sha256': planned[jid]['job_exec_sha256'], **step}
                          for (jid, proof), step in observed_units.items()]
    out = {'schema': 'gmi.pr8711.corrected_independent_ci_evidence_review/v1',
           'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'reviewer': '/root/ci_release_evidence',
           'identity': identity, 'tested_commit_parents': [BASE, HEAD], 'tested_commit_tree_sha': tested['tree']['sha'],
           'candidate_parent': OLD, 'snapshot_file': args.snapshot,
           'observation_completed_at_utc': snapshot['completed_at_utc'], 'disposition': disposition,
           'verification': {'assertions_evaluated': len(checks), 'assertions_passed': sum(checks.values()),
                            'all_observed_byte_identity_inventory_and_source_checks_passed': all(checks.values()),
                            'assertions': checks, 'verifier': record('verify_corrected_artifacts.py'), 'yaml_version': yaml.__version__,
                            'repository_code_imported_or_executed': False},
           'denominators': {'expected_complete_artifacts': 15, 'observed_retained_artifacts': len(artifact_rows),
                            'planned_packs': 12, 'observed_fragments': len(observed_packs),
                            'all_manifest_jobs': 254, 'manifest_code_jobs': 182, 'manifest_other_gate_jobs': 72,
                            'selected_jobs': 98, 'explicitly_excluded_code_jobs': 84, 'observed_jobs': len(observed_jobs),
                            'planned_proof_steps': 316, 'observed_proof_steps': len(observed_units), 'changed_paths': 125},
           'completeness': {'missing_packs': missing_packs, 'missing_jobs': missing_jobs, 'missing_units': missing_units,
                            'missing_artifact_names': sorted(expected_names - {r['name'] for r in by_id.values()}),
                            'all_available_api_artifacts_retained': True, 'final_aggregate_observed': aggregate is not None,
                            'aggregate_independently_reconciled': aggregate_reconciled, 'run_concluded': run_completed,
                            'owner_result_observed': owner_result is not None,
                            'contract_log_observed': 'contract_delta' in logs_by_role,
                            'ci_gate_log_observed': 'ci_gate' in logs_by_role,
                            'complete_ci_pass_evidence': complete_pass},
           'observed_outcomes': dict(collections.Counter(s['outcome'] for s in observed_units.values())),
           'all_observed_semantic_units_passed': all_observed_passed, 'observed_infrastructure_findings': infrastructure,
           'artifact_inventory': artifact_rows, 'fragment_inventory': fragment_rows,
           'manifest': {**record('sources/merged_legacy_jobs.yml'), 'git_blob_sha': MANIFEST_BLOB, 'ref': TESTED,
                        'all_job_inventory': [{'logical_job_id': jid, 'gate': definition.get('gate', 'code'),
                            'selected': jid in planned, 'explicitly_excluded_code_job': jid in plan['skipped_jobs']}
                            for jid, definition in definitions.items()],
                        'code_job_ids': code_ids, 'selected_job_ids': list(planned), 'excluded_code_job_ids': plan['skipped_jobs']},
           'source_law_inventory': source_rows, 'plan': {'raw': record(plan_entry['path']), 'logical_sha256': PLAN_LOGICAL_SHA,
                        'changed_files_sha256': plan['changed_files_sha256'], 'changed_files': changed,
                        'packs': plan['packs'], 'source_semantics': source_semantics},
           'fully_enumerated_observed_units': observed_inventory, 'observed_units_canonical_sha256': digest(observed_inventory),
           'aggregate': aggregate, 'owner': owner_result, 'owner_source_scope_paths': definitions[OWNER]['paths'],
           'contract_delta': contract_result, 'ci_gate': ci_gate_result, 'whole_log_inventory': log_rows,
           'hosted_run': {k: run[k] for k in ('id', 'run_attempt', 'status', 'conclusion', 'head_sha', 'updated_at', 'html_url')},
           'hosted_jobs': [{'id': j['id'], 'name': j['name'], 'status': j['status'], 'conclusion': j['conclusion'],
                            'started_at': j['started_at'], 'completed_at': j['completed_at'], 'html_url': j['html_url']}
                            for j in snapshot['jobs']['jobs']],
           'exact_head_checks': [{'id': c['id'], 'name': c['name'], 'status': c['status'], 'conclusion': c['conclusion'],
                                 'head_sha': c['head_sha'], 'details_url': c['details_url']} for c in snapshot['checks']['check_runs']],
           'source_correction': {'sources': correction_sources, 'both_archival_renames_exact_bytes_verified': True,
                                 'map': record('correction_sources/ARCHIVED_TEST_SOURCE_MAP.json'),
                                 'upstream_compare_observed_file_count': len(mapping_capture['upstream_compare']['files']),
                                 'upstream_compare_complete': False,
                                 'upstream_compare_limit_reason': 'GitHub compare file listing reached its 300-file cap; not a full source-overlap census'},
           'accepted_application_byte_pins': {
                'receipt': record('SOURCE_PIN_VERIFICATION.json'),
                'source_read_receipt': code_pin_proof['source_read_receipt'],
                'reference_manifest': code_pin_proof['reference_manifest'],
                'verifier': record('verify_tested_code_pins.py'),
                'tested_commit': TESTED, 'tested_git_tree': tested['tree']['sha'],
                'pinned_file_count': 53, 'unique_git_blob_count': 52,
                'total_pinned_file_bytes': 1483905, 'all_match_accepted_pins': True,
                'proof_limits': code_pin_proof['proof_limits']},
           'input_receipts': [record(name) for name in ['candidate_discovery_001.json', 'run_snapshot_and_sources_001.json',
                                'mapping_and_snapshot_002.json', 'SOURCE_PIN_VERIFICATION.json',
                                'tested_source_pin_read_001.json', 'context/EXPECTED_53_CODE_PINS.json',
                                *[n for n, c in captures]]],
           'proof_limits': ['This audit is not merge authorization or canonical release-helper adjudication.',
                'Old-run test outcomes are not inputs to the corrected-run conclusion; the old packet remains frozen.',
                'The plan partition and exact source digests are checked; the full scope-selection planner is not rerun.',
                'The GitHub PR base field lagged the actual tested synthetic parent; plan, immutable commit and checkout evidence bind the actual base.',
                'All 53 accepted engine/lib source byte pins independently match the actual tested Git tree. This is byte compatibility, not a new functional review or certification of the other 18 owner scope paths; the complete upstream changed-file census remains capped.',
                'Non-all-pass aggregate reconciliation is not claimed by this all-pass verifier; any such result remains explicit and requires review.',
                'Current main freshness, live holds, rights, history, fact, Graph1, production and predictive promotion are outside this audit.'],
           'authority': {'merge_authorized': False, 'gate_waiver': False, 'native_or_git_mutations': False,
                         'workflow_dispatch_rerun_or_cancellation': False, 'application_imports_or_tests': False,
                         'live_freshness_or_holds_certified': False}}
    target = ROOT / safe(args.output)
    assert target.parent == ROOT and not target.exists()
    with target.open('x', encoding='utf8') as handle:
        json.dump(out, handle, indent=2, sort_keys=True, ensure_ascii=False)
        handle.write('\n')
    print(json.dumps({'file': str(target), 'bytes': target.stat().st_size, 'sha256': sha(target.read_bytes()),
                      'disposition': disposition, 'assertions': len(checks), 'denominators': out['denominators'],
                      'observed_outcomes': out['observed_outcomes'], 'missing_packs': missing_packs,
                      'aggregate': {key: aggregate.get(key) for key in ('status', 'evidence_sha256')} if aggregate else None,
                      'owner_result': owner_result['actual_result'] if owner_result else None}, indent=2))


if __name__ == '__main__':
    main()
