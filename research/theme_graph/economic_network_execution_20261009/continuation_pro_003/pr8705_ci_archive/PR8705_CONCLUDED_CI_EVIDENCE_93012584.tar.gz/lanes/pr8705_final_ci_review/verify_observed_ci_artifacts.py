#!/usr/bin/env python3
"""Independent, scratch-only all-pass artifact census; does not invoke repository code.

Reads captured bytes. Missing final proof stays pending. This is an audit aid,
not a replacement release helper or a producer of GitHub semantic evidence.
"""
import argparse
import collections
import datetime
import hashlib
import json
from pathlib import Path
import unicodedata


ROOT = Path(__file__).resolve().parent
PLAN_PATH = ROOT.parent / 'pr8705_release_audit_evidence/ci-plan.json'
CHANGED_PATH = ROOT.parent / 'pr8705_release_audit_evidence/changed-files.json'
HEAD = '930125848136f08efd1bb61cc5899d9a5a0eeb51'
BASE = '4d736c55adb630a4a8eb11b261e31acd0f6dc48b'
TESTED = '04c56e0092ca2f5158a7020acacae003bf8d6098'
RUN = '37915994513'
OWNER = 'company-relationship-candidates'
COMMAND = 'python -m pytest tests/test_company_relationship_candidates.py tests/test_company_pinned_relationship_candidates.py tests/test_company_relationship_review_set.py -q'


def canonical(value, *, ascii=False):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=ascii).encode('utf8')


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def strict_load(path):
    raw = path.read_bytes()
    assert len(raw) <= 8 * 1024 * 1024
    def pairs(items):
        out = {}
        for key, value in items:
            assert key not in out, ('duplicate key', key)
            out[key] = value
        return out
    return json.loads(raw.decode('utf8', 'strict'), object_pairs_hook=pairs)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--snapshot', required=True)
    p.add_argument('--output', required=True)
    p.add_argument('--aggregate')
    a = p.parse_args()
    checks = {}
    def check(name, condition):
        checks[name] = bool(condition)
        assert condition, name

    plan = strict_load(PLAN_PATH)
    changed = strict_load(CHANGED_PATH)
    check('raw_plan_sha256', hashlib.sha256(PLAN_PATH.read_bytes()).hexdigest() == '4c1d87d65f4deb353075556c6ab25bcacfcf918d4924f8f934ef5e99ff74cb92')
    check('identity', (plan['workflow_run_id'], plan['workflow'], plan['event'], plan['role'], plan['subject_head_sha'], plan['base_sha'], plan['tested_tree_sha']) == (RUN, 'ci', 'pull_request', 'pr_head', HEAD, BASE, TESTED))
    identity = {k: plan[k] for k in ('workflow_run_id','workflow','event','role','tested_tree_sha','subject_head_sha','base_sha','plan_sha256')}
    check('schema', plan['schema'] == 'ci.pack_plan.v2')
    check('changed_list_digest', digest(changed) == plan['changed_files_sha256'])
    check('changed_count', len(changed) == len(set(changed)) == plan['changed_files_count'] == 30)
    payload = {k: plan[k] for k in ('schema','workflow_run_id','workflow','event','role','tested_tree_sha','subject_head_sha','base_sha','authority_changed','changed_from','scope_mode','changed_files_sha256')}
    payload.update(pack_count=len(plan['packs']), eligible_job_ids=plan['eligible_jobs'], pack_jobs=[x['jobs'] for x in plan['packs']], pack_weights=[x['weight'] for x in plan['packs']], semantic_jobs=plan['semantic_jobs'])
    check('logical_plan_digest', digest(payload) == plan['plan_sha256'])
    planned = {j['logical_job_id']: j for j in plan['semantic_jobs']}
    check('job_inventory_order_unique', list(planned) == plan['eligible_jobs'] and len(planned) == len(plan['semantic_jobs']) == plan['eligible_job_count'] == 99)
    check('excluded_count_and_partition', len(plan['skipped_jobs']) == len(set(plan['skipped_jobs'])) == plan['skipped_job_count'] == 82 and not set(plan['skipped_jobs']) & set(planned) and plan['legacy_job_count'] == 181)
    check('exact_pack_set', [x['index'] for x in plan['packs']] == list(range(12)) == plan['nonempty_pack_indices'])
    check('matrix', plan['matrix'] == {'include': [{'pack': i} for i in range(12)]})
    partition = [n for x in plan['packs'] for n in x['jobs']]
    check('pack_partition', len(partition) == len(set(partition)) == 99 and set(partition) == set(planned))
    expected_steps = {}
    for j in planned.values():
        check('plan_pack_'+j['logical_job_id'], j['logical_job_id'] in plan['packs'][j['pack_index']]['jobs'])
        for s in j['steps']:
            key = (j['logical_job_id'], s['proof_id'])
            check('unique_plan_unit_'+str(key), key not in expected_steps)
            expected_steps[key] = s
    check('expected_steps', len(expected_steps) == 324)

    observed, units, packs, pack_rows = {}, {}, set(), []
    fragment_keys = {'schema', *identity, 'pack_index', 'infrastructure', 'jobs'}
    for path in sorted(ROOT.glob('pack-*.json'), key=lambda x: int(x.stem.split('-')[1])):
        f = strict_load(path)
        i = f['pack_index']
        check('fragment_shape_'+str(i), set(f) == fragment_keys and f['schema'] == 'ci.semantic_fragment.v1')
        check('fragment_identity_'+str(i), all(f[k] == v for k, v in identity.items()))
        check('fragment_unique_pack_'+str(i), i not in packs and i in range(12) and path.name == f'pack-{i}.json')
        packs.add(i)
        check('fragment_infrastructure_'+str(i), f['infrastructure'] == [])
        check('fragment_job_partition_'+str(i), sorted(j['logical_job_id'] for j in f['jobs']) == sorted(plan['packs'][i]['jobs']))
        count = 0
        for j in f['jobs']:
            jid = j['logical_job_id']
            check('job_shape_'+jid, set(j) == {'logical_job_id','job_exec_sha256','infrastructure','steps'})
            check('job_binding_'+jid, jid not in observed and j['job_exec_sha256'] == planned[jid]['job_exec_sha256'] and planned[jid]['pack_index'] == i)
            check('job_infrastructure_'+jid, j['infrastructure'] == {'outcome': 'passed'})
            check('job_step_order_'+jid, [s['proof_id'] for s in j['steps']] == [s['proof_id'] for s in planned[jid]['steps']])
            observed[jid] = j
            for s in j['steps']:
                key = (jid, s['proof_id'])
                check('unit_shape_'+str(key), set(s) == {'proof_id','step_spec_sha256','outcome','failure_signature'})
                check('unit_binding_'+str(key), key not in units and s['step_spec_sha256'] == expected_steps[key]['step_spec_sha256'] and s['proof_id'] == ' '.join(unicodedata.normalize('NFC',s['proof_id']).split()))
                check('unit_result_'+str(key), s['outcome'] == 'passed' and s['failure_signature'] is None)
                units[key] = s
                count += 1
        pack_rows.append({'pack':i,'jobs':len(f['jobs']),'proof_steps':count,'raw_bytes':path.stat().st_size,'raw_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'outcome':'all_observed_passed'})

    check('owner_step_command_digest', digest({'run': COMMAND}) == planned[OWNER]['steps'][0]['step_spec_sha256'])
    actions = [{'uses':'actions/checkout@v4','with':{}},{'uses':'actions/setup-python@v5','with':{'python-version':'3.12'}}]
    action_hash = hashlib.sha256(canonical(actions,ascii=True)).hexdigest()
    owner_exec_payload = {'dependency_install_command':'pip install pytest pyyaml requests','timeout_minutes':None,'runner_contract':f'ci-pack/linux-x86_64/python-3.12.13/node-20/v2/actions-{action_hash}'}
    check('owner_execution_contract_digest', digest(owner_exec_payload) == planned[OWNER]['job_exec_sha256'])

    snap = strict_load(ROOT/a.snapshot)
    check('snapshot_pagination_complete', snap['jobs']['total_count'] == len(snap['jobs']['jobs']) < 100 and snap['checks']['total_count'] == len(snap['checks']['check_runs']) < 100 and snap['artifacts']['total_count'] == len(snap['artifacts']['artifacts']) < 100)
    check('snapshot_subject', snap['run']['id'] == int(RUN) and snap['run']['run_attempt'] == 1 and snap['run']['head_sha'] == HEAD and snap['run']['event'] == 'pull_request')
    check('all_check_subjects', all(c['head_sha'] == HEAD for c in snap['checks']['check_runs']))
    job_rows = [{'id':j['id'],'name':j['name'],'status':j['status'],'conclusion':j['conclusion'],'completed_at':j['completed_at']} for j in snap['jobs']['jobs']]
    hosted_packs = [j for j in job_rows if j['name'].startswith('ci-pack-')]
    check('hosted_all_twelve_scheduled', sorted(j['name'] for j in hosted_packs) == sorted(f'ci-pack-{i}' for i in range(12)))
    aggregate = None
    if a.aggregate:
        check('all_fragments_before_aggregate', packs == set(range(12)) and len(observed) == 99 and len(units) == 324)
        e = strict_load(ROOT/a.aggregate)
        expected_jobs = []
        for j in planned.values():
            o = observed[j['logical_job_id']]
            expected_jobs.append({'logical_job_id':j['logical_job_id'],'pack_index':j['pack_index'],'job_exec_sha256':j['job_exec_sha256'],'infrastructure':o['infrastructure'],'steps':[dict(s,classification='passed') for s in o['steps']]})
        expected_e = {'schema':'ci.semantic_evidence.v1',**identity,'authority_changed':plan['authority_changed'],'status':'clear','jobs':expected_jobs,'infrastructure':[]}
        expected_e['evidence_sha256'] = digest(expected_e)
        check('aggregate_exact_reconciliation', e == expected_e)
        aggregate = {'file':a.aggregate,'raw_bytes':(ROOT/a.aggregate).stat().st_size,'raw_sha256':hashlib.sha256((ROOT/a.aggregate).read_bytes()).hexdigest(),'evidence_sha256':e['evidence_sha256'],'status':e['status'],'job_count':len(e['jobs']),'proof_steps':sum(len(j['steps']) for j in e['jobs']),'classifications':dict(collections.Counter(s['classification'] for j in e['jobs'] for s in j['steps']))}

    out = {'schema':'gmi.pr8705.independent_ci_artifact_review/v1','created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/ci_release_evidence','identity':identity,'disposition':'ALL_OBSERVED_FRAGMENTS_VALID_OVERALL_PENDING' if aggregate is None else 'ALL_ARTIFACT_BINDINGS_AND_ALL_PASS_RECONCILIATION_VALID','checks_run':len(checks),'checks_passed':sum(checks.values()),'all_checks_pass':all(checks.values()),'denominators':{'planned_packs':12,'planned_logical_jobs':99,'planned_proof_steps':324,'planner_inventory':181,'planner_excluded_jobs':82},'observed':{'packs':len(packs),'logical_jobs':len(observed),'proof_steps':len(units),'outcomes':{'passed':len(units)},'missing_packs':sorted(set(range(12))-packs),'missing_jobs':sorted(set(planned)-set(observed))},'pack_results':pack_rows,'observed_units_canonical_sha256':digest([{'job':k[0],**v} for k,v in sorted(units.items())]),'owner':{'logical_job_id':OWNER,'pack_index':8,'command':COMMAND,'step_spec_sha256':digest({'run':COMMAND}),'action_contract':actions,'action_contract_sha256':action_hash,'execution_contract_payload':owner_exec_payload,'job_exec_sha256':digest(owner_exec_payload),'fragment_result':observed[OWNER]},'snapshot_file':a.snapshot,'snapshot_completed_at_utc':snap['completed_at_utc'],'hosted_run':{k:snap['run'][k] for k in ('id','run_attempt','status','conclusion','head_sha','updated_at')},'hosted_jobs':job_rows,'aggregate':aggregate,'authority':{'merge_authorized':False,'live_freshness_verified':False,'live_holds_verified':False,'native_postmerge_proof':False,'application_code_review':False,'native_application_imports_or_tests':False}}
    target=ROOT/a.output
    with target.open('x',encoding='utf8') as f:
        json.dump(out,f,indent=2,ensure_ascii=False);f.write('\n')
    print(json.dumps({'file':str(target),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'disposition':out['disposition'],'checks_run':len(checks),'observed':out['observed'],'aggregate':aggregate},indent=2))


if __name__ == '__main__':
    main()
