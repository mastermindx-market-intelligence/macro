# PR #8705 — concluded CI evidence review

**Disposition: PASS_BOUNDED_CONCLUDED_CI_EVIDENCE.**

The actual hosted CI run concluded successfully. All twelve scheduled pack artifacts account for **99 of 99 selected logical jobs and 324 of 324 planned proof steps**, all passed. The final semantic evidence document is exactly the independently reconstructed result of those artifacts and the authoritative plan. It has no missing, inherited, unknown, regression or infrastructure findings. The relationship owner job’s hosted log independently reports **215 passed in 5.81 seconds**.

This completes the bounded concluded-CI evidence review. It supplies no merge authorization. The principal session retains the live protected-source, base freshness, hold/review, expected-head release and accepted-source/native replay gates.

Reviewer: `/root/ci_release_evidence`. Date: 9 October 2026. All native actions in this review were read-only. Scratch analysis did not import or execute repository application code, CI packs, tests, acquisition code or replay harnesses.

## 1. Exact subject and final observation

| Binding | Observed value |
|---|---|
| Pull request | [#8705](https://github.com/mastermindx-market-intelligence/macro/pull/8705) |
| CI run | [37915994513](https://github.com/mastermindx-market-intelligence/macro/actions/runs/37915994513), attempt 1 |
| Workflow / event / role | `ci` / `pull_request` / `pr_head` |
| Subject head | `930125848136f08efd1bb61cc5899d9a5a0eeb51` |
| Authoritative plan base | `4d736c55adb630a4a8eb11b261e31acd0f6dc48b` |
| Plan `tested_tree_sha` field | `04c56e0092ca2f5158a7020acacae003bf8d6098` |
| Final metadata read | 10:43:22.529466–10:43:25.739047 UTC |
| Last artifact-byte read completed | 10:45:15.569648 UTC |
| Run conclusion | `completed` / `success`; run metadata updated at 10:40:25 UTC |

The `tested_tree_sha` field identifies the synthetic merge commit, as established by the preceding independent plan audit; it is not the accepted merge commit or a claim that the field contains a Git tree-object ID. The earlier audit identifies its tree object as `c26fd190c8bb13f8087753bc2a51df3d22872739` and its exact two parents as base and subject head. This review checked the same field in every plan, fragment and final evidence identity.

The complete final native REST snapshot contains 16 workflow jobs, 26 head check runs and 15 run artifacts. Each endpoint used `per_page=100`; returned lengths equal the corresponding reported totals, so no later page was omitted. Every observed check run identifies the exact subject head and GitHub Actions application ID 15368. Metadata source hashes and the full returned structures are retained in `native_snapshot_002.json`.

## 2. Concluded hosted gates

All scheduled pack jobs and their `validate and run legacy CI pack` execution step concluded successfully. The full partition is:

| Pack | Logical jobs | Proof steps | Hosted job ID | Completion UTC | Result |
|---:|---:|---:|---:|---|---|
| 0 | 1 | 16 | `113773386396` | 10:30:21 | Success; all planned fragment steps passed |
| 1 | 1 | 1 | `113773386190` | 10:23:55 | Success; all planned fragment steps passed |
| 2 | 6 | 11 | `113773386202` | 10:22:05 | Success; all planned fragment steps passed |
| 3 | 10 | 35 | `113773386322` | 10:23:36 | Success; all planned fragment steps passed |
| 4 | 10 | 30 | `113773386220` | 10:31:57 | Success; all planned fragment steps passed |
| 5 | 10 | 34 | `113773386314` | 10:27:20 | Success; all planned fragment steps passed |
| 6 | 10 | 40 | `113773386312` | 10:40:13 | Success; all planned fragment steps passed |
| 7 | 10 | 22 | `113773386344` | 10:30:05 | Success; all planned fragment steps passed |
| 8 | 10 | 36 | `113773386336` | 10:26:06 | Success; all planned fragment steps passed |
| 9 | 10 | 19 | `113773386250` | 10:32:37 | Success; all planned fragment steps passed |
| 10 | 10 | 41 | `113773386374` | 10:27:13 | Success; all planned fragment steps passed |
| 11 | 11 | 39 | `113773386417` | 10:23:39 | Success; all planned fragment steps passed |

The denominator is **the actual scoped plan**: 181 planner jobs, 99 selected and 82 excluded. The 324 count denotes semantic proof steps, which can each contain many individual tests or guards. It is not a claim of 324 individual pytest tests, a complete repository-wide test census, or a new 181-definition census of every legacy manifest entry.

The remaining relevant hosted conclusions are:

| Check or job | ID | Conclusion |
|---|---:|---|
| `ci-plan` | `113772185089` | Success at 10:14:18 UTC |
| `contract-delta` | `113772184727` | Success at 10:22:17 UTC |
| `ci-gate` | `113782137166` | Success at 10:40:24 UTC |
| `fence-pack` | `113772182575` | Success |
| `self-mod-fence` | `113772546104` | Success |
| `capability-broker` | `113772548964` | Success |
| `grader-manifest` | `113772551759` | Success |
| Active `ci-authority/main` | `113772249652` | Success |
| Generic `ci-authority` workflow job | `113772184025` | Success |

The final check census has 21 successes, four conditional skips and one failure. The skips are `trusted-ci` and three unused fork-fence expressions. The failure is the exact inactive `ci-authority/codex/merge-queue-pilot` context, check `113772246437`. Its actual output records `context_active=false`, `context_allowed=false` and `context_reason=inactive_base_context`; the underlying authority decision remains allowed. The active main context records `context_active=true`, `context_allowed=true`, the exact base/head, 30 changed files and one authority hit, `.github/ci/legacy-jobs.yml`.

The unchanged current `is_non_binding_check` source excludes this exact inactive pilot context for main-target PRs while keeping active main authority binding. That pre-existing rule is the reason the inactive context is not a failed gate here. This review introduced no new allowlist, waiver or status reinterpretation. All actually scheduled pack anchors, `ci-gate` and the applicable fence anchor have affirmative success; conditional skips do not substitute for them. [Release helper source](https://github.com/mastermindx-market-intelligence/macro/blob/930125848136f08efd1bb61cc5899d9a5a0eeb51/scripts/merge_on_green.py)

## 3. Artifact bytes and complete semantic accounting

All **15 of 15 artifact ZIPs** were read and hashed; their byte lengths and SHA-256 values match the actual GitHub artifact metadata. They contain exactly one expected JSON member each. All members were read fully, with CRC validation during ZIP extraction, and their exact bytes are retained. The total is 96,288 ZIP bytes and 284,398 JSON-member bytes. The artifact inventory contains each artifact ID, stable REST endpoint, creation/update/expiry times, ZIP/member sizes and both hashes.

The decisive identities are:

| Evidence | Bytes | SHA-256 |
|---|---:|---|
| Authoritative plan ZIP, artifact `11608754261` | 30,989 | `42eabf12152cd190ad6d2d4ea2db5eb95e9e329752cff4e0586b87b81d04f889` |
| `ci-plan.json` | 97,293 | `4c1d87d65f4deb353075556c6ab25bcacfcf918d4924f8f934ef5e99ff74cb92` |
| Pack 8 ZIP, artifact `11611015908` | 3,835 | `b498d70861b03e45efc614f3a1c2d5cdbe594a7f0bf6589e850d612663d4c12a` |
| `pack-8.json` | 9,664 | `d5d7b55dceaad7b7cf15d1612c94d03fd9fdfc908f3f0a9ccffc642f1bf44f0c` |
| Pack 6 ZIP, artifact `11610309828` | 4,338 | `c9a7c66934960927312607d81fc4f04aac06c33f944c2b7007d0c8a468b3aabc` |
| `pack-6.json` | 10,909 | `63df19bc2097951187f2dbf4e990e1a65794425172a0611378ee02e8187d2793` |
| Final evidence ZIP, artifact `11611168469` | 28,383 | `71eaa2c409eb766501ce0ebc09a9a7beda42c0812a5a80012e7297b53bb22227` |
| `ci-semantic-evidence.json` | 94,642 | `7f6fd60c5e3f2503ca9cd0cc8deb39ea0fccbe503a655e65aaff77de17599d11` |

The canonical plan digest independently recomputes as `5ef042a876c902b7c201374bcace6a50130e742b537f8e360ef66c10263a8eb5`. The canonical 30-path list digest independently recomputes as `f70ea32e334617750bc1305aed621eb8f83e021015f3b88e84f2e9b417cbbaf2`.

The verifier independently checked strict UTF-8 JSON without duplicate keys, closed observed fragment/job/step shapes, unique packs/jobs/proof IDs, exact pack membership, all eight shared identity fields, every job-execution digest, every step-spec digest, canonical proof IDs, exact expected step ordering, passed outcomes and null failure signatures. The full fragment set partitions the selected plan exactly. Every job infrastructure object is `{"outcome":"passed"}` and every fragment-level infrastructure list is empty.

For the final comparison, the audit reconstructed the expected all-pass document from the authoritative plan order and the actual fragment values, added the required `passed` classifications, recomputed its canonical digest, and compared the **entire document** with the actual downloaded final artifact. It did not accept a displayed green check, an artifact name or a self-reported status string as sufficient evidence.

The final document has schema `ci.semantic_evidence.v1`, status `clear`, 99 jobs, 324 `passed` classifications and no infrastructure rows. Its independently recomputed logical evidence digest is **`8ece88df014de230f2c2817d2489777ba78953ef757e72b7ca99b5c7f14047d6`**. Because every proof passed, this authority-changing candidate is not using inherited-base attribution to excuse a failure. [Canonical evidence contract](https://github.com/mastermindx-market-intelligence/macro/blob/930125848136f08efd1bb61cc5899d9a5a0eeb51/scripts/ci_semantic_proof.py)

The hosted `ci-gate` additionally records successful reconciliation at 10:40:21 UTC, successful final-artifact publication at 10:40:22 UTC and successful semantic-verdict enforcement at 10:40:22 UTC. The overall job concluded at 10:40:24 UTC. [Workflow definition](https://github.com/mastermindx-market-intelligence/macro/blob/930125848136f08efd1bb61cc5899d9a5a0eeb51/.github/workflows/ci.yml)

## 4. Relationship owner command, environment and actual test result

`company-relationship-candidates` occurs exactly once in the plan, pack 8 and final evidence. Its sole semantic proof is `File and pinned-source replay, manual boundary and temporal refusals`. The complete frozen manifest command is:

```bash
python -m pytest tests/test_company_relationship_candidates.py tests/test_company_pinned_relationship_candidates.py tests/test_company_relationship_review_set.py -q
```

The step-spec digest independently recomputes from that execution command as `1e3eb9cc27c0b74d65a3844fcee0f9b0b51725e799ffe7f174bb3484146cfc1a`, exactly matching the plan, raw fragment and final evidence.

This review also independently regenerated the job-execution digest, which the preceding audit had only recorded. The actual frozen action contract is checkout v4 with no inputs and setup-python v5 with `python-version: "3.12"`. Its action-contract digest is `256213cd4b602a01ce7f16297e77ced65318b7340bcf5001c2d42c280d7cf8a2`. The dependency command is `pip install pytest pyyaml requests`, manifest timeout is null, and the source-defined runner contract is `ci-pack/linux-x86_64/python-3.12.13/node-20/v2` followed by that action digest. Their canonical job digest recomputes to `5ff9e1dd799a76ff34ad59e95d95cafbc10cea6c6f4cb58da6922bb28801ff6f`, again exactly matching all three artifacts. [Frozen owner manifest](https://github.com/mastermindx-market-intelligence/macro/blob/930125848136f08efd1bb61cc5899d9a5a0eeb51/.github/ci/legacy-jobs.yml) · [Runner contract](https://github.com/mastermindx-market-intelligence/macro/blob/930125848136f08efd1bb61cc5899d9a5a0eeb51/scripts/run_ci_pack.py)

The full actual Actions log HTTP body for job `113773386336` was read into memory: 196,920 bytes, SHA-256 `4e3c6fea956ec8643adf47c9a37134aab7422a7a3620aa4ade38697cb99fa977`. The owner group starts at log line 1897, 10:25:11.3604722 UTC. Its result at line 1901, 10:25:17.5391481 UTC, is `215 passed in 5.81s`; the group then closes. The exact command comes from the hash-bound manifest/fragment chain; the log supplies the actual named-group execution and test count.

Only bounded, ANSI-stripped and JSON-escaped selected log lines are retained in `owner_job_log_read_003.json`. The full raw log body was hashed but was not saved. The report does not claim a total individual-test count for the other 98 selected logical jobs.

## 5. Read failures, state progression and limits

The initial 10:38:46–10:38:51 UTC snapshot had eleven successful packs, pack 6 still running and no final gate. The first fragment receipt truthfully records 89 observed jobs and 284 steps, with pack 6’s ten jobs and forty steps missing from the retained fragment set. That receipt is preserved as an intermediate observation; later success does not rewrite its provenance. The final run completed before the second read, and the final artifact comparison includes pack 6.

One combined source/log read, native PID `62965`, exited 1 because `gh` refused to emit a log containing terminal escape sequences. The exact CLI diagnostic was captured in a separate read, PID `65538`. The source observation was recovered independently. A subsequent GET, PID `67809`, directed explicitly permitted raw bytes only into an in-memory subprocess PIPE; selected emitted lines had ANSI removed and remaining controls JSON-escaped. That process exited 0. No raw log controls were written to a terminal, no native file was written, and no authentication or authorization restriction was bypassed. Both the failed read and the successful, constrained read are preserved.

All ten native process outcomes are reconciled in the companion JSON: `57249`, `62750`, `65538`, `67809`, `70241`, `73425`, `75392`, `75590` and `81533` exited 0; `62965` exited 1 as just described. The scripts and purposes are retained in `native_read_scripts.json`. No process remains pending.

The preceding independent audit and its protected-law/hold findings were read, including its correction of the inapplicable stale-main diagnostic. That correction remains valid within its stated green-baseline condition: this review did not invoke the red-baseline recovery helper, manufacture a baseline blocker, dispatch a new run or reinterpret its earlier diagnostic failure as a pass. The principal owns the current baseline and protected procedure checks.

This report does not independently certify application code, another reviewer’s replay-harness logic, source custody, rights, canonical issuer identity, historical admissibility, served-product behavior or predictive value. It does not clear unrelated or previously uncertain host actions. It does not refresh PR holds, reviews, threads or action-time base identity. It does not prove an accepted merge or postmerge native execution.

## 6. Preserved files and reproducibility

The complete structured result is `PR8705_CONCLUDED_CI_EVIDENCE_REVIEW.json`. The focused comparison receipt is `full_artifact_verification_002.json` (9,278 bytes; SHA-256 `a66a5bfb0b65071fa507358534f0ef599df9e06509ca5427fda8ae3cd5df0143`). `artifact_inventory_001.json` records all fifteen archives and members (15,541 bytes; SHA-256 `28dd66db16a339d5252b5020eac5228aa96c15b274be2215addf7f60fc02b475`).

`verify_observed_ci_artifacts.py` is a scratch audit utility that reads already captured JSON; it does not import repository application modules or run tests. Its exact invocation was:

```bash
python -B lanes/pr8705_final_ci_review/verify_observed_ci_artifacts.py \
  --snapshot native_snapshot_002.json \
  --aggregate ci-semantic-evidence.json \
  --output full_artifact_verification_002.json
```

The output path is create-only; use a new receipt filename to reproduce it. The plan and changed-file members live in the preceding `lanes/pr8705_release_audit_evidence/` directory; their paths and hashes are explicit in the inventory. Other raw members and all newly downloaded ZIPs live alongside this report. The artifact metadata reported a fourteen-day retention window, so durable publication should preserve the retained bytes, not rely solely on future availability of GitHub artifact URLs.

**Bounded CI evidence review complete. The principal may use this evidence in its live release adjudication; the report itself grants no release authority.**
