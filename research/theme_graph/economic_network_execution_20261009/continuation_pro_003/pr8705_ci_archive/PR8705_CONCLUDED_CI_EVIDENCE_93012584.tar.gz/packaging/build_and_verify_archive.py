#!/usr/bin/env python3
"""Create-only, deterministic packaging and scratch verification of frozen CI evidence."""
import argparse
import datetime
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import tarfile
from urllib.parse import parse_qsl, urlsplit
import zipfile
import zlib


ARCHIVE = 'PR8705_CONCLUDED_CI_EVIDENCE_93012584.tar.gz'
MANIFEST = 'PR8705_CONCLUDED_CI_EVIDENCE_MANIFEST.json'
RECEIPT = 'PACKAGING_VERIFICATION_RECEIPT.json'
HEAD = '930125848136f08efd1bb61cc5899d9a5a0eeb51'
MAX_FILE_BYTES = 8 * 1024 * 1024
MAX_PAYLOAD_BYTES = 16 * 1024 * 1024
URL_RE = re.compile(r'''https?://[^\s<>"']+''')
FORBIDDEN_QUERY_KEYS = {
    'sig', 'signature', 'token', 'access_token', 'auth', 'authorization',
    'x-amz-signature', 'x-amz-credential', 'x-amz-security-token',
    'x-goog-signature', 'x-goog-credential', 'googleaccessid',
    'awsaccesskeyid', 'key-pair-id', 'policy',
}
CREDENTIAL_PATTERNS = [
    re.compile(r'gh[pousr]_[A-Za-z0-9]{20,}'),
    re.compile(r'github_pat_[A-Za-z0-9_]{20,}'),
    re.compile(r'AKIA[A-Z0-9]{16}'),
    re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def json_bytes(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False) + '\n').encode('utf8')


def safe_name(name):
    if not isinstance(name, str) or not name or '\\' in name or '\x00' in name:
        raise ValueError('unsafe archive name')
    p = PurePosixPath(name)
    if p.is_absolute() or str(p) != name or any(x in ('', '.', '..') for x in p.parts):
        raise ValueError('absolute, noncanonical or traversing archive name')
    if any(not re.fullmatch(r'[A-Za-z0-9_.-]+', x) for x in p.parts):
        raise ValueError('unexpected archive path component')
    return p


def regular_read(path):
    path = Path(path).absolute()
    current = Path(path.anchor)
    for component in path.parts[1:-1]:
        current = current / component
        st = current.lstat()
        if not stat.S_ISDIR(st.st_mode):
            raise ValueError('non-directory or symlink in input parent path')
    lst = path.lstat()
    if not stat.S_ISREG(lst.st_mode) or lst.st_size > MAX_FILE_BYTES:
        raise ValueError('input is not a bounded regular file')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        before = os.fstat(fd)
        if (before.st_dev, before.st_ino) != (lst.st_dev, lst.st_ino):
            raise ValueError('input file identity changed')
        chunks, total = [], 0
        while True:
            b = os.read(fd, min(65536, MAX_FILE_BYTES + 1 - total))
            if not b:
                break
            chunks.append(b)
            total += len(b)
            if total > MAX_FILE_BYTES:
                raise ValueError('input exceeds file bound')
        after = os.fstat(fd)
        if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_mode) != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_mode):
            raise ValueError('input changed during bounded read')
        raw = b''.join(chunks)
        if len(raw) != before.st_size:
            raise ValueError('short input read')
        return raw
    finally:
        os.close(fd)


def scan_texts(payload):
    count, queries = 0, set()
    for name, raw in payload.items():
        if name.endswith('.zip'):
            continue
        text = raw.decode('utf8', 'strict')
        for pattern in CREDENTIAL_PATTERNS:
            if pattern.search(text):
                raise ValueError('credential-like material in selected text: ' + name)
        for url in URL_RE.findall(text):
            url = url.rstrip('\\')
            count += 1
            parts = urlsplit(url)
            if parts.username is not None or parts.password is not None:
                raise ValueError('URL userinfo in selected text: ' + name)
            keys = {k.lower() for k, _ in parse_qsl(parts.query, keep_blank_values=True)}
            if keys & FORBIDDEN_QUERY_KEYS or any(k.startswith(('x-amz-', 'x-goog-')) for k in keys):
                raise ValueError('signed or credential-bearing URL in selected text: ' + name)
            if parts.query:
                queries.add(url)
    return {'http_url_occurrences':count, 'distinct_unsigned_query_urls':sorted(queries), 'signed_urls_detected':0, 'credential_pattern_matches':0, 'scope':'Finite credential/signature pattern scan plus explicit evidence-file selection; no token or credential source was read.'}


def validate_inner_archives(payload):
    rows = []
    for name, raw in sorted(payload.items()):
        if not name.endswith('.zip'):
            continue
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            infos = z.infolist()
            if len(infos) != 1 or len({i.filename for i in infos}) != len(infos):
                raise ValueError('unexpected or duplicate inner ZIP members')
            info = infos[0]
            safe_name(info.filename)
            mode = info.external_attr >> 16
            if info.is_dir() or '/' in info.filename or (stat.S_IFMT(mode) not in (0, stat.S_IFREG)):
                raise ValueError('nonregular inner ZIP member')
            if info.file_size > MAX_FILE_BYTES:
                raise ValueError('inner ZIP member exceeds bound')
            member = z.read(info)
            matches = [n for n in payload if PurePosixPath(n).name == info.filename]
            if len(matches) != 1 or payload[matches[0]] != member:
                raise ValueError('inner ZIP does not exactly match one preserved JSON member')
            rows.append({'archive_name':name, 'zip_bytes':len(raw), 'zip_sha256':sha(raw), 'member_name':info.filename, 'preserved_member':matches[0], 'member_bytes':len(member), 'member_sha256':sha(member)})
    if len(rows) != 15:
        raise ValueError('expected exactly fifteen artifact archives')
    return rows


def encode_archive(payload):
    tar_buffer = io.BytesIO()
    with tarfile.open(fileobj=tar_buffer, mode='w', format=tarfile.USTAR_FORMAT) as out:
        for name, raw in sorted(payload.items()):
            safe_name(name)
            info = tarfile.TarInfo(name)
            info.type = tarfile.REGTYPE
            info.size = len(raw)
            info.mode = 0o644
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            info.mtime = 0
            info.linkname = ''
            out.addfile(info, io.BytesIO(raw))
    gz_buffer = io.BytesIO()
    with gzip.GzipFile(filename='', mode='wb', fileobj=gz_buffer, mtime=0, compresslevel=9) as out:
        out.write(tar_buffer.getvalue())
    return gz_buffer.getvalue(), len(tar_buffer.getvalue())


def extract_and_verify(raw, manifest, destination):
    destination.mkdir(mode=0o700)
    expected = {row['archive_name']:row for row in manifest['entries']}
    seen = set()
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        for member in archive:
            name = member.name
            safe_name(name)
            if name in seen or name not in expected:
                raise ValueError('duplicate or unexpected outer archive member')
            seen.add(name)
            if not member.isreg() or member.type != tarfile.REGTYPE or member.linkname or member.pax_headers:
                raise ValueError('outer archive member is not an ordinary regular file')
            if (member.mode, member.uid, member.gid, member.uname, member.gname, member.mtime) != (0o644,0,0,'','',0):
                raise ValueError('outer archive metadata is not normalized')
            if member.size != expected[name]['bytes'] or member.size > MAX_FILE_BYTES:
                raise ValueError('outer archive size mismatch')
            reader = archive.extractfile(member)
            if reader is None:
                raise ValueError('regular member has no byte stream')
            content = reader.read(MAX_FILE_BYTES + 1)
            if len(content) != member.size or sha(content) != expected[name]['sha256']:
                raise ValueError('outer archive content mismatch')
            target = destination.joinpath(*PurePosixPath(name).parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as out:
                out.write(content)
            os.chmod(target, 0o644)
    if seen != set(expected):
        raise ValueError('outer archive omitted a manifest member')
    actual = {p.relative_to(destination).as_posix() for p in destination.rglob('*') if p.is_file()}
    if actual != set(expected):
        raise ValueError('extracted inventory mismatch')
    for name, row in expected.items():
        content = regular_read(destination/name)
        if len(content) != row['bytes'] or sha(content) != row['sha256']:
            raise ValueError('extracted member readback mismatch')
    return len(seen)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-root', required=True)
    parser.add_argument('--output-dir', required=True)
    args = parser.parse_args()
    source_root = Path(args.source_root).absolute()
    package_dir = Path(__file__).absolute().parent
    output = Path(args.output_dir).absolute()
    output.mkdir(parents=True, exist_ok=True)
    if not stat.S_ISDIR(output.lstat().st_mode):
        raise ValueError('output must be a real directory')
    for name in (ARCHIVE, MANIFEST, RECEIPT, 'extracted_verification'):
        if (output/name).exists() or (output/name).is_symlink():
            raise ValueError('output already exists: ' + name)

    selected = json.loads(regular_read(package_dir/'source_selection.json'))
    if not isinstance(selected,list) or len(selected) != 51 or selected != sorted(set(selected)):
        raise ValueError('explicit source selection must contain 51 unique sorted names')
    payload, source_paths = {}, {}
    for name in selected:
        safe_name(name)
        if not (name.startswith(('lanes/pr8705_final_ci_review/','lanes/pr8705_release_audit_evidence/')) or name in ('lanes/PR8705_INDEPENDENT_RELEASE_AUDIT.md','lanes/PR8705_INDEPENDENT_RELEASE_AUDIT.json')):
            raise ValueError('source outside explicit evidence fence')
        source_paths[name] = source_root/name
        payload[name] = regular_read(source_paths[name])
    for name in ('README.md','build_and_verify_archive.py','source_selection.json'):
        archive_name = 'packaging/' + name
        source_paths[archive_name] = package_dir/name
        payload[archive_name] = regular_read(package_dir/name)
    if len(payload) != 54 or sum(map(len,payload.values())) > MAX_PAYLOAD_BYTES:
        raise ValueError('payload count or byte bound exceeded')

    scan = scan_texts(payload)
    inner = validate_inner_archives(payload)
    first, tar_bytes = encode_archive(payload)
    second, second_tar_bytes = encode_archive(payload)
    if first != second or tar_bytes != second_tar_bytes:
        raise ValueError('repeated archive encoding is not byte-deterministic')
    if len(first) > MAX_PAYLOAD_BYTES:
        raise ValueError('compressed archive exceeds package bound')
    manifest = {'schema':'gmi.pr8705.durable_ci_archive_manifest/v1','subject_head_sha':HEAD,'workflow_run_id':37915994513,'run_attempt':1,'archive':{'filename':ARCHIVE,'format':'gzip/ustar','bytes':len(first),'sha256':sha(first),'uncompressed_tar_bytes':tar_bytes,'normalization':{'entry_order':'lexicographic','type':'regular','mode':'0644','uid':0,'gid':0,'uname':'','gname':'','mtime':0,'gzip_mtime':0,'gzip_filename':'','compression_level':9}},'entry_count':len(payload),'payload_bytes':sum(map(len,payload.values())),'manifest_scope':'Every outer archive member is listed; this external manifest and the post-build receipt are not archive members.','entries':[{'archive_name':name,'type':'regular','bytes':len(content),'sha256':sha(content)} for name,content in sorted(payload.items())]}
    manifest_raw = json_bytes(manifest)
    with (output/ARCHIVE).open('xb') as out:
        out.write(first)
    with (output/MANIFEST).open('xb') as out:
        out.write(manifest_raw)
    if regular_read(output/ARCHIVE) != first or regular_read(output/MANIFEST) != manifest_raw:
        raise ValueError('archive or manifest durable readback mismatch')

    extract_root = output/'extracted_verification'
    verified = extract_and_verify(first,manifest,extract_root)
    verifier = extract_root/'lanes/pr8705_final_ci_review/verify_observed_ci_artifacts.py'
    replay_name = 'packaging_replay_verification_001.json'
    command = [sys.executable,'-B',str(verifier),'--snapshot','native_snapshot_002.json','--aggregate','ci-semantic-evidence.json','--output',replay_name]
    result = subprocess.run(command,cwd=extract_root,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
    if result.returncode != 0:
        raise ValueError('extracted artifact verifier failed: ' + result.stderr.decode('utf8',errors='replace')[:2000])
    replay_path = extract_root/'lanes/pr8705_final_ci_review'/replay_name
    replay_raw = regular_read(replay_path)
    replay = json.loads(replay_raw)
    original = json.loads(payload['lanes/pr8705_final_ci_review/full_artifact_verification_002.json'])
    replay_compare, original_compare = dict(replay), dict(original)
    replay_compare.pop('created_at_utc')
    original_compare.pop('created_at_utc')
    if replay_compare != original_compare:
        raise ValueError('replayed semantic receipt differs beyond creation timestamp')
    for name, path in source_paths.items():
        if regular_read(path) != payload[name]:
            raise ValueError('original input changed: ' + name)

    receipt = {'schema':'gmi.pr8705.durable_ci_archive_verification/v1','verified_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'disposition':'PASS_DETERMINISTIC_ARCHIVE_EXTRACTION_AND_PRESERVED_VERIFIER','archive':manifest['archive'],'manifest':{'filename':MANIFEST,'bytes':len(manifest_raw),'sha256':sha(manifest_raw)},'source_evidence_file_count':len(selected),'source_evidence_bytes':sum(len(payload[n]) for n in selected),'added_packaging_files':3,'entry_count':len(payload),'payload_bytes':sum(map(len,payload.values())),'original_inputs_unchanged_after_verification':True,'two_independent_encodings_byte_identical':True,'extracted_regular_files_verified':verified,'duplicate_outer_members':0,'links_or_traversal_or_nonregular_outer_entries':0,'all_fifteen_inner_archives_and_members_verified':True,'inner_artifacts':inner,'content_scan':scan,'raw_log_body_included':False,'cached_or_unrelated_inputs_included':False,'network_or_native_or_git_actions_performed':False,'application_imports_or_tests_performed':False,'runtime':{'python':sys.version,'zlib_compile_version':zlib.ZLIB_VERSION,'zlib_runtime_version':zlib.ZLIB_RUNTIME_VERSION},'extracted_verifier':{'returncode':result.returncode,'stdout_bytes':len(result.stdout),'stdout_sha256':sha(result.stdout),'stderr_bytes':len(result.stderr),'stderr_sha256':sha(result.stderr),'receipt_relative_path':'lanes/pr8705_final_ci_review/'+replay_name,'receipt_bytes':len(replay_raw),'receipt_sha256':sha(replay_raw),'receipt_equals_frozen_except_created_at':True,'disposition':replay['disposition'],'checks_run':replay['checks_run'],'observed':replay['observed'],'aggregate':replay['aggregate']}}
    receipt_raw = json_bytes(receipt)
    with (output/RECEIPT).open('xb') as out:
        out.write(receipt_raw)
    print(json.dumps({'archive_path':str(output/ARCHIVE),'archive_bytes':len(first),'archive_sha256':sha(first),'manifest_path':str(output/MANIFEST),'manifest_bytes':len(manifest_raw),'manifest_sha256':sha(manifest_raw),'verification_receipt_path':str(output/RECEIPT),'verification_receipt_bytes':len(receipt_raw),'verification_receipt_sha256':sha(receipt_raw),'entry_count':len(payload),'payload_bytes':sum(map(len,payload.values())),'disposition':receipt['disposition']},indent=2))


if __name__ == '__main__':
    main()
