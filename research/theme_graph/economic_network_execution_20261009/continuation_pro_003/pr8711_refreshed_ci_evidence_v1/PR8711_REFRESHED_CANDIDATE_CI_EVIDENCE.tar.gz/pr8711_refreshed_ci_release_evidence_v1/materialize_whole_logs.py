#!/usr/bin/env python3
"""Materialize already GET-read whole CI logs in scratch; no network/imports."""
import argparse
import base64
import hashlib
import json
from pathlib import Path
import stat

ROOT = Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--receipt', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    for name in (args.receipt, args.output):
        assert Path(name).name == name and name not in {'.', '..'}
    source = ROOT / args.receipt
    assert not source.is_symlink() and stat.S_ISREG(source.lstat().st_mode)
    document = json.loads(source.read_bytes())
    records = []
    (ROOT / 'logs').mkdir(exist_ok=True)
    assert not (ROOT / 'logs').is_symlink()
    for row in document.get('logs', []):
        assert type(row['job_id']) is int and row['job_id'] > 0
        assert row['returncode'] == 0 and row['raw_body_retained'] is True
        raw = base64.b64decode(row['raw_base64'], validate=True)
        assert len(raw) == row['bytes'] <= 8 * 1024 * 1024 and sha(raw) == row['sha256']
        path = ROOT / 'logs' / (str(row['job_id']) + '.log')
        if path.exists():
            assert not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode) and path.read_bytes() == raw
        else:
            with path.open('xb') as stream:
                stream.write(raw)
        records.append({'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw), 'sha256': sha(raw),
                        'job_id': row['job_id'], 'role': row['role'], 'endpoint': row['endpoint'],
                        'whole_raw_body_retained': True})
    output = {'schema': 'gmi.pr8711.corrected_whole_log_materialization/v1', 'source_receipt': args.receipt,
              'source_receipt_sha256': sha(source.read_bytes()), 'logs': records}
    target = ROOT / args.output
    with target.open('x', encoding='utf8') as stream:
        json.dump(output, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps({'path': str(target), 'bytes': target.stat().st_size, 'sha256': sha(target.read_bytes()),
                      'logs': records}, indent=2))


if __name__ == '__main__':
    main()
