#!/usr/bin/env python3
"""Deterministic scratch-only archive and unchanged preserved-data replays.

No network, Git, native device operation, repository imports or application
tests. Only the three already-owned preserved-data verifiers are executed.
"""
import datetime
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parent
DESTINATION = ROOT / 'durable_archive'
PREFIX = 'pr8711_refreshed_ci_release_evidence_v1'
ARCHIVE_NAME = 'PR8711_REFRESHED_CANDIDATE_CI_EVIDENCE.tar.gz'
MANIFEST_NAME = 'ARCHIVE_MANIFEST.json'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def safe(name):
    assert type(name) is str and name and not name.startswith('/') and '\\' not in name
    assert all(part not in {'', '.', '..'} for part in name.split('/'))
    assert str(PurePosixPath(name)) == name
    return name


def record(path):
    raw = path.read_bytes()
    return {'name': path.name, 'bytes': len(raw), 'sha256': sha(raw)}


def dump(path, value):
    raw = (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + '\n').encode()
    with path.open('xb') as handle:
        handle.write(raw)
    return record(path)


def load(path):
    return json.loads(path.read_text())


def main():
    assert not DESTINATION.exists(), 'Do not overwrite a frozen archive.'
    review = load(ROOT / 'CI_EVIDENCE_VERIFICATION.json')
    source_proof = load(ROOT / 'SOURCE_PIN_VERIFICATION.json')
    source_assessment = load(ROOT / 'SOURCE_REFRESH_ASSESSMENT.json')
    processes = load(ROOT / 'native_read_scripts.json')
    assert source_assessment['tested_commit'] == '7d5fd7428fa91567db755117657f856e1347c5f9'
    assert len(source_assessment['pack_assignment_changes']) == 51
    assert source_assessment['changed_job_ids'] == ['unrun-grading-board']
    assert sha((ROOT / 'assess_source_refresh.py').read_bytes()) == 'c3a0101d081f89d982c559613481c5f398b7d984dcbf82156146f372e1b68f5b'
    assert review['identity']['subject_head_sha'] == '693ee939c8a28920ef9de7bc32a9f47a7ba76b82'
    assert review['identity']['workflow_run_id'] == '37938576895'
    assert review['completeness']['complete_ci_pass_evidence'] is True
    assert review['denominators']['observed_retained_artifacts'] == 15
    assert review['denominators']['observed_fragments'] == 12
    assert review['denominators']['observed_jobs'] == 98
    assert review['denominators']['observed_proof_steps'] == 316
    assert review['aggregate']['classifications'] == {'passed': 316}
    assert source_proof['all_matches'] is True and source_proof['pinned_file_count'] == 53
    assert load(ROOT / 'native_read_scripts.json')['all_managed_processes_reconciled'] is True
    required_logs = {row['path']: row for row in review['whole_log_inventory']}
    assert len(required_logs) == 3

    # Reproduce the bounded exact raw-log packaging scan. False positives would
    # stop packaging for inspection; this does not alter any retained log.
    patterns = {
        'signed_s3_query': rb'(?i)[?&]X-Amz-(?:Signature|Credential)=',
        'signed_azure_query': rb'(?i)https?://[^\s"<>]*[?&]sig=',
        'github_pat': rb'github_pat_[A-Za-z0-9_]{40,}',
        'github_token': rb'gh[pousr]_[A-Za-z0-9]{30,}',
        'private_key_header': rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
    }
    log_scan = []
    for relative, row in required_logs.items():
        raw = (ROOT / relative).read_bytes()
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
        findings = {name: len(re.findall(pattern, raw)) for name, pattern in patterns.items()}
        assert all(count == 0 for count in findings.values()), (relative, findings)
        log_scan.append({'path': relative, 'bytes': len(raw), 'sha256': sha(raw), 'findings': findings})
    dump(ROOT / 'RAW_LOG_PACKAGING_CHECK.json', {
        'schema': 'gmi.pr8711.refreshed_raw_log_packaging_scan/v1',
        'patterns': {name: pattern.decode('ascii') for name, pattern in patterns.items()},
        'whole_logs': log_scan, 'all_pattern_counts_zero': True,
        'raw_log_bytes_unchanged': True,
        'limit': 'Bounded common credential/signed-URL patterns, not a universal secret-detection guarantee.'})

    rows = []
    original_mtimes = {}
    for current, directories, files in os.walk(ROOT, followlinks=False):
        current = Path(current)
        for name in directories:
            node = current / name
            assert not node.is_symlink() and stat.S_ISDIR(node.lstat().st_mode), str(node)
            assert name not in {'__pycache__', '.git', '.pytest_cache', '.mypy_cache', '.ruff_cache'}, str(node)
        for name in files:
            node = current / name
            assert not node.is_symlink() and stat.S_ISREG(node.lstat().st_mode), str(node)
            relative = safe(node.relative_to(ROOT).as_posix())
            assert not relative.endswith(('.pyc', '.pyo')), relative
            if relative.endswith('.log'):
                assert relative in required_logs, relative
            raw = node.read_bytes()
            assert len(raw) <= 16 * 1024 * 1024
            rows.append({'archive_name': safe(PREFIX + '/' + relative), 'source_relative_path': relative,
                         'bytes': len(raw), 'sha256': sha(raw)})
            original_mtimes[relative] = node.stat().st_mtime_ns
    rows.sort(key=lambda row: row['archive_name'])
    assert len(rows) == len({row['archive_name'] for row in rows})
    total = sum(row['bytes'] for row in rows)
    assert len(rows) < 512 and total <= 64 * 1024 * 1024
    relative_names = {row['source_relative_path'] for row in rows}
    required_artifact_files = set()
    for artifact in review['artifact_inventory']:
        required_artifact_files.add(artifact['zip']['path'])
        assert len(artifact['members']) == 1
        required_artifact_files.add(artifact['members'][0]['path'])
    actual_artifact_files = {name for name in relative_names if name.startswith('artifacts/')}
    assert len(required_artifact_files) == 30 and actual_artifact_files == required_artifact_files
    assert sum(name.endswith('/original.zip') for name in actual_artifact_files) == 15
    assert sum(name.endswith('.json') for name in actual_artifact_files) == 15
    assert review['verification']['verifier']['sha256'] == sha((ROOT / 'verify_refreshed_artifacts.py').read_bytes())
    assert source_proof['verifier']['sha256'] == sha((ROOT / 'verify_tested_code_pins.py').read_bytes())

    DESTINATION.mkdir()
    manifest = {
        'schema': 'gmi.pr8711.refreshed_deterministic_evidence_archive_manifest/v1',
        'archive_name': ARCHIVE_NAME, 'archive_prefix': PREFIX,
        'identity': review['identity'], 'attempt': 1,
        'frozen_observation_completed_at_utc': review['observation_completed_at_utc'],
        'disposition': review['disposition'],
        'regular_file_count': len(rows), 'uncompressed_file_bytes': total, 'entries': rows,
        'actual_artifact_zip_count': 15, 'actual_artifact_json_member_count': 15,
        'whole_raw_log_count': 3, 'accepted_source_byte_pin_count': 53,
        'normalized_metadata': {'archive_format': 'POSIX pax tar in gzip',
            'gzip_mtime': 0, 'gzip_filename': '', 'tar_member_mtime': 0,
            'uid': 0, 'gid': 0, 'uname': '', 'gname': '', 'mode_octal': '0644',
            'entry_order': 'archive-name lexical'},
        'explicit_exclusions': ['durable_archive outputs created after input enumeration',
            'credentials and signed artifact redirect URLs were not retained',
            'caches, unrelated sibling lanes and prior already-committed candidate archives'],
        'manifest_is_external': True,
    }
    manifest_record = dump(DESTINATION / MANIFEST_NAME, manifest)

    def build_archive(destination):
        with gzip.GzipFile(filename='', fileobj=destination, mode='wb', compresslevel=9, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as archive:
                for row in rows:
                    raw = (ROOT / row['source_relative_path']).read_bytes()
                    assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
                    info = tarfile.TarInfo(row['archive_name'])
                    info.type = tarfile.REGTYPE
                    info.size = len(raw)
                    info.mode = 0o644
                    info.uid = info.gid = info.mtime = 0
                    info.uname = info.gname = ''
                    archive.addfile(info, io.BytesIO(raw))

    archive_path = DESTINATION / ARCHIVE_NAME
    with archive_path.open('xb') as handle:
        build_archive(handle)
    archive_record = record(archive_path)
    second_encoding = io.BytesIO()
    build_archive(second_encoding)
    assert second_encoding.getvalue() == archive_path.read_bytes()

    extracted = DESTINATION / 'verification_extract'
    extracted.mkdir()
    expected = {row['archive_name']: row for row in rows}
    with tarfile.open(archive_path, 'r:gz') as archive:
        members = archive.getmembers()
        assert len(members) == len(rows)
        assert [member.name for member in members] == [row['archive_name'] for row in rows]
        assert len({member.name for member in members}) == len(rows)
        for member in members:
            safe(member.name)
            assert member.name in expected and member.isreg() and not member.issym() and not member.islnk()
            assert member.mode == 0o644 and member.uid == member.gid == member.mtime == 0
            assert member.uname == member.gname == '' and set(member.pax_headers).issubset({'path'})
            raw = archive.extractfile(member).read()
            row = expected[member.name]
            assert len(raw) == member.size == row['bytes'] and sha(raw) == row['sha256']
            target = extracted / member.name
            assert target.is_relative_to(extracted)
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as handle:
                handle.write(raw)
            assert target.read_bytes() == raw
    actual_names = sorted(path.relative_to(extracted).as_posix() for path in extracted.rglob('*') if path.is_file())
    assert actual_names == sorted(expected)
    extracted_root = extracted / PREFIX

    replay_records = []
    replay_specs = [
        ('assess_source_refresh.py', [], 'SOURCE_REFRESH_ASSESSMENT.json', 'ARCHIVE_REPLAY_SOURCE_REFRESH_ASSESSMENT.json'),
        ('verify_tested_code_pins.py', [], 'SOURCE_PIN_VERIFICATION.json', 'ARCHIVE_REPLAY_SOURCE_PIN_VERIFICATION.json'),
        ('verify_refreshed_artifacts.py', ['--snapshot', review['snapshot_file']], 'CI_EVIDENCE_VERIFICATION.json',
         'ARCHIVE_REPLAY_CI_EVIDENCE_VERIFICATION.json'),
    ]
    for script, arguments, original_name, replay_name in replay_specs:
        command = [sys.executable, '-B', str(extracted_root / script), *arguments, '--output', replay_name]
        process = subprocess.run(command, cwd=extracted_root, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                 timeout=60, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
        assert process.returncode == 0, process.stderr.decode('utf8', 'replace')[:2000]
        original = load(ROOT / original_name)
        replay_path = extracted_root / replay_name
        replay = load(replay_path)
        byte_identical = replay_path.read_bytes() == (ROOT / original_name).read_bytes()
        if script == 'assess_source_refresh.py':
            assert byte_identical
        assert {k: v for k, v in original.items() if k != 'created_at_utc'} == {
            k: v for k, v in replay.items() if k != 'created_at_utc'}
        replay_records.append({'relative_command': ['python', '-B', PREFIX + '/' + script,
                                                   *arguments, '--output', replay_name],
                               'exit_code': process.returncode, 'stdout_bytes': len(process.stdout),
                               'stdout_sha256': sha(process.stdout), 'stderr_bytes': len(process.stderr),
                               'stderr_sha256': sha(process.stderr),
                               'output': {'archive_relative_path': PREFIX + '/' + replay_name,
                                          **record(replay_path)},
                               'matches_original_except_created_at_utc': True,
                               'matches_original_bytes': byte_identical,
                               'original_preserved_report': PREFIX + '/' + original_name})
    for row in rows:
        for node in (ROOT / row['source_relative_path'], extracted / row['archive_name']):
            assert not node.is_symlink() and stat.S_ISREG(node.lstat().st_mode)
            raw = node.read_bytes()
            assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
        assert (ROOT / row['source_relative_path']).stat().st_mtime_ns == original_mtimes[row['source_relative_path']]
    extra_outputs = [PREFIX + '/' + spec[3] for spec in replay_specs]
    after_names = sorted(path.relative_to(extracted).as_posix() for path in extracted.rglob('*') if path.is_file())
    assert after_names == sorted([*expected, *extra_outputs])
    result = {
        'schema': 'gmi.pr8711.refreshed_deterministic_evidence_archive_verification/v1',
        'verified_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'archive': archive_record, 'manifest': manifest_record,
        'status': 'VERIFIED_FROZEN_REFRESHED_CANDIDATE_COMPLETE_CI_EVIDENCE',
        'identity': review['identity'], 'attempt': 1, 'disposition': review['disposition'],
        'regular_file_count': len(rows), 'uncompressed_file_bytes': total,
        'actual_artifact_zip_count': 15, 'actual_artifact_json_member_count': 15,
        'observed_fragments': 12, 'selected_jobs': 98, 'proof_steps': 316,
        'step_classifications': {'passed': 316}, 'whole_raw_log_count': 3,
        'accepted_code_pins_verified': 53, 'ci_verifier_assertions_passed': review['verification']['assertions_passed'],
        'all_manifest_entries_extracted_and_verified': True,
        'normalized_metadata_verified': True, 'unique_regular_files_only': True,
        'deterministic_reencode_byte_identical': True,
        'original_files_unchanged_after_packaging': True, 'original_file_mtimes_unchanged': True,
        'all_preserved_extracted_files_unchanged_after_verifiers': True,
        'replay_verifiers': replay_records, 'executed_verifier_count': 3,
        'source_refresh_assessment_replay_byte_identical': True,
        'extra_extracted_outputs_accounted_for': extra_outputs,
        'authority': {'merge_authorized': False, 'policy_waiver': False, 'ci_rerun': False,
                      'native_mutation': False, 'git_mutation': False, 'application_imports_or_tests': False},
    }
    verification_record = dump(DESTINATION / 'ARCHIVE_VERIFICATION.json', result)
    readme = f'''# PR8711 refreshed-candidate CI evidence archive

**Complete observed CI evidence for candidate `693ee939c8a28920ef9de7bc32a9f47a7ba76b82`; canonical release adjudication remains with the principal.**

The frozen observation completed at **{review['observation_completed_at_utc']}**. Run **37938576895**, attempt **1**, concluded **success**. Actual tested synthetic commit: `7d5fd7428fa91567db755117657f856e1347c5f9`; ordered parents: `3bb1ee47939d9caa1db10a4e764365d3a2ee5b77` then the exact candidate head. Distinct Git tree: `67c6a12f7b91e45b63614819a732753fa4a7599a`.

The archive contains all **15 original artifact ZIPs and 15 exact JSON members**: the plan, changed paths, all **12** raw pack fragments and final semantic aggregate. The independent verifier accounts for **98/98 selected jobs** and **316/316 proof steps**, all passed. It recomputes the 98 job execution and 316 step specification source digests and reconstructs the complete all-pass aggregate. Its logical SHA-256 is `{review['aggregate']['evidence_sha256']}`. The complete final gate JSON stdout, summary and notices match it exactly.

The actual current relationship owner is **pack 6**, with **275 passed in {review['owner']['actual_result']['seconds']}s**. The actual new contract gate reports **0 introduced, 0 inherited**, against the actual tested base. Whole raw owner, contract-delta and final gate logs are preserved unchanged with lengths, hashes and line references. The separate source proof verifies **53/53 accepted engine/lib byte pins**, **1,483,905 bytes**, from fresh native GET captures of three complete trees and 52 unique blobs at the tested tree. That establishes byte compatibility; functional code review retains its existing owner.

The retained old/new full manifests and plans establish exactly one changed job/step specification and **51 changed job-to-pack assignments**, including the owner moving from pack 11 to pack 6. All selected/excluded inventories and 98 execution-context digests remain unchanged. The complete source comparison and its unchanged replay are included. Prior successful and failed/pending packets remain separate and unchanged; their execution outcomes do not supply current-head proof.

## Transfer files

| File | Bytes | SHA-256 |
|---|---:|---|
| `{ARCHIVE_NAME}` | {archive_record['bytes']} | `{archive_record['sha256']}` |
| `{MANIFEST_NAME}` | {manifest_record['bytes']} | `{manifest_record['sha256']}` |
| `ARCHIVE_VERIFICATION.json` | {verification_record['bytes']} | `{verification_record['sha256']}` |

Keep this README with those three files. The archive has **{len(rows)} regular files**, totaling **{total:,} uncompressed file bytes**, under `{PREFIX}/`. The external manifest enumerates every relative archive name, length and SHA-256. Outer metadata, ownership, times, modes and entry order are normalized. A second in-memory encoding was byte-identical. Every original GitHub ZIP retains its exact original bytes and internal metadata. There are no links, duplicate names, traversal entries, caches or retained credentials/signed artifact redirect URLs. A bounded common-pattern scan of the three whole logs is retained without modifying them.

Entry points: `OBSERVATION_REPORT.md`, `CI_EVIDENCE_VERIFICATION.json`, `FOCUSED_OBSERVATION.json`, `ARTIFACT_INVENTORY.json`, `SOURCE_PIN_VERIFICATION.json`, `SOURCE_REFRESH_ASSESSMENT.json`, `READ_TIMELINE.json`, `PACKAGING_NOTES.md`, and `native_read_scripts.json`. Exact read scripts and all **{processes['managed_process_count']}** reconciled native PIDs are preserved. Historical partial observations and the refused initial preparation assertion remain unchanged. The archive helper's own origin, source diff and generation changes are in `ARCHIVE_BUILDER_DERIVATION.json` and `ARCHIVE_BUILDER_REVISION.diff`.

Every manifest entry was safely extracted and verified. All **three unchanged preserved-data verifiers** then executed from the extracted layout with fresh output filenames. The source comparison was byte-identical. The 53-pin and complete CI reports matched their preserved reports exactly apart from `created_at_utc`; all **{review['verification']['assertions_passed']:,} CI assertions** passed again. The three additional replay outputs are accounted for separately in `ARCHIVE_VERIFICATION.json` and are not part of the frozen archive. Original and extracted preserved files remained byte-identical; original input mtimes also remained unchanged.

From the extracted evidence directory, with Python 3 and PyYAML:

```sh
PYTHONDONTWRITEBYTECODE=1 python -B assess_source_refresh.py --output FRESH_SOURCE_REFRESH_ASSESSMENT.json
PYTHONDONTWRITEBYTECODE=1 python -B verify_tested_code_pins.py --output FRESH_SOURCE_PIN_VERIFICATION.json
PYTHONDONTWRITEBYTECODE=1 python -B verify_refreshed_artifacts.py --snapshot {review['snapshot_file']} --output FRESH_CI_EVIDENCE_VERIFICATION.json
```

Use new output names. These commands read preserved evidence without contacting GitHub, operating on native devices, mutating Git, importing repository applications or running application tests. Earlier partial snapshots describe their own available inventories; final replay uses the selected final snapshot and all retained captures.

The exact-head census explicitly retains `ci-authority/codex/merge-queue-pilot` as failure and `ci-authority/main` as success. This packet does not waive a check or rule on its current policy binding. Root retains current protected procedure, live freshness/holds, accepted-source verification, expected-head merge and the native C01 witness. No rights, custody, history, factual, Graph1, production or predictive promotion is made.
'''
    with (DESTINATION / 'ARCHIVE_README.md').open('x', encoding='utf8') as handle:
        handle.write(readme)
    print(json.dumps({'archive_directory': str(DESTINATION), 'archive': archive_record,
                      'manifest': manifest_record, 'verification': verification_record,
                      'readme': record(DESTINATION / 'ARCHIVE_README.md'),
                      'regular_files': len(rows), 'uncompressed_file_bytes': total,
                      'all_three_unchanged_verifier_replays_passed': True,
                      'status': result['status']}, indent=2))


if __name__ == '__main__':
    main()
