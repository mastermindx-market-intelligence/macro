#!/usr/bin/env python3
"""Prepare the refreshed generation's deterministic archive helper, scratch only."""
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent / 'pr8711_corrected_ci_release_evidence_v1' / 'build_durable_archive.py'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write(name, raw):
    target = ROOT / name
    with target.open('xb') as handle:
        handle.write(raw)
    return {'path': name, 'bytes': len(raw), 'sha256': sha(raw)}


def main():
    original = PREVIOUS.read_bytes()
    script = original.decode()
    replacements = [
        ('two already-owned preserved-data verifiers', 'three already-owned preserved-data verifiers'),
        ('pr8711_corrected_ci_release_evidence_v1', 'pr8711_refreshed_ci_release_evidence_v1'),
        ('PR8711_CORRECTED_CANDIDATE_CI_EVIDENCE.tar.gz', 'PR8711_REFRESHED_CANDIDATE_CI_EVIDENCE.tar.gz'),
        ('42174563149254d2399e23e101baafd8b06f9b1e', '693ee939c8a28920ef9de7bc32a9f47a7ba76b82'),
        ('37932039980', '37938576895'),
        ('04b70807e6b0a7d48091997eb405f9cc53ade9ad', '7d5fd7428fa91567db755117657f856e1347c5f9'),
        ('40ebaebdbcd57eedaa627623f1cfd1860ff3ee3a', '3bb1ee47939d9caa1db10a4e764365d3a2ee5b77'),
        ('0c5bd664aec83fe9a9d456b2f35e1e870fc0b3e8', '67c6a12f7b91e45b63614819a732753fa4a7599a'),
        ('verify_corrected_artifacts.py', 'verify_refreshed_artifacts.py'),
        ('gmi.pr8711.corrected_deterministic', 'gmi.pr8711.refreshed_deterministic'),
        ('VERIFIED_FROZEN_CORRECTED_CANDIDATE_COMPLETE_CI_EVIDENCE', 'VERIFIED_FROZEN_REFRESHED_CANDIDATE_COMPLETE_CI_EVIDENCE'),
        ('both_unchanged_verifier_replays_passed', 'all_three_unchanged_verifier_replays_passed'),
        ('caches, unrelated sibling lanes and prior already-committed failed-candidate archive',
         'caches, unrelated sibling lanes and prior already-committed candidate archives'),
    ]
    for before, after in replacements:
        assert before in script, before
        script = script.replace(before, after)
    script = script.replace(
        "    source_proof = load(ROOT / 'SOURCE_PIN_VERIFICATION.json')\n",
        "    source_proof = load(ROOT / 'SOURCE_PIN_VERIFICATION.json')\n"
        "    source_assessment = load(ROOT / 'SOURCE_REFRESH_ASSESSMENT.json')\n"
        "    processes = load(ROOT / 'native_read_scripts.json')\n"
        "    assert source_assessment['tested_commit'] == '7d5fd7428fa91567db755117657f856e1347c5f9'\n"
        "    assert len(source_assessment['pack_assignment_changes']) == 51\n"
        "    assert source_assessment['changed_job_ids'] == ['unrun-grading-board']\n"
        "    assert sha((ROOT / 'assess_source_refresh.py').read_bytes()) == 'c3a0101d081f89d982c559613481c5f398b7d984dcbf82156146f372e1b68f5b'\n"
    )
    script = script.replace(
        "    for relative, row in required_logs.items():\n",
        "    log_scan = []\n"
        "    for relative, row in required_logs.items():\n"
    )
    script = script.replace(
        "        assert all(not re.search(pattern, raw) for pattern in patterns.values())\n",
        "        findings = {name: len(re.findall(pattern, raw)) for name, pattern in patterns.items()}\n"
        "        assert all(count == 0 for count in findings.values()), (relative, findings)\n"
        "        log_scan.append({'path': relative, 'bytes': len(raw), 'sha256': sha(raw), 'findings': findings})\n"
        "    dump(ROOT / 'RAW_LOG_PACKAGING_CHECK.json', {\n"
        "        'schema': 'gmi.pr8711.refreshed_raw_log_packaging_scan/v1',\n"
        "        'patterns': {name: pattern.decode('ascii') for name, pattern in patterns.items()},\n"
        "        'whole_logs': log_scan, 'all_pattern_counts_zero': True,\n"
        "        'raw_log_bytes_unchanged': True,\n"
        "        'limit': 'Bounded common credential/signed-URL patterns, not a universal secret-detection guarantee.'})\n"
    )
    script = script.replace(
        "    replay_specs = [\n",
        "    replay_specs = [\n"
        "        ('assess_source_refresh.py', [], 'SOURCE_REFRESH_ASSESSMENT.json', 'ARCHIVE_REPLAY_SOURCE_REFRESH_ASSESSMENT.json'),\n"
    )
    script = script.replace(
        "        replay = load(replay_path)\n",
        "        replay = load(replay_path)\n"
        "        byte_identical = replay_path.read_bytes() == (ROOT / original_name).read_bytes()\n"
        "        if script == 'assess_source_refresh.py':\n"
        "            assert byte_identical\n"
    )
    script = script.replace(
        "                               'matches_original_except_created_at_utc': True,\n",
        "                               'matches_original_except_created_at_utc': True,\n"
        "                               'matches_original_bytes': byte_identical,\n"
    )
    script = script.replace(
        "        'replay_verifiers': replay_records, 'extra_extracted_outputs_accounted_for': extra_outputs,\n",
        "        'replay_verifiers': replay_records, 'executed_verifier_count': 3,\n"
        "        'source_refresh_assessment_replay_byte_identical': True,\n"
        "        'extra_extracted_outputs_accounted_for': extra_outputs,\n"
    )
    new_readme = """# PR8711 refreshed-candidate CI evidence archive

**Complete observed CI evidence for candidate `693ee939c8a28920ef9de7bc32a9f47a7ba76b82`; canonical release adjudication remains with the principal.**

The frozen observation completed at **{review['observation_completed_at_utc']}**. Run **37938576895**, attempt **1**, concluded **success**. Actual tested synthetic commit: `7d5fd7428fa91567db755117657f856e1347c5f9`; ordered parents: `3bb1ee47939d9caa1db10a4e764365d3a2ee5b77` then the exact candidate head. Distinct Git tree: `67c6a12f7b91e45b63614819a732753fa4a7599a`.

The archive contains all **15 original artifact ZIPs and 15 exact JSON members**: the plan, changed paths, all **12** raw pack fragments and final semantic aggregate. The independent verifier accounts for **98/98 selected jobs** and **316/316 proof steps**, all passed. It recomputes the 98 job execution and 316 step specification source digests and reconstructs the complete all-pass aggregate. Its logical SHA-256 is `{review['aggregate']['evidence_sha256']}`. The complete final gate JSON stdout, summary and notices match it exactly.

The actual current relationship owner is **pack 6**, with **275 passed in {review['owner']['actual_result']['seconds']}s**. The actual new contract gate reports **0 introduced, 0 inherited**, against the actual tested base. Whole raw owner, contract-delta and final gate logs are preserved unchanged with lengths, hashes and line references. The separate source proof verifies **53/53 accepted engine/lib byte pins**, **1,483,905 bytes**, from fresh native GET captures of three complete trees and 52 unique blobs at the tested tree. That establishes byte compatibility; functional code review retains its existing owner.

The retained old/new full manifests and plans establish exactly one changed job/step specification and **51 changed job-to-pack assignments**, including the owner moving from pack 11 to pack 6. All selected/excluded inventories and 98 execution-context digests remain unchanged. The complete source comparison and its unchanged replay are included. Prior successful and failed/pending packets remain separate and unchanged; their execution outcomes do not supply current-head proof.

## Transfer files

| File | Bytes | SHA-256 |
|---|---:|---|
| `{ARCHIVE_NAME}` | {archive_record['bytes']} | `{archive_record['sha256']}` |
| `{MANIFEST_NAME}` | {manifest_record['bytes']} | `{manifest_record['sha256']}` |
| `ARCHIVE_VERIFICATION.json` | {verification_record['bytes']} | `{verification_record['sha256']}` |

Keep this README with those three files. The archive has **{len(rows)} regular files**, totaling **{total:,} uncompressed file bytes**, under `{PREFIX}/`. The external manifest enumerates every relative archive name, length and SHA-256. Outer metadata, ownership, times, modes and entry order are normalized. A second in-memory encoding was byte-identical. Every original GitHub ZIP retains its exact original bytes and internal metadata. There are no links, duplicate names, traversal entries, caches or retained credentials/signed artifact redirect URLs. A bounded common-pattern scan of the three whole logs is retained without modifying them.

Entry points: `OBSERVATION_REPORT.md`, `CI_EVIDENCE_VERIFICATION.json`, `FOCUSED_OBSERVATION.json`, `ARTIFACT_INVENTORY.json`, `SOURCE_PIN_VERIFICATION.json`, `SOURCE_REFRESH_ASSESSMENT.json`, `READ_TIMELINE.json`, `PACKAGING_NOTES.md`, and `native_read_scripts.json`. Exact read scripts and all **{processes['managed_process_count']}** reconciled native PIDs are preserved. Historical partial observations and the refused initial preparation assertion remain unchanged. The archive helper's own origin, source diff and generation changes are in `ARCHIVE_BUILDER_DERIVATION.json` and `ARCHIVE_BUILDER_REVISION.diff`.

Every manifest entry was safely extracted and verified. All **three unchanged preserved-data verifiers** then executed from the extracted layout with fresh output filenames. The source comparison was byte-identical. The 53-pin and complete CI reports matched their preserved reports exactly apart from `created_at_utc`; all **{review['verification']['assertions_passed']:,} CI assertions** passed again. The three additional replay outputs are accounted for separately in `ARCHIVE_VERIFICATION.json` and are not part of the frozen archive. Original and extracted preserved files remained byte-identical; original input mtimes also remained unchanged.

From the extracted evidence directory, with Python 3 and PyYAML:

```sh
PYTHONDONTWRITEBYTECODE=1 python -B assess_source_refresh.py --output FRESH_SOURCE_REFRESH_ASSESSMENT.json
PYTHONDONTWRITEBYTECODE=1 python -B verify_tested_code_pins.py --output FRESH_SOURCE_PIN_VERIFICATION.json
PYTHONDONTWRITEBYTECODE=1 python -B verify_refreshed_artifacts.py --snapshot {review['snapshot_file']} --output FRESH_CI_EVIDENCE_VERIFICATION.json
```

Use new output names. These commands read preserved evidence without contacting GitHub, operating on native devices, mutating Git, importing repository applications or running application tests. Earlier partial snapshots describe their own available inventories; final replay uses the selected final snapshot and all retained captures.

The exact-head census explicitly retains `ci-authority/codex/merge-queue-pilot` as failure and `ci-authority/main` as success. This packet does not waive a check or rule on its current policy binding. Root retains current protected procedure, live freshness/holds, accepted-source verification, expected-head merge and the native C01 witness. No rights, custody, history, factual, Graph1, production or predictive promotion is made.
"""
    prefix, suffix = script.split("    readme = f'''", 1)
    _, rest = suffix.split("    with (DESTINATION / 'ARCHIVE_README.md')", 1)
    script = prefix + "    readme = f'''" + new_readme + "'''\n" + "    with (DESTINATION / 'ARCHIVE_README.md')" + rest
    compile(script, 'build_durable_archive.py', 'exec')
    outputs = [
        write('verifier_origin/build_corrected_durable_archive.py.txt', original),
        write('build_durable_archive.py', script.encode()),
        write('ARCHIVE_BUILDER_REVISION.diff', ''.join(difflib.unified_diff(
            original.decode().splitlines(keepends=True), script.splitlines(keepends=True),
            fromfile='previous-frozen/build_durable_archive.py', tofile='refreshed/build_durable_archive.py')).encode()),
    ]
    report = {
        'schema': 'gmi.pr8711.refreshed_archive_builder_derivation/v1',
        'origin': outputs[0], 'current': outputs[1], 'diff': outputs[2],
        'changes': [
            'Bind this generation to exact 693/run37938576895/tested7d/base3bb identities.',
            'Add an unchanged source-assessment replay alongside source-pin and CI verifiers.',
            'Enforce byte-identical source-assessment replay and preserve the unchanged CI/source verifier hashes.',
            'Record the bounded common-pattern whole-log scan before archive enumeration.',
            'Use current pack 6 owner result, actual PID count and precise current/prior proof boundaries.',
            'Retain the regular-only normalized manifest, safe extraction, deterministic re-encoding and original byte/mtime controls.',
        ],
        'existing_frozen_reports_or_verifiers_modified': False,
        'native_or_git_mutation': False,
        'application_imports_or_tests': False,
        'compile_only_check_passed': True,
    }
    outputs.append(write('ARCHIVE_BUILDER_DERIVATION.json',
                         (json.dumps(report, indent=2, sort_keys=True) + '\n').encode()))
    print(json.dumps({'outputs': outputs, 'compile_passed': True}, indent=2))


if __name__ == '__main__':
    main()

