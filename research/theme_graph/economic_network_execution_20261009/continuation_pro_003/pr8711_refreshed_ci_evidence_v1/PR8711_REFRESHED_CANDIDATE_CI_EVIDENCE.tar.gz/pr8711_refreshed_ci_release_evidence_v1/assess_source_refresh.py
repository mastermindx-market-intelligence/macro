#!/usr/bin/env python3
"""Compare exact preserved CI source/plan data across the normal main refresh."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parent
OWNER = 'company-relationship-candidates'
CHANGED_JOB = 'unrun-grading-board'
CHANGED_STEP = 'board ledger row-persistence + same-as_of continuity guard'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def digest(value):
    return sha(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode())


def record(relative):
    raw = (ROOT / relative).read_bytes()
    return {'path': relative, 'bytes': len(raw), 'sha256': sha(raw)}


class Loader(yaml.SafeLoader):
    pass


def unique(loader, node, deep=False):
    loader.flatten_mapping(node)
    result = {}
    for key, value in loader.construct_pairs(node, deep=deep):
        assert key not in result, ('duplicate YAML key', key)
        result[key] = value
    return result


Loader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, unique)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    assert Path(args.output).name == args.output
    old_manifest = 'context/prior_04b708_legacy_jobs.yml'
    new_manifest = 'sources/merged_legacy_jobs.yml'
    old_plan_path = 'context/prior_04b708_ci_plan.json'
    new_plan_path = 'artifacts/11621065219/ci-plan.json'
    assert record(old_manifest)['sha256'] == '6659e06968a347a6ccba8a35d07bdc7bb601e32acd84d410ad66ad238eed08cd'
    assert record(new_manifest)['sha256'] == 'e76d0e54e8401c56016447e8542c750fae02e78c7f160943b1d6a986b8a979aa'
    assert record(old_plan_path)['sha256'] == '7e2749004b694f74e9e111bbc292b2c0c3b42fb2cabe5c69a70b36397771ac11'
    assert record(new_plan_path)['sha256'] == '869dca9067e433a7041c9dba35468bb61f21c062454a3f798f15632e41bbb6df'
    old = yaml.load((ROOT / old_manifest).read_text(), Loader=Loader)
    new = yaml.load((ROOT / new_manifest).read_text(), Loader=Loader)
    old_jobs, new_jobs = old['jobs'], new['jobs']
    assert set(old_jobs) == set(new_jobs) and len(old_jobs) == len(new_jobs) == 254
    changes = [job for job in old_jobs if old_jobs[job] != new_jobs[job]]
    assert changes == [CHANGED_JOB]
    assert {k: v for k, v in old.items() if k != 'jobs'} == {k: v for k, v in new.items() if k != 'jobs'}
    expected = copy.deepcopy(old_jobs[CHANGED_JOB])
    matching = [step for step in expected['steps'] if step.get('name') == CHANGED_STEP]
    assert len(matching) == 1
    old_command = matching[0]['run']
    assert old_command == 'python -m pytest tests/test_us_board_ledger_continuity.py tests/test_us_board_continuity_guard.py -q'
    new_command = old_command[:-3] + ' tests/test_build_stock_library_price_clock.py -q'
    matching[0]['run'] = new_command
    assert expected == new_jobs[CHANGED_JOB]
    assert old_jobs[OWNER] == new_jobs[OWNER] and len(new_jobs[OWNER]['paths']) == 71
    old_plan = json.loads((ROOT / old_plan_path).read_text())
    new_plan = json.loads((ROOT / new_plan_path).read_text())
    assert old_plan['eligible_jobs'] == new_plan['eligible_jobs']
    assert old_plan['skipped_jobs'] == new_plan['skipped_jobs']
    before = {job['logical_job_id']: job for job in old_plan['semantic_jobs']}
    after = {job['logical_job_id']: job for job in new_plan['semantic_jobs']}
    placement_changes = [{'logical_job_id': job, 'prior_pack': before[job]['pack_index'],
                          'current_pack': after[job]['pack_index']} for job in before
                         if before[job]['pack_index'] != after[job]['pack_index']]
    execution_context_changes = [job for job in before
                                 if before[job]['job_exec_sha256'] != after[job]['job_exec_sha256']]
    assert execution_context_changes == []
    changed_semantics = [job for job in before
                         if {k: v for k, v in before[job].items() if k != 'pack_index'}
                         != {k: v for k, v in after[job].items() if k != 'pack_index'}]
    assert changed_semantics == [CHANGED_JOB]
    before_steps = {step['proof_id']: step for step in before[CHANGED_JOB]['steps']}
    after_steps = {step['proof_id']: step for step in after[CHANGED_JOB]['steps']}
    changed_proofs = [proof for proof in before_steps if before_steps[proof] != after_steps[proof]]
    assert changed_proofs == [CHANGED_STEP]
    result = {
        'schema': 'gmi.pr8711.refreshed_source_assessment/v1',
        'prior_tested_commit': '04b70807e6b0a7d48091997eb405f9cc53ade9ad',
        'tested_commit': '7d5fd7428fa91567db755117657f856e1347c5f9',
        'prior_manifest': record(old_manifest), 'current_manifest': record(new_manifest),
        'prior_plan': record(old_plan_path), 'current_plan': record(new_plan_path),
        'manifest_diff': record('UPSTREAM_MERGED_MANIFEST_DELTA.diff'),
        'all_manifest_jobs': 254, 'added_jobs': [], 'removed_jobs': [],
        'changed_job_ids': changes, 'changed_proof_ids': changed_proofs,
        'changed_step': {'logical_job_id': CHANGED_JOB, 'proof_id': CHANGED_STEP,
                         'old_command': old_command, 'new_command': new_command,
                         'prior_planned_job': before[CHANGED_JOB], 'current_planned_job': after[CHANGED_JOB]},
        'all_other_parsed_manifest_fields_identical': True,
        'eligible_inventory_identical': True, 'excluded_inventory_identical': True,
        'pack_assignments_identical': not placement_changes,
        'pack_assignment_changes': placement_changes,
        'job_execution_context_digest_changes': execution_context_changes,
        'semantic_change_limited_to_one_job_and_one_step': True,
        'owner': {'logical_job_id': OWNER, 'definition_identical': True,
                  'definition_canonical_sha256': digest(new_jobs[OWNER]), 'scope_path_count': 71,
                  'prior_planned_job': before[OWNER], 'current_planned_job': after[OWNER],
                  'full_definition': new_jobs[OWNER]},
        'proof_limit': 'Structural source/plan comparison only. No prior execution result supplies current-head CI proof.',
        'application_imports_or_tests': False, 'network_or_native_or_git_operations': False,
    }
    with (ROOT / args.output).open('x') as handle:
        json.dump(result, handle, indent=2, sort_keys=True)
        handle.write('\n')
    print(json.dumps({'output': record(args.output), 'changed_jobs': changes,
                      'changed_proofs': changed_proofs, 'owner_definition_unchanged': True,
                      'owner_current_pack': after[OWNER]['pack_index'],
                      'pack_placement_changes': len(placement_changes)}, indent=2))


if __name__ == '__main__':
    main()
