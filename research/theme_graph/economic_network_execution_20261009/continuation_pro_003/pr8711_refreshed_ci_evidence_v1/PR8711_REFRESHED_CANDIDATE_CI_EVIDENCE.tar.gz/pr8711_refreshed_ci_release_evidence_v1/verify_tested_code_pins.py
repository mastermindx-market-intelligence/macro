#!/usr/bin/env python3
"""Verify 53 accepted code byte pins against captured actual tested Git objects.

Pure preserved-data processing. No application/repository source imports,
execution, tests, native operations, Git commands or network requests.
"""
import argparse
import base64
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import stat

ROOT = Path(__file__).resolve().parent
HEAD = '693ee939c8a28920ef9de7bc32a9f47a7ba76b82'
TESTED = '7d5fd7428fa91567db755117657f856e1347c5f9'
TREE = '67c6a12f7b91e45b63614819a732753fa4a7599a'
REPO = 'mastermindx-market-intelligence/macro'
REFERENCE_SHA = 'e955ec0f462369f42b0d3689360682d1a30dcbcea63bf090d935db73b2c9d293'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def strict_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            assert key not in result, ('duplicate JSON key', key)
            result[key] = value
        return result
    return json.loads(raw.decode('utf8'), object_pairs_hook=pairs)


def read(relative):
    path = ROOT / relative
    assert path.is_relative_to(ROOT) and '..' not in Path(relative).parts
    for node in (path, *path.parents):
        if node.is_relative_to(ROOT):
            assert not node.is_symlink()
    assert stat.S_ISREG(path.lstat().st_mode)
    raw = path.read_bytes()
    assert len(raw) <= 16 * 1024 * 1024
    return raw


def captured_api(row):
    assert row['returncode'] == 0
    raw = gzip.decompress(base64.b64decode(row['raw_json_gzip_base64'], validate=True))
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    return strict_json(raw)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    assert Path(args.output).name == args.output
    capture_raw = read('tested_source_pin_read_001.json')
    capture = strict_json(capture_raw)
    reference_raw = read('context/EXPECTED_53_CODE_PINS.json')
    reference = strict_json(reference_raw)
    source_capture = strict_json(read('artifact_read_001_and_source_snapshot_001.json'))
    assert sha(reference_raw) == capture['expected_manifest_sha256'] == REFERENCE_SHA
    assert capture['head'] == HEAD and capture['tested_commit'] == TESTED and capture['tree_sha'] == TREE
    assert source_capture['tested_commit']['sha'] == TESTED and source_capture['tested_commit']['tree']['sha'] == TREE
    expected = {row['path']: row for row in reference['files']}
    assert len(expected) == len(reference['files']) == 53
    scopes = {path.split('/', 1)[0] for path in expected}
    tree_reads = {row['scope']: row for row in capture['tree_reads']}
    assert len(tree_reads) == len(capture['tree_reads']) and set(tree_reads) == {'root', *scopes}
    root_row = tree_reads['root']
    assert root_row['endpoint'] == f'repos/{REPO}/git/trees/{TREE}'
    root_tree = captured_api(root_row)
    assert root_tree['sha'] == TREE and root_tree['truncated'] is False
    root_entries = {entry['path']: entry for entry in root_tree['tree']}
    assert len(root_entries) == len(root_tree['tree'])
    entries = {}
    for scope in scopes:
        parent = root_entries[scope]
        assert parent['type'] == 'tree' and parent['mode'] == '040000'
        row = tree_reads[scope]
        assert row['endpoint'] == f"repos/{REPO}/git/trees/{parent['sha']}?recursive=1"
        tree = captured_api(row)
        assert tree['sha'] == parent['sha'] and tree['truncated'] is False
        local = {entry['path']: entry for entry in tree['tree']}
        assert len(local) == len(tree['tree'])
        for path, entry in local.items():
            entries[scope + '/' + path] = entry
    needed = {entries[path]['sha'] for path in expected}
    blob_rows = {row['git_blob_sha']: row for row in capture['blob_reads']}
    assert len(blob_rows) == len(capture['blob_reads']) and set(blob_rows) == needed
    actual_blobs = {}
    for blob, row in blob_rows.items():
        assert row['endpoint'] == f'repos/{REPO}/git/blobs/{blob}'
        body = captured_api(row)
        assert body['sha'] == blob and body['encoding'] == 'base64'
        raw = base64.b64decode(''.join(body['content'].split()), validate=True)
        assert len(raw) == body['size']
        assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + bytes([0]) + raw).hexdigest() == blob
        actual_blobs[blob] = raw
    declared = {row['path']: row for row in capture['source_files']}
    assert len(declared) == len(capture['source_files']) == 53 and set(declared) == set(expected)
    results = []
    for path, pin in expected.items():
        entry = entries[path]
        assert entry['type'] == 'blob' and entry['mode'] in {'100644', '100755'}
        raw = actual_blobs[entry['sha']]
        row = declared[path]
        assert entry['size'] == len(raw) == pin['byte_length'] == row['bytes'] == row['expected_bytes']
        assert sha(raw) == pin['sha256'] == row['sha256'] == row['expected_sha256']
        assert entry['sha'] == row['git_blob_sha'] and entry['mode'] == row['mode']
        assert gzip.decompress(base64.b64decode(row['content_gzip_base64'], validate=True)) == raw
        results.append({'path': path, 'bytes': len(raw), 'sha256': sha(raw), 'git_blob_sha': entry['sha'],
                        'mode': entry['mode'], 'matches_accepted_pin': True})
    output = {'schema': 'gmi.pr8711.refreshed_tested_source_pin_verification/v1',
              'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'head': HEAD, 'tested_commit': TESTED, 'tested_git_tree': TREE,
              'reference_manifest': {'path': 'context/EXPECTED_53_CODE_PINS.json', 'bytes': len(reference_raw),
                                     'sha256': sha(reference_raw), 'reference_reviewed_head': reference['reviewed_head']},
              'source_read_receipt': {'path': 'tested_source_pin_read_001.json', 'bytes': len(capture_raw),
                                      'sha256': sha(capture_raw)},
              'observed_at_utc': capture['observed_at_utc'], 'completed_at_utc': capture['completed_at_utc'],
              'status': 'ALL_53_ACCEPTED_CODE_BYTE_PINS_MATCH_ACTUAL_TESTED_TREE',
              'pinned_file_count': 53, 'unique_git_blob_count': len(actual_blobs),
              'total_pinned_file_bytes': sum(row['bytes'] for row in results),
              'all_matches': True, 'files': results,
              'retention': 'All actual tree/blob API response bytes and source bytes are losslessly retained in compressed base64 fields of the source read receipt.',
              'proof_limits': ['Byte compatibility for these 53 accepted engine/lib code paths, not a new functional code review.',
                               'This proof directly establishes the named selected-path byte identities; it does not infer them from a broad changed-file census.',
                               'No claim is made here for the other owner scope paths, tests, rights, production, predictive promotion, live freshness, holds or merge authority.'],
              'application_imports_or_tests': False, 'native_or_git_mutations': False,
              'verifier': {'path': 'verify_tested_code_pins.py', 'sha256': sha(read('verify_tested_code_pins.py'))}}
    target = ROOT / args.output
    with target.open('x', encoding='utf8') as handle:
        json.dump(output, handle, indent=2, sort_keys=True)
        handle.write('\n')
    print(json.dumps({'path': str(target), 'bytes': target.stat().st_size, 'sha256': sha(target.read_bytes()),
                      'status': output['status'], 'files': 53, 'unique_blobs': len(actual_blobs),
                      'total_pinned_file_bytes': output['total_pinned_file_bytes']}, indent=2))


if __name__ == '__main__':
    main()
