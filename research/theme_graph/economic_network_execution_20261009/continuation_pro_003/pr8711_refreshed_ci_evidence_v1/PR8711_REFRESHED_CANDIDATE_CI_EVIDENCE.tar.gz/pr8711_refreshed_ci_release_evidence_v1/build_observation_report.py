#!/usr/bin/env python3
"""Freeze reviewable summaries of a concluded independent CI evidence result."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = 'https://github.com/mastermindx-market-intelligence/macro'


def load(name):
    return json.loads((ROOT / name).read_text())


def record(name):
    raw = (ROOT / name).read_bytes()
    return {'path': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def write(name, value):
    raw = value.encode() if isinstance(value, str) else (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    with (ROOT / name).open('xb') as handle:
        handle.write(raw)
    return record(name)


def cell(value):
    return str(value).replace('|', '\\|').replace('\n', ' ')


def main():
    r = load('CI_EVIDENCE_VERIFICATION.json')
    assert r['completeness']['complete_ci_pass_evidence'] is True
    assert r['identity']['subject_head_sha'] == '693ee939c8a28920ef9de7bc32a9f47a7ba76b82'
    processes = load('native_read_scripts.json')
    assert processes['all_managed_processes_reconciled'] is True
    source = load('SOURCE_REFRESH_ASSESSMENT.json')
    upstream = load('UPSTREAM_COMMIT_CONFIRMATION.json')
    i, n = r['identity'], r['denominators']
    owner, contract, aggregate = r['owner'], r['contract_delta'], r['aggregate']
    assert owner['pack_index'] == 6 and owner['actual_result']['passed'] == 275
    outputs = []
    focused = {key: r[key] for key in (
        'identity', 'candidate_parent', 'tested_commit_parents', 'tested_commit_tree_sha',
        'observation_completed_at_utc', 'disposition', 'denominators', 'completeness',
        'observed_outcomes', 'aggregate', 'owner', 'contract_delta', 'ci_gate',
        'hosted_run', 'hosted_jobs', 'exact_head_checks', 'source_refresh',
        'accepted_application_byte_pins', 'proof_limits', 'authority')}
    focused.update(schema='gmi.pr8711.refreshed_focused_observation/v1',
                   full_verification=record('CI_EVIDENCE_VERIFICATION.json'),
                   upstream_confirmation=record('UPSTREAM_COMMIT_CONFIRMATION.json'),
                   native_processes=[{key: row[key] for key in ('pid', 'exit_code', 'runtime_seconds',
                                                              'purpose', 'receipt', 'reconciled')}
                                     for row in processes['processes']])
    outputs.append(write('FOCUSED_OBSERVATION.json', focused))
    outputs.append(write('ARTIFACT_INVENTORY.json', {
        'schema': 'gmi.pr8711.refreshed_actual_artifact_inventory/v1',
        'identity': i, 'observation_completed_at_utc': r['observation_completed_at_utc'],
        'original_zip_count': 15, 'exact_json_member_count': 15,
        'original_zip_and_member_inventory': r['artifact_inventory'],
        'fragment_inventory': r['fragment_inventory'], 'plan': r['plan']['raw'],
        'final_aggregate': aggregate, 'manifest': r['manifest'],
        'source_law_inventory': r['source_law_inventory'], 'whole_raw_logs': r['whole_log_inventory'],
        'accepted_application_byte_pins': r['accepted_application_byte_pins'],
        'source_refresh_assessment': record('SOURCE_REFRESH_ASSESSMENT.json'),
    }))
    timeline = []
    for path in sorted(ROOT.glob('artifact_read_*.json')):
        d = load(path.name)
        if 'run' in d and 'jobs' in d:
            timeline.append({'receipt': record(path.name), 'observed_at_utc': d['observed_at_utc'],
                             'completed_at_utc': d['completed_at_utc'],
                             'run_status': d['run']['status'], 'run_conclusion': d['run']['conclusion'],
                             'run_attempt': d['run']['run_attempt'],
                             'available_artifact_count': d['artifact_inventory']['total_count'],
                             'jobs': [{key: job[key] for key in ('id', 'name', 'status', 'conclusion')}
                                      for job in d['jobs']['jobs']]})
    outputs.append(write('READ_TIMELINE.json', {
        'schema': 'gmi.pr8711.refreshed_observation_timeline/v1', 'identity': i,
        'snapshots': timeline, 'all_earlier_observations_preserved': True,
        'preparation_observations': record('PREPARATION_OBSERVATIONS.json')}))
    fragments = {f['pack_index']: f for f in r['fragment_inventory']}
    hosted = {j['name']: j for j in r['hosted_jobs']}
    pack_rows = '\n'.join(f"| {index} | {hosted[f'ci-pack-{index}']['id']} | {hosted[f'ci-pack-{index}']['conclusion']} | "
                          f"{fragments[index]['logical_jobs']} | {fragments[index]['proof_steps']} |"
                          for index in range(12))
    artifact_rows = '\n'.join(f"| {a['artifact_id']} | `{a['artifact_name']}` | {a['zip']['bytes']:,} | `{a['zip']['sha256']}` |"
                             for a in r['artifact_inventory'])
    source_rows = '\n'.join(f"| `{s['path']}` | {s['bytes']:,} | `{s['sha256']}` |"
                           for s in [r['manifest'], *r['source_law_inventory']])
    log_rows = '\n'.join(f"| {l['role']} | {l['job_id']} | {l['bytes']:,} | `{l['sha256']}` |"
                        for l in r['whole_log_inventory'])
    check_rows = '\n'.join(f"| `{cell(c['name'])}` | {c['id']} | {c['status']} | {c['conclusion']} |"
                          for c in r['exact_head_checks'])
    process_rows = '\n'.join(f"| {p['pid']} | {cell(p['purpose'])} | {p['exit_code']} | {p['runtime_seconds']} |"
                            for p in processes['processes'])
    report = f'''# PR8711 refreshed-candidate independent CI evidence review

**The new exact-source CI run concluded successfully, and its complete semantic evidence reconciles independently against the actual tested source.** The frozen disposition is `{r['disposition']}`. This is a CI evidence conclusion; the principal retains canonical release adjudication, current freshness/holds, expected-head merge, accepted-source verification and the native C01 witness.

Observation completed: **{r['observation_completed_at_utc']}**. Reviewer: `/root/ci_release_evidence`. The complete machine-readable record is `CI_EVIDENCE_VERIFICATION.json`, with **{r['verification']['assertions_passed']:,} assertions passed**. Source was read as bytes, YAML data and AST; no repository application was imported or tested by this observer.

## Exact candidate, tested merge and plan

| Binding | Actual observed value |
|---|---|
| Candidate | `{i['subject_head_sha']}` |
| Candidate’s sole parent | `{r['candidate_parent']}` |
| Normal integration’s ordered parents | `42174563149254d2399e23e101baafd8b06f9b1e`, then `3bb1ee47939d9caa1db10a4e764365d3a2ee5b77` |
| Run / attempt / event | `{i['workflow_run_id']}` / `1` / `{i['event']}` |
| Actual tested synthetic commit | `{i['tested_tree_sha']}` |
| Tested commit’s ordered first parent | `{r['tested_commit_parents'][0]}` |
| Tested commit’s ordered second parent | `{r['tested_commit_parents'][1]}` |
| Distinct Git tree object | `{r['tested_commit_tree_sha']}` |
| Plan logical SHA-256 | `{r['plan']['logical_sha256']}` |
| Changed-path canonical SHA-256 | `{r['plan']['changed_files_sha256']}` |
| Actual merged manifest Git blob | `{r['manifest']['git_blob_sha']}` |
| Hosted run status / conclusion | `{r['hosted_run']['status']}` / `{r['hosted_run']['conclusion']}` |

The actual retained plan and immutable tested commit agree on base `3bb1ee4` and candidate `693ee939`. Actual hosted checkout logs bind their executed commit to the same synthetic merge. The workflow field named `tested_tree_sha` contains a commit SHA; this review records the distinct Git tree object separately.

Primary references: [PR8711]({REPO}/pull/8711), [exact run]({REPO}/actions/runs/{i['workflow_run_id']}), [candidate]({REPO}/commit/{i['subject_head_sha']}), [tested merge]({REPO}/commit/{i['tested_tree_sha']}), [actual merged manifest]({REPO}/blob/{i['tested_tree_sha']}/.github/ci/legacy-jobs.yml), and [accepted upstream commit]({REPO}/commit/{i['base_sha']}). Retained receipts enumerate the exact GET endpoints, Git object identifiers and byte hashes.

## Complete accounting

| Evidence dimension | Observed | Exact denominator |
|---|---:|---:|
| Original artifact ZIPs and exact JSON members | 15 | 15 |
| Raw pack fragments | 12 | 12 |
| Selected logical jobs represented | 98 | 98 |
| Proof steps represented | 316 | 316 |
| Selected code jobs | 98 | 182 code jobs |
| Explicitly excluded code jobs | 84 | 182 code jobs |
| Other manifest gate jobs | 72 | 254 total manifest jobs |
| Changed paths in this plan | 137 | 137 |
| Accepted engine/lib byte pins | 53 | 53 |

All **316 observed proof steps passed**. No planned pack, job, step or final artifact is missing. The 254 manifest jobs are not a test-pass denominator. The full 98-job selected inventory and 84-job excluded inventory exhaust the 182 code jobs. Q07 is present but explicitly excluded; this packet does not claim it ran.

The verifier recomputes all **98 execution-context digests** and **316 planned step specification digests** from the actual merged source. It checks exact plan, run, head, base and source bindings; complete selected/excluded and pack partitions; unique fragment jobs/steps; proof order; outcomes; and the final aggregate. It does not rerun the scope-selection planner or infer semantic success from job names.

| Pack | Hosted job ID | Hosted conclusion | Logical jobs | Proof steps |
|---:|---:|---|---:|---:|
{pack_rows}

The final aggregate is **`{aggregate['status']}`**, with **98 jobs**, **316 proof steps**, classification counts **`{json.dumps(aggregate['classifications'], sort_keys=True)}`**, and zero infrastructure findings. Logical evidence SHA-256: **`{aggregate['evidence_sha256']}`**. The verifier independently reconstructs the complete all-pass aggregate and compares the whole document. The actual final gate’s full JSON stdout, summary values and clear notices match that retained aggregate.

## Actual new owner and contract results

The relationship owner belongs to **pack 6** in this generation. Its hosted job is **`{owner['hosted_job_id']}`**. The exact logical owner and proof are `company-relationship-candidates` and `File, pinned-source and immutable observation replay contracts`.

```sh
{owner['command']}
```

The actual new owner log reports **{owner['actual_result']['passed']} passed in {owner['actual_result']['seconds']}s**, at line **{owner['actual_result']['line']}**. Its current raw fragment, exact source command, execution context and step specification are bound to that result. Execution-context SHA-256: `5ff9e1dd799a76ff34ad59e95d95cafbc10cea6c6f4cb58da6922bb28801ff6f`. Step specification SHA-256: `3f346c8660ce1278b5d782982c639324dfa4412faa4856e91d19d822a0481d70`.

The new contract-delta job **`{contract['hosted']['id']}`** concluded **`{contract['hosted']['conclusion']}`**. Its actual full log reports **{contract['actual_counts']['introduced']} introduced and {contract['actual_counts']['inherited']} inherited** findings against base `3bb1ee47939d`. That count and the actual `--base` command are verified from the new log. The final `ci-gate` independently enforced the successful semantic and contract results.

| Whole raw log | Hosted job ID | Bytes | SHA-256 |
|---|---:|---:|---|
{log_rows}

Each whole log is retained unchanged, with exact length/hash and line references. New-run results are not supplied by the earlier candidate’s logs.

## What the source refresh changed

The independently read accepted upstream commit `3bb1ee4` has sole parent `40ebaeb` and exactly **three changed paths**: `.github/ci/legacy-jobs.yml`, `scripts/build_stock_library.py`, and `tests/test_build_stock_library_price_clock.py`. `UPSTREAM_COMMIT_CONFIRMATION.json` binds the complete immutable commit response. This inventory is not a functional review of that upstream change.

The complete actual CI manifests before and after this refresh have **254 jobs**, no added or removed job identifiers, and identical top-level parsed fields. Exactly one existing job definition changes: **`unrun-grading-board`**. Its existing continuity step adds `tests/test_build_stock_library_price_clock.py` to the pytest command. The exact raw diff is retained in `UPSTREAM_MERGED_MANIFEST_DELTA.diff`; both full manifests and both plans are retained for offline structural comparison. The semantic reconciler, pack runner, differential contract checker, workflow and test-discovery source files are all byte-identical across these two generations.

The selected and excluded inventories remain identical, and all **98 execution-context digests remain unchanged**. Exactly one source step specification changes: `board ledger row-persistence + same-as_of continuity guard`, now SHA-256 `cfdce80317b9e4e7e15e9cb3c94f015ff0a081b8789bc8cd985ffa92469eb181`.

The actual new plan nevertheless **changes 51 job-to-pack assignments**. The relationship owner moves from pack 11 to **pack 6**. Its entire job definition, all 71 scope paths, command and proof digests remain unchanged. The verifier uses the new actual placement. `SOURCE_REFRESH_ASSESSMENT.json` fully enumerates the placement changes and the single changed source specification. An initial preparation assertion that placement was unchanged stopped before creating a report; the exact preparation source and refusal are preserved in `PREPARATION_OBSERVATIONS.json`. This was an observer preparation correction, not a hosted CI failure, and no result was attributed to the wrong owner pack.

The separate source verifier makes fresh GET reads of **three complete Git trees and 52 unique blobs** at the actual tested tree. All **53 accepted engine/lib paths**, totaling **1,483,905 bytes**, match the accepted reference pins. Every raw tree/blob API response and exact source byte sequence is losslessly retained in `tested_source_pin_read_001.json`. The accepted reference manifest remains checkpoint `6b58f15adae3b1d402d9993c52609d00083f1453`; its historical preservation in later reviews does not change that reference revision.

This establishes byte compatibility for the 53 named paths. It does not create a new functional code review or independently certify the other 18 owner scope paths. The principal’s broader 71-input and research-path preservation judgment is retained as attributed provenance.

| Exact actual CI source preserved as data | Bytes | SHA-256 |
|---|---:|---|
{source_rows}

## Preserved successful history and principal release boundary

The previous corrected candidate `4217456` obtained its own complete successful proof in run `37932039980`, tested at `04b708` on base `40ebaeb`. A later principal freshness check refused release after accepted main `3bb1ee4` changed CI definitions. The successful historical proof remains successful; that later freshness ruling does not rewrite its result. The principal applied an ordinary main integration and published this new evidence-only candidate for its own naturally triggered CI.

This observer independently checked the new candidate’s sole integration parent and that integration’s ordered parents. The evidence-only commit is exactly one commit ahead of the integration and changes **13 paths**, all in the existing `continuation_pro_003` research directory. The previous frozen successful packet’s **90 original manifest members** remain byte-identical. Its archive, manifest, verification, README and readable report match the actual Git blobs carried by this candidate; `PRIOR_SUCCESS_PACKET_PRESERVATION.json` records those checks. The prior archive was not replayed, rewritten or used as new execution proof.

The exact committed `CI_REFRESH_ADJUDICATION_002.md` and `CI_REFRESH_CHECKPOINT_MANIFEST_002.json` were independently read at the candidate and retained under `principal_context/`. They identify the prior canonical freshness refusal, normal integration and owner-preserving intent. They are principal-authored provenance, not this observer’s independent present-tense release ruling. Root retains the final protected procedure, source/hold/review and baseline checks, expected-head merge and fresh-store postmerge C01 witness.

## Complete artifact byte inventory

Every artifact below was downloaded through its actual artifact GET endpoint. Original ZIP length and SHA-256 match the API inventory. Each ZIP contains exactly one safe regular JSON member; duplicate names, links, traversal and malformed member shapes are refused. All available artifacts equal the exact selected snapshot inventory. Full member hashes, CRCs, logical jobs, proof steps and source bindings are enumerated in `ARTIFACT_INVENTORY.json` and the full verifier record.

| Artifact ID | Artifact name | ZIP bytes | ZIP SHA-256 |
|---:|---|---:|---|
{artifact_rows}

## Exact-head checks and native process accounting

The complete census contains **{len(r['exact_head_checks'])} exact-head checks**. Actual non-success states remain visible. The principal’s committed adjudication describes the inactive pilot context under the existing helper; this observer does not waive a check or adjudicate its current policy binding.

| Check | Check ID | Status | Conclusion |
|---|---:|---|---|
{check_rows}

All **{len(processes['processes'])}** managed native GET processes completed and were reconciled. The exact scripts, purposes, completion footers and capture references are preserved in `native_read_scripts.json`.

| Native PID | Purpose | Exit code | Runtime seconds |
|---:|---|---:|---:|
{process_rows}

## Offline reproduction and limits

`VERIFIER_DERIVATION.json`, `CI_VERIFIER_REVISION.diff` and `SOURCE_PIN_VERIFIER_REVISION.diff` preserve the exact verifier lineage. Core ZIP/member, plan/source/step, full-log, aggregate and Git-object validation algorithms are reused. Changes bind the new generation’s actual identities, 137 paths, pack-6 owner, structural refresh and provenance. The previous verifier bytes remain exact under `verifier_origin/`.

The archive includes all actual artifacts and whole new logs, source/object bytes, structural comparison inputs, captures, inventories, reports and bounded scripts. It has an external regular-file-only manifest with every relative name, length and SHA-256. Safe extraction and unchanged verifier replays are recorded separately in the archive verification receipt. With Python 3 and PyYAML, use fresh output names from the extracted evidence directory:

```sh
PYTHONDONTWRITEBYTECODE=1 python -B assess_source_refresh.py --output FRESH_SOURCE_REFRESH_ASSESSMENT.json
PYTHONDONTWRITEBYTECODE=1 python -B verify_tested_code_pins.py --output FRESH_SOURCE_PIN_VERIFICATION.json
PYTHONDONTWRITEBYTECODE=1 python -B verify_refreshed_artifacts.py --snapshot {r['snapshot_file']} --output FRESH_CI_EVIDENCE_VERIFICATION.json
```

These read preserved evidence without Git, network, native operations, application imports or application tests. `PACKAGING_NOTES.md` distinguishes exact raw artifact/source/log retention from decoded API metadata, and documents source-capture transport framing and the preparation correction.

This packet supplies no current main freshness or live-hold certification, merge authorization, policy waiver, source-rights permission, custody/authorship guarantee, historical availability, factual admission, Graph1 admission, production acceptance or predictive promotion. Functional code review and the actual accepted-source native C01 proof retain their existing owners.
'''
    outputs.append(write('OBSERVATION_REPORT.md', report))
    notes = '''# Refreshed-candidate evidence packaging notes

The earlier failed/pending and successful packets remain unchanged. This generation independently binds candidate 693ee939, run 37938576895 attempt 1, and tested merge 7d5fd742. Previous source and plan data are used only for structural comparisons. No prior execution outcome supplies current-head proof.

Historical partial reports describe the artifacts available at their own observation times. Their earlier snapshots do not include later transfers. The complete offline replay uses the final selected snapshot and all retained captures; an earlier snapshot is not relabelled as a complete inventory after new artifacts arrive.

## Exact local paths and provenance

`LOCAL_PROVENANCE_COPIES.json` and `LOCAL_PROVENANCE_COPIES_002.json` identify unchanged helper, verifier-origin, accepted-reference, prior manifest and prior plan copies. Actual current CI source is retained under `sources/`, including the real workflow path `sources/.github/workflows/ci.yml`. Actual candidate principal context is retained under `principal_context/`, with immutable repository paths, refs, Git blobs and hashes recorded separately. Every artifact has `artifacts/<actual-id>/original.zip` and its exact original JSON member.

`PRIOR_SUCCESS_PACKET_PRESERVATION.json` records checks of all 90 previous packet members and current committed Git blob identity of its five transferred archive/report objects. The previous archive itself is already committed and is not recursively recopied into this new archive. Its exact SHA-256 remains 9723b71acf3d44f6918ddb8c1d319e49bcc760c048106ec3277d09c94a7a7805.

## Preparation observations

The first source-assessment preparation stopped on an assumption of unchanged pack placement. Actual plan comparison found 51 changed placements, including the owner moving from pack 11 to pack 6. The selected/excluded sets, owner definition and source digests remained exact. The initial preparation source and its failed assertion are preserved; the corrected assessor and CI verifier explicitly check the actual new placements. No report was emitted by the refused initial assessment, and no hosted result was attributed to the wrong owner pack. This is not a hosted CI failure.

The fresh 53-pin native source read, PID 45345, emitted one compact JSON stdout body. RDC inserted one line break at its 1 MiB tool-output boundary. Joining that provider framing recovered the full JSON, after which every embedded raw API and source byte length, SHA-256 and Git blob hash was independently checked. No second source read or inferred source reconstruction was used. All new native log captures use the corrected ANSI sanitizer; the earlier generation’s separate sanitizer observation is not attributed to this generation.

Artifacts, JSON members, source bodies and whole new-candidate CI logs retain exact raw bytes. Metadata snapshots retain their full decoded JSON objects and actual GET length/hash receipts; that is not a claim to preserve every metadata response’s original serialization. Source tree/blob response bytes are additionally preserved losslessly in the 53-pin capture.

The outer archive normalizes its own metadata and ordering. It preserves original GitHub ZIP bytes and their internal metadata. An explicit external regular-file manifest excludes archive outputs, links, traversal, caches and unrelated lanes. Credentials and signed artifact redirect URLs were not retained. Whole raw new CI logs are included because full actual-log evidence is part of this task; bounded common credential/signed-URL scans are recorded without changing any log.

Replay outputs are created only under the scratch extraction directory with fresh names. They are accounted for separately and are not inserted into the frozen archive. No packaging or verification step imports or executes repository applications, runs application tests, mutates Git/native files, reruns hosted CI, grants a waiver or authorizes merge.
'''
    outputs.append(write('PACKAGING_NOTES.md', notes))
    print(json.dumps({'outputs': outputs, 'disposition': r['disposition']}, indent=2))


if __name__ == '__main__':
    main()
