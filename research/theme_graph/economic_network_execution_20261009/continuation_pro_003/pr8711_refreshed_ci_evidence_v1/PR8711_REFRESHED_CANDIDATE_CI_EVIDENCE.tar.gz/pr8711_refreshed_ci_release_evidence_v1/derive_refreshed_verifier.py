#!/usr/bin/env python3
"""Derive this generation's verifier from the frozen previous verifier bytes.

Only scratch code is written. No repository source imports or execution.
"""
import difflib
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def record(name):
    raw = (ROOT / name).read_bytes()
    return {'path': name, 'bytes': len(raw), 'sha256': sha(raw)}


def main():
    origin = 'verifier_origin/verify_corrected_artifacts.py.txt'
    raw = (ROOT / origin).read_bytes()
    assert sha(raw) == 'bff17768023f9d422b4981cae1097d1dc33e296a1e3e376c24e6eec1ac8d5c33'
    source = raw.decode()
    replacements = {
        'corrected head 4217456': 'refreshed head 693ee939',
        '42174563149254d2399e23e101baafd8b06f9b1e': '693ee939c8a28920ef9de7bc32a9f47a7ba76b82',
        '9df735bbeaa8d0f4d4967296270bfb2246a5212f': '1a1f4a2db62afd5d943a86a391e104f9dad560a1',
        '40ebaebdbcd57eedaa627623f1cfd1860ff3ee3a': '3bb1ee47939d9caa1db10a4e764365d3a2ee5b77',
        '04b70807e6b0a7d48091997eb405f9cc53ade9ad': '7d5fd7428fa91567db755117657f856e1347c5f9',
        '37932039980': '37938576895',
        "MANIFEST_PIN = (1248919, '6659e06968a347a6ccba8a35d07bdc7bb601e32acd84d410ad66ad238eed08cd')":
            "MANIFEST_PIN = (1249132, 'e76d0e54e8401c56016447e8542c750fae02e78c7f160943b1d6a986b8a979aa')",
        'a5cfd271fe02ad22458cab56cc29e878de8a8fc9': '07a8f2eb51f852e4da38142b00d862473889adcc',
        '7e2749004b694f74e9e111bbc292b2c0c3b42fb2cabe5c69a70b36397771ac11': '869dca9067e433a7041c9dba35468bb61f21c062454a3f798f15632e41bbb6df',
        'e637d0f4907e040b1a4069d7c14748fba81137387e83ea6ec255bf0d53c5ce88': '5545065ee276bfda077d80ab6ce243eff0142223066378eb3ed2d36ccd05d0e0',
        '5f2a89d5b23b7b307df3fbfd53bff817d26a7cedac3cf0937006ccc925b34ce4': '8300e2c6dc44f2afd29c6a011a5f1d6daa272bd79959a0904fe47e8e416a2cdd',
        'run_snapshot_and_sources_001.json': 'artifact_read_001_and_source_snapshot_001.json',
        "    mapping_capture = doc('mapping_and_snapshot_002.json')": "    refresh_assessment = doc('SOURCE_REFRESH_ASSESSMENT.json')",
        'candidate_parent_is_original_failed_head': 'candidate_parent_is_normal_main_integration',
        "== plan['changed_files_count'] == 125": "== plan['changed_files_count'] == 137",
        "'changed_paths': 125": "'changed_paths': 137",
        "planned[OWNER]['pack_index'] == 11": "planned[OWNER]['pack_index'] == 6",
        "'pack_index': 11": "'pack_index': 6",
        "hosted['ci-pack-11']": "hosted['ci-pack-6']",
        "'bytes': 17455": "'bytes': 17458",
        'f512c883f14d31565b249ebff8f653cae2f7969c91975d4d0eae2358b5821675': 'b2141ef10a9383ff9c7104617e4ebbb2b7159beefa1731c4a14712b3d52d789c',
        'gmi.pr8711.corrected_independent_ci_evidence_review/v1': 'gmi.pr8711.refreshed_independent_ci_evidence_review/v1',
        'verify_corrected_artifacts.py': 'verify_refreshed_artifacts.py',
        'Old-run test outcomes are not inputs to the corrected-run conclusion; the old packet remains frozen.':
            'Prior failed and successful packets remain frozen; no prior-run execution outcome supplies proof for this refreshed head.',
        'The GitHub PR base field lagged the actual tested synthetic parent; plan, immutable commit and checkout evidence bind the actual base.':
            'The actual new plan, immutable tested commit and hosted checkout logs bind this generation to its own tested base.',
        'All 53 accepted engine/lib source byte pins independently match the actual tested Git tree. This is byte compatibility, not a new functional review or certification of the other 18 owner scope paths; the complete upstream changed-file census remains capped.':
            'All 53 accepted engine/lib source byte pins independently match the actual tested Git tree. This is byte compatibility, not a new functional review or certification of the other 18 owner scope paths.',
    }
    for old, new in replacements.items():
        assert old in source, old
        source = source.replace(old, new)
    source = re.sub(r'\bOLD\b', 'INTEGRATION', source)
    marker = "    tested = source_capture['tested_commit']\n"
    source = source.replace(marker, """    check('normal_integration_ordered_parents', discovery['integration_commit']['sha'] == INTEGRATION
          and [p['sha'] for p in discovery['integration_commit']['parents']]
              == ['42174563149254d2399e23e101baafd8b06f9b1e', BASE])
    evidence_commit = source_capture['evidence_commit_compare']
    check('evidence_only_commit_ancestry_and_inventory', evidence_commit['ahead_by'] == 1
          and evidence_commit['behind_by'] == 0 and evidence_commit['total_commits'] == 1
          and evidence_commit['base_commit'] == evidence_commit['merge_base_commit'] == INTEGRATION
          and evidence_commit['commits'] == [{'sha': HEAD, 'parents': [INTEGRATION]}]
          and len(evidence_commit['files']) == 13
          and len({row['filename'] for row in evidence_commit['files']}) == 13
          and all(row['filename'].startswith(
              'research/theme_graph/economic_network_execution_20261009/continuation_pro_003/')
              for row in evidence_commit['files']))
""" + marker)
    begin = source.index('    # Independently retain and verify the exact archival representation repair.\n')
    end = source.index('    # The separate preserved-data verifier independently checks the actual\n', begin)
    refresh_block = """    # The prior source and plan supply structural comparisons, not execution
    # results. Verify the new owner's actual placement from the current plan.
    check('source_refresh_assessment_frozen', record('SOURCE_REFRESH_ASSESSMENT.json') == {
        'path': 'SOURCE_REFRESH_ASSESSMENT.json', 'bytes': 15241,
        'sha256': 'afefdf230cf75aaa4e83d3e572f261bf8736e00a319d96be763378a84d9a443d'})
    prior_manifest_raw = read('context/prior_04b708_legacy_jobs.yml')
    check('prior_source_manifest_exact_pin', len(prior_manifest_raw) == 1248919
          and sha(prior_manifest_raw) == '6659e06968a347a6ccba8a35d07bdc7bb601e32acd84d410ad66ad238eed08cd')
    prior_manifest = yaml.load(prior_manifest_raw.decode('utf8'), Loader=UniqueSafeLoader)
    prior_definitions = prior_manifest['jobs']
    check('refresh_exact_one_manifest_job_changed', set(prior_definitions) == set(definitions)
          and [jid for jid in prior_definitions if prior_definitions[jid] != definitions[jid]]
              == ['unrun-grading-board'])
    check('refresh_owner_definition_identical', prior_definitions[OWNER] == definitions[OWNER]
          == refresh_assessment['owner']['full_definition']
          and digest(definitions[OWNER]) == refresh_assessment['owner']['definition_canonical_sha256']
          and len(definitions[OWNER]['paths']) == 71)
    check('source_refresh_assessment_input_pins', refresh_assessment['prior_manifest']
          == record('context/prior_04b708_legacy_jobs.yml')
          and refresh_assessment['current_manifest'] == record('sources/merged_legacy_jobs.yml')
          and refresh_assessment['prior_plan'] == record('context/prior_04b708_ci_plan.json')
          and refresh_assessment['current_plan'] == record(plan_entry['path'])
          and refresh_assessment['manifest_diff'] == record('UPSTREAM_MERGED_MANIFEST_DELTA.diff'))
    prior_plan_raw = read('context/prior_04b708_ci_plan.json')
    check('prior_plan_exact_pin_for_structural_comparison', len(prior_plan_raw) == 95459
          and sha(prior_plan_raw) == '7e2749004b694f74e9e111bbc292b2c0c3b42fb2cabe5c69a70b36397771ac11')
    prior_plan = loads(prior_plan_raw)
    before = {job['logical_job_id']: job for job in prior_plan['semantic_jobs']}
    placement_changes = [{'logical_job_id': jid, 'prior_pack': before[jid]['pack_index'],
                          'current_pack': planned[jid]['pack_index']} for jid in before
                         if before[jid]['pack_index'] != planned[jid]['pack_index']]
    check('refresh_actual_pack_placement_changes', len(placement_changes) == 51
          and placement_changes == refresh_assessment['pack_assignment_changes']
          and planned[OWNER]['pack_index'] == 6 and before[OWNER]['pack_index'] == 11
          and before[OWNER] == refresh_assessment['owner']['prior_planned_job']
          and planned[OWNER] == refresh_assessment['owner']['current_planned_job'])
    check('refresh_scope_and_execution_context_inventories',
          prior_plan['eligible_jobs'] == plan['eligible_jobs']
          and prior_plan['skipped_jobs'] == plan['skipped_jobs']
          and all(before[jid]['job_exec_sha256'] == planned[jid]['job_exec_sha256'] for jid in before))
    changed_steps = [{'logical_job_id': jid, 'prior': old_step, 'current': new_step}
                     for jid in before for old_step, new_step in zip(before[jid]['steps'], planned[jid]['steps'])
                     if old_step != new_step]
    check('refresh_exact_changed_proof_specification', len(changed_steps) == 1
          and changed_steps[0]['logical_job_id'] == 'unrun-grading-board'
          and changed_steps[0]['current'] == {
              'proof_id': 'board ledger row-persistence + same-as_of continuity guard',
              'step_spec_sha256': 'cfdce80317b9e4e7e15e9cb3c94f015ff0a081b8789bc8cd985ffa92469eb181'})
    preservation = doc('PRIOR_SUCCESS_PACKET_PRESERVATION.json')
    check('prior_success_packet_preservation_identity', preservation['current_head'] == HEAD
          and preservation['prior_head'] == '42174563149254d2399e23e101baafd8b06f9b1e'
          and preservation['prior_run'] == 37932039980
          and preservation['all_original_members_unchanged'] is True
          and preservation['original_member_count'] == len(preservation['original_members']) == 90
          and preservation['prior_packet_files_changed'] is False
          and preservation['prior_archive_replay_repeated'] is False)
    compare_by_path = {row['filename']: row for row in evidence_commit['files']}
    check('prior_archive_and_companions_bound_to_current_commit',
          len(preservation['exact_committed_objects']) == 5 and all(
              compare_by_path[row['current_committed_path']]['sha'] == row['git_blob_sha']
              for row in preservation['exact_committed_objects']))
    prior_archive = next(row for row in preservation['exact_committed_objects']
                         if row['current_committed_path'].endswith('.tar.gz'))
    check('prior_success_archive_exact_frozen_identity', prior_archive['bytes'] == 3809105
          and prior_archive['sha256'] == '9723b71acf3d44f6918ddb8c1d319e49bcc760c048106ec3277d09c94a7a7805'
          and prior_archive['git_blob_sha'] == 'd35e4abbd66acf3acb13a03cc03f2cffc55d943d')
    principal_rows = []
    for capture_name, capture in captures:
        for item in capture.get('principal_context_sources', []):
            relative = 'principal_context/' + item['name']
            body = read(relative)
            check('principal_context_source_' + item['name'],
                  item['ref'] == HEAD and item['returncode'] == 0
                  and len(body) == item['bytes'] and sha(body) == item['sha256']
                  and git_blob(body) == item['git_blob_sha']
                  and gzip.decompress(base64.b64decode(item['content_gzip_base64'], validate=True)) == body
                  and compare_by_path[item['repository_path']]['sha'] == item['git_blob_sha'])
            principal_rows.append({**record(relative), 'ref': HEAD, 'repository_path': item['repository_path'],
                                   'git_blob_sha': item['git_blob_sha'], 'source_receipt': capture_name,
                                   'scope': 'Principal-authored provenance; not an independent current release ruling.'})
    check('principal_context_exact_inventory', len(principal_rows) == 2
          and {row['path'] for row in principal_rows} == {
              'principal_context/CI_REFRESH_ADJUDICATION_002.md',
              'principal_context/CI_REFRESH_CHECKPOINT_MANIFEST_002.json'})

"""
    source = source[:begin] + refresh_block + source[end:]
    begin = source.index("           'source_correction': {")
    end = source.index("           'accepted_application_byte_pins': {", begin)
    source = source[:begin] + """           'source_refresh': {'assessment': record('SOURCE_REFRESH_ASSESSMENT.json'),
                'prior_source_manifest': record('context/prior_04b708_legacy_jobs.yml'),
                'prior_plan': record('context/prior_04b708_ci_plan.json'),
                'integration_commit': INTEGRATION,
                'integration_ordered_parents': ['42174563149254d2399e23e101baafd8b06f9b1e', BASE],
                'evidence_commit_changed_paths': evidence_commit['files'],
                'owner_definition_identical': True, 'owner_current_pack': 6,
                'pack_assignment_changes': placement_changes, 'changed_proof_specs': changed_steps,
                'prior_packet_preservation': record('PRIOR_SUCCESS_PACKET_PRESERVATION.json'),
                'principal_context_inventory': principal_rows},
""" + source[end:]
    begin = source.index("           'input_receipts': [record(name) for name in [")
    end = source.index("           'proof_limits':", begin)
    source = source[:begin] + """           'input_receipts': [record(name) for name in dict.fromkeys([
                'candidate_discovery_001.json', 'SOURCE_REFRESH_ASSESSMENT.json',
                'PRIOR_SUCCESS_PACKET_PRESERVATION.json', 'SOURCE_PIN_VERIFICATION.json',
                'tested_source_pin_read_001.json', 'context/EXPECTED_53_CODE_PINS.json',
                *[name for name, capture in captures]])],
""" + source[end:]
    target = ROOT / 'verify_refreshed_artifacts.py'
    compile(source.encode(), str(target), 'exec')
    with target.open('x') as handle:
        handle.write(source)
    diff = ''.join(difflib.unified_diff(raw.decode().splitlines(keepends=True), source.splitlines(keepends=True),
                                     fromfile='preserved_421_ci_verifier.py', tofile='refreshed_693_ci_verifier.py'))
    with (ROOT / 'CI_VERIFIER_REVISION.diff').open('x') as handle:
        handle.write(diff)
    receipt = {
        'schema': 'gmi.pr8711.refreshed_verifier_derivation/v1',
        'prior_ci_verifier': record(origin), 'current_ci_verifier': record(target.name),
        'prior_source_pin_verifier': record('verifier_origin/verify_tested_code_pins.py.txt'),
        'current_source_pin_verifier': record('verify_tested_code_pins.py'),
        'source_assessment_verifier': record('assess_source_refresh.py'),
        'ci_revision': record('CI_VERIFIER_REVISION.diff'),
        'source_pin_revision': record('SOURCE_PIN_VERIFIER_REVISION.diff'),
        'unchanged_algorithms': ['Strict artifact ZIP/member length/hash/API binding',
            'Complete plan/source/step/result reconciliation and all-pass aggregate reconstruction',
            'Whole actual owner, contract and final-gate log matching',
            'Complete actual Git tree/blob and 53-file source byte verification'],
        'revisions': ['Exact new head, integration parent, tested merge/base, run and source/plan pins',
            '137 changed paths; current owner pack 6 after actual plan rebalance',
            'Source refresh structural comparison and exact 51 pack-placement changes',
            'Previous archive preservation and current committed principal-context provenance',
            'Generation schema, capture filenames and accurate proof-limit wording'],
        'prior_execution_outcomes_used_as_current_proof': False,
        'non_all_pass_limit': 'Failure/inheritance aggregate reconciliation is not claimed by the all-pass verifier; any such result requires bounded review.',
    }
    with (ROOT / 'VERIFIER_DERIVATION.json').open('x') as handle:
        json.dump(receipt, handle, indent=2, sort_keys=True)
        handle.write('\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
