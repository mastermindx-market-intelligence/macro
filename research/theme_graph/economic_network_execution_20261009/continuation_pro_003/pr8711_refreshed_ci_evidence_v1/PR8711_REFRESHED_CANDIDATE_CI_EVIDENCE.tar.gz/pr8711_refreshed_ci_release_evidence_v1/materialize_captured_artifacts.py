#!/usr/bin/env python3
"""Scratch-only retention of previously GET-read bytes; no network or app imports."""
import argparse
import base64
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import stat
import zipfile

ROOT = Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def safe(name):
    assert type(name) is str and name and not name.startswith('/') and '\\' not in name
    assert all(part not in {'', '.', '..'} for part in name.split('/'))
    assert str(PurePosixPath(name)) == name
    return name


def retain(path, raw):
    assert path.is_relative_to(ROOT)
    path.parent.mkdir(parents=True, exist_ok=True)
    assert all(not parent.is_symlink() for parent in [path.parent, *path.parent.parents] if parent.is_relative_to(ROOT))
    if path.exists():
        assert stat.S_ISREG(path.lstat().st_mode) and not path.is_symlink() and path.read_bytes() == raw
    else:
        with path.open('xb') as stream:
            stream.write(raw)
    assert path.read_bytes() == raw
    return {'path': str(path.relative_to(ROOT)), 'byte_length': len(raw), 'sha256': sha(raw)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--receipt', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    receipt_path = ROOT / safe(args.receipt)
    document = json.loads(receipt_path.read_bytes())
    inventory = []
    artifact_rows = document.get('artifacts', [])
    # A metadata snapshot carries the GitHub inventory object, not downloaded
    # ZIP bodies. It supplies no bytes to materialize; its source rows may do so.
    if isinstance(artifact_rows, dict):
        assert set(artifact_rows) == {'total_count', 'artifacts'}
        artifact_rows = []
    for row in artifact_rows:
        assert row['returncode'] == 0
        raw = base64.b64decode(row['zip_base64'], validate=True)
        assert len(raw) == row['zip_bytes'] and sha(raw) == row['zip_sha256']
        destination = ROOT / 'artifacts' / str(row['artifact_id'])
        zip_record = retain(destination / 'original.zip', raw)
        archive = zipfile.ZipFile(io.BytesIO(raw))
        infos = archive.infolist()
        assert len(infos) == len({entry.filename for entry in infos})
        assert len(infos) == len(row['members']) == 1
        members = []
        for entry, expected in zip(infos, row['members']):
            safe(entry.filename)
            assert not entry.is_dir() and stat.S_IFMT(entry.external_attr >> 16) in (0, stat.S_IFREG)
            assert entry.filename == expected['name'] and entry.file_size <= 8 * 1024 * 1024
            data = archive.read(entry)
            assert len(data) == expected['bytes'] and sha(data) == expected['sha256']
            json.loads(data.decode('utf-8'))
            members.append({**retain(destination / entry.filename, data), 'archive_member_name': entry.filename,
                            'crc32': entry.CRC, 'compressed_size': entry.compress_size,
                            'external_attr': entry.external_attr, 'create_system': entry.create_system})
        inventory.append({'artifact_id': row['artifact_id'], 'artifact_name': row['name'],
                          'endpoint': row['endpoint'], 'zip': zip_record, 'members': members})
    sources = []
    blob = document.get('tested_manifest_blob')
    if blob and blob['returncode'] == 0:
        compressed = base64.b64decode(blob['content_gzip_base64'], validate=True)
        raw = gzip.decompress(compressed)
        assert len(raw) == blob['bytes'] and sha(raw) == blob['sha256']
        assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == blob['git_blob_sha']
        sources.extend([retain(ROOT / 'sources' / 'merged_legacy_jobs.yml', raw),
                        retain(ROOT / 'sources' / 'merged_legacy_jobs.transfer.gz', compressed)])
    for item in document.get('sources', []):
        if item.get('returncode') != 0 or 'content_gzip_base64' not in item:
            continue
        raw = gzip.decompress(base64.b64decode(item['content_gzip_base64'], validate=True))
        assert len(raw) == item['bytes'] and sha(raw) == item['sha256']
        assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == item['git_blob_sha']
        sources.append(retain(ROOT / 'sources' / safe(item['path']), raw))
    out = {'schema': 'gmi.pr8711.retained_artifact_materialization/v1',
           'source_receipt': args.receipt, 'source_receipt_sha256': sha(receipt_path.read_bytes()),
           'artifacts': inventory, 'sources': sources,
           'source_diagnostics': document.get('diagnostics', []), 'source_bytes_changed': False}
    target = ROOT / safe(args.output)
    with target.open('x', encoding='utf-8') as stream:
        json.dump(out, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps({'file': str(target), 'byte_length': target.stat().st_size,
                      'sha256': sha(target.read_bytes()), 'retained_artifacts': len(inventory),
                      'sources': sources}, indent=2))


if __name__ == '__main__':
    main()
