# Refreshed-candidate evidence packaging notes

The earlier failed/pending and successful packets remain unchanged. This generation independently binds candidate 693ee939, run 37938576895 attempt 1, and tested merge 7d5fd742. Previous source and plan data are used only for structural comparisons. No prior execution outcome supplies current-head proof.

Historical partial reports describe the artifacts available at their own observation times. Their earlier snapshots do not include later transfers. The complete offline replay uses the final selected snapshot and all retained captures; an earlier snapshot is not relabelled as a complete inventory after new artifacts arrive.

## Exact local paths and provenance

`LOCAL_PROVENANCE_COPIES.json` and `LOCAL_PROVENANCE_COPIES_002.json` identify unchanged helper, verifier-origin, accepted-reference, prior manifest and prior plan copies. Actual current CI source is retained under `sources/`, including the real workflow path `sources/.github/workflows/ci.yml`. Actual candidate principal context is retained under `principal_context/`, with immutable repository paths, refs, Git blobs and hashes recorded separately. Every artifact has `artifacts/<actual-id>/original.zip` and its exact original JSON member.

`PRIOR_SUCCESS_PACKET_PRESERVATION.json` records checks of all 90 previous packet members and current committed Git blob identity of its five transferred archive/report objects. The previous archive itself is already committed and is not recursively recopied into this new archive. Its exact SHA-256 remains 9723b71acf3d44f6918ddb8c1d319e49bcc760c048106ec3277d09c94a7a7805.

## Preparation observations

The first source-assessment preparation stopped on an assumption of unchanged pack placement. Actual plan comparison found 51 changed placements, including the owner moving from pack 11 to pack 6. The selected/excluded sets, owner definition and source digests remained exact. The initial preparation source and its failed assertion are preserved; the corrected assessor and CI verifier explicitly check the actual new placements. No report was emitted by the refused initial assessment, and no hosted result was attributed to the wrong owner pack. This is not a hosted CI failure.

The fresh 53-pin native source read, PID 45345, emitted one compact JSON stdout body. RDC inserted one line break at its 1 MiB tool-output boundary. Joining that provider framing recovered the full JSON, after which every embedded raw API and source byte length, SHA-256 and Git blob hash was independently checked. No second source read or inferred source reconstruction was used. All new native log captures use the corrected ANSI sanitizer; the earlier generation’s separate sanitizer observation is not attributed to this generation.

Artifacts, JSON members, source bodies and whole new-candidate CI logs retain exact raw bytes. Metadata snapshots retain their full decoded JSON objects and actual GET length/hash receipts; that is not a claim to preserve every metadata response’s original serialization. Source tree/blob response bytes are additionally preserved losslessly in the 53-pin capture.

The outer archive normalizes its own metadata and ordering. It preserves original GitHub ZIP bytes and their internal metadata. An explicit external regular-file manifest excludes archive outputs, links, traversal, caches and unrelated lanes. Credentials and signed artifact redirect URLs were not retained. Whole raw new CI logs are included because full actual-log evidence is part of this task; bounded common credential/signed-URL scans are recorded without changing any log.

Replay outputs are created only under the scratch extraction directory with fresh names. They are accounted for separately and are not inserted into the frozen archive. No packaging or verification step imports or executes repository applications, runs application tests, mutates Git/native files, reruns hosted CI, grants a waiver or authorizes merge.
