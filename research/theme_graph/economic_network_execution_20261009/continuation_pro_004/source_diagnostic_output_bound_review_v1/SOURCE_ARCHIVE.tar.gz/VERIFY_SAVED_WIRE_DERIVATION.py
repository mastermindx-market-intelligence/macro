"""Verify retained request/result arithmetic only; no application import/call."""
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path

OUT = Path('/workspace/scratch/9fd3d58c239a/lanes/source_diagnostic_output_bound_review_v1')


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False).encode('utf-8')


def binding(raw):
    return {'byte_length': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def bundles(request):
    for record in request['records']:
        for cls in record['classes']:
            yield cls['shares']
            yield cls['price']
    for rate in request['fx']['rates']:
        yield rate['bundle']


def main():
    raw_old = gzip.decompress((OUT / 'DENSE_FILLED_BOUNDARIES.request.json.gz').read_bytes())
    raw_new = gzip.decompress((OUT / 'ESCAPED_ASSERTION_IDS.request.json.gz').read_bytes())
    raw_result = gzip.decompress((OUT / 'DENSE_FILLED_BOUNDARIES.result.json.gz').read_bytes())
    assert binding(raw_old)['sha256'] == 'ae06938825d9638c3386c8acc414f3285b2c46dde239328bfd69c2b4a34f14da'
    assert binding(raw_new)['sha256'] == '1d561f1f0708d70b8749b412d01e6012021b918d9c42ef7864dc1e871c2ecad4'
    assert binding(raw_result)['sha256'] == 'ad94dc10061b7630f58e16961a825f1a194967bc375bde9664c6ad52bbd9fdab'
    old, new, result = map(json.loads, (raw_old, raw_new, raw_result))
    changes = {}
    kinds = {}

    def note(old_value, new_value, kind):
        if old_value == new_value:
            return
        assert old_value not in changes or changes[old_value] == new_value
        changes[old_value] = new_value
        kinds[old_value] = kind

    for old_row, new_row in zip(old['records'], new['records'], strict=True):
        for old_cls, new_cls in zip(old_row['classes'], new_row['classes'], strict=True):
            note(old_cls['class_id'], new_cls['class_id'], 'class_id')
    for old_bundle, new_bundle in zip(bundles(old), bundles(new), strict=True):
        for old_assertion, new_assertion in zip(old_bundle['assertions'], new_bundle['assertions'], strict=True):
            for field in ('assertion_id', 'publisher_id'):
                note(old_assertion[field], new_assertion[field], field)
    occurrences = Counter()

    def transform(value, *, count):
        if isinstance(value, dict):
            assert not (set(value) & changes.keys())
            return {key: transform(item, count=count) for key, item in value.items()}
        if isinstance(value, list):
            return [transform(item, count=count) for item in value]
        if isinstance(value, str) and value in changes:
            if count:
                occurrences[value] += 1
            return changes[value]
        return value

    assert canonical(transform(old, count=False)) == raw_new
    projected = transform(result, count=True)
    id_changes = [value for value in changes if kinds[value] == 'assertion_id']
    assert len(id_changes) == 465 and all(occurrences[value] == 4 for value in id_changes)
    wire_deltas = Counter()
    for value, count in occurrences.items():
        wire_deltas[kinds[value]] += count * (len(canonical(changes[value])) - len(canonical(value)))
    assert wire_deltas == {'class_id': -391680, 'publisher_id': -305670, 'assertion_id': 2267160}
    projected['request_binding']['raw'] = binding(raw_new)
    projected['request_binding']['canonical_content'] = binding(raw_new)
    known_bundles = {frozenset(a['assertion_id'] for a in bundle['assertions']): bundle for bundle in bundles(new)}
    updated = 0

    def rebind_bundles(value):
        nonlocal updated
        if isinstance(value, dict):
            if 'bundle_content_binding' in value and 'supplied_assertions' in value:
                key = frozenset(a['assertion_id'] for a in value['supplied_assertions'])
                value['bundle_content_binding'] = binding(canonical(known_bundles[key]))
                updated += 1
            for child in value.values():
                rebind_bundles(child)
        elif isinstance(value, list):
            for child in value:
                rebind_bundles(child)

    rebind_bundles(projected)
    projected_raw = canonical(projected)
    expected_projection = json.loads((OUT / 'PHASE2_DERIVATION.json').read_bytes())['analytical_unbounded_response_projection']
    assert binding(projected_raw) == {k: expected_projection[k] for k in ('byte_length', 'sha256')}
    assert len(canonical('\x00' * 256)) == 1538
    assert (10239 * 392) == 4013688
    # Verify the specific correction to the initial independent rank prediction.
    metadata = json.loads((OUT / 'DENSE_FILLED_BOUNDARIES.construction.json').read_bytes())
    by_activity = {}
    for activity in ('SEMICONDUCTOR_CLOUD', 'INDUSTRIALS', 'CONSUMER', 'ENERGY_MATERIALS'):
        members = [r for r in metadata['records'] if r['country'] == 'JP' and r['activity'] == activity]
        count = Counter(r['price_index'] for r in members)
        assert len(members) == 94 and count == {0: 91, 1: 1, 2: 1, 3: 1}
        by_activity[activity] = {'N': len(members), 'price4': count[0], 'price3': count[1],
                                 'price2': count[2], 'price1': count[3], 'k1': 47, 'k2': 71}
    old_check_raw = (OUT / 'SAVED_RESULT_CHECK.json').read_bytes()
    assert hashlib.sha256(old_check_raw).hexdigest() == 'c996aebcd348815885ef4efc87337389d1a68ce400bd1b9bc764a1149453e660'
    corrected = json.loads(old_check_raw)
    corrected['schema'] = 'independent.wp02.output_probe_saved_result_check/v2'
    corrected['supersedes_explanation_only_of'] = binding(old_check_raw)
    corrected['explanation'] = (
        'Each affected JP pool has 94 rows: 91 at price 4, plus one each at prices 3, 2 and 1. '
        'The 90 added rows augment the single original price-4 row. k1=47 and k2=71 both fall '
        'at price 4. The four original price-3 rows therefore become S and are valid INCLUDE '
        'choices. The constructor prediction of 376 critical L competitors becomes 372 actual '
        'infeasible-completion exclusions. The earlier saved-check wording of 92 high and two '
        'lower rows was a reviewer narrative error; its four identified rows and actual outcomes were correct.'
    )
    corrected['independent_pool_counts'] = by_activity
    (OUT / 'SAVED_RESULT_CHECK_002.json').write_text(json.dumps(corrected, sort_keys=True, indent=2) + '\n')
    receipt = {
        'schema': 'independent.wp02.saved_wire_derivation_verification/v1',
        'application_imports': 0, 'additional_API_calls': 0,
        'request_label_only_transformation_exact': True,
        'changed_assertion_ID_count': len(id_changes),
        'each_changed_assertion_ID_actual_prior_output_occurrences': 4,
        'output_wire_deltas_before_binding_digit_effects': dict(wire_deltas),
        'bundle_bindings_recomputed_using_supplied_input_arrays': updated,
        'bundle_binding_length_digit_growth': len(projected_raw) - len(raw_result) - sum(wire_deltas.values()),
        'analytical_projection': binding(projected_raw),
        'analytical_projection_is_not_actual_API_output': True,
        'projected_body_not_saved': True,
        'actual_original_output': binding(raw_result),
        'old_request': binding(raw_old), 'new_request': binding(raw_new),
        'max_json_quoted_256_UTF8_byte_string_wire_bytes': 1538,
        'initial_per_trial_upper_bound_is_ASCII_only': True,
        'corrected_loose_trial_upper_bytes': 10239,
        'corrected392_trial_product_bytes': 4013688,
        'global_combined_unreachability_bound_proved': False,
        'four_JP_pool_counts': by_activity,
        'initial_saved_result_check_preserved': (OUT / 'SAVED_RESULT_CHECK.json').read_bytes() == old_check_raw,
    }
    (OUT / 'SAVED_WIRE_VERIFICATION.json').write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'additional_API_calls': 0, 'projection_verified': binding(projected_raw),
                      'label_only_request_delta_verified': True, 'initial_prediction_correction_verified': True}, sort_keys=True))


if __name__ == '__main__':
    main()
