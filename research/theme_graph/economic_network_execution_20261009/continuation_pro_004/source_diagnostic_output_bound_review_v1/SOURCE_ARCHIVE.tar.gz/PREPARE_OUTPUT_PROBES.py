"""Construct only artificial byte requests; no kernel import/API call.

Combine a forced INT cut with long identifiers, exact large decimal factors and
as many equivalent price assertions as the actual byte/token budgets permit.
"""
from collections import Counter
import copy
from fractions import Fraction
import gzip
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path('/workspace/scratch/9fd3d58c239a')
OUT=ROOT/'lanes/source_diagnostic_output_bound_review_v1'
ACTIVITIES=('SEMICONDUCTOR_CLOUD','INDUSTRIALS','CONSUMER','ENERGY_MATERIALS','FINANCIALS','HEALTHCARE')
GROUPS=('US','CN_MAINLAND','HK','CA','UK','JP','EU')
EVENTS=('ADMISSION','REMOVAL','TRANSFER','CONVERSION','IDENTITY_REPLACEMENT','PRIMARY_STATUS_CHANGE')
LIMIT=2097152


def canonical(x):
    return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()


def binding(raw):
    return {'byte_length':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def metrics(raw):
    inside=escape=False;depth=maximum=tokens=0
    for char in raw.decode():
        if inside:
            if escape: escape=False
            elif char=='\\': escape=True
            elif char=='"': inside=False
        elif char=='"': inside=True;tokens+=1
        elif char in '[{': depth+=1;maximum=max(maximum,depth);tokens+=1
        elif char in ']}': depth-=1
        elif char in ',:': tokens+=1
    return dict(binding(raw),lexical_tokens=tokens,maximum_depth=maximum)


def priority(s):
    parts=[p.encode() for p in ('issuer-priority','GMI-WP02-20261009-v1',s)]
    return hashlib.sha256(b''.join(len(p).to_bytes(8,'big')+p for p in parts)).digest()


def decimal(n):
    s=str(n).rjust(25,'0')
    return s[:-24]+'.'+s[-24:]


class Inputs:
    def __init__(self): self.sources={};self.counter=0;self.search_steps=0
    def evidence(self,text):
        raw=text.encode();key='s'+hashlib.sha256(raw).hexdigest()[:10]
        if key in self.sources: assert self.sources[key]['content']==text
        self.sources[key]={'source_id':key,'content':text,'byte_length':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
        return {'source_id':key,'start':0,'end':len(raw)}
    def issuer(self,role):
        while True:
            self.counter+=1;self.search_steps+=1
            prefix='ARTIFICIAL_OUTPUT_BOUND|'+str(self.counter)+'|'
            s=prefix+'x'*(256-len(prefix))
            first=priority(s)[0]
            if role=='ANY' or (role=='EARLY' and first<32) or (role=='LATE' and first>=224): return s


def aid(rid,component,index,length=256):
    text=rid+'|'+component+'|'+str(index)+'|'
    return text+'a'*(length-len(text))


def assertion(inputs,rid,component,value,index=0,length=256):
    return {'assertion_id':aid(rid,component,index,length),'publisher_id':'p','coordinate':'2026-09-30',
            'valid_to':None,'public_upper':'2026-10-01T00:00:00Z','value':value,'unit_basis':'u','status':'ACTUAL',
            'evidence':inputs.evidence(value)}


def build(extra_records,large_numbers=False):
    inputs=Inputs();descriptors=[]
    for country in GROUPS:
        for activity in ACTIVITIES:
            if country=='UK':
                if activity not in ACTIVITIES[:4]: continue
                indices=(0,0)
            else: indices=range(4)
            for index in indices: descriptors.append((country,activity,index))
    for index in range(extra_records): descriptors.append(('JP',ACTIVITIES[index%4],0))
    assert len(descriptors)==152+extra_records
    share=decimal(10**71-101) if large_numbers else '100000000'
    prices=[decimal((10**70+37)*m) if large_numbers else str(m) for m in (4,3,2,1)]
    scale=decimal(10**71-303) if large_numbers else '1'
    usd=decimal(10**71-61) if large_numbers else '1.1'
    jpy=decimal(10**71-123) if large_numbers else '1.1'
    records=[];members=[];meta=[]
    for i,(country,activity,index) in enumerate(descriptors):
        rid='r'+str(i);early=country in ('JP','EU') and activity in ACTIVITIES[:4] and index<2
        role='EARLY' if early else 'LATE' if country in ('UK','JP','EU') else 'ANY'
        issuer=inputs.issuer(role)
        share_a=assertion(inputs,rid,'SHARES',share)
        price_a=assertion(inputs,rid,'PRICE',prices[index])
        cls={'class_id':'c','kind':'ORDINARY','d_basis':'u','shares':{'state_kind':'POINT','assertions':[share_a],'relations':[]},
             'price':{'state_kind':'POINT','assertions':[price_a],'relations':[]},'quote_scale':scale,
             'quote_scale_evidence':inputs.evidence(scale),'currency':'JPY','counter':{'mic':'m','security_id':'s'},
             'calendar':['2026-09-30'],'actions':[],'declared_event_ids':[],'share_bridge_event_ids':[],'price_bridge_event_ids':[]}
        records.append({'record_id':rid,'issuer_id':issuer,'eligibility':'ELIGIBLE','primary_groups':[country],
                        'activity':activity,'exclusion_reason':None,'exclusion_evidence':None,'class_ids':['c'],'classes':[cls]})
        members.append({'member_id':'m'+str(i),'record_id':rid,'partition_id':country,'instrument':'ORDINARY','primary_status':'PRIMARY'})
        meta.append({'record_id':rid,'issuer_id':issuer,'country':country,'activity':activity,'price_index':index,'early_forced_L_competitor':early})
    rates=[]
    for currency,value in [('USD',usd),('JPY',jpy)]:
        a=assertion(inputs,'ECB_MODEL',currency,value,length=24);a['unit_basis']='UNITS_'+currency+'_PER_EUR'
        rates.append({'currency':currency,'bundle':{'state_kind':'POINT','assertions':[a],'relations':[]}})
    member_source=inputs.evidence(canonical(members).decode())['source_id']
    event_source=inputs.evidence('[]')['source_id']
    history={'kind':'SNAPSHOT','target_date':'2026-09-30','anchor_date':'2026-09-30','anchor_public_upper':'2026-10-01T00:00:00Z',
             'partitions':[{'partition_id':c,'jurisdiction':c} for c in GROUPS],'declared_partition_ids':list(GROUPS),
             'anchor_members':members,'target_members':copy.deepcopy(members),'anchor_source_id':member_source,
             'target_source_id':member_source,'events_source_id':event_source,'events':[],
             'coverage_start':'2026-09-30','coverage_end':'2026-09-30','covered_event_kinds':list(EVENTS),
             'declared_event_ids':[],'expected_anchor_member_ids':[m['member_id'] for m in members],
             'expected_target_member_ids':[m['member_id'] for m in members]}
    n=len(records)
    counts={k:n for k in ('source_declared_total','exhaustive_total','raw_record_count','parsed_record_count','anchor_count','resulting_d_member_count','identity_resolved_issuer_count')}
    counts.update({k:0 for k in ('duplicates_resolved_count','evidenced_out_of_scope_count','potentially_eligible_omission_count','unresolved_potentially_eligible_count')})
    counts.update({'event_'+k:0 for k in EVENTS})
    request={'schema':'research.gmi.wp02.source_diagnostic_request/v1','mode':'SYNTHETIC_MODEL','sources':list(inputs.sources.values()),
             'records':records,'history':history,'fx':{'series':'ECB euro foreign exchange reference rates','available_dates':['2026-09-30'],
             'reference_date':'2026-09-30','rates':rates},'counts':counts,'stress_cases':[],'claims':{}}
    base=Fraction(share)*Fraction(scale)*Fraction(usd)/Fraction(jpy)
    expected={str(index):{'numerator':str((base*Fraction(price)).numerator),'denominator':str((base*Fraction(price)).denominator)} for index,price in enumerate(prices)}
    return request,{'records':meta,'search_steps':inputs.search_steps,'expected_caps_by_price_index':expected,
                    'issuer_priority_policy':'Artificial labels deliberately chosen to exercise existing fixed priority; no real issuer reordering or reseed.',
                    'early_competitor_count':sum(m['early_forced_L_competitor'] for m in meta)}


def fill(request):
    # The assertion-copy route has3 additional identifier copies in a resolved
    # receipt. Each appended price assertion is equivalent, with a unique ID.
    additions=[];raw=canonical(request)
    for row in request['records']:
        bundle=row['classes'][0]['price']
        for j in range(1,16):
            a=copy.deepcopy(bundle['assertions'][0]);a['assertion_id']=aid(row['record_id'],'PRICE',j)
            prospective_tokens=metrics(raw)['lexical_tokens']+metrics(canonical(a))['lexical_tokens']+1
            prospective_bytes=len(raw)+len(canonical(a))+1
            if prospective_tokens>160000 or prospective_bytes>LIMIT: break
            bundle['assertions'].append(a);additions.append((row['record_id'],j))
            raw=canonical(request)
        if metrics(raw)['lexical_tokens']+metrics(canonical(a))['lexical_tokens']+1>160000 or len(raw)+len(canonical(a))+1>LIMIT: break
    # Use remaining bytes for class IDs (up to3 output copies for2 input copies).
    low,high=1,256
    while low<high:
        mid=(low+high+1)//2
        for row in request['records']:
            row['class_ids']=['c'*mid];row['classes'][0]['class_id']='c'*mid
        if len(canonical(request))<=LIMIT: low=mid
        else: high=mid-1
    for row in request['records']:
        row['class_ids']=['c'*low];row['classes'][0]['class_id']='c'*low
    raw=canonical(request)
    # A final per-class partial fill consumes residual bytes without adding
    # JSON tokens or changing any numeric/identity/eligibility premise.
    for row in request['records']:
        grow=min(256-len(row['class_ids'][0]),(LIMIT-len(raw))//2)
        if grow:
            row['class_ids']=['c'*(len(row['class_ids'][0])+grow)];row['classes'][0]['class_id']=row['class_ids'][0]
            raw=canonical(request)
    assert len(raw)<=LIMIT and metrics(raw)['lexical_tokens']<=160000
    return {'added_equivalent_price_assertions':len(additions),'class_id_lengths':dict(Counter(len(r['class_ids'][0]) for r in request['records'])),
            'bytes_remaining_before_2MiB':LIMIT-len(raw)}


def all_schema_prechecks(request):
    raw=canonical(request);m=metrics(raw)
    assert m['byte_length']<=LIMIT and m['lexical_tokens']<=160000 and m['maximum_depth']<=24
    assert len(request['records'])<=512 and len(request['sources'])<=1024
    aids=[]
    for row in request['records']:
        for cls in row['classes']:
            for field in ('shares','price'):
                assert len(cls[field]['assertions'])<=16
                aids.extend(a['assertion_id'] for a in cls[field]['assertions'])
    aids.extend(a['assertion_id'] for row in request['fx']['rates'] for a in row['bundle']['assertions'])
    assert len(aids)==len(set(aids)) and all(len(a.encode())<=256 for a in aids)
    for s in request['sources']:
        b=s['content'].encode();assert len(b)<=262144 and s['byte_length']==len(b) and s['sha256']==hashlib.sha256(b).hexdigest()
    return dict(m,records=len(request['records']),sources=len(request['sources']),assertions=len(aids))


def main():
    assert hashlib.sha256((ROOT/'lanes/source_diagnostic_kernel_v2/source_diagnostic.py').read_bytes()).hexdigest()=='f9814c8e65a155ae8273b4127661b5568e97a45c135b679f1db2eb84f36afdb6'
    ordinary,ometa=build(0)
    dense,dmeta=build(360,True)
    dmeta['density_fill']=fill(dense)
    rows=[]
    for name,request,meta in [('ORDINARY_CONTROL',ordinary,ometa),('DENSE_FORCED_INT',dense,dmeta)]:
        raw=canonical(request);checked=all_schema_prechecks(request)
        (OUT/(name+'.request.json.gz')).write_bytes(gzip.compress(raw,mtime=0))
        (OUT/(name+'.construction.json')).write_text(json.dumps(meta,sort_keys=True,ensure_ascii=False,indent=2)+'\n')
        rows.append({'case_id':name,'request':checked,'construction_file':name+'.construction.json',
                     'early_competitors':meta['early_competitor_count'],'density_fill':meta.get('density_fill')})
    plan={'schema':'independent.wp02.output_bound_probe_plan/v1','source_sha256':'f9814c8e65a155ae8273b4127661b5568e97a45c135b679f1db2eb84f36afdb6',
          'maximum_initial_public_calls':2,'actual_API_calls_so_far':0,'cases':rows,
          'ordinary_expected':'Complete artificial120 model and unchanged authority holds.',
          'dense_intended':'Attempt output amplification using equivalent assertion-ID retention and376 early infeasible completion trials; exact8MiB refusal counts only if returned model_state OUTPUT_REFUSED and OUTPUT_BYTE_LIMIT.',
          'no_unreachable_claim':'Failure to reach output8MiB is an observed limit of this construction, not a proof of global unreachability.',
          'resource_tradeoff':'Input bytes and160000 lexical tokens are jointly budgeted; IDs max256, price bundles max16, records512. Empty assertion arrays, malformed fields and pre-parser overflow are not output-bound witnesses.',
          'independent_arithmetic':'Large72-digit decimal quantities share a common exact positive factor; price ratios4:3:2:1 preserve the artificial rank/cut construction. All derived fractions are far below8192 bits.',
          'raw_source_acquisition_or_authentication':False,'policy_seed_or_source_constants_changed':False}
    (OUT/'PROBE_PLAN.json').write_text(json.dumps(plan,sort_keys=True,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'actual_API_calls':0,'cases':rows},sort_keys=True),flush=True)


if __name__=='__main__': main()
