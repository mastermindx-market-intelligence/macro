"""One authorized public-API call for the pre-frozen escaped-ID witness.

No private kernel helper, source/constant change, author helper or old suite.
"""
import datetime
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path('/workspace/scratch/9fd3d58c239a')
OUT = ROOT / 'lanes/source_diagnostic_output_bound_review_v1'
sys.path.insert(0, str(ROOT / 'lanes/source_diagnostic_kernel_review_v1'))
import RUN_FROZEN_VECTORS as guard
import PREPARE_OUTPUT_PROBES as preparation


def binding(raw):
    return {'byte_length': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False).encode('utf-8')


def main():
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    required = {
        'PHASE2_PLAN.json': '2a58b542c6546249435ab5fb2066d22b98df05ea6bb6fbb1b6a71b4ab6f5853a',
        'PHASE2_DERIVATION.json': 'fd9266b5a6845d868009e62144b4f4b71738952d7ca5bf2974462731c217e5f1',
        'EXECUTION_RECEIPT.json': '2f2847d59eaac47ba89c6dabc7e92d4d13795dfc02a05bcbfbcd83312415addd',
    }
    frozen = {name: (OUT / name).read_bytes() for name in required}
    for name, expected in required.items():
        assert hashlib.sha256(frozen[name]).hexdigest() == expected, name
    plan = json.loads(frozen['PHASE2_PLAN.json'])
    assert plan['actual_phase2_calls'] == 0 and plan['phase2_max_calls'] == 1
    packed_request = (OUT / plan['candidate_file']).read_bytes()
    request_raw = gzip.decompress(packed_request)
    request = json.loads(request_raw)
    prechecks = preparation.all_schema_prechecks(request)
    assert canonical(request) == request_raw
    assert prechecks == plan['candidate']
    ids = [a['assertion_id'] for record in request['records']
           for cls in record['classes'] for field in ('shares', 'price')
           for a in cls[field]['assertions']]
    ids += [a['assertion_id'] for rate in request['fx']['rates']
            for a in rate['bundle']['assertions']]
    assert len(ids) == len(set(ids)) == 1543
    assert max(len(value.encode('utf-8')) for value in ids) == 256
    assert sum('\x00' in value for value in ids) == 465
    assert sum(value.count('\x00') for value in ids) == 113358
    source = ROOT / 'lanes/source_diagnostic_kernel_v2/source_diagnostic.py'
    source_raw = source.read_bytes()
    assert binding(source_raw) == {
        'byte_length': 77602,
        'sha256': 'f9814c8e65a155ae8273b4127661b5568e97a45c135b679f1db2eb84f36afdb6',
    }
    pins = guard.verify_pins()
    runner_raw = Path(__file__).read_bytes()
    print(json.dumps({'phase': 'before_public_call', 'pid': os.getpid(),
                      'prechecks': prechecks, 'phase2_calls_so_far': 0,
                      'prior_calls_preserved': 2}, sort_keys=True), flush=True)
    spec = importlib.util.spec_from_file_location('escaped_wire_review_wp02', source)
    module = importlib.util.module_from_spec(spec)
    sys.addaudithook(guard.audit)
    guard.ACTIVE = True
    try:
        spec.loader.exec_module(module)
    finally:
        guard.ACTIVE = False
    exception = None
    elapsed = time.perf_counter()
    guard.ACTIVE = True
    try:
        result = module.diagnose(request_raw, policy_bytes=pins['policy'],
                                 adoption_bytes=pins['adoption'])
    except Exception as exc:
        exception = {'type': type(exc).__name__, 'message': str(exc)[:2000]}
        result = {'unexpected_exception': exception}
    finally:
        guard.ACTIVE = False
    duration = time.perf_counter() - elapsed
    result_raw = canonical(result)
    compressed = gzip.compress(result_raw, mtime=0)
    (OUT / 'ESCAPED_ASSERTION_IDS.result.json.gz').write_bytes(compressed)
    authority = guard.authority_errors(result) if exception is None else ['UNEXPECTED_EXCEPTION']
    reached = (
        exception is None
        and result.get('model_state') == 'OUTPUT_REFUSED'
        and {'code': 'OUTPUT_BYTE_LIMIT', 'scope': 'output'} in result.get('holds', [])
        and result.get('synthetic') is None
        and result.get('axes', {}).get('receipt_structure_state') == 'OUTPUT_BUDGET_REFUSAL'
    )
    assert source.read_bytes() == source_raw
    for name, raw in frozen.items():
        assert (OUT / name).read_bytes() == raw, name
    assert (OUT / plan['candidate_file']).read_bytes() == packed_request
    guard.verify_pins()
    receipt = {
        'schema': 'independent.wp02.output_bound_phase2_execution/v1',
        'case_id': 'ESCAPED_ASSERTION_IDS',
        'pid': os.getpid(), 'pid_scope': 'Observed scratch process-local PID; not a native host PID',
        'python': sys.version,
        'started_utc': start,
        'completed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'duration_seconds': round(duration, 6),
        'actual_phase2_public_API_calls': 1, 'prior_public_API_calls_preserved': 2,
        'total_public_API_calls_in_this_review': 3,
        'private_kernel_helper_calls': 0,
        'source': binding(source_raw), 'policy': binding(pins['policy']),
        'adoption': binding(pins['adoption']), 'runner': binding(runner_raw),
        'frozen_inputs': {name: binding(raw) for name, raw in frozen.items()},
        'request': binding(request_raw), 'compressed_request': binding(packed_request),
        'independent_prechecks': prechecks,
        'output': binding(result_raw), 'compressed_output': binding(compressed),
        'exception': exception, 'model_state': result.get('model_state'),
        'holds': result.get('holds'), 'authority_errors': authority,
        'actual_public_output_refusal_reached': reached,
        'synthetic_is_null': result.get('synthetic') is None,
        'named_effect_guard_events': guard.EVENTS,
        'guard_scope': 'Named Python filesystem-mutation/process/socket audit events during actual module import and diagnose only; no universal external-authority proof.',
        'source_method_plan_candidate_and_prior_receipt_unchanged': True,
        'native_or_real_source_execution': False,
        'analytical_projection_is_not_actual_API_output': True,
    }
    (OUT / 'PHASE2_EXECUTION_RECEIPT.json').write_text(
        json.dumps(receipt, ensure_ascii=False, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'pid': os.getpid(), 'phase2_API_calls': 1,
                      'total_API_calls': 3, 'actual_output': binding(result_raw),
                      'model_state': result.get('model_state'),
                      'holds': result.get('holds'), 'exception': exception,
                      'output_refusal_reached': reached,
                      'authority_errors': authority,
                      'named_effect_guard_events': guard.EVENTS}, sort_keys=True), flush=True)
    return 0 if reached and not authority and not guard.EVENTS else 1


if __name__ == '__main__':
    raise SystemExit(main())
