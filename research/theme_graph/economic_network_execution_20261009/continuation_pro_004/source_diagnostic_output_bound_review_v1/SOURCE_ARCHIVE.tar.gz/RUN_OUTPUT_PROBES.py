"""Execute exactly the two frozen constructed byte probes against corrected v2."""
from fractions import Fraction
import datetime
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

ROOT=Path('/workspace/scratch/9fd3d58c239a');OUT=ROOT/'lanes/source_diagnostic_output_bound_review_v1'
sys.path.insert(0,str(ROOT/'lanes/source_diagnostic_kernel_review_v1'))
import RUN_FROZEN_VECTORS as guard


def binding(raw): return {'byte_length':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def canonical(value): return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()


def main():
    plan_raw=(OUT/'EXECUTION_PLAN.json').read_bytes();assert hashlib.sha256(plan_raw).hexdigest()=='ff19a6e50cec60c97e2a655802c8044bc961837dc016feaaaa1a12afba58d6d2'
    plan=json.loads(plan_raw)
    source=ROOT/'lanes/source_diagnostic_kernel_v2/source_diagnostic.py';source_raw=source.read_bytes()
    assert hashlib.sha256(source_raw).hexdigest()=='f9814c8e65a155ae8273b4127661b5568e97a45c135b679f1db2eb84f36afdb6'
    pins=guard.verify_pins()
    spec=importlib.util.spec_from_file_location('output_bound_review_wp02',source);module=importlib.util.module_from_spec(spec)
    sys.addaudithook(guard.audit);guard.ACTIVE=True
    try: spec.loader.exec_module(module)
    finally: guard.ACTIVE=False
    rows=[]
    for case in plan['calls']:
        name=case['case_id'];raw=gzip.decompress((OUT/(name+'.request.json.gz')).read_bytes());assert binding(raw)==case['request']
        meta=json.loads((OUT/(name+'.construction.json')).read_text())
        exception=None;guard.ACTIVE=True
        try: result=module.diagnose(raw,policy_bytes=pins['policy'],adoption_bytes=pins['adoption'])
        except Exception as exc: exception={'type':type(exc).__name__,'message':str(exc)[:2000]};result={'unexpected_exception':exception}
        finally: guard.ACTIVE=False
        result_raw=canonical(result);compressed=gzip.compress(result_raw,mtime=0)
        (OUT/(name+'.result.json.gz')).write_bytes(compressed)
        actual_codes=[h for h in result.get('holds',[]) if h['code'] not in guard.BASE_HOLDS]
        authority=guard.authority_errors(result) if exception is None else ['UNEXPECTED_EXCEPTION']
        reached=result.get('model_state')=='OUTPUT_REFUSED' and {'code':'OUTPUT_BYTE_LIMIT','scope':'output'} in result.get('holds',[]) and result.get('synthetic') is None
        syn=result.get('synthetic') or {};selection=syn.get('selection') or {};intl=selection.get('INT') or {};trials=intl.get('trials') or []
        complete=result.get('model_state')=='ARTIFICIAL_MODEL_COMPLETE' and not actual_codes and len(selection.get('selected_issuer_ids') or [])==120
        cap_matches=None
        if complete:
            receipts={r['record_id']:r for r in syn['modeled_cap_receipts']}
            cap_matches=all(receipts[m['record_id']]['modeled_cap_usd']==meta['expected_caps_by_price_index'][str(m['price_index'])] for m in meta['records'])
            assert cap_matches
        categories={key:len(canonical(value)) for key,value in result.items()}
        if syn:
            categories['synthetic_components']={key:len(canonical(value)) for key,value in syn.items()}
            categories['INT_trials_bytes']=len(canonical(trials))
            categories['INT_failed_trials_bytes']=sum(len(canonical(t)) for t in trials if t['decision']=='EXCLUDE_INFEASIBLE_COMPLETION')
        row={'case_id':name,'input':binding(raw),'output':binding(result_raw),'compressed_output':binding(compressed),
             'exception':exception,'model_state':result.get('model_state'),'holds':actual_codes,'authority_errors':authority,
             'intended_output_refusal_reached':reached,'complete_model_returned':complete,'all_exact_constructed_caps_match':cap_matches,
             'actual_INT_initial_flow':(intl.get('initial_flow') or {}).get('achieved_flow'),
             'actual_residual_exclusion_count':sum(t['decision']=='EXCLUDE_INFEASIBLE_COMPLETION' for t in trials),
             'output8MiB_headroom':8388608-len(result_raw),'serialized_section_sizes':categories}
        rows.append(row)
        print(json.dumps({k:row[k] for k in ('case_id','input','output','exception','model_state','holds','intended_output_refusal_reached','complete_model_returned','actual_residual_exclusion_count','authority_errors')},sort_keys=True),flush=True)
    assert source.read_bytes()==source_raw and (OUT/'EXECUTION_PLAN.json').read_bytes()==plan_raw
    guard.verify_pins()
    receipt={'schema':'independent.wp02.output_bound_actual_execution/v1','pid':os.getpid(),
             'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_public_API_calls':len(rows),
             'private_kernel_helper_calls':0,'source':binding(source_raw),'policy':binding(pins['policy']),'adoption':binding(pins['adoption']),
             'frozen_plan':binding(plan_raw),'cases':rows,'named_effect_guard_events':guard.EVENTS,'source_and_prior_method_pins_unchanged':True,
             'production_or_real_source_effects':False,'scope':'Exactly two independent constructed probes; no global unreachability claim follows from a finite sample.'}
    (OUT/'EXECUTION_RECEIPT.json').write_text(json.dumps(receipt,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    assert rows[0]['complete_model_returned'] and rows[0]['all_exact_constructed_caps_match']
    assert all(r['exception'] is None and not r['authority_errors'] for r in rows) and not guard.EVENTS
    print(json.dumps({'pid':os.getpid(),'public_calls':len(rows),'output_limit_reached':any(r['intended_output_refusal_reached'] for r in rows),
                      'unexpected_exceptions':0,'effect_guard_events':len(guard.EVENTS)},sort_keys=True),flush=True)


if __name__=='__main__': main()
