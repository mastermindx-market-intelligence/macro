"""Independent narrow public-API verification of the frozen UTC correction.

Original v1 failure bytes are replayed unchanged. Other cases are explicit
mutations of independently retained inputs, not imports of author test fixtures.
"""
import copy
import datetime
from fractions import Fraction
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

ROOT=Path('/workspace/scratch/9fd3d58c239a')
OLD=ROOT/'lanes/source_diagnostic_kernel_review_v1'
OUT=ROOT/'lanes/source_diagnostic_kernel_review_v2'
sys.path.insert(0,str(OLD))
import RUN_FROZEN_VECTORS as review

PINS={
 'module':('lanes/source_diagnostic_kernel_v2/source_diagnostic.py',77602,'f9814c8e65a155ae8273b4127661b5568e97a45c135b679f1db2eb84f36afdb6'),
 'suite':('lanes/source_diagnostic_kernel_v2/test_gmi_source_diagnostic_kernel.py',50961,'d7f8dc3ebaf7adafe164e3a370c017ac4bb26e509e35ccf2ba5978429d915082'),
 'helper':('lanes/source_diagnostic_kernel_v2/synthetic_example.py',7312,'37db957fff940f2e9557e36586c07ee4a1a3ea534d9b3e36a5c96630b1a5aa78'),
 'contract':('lanes/source_diagnostic_kernel_v2/INPUT_CONTRACT.md',19420,'2806f32cd4367a4b9d6974ccea6ceaa2f2649794c35d256f0b6c5ccae781d0b5'),
 'v1_review_manifest':('lanes/source_diagnostic_kernel_review_v1/MANIFEST.json',27611,'8e5a2712a8eafadb37fc52950e99ed55ef6bebe33eb7652d3583fd44609dc3b9'),
}


def verify():
    raw=review.verify_pins()
    for name,(path,size,digest) in PINS.items():
        value=(ROOT/path).read_bytes()
        assert len(value)==size and hashlib.sha256(value).hexdigest()==digest,name
    return raw


def old_request(folder,name):
    return gzip.decompress((OLD/folder/(name+'.request.json.gz')).read_bytes())


def frozen_request(name):
    return gzip.decompress((review.VECTORS/'wire'/(name+'.request.gz')).read_bytes())


def bind_events(request):
    h=request['history'];text=review.canonical(h['events']).decode()
    raw=text.encode()
    row=next(r for r in request['sources'] if r['source_id']==h['events_source_id'])
    row.update(content=text,sha256=hashlib.sha256(raw).hexdigest(),byte_length=len(raw))
    assert json.loads(row['content'])==h['events']


def main():
    raw=verify()
    (OUT/'requests').mkdir(exist_ok=False);(OUT/'outputs').mkdir(exist_ok=False)
    spec=importlib.util.spec_from_file_location('independent_UTC_corrected_wp02',ROOT/PINS['module'][0])
    module=importlib.util.module_from_spec(spec)
    sys.addaudithook(review.audit)
    review.ACTIVE=True
    try:
        spec.loader.exec_module(module)
    finally:
        review.ACTIVE=False
    cases=[]
    def add(name,request_raw,*,expected_code=None,expected_cap=None,unchanged_output=None,reason=None):
        cases.append({'case_id':name,'raw':request_raw,'expected_code':expected_code,'expected_cap':expected_cap,
                      'unchanged_output':unchanged_output,'reason':reason})

    for scope in ('ANCHOR','CORRECTION'):
        for frac in ('000001','0000001'):
            name='K_PLUS_'+frac+'_'+scope
            value=old_request('cutoff_precision',name)
            if frac=='0000001':
                add('EXACT_V1_'+name,value,expected_code='UTC_TIMESTAMP_PRECISION_UNSUPPORTED',reason='Exact failingv1 bytes replayed; no fixture mutation')
            elif scope=='ANCHOR':
                add('EXACT_V1_'+name,value,expected_code='POST_CUTOFF_ANCHOR',unchanged_output=('cutoff_precision',name+'.result.json.gz'),reason='Exact valid negative control; complete output must remain byte-identical')
            else:
                add('EXACT_V1_'+name,value,expected_cap=1900000000,unchanged_output=('cutoff_precision',name+'.result.json.gz'),reason='Exact supported precision preserves prior1.9b cap and full result bytes')
    add('UNCHANGED_V01_COMPLETE_MODEL',frozen_request('V01_COMPLETE_MODEL'),expected_cap=400000000,
        unchanged_output=('frozen_outputs','V01_COMPLETE_MODEL.result.json.gz'))
    add('UNCHANGED_V10_WHOLE_SECOND_POST_K',frozen_request('V10_POST_K_REVISION'),expected_cap=1900000000,
        unchanged_output=('frozen_outputs','V10_POST_K_REVISION.result.json.gz'))

    for consumer in ('membership_event','share_assertion','price_assertion','fx_assertion','relation','action'):
        if consumer=='membership_event':
            source=old_request('recipe_input_corrections','EVENT_CONVERSION')
        elif consumer=='relation':
            source=old_request('boundary_recipes','EXPLICIT_PRE_K_SUPERSESSION')
        elif consumer=='action':
            source=frozen_request('V12_NEGATIVE')
        else:
            source=frozen_request('V01_COMPLETE_MODEL')
        for suffix in ('000000','0000001'):
            request=json.loads(source)
            if consumer=='membership_event': row=request['history']['events'][0]
            elif consumer=='fx_assertion': row=request['fx']['rates'][0]['bundle']['assertions'][0]
            elif consumer=='relation': row=request['records'][0]['classes'][0]['shares']['relations'][0]
            elif consumer=='action': row=request['records'][0]['classes'][0]['actions'][0]
            else: row=request['records'][0]['classes'][0]['shares' if consumer=='share_assertion' else 'price']['assertions'][0]
            row['public_upper']='2026-10-09T00:00:00.'+suffix+'Z'
            if consumer=='membership_event': bind_events(request)
            add('CONSUMER_'+consumer.upper()+'_'+suffix,review.canonical(request),
                expected_code='UTC_TIMESTAMP_PRECISION_UNSUPPORTED' if suffix=='0000001' else None,
                expected_cap=None if suffix=='0000001' else (2100000000 if consumer=='relation' else 1800000000 if consumer=='action' else 400000000),
                reason='Paired complete valid premise atK followed by isolated unsupported precision; event source bytes rebound where required')

    for suffix,ts in [('AT_K','2026-10-09T00:00:00Z'),('BEFORE_K','2026-10-08T23:59:59.999999Z')]:
        request=json.loads(frozen_request('V10_POST_K_REVISION'))
        bundle=request['records'][0]['classes'][0]['shares']
        bundle['assertions'][1]['public_upper']=bundle['relations'][0]['public_upper']=ts
        add('CORRECTION_'+suffix,review.canonical(request),expected_cap=2100000000,reason='Supported exact current-vintage correction should still be effective')

    for suffix,ts in [('SECONDS','2026-10-09T00:00:00Z'),('ONE_FRACTION','2026-10-09T00:00:00.0Z'),('BEFORE_SIX','2026-10-08T23:59:59.999999Z')]:
        request=json.loads(frozen_request('V01_COMPLETE_MODEL'))
        request['history']['anchor_public_upper']=ts
        add('ANCHOR_VALID_'+suffix,review.canonical(request),expected_cap=400000000)
    for suffix,ts,code in [('COMMA','2026-10-09T00:00:00,0Z','EXPLICIT_UTC_BOUND_REQUIRED'),
                          ('UNICODE_DIGIT','2026-10-09T00:00:00.٠Z','EXPLICIT_UTC_BOUND_REQUIRED'),
                          ('SEVEN_ZEROES','2026-10-09T00:00:00.0000000Z','UTC_TIMESTAMP_PRECISION_UNSUPPORTED')]:
        request=json.loads(frozen_request('V01_COMPLETE_MODEL'));request['history']['anchor_public_upper']=ts
        add('ANCHOR_SHAPE_'+suffix,review.canonical(request),expected_code=code)

    rows=[]
    for case in cases:
        name=case['case_id'];request_raw=case['raw']
        (OUT/'requests'/(name+'.request.json.gz')).write_bytes(gzip.compress(request_raw,mtime=0))
        exception=None
        review.ACTIVE=True
        try:
            result=module.diagnose(request_raw,policy_bytes=raw['policy'],adoption_bytes=raw['adoption'])
        except Exception as exc:
            exception={'type':type(exc).__name__,'message':str(exc)[:2000]}
            result={'unexpected_exception':exception}
        finally:
            review.ACTIVE=False
        result_raw=review.canonical(result)
        (OUT/'outputs'/(name+'.result.json.gz')).write_bytes(gzip.compress(result_raw,mtime=0))
        observed=review.summarize(result,request_raw) if exception is None else None
        actual_codes={h['code'] for h in observed['holds']} if observed else set()
        cap=observed and observed['first_supplied_record_cap_receipt']
        cap=cap and cap.get('modeled_cap_usd')
        cap_value=None if cap is None else Fraction(int(cap['numerator']),int(cap['denominator']))
        check=exception is None and not observed['real_authority_errors']
        if case['expected_code'] is not None:
            check=check and case['expected_code'] in actual_codes and observed['selected_count'] is None and cap is None
        else:
            check=check and result['model_state']=='ARTIFICIAL_MODEL_COMPLETE' and not actual_codes and observed['selected_count']==120 and cap_value==case['expected_cap']
        same=None
        if case['unchanged_output']:
            previous=gzip.decompress((OLD/case['unchanged_output'][0]/case['unchanged_output'][1]).read_bytes())
            same=result_raw==previous
            check=check and same
        row={'case_id':name,'request':review.binding(request_raw),'output':review.binding(result_raw),
             'reason':case['reason'],'expected_code':case['expected_code'],'expected_cap':case['expected_cap'],
             'observed':observed,'exception':exception,'complete_output_unchanged_where_required':same,'independent_oracle_met':bool(check)}
        rows.append(row)
        print(json.dumps({'case_id':name,'oracle_met':bool(check),'model_state':result.get('model_state'),
            'codes':sorted(actual_codes),'complete_output_unchanged':same,'exception':exception},sort_keys=True),flush=True)
    verify()
    receipt={'schema':'independent.wp02.UTC_corrective_public_replay/v1','pid':os.getpid(),
             'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_public_API_calls':len(rows),
             'exact_original_cutoff_requests_replayed':4,'paired_other_timestamp_consumers':6,
             'author_suite_or_fixture_helper_imported':False,'private_kernel_helper_calls':0,
             'all_oracles_met':all(r['independent_oracle_met'] for r in rows),'cases':rows,
             'effect_guard_events':review.EVENTS,'input_bindings':{n:dict(review.binding((ROOT/p).read_bytes()),path=p) for n,(p,_,_) in PINS.items()},
             'policy':review.binding(raw['policy']),'adoption':review.binding(raw['adoption']),
             'source_pins_unchanged_after':True,'v1_review_manifest_unchanged':True,
             'scope':'Correction ofv1R1 only; unconditional real-source rights/history/admission holds remain.'}
    (OUT/'CORRECTIVE_PUBLIC_REPLAY_RECEIPT.json').write_bytes(json.dumps(receipt,ensure_ascii=False,sort_keys=True,indent=2).encode()+b'\n')
    print(json.dumps({'pid':os.getpid(),'API_calls':len(rows),'all_oracles_met':receipt['all_oracles_met'],
                     'unexpected_exceptions':sum(r['exception'] is not None for r in rows),'effect_guard_events':len(review.EVENTS)},sort_keys=True),flush=True)
    return 0 if receipt['all_oracles_met'] and not review.EVENTS else 1


if __name__=='__main__':
    raise SystemExit(main())
