"""Independent scratch-only verification of the one archived MU refusal witness.

No application import, script execution, native access, provider request or
private-file read. All reads use explicit archived public evidence paths.
"""
from pathlib import Path
import ast
import datetime
import hashlib
import json
import os
import re
import shlex

HERE = Path(__file__).resolve().parent
LANES = HERE.parents[1]
PRINCIPAL = LANES / "native_mu_capture_principal_v1"
REVIEW = HERE.parent
FEASIBILITY = LANES / "native_massive_us_feasibility_v1"
SCRIPT_SHA = "6fe0f67b7335b31ef3e4a3eb9a914ac1557236689deb563ac8887b5bd2d53439"
PUBLIC_SHA = "9e9a8368a7ecfb38bcbf1f1e7ca71ae29b242aa55f4cf293492c5da472190483"
HEAD = "7af7a9785d74c1b420b23de3be0eac6946cc2200"
SOURCE = "87b01101ef13aa20ded205f3a2b267b68d094def"
PROTECTED = "8d838c8df453a78fac3459b7458576e1ba2cbcb8"
DEVICE = "3f5ce987-e3eb-40a3-af9f-4b0ae54919cc"
RUNROOT = "/Users/chriswong/Library/Caches/Mastermind/economic-network-20261009/native-mu-split-pro-004-001"
SCRIPT_NATIVE = "/Users/chriswong/Library/Caches/Mastermind/economic-network-20261009/native-mu-capture-runner-001.py"
CHECKS = []
INPUTS = []


def require(condition, code):
    if not condition:
        raise ValueError(code)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pairs(entries):
    result = {}
    for key, value in entries:
        require(key not in result, "DUPLICATE_JSON_KEY")
        result[key] = value
    return result


def constant(_):
    raise ValueError("NONFINITE_JSON_CONSTANT")


def json_value(text):
    return json.loads(text, object_pairs_hook=pairs, parse_constant=constant)


def read_input(path, maximum=262144):
    data = path.read_bytes()
    require(len(data) <= maximum, "INPUT_BYTE_BUDGET")
    INPUTS.append({"path": str(path.relative_to(LANES)), "byte_length": len(data),
                   "sha256": digest(data)})
    return data


def json_input(path, maximum=262144):
    return json_value(read_input(path, maximum).decode("utf-8"))


def checkpoint(name, facts):
    CHECKS.append({"check": name, "verdict": "PASS", "facts": facts})


def text_blocks(result):
    require(result.get("isError") is False, "TOOL_RECEIPT_ERROR")
    require(type(result.get("content")) is list, "TOOL_RECEIPT_CONTENT")
    return [x["text"] for x in result["content"] if x.get("type") == "text"]


def json_output_lines(text):
    return [json_value(x) for x in text.splitlines() if x.startswith("{") and x.endswith("}")]


def integer(value, expected=None):
    require(type(value) is int and value >= 0, "COUNT_TYPE")
    if expected is not None:
        require(value == expected, "COUNT_VALUE")


def stamp(value):
    require(type(value) is str and re.fullmatch(r"[1-9][0-9]{0,19}", value), "CLOCK_LEXICAL")
    return int(value)


def utc_ns(value):
    seconds, fraction = divmod(value, 1000000000)
    date = datetime.datetime.fromtimestamp(seconds, datetime.timezone.utc)
    return date.strftime("%Y-%m-%dT%H:%M:%S") + "." + f"{fraction:09d}" + "Z"


# Preserve the original pre-script/pre-result packet.
manifest_bytes = read_input(REVIEW / "SOURCE_REVIEW_MANIFEST.json")
require(digest(manifest_bytes) == "9c1f7a2a7ef1d1979c96c91cde9eefa91db2011baa844c8c9cbb65f6ef53c319",
        "PRE_RESULT_MANIFEST_CHANGED")
manifest = json_value(manifest_bytes.decode("utf-8"))
for row in manifest["files"]:
    data = read_input(REVIEW / row["path"])
    require(len(data) == row["byte_length"] and digest(data) == row["sha256"],
            "PRE_RESULT_FILE_CHANGED")
checkpoint("pre_result_packet_preserved", {"member_count_including_manifest": 6})

# Exact script, launcher and launch command binding without executing their code.
script = read_input(PRINCIPAL / "run_native_mu_capture_001.py", 131072)
require(len(script) == 18367 and digest(script) == SCRIPT_SHA, "SCRIPT_IDENTITY")
wrapper = read_input(PRINCIPAL / "LAUNCH_WRAPPER_001.py", 131072)
wrapper_text = wrapper.decode("utf-8")
assignments = [x for x in ast.parse(wrapper_text).body if isinstance(x, ast.Assign)
               and any(isinstance(t, ast.Name) and t.id == "b" for t in x.targets)]
require(len(assignments) == 1, "WRAPPER_EMBEDDED_ASSIGNMENT")
call = assignments[0].value
require(isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute)
        and call.func.attr == "encode", "WRAPPER_ENCODING")
require(ast.literal_eval(call.args[0]) == "utf-8", "WRAPPER_ENCODING")
embedded = ast.literal_eval(call.func.value).encode("utf-8")
require(embedded == script, "WRAPPER_SCRIPT_MISMATCH")
command = json_input(PRINCIPAL / "LAUNCH_COMMAND_001.json")
require(command["device_id"] == DEVICE and command["expected_script_sha256"] == SCRIPT_SHA,
        "LAUNCH_COMMAND_BINDING")
argv = shlex.split(command["command"])
require(argv == ["PYTHONDONTWRITEBYTECODE=1",
                 "/opt/homebrew/Caskroom/miniconda/base/bin/python3",
                 "-I", "-B", "-c", wrapper_text], "ACTUAL_LAUNCH_ARGV")
checkpoint("launch_command_wrapper_script_binding",
           {"script_bytes": len(script), "script_sha256": SCRIPT_SHA,
            "wrapper_sha256": digest(wrapper), "isolated_flag": True,
            "bytecode_disabled_flags": True, "reviewer_executed_script": False})

# Native tool receipts are evidence, not new tool/native calls by this verifier.
start_receipt = json_input(PRINCIPAL / "START_RESULT_001.json")
completion_receipt = json_input(PRINCIPAL / "COMPLETION_RESULT_001.json")
start_blocks = text_blocks(start_receipt)
completion_blocks = text_blocks(completion_receipt)
require(any(DEVICE in x and "m2studio" in x for x in start_blocks), "START_DEVICE")
require(any(DEVICE in x and "m2studio" in x for x in completion_blocks), "COMPLETION_DEVICE")
pid_match = re.search(r"Process started with PID ([0-9]+)", start_blocks[0])
require(pid_match is not None, "START_PID")
pid = int(pid_match.group(1))
start_lines = json_output_lines(start_blocks[0])
completion_lines = json_output_lines(completion_blocks[0])
require(len(start_lines) == 1 and len(completion_lines) == 2, "PROCESS_STDOUT_CARDINALITY")
launch = start_lines[0]
require(launch == completion_lines[0], "START_COMPLETION_LAUNCH_MISMATCH")
require(launch == {"stage": "EXECUTING_REVIEWED_SCRIPT", "script_path": SCRIPT_NATIVE,
                   "script_bytes": 18367, "script_sha256": SCRIPT_SHA,
                   "bytecode_disabled": True}, "NATIVE_SCRIPT_EXECUTION_BINDING")
terminal = re.search(r"Process completed with exit code ([0-9]+) \(runtime: ([0-9.]+)s\)",
                     completion_blocks[0])
require(terminal is not None and terminal.group(1) == "0"
        and terminal.group(2) == "8.49", "TERMINAL_EXIT")
stdout = completion_lines[1]
checkpoint("actual_process_receipt",
           {"pid": pid, "exit_code": 0, "runtime_seconds_text": terminal.group(2),
            "separate_pid_field_in_completion_receipt": False,
            "binding_basis": "Start PID plus matching launch stdout, final public digest and public python_pid."})

# Strict bounded actual public result. No private source data is read.
public_bytes = read_input(PRINCIPAL / "PUBLIC_RESULT.json")
require(len(public_bytes) == 16454 and digest(public_bytes) == PUBLIC_SHA, "PUBLIC_BYTE_BINDING")
public = json_value(public_bytes.decode("utf-8"))
require(type(public) is dict, "PUBLIC_TOP_LEVEL")
stack = [(public, 0)]
nodes = 0
max_depth = 0
max_scalar = 0
while stack:
    value, depth = stack.pop()
    nodes += 1
    max_depth = max(max_depth, depth)
    require(nodes <= 8192 and depth <= 16, "PUBLIC_STRUCTURE_BUDGET")
    if type(value) is dict:
        stack.extend((x, depth + 1) for pair in value.items() for x in pair)
    elif type(value) is list:
        stack.extend((x, depth + 1) for x in value)
    elif type(value) is str:
        value.encode("utf-8")
        max_scalar = max(max_scalar, len(value))
        require(len(value) <= 4096, "PUBLIC_SCALAR_BUDGET")
    else:
        require(value is None or type(value) in (bool, int, float), "PUBLIC_VALUE_TYPE")
checkpoint("strict_public_json",
           {"byte_length": len(public_bytes), "sha256": PUBLIC_SHA, "nodes": nodes,
            "maximum_depth": max_depth, "maximum_scalar_characters": max_scalar,
            "duplicate_keys": "rejected", "nonfinite_constants": "rejected"})

read_tool = json_input(PRINCIPAL / "PUBLIC_READ_TOOL_RESULT_001.json")
read_blocks = text_blocks(read_tool)
require(any(DEVICE in x and "m2studio" in x for x in read_blocks), "PUBLIC_READ_DEVICE")
header, payload = read_blocks[0].split("\n\n", 1)
require(header == "[Reading 452 lines from start (total: 452 lines, 0 remaining)]",
        "PUBLIC_READ_NOT_COMPLETE")
require((payload + "\n").encode("utf-8") == public_bytes, "PUBLIC_READ_BYTES")
require(stdout["public_identity"] == {"byte_length": 16454, "sha256": PUBLIC_SHA},
        "STDOUT_PUBLIC_IDENTITY")
require(stdout["public_result"] == RUNROOT + "/PUBLIC_RESULT.json", "PUBLIC_PATH_BINDING")
require(public["python_pid"] == pid == 17056, "PUBLIC_PID_BINDING")
checkpoint("native_public_copy_binding",
           {"tool_read_reported_lines": 452,
            "exact_reconstruction": "Complete read-tool payload plus exactly one terminal LF equals frozen public file.",
            "native_stdout_digest_matches": True, "public_python_pid": pid})

# Fixed single request and exact honest pre-acquisition branch.
expected_query = {"endpoint": "https://api.massive.com/stocks/v1/splits",
                  "ticker": "MU", "execution_date.gte": "2026-09-30",
                  "sort": "execution_date.asc", "limit": 1000}
require(public["schema"] == "economic_network.native_mu_capture_witness/v1", "PUBLIC_SCHEMA")
require(public["query"] == expected_query and type(public["query"]["limit"]) is int,
        "EXACT_QUERY")
require(public["D"] == "2026-09-30" and public["K"] == "2026-10-09T00:00:00Z"
        and public["basis_date_metadata"] == "2026-09-30"
        and public["upper_execution_date_filter"] is None, "DATE_SCOPE")
require(public["requested_vendor_token"] == "MU"
        and public["producer_entrypoint"] == "engine.close_pass.massive_close.retain_split_history",
        "PUBLIC_PRODUCER")
for name, expected in [("requested_case_count", 1), ("producer_call_count", 1),
                       ("same_artifact_intake_repeat_call_count", 0),
                       ("cohort_selected_case_count", 0), ("wrapper_exit_code", 0)]:
    integer(public[name], expected)
require(public["status"] == "REFUSED_BEFORE_ACQUISITION"
        and public["stage"] == "PRODUCER_CALL", "REFUSAL_BRANCH")
refusal = public["refusal"]
require(refusal["type"] == "SplitEvidenceError"
        and refusal["base_type"] == "SourceIntakeError"
        and refusal["diagnostic"] == "missing_credentials", "EXACT_TYPED_REFUSAL")
integer(refusal["provider_request_attempts_code_derived"], 0)
require(refusal["network_instrumentation"] is False
        and public["provider_request_count_is_network_instrumented"] is False
        and public["provider_request_attempts_recorded"] is None, "REQUEST_COUNT_HONESTY")
for name in ["F", "acquisition", "owner_receipt", "read_receipt", "repeat"]:
    require(name in public and public[name] is None, "REFUSAL_HAS_SOURCE_RESULT")
require("generation_id" not in public and "store_after_intake" not in public,
        "REFUSAL_HAS_COMMITTED_STORE")
require(public["validation"] == {"missing_credentials_no_store_created": True},
        "REFUSAL_VALIDATION_SCOPE")
require("error" not in public and "postflight_error_type" not in public, "HIDDEN_FAILURE")
require(stdout["status"] == public["status"] and stdout["stage"] == public["stage"]
        and stdout["producer_call_count"] == 1 and stdout["wrapper_exit_code"] == 0
        and stdout["provider_request_attempts_recorded"] is None
        and stdout["source_acquisition_status"] is None
        and stdout["retained_row_count"] is None, "STDOUT_SEMANTIC_BINDING")
checkpoint("typed_pre_request_refusal",
           {"requested_case_count": 1, "actual_producer_calls": 1,
            "captured_source_cases": 0, "source_row_count": None,
            "intake_repeat_calls": 0, "recorded_provider_page_count": None,
            "code_derived_source_request_count": 0, "network_instrumented": False,
            "actual_F": None, "source_status": None, "cohort_selected": 0})

require(public["initial_store"] == {"exists": False, "files": []}
        and public["final_store"] == {"exists": False, "files": []}, "STORE_EFFECT")
require(public["store_root"] == RUNROOT + "/sources-massive-split-history-v1", "STORE_ROOT")
require(public["preflight_complete"] is True and public["workspace_clean_after"] is True
        and public["ignored_paths_absent_after"] is True
        and public["all_source_pins_unchanged_after"] is True, "POSTFLIGHT")
require(public["native_head"] == HEAD and public["final_native_head"] == HEAD
        and public["reviewed_source"] == SOURCE
        and public["protected_master_expected"] == PROTECTED
        and public["protected_master_observed"] == PROTECTED, "REVISION_BINDING")
checkpoint("scoped_effects_and_revisions",
           {"source_store_absent_before_and_after": True, "workspace_head": HEAD,
            "reviewed_source": SOURCE, "protected_source": PROTECTED,
            "workspace_clean_and_ignored_absent": True,
            "harness_effects": "Runner, run directory and private/public result files were intentionally created; not claimed zero."})

# The private file is not read. Its declared identity agrees with the expected
# unchanged null envelope emitted by this exact reviewed branch.
expected_private = {"schema": "economic_network.native_mu_capture_private/v1",
                    "source_result": None, "read_result": None, "repeat_result": None}
private_bytes = (json.dumps(expected_private, sort_keys=True, indent=2,
                            ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")
expected_identity = {"byte_length": len(private_bytes), "sha256": digest(private_bytes)}
require(public["private_result_identity"] == expected_identity
        and stdout["private_result_identity"] == expected_identity, "NULL_PRIVATE_IDENTITY")
checkpoint("private_identity_without_private_read",
           {"expected_null_envelope_identity": expected_identity,
            "private_file_read": False, "scope": "Expected serialization digest agrees with the principal's published identity; not an independent private-file read."})

pins_bytes = read_input(FEASIBILITY / "SOURCE_PINS.json")
require(digest(pins_bytes) == "a4846212a1c7c6ea73f2be59e8dd8dc07a21232db8e99b8cc32b2c9be905ff8f",
        "FEASIBILITY_PINS_CHANGED")
expected_pins = json_value(pins_bytes.decode("utf-8"))["source_files"]
project = lambda r: {k: r[k] for k in ["path", "byte_length", "sha256", "git_blob_sha1"]}
expected_rows = sorted([project(x) for x in expected_pins], key=lambda x: x["path"])
actual_rows = public["source_pins"]
require(len(actual_rows) == 18 and len({x["path"] for x in actual_rows}) == 18,
        "SOURCE_PIN_CARDINALITY")
require(actual_rows == expected_rows, "ACTUAL_SOURCE_PINS_DIFFER")
for row in actual_rows:
    integer(row["byte_length"])
checkpoint("all_18_source_pins", {"expected_and_actual_exact": True, "count": 18,
           "subject": "Public evidence of the script's native pre/postflight checks against reviewed pins."})

before = public["imported_repository_sources_before_call"]
after = public["imported_repository_sources_after_call"]
require(before == after and len(before) == 21, "IMPORTED_SOURCE_SET_CHANGED")
require(len({x["module"] for x in before}) == 21 and len({x["path"] for x in before}) == 21,
        "IMPORTED_SOURCE_DUPLICATES")
for row in before:
    require(set(row) == {"module", "path", "byte_length", "sha256"}, "IMPORTED_SOURCE_SHAPE")
    integer(row["byte_length"])
    require(re.fullmatch(r"[a-f0-9]{64}", row["sha256"]) is not None,
            "IMPORTED_SOURCE_HASH_SHAPE")
    require(row["path"].endswith(".py") and not row["path"].startswith("/")
            and ".." not in row["path"].split("/"), "IMPORTED_SOURCE_PATH")
pinned_by_path = {x["path"]: x for x in actual_rows}
overlap = 0
for row in before:
    if row["path"] in pinned_by_path:
        pin = pinned_by_path[row["path"]]
        require(row["byte_length"] == pin["byte_length"] and row["sha256"] == pin["sha256"],
                "IMPORTED_REVIEWED_PIN_MISMATCH")
        overlap += 1
checkpoint("21_imported_source_bindings",
           {"before_after_exact": True, "count": 21, "overlap_with_18_reviewed_pins": overlap,
            "scope": "The reviewed principal script checks all 21 actual repository imports against HEAD. This reviewer did not import or independently fetch their native bytes."})

expected_boundaries = {
    "K_public_vintage": "UNPROVED", "D_close_price_and_currency": "NOT_SUPPLIED",
    "canonical_issuer_class_and_shares": "NOT_ADMITTED",
    "global_population_and_relative_cap": "NOT_ADMITTED",
    "WP02_real_cohort": "NOT_ADMITTED", "Graph1": None,
    "ranking": False, "gating": False, "sizing": False, "trading": False,
    "prediction": False, "source_registry_modified": False,
    "production_activation": False, "Sol_CEO_architectural_adjudication": "NOT_ASSERTED"}
require(public["boundaries"] == expected_boundaries, "AUTHORITY_HOLD_CHANGED")
for name in ["transport_or_clock_replacement", "secret_values_recorded",
             "raw_provider_body_published", "git_mutation"]:
    require(public[name] is False, "PUBLIC_EFFECT_CLAIM")
require(not {"rows", "source_result", "read_result", "repeat_result", "raw_body",
             "provider_body", "credentials"}.intersection(public), "PRIVATE_PAYLOAD_PUBLIC")
checkpoint("scope_privacy_and_authority", {"boundaries_exact": True,
           "no_source_or_reviewer_authentication_minted": True,
           "accepted_enterprise_grant": "Unchanged; credential refusal does not revoke it.",
           "positive_acquisition_read_repeat_branch": "NOT_EXERCISED"})

start_ns = stamp(public["started_utc_ns"])
end_ns = stamp(public["finished_utc_ns"])
require(start_ns <= end_ns, "DRIVER_CLOCK_ORDER")
checkpoint("driver_clock_precision", {
    "driver_started_utc_ns": str(start_ns), "driver_finished_utc_ns": str(end_ns),
    "driver_started_utc": utc_ns(start_ns), "driver_finished_utc": utc_ns(end_ns),
    "driver_elapsed_ns": str(end_ns - start_ns),
    "source_acquisition_F": None,
    "meaning": "Driver action-stage clocks only; finish precedes postflight/export and is not provider publication or actual process termination."})

result = {
    "schema": "economic_network.native_mu_actual_refusal_independent_verification/v1",
    "verdict": "PASS_TYPED_PRE_REQUEST_REFUSAL",
    "principal_native_process": {"pid": pid, "exit_code": 0, "runtime_seconds_text": "8.49"},
    "reviewer_local_pid": os.getpid(),
    "input_files": INPUTS,
    "check_group_count": len(CHECKS),
    "checks": CHECKS,
    "actual_provider_data_acquisition": "DID_NOT_OCCUR_ON_THE_REVIEWED_SOURCE_PATH",
    "provider_request_count_basis": "Code-derived zero, explicitly not network instrumentation.",
    "positive_capture_storage_read_repeat_proof": "NOT_EXERCISED",
    "reviewer_effects": {"native_calls": 0, "provider_requests": 0, "credentials_inspected": 0,
                        "application_imports": 0, "principal_script_execution": 0,
                        "private_file_reads": 0, "native_or_git_writes": 0,
                        "scratch_public_evidence_check_processes": 1},
    "limitations": [
        "Principal-supplied tool/source/result receipts were independently checked; no new native read was made.",
        "No network instrumentation, provider response, source raw bytes, intake, pinned read or repeat was produced by this actual branch.",
        "Expected null-private serialization was hashed locally, but the private native file itself was not read.",
        "No historical K, D-close, issuer identity, capitalization, cohort, Graph1, trade or predictive authority is admitted."
    ]
}
output = HERE / "PUBLIC_VERIFICATION.json"
body = (json.dumps(result, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")
with output.open("xb") as handle:
    handle.write(body)
require(output.read_bytes() == body, "VERIFICATION_OUTPUT_READBACK")
print(json.dumps({"verdict": result["verdict"], "local_pid": os.getpid(),
                  "check_groups": len(CHECKS), "output_byte_length": len(body),
                  "output_sha256": digest(body), "actual_native_pid": pid,
                  "reviewer_native_calls": 0, "reviewer_provider_calls": 0},
                 sort_keys=True))

