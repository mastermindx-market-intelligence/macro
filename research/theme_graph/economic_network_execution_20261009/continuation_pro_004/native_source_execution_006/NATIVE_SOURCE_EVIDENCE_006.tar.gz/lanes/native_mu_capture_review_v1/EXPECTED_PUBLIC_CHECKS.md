# Independent MU capture checks — frozen before the principal result

## Purpose and current status

This is the independent pre-result review protocol for one actual MU current-capture attempt. The principal owns the native call and all private bytes. This lane has received neither the exact execution script nor its actual result at this freeze. There is therefore no actual capture verdict, credential finding or provider observation here.

The protocol binds the existing source module at Macro 87b01101ef13aa20ded205f3a2b267b68d094def, SHA-256 a1d32eacd48c90f793df717a7284fa044054c476241c622e9b9f9abc997c6942. It references the prior frozen feasibility packet without copying or changing it. The preparatory source excerpts came only from that earlier retained read.

## Exact call and a material boundary

The proposed public call is retain_split_history("MU", "2026-09-30", "2026-09-30", store_root=principal_selected_private_root). It reaches the incumbent /stocks/v1/splits endpoint. Only execution_date.gte is sent; basis_date supplies no upper filter. This request is not an exact-day query, a complete split history before D, an issuer price observation or a selected WP02 record.

The principal should explicitly pin SplitEvidenceReader to the generation returned by the actual intake, then repeat intake using exactly stored.artifact. It should not call the producer again to test idempotency. A fresh isolated source root removes ambiguity about unrelated generation appends. If a writer or effect is unexpectedly present, the review must report it rather than assume isolation.

## Branch A: genuine typed refusal before a request

The exact source type is SplitEvidenceError, a subclass of the shared SourceIntakeError. The fixed message is missing_credentials. In the reviewed implementation, that refusal happens before producer time_ns/UUID construction, page creation, transport and intake. The wrapper performs read-only destination validation first.

The script must catch this actual source exception from the proposed call. It must not inspect, print or independently test secret values, synthesize the exception, or fall back to a different account. A broad except Exception branch containing the text "missing_credentials" is insufficient by itself: the actual type and reachable raising site must agree.

An honest result has one requested attempt and zero captured source cases, with no acquisition ID, source F, artifact, receipt, generation, reader result or intake repeat. Source row count is null, not the zero rows of a completed empty provider response. It supplies no claim that the provider has no records or that the accepted licence has disappeared.

A source-specific zero request count needs real observation or a clear code-path qualification. A counter initialized to zero and never connected to transport is not a network witness. A transparent observation wrapper must call the original transport unchanged and never substitute a response or a credential. This review does not demand an extra provider call to prove the counter.

The actual source leaf should remain absent if it was absent before the call. Distinguish the principal's preparation/log writes elsewhere from the source-store effect. If absence is not checked, say effect unobserved; do not invent a filesystem-clean receipt.

## Branch B: an actual returned source, including negative outcomes

The artifact status may be complete, partial or failed. A failed or partial source can still be validly retained/read/repeated by the immutable source contract. Storage success is not economic-data success. A complete empty result is distinct from a failed attempt, and neither demonstrates absence outside the actual request.

Review the script's private comparisons, then the bounded public summary, for these exact invariants:

| Check | Actual objects required | Failure that must remain visible |
|---|---|---|
| Request identity | The returned artifact's complete request | Another ticker/date/endpoint/filter substituted |
| Source counts | Actual retained pages and rows | Dropped failed pages or omitted rows; bool treated as an integer |
| Time order | Producer/page/intake/read clocks from their actual objects | Clock regression; principal-added historical timestamp; F relabeled K |
| Artifact preservation | Complete stored.artifact and reader.artifact | Selected-field comparison hiding a different payload |
| Receipt preservation | Complete stored.receipt and reader.owner_receipt | Expected receipt substituted for actual read receipt |
| Generation pin | Actual stored.generation_id passed to the reader and observed at readback | Latest/HEAD fallback or a different generation |
| Byte binding | Actual source-object bytes/length and canonical object/receipt digests | A hash printed without checking its subject |
| Same-artifact repeat | Actual first artifact passed to intake, then complete repeated result | Reacquisition, new observation or silent repair |
| No extra transport | Actual source-request observations during read/repeat | A repeat that calls the provider again |
| Authority | Full inherited context authority and basis_eligible=false | Added graph/rank/trade/predictive admission |

The public output may contain only source metadata, counts, precise clocks, digests, bounded receipt metadata and the conclusions of privately executed comparisons. It must not disclose raw response bytes, provider row payloads or credentials. In particular, a public boolean such as artifact_matches=true is not independently self-authenticating: review must establish that the exact script compared the two actual returned objects and bound the real execution to those script bytes.

The producer permits at most eight pages and 4,096 rows. Per-page observed body bytes may reach 1 MiB + 1 sentinel on an oversize refusal; the source kernel admits at most a 1 MiB canonical source object. These are different denominators and limits. No raw provider body is retained by this source, so no review may claim full raw-response replay merely because a body hash exists.

For aggregate public date counts, before-D + on-D + after-D must equal the retained row count; before-D must be zero under the existing row validator. Do not infer any actual counts before the result arrives. Rows on or after D are not automatically applicable-by-D or known-by-K.

## Branch C: a later failure or uncertain effect

A script may fail at preflight, producer, intake, exact-generation read, repeat or evidence export. Preserve the actual reached stage and any already observed artifact/receipt/generation reference. Do not report a successful chain if only acquisition succeeded. A modifying call whose acknowledgment is lost may have effected storage; a later exception is not proof nothing was written.

No broad retry is part of this review. The principal reconciles its original process and narrowly scoped source-root effects. A failure is useful evidence; it is not a reason to create a synthetic positive or expand to another endpoint.

## Bounded outer evidence check

The later check is a scratch-only read of the exact supplied script and public result, with their hashes and actual process receipts. The public JSON budget is 256 KiB, depth 16, 8,192 nodes and 4,096 characters per scalar. The script budget is 128 KiB. Ambiguous duplicate keys, invalid UTF-8 or nonfinite JSON constants refuse evidence parsing. Cardinalities are exact nonnegative integers excluding bool.

The principal does not need to create a new application schema to satisfy this review. The reviewer will map the actual envelope to this frozen checklist; unsupported or missing facts remain explicit. These bounds limit the review input, not the native API or a newly implemented registry.

Verdicts are distinct: PASS_TYPED_PRE_REQUEST_REFUSAL; PASS_CURRENT_CAPTURE_CHAIN; PASS_CURRENT_CAPTURE_CHAIN_NEGATIVE_SOURCE_OUTCOME; INCOMPLETE_EVIDENCE; FAIL_CONCRETE_BINDING_OR_SCOPE_ERROR; EFFECT_UNKNOWN. Before any result, the only verdict is NOT_REVIEWED_NO_RESULT. A passing chain describes the narrowly reviewed execution and does not authenticate every source fact or prove historical availability.

## Preserved holds

D is 2026-09-30 and K is 2026-10-09T00:00:00Z. F must be the actual later source/read time, with original precision retained. No floor, backdating or report-time substitution is permitted. Provider execution dates are not publication clocks; basis_date is not a vintage receipt. Issuer identity, class completeness, reported shares, close price, capitalization, population selection, Graph1 and predictive admission remain held.

The accepted Massive enterprise grant remains the rights basis for the proposed research-retention purpose. A successful response is not a new rights certificate; a missing credential is not revocation of that grant. Digest/owner labels do not authenticate source custody themselves. The existing dataset remains PROPOSED.

## Reviewer effects at this freeze

No principal script or actual result has yet been reviewed. No public-result verifier call, native import/call, provider request, credential inspection, Git write or application mutation has occurred in this lane. Only this disjoint protocol packet was written. Later findings will use separate files and will not alter this pre-result freeze.

