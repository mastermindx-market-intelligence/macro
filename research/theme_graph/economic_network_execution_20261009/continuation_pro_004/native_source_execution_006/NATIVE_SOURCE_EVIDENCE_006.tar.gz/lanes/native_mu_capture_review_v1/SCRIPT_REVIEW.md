# Principal MU script: independent pre-execution review

**Verdict: PASS_PRE_EXECUTION_SOURCE_REVIEW. No concrete required code correction was found within the bounded current-capture scope.** This is a complete read of the actual script, not a native test or provider result.

The reviewed file is ../native_mu_capture_principal_v1/run_native_mu_capture_001.py: **18,367 bytes**, SHA-256 **6fe0f67b7335b31ef3e4a3eb9a914ac1557236689deb563ac8887b5bd2d53439**. The protocol and expected checks were frozen before reading it; their manifest is a480ca4b38492ad6c40aedd8570a5cbb3d20d08a9a98cd81ae299372210a0114.

## Decisive checks

The script validates 18 materialized source pins against the reviewed Git objects and local HEAD, checks the designated clean workspace and protected revision, and requires a fresh isolated run root. It invokes the ordinary existing MU/D/D wrapper once. It does not patch the key resolver, producer clock, UUID or transport.

The exact SplitEvidenceError missing_credentials branch is correctly distinguished from other errors. It leaves F and all source/read/repeat outputs absent, retains the one requested producer call, and checks that the source leaf was not created. Its zero-request statement is expressly code-derived rather than represented as network instrumentation.

When the producer returns, the script keeps the full actual source result private, checks exact request and inherited authority, verifies stored object bytes, pins the reader to the actual returned generation, and compares complete artifacts and owner receipts. Reader hash/length/identity and original-precision clock checks are reachable before success. The repeat passes exactly stored.artifact to intake and requires created=false, identical content/receipt/generation and unchanged store inventory. It does not reacquire.

Complete, partial, failed and complete-empty source results remain distinguishable. Public output is a metadata/count/receipt/hash projection, with provider rows excluded. Unexpected exception messages are omitted. K-vintage, price, identity, cohort and product/predictive holds remain in place.

## Limits to apply to the actual result

Bind the native launch to these reviewed bytes and Python -B/no bytecode behavior. A script hash or a public pass flag cannot authenticate itself; the actual principal process and result receipts are separate evidence.

The producer's retained page count is not an independently observed socket/request count. The script labels that correctly. No extra API call or instrumented replacement is requested by this review.

A later intake, postflight or evidence-export failure may follow source effects. A generic action-failed status is not proof nothing was written. Reconcile the original process and narrow private root before retrying. Preserve any actual committed artifact even if a later read, repeat or export is incomplete.

The store inventory is of a fresh, isolated, owner-written private root. This review does not add a hostile-host filesystem sandbox or a fleet-wide audit. The script's finished_utc_ns is captured before postflight/export; it must not be promoted to actual process termination or provider publication time.

## Effect receipt

The local standard-library read/freeze process was Python PID 5, tool chunk 842512, exit 0. It wrote only this lane's protocol manifest and read the script text. The principal separately reported a syntax parse; that is not recast as a reviewer or native test.

Reviewer native/provider calls, credential inspection, script imports/execution, Git/application writes and actual-result checks are all zero. The principal's actual run and result were not yet supplied at this freeze. Later result findings will be appended as separate files without changing this protocol or source-review history.

**STOP for this preparation/source-review phase.**

