import pathlib,sys,os,subprocess,json,hashlib,time,datetime,stat
ROOT=pathlib.Path('/Volumes/Mastermind/agent-workspaces/macro/web/gmi-economic-source-diagnostic-20261009-pro-004')
CACHE=pathlib.Path('/Users/chriswong/Library/Caches/Mastermind/economic-network-20261009')
RUNROOT=CACHE/'native-mu-split-pro-004-002'
STORE=RUNROOT/'sources-massive-split-history-v1'
HEAD='7af7a9785d74c1b420b23de3be0eac6946cc2200'
SOURCE='87b01101ef13aa20ded205f3a2b267b68d094def'
PROTECTED='8d838c8df453a78fac3459b7458576e1ba2cbcb8'
PINS=json.loads("[{\"path\":\"agentos/discoveries/DSC-MASSIVE-DAY-AGGS-LASTMODIFIED-FOLLOWS-0430Z.md\",\"byte_length\":2152,\"sha256\":\"6d126b2c3799eac8c291718a05691f5b25d43d00d8b1e0d54bc79f9fe7d7cc04\",\"git_blob_sha1\":\"662fc013dc4507fa7575dff41a4d4846fbe79123\"},{\"path\":\"agentos/discoveries/DSC-MASSIVE-GROUPED-DAILY-AVAILABLE-AT-XNYS-CLOSE.md\",\"byte_length\":1727,\"sha256\":\"71e4a297d2e91e6eca964022236bcc04f43e5d496cbf26c3431d6c81e6b3cfaa\",\"git_blob_sha1\":\"85b2075faaf9ac9ee31871a41652bb4ac6d19c07\"},{\"path\":\"agentos/workstreams/WS-MASSIVE-STOCK-DAY-R2-COHERENCE.md\",\"byte_length\":2833,\"sha256\":\"fef7490c2f3576041cbeb728a867bb16095c896bb6085e6ee10c40c27e8b0992\",\"git_blob_sha1\":\"0ff65376a7c9e1312cc3baa3d3efe1fa0967903a\"},{\"path\":\"collectors/massive_flatfiles.py\",\"byte_length\":12770,\"sha256\":\"1b270024530bb4e1ef66553c690786d14c7dcc1d6aa6c1fc56e047ffd4f46eb4\",\"git_blob_sha1\":\"f94ae42ea3c9810e4c767dee71abb4846d319ce3\"},{\"path\":\"collectors/massive_stock_day.py\",\"byte_length\":39815,\"sha256\":\"4fd28b8fc7740a9d9dc0f397b8fb1daf5e24ebeda6aee2cfcece26cf175db105\",\"git_blob_sha1\":\"fcad0850eb5ca3aa699cb52d3ba9a62d92231616\"},{\"path\":\"collectors/polygon_options.py\",\"byte_length\":22124,\"sha256\":\"0c2efcdb11af39fec8b03b83f6f40497f33f6536f6421a99c9ab1714751cad0f\",\"git_blob_sha1\":\"2271adc2b9d9c787670c66e53eecb526b9a8d3a4\"},{\"path\":\"config/dataset_registry.yml\",\"byte_length\":50632,\"sha256\":\"bb9b6975eeabebf630f73e632d307d280ea1d9e34f30953ac3989c65fc90f0a7\",\"git_blob_sha1\":\"42252174a9f97c0643d30c9057455761aff35f80\"},{\"path\":\"engine/close_pass/massive_close.py\",\"byte_length\":29522,\"sha256\":\"43bc800dedba38a35ea5a94bc2f1de539401350a683123ecd9d40e6581e7bb66\",\"git_blob_sha1\":\"c5c61536bbba04fd9f8f72b893528bf00e94ee62\"},{\"path\":\"engine/close_pass/massive_split_evidence.py\",\"byte_length\":26549,\"sha256\":\"a1d32eacd48c90f793df717a7284fa044054c476241c622e9b9f9abc997c6942\",\"git_blob_sha1\":\"f7123e761ea83011f603a8e3cd37d4240ab5d59b\"},{\"path\":\"engine/neuralweb/market_memory_source_kernel.py\",\"byte_length\":36991,\"sha256\":\"270f6efdab81d464b7f251d0440c1d82b371bab35a08fab7ee35b8a3e26fffbc\",\"git_blob_sha1\":\"2a75c5016c07e9c1a5377fe4331a4f06b95e79dd\"},{\"path\":\"engine/neuralweb/market_memory_sources_spy.py\",\"byte_length\":36909,\"sha256\":\"a29d0ebc0ae4b7fa7949d319b8872abcbef189425da99453a9d017895dc006b3\",\"git_blob_sha1\":\"de416757bf77946776e1872b437eab9399d4997c\"},{\"path\":\"engine/neuralweb/market_memory.py\",\"byte_length\":107556,\"sha256\":\"d64a53df452eeece71588e61006cb103e8930c6c7a8f3bc1c97b20a7dc747bc5\",\"git_blob_sha1\":\"adffe89b75ea72d58d06fc6618da7ba487b6598a\"},{\"path\":\"lib/dataos/temporal.py\",\"byte_length\":12847,\"sha256\":\"4415404186f0b0d2870f42d9e4a0b95be87937863adf30cf015ed34e8bf92b67\",\"git_blob_sha1\":\"094b149a8b9158f19cb99c4005568c12db96ed41\"},{\"path\":\"research/licenses/MASSIVE_ENTITLEMENT_RECORD.md\",\"byte_length\":3652,\"sha256\":\"82ad971b46d4159739117d3defe19a25a2a24ede45e5e8d28494c5849e757891\",\"git_blob_sha1\":\"3969a9aae918141b51baffbb0e17d8a2ec2485a0\"},{\"path\":\"scripts/build_security_master.py\",\"byte_length\":230231,\"sha256\":\"bfe25480ec3e3dca98dcc5a4f0efad5fdad0f19870095066285e795598b022d6\",\"git_blob_sha1\":\"4a042933f37f32d112bd4d77a704f233bbd7d4a9\"},{\"path\":\"scripts/entry_radar_vendor.py\",\"byte_length\":31301,\"sha256\":\"0dcb882f7d311a063a4d7ddeea2bbe9e56a5499c5c224bd15f93e513767b8dea\",\"git_blob_sha1\":\"8d0b533f6cac2d884954b6d207bdc48d3c7ce916\"},{\"path\":\"scripts/ingest_market_memory_sources_spy.py\",\"byte_length\":30383,\"sha256\":\"1caba034ac3757037ab2b38bbfa7aeb80695cf0560116e2ea86c828fbaa7ffdb\",\"git_blob_sha1\":\"b2d4188148b75d1fd6d7a6ce696723f0317dc336\"},{\"path\":\"scripts/massive_entitlement_probe.py\",\"byte_length\":36743,\"sha256\":\"64f05064e53a256fb9632bfa1f83fb0db53cceee3e84d00234b44caaf4bd7395\",\"git_blob_sha1\":\"8a6a16d159b8a1c0b9854527206c5785d3173b84\"}]")
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
private={'schema':'economic_network.native_mu_capture_private/v1','source_result':None,'read_result':None,'repeat_result':None}
public={'schema':'economic_network.native_mu_capture_witness/v1','status':'IN_PROGRESS','stage':'PREFLIGHT','native_head':HEAD,'reviewed_source':SOURCE,'protected_master_expected':PROTECTED,'D':'2026-09-30','K':'2026-10-09T00:00:00Z','F':None,'requested_vendor_token':'MU','requested_case_count':1,'cohort_selected_case_count':0,'query':{'endpoint':'https://api.massive.com/stocks/v1/splits','ticker':'MU','execution_date.gte':'2026-09-30','sort':'execution_date.asc','limit':1000},'basis_date_metadata':'2026-09-30','upper_execution_date_filter':None,'producer_entrypoint':'engine.close_pass.massive_close.retain_split_history','producer_call_count':0,'same_artifact_intake_repeat_call_count':0,'provider_request_attempts_recorded':None,'provider_request_count_is_network_instrumented':False,'acquisition':None,'owner_receipt':None,'read_receipt':None,'repeat':None,'validation':{},'started_utc_ns':str(time.time_ns()),'python_pid':os.getpid(),'boundaries':{'K_public_vintage':'UNPROVED','D_close_price_and_currency':'NOT_SUPPLIED','canonical_issuer_class_and_shares':'NOT_ADMITTED','global_population_and_relative_cap':'NOT_ADMITTED','WP02_real_cohort':'NOT_ADMITTED','Graph1':None,'ranking':False,'gating':False,'sizing':False,'trading':False,'prediction':False,'source_registry_modified':False,'production_activation':False,'Sol_CEO_architectural_adjudication':'NOT_ASSERTED'},'transport_or_clock_replacement':False,'secret_values_recorded':False,'raw_provider_body_published':False,'git_mutation':False}
def sha(b):return hashlib.sha256(b).hexdigest()
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf-8')
def get(*args):
 p=subprocess.run(['git','--no-lazy-fetch','--no-optional-locks','-C',str(ROOT),*args],capture_output=True,env=env)
 if p.returncode:raise RuntimeError('READ_ONLY_GIT_FAILED')
 return p.stdout
def check(ok,code):
 if not ok:raise RuntimeError(code)
def writer(path,value):
 b=(json.dumps(value,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode('utf-8')
 fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,'O_NOFOLLOW',0),0o600)
 with os.fdopen(fd,'wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
 return {'byte_length':len(b),'sha256':sha(b)}
def inventory():
 if not STORE.exists():return {'exists':False,'files':[]}
 check(STORE.is_dir() and not STORE.is_symlink(),'STORE_NOT_REGULAR_DIRECTORY')
 result=[];total=0
 for p in sorted(STORE.rglob('*')):
  check(not p.is_symlink(),'STORE_SYMLINK_REFUSED')
  if p.is_dir():continue
  st=p.stat();check(stat.S_ISREG(st.st_mode),'STORE_NONREGULAR_REFUSED')
  check(st.st_size<=5*1024*1024,'STORE_FILE_READ_BUDGET')
  total+=st.st_size;check(total<=32*1024*1024 and len(result)<64,'STORE_TOTAL_READ_BUDGET')
  b=p.read_bytes()
  result.append({'path':p.relative_to(STORE).as_posix(),'byte_length':len(b),'sha256':sha(b),'mtime_ns':str(st.st_mtime_ns),'mode':oct(stat.S_IMODE(st.st_mode))})
 return {'exists':True,'files':result,'total_bytes':total}
def pins_check():
 for row in PINS:
  p=ROOT/row['path'];check(p.is_file() and not p.is_symlink(),'SOURCE_NOT_REGULAR')
  b=p.read_bytes();check(len(b)==row['byte_length'] and sha(b)==row['sha256'],'SOURCE_PIN_MISMATCH')
  check(get('rev-parse',SOURCE+':'+row['path']).decode().strip()==row['git_blob_sha1'],'REVIEWED_GIT_BLOB_MISMATCH')
  check(get('show',HEAD+':'+row['path'])==b,'LOCAL_HEAD_SOURCE_MISMATCH')
def current_imports():
 rows=[]
 for name,module in sorted(sys.modules.items()):
  f=getattr(module,'__file__',None)
  if not f:continue
  p=pathlib.Path(f).resolve()
  if not p.is_relative_to(ROOT):continue
  check(p.suffix=='.py','UNEXPECTED_REPOSITORY_IMPORT_TYPE')
  rel=p.relative_to(ROOT).as_posix();b=p.read_bytes()
  check(get('show',HEAD+':'+rel)==b,'LOADED_SOURCE_NOT_HEAD')
  rows.append({'module':name,'path':rel,'byte_length':len(b),'sha256':sha(b)})
 return rows
exit_code=2
preflight_complete=False
try:
 check(not RUNROOT.exists() and not RUNROOT.is_symlink(),'FRESH_RUNROOT_REQUIRED')
 check(CACHE.is_dir() and CACHE.resolve()==CACHE,'CACHE_PATH_NOT_CANONICAL')
 check(get('rev-parse','HEAD').decode().strip()==HEAD,'WORKSPACE_HEAD_CHANGED')
 check(get('branch','--show-current').decode().strip()=='sol/web-gmi-economic-source-diagnostic-20261009-pro-004','WORKSPACE_BRANCH_CHANGED')
 check(not get('status','--porcelain=v1','--untracked-files=all').strip(),'WORKSPACE_NOT_CLEAN')
 check(not get('ls-files','--others','--ignored','--exclude-standard').strip(),'IGNORED_PATH_PRESENT')
 check(sha((ROOT/'AGENTS.md').read_bytes())=='463ea7c70ea9a1ddbb5154b9f65b7c745d0093dc15485db216936fa9bddf057c','AGENTS_CHANGED')
 check(sha((ROOT/'CLAUDE.md').read_bytes())=='3c2016ddb9a67a6488f7938e665cb5f37b767b7d39c2122057cb9d110149d329','CLAUDE_CHANGED')
 pins_check()
 p=subprocess.run(['gh','api','repos/mastermindx-market-intelligence/Mastermind/branches/master'],capture_output=True,cwd=ROOT,env=env)
 check(p.returncode==0,'PROTECTED_SOURCE_READ_FAILED')
 protected=json.loads(p.stdout);public['protected_master_observed']=protected['commit']['sha']
 check(protected['commit']['sha']==PROTECTED and protected['protected'] is True,'PROTECTED_SOURCE_CHANGED')
 public['source_pins']=PINS
 RUNROOT.mkdir(mode=0o700)
 public['store_root']=str(STORE)
 public['initial_store']=inventory()
 preflight_complete=True
 public['stage']='IMPORT'
 sys.path.insert(0,str(ROOT))
 from engine.close_pass.massive_close import retain_split_history
 from engine.close_pass.massive_split_evidence import SplitEvidenceReader,intake_split_acquisition,SplitEvidenceError,AUTHORITY
 from engine.neuralweb import market_memory_source_kernel as K
 check(pathlib.Path(sys.modules[retain_split_history.__module__].__file__).resolve()==ROOT/'engine/close_pass/massive_close.py','ENTRYPOINT_FILE_MISMATCH')
 check(retain_split_history.__name__=='retain_split_history','ENTRYPOINT_NAME_MISMATCH')
 public['imported_repository_sources_before_call']=current_imports()
 public['stage']='PRODUCER_CALL'
 public['producer_call_count']=1
 try:
  stored=retain_split_history('MU','2026-09-30','2026-09-30',store_root=STORE)
 except SplitEvidenceError as exc:
  if str(exc)!='missing_credentials':raise
  public['status']='REFUSED_BEFORE_ACQUISITION'
  public['refusal']={'type':'SplitEvidenceError','base_type':'SourceIntakeError','diagnostic':'missing_credentials','basis':'Actual public producer raised the fixed source diagnostic before time/UUID/page/transport construction in the reviewed source.','provider_request_attempts_code_derived':0,'network_instrumentation':False}
  check(not STORE.exists(),'MISSING_CREDENTIALS_STORE_EFFECT_UNEXPECTED')
  public['validation']['missing_credentials_no_store_created']=True
  exit_code=0
 else:
  public['stage']='STORED'
  private['source_result']={'artifact':stored.artifact,'receipt':stored.receipt,'generation_id':stored.generation_id,'created':stored.created}
  a=stored.artifact;r=stored.receipt
  expected_request=dict(public['query'],basis_date=public['basis_date_metadata'])
  check(a['request']==expected_request,'RETURNED_REQUEST_MISMATCH')
  check(a['basis_eligible'] is False and r['basis_eligible'] is False and a['authority']==AUTHORITY and r['authority']==AUTHORITY,'SOURCE_AUTHORITY_CHANGED')
  check(stored.created is True,'FRESH_INTAKE_NOT_CREATED')
  ab=K._canonical_bytes(a);rb=K._canonical_bytes(r)
  check(sha(ab)==r['artifact_sha256'],'ARTIFACT_RECEIPT_HASH_MISMATCH')
  check((STORE/r['object_key']).read_bytes()==ab,'STORED_OBJECT_NOT_EXACT_ARTIFACT')
  public['F']={'producer_started_utc_ns':str(a['started_utc_ns']),'producer_completed_utc_ns':str(a['completed_utc_ns']),'precision':'exact decimal strings for native integer nanoseconds','public_by_K':'UNPROVED'}
  public['acquisition']={'acquisition_id':a['acquisition_id'],'acquisition_sha256':a['acquisition_sha256'],'artifact_sha256':sha(ab),'artifact_byte_length':len(ab),'status':a['status'],'failure_kind':a['failure_kind'],'page_count':len(a['pages']),'retained_row_count':len(a['rows']),'row_execution_date_counts':{'on_D':sum(v['execution_date']=='2026-09-30' for v in a['rows']),'after_D':sum(v['execution_date']>'2026-09-30' for v in a['rows'])},'pages':[{k:(str(v) if k.endswith('_utc_ns') else v) for k,v in page.items()} for page in a['pages']],'basis_eligible':a['basis_eligible'],'authority':a['authority'],'raw_body_retained':False}
  public['provider_request_attempts_recorded']=len(a['pages'])
  public['owner_receipt']={k:(str(v) if k.endswith('_utc_ns') else v) for k,v in r.items()}
  public['owner_receipt']['canonical_receipt_sha256']=sha(rb)
  public['generation_id']=stored.generation_id
  before=inventory();public['store_after_intake']=before
  public['stage']='PINNED_READ'
  snap=SplitEvidenceReader(STORE,generation_id=stored.generation_id).read(r['receipt_id'])
  private['read_result']={'artifact':snap.artifact,'owner_receipt':snap.owner_receipt,'read_receipt':snap.read_receipt}
  check(snap.artifact==a and snap.owner_receipt==r,'READER_PAYLOAD_MISMATCH')
  rr=snap.read_receipt
  check(rr['generation_id']==stored.generation_id and rr['receipt_id']==r['receipt_id'],'READER_IDENTITY_MISMATCH')
  check(rr['artifact_sha256']==sha(ab) and rr['receipt_sha256']==sha(rb) and rr['artifact_bytes']==len(ab),'READER_HASH_BINDING_MISMATCH')
  check(rr['basis_eligible'] is False,'READER_BASIS_PROMOTION')
  check(rr['read_receipt_sha256']==sha(K._canonical_bytes({k:v for k,v in rr.items() if k!='read_receipt_sha256'})),'READ_RECEIPT_HASH_MISMATCH')
  check(a['started_utc_ns']<=a['completed_utc_ns']<=r['owner_intake_started_utc_ns']<=r['owner_receipt_assembled_utc_ns']<=rr['read_started_utc_ns']<=rr['read_completed_utc_ns'],'CUSTODY_CLOCK_ORDER')
  after_read=inventory();check(after_read==before,'PINNED_READ_CHANGED_STORE')
  public['read_receipt']={k:(str(v) if k.endswith('_utc_ns') else v) for k,v in rr.items()}
  public['validation'].update({'returned_request_exact':True,'source_authority_preserved':True,'fresh_intake_created':True,'artifact_object_bytes_equal':True,'pinned_generation_read_payload_equal':True,'read_receipt_hash_and_binding_valid':True,'actual_clock_order_valid':True,'read_store_bytes_mtime_unchanged':True})
  public['stage']='SAME_ARTIFACT_REPEAT'
  public['same_artifact_intake_repeat_call_count']=1
  repeated=intake_split_acquisition(stored.artifact,store_root=STORE)
  private['repeat_result']={'artifact':repeated.artifact,'receipt':repeated.receipt,'generation_id':repeated.generation_id,'created':repeated.created}
  check(repeated.created is False and repeated.generation_id==stored.generation_id and repeated.artifact==a and repeated.receipt==r,'SAME_ACQUISITION_REPEAT_MISMATCH')
  after_repeat=inventory();check(after_repeat==before,'REPEAT_CHANGED_STORE_BYTES_OR_MTIME')
  public['repeat']={'created':repeated.created,'same_generation':True,'same_artifact':True,'same_owner_receipt':True,'same_acquisition_id':repeated.artifact['acquisition_id']==a['acquisition_id'],'store_bytes_and_mtime_unchanged':True,'producer_reacquisition':False}
  public['validation']['same_artifact_repeat_idempotent']=True
  public['status']='CAPTURE_STORE_READ_REPEAT_VERIFIED'
  exit_code=0
except BaseException as exc:
 public['status']='ACTION_OR_VALIDATION_FAILED'
 public['error']={'type':type(exc).__name__,'module':type(exc).__module__,'message':'Omitted: no exception payload, provider content or credential values published.'}
 if isinstance(exc,RuntimeError) and str(exc) in {'READ_ONLY_GIT_FAILED','SOURCE_PIN_MISMATCH','PROTECTED_SOURCE_CHANGED','FRESH_RUNROOT_REQUIRED','SOURCE_AUTHORITY_CHANGED','SAME_ACQUISITION_REPEAT_MISMATCH','REPEAT_CHANGED_STORE_BYTES_OR_MTIME','PINNED_READ_CHANGED_STORE'}:public['error']['fixed_diagnostic']=str(exc)
 exit_code=2
finally:
 public['finished_utc_ns']=str(time.time_ns())
 public['preflight_complete']=preflight_complete
 if preflight_complete:
  try:
   public['final_store']=inventory()
   public['final_native_head']=get('rev-parse','HEAD').decode().strip()
   public['workspace_clean_after']=not get('status','--porcelain=v1','--untracked-files=all').strip()
   public['ignored_paths_absent_after']=not get('ls-files','--others','--ignored','--exclude-standard').strip()
   pins_check()
   public['all_source_pins_unchanged_after']=True
   public['imported_repository_sources_after_call']=current_imports()
   check(public['final_native_head']==HEAD and public['workspace_clean_after'] and public['ignored_paths_absent_after'],'POSTFLIGHT_WORKSPACE_CHANGED')
  except BaseException as exc:
   public['postflight_error_type']=type(exc).__name__;public['status']='POSTFLIGHT_VALIDATION_FAILED';exit_code=2
  public['private_result_identity']=writer(RUNROOT/'PRIVATE_RESULT.json',private)
  public['wrapper_exit_code']=exit_code
  identity=writer(RUNROOT/'PUBLIC_RESULT.json',public)
  print(json.dumps({'status':public['status'],'stage':public['stage'],'wrapper_exit_code':exit_code,'producer_call_count':public['producer_call_count'],'provider_request_attempts_recorded':public['provider_request_attempts_recorded'],'source_acquisition_status':(public.get('acquisition') or {}).get('status'),'retained_row_count':(public.get('acquisition') or {}).get('retained_row_count'),'public_result':str(RUNROOT/'PUBLIC_RESULT.json'),'public_identity':identity,'private_result_identity':public['private_result_identity'],'workspace_clean_after':public.get('workspace_clean_after')}),flush=True)
 else:
  print(json.dumps({'status':public['status'],'stage':public['stage'],'preflight_complete':False,'source_call_count':public['producer_call_count'],'error':public.get('error')}),flush=True)
sys.exit(exit_code)

