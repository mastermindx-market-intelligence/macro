import pathlib,subprocess,json,hashlib,stat,os,datetime,ast
ROOT=pathlib.Path('/Volumes/Mastermind/agent-workspaces/macro/web/gmi-economic-source-diagnostic-20261009-pro-004')
CACHE=pathlib.Path('/Users/chriswong/Library/Caches/Mastermind/economic-network-20261009')
HEAD='7af7a9785d74c1b420b23de3be0eac6946cc2200'
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def get(*a):
 p=subprocess.run(['git','--no-lazy-fetch','--no-optional-locks','-C',str(ROOT),*a],capture_output=True,env=env);assert p.returncode==0,(a,p.returncode);return p.stdout
assert get('rev-parse','HEAD').decode().strip()==HEAD and not get('status','--porcelain=v1','--untracked-files=all').strip()
helper=ROOT/'scripts/close_pass_host_runner.py';b=helper.read_bytes()
assert len(b)==67554 and hashlib.sha256(b).hexdigest()=='20335fb0f694ca904e130a2b9016f379161c10946adb2e15dbfc5bdff3addd69'
assert get('rev-parse',HEAD+':scripts/close_pass_host_runner.py').decode().strip()=='a5df3ba140cb9fa9827642d3f90f1ed2e69ce057'
common=pathlib.Path(get('rev-parse','--path-format=absolute','--git-common-dir').decode().strip()).resolve()
assert common.name=='.git' and common.is_dir()
primary=common.parent
first=[l[len('worktree '):] for l in get('worktree','list','--porcelain').decode().splitlines() if l.startswith('worktree ')][0]
assert pathlib.Path(first).resolve()==primary
owner=primary/'.env'
result={'schema':'economic_network.native_mu_owner_env_metadata/v1','observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':HEAD,'git_common_dir':str(common),'primary_worktree':str(primary),'first_registered_worktree':first,'owner_environment_candidate':str(owner),'source_binding':'The tracked Massive native close-pass bootstrap explicitly identifies PRIMARY as owner of Git objects, remote and .env; actual Git common-dir/first-worktree equality selects that primary without credential-file search.','helper_sha256':hashlib.sha256(b).hexdigest(),'helper_blob':'a5df3ba140cb9fa9827642d3f90f1ed2e69ce057','helper_proposed_callable':'load_env_file','credential_file_content_read':False,'environment_values_inspected':False,'application_or_parser_imported':False,'provider_calls':0,'current_euid':os.geteuid(),'native_source_or_git_mutation':False}
try:
 s=owner.lstat();result['file_metadata']={'exists':True,'is_regular':stat.S_ISREG(s.st_mode),'is_symlink':stat.S_ISLNK(s.st_mode),'owner_uid':s.st_uid,'mode':oct(stat.S_IMODE(s.st_mode)),'size':s.st_size,'device':s.st_dev,'inode':s.st_ino,'mtime_ns':str(s.st_mtime_ns),'same_euid':s.st_uid==os.geteuid(),'group_or_world_writable':bool(s.st_mode&0o022),'within_1MiB':s.st_size<=1024*1024}
except FileNotFoundError:result['file_metadata']={'exists':False}
tree=ast.parse(b)
result['module_top_level_statement_kinds']=[type(x).__name__ for x in tree.body]
result['module_top_level_executable_text']=[ast.get_source_segment(b.decode(),x) for x in tree.body if isinstance(x,(ast.Expr,ast.If)) and not (isinstance(x,ast.Expr) and isinstance(x.value,ast.Constant) and isinstance(x.value.value,str))]
dest=CACHE/'native-mu-owner-env-metadata-002.json'
body=(json.dumps(result,indent=2,sort_keys=True)+'\n').encode()
with dest.open('xb') as f:f.write(body)
print(json.dumps(result));print(json.dumps({'receipt_bytes':len(body),'receipt_sha256':hashlib.sha256(body).hexdigest()}))
