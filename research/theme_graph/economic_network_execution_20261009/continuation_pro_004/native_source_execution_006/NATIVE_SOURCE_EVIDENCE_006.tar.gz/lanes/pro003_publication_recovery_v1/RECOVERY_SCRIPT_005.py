import pathlib,subprocess,json,hashlib,datetime,os
ROOT=pathlib.Path('/Volumes/Mastermind/agent-workspaces/macro/web/gmi-economic-observations-20261009-pro-003')
CACHE=pathlib.Path('/Users/chriswong/Library/Caches/Mastermind/economic-network-20261009')
HEAD='cbcc5ee143400af162a252e4faac0f06c7157e37';OLD='693ee939c8a28920ef9de7bc32a9f47a7ba76b82';BASE='87b01101ef13aa20ded205f3a2b267b68d094def';BRANCH='sol/web-gmi-economic-observations-20261009-pro-003'
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def sha(b):return hashlib.sha256(b).hexdigest()
def run(*a):return subprocess.run(['git','--no-lazy-fetch','--no-optional-locks','-C',str(ROOT),*a],capture_output=True,env=env)
def get(*a):
 p=run(*a);assert p.returncode==0,(a,p.returncode);return p.stdout
def save(name,d):
 dest=CACHE/name;assert not dest.exists();b=(json.dumps(d,indent=2,sort_keys=True)+'\n').encode()
 with dest.open('xb') as f:f.write(b)
 return {'path':str(dest),'byte_length':len(b),'sha256':sha(b)}
old_b=(CACHE/'pro003-ci-refresh-push-004.json').read_bytes();old=json.loads(old_b)
assert sha(old_b)=='8d94a78672a6594305333e11a2c26f7935267a4b0b14e4539d9fd48869af20a3'
assert old['push_exit_code']==1 and old['head']==HEAD and old['remote_head']==OLD
assert get('rev-parse','HEAD').decode().strip()==HEAD and get('branch','--show-current').decode().strip()==BRANCH
assert not get('status','--porcelain=v1','--untracked-files=all').strip() and not get('ls-files','--others','--ignored','--exclude-standard').strip()
mb=(ROOT/'research/theme_graph/economic_network_execution_20261009/continuation_pro_003/CI_REFRESH_CHECKPOINT_MANIFEST_004.json').read_bytes()
assert sha(mb)=='c0529dc603316a7f97e4d468269ca3e04df2ba257ae4db3d85437f987fccb896'
m=json.loads(mb);assert len(m['files'])==139
for row in m['files']:
 b=(ROOT/row['path']).read_bytes();assert len(b)==row['byte_length'] and sha(b)==row['sha256']
source=json.loads((CACHE/'pro003-current-main-integration-004.json').read_bytes())
for row in source['owner_inputs_before']:assert sha((ROOT/row['path']).read_bytes())==row['sha256']
assert get('rev-list','--parents','-n','1',HEAD).decode().split()==[HEAD,'3521765204903320db76ddd84d6a43539ded8e62']
closure=get('rev-list','--objects','--missing=print',HEAD,'--not',OLD,BASE)
assert not any(l.startswith(b'?') for l in closure.splitlines())
remote_before=get('ls-remote','--exit-code','origin','refs/heads/'+BRANCH).decode().split()[0];assert remote_before==OLD
config_before=run('config','--get','push.negotiate')
cmd=['git','--no-lazy-fetch','--no-optional-locks','-c','push.negotiate=true','-C',str(ROOT),'push','--progress','origin','HEAD:refs/heads/'+BRANCH]
pre={'schema':'economic_network.observation_push_recovery_preflight/v1','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':HEAD,'prior_push_pid':50875,'prior_process_terminal_exit_observed':1,'prior_push_receipt_sha256':sha(old_b),'remote_before':remote_before,'all_139_checkpoint_members_unchanged':True,'all_71_owner_inputs_unchanged':True,'new_closure_missing_objects':0,'new_closure_entry_count':len(closure.splitlines()),'command':cmd,'transport_change':'Command-scoped standard push.negotiate=true; unchanged source and release controls. Existing no-lazy-fetch protection remains.','rationale':'Remote main advanced beyond the accepted local base. Negotiate common commits rather than relying only on currently advertised tips.','primary_documentation':'https://git-scm.com/docs/git-config#Documentation/git-config.txt-pushnegotiate','no_force_reset_new_carrier_or_hook_override':True,'persistent_git_config_change':False}
pre_id=save('pro003-push-recovery-preflight-005.json',pre)
stdout_path=CACHE/'pro003-push-recovery-005.stdout.log';stderr_path=CACHE/'pro003-push-recovery-005.stderr.log'
with stdout_path.open('xb') as out,stderr_path.open('xb') as err:
 p=subprocess.Popen(cmd,stdout=out,stderr=err,env=env)
 print(json.dumps({'stage':'PUSH_RECOVERY_STARTED','child_pid':p.pid,'head':HEAD,'preflight_receipt':pre_id,'stderr_progress':str(stderr_path)}),flush=True)
 code=p.wait()
remote_after=get('ls-remote','--exit-code','origin','refs/heads/'+BRANCH).decode().split()[0]
config_after=run('config','--get','push.negotiate');unchanged=config_before.returncode==config_after.returncode and config_before.stdout==config_after.stdout
receipt={'schema':'economic_network.observation_push_recovery/v1','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':HEAD,'remote_head':remote_after,'push_exit_code':code,'stdout':stdout_path.read_text(),'stderr':stderr_path.read_text(),'preflight_receipt':pre_id,'clean':not get('status','--porcelain=v1','--untracked-files=all').strip(),'no_ignored_paths':not get('ls-files','--others','--ignored','--exclude-standard').strip(),'persistent_push_negotiate_config_unchanged':unchanged,'status':'PUBLISHED' if code==0 and remote_after==HEAD else 'NOT_PUBLISHED','merge_performed':False}
identity=save('pro003-push-recovery-005.json',receipt)
print(json.dumps({'stage':receipt['status'],'head':HEAD,'remote_head':remote_after,'push_exit':code,'receipt':identity,'persistent_config_unchanged':unchanged}),flush=True)
assert code==0 and remote_after==HEAD and receipt['clean'] and receipt['no_ignored_paths'] and unchanged
