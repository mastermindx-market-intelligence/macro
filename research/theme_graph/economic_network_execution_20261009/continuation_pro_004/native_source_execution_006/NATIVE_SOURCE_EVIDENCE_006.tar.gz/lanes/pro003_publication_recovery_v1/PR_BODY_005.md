Workstream: WS:GMI-THEME-GRAPH
Linear: NONE
Portfolio-Mode: tracked
Wave: GMI-ECONOMIC-OBSERVATION-PRO-003
Authority: implementation
Completion: proof-required

## Observable capability and why it matters

A retained relationship inspection can now be saved with its complete evidence and reconstructed by a fresh reader. The accepted reader depended on separately retained inputs; preserving only its successful output would lose the evidence closure and could carry a current positive into an invalid historical request.

This change adds the bounded private observation capability authorized by `agentos/decisions/DEC-GMI-ECONOMIC-RELATIONSHIP-OBSERVATION-MATERIALIZATION.md`, under the Chairman's existing research-and-end-to-end execution commission. It continues accepted research #8661, initial inspection #8667 and the accepted pure reader/review-set #8705. The workstream record has no canonical Linear issue binding; none is invented here.

## Exact implementation

- Add `engine/company_intelligence/relationship_observations.py` and its tests. Accept exactly seven original byte inputs, require both retained-byte judgments, compute the incumbent inspector internally, and preserve the complete inspection.
- Use the injected incumbent Research Vault strict conditional-write and exact-length bounded-read protocols. A content-addressed package is capped at 1 MiB, with at most 64 chunks of 16 KiB and a bounded manifest published last.
- Repeating identical inputs verifies the complete committed closure and returns the same reference without writes. Corrupt or incomplete commitments refuse; ambiguous final-write effects expose the expected reference and never become an unobserved success or automatic repair.
- Recompute the real inspector on every read. Unchanged requests compare the entire fresh result with the sealed result. Changed historical requests can abstain and withhold saved positive/support/review semantics. Explicit predecessor declarations preserve unresolved corrections rather than selecting winners.
- Enroll the two new paths and fourth suite in the existing `company-relationship-candidates` CI job. The independently reviewed inverse delta restores the previous shared manifest; other job changes are preserved.
- Preserve the real source/frame investigation, policy recommendation and independent findings, earlier reader release receipts, implementation reviews, native test logs and actual proof harness/receipts as source-bound research evidence.

Only the new module/test and that existing CI enrollment change runtime scope. Company Intelligence, Research Vault, Data OS, theme/propagation/K3-D/F04 and publication owners retain their contracts. This introduces no registry row, acquisition job, environment-selected factory, latest pointer, new cloud backend or product surface.

## Source and current-state receipt

Current candidate head: `cbcc5ee143400af162a252e4faac0f06c7157e37`. Its parent `3521765204903320db76ddd84d6a43539ded8e62` normally integrated the preceding successful candidate `693ee939c8a28920ef9de7bc32a9f47a7ba76b82` with accepted main `87b01101ef13aa20ded205f3a2b267b68d094def`.

The source integration preserved all 71 owner input bytes, the whole observation job definition and all 119 prior research files. Every other accepted CI job and all top-level manifest fields are preserved. The subsequent evidence-only commit deliberately versions README, preserves its previous exact bytes, and adds the complete 693 CI packet, the actual later canonical refusals and their reconciliation. Its 22 changed paths are confined to the existing observation research directory; all 139 checkpoint-manifest members were checked. No application, test or CI-policy bytes are altered by this evidence commit.

Accepted main includes risk-context #8712 (`ff652de571523466dea4d4d7f9644022198c3465`) and data/render updates. The upstream manifest adds `engine/risk_envelope.py` to six existing scopes without changing any job command or identifier. Its check-definition change required a new naturally triggered CI run; historical successful runs are retained as historical evidence.

Native implementation/proof source remains `6b58f15adae3b1d402d9993c52609d00083f1453`. The canonical workspace remains `gmi-economic-observations-20261009-pro-003`. Current protected Mastermind source is `8d838c8df453a78fac3459b7458576e1ba2cbcb8`. INDEX and all ten required companions were fetched from that exact revision and are byte-identical to the previously loaded `8c3bc581…` source; schema `mastermind.sol_skillpack.v1`, version 1.0.1 and minimum bootstrap major 1 remain compatible.

Canonical records: `agentos/workstreams/WS-GMI-THEME-GRAPH.md` and `agentos/decisions/DEC-GMI-ECONOMIC-RELATIONSHIP-OBSERVATION-MATERIALIZATION.md`. Existing Theme/F04/Forensics holds and owners remain in force. The older owner name is not treated as an absent-session permission gate. The earlier unresolved Studio Direct copy remains scoped to its reserved pro-002 destination; it was not replayed and is not represented as resolved.

[CI_REFRESH_ADJUDICATION_004.md](research/theme_graph/economic_network_execution_20261009/continuation_pro_003/CI_REFRESH_ADJUDICATION_004.md) is the latest detailed release continuation.

## Validation already completed

- **275 native application tests passed** across manual, pinned, review-set and observation suites. Eight pytest cleanup warnings concern pre-existing temporary browser-test garbage and remain recorded.
- **Five native CI contract tests passed**, including actual-manifest scope coverage, curated import closure and deterministic planning.
- **AgentOS: 1,593 records, zero errors, 143 existing warnings.**
- Independent implementation review raised three P2 findings; the frozen v2 corrective review is PASS. Independent CI enrollment review is PASS.
- **Actual retained-C01 native proof: PASS.** All seven original components persisted exactly; 36 chunks and one manifest formed a 580,751-byte package. The actual repeat made zero writes. Two distinct fresh processes returned identical complete 87,563-byte outputs.
- Current/support/history outputs each matched their complete direct actual inspector result. Historical `Registry([])` returned `ABSTAINED / AS_OF_DATASET_REQUIRED` without releasing saved positive/support/review content.
- All original, code and proof inputs were unchanged; the store remained unchanged through repeat/read/child phases. There were 21 expected guard controls, zero unexpected attempts, 19 actually compiled first-party source files and no acquisition, fixture or factory path.
- The principal verified all 53 declared first-party source files against materialized and committed bytes. The worktree remained clean with zero ignored files.

The complete reviewable result is in [OBSERVATION_NATIVE_PROOF_ADJUDICATION.md](research/theme_graph/economic_network_execution_20261009/continuation_pro_003/OBSERVATION_NATIVE_PROOF_ADJUDICATION.md), with the full public proof and manifests in its linked files. Private original HTML, stored packages and full private runtime payloads are excluded from Git.

Default whitespace diagnostics retain the frozen source artifacts' original hard breaks/terminal blank lines. Source/CI and newly authored principal controls pass their separate check; no frozen evidence, hook or policy was normalized to manufacture a whole-tree PASS.

## Original failed CI and preserved representation correction

Original candidate `9df735bbeaa8d0f4d4967296270bfb2246a5212f`, run `37925499382` attempt 1, actually failed `contract-delta` with **two introduced / zero inherited** unrun-suite findings. Both were archived v1/v2 authored test-source copies under research. The current canonical suite was separately enrolled and its actual four-suite owner command passed **275 tests in 8.73 seconds** on that original run.

The correction preserves those two archived files byte-for-byte as `.py.txt`, with full original commit/path/size/hash mapping. It does not change test discovery, CI enrollment, source baselines, waivers or application code. Native verification checked the exact relocation, all 53 unchanged source pins, both unchanged historical manifests and every member of the frozen independent CI/integration archives. A normal commit/push verified the exact current remote head and a clean worktree with zero ignored paths.

The [archive correction](research/theme_graph/economic_network_execution_20261009/continuation_pro_003/ARCHIVED_TEST_SOURCE_CORRECTION.md) retains:
- The original failed/pending snapshot: 13 available artifacts against 15 expected, 97 of 98 selected jobs and 300 of 316 planned proof steps observed at its fixed cutoff. Pack 0 and the final semantic aggregate remain missing in that historical packet.
- A 57-member byte-verified independent CI archive and a nine-member source-integration archive.
- The complete 30,995-byte failed-gate log, separately captured as connector-decoded text encoded as UTF-8, matching the observer's raw-log SHA-256 `85fe520d6cb4f29cafe4f990a792bb7c28218742ac72a54e17710f0858666334`. The independent packet itself retains excerpts and the hash.
- The prior CLI log read's explicit exit-1/no-file effect; no terminal-escape override was used.

New principal controls pass their whitespace check. Nine trailing-space lines in the original CI log remain byte-exact; the whole-delta whitespace diagnostic remains recorded, not relabelled PASS. No unchanged application test repeat was needed for this archive representation change.

## Complete historical success and current-main refresh

The corrected candidate `42174563149254d2399e23e101baafd8b06f9b1e` completed run `37932039980`, attempt 1. Its actual tested merge was `04b70807e6b0a7d48091997eb405f9cc53ade9ad`, with ordered parents `40ebaebdbcd57eedaa627623f1cfd1860ff3ee3a` and that candidate. The frozen independent packet contains all **15/15 artifacts, 12/12 fragments, 98/98 selected jobs and 316/316 successful proof steps**. The actual owner command passed **275 tests in 9.25s**; contract-delta reported **0 introduced / 0 inherited**. All 53 accepted engine/lib source pins were independently checked against the actual tested Git tree. The entire aggregate and final gate JSON were independently reconstructed.

The complete 90-file packet, exact archive manifest, independent replay verification and readable observation report are retained in [pr8711_corrected_ci_evidence_v1](research/theme_graph/economic_network_execution_20261009/continuation_pro_003/pr8711_corrected_ci_evidence_v1/ARCHIVE_README.md). Its archive SHA-256 is `9723b71acf3d44f6918ddb8c1d319e49bcc760c048106ec3277d09c94a7a7805`. The historical inactive merge-queue check failure is retained; the unchanged canonical base-main classifier treats it as non-binding. No waiver or classifier change was made.

A subsequent canonical release check **refused before merge** because accepted main moved to `3bb1ee47939d9caa1db10a4e764365d3a2ee5b77` and changed the CI definitions themselves. The old green therefore remains historical evidence. It is not reused as the current candidate's gate. The current candidate normally integrates that main revision and publishes the complete review history.

See [CI_REFRESH_ADJUDICATION_002.md](research/theme_graph/economic_network_execution_20261009/continuation_pro_003/CI_REFRESH_ADJUDICATION_002.md) for the exact freshness refusal, source-preserving refresh, new-candidate requirement and current boundaries.

### Concluded preceding-candidate CI and subsequent release checks

Candidate `693ee939c8a28920ef9de7bc32a9f47a7ba76b82` completed its naturally triggered [run 37938576895, attempt 1](https://github.com/mastermindx-market-intelligence/macro/actions/runs/37938576895) successfully. The actual tested synthetic commit is `7d5fd7428fa91567db755117657f856e1347c5f9`, with ordered parents accepted main `3bb1ee47939d9caa1db10a4e764365d3a2ee5b77` and that candidate; distinct Git tree `67c6a12f7b91e45b63614819a732753fa4a7599a`.

The new independent packet verifies **15/15 exact artifact ZIP/member pairs, 12/12 fragments, 98/98 selected logical jobs and 316/316 successful proof steps**. All **2,302 CI assertions** passed, with complete aggregate reconstruction and equality to the actual final-gate JSON stdout. The aggregate logical SHA-256 is `e9deb074013733053d9552c8ab4f710f44e1cd940e2b30eb1be40fa0c838e913`. The actual owner moved to **pack 6** in this generation and reports **275 passed in 10.76 seconds**. The actual new contract-delta reports **0 introduced / 0 inherited**. Fresh tested-tree reads prove all **53/53 accepted engine/lib byte pins**.

The complete frozen packet contains 98 regular files and 11,768,732 uncompressed bytes. Its deterministic archive is 4,171,717 bytes, SHA-256 `9c6baa4681447f390cb176ebbe18ae39b6362daee64884799a0fec9bf42b00ce`; all three unchanged verifiers passed after safe extraction. Full report SHA-256 `64a2c476c3dcf128c23d56549ecc47c9ad330df4bcc8fb64db4e4b7317d95686`. Seven native GET processes completed with exit 0 and are reconciled. This packet is now retained in [pr8711_refreshed_ci_evidence_v1](research/theme_graph/economic_network_execution_20261009/continuation_pro_003/pr8711_refreshed_ci_evidence_v1/ARCHIVE_README.md), including the complete archive, external manifest, archive verification and readable report.

The inactive pilot authority failure remains explicitly preserved. No waiver or CI-policy modification was used.

The principal's subsequent gate002 stopped on the advanced protected-source pin; that revision was atomically reconciled with unchanged procedures. Gate003 then found clean strict checks/anchors, a green baseline and no recorded hold, but refused freshness because accepted `ff652de5…` changed check definitions. Both actual refusals are preserved. They are source-policy events, not automatic approval-review rejections or test failures.

The complete source refresh used a native Git inventory because the initial API compare reached its 300-file limit and was correctly refused as incomplete. Actual normal integration passed with all 71 source inputs and 119 research files unchanged. One later transport preparation stopped before repository writes on an archive-manifest field mismatch (`entries` versus `files`); the corrected reader checked all 98 original archive members without altering the frozen packet. Its original failed receipt and exact runner are retained separately. All completed principal processes are reconciled.

**The new `cbcc5ee1…` candidate requires its own concluded natural hosted run, current canonical release gate, ordinary expected-head merge and accepted-source postmerge proof.**

## Data, time, rights and authority

This C01 contract preserves the narrow planned 24GB 8H HBM3E-to-H200 integration. Date-only precision remains explicit; canonical legal parties, shipments, revenue, economic weights, current continuing commerce and theme membership are unproved. Bytes and reviewer labels do not authenticate custody, authorship, independence, truth or permitted source use.

All results remain `NOT_ADMITTED`, Graph1 is null, and rank/gate/size/trade/prediction flags remain false. Production, public export and training permission remain unestablished. The native witness establishes LocalStore behavior on the observed Python installation, not cloud equivalence, an operating-system sandbox or cross-platform proof.

## Completion and continuation

This PR completes only its bounded private observation implementation after concluded hosted CI, ordinary expected-head merge, accepted-source verification and a fresh-store postmerge witness. Merge itself does not complete production, historical or predictive acceptance.

The 120-issuer WP02 diagnostic has no real selected cohort: the measured frame is incomplete. V2 plus the signed-action clarification is adopted for research in separate checkpoint `7c1463015b8f1a3296f09d12a8052112939b4c25`, after independent method review. Its corrected structural kernel passed independent v2 review, and a separate bounded public-API investigation reached the whole-output refusal. The corrected kernel, independent output-bound proof, native validation and CI enrollment are published in separate checkpoint `7af7a9785d74c1b420b23de3be0eac6946cc2200`. Its PR is sequenced after this observation release so both preserve the current shared CI manifest. Real source history, complete ranking denominators, rights, identity/activity evidence and genuine difficult cases remain held; the parallel increment does not relax them or grant predictive authority.

## Publication transport reconciliation

The first push of `cbcc5ee143400af162a252e4faac0f06c7157e37` terminated with exit 1 because a partial-clone history object was unavailable to that packing operation while lazy fetching was disabled; the remote remained at `693ee939`. That terminal failure and its receipt are preserved. After read-only reconciliation, the same unchanged candidate was published normally with Git's command-scoped `push.negotiate=true`, retaining the no-lazy-fetch protection. Native recovery PID 30522 completed with exit 0; the remote head equals `cbcc5ee143400af162a252e4faac0f06c7157e37`. The recovery receipt SHA-256 is `4810a1c6cf0679b107a2592a330a80e573ff3841ef504b67c59f563c5b9a961b`. No persistent Git configuration, source bytes, release conditions or hook policy changed. This is publication evidence; the candidate's own natural CI and current release checks remain required.
