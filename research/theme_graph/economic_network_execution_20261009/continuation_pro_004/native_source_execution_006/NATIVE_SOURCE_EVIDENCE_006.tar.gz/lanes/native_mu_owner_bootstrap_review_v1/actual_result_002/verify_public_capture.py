"""Independent public-evidence arithmetic; never imports or executes native code.

Inputs are frozen public/source archives. Normalized empty acquisition objects
are constructed only in memory and only their identities are emitted. No raw
provider body, credential file, native store, or private result file is read.
"""
from __future__ import annotations

import ast
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import sys
from datetime import datetime, timezone

BASE = Path('/workspace/scratch/9fd3d58c239a/lanes')
OUT = BASE / 'native_mu_owner_bootstrap_review_v1/actual_result_002'
P = 'native_mu_capture_principal_v2/'
F = 'native_massive_us_feasibility_v1/'
DEVICE = '3f5ce987-e3eb-40a3-af9f-4b0ae54919cc'
HEAD = '7af7a9785d74c1b420b23de3be0eac6946cc2200'
CURRENT = '87b01101ef13aa20ded205f3a2b267b68d094def'
PROTECTED = '8d838c8df453a78fac3459b7458576e1ba2cbcb8'
PIN_FIELDS = ('path', 'byte_length', 'sha256', 'git_blob_sha1')
EXPECTED = {
    P+'PUBLIC_RESULT_002.json': (25559, '4fcd11f2d47e48748ab92461a01f778f0c767ae2b35db04efef6430422ee2a54'),
    P+'OUTER_RESULT_002.json': (3405, 'ee07bb7e324f9fe00495832afdf482ba13668584ea7ddea6ebaecdbd022e7b52'),
    P+'PUBLIC_READ_TOOL_RESULT_002.json': (28142, '9e9cb297a8ee755f397c97f6cc47f27d065c68c7ce19f54a737fa0e5edbdaf96'),
    P+'OUTER_READ_TOOL_RESULT_002.json': (3987, '1f3f38941d47e22cbca8053aae96646f5b02744f43e6a3f508f4888c5bf91ed4'),
    P+'NATIVE_START_002.json': (680, '0e9498907fd0e04a0553348c477044421220f84776a57809b7e47a458be20635'),
    P+'NATIVE_COMPLETION_002.json': (1805, 'f88504ff9a60c4914598f0a11c1887c4275c689327cd09e35d5e081d884fbd0f'),
    P+'LAUNCH_COMMAND_002.json': (38556, 'fca5a4679074c756405ac4dbb9522bea6b33acde7ebdf24331ce9b1e0aa8067c'),
    P+'LAUNCH_WRAPPER_002.py': (30342, 'f6469aa370e6b78c48496a521bb943205b9523b75c2952ef79275ba9d828c58a'),
    P+'run_owner_bootstrap_002.py': (28296, 'bd88bb68b15894a85f71fa7ac75f5a4a7fcce43518804f9b27e28f5fdc14b2f3'),
    P+'run_owner_bootstrap_002_unexecuted_pre_review.py.txt': (28311, 'b6ab3f96a68834b8616b2c98545cfccaa379c0db5f760c447d941a9ca8d02509'),
    P+'run_native_mu_capture_002.py': (18367, 'de5f94b084726522352b44966a928bd2c410f9260901c63833603f2d51817ac1'),
    P+'source_snapshots/close_pass_host_runner.py.txt': (67554, '20335fb0f694ca904e130a2b9016f379161c10946adb2e15dbfc5bdff3addd69'),
    P+'native-mu-owner-env-metadata-002.json': (3279, '5c218ba77b23446d41490adf13e99b5da2b3661f0cff06789d3377049b7fc31b'),
    P+'OWNER_METADATA_COMPLETION_002.json': (3506, '4ed442350a5c48b4b020aeb2d97b6f1331ec57b1da95684140b1d7fabd4130b8'),
    P+'OWNER_METADATA_SCRIPT_002.py': (3328, 'f4e04ac2b4100015ca9b43384735e30da49a84285d27325101deaabce7b24c8b'),
    'native_mu_capture_principal_v1/PUBLIC_RESULT.json': (16454, '9e9a8368a7ecfb38bcbf1f1e7ca71ae29b242aa55f4cf293492c5da472190483'),
    'native_mu_capture_principal_v1/run_native_mu_capture_001.py': (18367, '6fe0f67b7335b31ef3e4a3eb9a914ac1557236689deb563ac8887b5bd2d53439'),
    'native_mu_owner_bootstrap_review_v1/REVIEW.md': (9704, '919a6f483ce8ab5ca428a5bf79180d08566fe5a3ee0b62a78caa3133125324ca'),
    'native_mu_owner_bootstrap_review_v1/RECEIPT.json': (9444, '1a25f963508c1d084f5ed905b314da790412a02594f7a6605825b6b0f5d1f705'),
    'native_mu_owner_bootstrap_review_v1/SOURCE_REVIEW_MANIFEST.json': (826, '59a8e53a39417220cdf2f57c80f014a115a46a38867df53b31d0b95b0df16dca'),
    F+'SOURCE_PINS.json': (15589, 'a4846212a1c7c6ea73f2be59e8dd8dc07a21232db8e99b8cc32b2c9be905ff8f'),
    F+'READ_003_COMPLETION.json': (88492, 'ca7f2bdc58d92db336eecb2f5548e54600d4b787ca7bc99ae0e434a27de37757'),
    F+'READ_008_COMPLETION.json': (12773, 'd602c804501b9584f584abb3643d01dcccf13856ca3e70217c8195b74874660c'),
}


def require(condition, label):
    if not condition:
        raise AssertionError(label)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(data):
    return {'byte_length': len(data), 'sha256': sha(data)}


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode('utf-8')


def pairs(items):
    result = {}
    for key, value in items:
        require(key not in result, 'DUPLICATE_JSON_KEY')
        result[key] = value
    return result


def invalid_constant(value):
    raise AssertionError('NONFINITE_JSON_CONSTANT')


def parse(data):
    return json.loads(data.decode('utf-8'), object_pairs_hook=pairs,
                      parse_constant=invalid_constant)


def bounded_public(value):
    pending = [(value, 0)]
    nodes = 0
    while pending:
        obj, depth = pending.pop()
        nodes += 1
        require(nodes <= 8192 and depth <= 16, 'PUBLIC_SHAPE_BOUND')
        if type(obj) is dict:
            for key, item in obj.items():
                require(type(key) is str and len(key) <= 256, 'PUBLIC_KEY_BOUND')
                pending.append((item, depth+1))
        elif type(obj) is list:
            pending.extend((item, depth+1) for item in obj)
        elif type(obj) is str:
            require(len(obj) <= 4096, 'PUBLIC_SCALAR_BOUND')
        else:
            require(obj is None or type(obj) in (int, bool), 'PUBLIC_SCALAR_TYPE')
    return nodes


def tool_text(value):
    require(value.get('isError') is False, 'TOOL_ERROR')
    texts = [c['text'] for c in value['content'] if c.get('type') == 'text']
    require(len(texts) == 2 and DEVICE in texts[1], 'TOOL_DEVICE')
    return texts[0]


def convert_ns(mapping):
    result = dict(mapping)
    for key, value in result.items():
        if key.endswith('_utc_ns'):
            require(type(value) is str and re.fullmatch(r'[0-9]{1,24}', value),
                    'EXACT_NS_LEXEME')
            result[key] = int(value)
    return result


def iso_ns(value):
    seconds, nanos = divmod(int(value), 1_000_000_000)
    return datetime.fromtimestamp(seconds, timezone.utc).strftime('%Y-%m-%dT%H:%M:%S') + f'.{nanos:09d}Z'


def source_files(tool_result):
    text = tool_text(tool_result)
    rows = [parse(line.encode()) for line in text.splitlines() if line.startswith('{"files":')]
    require(len(rows) == 1, 'SOURCE_ARCHIVE_RECORD')
    return {r['path']: r for r in rows[0]['files']}


def literal_assignment(tree, name):
    matches = [n.value for n in tree.body if isinstance(n, ast.Assign)
               and any(isinstance(t, ast.Name) and t.id == name for t in n.targets)]
    require(len(matches) == 1, 'SINGLE_LITERAL_ASSIGNMENT_'+name)
    value = matches[0]
    if isinstance(value, ast.Call):
        require(isinstance(value.func, ast.Attribute) and value.func.attr == 'encode'
                and len(value.args) == 1 and ast.literal_eval(value.args[0]) == 'utf-8'
                and not value.keywords, 'EMBEDDED_UTF8_LITERAL')
        return ast.literal_eval(value.func.value).encode('utf-8')
    return ast.literal_eval(value)


def main():
    raw = {}
    for relative, expected in EXPECTED.items():
        path = BASE / relative
        require(path.is_file() and not path.is_symlink(), 'INPUT_REGULAR_FILE')
        require(path.stat().st_size == expected[0] <= 256*1024, 'INPUT_BYTE_BOUND')
        data = path.read_bytes()
        require((len(data), sha(data)) == expected, 'INPUT_IDENTITY_'+relative)
        raw[relative] = data
    public = parse(raw[P+'PUBLIC_RESULT_002.json'])
    outer = parse(raw[P+'OUTER_RESULT_002.json'])
    first = parse(raw['native_mu_capture_principal_v1/PUBLIC_RESULT.json'])
    public_nodes = bounded_public(public)
    bounded_public(outer)
    require(first['status'] == 'REFUSED_BEFORE_ACQUISITION'
            and first['refusal']['diagnostic'] == 'missing_credentials'
            and all(first[k] is None for k in ('F', 'acquisition', 'owner_receipt', 'read_receipt', 'repeat'))
            and first['final_store'] == {'exists': False, 'files': []}, 'FIRST_REFUSAL_PRESERVED')

    corrected = raw[P+'run_owner_bootstrap_002.py']
    original = raw[P+'run_owner_bootstrap_002_unexecuted_pre_review.py.txt']
    old_label = b'owner_environment_file_read_once_by_existing_parser'
    new_label = b'owner_environment_parser_called_once'
    require(original.count(old_label) == 1 and corrected == original.replace(old_label, new_label),
            'EXACT_CORRECTIVE_FIELD_ONLY')
    action = raw[P+'run_native_mu_capture_002.py']
    require(action.replace(b'native-mu-split-pro-004-002', b'native-mu-split-pro-004-001')
            == raw['native_mu_capture_principal_v1/run_native_mu_capture_001.py'],
            'EXACT_ACTION_RUNROOT_ONLY')
    launch = raw[P+'LAUNCH_WRAPPER_002.py']
    require(literal_assignment(ast.parse(launch), 'b') == corrected, 'LAUNCH_EMBEDDED_WRAPPER')
    command = parse(raw[P+'LAUNCH_COMMAND_002.json'])
    argv = shlex.split(command['command'])
    require(argv == ['PYTHONDONTWRITEBYTECODE=1', '/opt/homebrew/Caskroom/miniconda/base/bin/python3',
                     '-I', '-B', '-c', launch.decode('utf-8')], 'EXACT_LAUNCH_COMMAND')
    require(command['deviceId'] == DEVICE and command['executed_once'] is True
            and command['outer_script_sha256'] == sha(corrected)
            and command['action_sha256'] == sha(action), 'LAUNCH_METADATA')
    for key in ('PUBLIC', 'OUTER'):
        tool = parse(raw[P+key+'_READ_TOOL_RESULT_002.json'])
        text = tool_text(tool)
        header, payload = text.split('\n\n', 1)
        require('0 remaining' in header, 'READ_COPY_COMPLETE')
        require((payload+'\n').encode('utf-8') == raw[P+key+'_RESULT_002.json'], 'EXACT_NATIVE_COPY_'+key)
    start = tool_text(parse(raw[P+'NATIVE_START_002.json']))
    completed = tool_text(parse(raw[P+'NATIVE_COMPLETION_002.json']))
    require('Process started with PID 59297' in start, 'OUTER_START_PID')
    require('Process completed with exit code 0 (runtime: 13.54s)' in completed, 'OUTER_COMPLETION_EXIT')
    stages = [parse(line.encode()) for line in completed.splitlines() if line.startswith('{')]
    started = [parse(line.encode()) for line in start.splitlines() if line.startswith('{')]
    require(len(stages) == 3 and started == stages[:1], 'START_COMPLETION_STAGE_BINDING')
    require(stages[0]['script_sha256'] == sha(corrected) and stages[0]['script_bytes'] == len(corrected)
            and stages[0]['bytecode_disabled'] is True, 'ACTUAL_WRAPPER_BINDING')
    require(stages[1]['child_pid'] == 59339 and stages[1]['action_script_sha256'] == sha(action)
            and stages[1]['raw_child_output'] == 'PRIVATE_ONLY', 'ACTUAL_CHILD_BINDING')
    require(stages[2]['receipt_sha256'] == sha(raw[P+'OUTER_RESULT_002.json'])
            and stages[2]['receipt_bytes'] == len(raw[P+'OUTER_RESULT_002.json'])
            and stages[2]['result'] == outer['result']
            and stages[2]['outer_exit_code'] == stages[2]['child_exit_code'] == 0, 'ACTUAL_OUTER_RESULT_BINDING')
    require(outer['status'] == 'OWNER_BOOTSTRAP_AND_ACTUAL_CHILD_RESULT_RECONCILED'
            and outer['python_pid'] == 59297 and outer['child_pid'] == public['python_pid'] == 59339
            and outer['child_started'] is True and outer['child_exit_code'] == outer['outer_exit_code'] == public['wrapper_exit_code'] == 0,
            'PROCESS_RESULT_CHAIN')
    require({k:outer['child_public_result'][k] for k in ('byte_length', 'sha256')}
            == identity(raw[P+'PUBLIC_RESULT_002.json']), 'OUTER_CHILD_PUBLIC_BINDING')
    require(outer['first_attempt_public_sha256'] == sha(raw['native_mu_capture_principal_v1/PUBLIC_RESULT.json']),
            'OUTER_FIRST_REFUSAL_BINDING')
    require(outer['action_script_sha256'] == sha(action) and outer['helper_sha256']
            == sha(raw[P+'source_snapshots/close_pass_host_runner.py.txt']), 'OUTER_SOURCE_BINDING')
    require(outer['forwarded_owner_env_names'] == ['MASSIVE_API_KEY']
            and outer[new_label.decode()] is True and old_label.decode() not in outer,
            'CORRECTED_PARSER_ALLOWLIST_OBSERVATION')
    require(outer['owner_env_metadata_before'] == outer['owner_env_metadata_after']
            == {'device':16777234, 'inode':1035475373, 'uid':501, 'mode':384, 'size':1225,
                'mtime_ns':'1786287063173714000', 'regular':True, 'symlink':False}, 'OWNER_METADATA_UNCHANGED')
    metadata = parse(raw[P+'native-mu-owner-env-metadata-002.json'])
    require(metadata['first_registered_worktree'] == metadata['primary_worktree'] == outer['owner_primary']
            and metadata['git_common_dir'] == outer['owner_primary']+'/.git'
            and metadata['owner_environment_candidate'] == outer['owner_env_path'], 'PRIMARY_OWNER_PATH_BINDING')
    require(metadata['file_metadata']['owner_uid'] == metadata['current_euid'] == 501
            and metadata['file_metadata']['size'] == 1225
            and metadata['file_metadata']['inode'] == outer['owner_env_metadata_before']['inode'], 'PRIOR_METADATA_BINDING')
    for flag in ('credential_file_copied_or_modified', 'credential_values_published_or_written',
                 'owner_file_search_performed', 'provider_accounts_substituted', 'shell_env_executed',
                 'git_mutation', 'source_registry_or_production_activation'):
        require(outer[flag] is False, 'OUTER_EFFECT_BOUNDARY_'+flag)

    pins = parse(raw[F+'SOURCE_PINS.json'])
    normalize = lambda rows: sorted(({k:r[k] for k in PIN_FIELDS} for r in rows), key=lambda r:r['path'])
    require(len(public['source_pins']) == 18 and len({r['path'] for r in public['source_pins']}) == 18
            and normalize(public['source_pins']) == normalize(pins['source_files'])
            == normalize(first['source_pins']), 'EIGHTEEN_EXACT_SOURCE_PINS')
    imports = public['imported_repository_sources_before_call']
    require(imports == public['imported_repository_sources_after_call']
            == first['imported_repository_sources_before_call'] and len(imports) == 21
            and len({r['module'] for r in imports}) == len({r['path'] for r in imports}) == 21,
            'UNCHANGED_TWENTY_ONE_IMPORTED_SOURCE_IDENTITIES')
    for field in ('native_head', 'final_native_head'):
        require(public[field] == HEAD, 'CHILD_HEAD')
    require(outer['head'] == outer['native_head_after'] == HEAD
            and public['reviewed_source'] == CURRENT
            and public['protected_master_expected'] == public['protected_master_observed'] == PROTECTED,
            'REVISION_CHAIN')
    for flag in ('workspace_clean_after', 'ignored_paths_absent_after', 'all_source_pins_unchanged_after', 'preflight_complete'):
        require(public[flag] is True, 'SOURCE_POSTFLIGHT_'+flag)
    require(outer['workspace_clean_after'] is True and outer['ignored_paths_absent_after'] is True
            and outer['helper_bytes_unchanged_after'] is True and outer['owner_env_metadata_unchanged'] is True,
            'BOOTSTRAP_POSTFLIGHT')

    acquisition = public['acquisition']
    query = {'endpoint':'https://api.massive.com/stocks/v1/splits', 'ticker':'MU',
             'execution_date.gte':'2026-09-30', 'sort':'execution_date.asc', 'limit':1000}
    require(public['query'] == query and public['upper_execution_date_filter'] is None
            and public['D'] == public['basis_date_metadata'] == '2026-09-30'
            and public['K'] == '2026-10-09T00:00:00Z', 'EXACT_REQUEST_SCOPE')
    require(public['status'] == 'CAPTURE_STORE_READ_REPEAT_VERIFIED' and public['stage'] == 'SAME_ARTIFACT_REPEAT'
            and public['requested_case_count'] == public['producer_call_count']
            == public['same_artifact_intake_repeat_call_count'] == 1
            and public['cohort_selected_case_count'] == 0, 'REQUEST_PROCESSING_DENOMINATOR')
    require(public['provider_request_attempts_recorded'] == acquisition['page_count'] == len(acquisition['pages']) == 1
            and public['provider_request_count_is_network_instrumented'] is False, 'RECORDED_NOT_INSTRUMENTED_COUNT')
    require(acquisition['status'] == 'complete' and acquisition['failure_kind'] is None
            and acquisition['retained_row_count'] == 0
            and acquisition['row_execution_date_counts'] == {'on_D':0, 'after_D':0}, 'COMPLETE_EMPTY_RESULT')
    page = acquisition['pages'][0]
    require(page['http_status'] == 200 and page['body_bytes_observed'] == 76
            and page['body_complete'] is True and page['outcome'] == 'ok'
            and page['rows_received'] == page['rows_retained'] == page['page_index'] == 0
            and page['cursor_sha256'] is None
            and page['observed_body_sha256'] == '14af1ec774f42eb00a8f9d65cc02cbcf7fb823fbbd8e597202e81a55651902c8',
            'EMPTY_PAGE_OBSERVATION')
    source = source_files(parse(raw[F+'READ_003_COMPLETION.json']))['engine/close_pass/massive_split_evidence.py']
    source_data = source['content'].encode('utf-8')
    source_pin = next(r for r in public['source_pins'] if r['path'] == source['path'])
    require(identity(source_data) == {k:source_pin[k] for k in ('byte_length','sha256')}
            and hashlib.sha1(b'blob '+str(len(source_data)).encode()+b'\0'+source_data).hexdigest() == source_pin['git_blob_sha1'],
            'EXACT_ACQUISITION_CONTRACT_SOURCE')
    source_tree = ast.parse(source_data)
    require(literal_assignment(source_tree, 'SCHEMA') == 'market_memory.source.massive_split_history.v1'
            and literal_assignment(source_tree, 'SOURCE_ID') == 'massive_rest:stocks:split_history'
            and literal_assignment(source_tree, 'ENDPOINT') == query['endpoint'], 'SOURCE_SCHEMA_CONSTANTS')

    artifact = {'schema':'market_memory.source.massive_split_history.v1', 'source_id':'massive_rest:stocks:split_history',
                'acquisition_id':acquisition['acquisition_id'], 'request':{**query, 'basis_date':public['D']},
                'started_utc_ns':int(public['F']['producer_started_utc_ns']),
                'completed_utc_ns':int(public['F']['producer_completed_utc_ns']),
                'status':acquisition['status'], 'failure_kind':acquisition['failure_kind'],
                'pages':[convert_ns(page)], 'rows':[], 'basis_eligible':False, 'authority':acquisition['authority']}
    require(sha(canonical(artifact)) == acquisition['acquisition_sha256'], 'RECONSTRUCTED_ACQUISITION_SEAL')
    artifact['acquisition_sha256'] = acquisition['acquisition_sha256']
    artifact_bytes = canonical(artifact)
    require(identity(artifact_bytes) == {'byte_length':acquisition['artifact_byte_length'],
                                       'sha256':acquisition['artifact_sha256']}, 'RECONSTRUCTED_ARTIFACT_BYTES')
    owner = convert_ns(public['owner_receipt'])
    owner_hash = owner.pop('canonical_receipt_sha256')
    require(sha(canonical(owner)) == owner_hash, 'RECONSTRUCTED_OWNER_RECEIPT_SEAL')
    require(owner['capture_id'] == 'mmscapture_'+sha(canonical({'source_id':artifact['source_id'],
                'acquisition_id':artifact['acquisition_id']})), 'RECONSTRUCTED_CAPTURE_ID')
    require(owner['vintage_id'] == 'mmsvintage_'+sha(canonical(artifact['request'])), 'RECONSTRUCTED_VINTAGE_ID')
    require(owner['revision_id'] == 'mmsrevision_'+sha(canonical({'vintage_id':owner['vintage_id'],
                'artifact_sha256':acquisition['artifact_sha256']})), 'RECONSTRUCTED_REVISION_ID')
    require(owner['receipt_id'] == 'mmsrc_'+sha(canonical({**owner,'receipt_id':''})), 'RECONSTRUCTED_RECEIPT_ID')
    read = convert_ns(public['read_receipt'])
    require(read['read_receipt_sha256'] == sha(canonical({k:v for k,v in read.items() if k != 'read_receipt_sha256'})),
            'RECONSTRUCTED_READ_RECEIPT_SEAL')
    require(read['store_id'] == owner['store_id'] and read['receipt_id'] == owner['receipt_id']
            and read['generation_id'] == public['generation_id'] and read['receipt_sha256'] == owner_hash
            and read['artifact_sha256'] == owner['artifact_sha256'] == acquisition['artifact_sha256']
            and read['artifact_bytes'] == len(artifact_bytes)
            and read['reader_id'] == 'CorpActions.SplitEvidenceReader', 'PINNED_READER_BINDINGS')
    expected_private = {'schema':'economic_network.native_mu_capture_private/v1',
                        'source_result':{'artifact':artifact, 'receipt':owner, 'generation_id':public['generation_id'], 'created':True},
                        'read_result':{'artifact':artifact, 'owner_receipt':owner, 'read_receipt':read},
                        'repeat_result':{'artifact':artifact, 'receipt':owner, 'generation_id':public['generation_id'], 'created':False}}
    expected_private_bytes = (json.dumps(expected_private, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False)+'\n').encode()
    require(identity(expected_private_bytes) == public['private_result_identity'], 'EXPECTED_NORMALIZED_PRIVATE_ENVELOPE_IDENTITY')

    inventory = public['final_store']
    require(public['initial_store'] == {'exists':False, 'files':[]}
            and public['store_after_intake'] == inventory and inventory['exists'] is True
            and len(inventory['files']) == 8 and sum(x['byte_length'] for x in inventory['files']) == inventory['total_bytes'] == 6276,
            'UNCHANGED_EIGHT_FILE_INVENTORY')
    files = {r['path']:r for r in inventory['files']}
    require(len(files) == 8 and all(r['mode'] == '0o600' for r in files.values()), 'STORE_PATH_UNIQUENESS_AND_MODES')
    artifact_key = 'source_objects/'+acquisition['artifact_sha256'][:2]+'/'+acquisition['artifact_sha256']+'.json'
    require(owner['object_key'] == artifact_key and {k:files[artifact_key][k] for k in ('byte_length','sha256')} == identity(artifact_bytes),
            'RECONSTRUCTED_OBJECT_INVENTORY_BINDING')
    for prefix, id_key, tag in [('source_receipts','receipt_id','mmsrc_'), ('source_captures','capture_id','mmscapture_')]:
        identifier = owner[id_key]
        key = prefix+'/'+identifier[len(tag):len(tag)+2]+'/'+identifier+'.json'
        require({k:files[key][k] for k in ('byte_length','sha256')} == identity(canonical(owner)), 'RECONSTRUCTED_RECEIPT_COPY_BINDING')
    require(public['repeat'] == {'created':False, 'producer_reacquisition':False,
            'same_acquisition_id':True, 'same_artifact':True, 'same_generation':True,
            'same_owner_receipt':True, 'store_bytes_and_mtime_unchanged':True}, 'ACTUAL_SAME_ARTIFACT_REPEAT')
    require(len(public['validation']) == 9 and all(v is True for v in public['validation'].values()), 'NINE_PRINCIPAL_VALIDATIONS')

    expected_authority = {'context_only':True, 'horizon_role':'context', 'tier':'display', 'proposal_weight':0,
        **{k:False for k in ('may_append_outcome','may_escalate','may_execute','may_gate','may_originate','may_rank',
                            'may_select_options_candidate','may_size','may_trade','may_train_prophet','may_write_options_episode')}}
    require(acquisition['authority'] == owner['authority'] == expected_authority
            and acquisition['basis_eligible'] is owner['basis_eligible'] is read['basis_eligible'] is False,
            'CONTEXT_ONLY_NO_PROMOTION')
    require(public['boundaries'] == first['boundaries'] and public['F']['public_by_K'] == 'UNPROVED'
            and public['boundaries']['Graph1'] is None, 'ORIGINAL_HOLDS_UNCHANGED')
    require(acquisition['raw_body_retained'] is False and all(public[k] is False for k in
            ('raw_provider_body_published','secret_values_recorded','git_mutation','transport_or_clock_replacement')), 'NO_RAW_BODY_OR_NEW_AUTHORITY')
    clock_names = ('outer_started','child_started','producer_started','request_started','response_completed',
                   'producer_completed','owner_intake_started','owner_receipt_assembled','read_started','read_completed',
                   'child_finished','outer_finished')
    clocks = [outer['started_utc_ns'], public['started_utc_ns'], public['F']['producer_started_utc_ns'],
              page['request_started_utc_ns'], page['response_completed_utc_ns'], public['F']['producer_completed_utc_ns'],
              public['owner_receipt']['owner_intake_started_utc_ns'], public['owner_receipt']['owner_receipt_assembled_utc_ns'],
              public['read_receipt']['read_started_utc_ns'], public['read_receipt']['read_completed_utc_ns'],
              public['finished_utc_ns'], outer['finished_utc_ns']]
    require(all(type(n) is str and re.fullmatch(r'[0-9]{19}', n) for n in clocks)
            and list(map(int,clocks)) == sorted(map(int,clocks)), 'EXACT_CLOCK_ORDER')
    expected_summary = {'status':public['status'],'stage':public['stage'],'producer_call_count':1,
                        'provider_request_attempts_recorded':1,'source_status':'complete','source_failure_kind':None,
                        'retained_row_count':0,'F':public['F'],'same_artifact_repeat_calls':1,'source_store_exists':True}
    require(outer['result'] == expected_summary, 'OUTER_CHILD_RESULT_SEMANTICS')
    require(all((len((BASE/p).read_bytes()), sha((BASE/p).read_bytes())) == expected
                for p,expected in EXPECTED.items()), 'ALL_INPUTS_UNCHANGED_AFTER')
    result = {
        'schema':'economic_network.independent_native_mu_public_verification/v2',
        'verdict':'PASS_CURRENT_CAPTURE_CHAIN', 'source_outcome':'COMPLETE_EMPTY_RESULT',
        'reviewer_process':{'pid':os.getpid(),'parent_pid':os.getppid(),'bytecode_disabled':sys.dont_write_bytecode,
                            'native_processes_invoked':0,'application_imports':0,'provider_calls':0,
                            'credential_or_private_native_files_read':0},
        'native_processes_observed_from_archived_receipts':{'outer_pid':59297,'outer_exit':0,'runtime_seconds':'13.54',
                                                           'child_pid':59339,'child_exit':0},
        'public_envelope_nodes':public_nodes,
        'input_bindings':[{'path':p,'byte_length':n,'sha256':h} for p,(n,h) in sorted(EXPECTED.items())],
        'source_pin_count':18,'imported_repository_source_count':21,
        'native_head':HEAD,'reviewed_source':CURRENT,'protected_source':PROTECTED,
        'reconstructed_normalized_content':{
            'acquisition_seal':acquisition['acquisition_sha256'], 'artifact':identity(artifact_bytes),
            'owner_receipt':identity(canonical(owner)), 'read_receipt_seal':read['read_receipt_sha256'],
            'expected_private_envelope':identity(expected_private_bytes),
            'capture_vintage_revision_receipt_ids_recomputed':True,
            'raw_provider_body_reconstructed':False,'private_native_file_read':False,
            'store_manifest_or_generation_content_reconstructed':False},
        'count_basis':{'requested_cases':1,'producer_calls':1,'recorded_pages':1,'http_statuses':[200],
                       'recorded_response_bytes':76,'rows_received':0,'rows_retained':0,'same_artifact_intake_repeats':1,
                       'provider_request_count_independently_network_instrumented':False,'selected_cohort_cases':0},
        'store':{'files_after_intake':8,'files_after_read_and_repeat':8,'total_bytes':6276,
                 'all_reported_bytes_modes_mtimes_identical':True,'same_artifact_repeat_created':False},
        'clocks':{k:{'native_ns':v,'utc_display':iso_ns(v)} for k,v in zip(clock_names,clocks)},
        'boundaries':public['boundaries'],'authority':expected_authority,
        'first_refusal_preserved':True,'pre_execution_review_packet_unchanged':True,'inputs_unchanged_after':True,
        'authentication_limit':'Content identities and consistent owner receipts do not self-authenticate provider truth, reviewer independence, contractual rights, historical publication, legal identity, or production authority.',
        'evidence_limit':'Native operations are principal executions bound by archived source/tool/public receipts; this reviewer performed only local public-evidence arithmetic.'}
    data = (json.dumps(result,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode()
    with (OUT/'PUBLIC_VERIFICATION.json').open('xb') as handle:
        handle.write(data)
    print(json.dumps({'verdict':result['verdict'],'source_outcome':result['source_outcome'],
                      'reviewer_pid':os.getpid(),'verification':identity(data),
                      'reconstructed_artifact':identity(artifact_bytes),'input_files':len(EXPECTED)},sort_keys=True))


if __name__ == '__main__':
    main()
