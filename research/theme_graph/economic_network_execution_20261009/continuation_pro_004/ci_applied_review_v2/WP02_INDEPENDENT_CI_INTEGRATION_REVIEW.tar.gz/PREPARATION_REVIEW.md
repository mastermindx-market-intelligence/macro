# WP02 corrective delivery: CI integration preparation

**PASS for the inspected delivery representation. Actual native application and inverse-delta review remain pending.** No defect was found in the source-map, stable namespace, frozen-evidence representation, or the sole runnable suite placement.

This preparation read only scratch delivery files. It did not read the in-progress native integration, run the kernel or its tests, inspect or interfere with native merge processes 45223/45324, or mutate native files, refs, CI, providers, or stores.

## Exact delivery checked

The delivery has exactly 30 files. `KERNEL_SOURCE_MAP_003.json` has SHA-256 `2c6064464ddf290b93c0ddfa71e8afbb01c66f02959ff3cafe1674f057178d43` and describes all 29 other files without duplicate or missing targets. Every described byte length and SHA-256 matches the delivered file. Every mapping labeled `EXACT_ORIGINAL_BYTES` also matches its actual scratch source file byte for byte.

The current canonical implementation is corrective source revision 2, SHA-256 `f9814c8e65a155ae8273b4127661b5568e97a45c135b679f1db2eb84f36afdb6`. The canonical suite is SHA-256 `d7f8dc3ebaf7adafe164e3a370c017ac4bb26e509e35ccf2ba5978429d915082`. The shared helper remains SHA-256 `37db957fff940f2e9557e36586c07ee4a1a3ea534d9b3e36a5c96630b1a5aa78`.

The runtime path `source_diagnostic_kernel_v1` continues to identify the version 1 public contract. Both the map and README explicitly distinguish that stable namespace from implementation revision 2. They do not present a path rename as method adoption or evidence admission.

## Archive and discovery representation

All five archives were opened without extracting any files. All 298 members were verified against their archive manifests and original scratch packet bytes. Member names are unique and relative, with no parent traversal; every member is a regular file. Each archived original `MANIFEST.json` matches the source-map identity. The archived member counts are 16, 19, 56, 145, and 62. No original packet or earlier failure evidence was rewritten by the delivery representation.

Exactly one delivered file has a runnable pytest filename: `tests/test_gmi_source_diagnostic_kernel.py`. The archive's internal test names are not filesystem source paths and are not scanned as suites by the existing CI discovery mechanism. There are no duplicate research `test_*.py` files in the delivered tree.

Static inspection of the suite's explicit test functions and case-list lengths yields 117 cases. This is an AST count, not a native collection or execution result. The first counter attempted literal evaluation of a case list containing a call expression and refused; the corrected counter counted explicit list elements without evaluating any expression. Both attempts are recorded in `DELIVERY_PREPARATION_RECEIPT.json`.

## Frozen recommendation and current applicability

The seven-file original CI recommendation is preserved exactly, including its pre-correction module/suite hashes and historical 90-test count. The current source map and README expressly mark it as a frozen pre-application proposal and identify the corrected module and 117-test suite separately. That is a truthful history rather than a stale execution claim. `native_execution` and `hosted_ci` remain pending separate receipts in the current map.

The corrected module and suite introduce no new imports. The module's source delta is the declared UTC precision guard; the suite's additions exercise those timestamp cases without adding a file, provider, store, or dynamic import dependency. The helper, exact policy bytes, exact adoption bytes, canonical path layout, and source-loading code remain unchanged. The prior 32-path enrollment recommendation therefore remains applicable to these exact corrected sources, subject to native application and the ordinary closure checks.

## Prepared applied review

`verify_applied_ci_delta.py` is a read-only reviewer helper, syntax-checked but not executed against native files. It accepts an exact completed integrated preimage SHA and a worktree or exact after SHA. It must not be pointed at the stale pre-merge head as the preimage.

The verifier checks:

- Exact new job definition and the reviewed 32-path list; one added job and no incumbent definition or top-level manifest change.
- Existing manifest prefix preserved byte for byte, allowing only separator newlines at the old end of file; exact appended job bytes.
- Exact curated-set insertion, with the inverse Python AST and inverse source bytes equal to the integrated preimage.
- All 27 shared inputs unchanged across the insertion and still equal to their frozen reviewed identities.
- Existing selector, discovery, trigger-closure, dependency analyzer, and workflow bytes unchanged across this bounded insertion.
- Exact policy/adoption hashes, current source-map hash, and all 29 mapped delivery file hashes.
- One runnable delivery suite and no extra runnable research suite under this continuation namespace.
- HEAD unchanged during verification.

It runs no pytest, kernel, CI pack, source acquisition, provider call, or store operation. It issues only read-only Git commands and file reads, then prints a bounded JSON receipt. It is an independent review aid, not a new repository CI mechanism. The parent retains responsibility for actual native execution, selector/closure checks, hosted integration proof, and release.

I am available for the actual native inverse-delta review after the parent supplies the completed merge SHA and applied source delta. No native read will occur before that message.

## Artifacts

- `DELIVERY_PREPARATION_RECEIPT.json`: complete preparation result and archive counts; SHA-256 `070ace6b1034f82b797ee9e1949cd5bb09e534b15debc6eb36dd7a8b0efe112d`.
- `verify_applied_ci_delta.py`: prepared read-only verifier; SHA-256 `0711eb6b4c9fd252d462867f597a3349b2792a23e054772c5b115a723755cb94`.

The project remains a structural research kernel with no real cohort, source authority, rights, admission, predictive, or production promotion established by this preparation review.
