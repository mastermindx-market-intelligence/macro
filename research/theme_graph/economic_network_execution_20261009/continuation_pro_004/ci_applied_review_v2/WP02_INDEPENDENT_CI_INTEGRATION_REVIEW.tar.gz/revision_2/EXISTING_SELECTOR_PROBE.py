"""Root-run read-only native API probe; requires the canonical suite in git ls-files.

Stream through `python3 -B -` from the canonical repository root. This does not execute pytest or the kernel,
replace the selector, create a baseline, or run a CI pack. Packing measurements are
covered by the existing test_exclusive_curation_narrows_ordinary_code_prs test.
"""
import json
from pathlib import Path

from scripts import audit_unrun_tests as AUDIT
from scripts import run_ci_pack as PACK

JOB = "gmi-source-diagnostic-kernel"
SUITE = "tests/test_gmi_source_diagnostic_kernel.py"
REVIEW = Path("research/theme_graph/economic_network_execution_20261009/continuation_pro_004/ci_enrollment_review_v1")
expected_paths = json.loads((REVIEW / "RUNTIME_PATHS.json").read_text())["paths"]

suites = AUDIT.discover_suites()
same_name = sorted(s for s in suites if s.rsplit("/", 1)[-1] == SUITE.rsplit("/", 1)[-1])
assert same_name == [SUITE], ("native suite discovery mismatch; check git index", same_name)

jobs = PACK.load_legacy_jobs(Path(".github/ci/legacy-jobs.yml"))
owners = [j for j in jobs if j.job_id == JOB]
assert len(owners) == 1
owner = owners[0]
assert owner.gate == "code" and owner.exclusive
assert list(owner.paths) == expected_paths and len(expected_paths) == 32
commands = [s["run"] for s in owner.definition["steps"] if "run" in s]
assert sum(command.count(SUITE) for command in commands) == 1
scoped, note = PACK.infer_job_scopes(owners)
assert len(scoped) == 1 and not scoped[0].fallback_paths

def selected(path, **kwargs):
    hit, reason = PACK.select_jobs(scoped, [path], **kwargs)
    return JOB in {j.job_id for j in hit}, reason

positive = {path: selected(path) for path in expected_paths}
assert all(hit for hit, _ in positive.values()), positive
negative_paths = [
    "templates/index.html",
    "scripts/build_free_content.py",
    "engine/prophet/plan_book.py",
    "research/theme_graph/economic_network_execution_20261009/continuation_pro_004/source_diagnostic_kernel_v1/README.md",
]
negative = {path: selected(path) for path in negative_paths}
assert not any(hit for hit, _ in negative.values()), negative
manifest_default = selected(".github/ci/legacy-jobs.yml")
manifest_named = selected(".github/ci/legacy-jobs.yml", manifest_changed_job_ids=(JOB,))
assert manifest_default[0] and manifest_named[0]

print(json.dumps({
    "schema": "research.gmi.wp02.native_selector_probe/v1",
    "status": "PASS_NATIVE_API_PROBE",
    "sole_native_discovered_suite": same_name,
    "job_count": len(jobs), "job_id": JOB, "weight": owner.weight,
    "path_count": len(expected_paths), "fallback_paths": list(scoped[0].fallback_paths),
    "inference_note": note, "positive_paths": positive, "negative_paths": negative,
    "manifest_default": manifest_default, "manifest_named_job": manifest_named,
    "named_manifest_probe_is_not_a_new_manifest_classifier": True,
    "kernel_or_pytest_execution": False,
    "packing_measurement_claim": False,
}, sort_keys=True))
