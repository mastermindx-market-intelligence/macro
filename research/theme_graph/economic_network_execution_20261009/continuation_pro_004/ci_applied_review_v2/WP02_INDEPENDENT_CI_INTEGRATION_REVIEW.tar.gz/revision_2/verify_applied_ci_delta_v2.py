"""Read-only inverse-delta verifier; run only after root supplies the applied integration."""
from __future__ import annotations
import argparse
import ast
import copy
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import yaml

EXPECTED_JOB_YAML = "  gmi-source-diagnostic-kernel:\n    # WP02 deterministic artificial research model and structural-only refusals.\n    # Exact kernel/policy inputs plus shared pytest imports; no source acquisition.\n    if: ${{ false }}\n    gate: code\n    scope: exclusive\n    paths:\n      - engine/__init__.py\n      - engine/basket_breadth_divergence.py\n      - engine/catalyst_tone.py\n      - engine/desk_ledger.py\n      - engine/gdelt_client.py\n      - engine/marketing/__init__.py\n      - engine/marketing/accounts.py\n      - engine/marketing/authority.py\n      - engine/marketing/chart_render.py\n      - engine/marketing/charter.py\n      - engine/marketing/claims.py\n      - engine/marketing/cmo.py\n      - engine/marketing/departments.py\n      - engine/marketing/economics.py\n      - engine/marketing/events.py\n      - engine/marketing/ledgers.py\n      - engine/marketing/logo_cache.py\n      - engine/marketing/opportunity_bus.py\n      - engine/marketing/publication.py\n      - engine/marketing/state.py\n      - engine/master_brain.py\n      - lib/__init__.py\n      - lib/config.py\n      - research/theme_graph/economic_network_execution_20261009/continuation_pro_004/source_diagnostic_kernel_v1/source_diagnostic.py\n      - research/theme_graph/economic_network_execution_20261009/continuation_pro_004/source_diagnostic_kernel_v1/synthetic_example.py\n      - research/theme_graph/economic_network_execution_20261009/continuation_pro_004/source_diagnostic_policy_adoption_v1/POLICY_ADOPTION.json\n      - research/theme_graph/economic_network_execution_20261009/continuation_pro_004/source_diagnostic_policy_v2/RECOMMENDED_SELECTION_POLICY.json\n      - scripts/__init__.py\n      - scripts/worktree_sparse.py\n      - tests/__init__.py\n      - tests/conftest.py\n      - tests/test_gmi_source_diagnostic_kernel.py\n    runs-on: ubuntu-latest\n    steps:\n      - uses: actions/checkout@v4\n      - uses: actions/setup-python@v5\n        with:\n          python-version: \"3.12\"\n      - name: install source diagnostic test dependencies\n        run: pip install pytest\n      - name: WP02 source diagnostic kernel contracts\n        run: python -m pytest tests/test_gmi_source_diagnostic_kernel.py -q\n"
EXPECTED_INVENTORY_INSERTION = '    # WP02 source-diagnostic research kernel: exact inputs and shared pytest imports.\n    # Preserve closure audits, packing limits and incumbent owner declarations.\n    "gmi-source-diagnostic-kernel",\n'
EXPECTED_SHARED = json.loads("{\"engine/__init__.py\":{\"blob\":\"e69de29bb2d1d6434b8b29ae775ad8c2e48c5391\",\"bytes\":0,\"sha256\":\"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855\"},\"engine/basket_breadth_divergence.py\":{\"blob\":\"0ad5ecbfc6a0b983d43bf3d591904878e7bb004f\",\"bytes\":16985,\"sha256\":\"f073f778f43f9e040b5b3b76cfb66fe5085940ca00b92e7ae2fac359d1d68be6\"},\"engine/catalyst_tone.py\":{\"blob\":\"0540c15eefbff8944730c3ea6e1df1b9c5fe9b84\",\"bytes\":31503,\"sha256\":\"1856dc10ea0c9fc480517d50b1b8488303ea29dbc18c7b86cd11d29ea0e7dbb0\"},\"engine/desk_ledger.py\":{\"blob\":\"379028a7bf1fbf4ec96c86e39eeb0339b1d69381\",\"bytes\":6683,\"sha256\":\"9e079f7d26e3a60e75ee651140612c2efd6a9d00a9405ac5c424fe219600dbc2\"},\"engine/gdelt_client.py\":{\"blob\":\"27f194c1002021331572635b3b9faab1d3b58775\",\"bytes\":17148,\"sha256\":\"9282e05655b3de93da3046c0fe36d17e6b682d5825237fd68a16017ae788ab6a\"},\"engine/marketing/__init__.py\":{\"blob\":\"43080bba5ba2a0649a4ae0a7a18a1493cb5f39b2\",\"bytes\":660,\"sha256\":\"6c9056208c0a9c0115eb54b9f8abfd01b36fd168e843b0d5235c9291240bfa5c\"},\"engine/marketing/accounts.py\":{\"blob\":\"8af0b7119cd4cb9e0bcb8591ae6ac216e1aacd8d\",\"bytes\":5038,\"sha256\":\"868a6f728f177009808c9321416d08a9a8e610ff2c6aa3733bf3cb1c0adcc40f\"},\"engine/marketing/authority.py\":{\"blob\":\"b106235bcbf842dc793680585e9b1f2144910682\",\"bytes\":5355,\"sha256\":\"0d73e0cdd1bc36b24a6ea45658e63c254094bd3b8ef8878b092020afd1a27368\"},\"engine/marketing/chart_render.py\":{\"blob\":\"2de10f26bfebde3a5baf28756823a8e4a7e19c92\",\"bytes\":287289,\"sha256\":\"2d8d596c39545c9c0b064a56ec8508b41fb7845ff8fb124902a956896668fbcd\"},\"engine/marketing/charter.py\":{\"blob\":\"150e34351754dcbc2aad5a796752c2bd88735109\",\"bytes\":3628,\"sha256\":\"af4bef84e91e4631534e7da7508c4c6eae9b0529272365228339fe7b48ec4f1f\"},\"engine/marketing/claims.py\":{\"blob\":\"ecc812e3cd5d2b0a9675ceed600542e300dfa107\",\"bytes\":4436,\"sha256\":\"ad6667e71d23ddb4cda28cf5b8d79fc7328a80f94f415540063822c6dd0d9d0b\"},\"engine/marketing/cmo.py\":{\"blob\":\"9c401b07af2080ddb4dcb706de67369d27cf6fd8\",\"bytes\":10714,\"sha256\":\"f2b124754fb808d1935fcde19bdad3d66f334ada97b1f292fbfc9af0686974f9\"},\"engine/marketing/departments.py\":{\"blob\":\"1f3d42cb9afae285cada2606dc4138962d3cd3bc\",\"bytes\":45779,\"sha256\":\"f42be96b317a040bf28c6dcdb4343aa9d8b83fce0133ef77121448f2015f889f\"},\"engine/marketing/economics.py\":{\"blob\":\"d2b9da7d075f1dc1f1e67cec2ed931e826a055ff\",\"bytes\":4797,\"sha256\":\"bb4e78bb1251366d536a79aa789a357ce6ece47c32ca4534e920e8ee4d24b3d9\"},\"engine/marketing/events.py\":{\"blob\":\"2773e8872a3f14599d0c6b5c5fd0680b6bbba6fe\",\"bytes\":2136,\"sha256\":\"f940ba236256f56841cc944fdab5914ee4c5a85a5b9ce774137bcede7c5caace\"},\"engine/marketing/ledgers.py\":{\"blob\":\"fa7759742dfb9cab8605d8104e93fc9f37951d70\",\"bytes\":1686,\"sha256\":\"a94a60f25914ff67328c3b54eb46befa81c1b3910a9a0f72c260fb0609c7a3e8\"},\"engine/marketing/logo_cache.py\":{\"blob\":\"43685a6ccd37403e93f91e88f4eb845253e5d82e\",\"bytes\":14389,\"sha256\":\"afc70743c63ba6c7ddc732914876baa38ef0eff384b296b42f249fe09510d0c6\"},\"engine/marketing/opportunity_bus.py\":{\"blob\":\"624fc8d229e61de1f92d2142a34fe56c8382eb30\",\"bytes\":5350,\"sha256\":\"09f0ce3e55bcbda2e83051c396ba78bdc68d9e7d0fdfb093fdb4b09197f94df2\"},\"engine/marketing/publication.py\":{\"blob\":\"5b466cda88cdb05f37461a2184c07347734aceee\",\"bytes\":7182,\"sha256\":\"9904f90241f1b236dd88094aa6b388fdf43d627c6117900a3b36ededb6f4beb2\"},\"engine/marketing/state.py\":{\"blob\":\"4acc5934c0c23316e6893cb50fde0b0199948bab\",\"bytes\":18901,\"sha256\":\"1b933891c7c3c1d22018ea6b49fbb370a7f6cd5f9e5e9123912405081b81c15b\"},\"engine/master_brain.py\":{\"blob\":\"67bf21c6bb387505bd4c8b237804ba664181ff38\",\"bytes\":142755,\"sha256\":\"9d58cfe754f365206be998d95b29a60cf2a54df46a1cad8ac7788fae66a16b70\"},\"lib/__init__.py\":{\"blob\":\"e69de29bb2d1d6434b8b29ae775ad8c2e48c5391\",\"bytes\":0,\"sha256\":\"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855\"},\"lib/config.py\":{\"blob\":\"b6fc888269876242597da354aaa726c20ed95802\",\"bytes\":1131,\"sha256\":\"fa22ec934ec5294072b6bb4bf081d787f3f8ad5da4702ce3f4818b1674dbd53f\"},\"scripts/__init__.py\":{\"blob\":\"dafbbd0c3a49c56a2635c0d3d8918302d10689a6\",\"bytes\":2217,\"sha256\":\"099b906ef95aec83bbfc4d84b5ceb4f050e57a5fd2840e99faa9dc202e90c378\"},\"scripts/worktree_sparse.py\":{\"blob\":\"296e47bab2d28f9a019e81b5aef76eeea62a6cc3\",\"bytes\":88324,\"sha256\":\"08a6c23c75569c7acb6c8e1ef028bd7d752d283bbb37d540d666c25ab117657f\"},\"tests/__init__.py\":{\"blob\":\"e69de29bb2d1d6434b8b29ae775ad8c2e48c5391\",\"bytes\":0,\"sha256\":\"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855\"},\"tests/conftest.py\":{\"blob\":\"b2d40ef0eebddcfa3b4292a0d1cd296563222cdc\",\"bytes\":34456,\"sha256\":\"ad0b342a4303b5dc098d203530e8e8a83d4b5c3cbc38730309448cac14570425\"}}")
SOURCE_MAP_PATH = 'research/theme_graph/economic_network_execution_20261009/continuation_pro_004/KERNEL_SOURCE_MAP_004.json'
SOURCE_MAP_SHA = '0c456c830e5930b0bbd2beb75fdbbfdff823d4a99d9723a5a193c696c08ba018'
JOB_ID = 'gmi-source-diagnostic-kernel'
PREFIX = 'research/theme_graph/economic_network_execution_20261009/continuation_pro_004/'
POLICY_HASHES = {
    PREFIX + 'source_diagnostic_policy_v2/RECOMMENDED_SELECTION_POLICY.json': 'd41422d76219b1c5d3a3c9cbb19a1bc3124433031200b09499033bd4dc30d522',
    PREFIX + 'source_diagnostic_policy_adoption_v1/POLICY_ADOPTION.json': '645a20a39842d9c5a03b4ff39a37280d1aa02c32ef545c061d0aa959f06e0016',
}
CONTROL_PATHS = (
    'scripts/run_ci_pack.py', 'scripts/ci_scope_dependencies.py',
    'scripts/audit_unrun_tests.py', 'scripts/check_ci_trigger_closure.py',
    '.github/workflows/ci.yml',
)

def digest(value):
    return hashlib.sha256(value).hexdigest()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', required=True)
    parser.add_argument('--base', required=True, help='Completed integrated preimage commit; not the stale pre-merge branch.')
    parser.add_argument('--after', default='WORKTREE', help='WORKTREE or an immutable applied commit.')
    args = parser.parse_args()
    if not re.fullmatch('[0-9a-f]{40}', args.base):
        raise ValueError('base must be an exact commit SHA')
    if args.after != 'WORKTREE' and not re.fullmatch('[0-9a-f]{40}', args.after):
        raise ValueError('after must be WORKTREE or exact commit SHA')
    assert args.base == '07e663731b7ad7f1854b181180fee5855746d237', 'unexpected integrated preimage'
    repo = Path(args.repository).resolve()
    def git(*argv):
        return subprocess.run(['git', '-C', str(repo), *argv], capture_output=True, check=True, timeout=120).stdout
    def before(path):
        return git('show', args.base + ':' + path)
    def after(path):
        if args.after == 'WORKTREE':
            return (repo / path).read_bytes()
        return git('show', args.after + ':' + path)
    first_head = git('rev-parse', 'HEAD').decode().strip()
    expected = yaml.safe_load(EXPECTED_JOB_YAML)[JOB_ID]
    mb = before('.github/ci/legacy-jobs.yml')
    ma = after('.github/ci/legacy-jobs.yml')
    assert digest(mb) == 'b1b3d11fea1aa0aafa808f63d408adb5b92f1f0c285097a6edf8612c73d22008', 'preimage manifest identity mismatch'
    parsed_before, parsed_after = yaml.safe_load(mb), yaml.safe_load(ma)
    assert JOB_ID not in parsed_before['jobs'], 'job already exists in preimage'
    assert parsed_after['jobs'][JOB_ID] == expected, 'applied job differs from reviewed proposal'
    inverse = copy.deepcopy(parsed_after)
    del inverse['jobs'][JOB_ID]
    assert inverse == parsed_before, 'incumbent manifest definitions or top-level fields changed'
    text = ma.decode()
    anchor = '  ' + JOB_ID + ':\n'
    assert text.count(anchor) == 1, 'new job key does not occur exactly once'
    index = text.index(anchor)
    assert text[:index].rstrip('\r\n') == mb.decode().rstrip('\r\n'), 'existing manifest prefix was not preserved'
    assert text[index:] == EXPECTED_JOB_YAML, 'new block bytes differ from frozen insertion'
    tb = before('tests/test_ci_pack.py')
    ta = after('tests/test_ci_pack.py')
    before_tree, after_tree = ast.parse(tb), ast.parse(ta)
    def inventory(tree):
        return next(n for n in tree.body if isinstance(n, ast.Assign) and
                    any(isinstance(t, ast.Name) and t.id == 'CURATED_EXCLUSIVE' for t in n.targets))
    inv_before, inv_after = inventory(before_tree), inventory(after_tree)
    assert isinstance(inv_before.value, ast.Set) and isinstance(inv_after.value, ast.Set)
    entries = [n for n in inv_after.value.elts if isinstance(n, ast.Constant) and n.value == JOB_ID]
    assert len(entries) == 1
    assert JOB_ID not in ast.literal_eval(inv_before.value)
    inv_after.value.elts.remove(entries[0])
    assert ast.dump(before_tree, include_attributes=False) == ast.dump(after_tree, include_attributes=False), 'test AST changed beyond one inventory member'
    assert ta.decode().count(EXPECTED_INVENTORY_INSERTION) == 1
    assert ta.decode().replace(EXPECTED_INVENTORY_INSERTION, '', 1) == tb.decode(), 'test source changed beyond the exact reviewed insertion'
    shared = {}
    for path, value in EXPECTED_SHARED.items():
        current = after(path)
        assert current == before(path), 'shared input changed across insertion: ' + path
        assert digest(current) == value['sha256'], 'shared input differs from frozen reviewed input: ' + path
        shared[path] = digest(current)
    for path in CONTROL_PATHS:
        assert after(path) == before(path), 'control plane changed across insertion: ' + path
    for path, expected_hash in POLICY_HASHES.items():
        assert digest(after(path)) == expected_hash, 'policy binding changed: ' + path
    source_map_bytes = after(SOURCE_MAP_PATH)
    assert digest(source_map_bytes) == SOURCE_MAP_SHA
    source_map = json.loads(source_map_bytes)
    mapped = {}
    rows = source_map['all_delivery_files_except_this_map']
    assert len(rows) == 35 and len({r['target_path'] for r in rows}) == 35
    for row in rows:
        raw = after(row['target_path'])
        assert len(raw) == row['byte_length'] and digest(raw) == row['sha256'], 'delivery bytes changed: ' + row['target_path']
        mapped[row['target_path']] = digest(raw)
    pattern = re.compile(r'^(?:test_.+|.+_test)\.py$')
    mapped_suites = sorted(p for p in mapped if pattern.match(Path(p).name))
    assert mapped_suites == ['tests/test_gmi_source_diagnostic_kernel.py']
    if args.after == 'WORKTREE':
        unexpected = [p.relative_to(repo).as_posix() for p in (repo / PREFIX).rglob('*.py') if pattern.match(p.name)]
        assert not unexpected, 'duplicate runnable research suite(s): ' + repr(unexpected)
    else:
        research_files = git('ls-tree', '-r', '--name-only', args.after, '--', PREFIX).decode().splitlines()
        unexpected = [p for p in research_files if pattern.match(Path(p).name)]
        assert not unexpected, 'duplicate runnable research suite(s): ' + repr(unexpected)
    final_head = git('rev-parse', 'HEAD').decode().strip()
    assert final_head == first_head, 'HEAD moved during read-only verification'
    commands = [s['run'] for s in expected['steps'] if 'run' in s]
    command_text = '\n'.join(commands)
    print(json.dumps({
        'schema': 'research.gmi.wp02.applied_ci_inverse_delta/v2',
        'status': 'PASS_INVERSE_DELTA_ONLY', 'base_sha': args.base,
        'after_ref': args.after, 'observed_head': final_head,
        'manifest_before_sha256': digest(mb), 'manifest_after_sha256': digest(ma),
        'test_before_sha256': digest(tb), 'test_after_sha256': digest(ta),
        'job_count_before': len(parsed_before['jobs']), 'job_count_after': len(parsed_after['jobs']),
        'job_id': JOB_ID, 'declared_paths': expected['paths'],
        'expected_weight': max(1, len(commands) + command_text.count('tests/test_') * 2 + len(command_text) // 800),
        'all_incumbent_job_definitions_preserved': True,
        'all_control_plane_bytes_preserved': True,
        'manifest_prefix_bytes_preserved_except_eof_separator_newlines': True,
        'test_inverse_bytes_exact': True, 'shared_inputs_verified': shared,
        'source_map_sha256': digest(source_map_bytes), 'delivery_hashes': mapped,
        'sole_runnable_delivery_suite': mapped_suites[0],
        'native_suite_execution': False, 'hosted_ci_execution': False,
        'release_approval': False, 'native_mutation': False,
    }, sort_keys=True))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())

