# WP02 delivery revision 2: independent CI preparation review

**PASS for the revised delivery representation. Native application and applied inverse-delta review remain pending.** This is a new review generation; the original preparation report, receipts, manifest, and verifier remain unchanged.

The exact current source map is `KERNEL_SOURCE_MAP_004.json`, SHA-256 `0c456c830e5930b0bbd2beb75fdbbfdff823d4a99d9723a5a193c696c08ba018`. Independent scratch validation verified all 36 files, totaling 4,864,377 bytes: every one of the 35 mapping rows plus the source map itself. There are no duplicate, missing, or extra delivery targets. Every row marked `EXACT_ORIGINAL_BYTES` matches its source file directly, in addition to matching its declared length and hash.

All six archives were opened without extraction. Their 332 members match the archive manifests and original packet files byte for byte. All member names are unique, relative, and free of parent traversal; every member is a regular file. The six original packet manifests match their independently read archived bytes.

The sixth archive is the later output-bound review, 34 members, SHA-256 `3cff335f86997c698a1cfa45c9620b1cec5ec58751eb4f21cb41924321222da7`. Its complete review and verification files are separately accessible in the delivery. The current README and map attribute the successful output-refusal witness to that later review and preserve the earlier review limitation as historical evidence. They distinguish the actual 3,300-byte response from the analytical 8,912,663-byte projection and retain the unproved global output, memory, and adjacent-threshold limits. This packaging review did not repeat the three public calls or independently re-adjudicate the kernel's output behavior.

All 30 files of the first unapplied delivery remain unchanged in its original scratch tree and are also preserved byte for byte in the revised delivery. The previous map and runtime README have explicit historical paths under `kernel_delivery_preparation_v1`; the other 28 files retain their paths. This representation does not overwrite the original failure witnesses, original author/reviewer source packets, frozen CI recommendation, or previous preparation identities.

The runtime implementation remains corrective source revision 2 under the stable version 1 public-contract namespace. The module SHA-256 is `f9814c8e65a155ae8273b4127661b5568e97a45c135b679f1db2eb84f36afdb6`; the sole canonical suite SHA-256 is `d7f8dc3ebaf7adafe164e3a370c017ac4bb26e509e35ccf2ba5978429d915082`. The helper, policy/adoption identities, and all seven original CI proposal files remain unchanged.

There is exactly one runnable pytest filename in the delivery: `tests/test_gmi_source_diagnostic_kernel.py`. Its explicit case declarations statically count to 117. No archive extraction or import was used to calculate that count, and no native collection or test execution is claimed. The sixth archive adds no runtime dependency. The previously reviewed 32-path exclusive job remains applicable to the exact runtime bytes.

The current source map still marks both native execution and hosted CI as pending separate receipts. It makes no actual source-authority, real-cohort, admission, predictive, or production claim.

The versioned read-only verifier `verify_applied_ci_delta_v2.py` now binds to map004 and its 35 mapped files. It also explicitly requires the parent's completed integrated preimage `07e663731b7ad7f1854b181180fee5855746d237` and manifest SHA-256 `b1b3d11fea1aa0aafa808f63d408adb5b92f1f0c285097a6edf8612c73d22008`. These are expected identities supplied by the parent; their actual native bytes will be checked after application is announced. All prior inverse checks remain: exact new job and 32 paths, incumbent manifest prefix and definitions, exact curated-set insertion, all other test AST/source bytes, shared runtime files, control-plane preservation, policy hashes, delivery hashes, and no duplicate research suite.

The verifier has been syntax-checked only. Neither this reviewer nor the helper has read or executed the native applied candidate. No native operation, process interaction, source/Git mutation, CI dispatch, provider call, or store action occurred in this preparation phase.

The machine-readable result is `DELIVERY_PREPARATION_RECEIPT_V2.json`, SHA-256 `0700226612f6738562e95d603824b5b4670dabed78a8a62b2157048b6a23cce9`. Actual application review will produce a separate receipt after the parent supplies the applied state.
