"""Encode independent adversarial requests against a pinned draft wire schema.

This is fixture construction, not a second kernel or a source-proof verifier.
It imports no builder code, invokes no application API and solves no cohort.
Every input is artificial; expected results were frozen before the draft read.
"""
from copy import deepcopy
from hashlib import sha256
import gzip
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
WIRE = HERE / "wire"
INDEX = []


def encoded(obj):
    return json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf-8")


def source(x, content):
    raw = content.encode("utf-8")
    digest = sha256(raw).hexdigest()
    for s in x["sources"]:
        if s["sha256"] == digest and s["content"] == content:
            return s["source_id"]
    sid = "INDEPENDENT_SOURCE:" + digest
    x["sources"].append({"source_id": sid, "content": content, "sha256": digest, "byte_length": len(raw)})
    return sid


def evidence(x, token):
    return {"source_id": source(x, token), "start": 0, "end": len(token.encode("utf-8"))}


def numeric(x, a, value):
    a["value"] = value
    a["evidence"] = evidence(x, value)


def history_sources(x):
    h = x["history"]
    for field, binding in (("anchor_members", "anchor_source_id"), ("target_members", "target_source_id"), ("events", "events_source_id")):
        h[binding] = source(x, encoded(h[field]).decode("utf-8"))
    h["expected_anchor_member_ids"] = [r["member_id"] for r in h["anchor_members"]]
    h["expected_target_member_ids"] = [r["member_id"] for r in h["target_members"]]
    h["declared_event_ids"] = [r["event_id"] for r in h["events"]]
    x["counts"]["anchor_count"] = len(h["anchor_members"])
    x["counts"]["resulting_d_member_count"] = len(h["target_members"])
    for kind in h["covered_event_kinds"]:
        x["counts"]["event_" + kind] = sum(r["kind"] == kind for r in h["events"])


def snapshot_records(x):
    members = [{"member_id": r["issuer_id"] + ":MEMBER", "record_id": r["record_id"],
                "partition_id": "ARTIFICIAL_PARTITION:" + r["primary_groups"][0],
                "instrument": "ORDINARY", "primary_status": "PRIMARY"} for r in x["records"]]
    x["history"]["anchor_members"] = deepcopy(members)
    x["history"]["target_members"] = deepcopy(members)
    for name in ("source_declared_total", "exhaustive_total", "raw_record_count", "parsed_record_count", "identity_resolved_issuer_count"):
        x["counts"][name] = len(x["records"])
    history_sources(x)


def rename(value, old, new):
    if isinstance(value, dict):
        return {k: rename(v, old, new) for k, v in value.items()}
    if isinstance(value, list):
        return [rename(v, old, new) for v in value]
    return value.replace(old, new) if isinstance(value, str) else value


def save(case_id, obj, expected, reason, seed="V01_COMPLETE_MODEL", raw=None):
    payload = raw if raw is not None else encoded(obj)
    packed = gzip.compress(payload, compresslevel=9, mtime=0)
    name = case_id + ".request.gz"
    (WIRE / name).write_bytes(packed)
    INDEX.append({"case_id": case_id, "wire_file": "wire/" + name,
                  "request_byte_length": len(payload), "request_sha256": sha256(payload).hexdigest(),
                  "gzip_byte_length": len(packed), "gzip_sha256": sha256(packed).hexdigest(),
                  "baseline": seed, "expected_model_outcome": expected,
                  "independent_reason": reason, "actual_api_execution": "NOT_RUN"})


def main():
    assert not WIRE.exists(), "Do not overwrite frozen vectors"
    WIRE.mkdir()
    raw = gzip.decompress((HERE / "DRAFT_BASELINE.json.gz").read_bytes())
    assert sha256(raw).hexdigest() == "b9272931831e1cce8834911b0ec1e321cd2de7dc8c622b01038bc8242fc605cf"
    base = json.loads(raw)
    for r in base["records"]:
        numeric(base, r["classes"][0]["shares"]["assertions"][0], "100000000")
    save("V01_COMPLETE_MODEL", base, "ARTIFICIAL_MODEL_COMPLETE with120 distinct modeled IDs and every fixed quota; all real fields/authorities held", "Independent four-value pool control; artificial caps400m/300m/200m/100m; no real stress requirement is satisfied.", seed="Pinned author draft seed with every share quantity changed to100m and exact supplied-token binding updated")

    x = deepcopy(base)
    template = next(r for r in x["records"] if r["primary_groups"] == ["UK"] and r["activity"] == "SEMICONDUCTOR_CLOUD")
    x["records"] = [r for r in x["records"] if r["primary_groups"] != ["UK"]]
    for i in range(8):
        r = rename(deepcopy(template), template["issuer_id"], f"INDEPENDENT:UK:SEMICONDUCTOR_CLOUD:{i}")
        numeric(x, r["classes"][0]["price"]["assertions"][0], "4")
        x["records"].append(r)
    snapshot_records(x)
    assert len(x["records"]) == 152
    save("V02_INT_HALL_DEFICIENCY", x, "Initial artificial INT flow18<24, explicit deficient cut, no completed model cohort", "Exact 18-cell flow/cut proof in HALL_18_CAPACITY_VECTOR.json; all country and cell marginals pass.")

    for cid, values, expect in (("V03_BOUNDARY_TIE", ["4", "3", "3", "1"], "L3/M0/S1"), ("V04_ALL_TIED", ["4"]*4, "L4/M0/S0")):
        x = deepcopy(base)
        rows = [r for r in x["records"] if r["primary_groups"] == ["US"] and r["activity"] == "SEMICONDUCTOR_CLOUD"]
        for r, value in zip(rows, values):
            numeric(x, r["classes"][0]["price"]["assertions"][0], value)
        save(cid, x, "Explicit non-INT quota shortfall; " + expect, "Equal cap values must not be split by identifier priority.")

    x = deepcopy(base)
    foreign = next(r for r in x["records"] if r["primary_groups"] == ["CN_MAINLAND"])
    foreign["issuer_id"] = x["records"][0]["issuer_id"]
    save("V05_DUPLICATE_ISSUER", x, "Typed global duplicate-economic-issuer refusal before selection", "Different record IDs and pool positions contain the same exact canonical model issuer ID.")

    for reverse in (False, True):
        x = deepcopy(base)
        h = x["history"]
        original = deepcopy(h["anchor_members"][0])
        replacement = dict(original, member_id="INDEPENDENT:REPLACEMENT:MEMBER")
        day = "2026-10-01" if reverse else "2026-09-30"
        h["kind"] = "RECONSTRUCTION"
        h["anchor_date"] = "2026-10-01" if reverse else "2026-09-29"
        h["anchor_public_upper"] = "2026-10-02T00:00:00Z"
        h["coverage_start"], h["coverage_end"] = sorted([h["anchor_date"], h["target_date"]])
        h["events"] = [
            {"event_id": "INDEPENDENT:REMOVE", "effective_date": day, "sequence": 0, "kind": "REMOVAL", "public_upper": "2026-10-02T00:00:00Z", "before": [original], "after": []},
            {"event_id": "INDEPENDENT:ADMIT", "effective_date": day, "sequence": 1, "kind": "ADMISSION", "public_upper": "2026-10-02T00:00:00Z", "before": [], "after": [replacement]}]
        if reverse:
            h["anchor_members"][0] = deepcopy(replacement)
            h["target_members"][0] = deepcopy(replacement)
        history_sources(x)
        save("V07_REVERSE_SET_MISMATCH" if reverse else "V06_FORWARD_SET_MISMATCH", x, "Typed history exact-set mismatch despite equal168 anchor/target counts", "Source bytes match supplied arrays and declared event/count metadata; only applying/reversing states exposes the wrong target.")
        if reverse:
            h["events"][1]["after"][0]["member_id"] = "INDEPENDENT:ABSENT_AFTER_STATE"
            history_sources(x)
            save("V07_REVERSE_AFTER_STATE", x, "Typed reverse-transition after-state mismatch", "Reverse admission requires a member absent from the supplied anchor.")

    for cid in ("V08_SAME_FACT_CONFLICT", "V09_MEASUREMENT_ORDER", "V10_POST_K_REVISION", "V11_PERSISTENT_SCOPE_HOLD"):
        x = deepcopy(base)
        c = x["records"][0]["classes"][0]
        a = c["shares"]["assertions"][0]
        a["coordinate"] = "2026-09-30"
        numeric(x, a, "190000000")
        numeric(x, c["price"]["assertions"][0], "10")
        b = deepcopy(a)
        b["assertion_id"] = "INDEPENDENT:COMPETING_ASSERTION"
        b["publisher_id"] = "INDEPENDENT:SECOND_PUBLISHER"
        b["public_upper"] = "2026-10-08T00:00:00Z"
        numeric(x, b, "210000000")
        c["shares"]["assertions"].append(b)
        expect = "Typed same-fact component conflict; null whole issuer cap; no publication-recency winner"
        if cid == "V09_MEASUREMENT_ORDER":
            b["coordinate"] = "2026-06-30"
            expect = "Reference measurement Sep30 gives modeled cap1.9b; later publication of Jun30 does not win"
        elif cid == "V10_POST_K_REVISION":
            b["publisher_id"] = a["publisher_id"]
            b["public_upper"] = "2026-10-09T00:00:01Z"
            rid = "SUPERSEDES:" + b["assertion_id"] + ":" + a["assertion_id"]
            c["shares"]["relations"] = [{"relation_id": "INDEPENDENT:POST_K_CORRECTION", "kind": "SUPERSEDES", "publisher_id": a["publisher_id"], "new_id": b["assertion_id"], "old_id": a["assertion_id"], "fact_coordinate": "2026-09-30", "unit_basis": a["unit_basis"], "public_upper": b["public_upper"], "evidence": evidence(x, rid), "resolution_owner_id": "INDEPENDENT:UNVERIFIED_OWNER"}]
            expect = "PostK assertion/relation cannot replace eligible original; typed post-cutoff hold or explicit prior190m result, never210m corrected result"
        elif cid == "V11_PERSISTENT_SCOPE_HOLD":
            c["shares"]["state_kind"] = "PERSISTENT"
            a["coordinate"], b["coordinate"] = "2026-09-01", "2026-09-15"
            expect = "Explicit POINT-required/persistent-state scope hold in the public shares API; no later-start winner"
        save(cid, x, expect, "Competing model assertions are individually token-bound; provenance and semantic truth remain unverified.")

    for name, delta, zero in (("NEGATIVE", "-10000000", True), ("ZERO_EVIDENCED", "0", True), ("ZERO_MISSING_EVIDENCE", "0", False), ("POSITIVE", "10000000", True)):
        x = deepcopy(base)
        c = x["records"][0]["classes"][0]
        numeric(x, c["price"]["assertions"][0], "20")
        eid = "INDEPENDENT:DELTA"
        action = {"event_id": eid, "effective_date": "2026-09-29", "sequence": 0, "kind": "DELTA", "public_upper": "2026-09-30T00:00:00Z", "value": delta, "before_basis": c["d_basis"], "after_basis": c["d_basis"], "evidence": evidence(x, delta), "zero_evidence": evidence(x, "EXPLICIT_NO_CHANGE:" + eid) if delta == "0" and zero else None}
        c["actions"], c["declared_event_ids"], c["share_bridge_event_ids"] = [action], [eid], [eid]
        expect = {"NEGATIVE": "Modeled cap1.8b", "ZERO_EVIDENCED": "Modeled cap2.0b; numeric zero still grants no actual no-change proof", "ZERO_MISSING_EVIDENCE": "Typed missing explicit-no-change evidence hold; cap null", "POSITIVE": "Modeled cap2.2b"}[name]
        save("V12_" + name, x, expect, "Signed additive domain isolated from positive price and multiplicative factor domains.")

    x = deepcopy(base)
    c = x["records"][0]["classes"][0]
    c["d_basis"] = "INDEPENDENT:POST_SPLIT_UNITS"
    a, b = c["shares"]["assertions"][0], c["price"]["assertions"][0]
    a["coordinate"], b["coordinate"] = "2026-09-25", "2026-09-28"
    a["unit_basis"] = b["unit_basis"] = "INDEPENDENT:PRE_SPLIT_UNITS"
    numeric(x, b, "10")
    c["calendar"] = ["2026-09-28", "2026-09-29", "2026-09-30"]
    eid = "INDEPENDENT:SPLIT"
    c["actions"] = [{"event_id": eid, "effective_date": "2026-09-29", "sequence": 0, "kind": "SPLIT", "public_upper": "2026-09-30T00:00:00Z", "value": "2", "before_basis": a["unit_basis"], "after_basis": c["d_basis"], "evidence": evidence(x, "2"), "zero_evidence": None}]
    c["declared_event_ids"] = c["share_bridge_event_ids"] = c["price_bridge_event_ids"] = [eid]
    save("V13_SPLIT_COMPLETE_BRIDGE", x, "Modeled shares200m × D-equivalent price5 =1b", "Stale quote remains inside the model age bounds; only split-unit bridge changes its basis.")
    c["price_bridge_event_ids"] = []
    save("V13_SPLIT_MISSING_PRICE_BRIDGE", x, "Typed missing required price split bridge/basis hold, cap null", "No unbridged raw10 × doubled200m result.")

    for kind in ("ORDINARY", "ZERO_OR_CEASED"):
        x = deepcopy(base)
        r = x["records"][0]
        c = deepcopy(r["classes"][0])
        c["class_id"] = "INDEPENDENT:SECOND_CLASS"
        c["kind"] = kind
        c["shares"]["assertions"][0]["assertion_id"] = "INDEPENDENT:SECOND_CLASS:SHARES"
        numeric(x, c["shares"]["assertions"][0], "20000000")
        c["price"]["assertions"] = []
        r["class_ids"].append(c["class_id"])
        r["classes"].append(c)
        save("V14_" + kind, x, "Whole issuer cap null; unpriced component hold" if kind == "ORDINARY" else "RICHER_CLASS_RIGHTS_OR_CEASED_FACT_NOT_IMPLEMENTED; whole cap null", "A complete declared class set cannot silently lose an unsupported/unpriced member.")

    for mode in ("REAL_SOURCE", "SYNTHETIC_MODEL", None):
        x = deepcopy(base)
        if mode is None:
            del x["mode"]
        else:
            x["mode"] = mode
        x["claims"] = {"producer_success": True, "source_authority_verified": True, "history_proven": True, "rights_verified": True, "owner_id": "INDEPENDENT:SELF_ATTESTED", "receipt_sha256": "f"*64, "source_path": "NO_TRUSTED_SOURCE_PATH", "actual_F": "2026-10-09T12:00:00Z"}
        save("V16_SYNTHETIC_CLAIMS" if mode == "SYNTHETIC_MODEL" else "V15_" + (mode or "DEFAULT_REAL"), x, "Every real field null and every real authority/history/right held; modeled output only for explicit synthetic mode", "Claims are shape-valid but cannot authenticate their own origin or bypass the absent trust adapter.")

    payload = encoded(base)
    save("V17_DUPLICATE_TOP_KEY", None, "Stable duplicate-JSON-key refusal", "Full otherwise valid envelope with duplicate schema property.", raw=b'{"schema":"research.gmi.wp02.source_diagnostic_request/v1",' + payload[1:])
    save("V17_DUPLICATE_NESTED_KEY", None, "Stable duplicate-JSON-key refusal", "Full envelope, duplicate documented anchor_count inside counts.", raw=payload.replace(b'"counts":{', b'"counts":{"anchor_count":168,', 1))
    save("V17_INVALID_UTF8", None, "Stable UTF8 refusal, no replacement decoding", "Invalid leading byte; supplied record count is not proved parsed.", raw=b'\xff' + payload)
    for token in (b"NaN", b"Infinity"):
        save("V17_" + token.decode().upper(), None, "Stable nonfinite JSON refusal", "Invalid JSON numeric constant replaces one share quantity.", raw=payload.replace(b'"value":"100000000"', b'"value":' + token, 1))
    x = deepcopy(base)
    x["claims"] = {"owner_id": "INDEPENDENT_OWNER"}
    surrogate = encoded(x).replace(b'"INDEPENDENT_OWNER"', b'"\\ud800"', 1)
    save("V17_UNPAIRED_SURROGATE", None, "Stable invalid Unicode/UTF8 scalar refusal", "JSON escape encodes an unpaired surrogate, despite ASCII wire bytes.", raw=surrogate)

    for name, value in (("COUNT_BOOL", True), ("COUNT_NEGATIVE", -1), ("COUNT_FLOAT", 168.0), ("COUNT_INTEGER_13_DIGITS", 1000000000000)):
        x = deepcopy(base)
        x["counts"]["raw_record_count"] = value
        save("V18_" + name, x, "Typed integer-domain or JSON-integer-budget refusal; no count coercion", "Only one documented count field changes.")
    for name, value in (("VALUE_BOOL", True), ("VALUE_FLOAT", 1.5), ("NONPOSITIVE_PRICE", "0")):
        x = deepcopy(base)
        x["records"][0]["classes"][0]["price"]["assertions"][0]["value"] = value
        if isinstance(value, str):
            x["records"][0]["classes"][0]["price"]["assertions"][0]["evidence"] = evidence(x, value)
        save("V18_" + name, x, "Typed numeric-role refusal/hold; whole issuer cap null", "Signed delta exception must not admit invalid raw prices or binary floating values.")
    for length in (256*1024, 256*1024+1):
        x = deepcopy(base)
        source(x, "x"*length)
        save("V18_SOURCE_" + str(length), x, "Source-byte bound permits this size" if length == 256*1024 else "Typed source-byte limit refusal", "Added unused source has exact matching bytes/hash/length; total request stays below2MiB.")
    x = deepcopy(base)
    bundle = x["records"][0]["classes"][0]["shares"]
    template = bundle["assertions"][0]
    bundle["assertions"] = [dict(deepcopy(template), assertion_id="INDEPENDENT:EQUIVALENT:"+str(i)) for i in range(17)]
    save("V18_ASSERTIONS_17", x, "Typed per-bundle16-assertion limit refusal", "All17 values agree; conflict is not the target.")
    for length in (2*1024*1024, 2*1024*1024+1):
        padded = payload + b" "*(length-len(payload))
        save("V18_REQUEST_" + str(length), None, "Input-byte bound permits this size; same modeled content" if length == 2*1024*1024 else "Typed input-byte limit refusal", "Only legal trailing JSON whitespace changes; source/record semantics remain identical.", raw=padded)

    recipes = [
        {"case_id": "V17_REQUEST_NOT_BYTES", "invocation_mutation": "Decode V01 request as str and pass that str as request_bytes", "expected": "Stable byte-argument refusal; no Python traceback", "execution": "NOT_RUN"},
        {"case_id": "V19_POLICY_RAW_BINDING", "invocation_mutation": "Use V01 request; append one newline byte to exact policy_bytes", "expected": "Fixed raw policy binding refusal despite equal parsed JSON", "execution": "NOT_RUN"},
        {"case_id": "V19_ADOPTION_RAW_BINDING", "invocation_mutation": "Use V01 request; append one newline byte to exact adoption_bytes", "expected": "Fixed raw adoption binding refusal despite equal parsed JSON", "execution": "NOT_RUN"},
        {"case_id": "V18_RECORDS_513", "invocation_mutation": "Expand V01 to513 distinct artificial records, rebind full membership sources and all count fields, keep raw input<=2MiB", "expected": "Typed512-record budget refusal; exact bytes to be generated in frozen review if needed", "execution": "NOT_ENCODED_RECIPE_ONLY"},
        {"case_id": "V18_DEEP_STRUCTURE", "invocation_mutation": "Construct24/25-depth and160000/160001 lexical-token controls using documented counting conventions from frozen parser", "expected": "Boundary-specific refusal; no claim from an unrelated outer-shape error", "execution": "NOT_ENCODED_COUNTING_CONVENTION_PENDING_FROZEN_SOURCE"},
        {"case_id": "V18_OUTPUT_BUDGET", "invocation_mutation": "Determine a supported input that actually reaches output limit, or explicitly report branch reachability not exercised", "expected": "Whole-output refusal beyond8MiB with null synthetic content, never truncation", "execution": "NOT_ENCODED_OUTPUT_REACHABILITY_NOT_ESTABLISHED"}]
    (HERE / "WIRE_RECIPES.json").write_text(json.dumps(recipes, indent=2, sort_keys=True)+"\n")
    index = {"schema": "research.gmi.wp02.independent_wire_vectors/v1", "interface_snapshot": "INTERFACE_SNAPSHOT.json", "wire_case_count": len(INDEX), "cases": INDEX,
             "global_expected_result": {"status": "STRUCTURAL_ONLY", "readiness": "NOT_READY", "admission": "NOT_ADMITTED", "all_real_inputs_values": None, "source_authority": "SOURCE_AUTHORITY_UNVERIFIED", "source_rights": "SOURCE_RIGHTS_UNVERIFIED", "real_history": "FRAME_HISTORY_UNPROVEN"},
             "actual_application_api_calls": 0, "application_implementation_read": False,
             "scope": "Expected properties, not observed consumer output; holds use declared reason families until frozen-code mapping. All fixtures artificial. Draft shape readiness is not execution proof."}
    (HERE / "WIRE_INDEX.json").write_text(json.dumps(index, indent=2, sort_keys=True)+"\n")
    print(json.dumps({"wire_cases_encoded": len(INDEX), "compressed_wire_bytes": sum(c["gzip_byte_length"] for c in INDEX), "api_calls": 0}))


if __name__ == "__main__":
    main()
