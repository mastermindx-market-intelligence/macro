"""Independent public-only NVDA receipt audit. Stdlib only; no application import.
Single authorized execution, new review directory only. Provider rows, private
result, source-store payloads, credentials, Git, network and APIs are out of scope.
"""
import ast, datetime, hashlib, json, os, pathlib, re, stat, sys, time

CACHE = pathlib.Path('/Users/chriswong/Library/Caches/Mastermind/economic-network-20261009')
OUT = CACHE / 'native-nvda-public-independent-review-001'
REPO = pathlib.Path('/Volumes/Mastermind/agent-workspaces/macro/web/gmi-economic-source-diagnostic-20261009-pro-004')
PUBLIC_PATH = CACHE / 'native-nvda-split-pro-004-001/PUBLIC_RESULT.json'
OUTER_PATH = CACHE / 'native-nvda-owner-bootstrap-001.json'
ACTION_PATH = CACHE / 'native-nvda-capture-runner-001.py'
BOOTSTRAP_PATH = CACHE / 'native-nvda-owner-bootstrap-runner-001.py'
EXPECTED = {
    str(PUBLIC_PATH): (26399, '3fe5f660d92703e370c716135bd078d57fd281b8f30da611c65b5a6d8346414d'),
    str(OUTER_PATH): (4261, '6ea1031084e6948ee284222201158227ec5cc111874e08ebcd9d6a2b00d56040'),
    str(ACTION_PATH): (19659, '264535ec562043a18e4bc75c92fbbe9b5cba12428422b2a9677e89c0f769f699'),
    str(BOOTSTRAP_PATH): (29119, '92298f53a839bea81b16556ff71277f461d44f732df88a044a990785c620f0a3'),
}
HEAD = '74c542beb6e137958e3babe91a78b50aef651768'
SOURCE = '87b01101ef13aa20ded205f3a2b267b68d094def'
PROTECTED = '8d838c8df453a78fac3459b7458576e1ba2cbcb8'
CASE_SHA = 'c0fdd60f75ae4a741d77f452c6859938b75825c9e6fba9384942427f511ae5b9'
PROFILE_SHA = '7cd0ee632314baf4ac57489dbd58e5fe26675323a6840ef5bb6740885111a25b'
LAUNCHER_SHA = 'c1745bbce8934986ad0a218818b2f435121ed405d48a7ed1200a92272337e221'
DEVICE = '3f5ce987-e3eb-40a3-af9f-4b0ae54919cc'
AUTHORITY = {'context_only': True, 'horizon_role': 'context', 'tier': 'display', 'proposal_weight': 0,
    **{k:False for k in ('may_append_outcome','may_escalate','may_execute','may_gate','may_originate','may_rank',
    'may_select_options_candidate','may_size','may_trade','may_train_prophet','may_write_options_episode')}}
BOUNDARIES = {'D_close_price_and_currency':'NOT_SUPPLIED','Graph1':None,'K_public_vintage':'UNPROVED',
'Sol_CEO_architectural_adjudication':'NOT_ASSERTED','WP02_real_cohort':'NOT_ADMITTED',
'canonical_issuer_class_and_shares':'NOT_ADMITTED','gating':False,'global_population_and_relative_cap':'NOT_ADMITTED',
'prediction':False,'production_activation':False,'ranking':False,'sizing':False,'source_registry_modified':False,'trading':False}
SOURCE_ID = 'massive_rest:stocks:split_history'
SOURCE_SCHEMA = 'market_memory.source.massive_split_history.v1'
QUERY = {'endpoint':'https://api.massive.com/stocks/v1/splits','ticker':'NVDA','execution_date.gte':'2024-06-01',
         'sort':'execution_date.asc','limit':1000}
PREVIOUSLY_READ = {
 'basis':'Exact local public/source/tool receipts were read before the scratch executor stalled. This native phase does not reread their tool archives or the launch-command payload.',
 'principal_native_parent_pid':28236,'principal_native_child_pid':28310,'principal_parent_exit':0,'principal_child_exit':0,'principal_runtime_seconds':'11.78',
 'principal_start_archive':{'byte_length':682,'sha256':'020e82b277fde4b58c80243149f993c7c5913638fd37f98042594c9e06758a1a'},
 'principal_completion_archive':{'byte_length':2616,'sha256':'451e2544674c77dd2e1e745e887d751ccc8ce5ae01f4a5430a9d9ca8e6f5b8b9'},
 'principal_launch_command_archive':{'byte_length':39547,'sha256':'c687576dd37d7c9ef5aec651262318cdfaac6874ae6910f0f74bb8940bd4527d',
     'device_id':DEVICE,'launcher_sha256':LAUNCHER_SHA,'command_prefix_observed':'PYTHONDONTWRITEBYTECODE=1 /opt/homebrew/Caskroom/miniconda/base/bin/python3 -I -B -c',
     'exact_shell_payload_reverification_in_this_phase':False},
 'corrected_pre_execution_review_manifest_sha256':'5599394fd334f22cc24870ffd7427fbf01a1fc51e078aa0044712131695abba3',
 'initial_pre_execution_review_manifest_sha256':'a7308db3f8352fd92146bb416e3048cec04608dffbdbd909ae3aee311d1cb756',
 'source_case_sha256':CASE_SHA,'comparison_definition_sha256':PROFILE_SHA,
 'issuer_and_profile_bytes_reread_native':False,'source_case_profile_binding':'Prior exact source-only review attribution; hashes in actual action and public receipt checked here.',
 'local_carrier':{'functions_cell':'208','phase':'input-manifest preparation only','meaningful_verification_runs':0,
     'orchestration_termination_confirmed':True,'scratch_manifest_effect':'Unknown; executor stalled. No original input edit was requested. Do not replay.',
     'native_actions_in_that_phase':0},
}
ALLOWED_READS = {str(PUBLIC_PATH),str(OUTER_PATH),str(ACTION_PATH),str(BOOTSTRAP_PATH),str(pathlib.Path(__file__))}
for n in ('VERIFICATION_RESULT.json','INPUT_INVENTORY.json','REVIEW.md','MANIFEST.json','PRIOR_EVIDENCE_AND_CARRIER_CHANGE.json'):
    ALLOWED_READS.add(str(OUT/n))
for n in ('PUBLIC_RESULT.json','OUTER_RESULT.json','ACTION.py.txt','BOOTSTRAP.py.txt'):
    ALLOWED_READS.add(str(OUT/'inputs'/n))
checks = []
inventory = {}
started_ns = time.time_ns()
def digest(b): return hashlib.sha256(b).hexdigest()
digest(b'')
hashlib.sha1(b'').hexdigest()

def audit(event, args):
    if event.startswith(('socket.','subprocess.','urllib.')) or event in ('os.system','os.exec','os.posix_spawn'):
        raise RuntimeError('AUDIT_EXTERNAL_EXECUTION_OR_NETWORK_DENIED')
    if event == 'import':
        raise RuntimeError('AUDIT_LATE_IMPORT_DENIED')
    if event == 'open':
        p, mode, flags = args
        if isinstance(p, int):
            return
        p = os.path.abspath(os.fspath(p))
        writes = isinstance(flags,int) and bool(flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
        if writes:
            if not (p.startswith(str(OUT)+os.sep)):
                raise RuntimeError('AUDIT_WRITE_OUTSIDE_NEW_REVIEW_DENIED')
        elif p not in ALLOWED_READS:
            raise RuntimeError('AUDIT_UNLISTED_CONTENT_READ_DENIED')
    if event == 'os.mkdir':
        p = os.path.abspath(os.fspath(args[0]))
        if not p.startswith(str(OUT)+os.sep):
            raise RuntimeError('AUDIT_MKDIR_OUTSIDE_NEW_REVIEW_DENIED')
    if event in ('os.remove','os.rmdir','os.rename','os.link','os.symlink','os.utime','os.truncate','os.chmod','os.chown'):
        raise RuntimeError('AUDIT_MUTATION_DENIED')
sys.addaudithook(audit)

def require(ok, label):
    if not ok: raise RuntimeError(label)
    checks.append(label)

def secure_read(path, max_bytes=512*1024, remember=True):
    path=pathlib.Path(path)
    require(str(path) in ALLOWED_READS,'ALLOWLIST_'+path.name)
    before=path.lstat()
    require(stat.S_ISREG(before.st_mode) and not stat.S_ISLNK(before.st_mode),'REGULAR_'+path.name)
    require(before.st_size<=max_bytes,'READ_BUDGET_'+path.name)
    fd=os.open(path,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0))
    try:
        opened=os.fstat(fd)
        require((opened.st_dev,opened.st_ino,opened.st_size,opened.st_mtime_ns)==
                (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns),'DESCRIPTOR_BINDING_'+path.name)
        chunks=[];total=0
        while True:
            part=os.read(fd,min(65536,max_bytes+1-total))
            if not part:break
            chunks.append(part);total+=len(part)
            require(total<=max_bytes,'READ_TOTAL_'+path.name)
        body=b''.join(chunks)
        after=os.fstat(fd)
        require((after.st_size,after.st_mtime_ns)==(before.st_size,before.st_mtime_ns) and len(body)==before.st_size,'READ_STABILITY_'+path.name)
    finally:os.close(fd)
    if remember:
        inventory[str(path)]={'path':str(path),'byte_length':len(body),'sha256':digest(body),
            'mtime_ns':str(before.st_mtime_ns),'device':before.st_dev,'inode':before.st_ino,'mode':oct(stat.S_IMODE(before.st_mode))}
    return body

def write_new(name,body):
    path=OUT/name
    require(path.parent==OUT or path.parent==OUT/'inputs','OUTPUT_PARENT')
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,'O_NOFOLLOW',0),0o600)
    with os.fdopen(fd,'wb') as f:f.write(body);f.flush();os.fsync(f.fileno())
    ALLOWED_READS.add(str(path))
    return {'path':str(path),'byte_length':len(body),'sha256':digest(body)}

def pretty(value):return (json.dumps(value,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode('utf-8')
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf-8')
def pairs(xs):
    d={}
    for k,v in xs:
        if k in d:raise RuntimeError('DUPLICATE_JSON_KEY')
        d[k]=v
    return d
def bad_constant(v):raise RuntimeError('NONFINITE_JSON')
def parse(body,label):
    require(len(body)<=256*1024,'JSON_BYTES_'+label)
    obj=json.loads(body.decode('utf-8'),object_pairs_hook=pairs,parse_constant=bad_constant)
    nodes=0
    def walk(v,depth):
        nonlocal nodes
        nodes+=1
        require(depth<=16 and nodes<=8192,'JSON_STRUCTURE_'+label)
        if isinstance(v,dict):
            for k,w in v.items():
                require(isinstance(k,str) and len(k)<=4096,'JSON_KEY_'+label);walk(w,depth+1)
        elif isinstance(v,list):
            for w in v:walk(w,depth+1)
        elif isinstance(v,str):require(len(v)<=4096,'JSON_SCALAR_'+label)
        elif v is not None and type(v) not in (bool,int,float):raise RuntimeError('JSON_TYPE')
    walk(obj,0)
    return obj

def integer(v,label,minimum=0):
    require(type(v) is int and v>=minimum,'INTEGER_'+label);return v
def ns(v,label):
    require(type(v) is str and re.fullmatch(r'[1-9][0-9]{15,21}',v) is not None,'NS_STRING_'+label)
    return int(v)
def sha_field(v,label):
    require(type(v) is str and re.fullmatch(r'[a-f0-9]{64}',v) is not None,'SHA_'+label);return v
def exact_fields(v,fields,label):require(isinstance(v,dict) and set(v)==set(fields),'CLOSED_FIELDS_'+label)
def ast_assignment(t,name):
    found=[n.value for n in t.body if isinstance(n,ast.Assign) and any(isinstance(k,ast.Name) and k.id==name for k in n.targets)]
    require(len(found)==1,'AST_ASSIGN_'+name);return found[0]
def literal_dict(n):
    require(isinstance(n,ast.Dict),'AST_DICT')
    return {ast.literal_eval(k):v for k,v in zip(n.keys,n.values)}
def utc_text(v):
    seconds,nanos=divmod(v,10**9)
    return datetime.datetime.fromtimestamp(seconds,datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%S')+'.'+str(nanos).zfill(9)+'Z'

result={'schema':'economic_network.native_nvda_public_independent_review/v1','status':'IN_PROGRESS',
        'reviewer_pid':os.getpid(),'reviewer_started_utc_ns':str(started_ns)}
print(json.dumps({'stage':'INDEPENDENT_PUBLIC_REVIEW_STARTED','pid':os.getpid(),'review_root':str(OUT),'provider_calls':0,'application_imports':0}),flush=True)
exit_code=2
raw={}
try:
    require(sys.dont_write_bytecode is True,'BYTECODE_DISABLED')
    require(OUT.is_dir() and not OUT.is_symlink(),'NEW_REVIEW_DIRECTORY')
    raw={}
    for path,(size,h) in EXPECTED.items():
        b=secure_read(path);require(len(b)==size and digest(b)==h,'EXACT_INPUT_'+pathlib.Path(path).name);raw[path]=b
    public=parse(raw[str(PUBLIC_PATH)],'public');outer=parse(raw[str(OUTER_PATH)],'outer')
    A=ast.parse(raw[str(ACTION_PATH)]);B=ast.parse(raw[str(BOOTSTRAP_PATH)])
    emb=ast_assignment(B,'ACTION_BYTES')
    require(isinstance(emb,ast.Call) and isinstance(emb.func,ast.Attribute) and emb.func.attr=='encode'
            and len(emb.args)==1 and ast.literal_eval(emb.args[0])=='utf-8','ACTION_EMBED_SHAPE')
    require(ast.literal_eval(emb.func.value).encode('utf-8')==raw[str(ACTION_PATH)],'BOOTSTRAP_EMBEDS_ACTUAL_ACTION')
    require(ast.literal_eval(ast_assignment(B,'ACTION_SHA'))==EXPECTED[str(ACTION_PATH)][1],'BOOTSTRAP_ACTION_SHA')
    require(ast.literal_eval(ast_assignment(A,'HEAD'))==ast.literal_eval(ast_assignment(B,'HEAD'))==HEAD,'CODE_HEAD_BINDING')
    initial=literal_dict(ast_assignment(A,'public'))
    require(ast.literal_eval(initial['query'])==QUERY,'CODE_QUERY')
    require(ast.literal_eval(initial['boundaries'])==BOUNDARIES,'CODE_BOUNDARIES')
    rs_node=next(n.value for n in A.body if isinstance(n,ast.Assign) and any(ast.unparse(k)=="public['row_summary']" for k in n.targets))
    initial_rs=ast.literal_eval(rs_node)
    require(initial_rs['candidate_comparison_status']=='NOT_EVALUATED' and initial_rs['public_review_limit'].startswith('If evaluated,'),'CORRECTION_PRESENT')
    calls=[n for n in ast.walk(A) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='retain_split_history']
    require(len(calls)==1 and [ast.literal_eval(v) for v in calls[0].args]==['NVDA','2024-06-01','2026-09-30'],'ONE_ACTUAL_SOURCE_CALL_IN_CODE')
    require(all('candidate_issuer_profile_match' not in ast.unparse(n) and 'nonempty_actual_rows' not in ast.unparse(n)
        for n in ast.walk(A) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='check'),'NO_REQUIRED_POSITIVE')
    require(public['schema']=='economic_network.native_nvda_capture_witness/v1' and outer['schema']=='economic_network.native_nvda_owner_bootstrap/v1','PUBLIC_SCHEMAS')
    require(public['python_pid']==28310 and outer['python_pid']==28236 and outer['child_pid']==public['python_pid'],'PRINCIPAL_PIDS')
    require(type(public['python_pid']) is int and type(outer['python_pid']) is int and outer['child_started'] is True,'PID_TYPES_AND_START')
    require(public['wrapper_exit_code']==outer['child_exit_code']==outer['outer_exit_code']==0
        and all(type(v) is int for v in (public['wrapper_exit_code'],outer['child_exit_code'],outer['outer_exit_code'])),'ACTUAL_ZERO_EXITS')
    require(public['status']=='CAPTURE_STORE_READ_REPEAT_VERIFIED' and public['stage']=='SAME_ARTIFACT_REPEAT'
        and outer['status']=='OWNER_BOOTSTRAP_AND_ACTUAL_CHILD_RESULT_RECONCILED','ACTUAL_COMPLETED_STATUSES')
    require(outer['child_argv']==['/opt/homebrew/Caskroom/miniconda/base/bin/python3','-I','-B',str(ACTION_PATH)],'CHILD_ARGV')
    require(outer['action_script_sha256']==EXPECTED[str(ACTION_PATH)][1],'OUTER_ACTION_IDENTITY')
    require(outer['child_public_result']=={'path':str(PUBLIC_PATH),'byte_length':len(raw[str(PUBLIC_PATH)]),'sha256':digest(raw[str(PUBLIC_PATH)])},'OUTER_PUBLIC_FILE_IDENTITY')
    require(public['native_head']==public['final_native_head']==outer['head']==outer['native_head_after']==HEAD,'RECORDED_HEADS')
    require(public['reviewed_source']==SOURCE and public['protected_master_expected']==public['protected_master_observed']==PROTECTED,'RECORDED_SOURCE_REVISIONS')
    for flag in ('preflight_complete','workspace_clean_after','ignored_paths_absent_after','all_source_pins_unchanged_after'):
        require(public[flag] is True,'PUBLIC_POSTFLIGHT_'+flag)
    for flag in ('workspace_clean_after','ignored_paths_absent_after','helper_bytes_unchanged_after','owner_env_metadata_unchanged','owner_environment_parser_called_once'):
        require(outer[flag] is True,'OUTER_POSTFLIGHT_'+flag)
    owner_expected={'device':16777234,'inode':1035475373,'uid':501,'mode':384,'size':1225,
        'mtime_ns':'1786287063173714000','regular':True,'symlink':False}
    require(outer['owner_env_metadata_before']==outer['owner_env_metadata_after']==owner_expected,'OWNER_METADATA_UNCHANGED_REPORTED')
    require(outer['owner_primary']=='/Users/chriswong/Documents/Cluade/Macro Dashboard'
        and outer['owner_env_path']==outer['owner_primary']+'/.env','OWNER_PATH_REPORTED')
    require(outer['forwarded_owner_env_names']==['MASSIVE_API_KEY'],'FORWARDED_NAME_ONLY')
    require(outer['helper_sha256']=='20335fb0f694ca904e130a2b9016f379161c10946adb2e15dbfc5bdff3addd69','HELPER_SHA_REPORTED')
    for key in ('credential_values_published_or_written','credential_file_copied_or_modified','owner_file_search_performed','provider_accounts_substituted','shell_env_executed','git_mutation','source_registry_or_production_activation'):
        require(outer[key] is False,'OUTER_NO_EFFECT_'+key)
    require(public['query']==QUERY and public['D']==public['basis_date_metadata']=='2026-09-30'
        and public['K']=='2026-10-09T00:00:00Z' and public['upper_execution_date_filter'] is None,'ACTUAL_REQUEST')
    require(public['requested_vendor_token']=='NVDA' and public['producer_entrypoint']=='engine.close_pass.massive_close.retain_split_history','REQUESTED_VENDOR_AND_OWNER')
    require(public['boundaries']==BOUNDARIES and public['cohort_F'] is None and integer(public['cohort_selected_case_count'],'cohort')==0,'COHORT_AND_PRODUCT_HOLDS')
    for key in ('requested_case_count','producer_call_count','same_artifact_intake_repeat_call_count'):
        require(integer(public[key],key)==1,'ACTUAL_ONE_'+key)
    pins_node=ast_assignment(A,'PINS')
    require(isinstance(pins_node,ast.Call) and ast.unparse(pins_node.func)=='json.loads','PIN_LITERAL_SHAPE')
    source_pins=json.loads(ast.literal_eval(pins_node.args[0]),object_pairs_hook=pairs)
    require(source_pins==public['source_pins'] and len(source_pins)==18,'EIGHTEEN_EXACT_SOURCE_PINS')
    imports=public['imported_repository_sources_before_call']
    require(imports==public['imported_repository_sources_after_call'] and len(imports)==21
            and len({r['module'] for r in imports})==len({r['path'] for r in imports})==21,'TWENTY_ONE_IMPORTS_UNCHANGED')
    approved={}
    for row in source_pins+imports:
        rel=row['path'];p=pathlib.PurePosixPath(rel)
        require(not p.is_absolute() and '..' not in p.parts and '\\' not in rel,'SAFE_REPO_RELATIVE')
        integer(row['byte_length'],'source_size');sha_field(row['sha256'],'source_hash')
        if rel in approved:require(approved[rel]['byte_length']==row['byte_length'] and approved[rel]['sha256']==row['sha256'],'OVERLAPPING_SOURCE_IDENTITY')
        approved[rel]=row
        ALLOWED_READS.add(str(REPO/rel))
    require(len(approved)<=39,'BOUNDED_REPO_READ_SET')
    total_source_bytes=0
    for rel,row in sorted(approved.items()):
        b=secure_read(REPO/rel)
        total_source_bytes+=len(b)
        require(total_source_bytes<=4*1024*1024,'SOURCE_TOTAL_BUDGET')
        require(len(b)==row['byte_length'] and digest(b)==row['sha256'],'CURRENT_NATIVE_SOURCE_'+rel)
        if 'git_blob_sha1' in row:
            require(hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['git_blob_sha1'],'SOURCE_GIT_BLOB_FROM_BYTES_'+rel)
    acquisition=public['acquisition']
    exact_fields(acquisition,['acquisition_id','acquisition_sha256','artifact_byte_length','artifact_sha256','authority',
        'basis_eligible','failure_kind','page_count','pages','raw_body_retained','retained_row_count','status'],'acquisition_projection')
    require(re.fullmatch(r'[a-f0-9]{32}',acquisition['acquisition_id']) is not None,'ACQUISITION_ID_SHAPE')
    sha_field(acquisition['acquisition_sha256'],'acquisition_seal_not_recomputed')
    artifact_sha=sha_field(acquisition['artifact_sha256'],'artifact_digest_not_recomputed')
    artifact_bytes=integer(acquisition['artifact_byte_length'],'artifact_bytes',1)
    require(artifact_bytes==1534 and artifact_bytes<=1024*1024,'ARTIFACT_DECLARED_SIZE')
    pages=acquisition['pages'];n=integer(acquisition['retained_row_count'],'retained_rows')
    require(acquisition['status']=='complete' and acquisition['failure_kind'] is None,'COMPLETE_SOURCE_STATUS')
    require(n==1 and integer(acquisition['page_count'],'page_count')==len(pages)==1
        and integer(public['provider_request_attempts_recorded'],'recorded_requests')==len(pages),'ACTUAL_ROW_AND_PAGE_DENOMINATORS')
    require(public['provider_request_count_is_network_instrumented'] is False,'NOT_NETWORK_INSTRUMENTED')
    received=retained=body_bytes=0;clock_pages=[]
    for i,page in enumerate(pages):
        exact_fields(page,['page_index','cursor_sha256','request_started_utc_ns','response_completed_utc_ns','http_status',
            'observed_body_sha256','body_bytes_observed','body_complete','rows_received','rows_retained','outcome'],'page')
        require(integer(page['page_index'],'page_index')==i,'PAGE_INDEX_ORDER')
        require(page['cursor_sha256'] is None if i==0 else bool(re.fullmatch(r'[a-f0-9]{64}',page['cursor_sha256'])),'CURSOR_HASH_ONLY')
        require(integer(page['http_status'],'http_status')==200 and page['body_complete'] is True and page['outcome']=='ok','COMPLETE_OK_PAGE')
        rcv=integer(page['rows_received'],'rows_received');ret=integer(page['rows_retained'],'rows_retained')
        count=integer(page['body_bytes_observed'],'body_bytes')
        require(rcv==ret and count<=1024*1024,'PAGE_COUNT_BOUNDS')
        sha_field(page['observed_body_sha256'],'observed_body_not_read')
        received+=rcv;retained+=ret;body_bytes+=count
        begin=ns(page['request_started_utc_ns'],'page_begin');end=ns(page['response_completed_utc_ns'],'page_end')
        require(begin<=end,'PAGE_CLOCK_ORDER');clock_pages.append((begin,end))
    require(received==retained==n and body_bytes==298,'ROW_LEDGER_ARITHMETIC')
    row=public['row_summary']
    require(set(row)==set(initial_rs),'ROW_PROJECTION_CLOSED')
    for field in ('profile_id','vendor_execution_date_semantics','comparison_source_case_sha256','comparison_definition_sha256','public_review_limit'):
        require(row[field]==initial_rs[field],'ROW_FIXED_METADATA_'+field)
    require(row['comparison_source_case_sha256']==CASE_SHA and row['comparison_definition_sha256']==PROFILE_SHA,'PROFILE_REFERENCES_PRIOR_SOURCE_REVIEW')
    require(integer(row['retained_row_count'],'row_summary_count')==n and row['nonempty_actual_rows'] is True
        and row['all_retained_rows_requested_vendor_token'] is True,'PUBLIC_NONEMPTY_AND_TOKEN_FLAGS')
    require(row['candidate_comparison_status']=='EVALUATED_ON_RETAINED_ROWS' and row['candidate_issuer_profile_match'] is True,'PRINCIPAL_PROFILE_BOOLEAN_REPORTED_NOT_RECOMPUTED')
    require(row['vendor_execution_date_semantics']=='UNRECONCILED','VENDOR_DATE_SEMANTICS_HELD')
    owner=dict(public['owner_receipt'])
    canonical_owner_sha=sha_field(owner.pop('canonical_receipt_sha256'),'owner_canonical_sha')
    for k in ('owner_intake_started_utc_ns','owner_receipt_assembled_utc_ns'):owner[k]=ns(owner[k],k)
    exact_fields(owner,['artifact_sha256','authority','basis_eligible','capture_id','object_key','owner_intake_started_utc_ns',
        'owner_receipt_assembled_utc_ns','receipt_id','revision_id','schema','source_id','source_schema','store_id','vintage_id'],'owner_receipt')
    require(owner['schema']=='market_memory.source_artifact_receipt.massive_split_history.v1'
        and owner['source_id']==SOURCE_ID and owner['source_schema']==SOURCE_SCHEMA,'OWNER_SOURCE_FAMILY')
    require(owner['artifact_sha256']==artifact_sha,'OWNER_ARTIFACT_DIGEST_BINDING')
    owner_bytes=canonical(owner);require(digest(owner_bytes)==canonical_owner_sha and len(owner_bytes)==1301,'OWNER_CANONICAL_BYTES_AND_SHA')
    owner_core=dict(owner);owner_core['receipt_id']=''
    require(owner['receipt_id']=='mmsrc_'+digest(canonical(owner_core)),'OWNER_RECEIPT_CONTENT_ID')
    require(owner['capture_id']=='mmscapture_'+digest(canonical({'source_id':SOURCE_ID,'acquisition_id':acquisition['acquisition_id']})),'CAPTURE_ID_FROM_PUBLIC_METADATA')
    vintage='mmsvintage_'+digest(canonical({**QUERY,'basis_date':public['basis_date_metadata']}))
    require(owner['vintage_id']==vintage,'REQUEST_VINTAGE_ID_NOT_PUBLICATION_VINTAGE')
    require(owner['revision_id']=='mmsrevision_'+digest(canonical({'vintage_id':vintage,'artifact_sha256':artifact_sha})),'REVISION_ID_FROM_DIGEST_REFERENCE')
    require(re.fullmatch(r'mmsstore_[a-f0-9]{64}',owner['store_id']) is not None,'STORE_ID_SHAPE')
    read=dict(public['read_receipt'])
    for k in ('read_started_utc_ns','read_completed_utc_ns'):read[k]=ns(read[k],k)
    exact_fields(read,['artifact_bytes','artifact_sha256','basis_eligible','generation_id','read_completed_utc_ns',
        'read_receipt_sha256','read_started_utc_ns','reader_id','receipt_id','receipt_sha256','schema','store_id'],'read_receipt')
    read_seal=sha_field(read['read_receipt_sha256'],'read_seal')
    require(read_seal==digest(canonical({k:v for k,v in read.items() if k!='read_receipt_sha256'})),'READ_RECEIPT_SEAL_RECOMPUTED')
    require(read['schema']=='market_memory.source_read.massive_split_history.v1' and read['reader_id']=='CorpActions.SplitEvidenceReader','READER_OWNER')
    require(read['generation_id']==public['generation_id'] and read['receipt_id']==owner['receipt_id']
        and read['store_id']==owner['store_id'] and read['receipt_sha256']==canonical_owner_sha
        and read['artifact_sha256']==artifact_sha and integer(read['artifact_bytes'],'read_artifact_bytes')==artifact_bytes,'PINNED_READER_FULL_PUBLIC_BINDINGS')
    require(re.fullmatch(r'mmsgen_[a-f0-9]{64}',read['generation_id']) is not None,'GENERATION_ID_SHAPE')
    require(acquisition['authority']==owner['authority']==AUTHORITY
        and acquisition['basis_eligible'] is owner['basis_eligible'] is read['basis_eligible'] is False,'CONTEXT_ONLY_AUTHORITY_NO_PROMOTION')
    f=public['F'];start=ns(f['producer_started_utc_ns'],'producer_start');end=ns(f['producer_completed_utc_ns'],'producer_end')
    require(f['public_by_K']=='UNPROVED','K_PUBLIC_UNPROVED')
    clocks=[ns(outer['started_utc_ns'],'outer_start'),ns(public['started_utc_ns'],'action_start'),start]
    for pair in clock_pages:clocks.extend(pair)
    clocks += [end,owner['owner_intake_started_utc_ns'],owner['owner_receipt_assembled_utc_ns'],read['read_started_utc_ns'],
        read['read_completed_utc_ns'],ns(public['finished_utc_ns'],'action_sampled_finish'),ns(outer['finished_utc_ns'],'outer_sampled_finish')]
    require(all(a<=b for a,b in zip(clocks,clocks[1:])),'ALL_REPORTED_NATIVE_CLOCK_ORDER')
    cutoff_ns=int(datetime.datetime(2026,10,9,tzinfo=datetime.timezone.utc).timestamp())*10**9
    require(start>cutoff_ns,'ACTUAL_F_AFTER_K')
    store=public['final_store']
    require(public['initial_store']=={'exists':False,'files':[]} and public['store_after_intake']==store and store['exists'] is True,'FRESH_STORE_AND_EQUAL_POSTFLIGHT_INVENTORIES')
    files=store['files'];require(len(files)==8 and len({v['path'] for v in files})==8,'EIGHT_UNIQUE_STORE_METADATA_ENTRIES')
    total=0;mapping={}
    for item in files:
        exact_fields(item,['byte_length','mode','mtime_ns','path','sha256'],'store_file')
        p=pathlib.PurePosixPath(item['path'])
        require(not p.is_absolute() and '..' not in p.parts,'STORE_RELATIVE_METADATA_PATH')
        total+=integer(item['byte_length'],'store_file_size')
        sha_field(item['sha256'],'store_file_hash_not_payload_read');ns(item['mtime_ns'],'store_mtime')
        require(item['mode']=='0o600','STORE_PRIVATE_MODE_REPORTED')
        mapping[item['path']]=item
    require(total==integer(store['total_bytes'],'store_total')==6536,'STORE_TOTAL_ARITHMETIC')
    object_key='source_objects/'+artifact_sha[:2]+'/'+artifact_sha+'.json'
    require(owner['object_key']==object_key and mapping[object_key]['sha256']==artifact_sha
        and mapping[object_key]['byte_length']==artifact_bytes,'OBJECT_INVENTORY_DIGEST_REFERENCE')
    for prefix,id_key,tag in [('source_captures','capture_id','mmscapture_'),('source_receipts','receipt_id','mmsrc_')]:
        value=owner[id_key];path=prefix+'/'+value[len(tag):len(tag)+2]+'/'+value+'.json'
        require(mapping[path]['sha256']==canonical_owner_sha and mapping[path]['byte_length']==len(owner_bytes),'OWNER_COPY_INVENTORY_'+prefix)
    g=public['generation_id'];current_gen='source_generations/'+g[len('mmsgen_'):len('mmsgen_')+2]+'/'+g+'.json'
    require(current_gen in mapping and len([k for k in mapping if k.startswith('source_generations/')])==2
        and 'SOURCE_HEAD.json' in mapping and 'SOURCE_STORE.json' in mapping and '.writer.lock' in mapping,'GENERATION_STORE_STRUCTURE_METADATA')
    require(mapping['.writer.lock']['byte_length']==0 and mapping['.writer.lock']['sha256']==digest(b''),'EMPTY_LOCK_METADATA')
    require(public['store_root']==str(CACHE/'native-nvda-split-pro-004-001/sources-massive-split-history-v1'),'STORE_ROOT_RECORDED')
    require(public['repeat']=={'created':False,'producer_reacquisition':False,'same_acquisition_id':True,'same_artifact':True,
        'same_generation':True,'same_owner_receipt':True,'store_bytes_and_mtime_unchanged':True},'ACTUAL_REPEAT_PUBLIC_RECEIPT')
    validation_fields={'actual_clock_order_valid','artifact_object_bytes_equal','fresh_intake_created','pinned_generation_read_payload_equal',
        'read_receipt_hash_and_binding_valid','read_store_bytes_mtime_unchanged','returned_request_exact','same_artifact_repeat_idempotent','source_authority_preserved'}
    require(set(public['validation'])==validation_fields and all(v is True for v in public['validation'].values()),'NINE_ACTUAL_PRINCIPAL_VALIDATIONS')
    require(acquisition['raw_body_retained'] is False,'RAW_BODY_NOT_RETAINED')
    for key in ('raw_provider_body_published','secret_values_recorded','git_mutation','transport_or_clock_replacement'):
        require(public[key] is False,'NO_PRIVATE_OR_EXTERNAL_EFFECT_'+key)
    expected_outer_result={'status':public['status'],'stage':public['stage'],'producer_call_count':public['producer_call_count'],
        'provider_request_attempts_recorded':public['provider_request_attempts_recorded'],'source_status':acquisition['status'],
        'source_failure_kind':acquisition['failure_kind'],'retained_row_count':n,'F':f,
        'same_artifact_repeat_calls':public['same_artifact_intake_repeat_call_count'],'source_store_exists':store['exists'],'row_summary':row}
    require(outer['result']==expected_outer_result,'COMPLETE_OUTER_SUMMARY_BINDING')
    public_identity={'byte_length':len(raw[str(PUBLIC_PATH)]),'sha256':digest(raw[str(PUBLIC_PATH)])}
    expected_stdout={'status':public['status'],'stage':public['stage'],'wrapper_exit_code':public['wrapper_exit_code'],
        'producer_call_count':public['producer_call_count'],'provider_request_attempts_recorded':public['provider_request_attempts_recorded'],
        'source_acquisition_status':acquisition['status'],'retained_row_count':n,'public_result':str(PUBLIC_PATH),
        'public_identity':public_identity,'private_result_identity':public['private_result_identity'],'workspace_clean_after':public['workspace_clean_after']}
    stdout=(json.dumps(expected_stdout)+'\n').encode()
    require(outer['child_stdout_identity']=={'byte_length':len(stdout),'sha256':digest(stdout)},'EXPECTED_METADATA_ONLY_STDOUT_IDENTITY')
    require(outer['child_stderr_identity']=={'byte_length':0,'sha256':digest(b'')},'EMPTY_STDERR_IDENTITY')
    exact_fields(public['private_result_identity'],['byte_length','sha256'],'private_identity_only')
    integer(public['private_result_identity']['byte_length'],'private_result_declared_bytes',1)
    sha_field(public['private_result_identity']['sha256'],'private_result_not_read')
    # Read back only the permitted public/source inputs. Never traverse the source store.
    before_inputs=dict(inventory)
    for path,row0 in before_inputs.items():
        b=secure_read(path,remember=False);s=pathlib.Path(path).lstat()
        require(len(b)==row0['byte_length'] and digest(b)==row0['sha256'] and str(s.st_mtime_ns)==row0['mtime_ns']
            and s.st_ino==row0['inode'] and s.st_dev==row0['device'],'INPUT_BYTES_AND_METADATA_UNCHANGED_'+pathlib.Path(path).name)
    result.update({'status':'PASS_CURRENT_CAPTURE_CHAIN_PUBLIC_EVIDENCE','source_outcome':'COMPLETE_NONEMPTY_RESULT',
        'public_file_identity':public_identity,'outer_file_identity':{'byte_length':len(raw[str(OUTER_PATH)]),'sha256':digest(raw[str(OUTER_PATH)])},
        'principal_processes':{'parent_pid':28236,'child_pid':28310,'parent_exit':0,'child_exit':0,'runtime_seconds_from_previously_read_tool_receipt':'11.78'},
        'current_native_source_files_hashed':len(approved),'source_pins':18,'imported_sources':21,'source_total_bytes':total_source_bytes,
        'count_basis':{'requested_cases':1,'producer_calls':1,'recorded_pages':len(pages),'packet_level_instrumentation':False,
            'received_rows':received,'retained_rows':n,'observed_response_body_bytes':body_bytes,'same_artifact_intake_repeats':1,'cohort_cases':0},
        'independently_recomputed':{'canonical_owner_receipt_bytes':len(owner_bytes),'canonical_owner_receipt_sha256':canonical_owner_sha,
            'owner_receipt_id':owner['receipt_id'],'capture_id':owner['capture_id'],'vintage_id':owner['vintage_id'],'revision_id':owner['revision_id'],
            'read_receipt_sha256':read_seal,'metadata_only_child_stdout_sha256':digest(stdout)},
        'artifact_reference_only':{'byte_length':artifact_bytes,'sha256':artifact_sha,'acquisition_seal':acquisition['acquisition_sha256'],
            'independently_reconstructed_or_read':False},
        'principal_private_comparison':{'status':row['candidate_comparison_status'],'candidate_profile_match_reported':row['candidate_issuer_profile_match'],
            'independently_recomputed_from_rows':False,'vendor_date_semantics':'UNRECONCILED'},
        'store_metadata':{'file_count':8,'total_bytes':total,'before_after_inventory_equal':True,'actual_store_payloads_read_by_reviewer':False},
        'source_F':{'started_utc_ns':str(start),'completed_utc_ns':str(end),'started_utc':utc_text(start),'completed_utc':utc_text(end),
            'after_K':True,'public_by_K':'UNPROVED'},
        'input_bytes_and_metadata_unchanged':True,'required_corrections':[]})
    exit_code=0
except BaseException as exc:
    result.update({'status':'FAIL_OR_INCOMPLETE_PUBLIC_REVIEW','error_type':type(exc).__name__,
                   'fixed_diagnostic':str(exc) if isinstance(exc,RuntimeError) else 'UNEXPECTED_STDLIB_OR_IO_ERROR',
                   'required_corrections':['Preserve this original verification result; do not rerun or substitute after an unknown effect. Principal adjudication required.']})
finally:
    result['reviewer_finished_utc_ns']=str(time.time_ns())
    result['checks_completed']=len(checks)
    result['checks']=list(checks)
    result['effects']={'native_verifier_process_count':1,'native_verifier_pid':os.getpid(),'provider_calls':0,'api_calls':0,'git_commands':0,
        'credential_or_environment_file_reads':0,'private_result_reads':0,'source_store_payload_reads':0,'application_imports':0,
        'application_tests':0,'source_or_registry_mutations':0,'prior_capture_replays':0,'writes':'Only the new independent review directory',
        'earlier_pre_execution_review_native_counters_remain_zero':True}
    result['launch_command_limit']='The principal launch tool archives and corrected launcher were read in the preceding local source/public phase; this native verifier re-reads actual action/bootstrap bytes and actual public/outer files, not the original shell payload. Exact launch-command execution is principal tool-receipt evidence, not newly observed here.'
    result['public_only_limit']='No nonempty acquisition artifact, raw HTTP body, private result envelope or store payload was read/reconstructed. Owner/read seals and content IDs use public fields; row/payload equality and optional issuer-profile arithmetic are principal-executed checks under exact reviewed source.'
    outputs=[]
    if raw:
        (OUT/'inputs').mkdir(mode=0o700)
        for source,name in [(PUBLIC_PATH,'PUBLIC_RESULT.json'),(OUTER_PATH,'OUTER_RESULT.json'),(ACTION_PATH,'ACTION.py.txt'),(BOOTSTRAP_PATH,'BOOTSTRAP.py.txt')]:
            if str(source) in raw:outputs.append(write_new('inputs/'+name,raw[str(source)]))
    outputs.append(write_new('PRIOR_EVIDENCE_AND_CARRIER_CHANGE.json',pretty(PREVIOUSLY_READ)))
    outputs.append(write_new('INPUT_INVENTORY.json',pretty({'files':list(inventory.values()),'file_count':len(inventory),'source_store_payloads_included':False})))
    receipt_identity=write_new('VERIFICATION_RESULT.json',pretty(result));outputs.append(receipt_identity)
    if exit_code==0:
        report=(
            '# Independent actual NVDA public-result review\n\n'
            '**PASS_CURRENT_CAPTURE_CHAIN_PUBLIC_EVIDENCE. Source outcome: COMPLETE_NONEMPTY_RESULT.**\n\n'
            'The actual principal execution returned a complete HTTP 200 split-source observation with one retained row. Its source intake, generation-pinned read and same-artifact repeat passed the reviewed native checks. This independent review verifies public identities, canonical receipt seals, counts, clocks and current source bytes. It does not independently read the provider row or recompute its event predicate.\n\n'
            '## Actual identity and process chain\n\n'
            f"The native public file is {len(raw[str(PUBLIC_PATH)]):,} bytes, SHA-256 {digest(raw[str(PUBLIC_PATH)])}. The outer file is {len(raw[str(OUTER_PATH)]):,} bytes, SHA-256 {digest(raw[str(OUTER_PATH)])}. Both were read directly at their known native paths and matched the prior complete exported-file identities.\n\n"
            'Principal parent PID 28236 and child PID 28310 both exited 0; the previously read completion tool receipt reports 11.78 seconds. Actual outer/public PIDs and result identities agree. The source action is 19,659 bytes, SHA-256 264535ec562043a18e4bc75c92fbbe9b5cba12428422b2a9677e89c0f769f699. The actual bootstrap is 29,119 bytes, SHA-256 92298f53a839bea81b16556ff71277f461d44f732df88a044a990785c620f0a3, and embeds exactly those action bytes.\n\n'
            'The corrected launcher identity c1745bbce8934986ad0a218818b2f435121ed405d48a7ed1200a92272337e221 and the launch-command/start/completion archives were read in the preceding local phase. Their exact identities and observed PID/exit metadata are retained in PRIOR_EVIDENCE_AND_CARRIER_CHANGE.json. This native verifier does not reread or claim to newly validate the entire original shell payload. The principal tool-receipt binding and earlier complete source/embedding review supply that part of the chain.\n\n'
            f"All 18 source pins and 21 before/after repository import identities agree. This verifier directly read and hashed the {len(approved)} unique permitted current repository paths ({total_source_bytes:,} bytes), recomputed Git blob identities for pinned paths from their bytes, and checked every input's bytes/inode/mtime unchanged at the end. No Git command or application import occurred. Recorded executing head remains {HEAD}; this is not an independent live Git-HEAD or release-policy check.\n\n"
            '## Request, counts and optional profile\n\n'
            'The one actual call was retain_split_history(NVDA, 2024-06-01, 2026-09-30), through the unchanged existing producer. The query has only execution_date.gte=2024-06-01, ascending execution-date sort and page limit 1000. Basis date 2026-09-30 is metadata; no upper HTTP filter is added.\n\n'
            '| Denominator | Actual count |\n|---|---:|\n| Requested convenience cases | 1 |\n| Producer calls | 1 |\n| Recorded provider page attempts | 1 |\n| Received / retained rows | 1 / 1 |\n| Observed response-body bytes | 298 |\n| Same-artifact intake repeats | 1 |\n| Selected WP02 cohort cases | 0 |\n\n'
            'The complete page has HTTP 200, outcome ok, complete framing and matching received/retained counts. Page-ledger attempts are not a separately instrumented network packet count. Raw HTTP body bytes were not retained by the producer and were not read by this reviewer. Its observed-body digest remains a reference to bytes not available in this packet.\n\n'
            'The actual principal row summary reports nonempty=true, exact requested-vendor-token binding=true and candidate profile=true. The adopted profile is the predeclared NVDA/June-2024/forward/old=1/new=10 comparison, tied to definition SHA-256 7cd0ee632314baf4ac57489dbd58e5fe26675323a6840ef5bb6740885111a25b and issuer-case SHA-256 c0fdd60f75ae4a741d77f452c6859938b75825c9e6fba9384942427f511ae5b9. Those issuer/profile bytes were checked in the prior source-only review; this native phase checks their exact references and unchanged actual action. The provider row is private. The boolean is principal-executed, not independently recomputed here. It shows candidate consistency under that narrow profile; vendor date semantics remain UNRECONCILED. No exact provider row ID, execution date, ratio token or payload is disclosed.\n\n'
            '## Independently reproducible public seals and custody limits\n\n'
            f"The owner receipt was canonicalized after converting its two decimal-string native nanoseconds back to exact integers. Its {len(owner_bytes):,} bytes hash to {canonical_owner_sha}; its receipt content ID, capture ID, request-derived vintage ID and digest-derived revision ID were independently reproduced. The read-receipt content seal was independently reproduced as {read_seal}. Its store/generation/receipt/artifact references and lengths agree with the owner and public source projection.\n\n"
            f"The artifact reference is {artifact_bytes:,} bytes, SHA-256 {artifact_sha}. This digest appears consistently in the actual source projection, owner/read receipts and content-addressed object inventory. The reviewer did not read or reconstruct the nonempty artifact, its acquisition seal, the complete private result envelope or store payloads. No empty-artifact reconstruction or old MU verifier was used. Hash consistency is not a signature authenticating provider truth, rights or public vintage.\n\n"
            'The reported fresh store has eight unique mode-0600 files totaling 6,536 bytes. The complete public inventory after intake equals the final inventory, including hashes, lengths, modes and nanosecond mtimes. Owner receipt/capture copies match the independently canonicalized receipt; the artifact and generation references resolve within the reported inventory. The unchanged kernel has SOURCE_HEAD metadata, while the actual reader uses the exact returned generation. This reviewer did not independently traverse that private store.\n\n'
            'The exact reviewed action compares complete actual stored/read artifacts and owner receipts, performs byte/hash/clock checks, then calls intake with exactly the same acquired artifact. The actual repeat reports created=false and the same artifact, receipt, acquisition and generation with unchanged observed store bytes/mtimes. These private comparisons are principal execution evidence. The expected metadata-only child stdout was independently regenerated and its digest matches the outer receipt; the outer reports empty stderr.\n\n'
            '## Time, authority and admissibility\n\n'
            f"Actual source F starts {utc_text(start)} ({start} ns) and ends {utc_text(end)} ({end} ns). The complete producer/page/owner/read/driver clock order is consistent using integer nanoseconds. F is after K=2026-10-09T00:00:00Z. Reported finished timestamps are sampling points before later postflight/export, not exact process-exit or vendor-publication timestamps. Owner receipt assembly likewise is not durable publication time.\n\n"
            'Source, owner and reader basis_eligible remain false. Context-only is intentionally true, with display/context authority, zero proposal weight and every inherited may_* capability false. K-public vintage stays UNPROVED; Graph1 and cohort F are null; cohort count is zero. Canonical issuer/class/shares, D-price/currency, global population/relative-cap and downstream admission remain withheld. No registry modification, rights change, production activation, trading or predictive promotion follows from this result.\n\n'
            '## Carrier change, effects and preservation\n\n'
            'The scratch executor stalled during input-manifest preparation before any meaningful verification ran. Functions cell 208 was terminated only as an orchestration cell at the principal request. Its possible scratch manifest effect remains unobserved; it was not replayed. The principal then explicitly authorized this separate native standard-library public review and its new review directory. Earlier pre-execution reviews retain their zero native counters.\n\n'
            f"This review is one native verifier process, PID {os.getpid()}, with {result['checks_completed']} completed public/source assertions before final evidence writes. It made zero provider/API calls, Git commands, credential/environment-file reads, private-result/store-payload reads, application imports/tests, original edits or source/registry mutations. The actual verifier used a restrictive file/network/process audit hook and wrote only the new review directory. It is not a hostile-host isolation proof. Actual verifier terminal exit is to be reconciled from its independent RDC process completion; the result file alone is not an exit receipt.\n\n"
            'All directly read inputs remained byte/inode/mtime-identical over this audit. Complete code, public-only input copies, inventories, results and this report are retained for principal publication. The raw principal start/completion/launch archives and earlier frozen reviews remain separate unchanged evidence. No follow-on acquisition or retry is requested by this review.\n\n'
            '**STOP: bounded actual public-only review complete; no source fact or predictive promotion.**\n'
        )
    else:
        report='# Independent actual NVDA public-result review\n\n**FAIL_OR_INCOMPLETE_PUBLIC_REVIEW.**\n\nThe original single native verification reached '+str(len(checks))+' checks and then stopped with '+result.get('error_type','unknown')+' / '+result.get('fixed_diagnostic','unknown')+'. Preserve this result and reconcile the actual native process. No provider, application or Git operation was part of the verifier. It does not certify the capture chain.\n\n'
    report_identity=write_new('REVIEW.md',report.encode('utf-8'));outputs.append(report_identity)
    own=secure_read(pathlib.Path(__file__),remember=False)
    outputs.append({'path':str(pathlib.Path(__file__)),'byte_length':len(own),'sha256':digest(own)})
    manifest={'schema':'economic_network.native_nvda_independent_review_manifest/v1','status':result['status'],'self_excluded':True,
        'reviewer_pid':os.getpid(),'files':[{'path':pathlib.Path(v['path']).relative_to(OUT).as_posix(),'byte_length':v['byte_length'],'sha256':v['sha256']} for v in outputs],
        'public_or_source_only':True,'private_provider_rows_included':False,'raw_provider_body_included':False}
    manifest_identity=write_new('MANIFEST.json',pretty(manifest))
    print(json.dumps({'stage':'INDEPENDENT_PUBLIC_REVIEW_COMPLETE','status':result['status'],'pid':os.getpid(),'exit_code':exit_code,
        'checks_completed':result['checks_completed'],'review_root':str(OUT),'verification':receipt_identity,'report':report_identity,
        'manifest':manifest_identity,'verifier':outputs[-1],'native_process_count':1,'provider_calls':0,'application_imports':0,
        'reported_source_rows':result.get('count_basis',{}).get('retained_rows'),'private_artifact_reconstructed':False}),flush=True)
    print(json.dumps({'stage':'INDEPENDENT_PUBLIC_REVIEW_FULL_REPORT','report':report},ensure_ascii=False),flush=True)
sys.exit(exit_code)
