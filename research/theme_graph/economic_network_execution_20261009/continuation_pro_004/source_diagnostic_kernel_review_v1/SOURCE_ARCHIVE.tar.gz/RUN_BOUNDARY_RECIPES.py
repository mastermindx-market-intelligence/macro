"""Independent reachable byte-API recipes and controls; stdlib only.

This builds artificial premises locally. No author fixture/helper is imported.
"""
import copy
import datetime
from fractions import Fraction
import gzip
import hashlib
import importlib.util
import json
import math
import os
import sys
import RUN_FROZEN_VECTORS as review


def load_case(name='V01_COMPLETE_MODEL'):
    return json.loads(gzip.decompress((review.VECTORS / 'wire' / (name + '.request.gz')).read_bytes()))


def put_source(request, sid, text):
    raw = text.encode('utf-8')
    row = {'source_id': sid, 'content': text, 'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw)}
    previous = next((i for i, item in enumerate(request['sources']) if item['source_id'] == sid), None)
    if previous is None:
        request['sources'].append(row)
    else:
        request['sources'][previous] = row
    return {'source_id': sid, 'start': 0, 'end': len(raw)}


def token(request, value):
    return put_source(request, 'REVIEW_TOKEN:' + hashlib.sha256(value.encode()).hexdigest(), value)


def rebind_history(request):
    h = request['history']
    for field, key in [('anchor_members', 'anchor_source_id'), ('target_members', 'target_source_id'), ('events', 'events_source_id')]:
        put_source(request, h[key], review.canonical(h[field]).decode('utf-8'))
    h['expected_anchor_member_ids'] = [r['member_id'] for r in h['anchor_members']]
    h['expected_target_member_ids'] = [r['member_id'] for r in h['target_members']]
    h['declared_event_ids'] = [r['event_id'] for r in h['events']]
    counts = request['counts']
    for field in ('source_declared_total', 'exhaustive_total', 'raw_record_count', 'parsed_record_count', 'anchor_count'):
        counts[field] = len(h['anchor_members'])
    counts['resulting_d_member_count'] = len(h['target_members'])
    counts['identity_resolved_issuer_count'] = len(request['records'])
    counts['duplicates_resolved_count'] = len(h['target_members']) - len(request['records'])
    for kind in h['covered_event_kinds']:
        counts['event_' + kind] = sum(e['kind'] == kind for e in h['events'])


def rename(value, old, new):
    if isinstance(value, str):
        return value.replace(old, new)
    if isinstance(value, list):
        return [rename(v, old, new) for v in value]
    if isinstance(value, dict):
        return {k: rename(v, old, new) for k, v in value.items()}
    return value


def parser_metrics(raw):
    # Independently count the frozen lexical convention; no module helper used.
    text = raw.decode('utf-8')
    depth = maximum = tokens = 0
    inside = escaped = False
    for char in text:
        if inside:
            if escaped:
                escaped = False
            elif char == '\\':
                escaped = True
            elif char == '"':
                inside = False
        elif char == '"':
            inside = True
            tokens += 1
        elif char in '[{':
            depth += 1
            maximum = max(maximum, depth)
            tokens += 1
        elif char in ']}':
            depth -= 1
        elif char in ',:':
            tokens += 1
    return {'lexical_tokens': tokens, 'maximum_depth': maximum, 'byte_length': len(raw)}


def huge_bridge(request, count):
    record = request['records'][0]
    template = copy.deepcopy(record['classes'][0])
    classes = []
    factors = [10**47 + 1, 10**47 + 3]
    assert math.gcd(*factors) == 1
    for index in range(count):
        cls = copy.deepcopy(template)
        cid = 'HUGE_CLASS_' + str(index)
        cls['class_id'] = cid
        cls['d_basis'] = 'UNIT_32'
        cls['counter']['security_id'] += ':' + cid
        share = cls['shares']['assertions'][0]
        share['assertion_id'] += ':' + cid
        share['unit_basis'] = 'UNIT_32'
        price = cls['price']['assertions'][0]
        price['assertion_id'] += ':' + cid
        price['coordinate'] = '2026-09-28'
        price['unit_basis'] = 'UNIT_0'
        price['value'] = '1'
        price['evidence'] = token(request, '1')
        cls['calendar'] = ['2026-09-28', '2026-09-29', '2026-09-30']
        cls['actions'] = []
        for sequence in range(32):
            eid = cid + ':SPLIT:' + str(sequence)
            cls['actions'].append({'event_id': eid, 'effective_date': '2026-09-29', 'sequence': sequence,
                'kind': 'SPLIT', 'public_upper': '2026-10-01T00:00:00Z', 'value': str(factors[index]),
                'before_basis': 'UNIT_' + str(sequence), 'after_basis': 'UNIT_' + str(sequence + 1),
                'evidence': token(request, str(factors[index])), 'zero_evidence': None})
        cls['declared_event_ids'] = [a['event_id'] for a in cls['actions']]
        cls['price_bridge_event_ids'] = list(cls['declared_event_ids'])
        cls['share_bridge_event_ids'] = []
        classes.append(cls)
    record['classes'] = classes
    record['class_ids'] = [c['class_id'] for c in classes]
    values = [Fraction(100000000, q**32) for q in factors[:count]]
    total = sum(values, Fraction(0))
    return {'individual_denominator_bits': [v.denominator.bit_length() for v in values],
            'sum_denominator_bits': total.denominator.bit_length(),
            'sum_numerator_bits': total.numerator.bit_length(),
            'independent_exact_arithmetic': 'Fraction(100000000, (10**47+1)**32) plus optionally Fraction(100000000, (10**47+3)**32)'}


def main():
    pins = review.verify_pins()
    out = review.OUT / 'boundary_recipes'
    out.mkdir(exist_ok=False)
    spec = importlib.util.spec_from_file_location('boundary_review_wp02', review.ROOT / review.PINS['module'][0])
    module = importlib.util.module_from_spec(spec)
    sys.addaudithook(review.audit)
    review.ACTIVE = True
    try:
        spec.loader.exec_module(module)
    finally:
        review.ACTIVE = False
    cases = []
    def add(case_id, request=None, raw=None, expected_code=None, expectation=None, meta=None, **kwargs):
        if raw is None:
            raw = review.canonical(request)
        cases.append({'case_id': case_id, 'raw': raw, 'expected_code': expected_code,
                      'expectation': expectation, 'meta': meta or {}, **kwargs})

    baseline = review.canonical(load_case())
    add('REQUEST_NOT_BYTES', raw=baseline, argument_type='str', expected_code='BYTES_REQUIRED')
    add('POLICY_RAW_NEWLINE', raw=baseline, policy_suffix=b'\n', expected_code='POLICY_RAW_BINDING_MISMATCH')
    add('ADOPTION_RAW_NEWLINE', raw=baseline, adoption_suffix=b'\n', expected_code='ADOPTION_RAW_BINDING_MISMATCH')

    x = load_case()
    first = copy.deepcopy(x['records'][0])
    member = copy.deepcopy(x['history']['target_members'][0])
    issuer = first['issuer_id']
    for index in range(345):
        new_id = 'INDEPENDENT_EXTRA:' + str(index)
        x['records'].append(rename(first, issuer, new_id))
        new_member = rename(member, issuer, new_id)
        x['history']['anchor_members'].append(copy.deepcopy(new_member))
        x['history']['target_members'].append(copy.deepcopy(new_member))
    rebind_history(x)
    raw = review.canonical(x)
    assert len(x['records']) == 513 and len(raw) <= 2097152
    add('RECORDS_513', raw=raw, expected_code='ARRAY_SHAPE_OR_LIMIT', meta=parser_metrics(raw))

    for depth in (24, 25):
        x = load_case()
        nested = None
        for _ in range(depth - 2):
            nested = [nested]
        x['counts']['raw_record_count'] = nested
        raw = review.canonical(x)
        assert parser_metrics(raw)['maximum_depth'] == depth
        add('DEPTH_' + str(depth), raw=raw,
            expected_code='SUPPLIED_COUNT_INVALID_COUNT' if depth == 24 else 'JSON_DEPTH_LIMIT',
            meta=parser_metrics(raw), expectation='At-boundary parser continuation is evidenced only by the later typed count hold; this is not a valid count input.')
    for target in (160000, 160001):
        x = load_case()
        n = target - parser_metrics(review.canonical(x))['lexical_tokens']
        x['counts']['raw_record_count'] = [None] * n
        raw = review.canonical(x)
        assert parser_metrics(raw)['lexical_tokens'] == target and len(raw) <= 2097152
        add('TOKENS_' + str(target), raw=raw,
            expected_code='SUPPLIED_COUNT_INVALID_COUNT' if target == 160000 else 'JSON_NODE_LIMIT',
            meta=parser_metrics(raw), expectation='At-boundary parser continuation is evidenced only by the later typed count hold; this is not a valid count input.')

    for classes in (1, 2):
        x = load_case()
        arithmetic = huge_bridge(x, classes)
        add('DERIVED_ARITHMETIC_' + str(classes) + '_CLASSES', x,
            expected_code=None if classes == 1 else 'EXACT_ARITHMETIC_BUDGET', meta=arithmetic,
            expectation='One 4997-bit denominator is supported; summing two coprime denominators exceeds8192 bits and must hold whole cap.')

    x = load_case()
    cls = x['records'][0]['classes'][0]
    cls['price']['assertions'][0]['assertion_id'] = cls['shares']['assertions'][0]['assertion_id']
    add('GLOBAL_ASSERTION_ID_REUSE', x, expected_code='ASSERTION_ID_REUSED_ACROSS_COMPONENTS')

    for kind in ('CONVERSION', 'TRANSFER'):
        x = load_case()
        h = x['history']
        h.update(kind='RECONSTRUCTION', anchor_date='2026-09-29', coverage_start='2026-09-29')
        h['anchor_members'][0]['instrument'] = 'DEPOSITARY_RECEIPT'
        h['events'] = [{'event_id': 'INDEPENDENT:CONVERSION', 'effective_date': '2026-09-30', 'sequence': 0,
                        'kind': kind, 'public_upper': '2026-10-01T00:00:00Z',
                        'before': [copy.deepcopy(h['anchor_members'][0])],
                        'after': [copy.deepcopy(h['target_members'][0])]}]
        rebind_history(x)
        add('EVENT_' + kind, x, expected_code=None if kind == 'CONVERSION' else 'EVENT_KIND_CHANGED_FIELDS_MISMATCH')

    x = load_case('V10_POST_K_REVISION')
    bundle = x['records'][0]['classes'][0]['shares']
    bundle['assertions'][1]['public_upper'] = bundle['relations'][0]['public_upper'] = '2026-10-08T00:00:00Z'
    add('EXPLICIT_PRE_K_SUPERSESSION', x, expectation='Supported same-publisher correction gives modeled cap2100000000; all assertions and link retained.')
    x = copy.deepcopy(x)
    x['records'][0]['classes'][0]['shares']['relations'] = []
    add('SAME_PUBLISHER_WITHOUT_LINK', x, expected_code='CAP_COMPONENT_CONFLICT')

    x = load_case('V09_MEASUREMENT_ORDER')
    bundle = x['records'][0]['classes'][0]['shares']
    old = bundle['assertions'][0]
    rel = {'relation_id': 'INDEPENDENT:LATEST_RETRACTION', 'kind': 'RETRACTS', 'publisher_id': old['publisher_id'],
           'new_id': None, 'old_id': old['assertion_id'], 'fact_coordinate': old['coordinate'],
           'unit_basis': old['unit_basis'], 'public_upper': '2026-10-08T00:00:00Z',
           'resolution_owner_id': 'UNTRUSTED_TEST_LABEL'}
    rel['evidence'] = token(x, 'RETRACTS::' + old['assertion_id'])
    bundle['relations'] = [rel]
    add('LATEST_RETRACTED_NO_OLDER_FALLBACK', x, expected_code='CAP_COMPONENT_UNAVAILABLE')

    x = load_case()
    x['records'].reverse()
    x['history']['anchor_members'].reverse()
    x['history']['target_members'].reverse()
    x['history']['partitions'].reverse()
    x['history']['declared_partition_ids'].reverse()
    rebind_history(x)
    x['sources'].reverse()
    add('PERMUTED_COMPLETE_MODEL', x, expectation='Same selected ID ordering, exact pools, full INT flow and quota audit as V01; distinct original request bindings.')

    for counter in ('ABSENT', 'UNKNOWN', 'NOT_PUBLISHED', 'VALID_ZERO'):
        x = load_case()
        if counter == 'ABSENT':
            x['counts'].pop('source_declared_total')
        elif counter == 'UNKNOWN':
            x['counts']['source_declared_total'] = None
        elif counter == 'NOT_PUBLISHED':
            x['counts']['source_declared_total'] = counter
        else:
            x['counts']['source_declared_total'] = 0
        expected = {'ABSENT':'SUPPLIED_COUNT_MISSING','UNKNOWN':'SUPPLIED_COUNT_UNKNOWN','NOT_PUBLISHED':None,'VALID_ZERO':'SUPPLIED_COUNT_RECONCILIATION_MISMATCH'}[counter]
        add('COUNT_SOURCE_' + counter, x, expected_code=expected)

    x = load_case()
    x['records'][0]['classes'][0]['shares']['assertions'][0]['coordinate'] = '2026-03-30'
    add('SHARES_184_DAYS_OLD', x, expected_code='CAP_COMPONENT_UNAVAILABLE')
    x = load_case()
    x['records'][0]['classes'][0]['price']['assertions'][0]['coordinate'] = '2026-09-19'
    add('PRICE_11_DAYS_OLD', x, expected_code='CAP_COMPONENT_UNAVAILABLE')
    x = load_case()
    cls = x['records'][0]['classes'][0]
    cls['price']['assertions'][0]['coordinate'] = '2026-09-24'
    cls['calendar'] = ['2026-09-' + str(d) for d in range(24, 31)]
    add('PRICE_6_SUPPLIED_SESSIONS_OLD', x, expected_code='PRICE_TOO_OLD')

    x = load_case()
    x['claims']['admission_adapter'] = 'FAKE_SOURCE_AUTHORITY'
    add('CLOSED_CLAIMS_REJECTS_ADAPTER', x, expected_code='CLOSED_OBJECT_SHAPE')

    # These typed nested-shape probes should never escape as native exceptions.
    x = load_case()
    x['records'][0]['primary_groups'] = {}
    add('WRONG_PRIMARY_GROUP_CONTAINER', x, expected_code='ARRAY_SHAPE_OR_LIMIT')
    x = load_case()
    x['history']['events'] = None
    add('WRONG_EVENT_CONTAINER', x, expected_code='ARRAY_SHAPE_OR_LIMIT')

    results = []
    for case in cases:
        cid, raw = case['case_id'], case['raw']
        request_raw_path = cid + '.request.json.gz'
        (out / request_raw_path).write_bytes(gzip.compress(raw, mtime=0))
        kwargs = {'policy_bytes': pins['policy'] + case.get('policy_suffix', b''),
                  'adoption_bytes': pins['adoption'] + case.get('adoption_suffix', b'')}
        argument = raw.decode('utf-8') if case.get('argument_type') == 'str' else raw
        exception = None
        review.ACTIVE = True
        try:
            result = module.diagnose(argument, **kwargs)
        except Exception as exc:
            exception = {'type': type(exc).__name__, 'message': str(exc)[:2000]}
            result = {'unexpected_exception': exception}
        finally:
            review.ACTIVE = False
        result_raw = review.canonical(result)
        (out / (cid + '.result.json.gz')).write_bytes(gzip.compress(result_raw, mtime=0))
        observed = review.summarize(result, raw) if exception is None else None
        codes = [r['code'] for r in observed['holds']] if observed else []
        code_met = case['expected_code'] is None or case['expected_code'] in codes
        row = {'case_id': cid, 'request': review.binding(raw), 'request_argument_type': type(argument).__name__,
            'policy': review.binding(kwargs['policy_bytes']), 'adoption': review.binding(kwargs['adoption_bytes']),
            'result': review.binding(result_raw), 'exception': exception, 'observed': observed,
            'expected_code': case['expected_code'], 'expected_code_observed': code_met,
            'expectation': case['expectation'], 'independent_metadata': case['meta']}
        results.append(row)
        print(json.dumps({'case_id': cid, 'expected_code': case['expected_code'], 'code_met': code_met,
            'codes': codes, 'model_state': (observed or {}).get('model_state'), 'exception': exception}, sort_keys=True), flush=True)
    review.verify_pins()
    receipt = {'schema':'independent.wp02.boundary_recipe_execution/v1', 'pid':os.getpid(),
        'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'api_call_count':len(results),
        'module':dict(review.binding(pins['module']),path=review.PINS['module'][0]),
        'cases':results, 'effect_guard_events':review.EVENTS, 'source_pins_unchanged_after':True,
        'private_mathematical_or_parser_helper_calls':0,
        'output_8MiB_public_reachability':'NOT_EXERCISED; source branch inspection does not count as execution'}
    (review.OUT / 'BOUNDARY_RECIPE_EXECUTION.json').write_bytes(json.dumps(receipt,ensure_ascii=False,sort_keys=True,indent=2).encode()+b'\n')
    print(json.dumps({'pid':os.getpid(),'api_calls':len(results),'unexpected_exceptions':sum(r['exception'] is not None for r in results),
        'expected_code_mismatches':sum(not r['expected_code_observed'] for r in results),'effect_guard_events':len(review.EVENTS)},sort_keys=True),flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
