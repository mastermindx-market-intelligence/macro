"""Independent checks of saved public outputs, with no kernel import/API call.

Residual infeasibility is checked by supplied-capacity cuts and final feasible
witnesses, not by a second implementation of the selector or another729 run.
"""
from collections import Counter
from fractions import Fraction
import gzip
import hashlib
import json
import os
import datetime
import RUN_FROZEN_VECTORS as review

OUT = review.OUT
CHECKS = []
ACTIVITIES = ('SEMICONDUCTOR_CLOUD','INDUSTRIALS','CONSUMER','ENERGY_MATERIALS','FINANCIALS','HEALTHCARE')
STRATA = ('US','CN_MAINLAND','HK','CA','INT')
QUOTA = {'L':2,'M':1,'S':1}


def read_result(folder, name):
    return json.loads(gzip.decompress((OUT/folder/name).read_bytes()))


def frozen(name):
    return read_result('frozen_outputs',name+'.result.json.gz')


def request(name):
    return json.loads(gzip.decompress((review.VECTORS/'wire'/(name+'.request.gz')).read_bytes()))


def check(name, condition, detail=None):
    CHECKS.append({'check':name,'pass':bool(condition),'detail':detail})
    assert condition,name


def codes(result):
    return {r['code'] for r in result['holds']} - review.BASE_HOLDS


def first_cap(result, case='V01_COMPLETE_MODEL'):
    rid = request(case)['records'][0]['record_id']
    rows = (result.get('synthetic') or {}).get('modeled_cap_receipts',[])
    row = next((r for r in rows if r['record_id']==rid),None)
    return row


def rational(value):
    return None if value is None else Fraction(int(value['numerator']),int(value['denominator']))


def priority(issuer):
    parts = [s.encode() for s in ('issuer-priority','GMI-WP02-20261009-v1',issuer)]
    return hashlib.sha256(b''.join(len(s).to_bytes(8,'big')+s for s in parts)).digest(),issuer.encode()


def verify_quota(result,name):
    s=result['synthetic']['selection']; selected=s['selected_issuer_ids']
    by_id={r['issuer_id']:r for r in result['synthetic']['modeled_candidates']}
    rows=[by_id[i] for i in selected]
    strata=Counter(r['country'] if r['country'] in STRATA[:4] else 'INT' for r in rows)
    cells=Counter(((r['country'] if r['country'] in STRATA[:4] else 'INT'),r['activity'],r['band']) for r in rows)
    check(name+':full_independent_quota',len(selected)==len(set(selected))==120 and strata=={s:24 for s in STRATA}
          and cells=={(s,a,b):q for s in STRATA for a in ACTIVITIES for b,q in QUOTA.items()}
          and Counter(r['country'] for r in rows if r['country'] in ('UK','JP','EU'))=={'UK':8,'JP':8,'EU':8})
    check(name+':exact_priority_order',selected==sorted(selected,key=priority))
    check(name+':absolute_tags_compulsory',all(r['absolute_band'] in ('MICRO','S_ABS','M_ABS','L_ABS') for r in rows))


def verify_flow_certificate(flow,candidates,country,cell,name):
    matrix=Counter((r['country'],r['cell']) for r in candidates)
    check(name+':exact_demands',flow['country_demands']==country and flow['cell_demands']==cell
          and flow['target']==sum(country.values())==sum(cell.values()))
    check(name+':actual_remaining_capacity',flow['capacity_matrix']=={c:{k:matrix[c,k] for k in cell} for c in country})
    allocation=flow['allocation']
    valid=all(type(allocation[c][k]) is int and 0<=allocation[c][k]<=matrix[c,k] for c in country for k in cell)
    valid=valid and all(sum(allocation[c].values())<=country[c] for c in country)
    valid=valid and all(sum(allocation[c][k] for c in country)<=cell[k] for k in cell)
    total=sum(sum(v.values()) for v in allocation.values())
    check(name+':feasible_allocation_witness',valid and total==flow['achieved_flow'])
    cut=flow['deficient_cut']
    if cut is not None:
        cr=set(cut['reachable_countries']); kr=set(cut['reachable_cells'])
        capacity=sum(v for c,v in country.items() if c not in cr)+sum(matrix[c,k] for c in cr for k in cell if k not in kr)+sum(cell[k] for k in kr)
        check(name+':independent_cut',cr<=country.keys() and kr<=cell.keys() and capacity==cut['capacity']==total
              and capacity<flow['target'] and cut['deficit']==flow['target']-capacity)


def verify_lexicographic_certificates(result,name):
    synth=result['synthetic']; intl=synth['selection']['INT']
    candidates=sorted([r for r in synth['modeled_candidates'] if r['country'] in ('UK','JP','EU')],key=lambda r:priority(r['issuer_id']))
    country={c:8 for c in ('UK','JP','EU')}; cell={a+'|'+b:q for a in ACTIVITIES for b,q in QUOTA.items()}
    verify_flow_certificate(intl['initial_flow'],candidates,country,cell,name+':initial')
    if intl['state']=='MODEL_INFEASIBLE':
        return
    trials=intl['trials']; included=[]; exclusions=0; zero_seen=False
    check(name+':trials_cover_priority_sequence',[t['issuer_id'] for t in trials]==[r['issuer_id'] for r in candidates])
    selected_set=set(intl['selected_issuer_ids'])
    for index,(row,trial) in enumerate(zip(candidates,trials)):
        decision=trial['decision']; c,k=row['country'],row['cell']
        if decision=='NOT_NEEDED_AFTER_QUOTA_COMPLETE':
            check(name+':after_complete:'+str(index),len(included)==24)
            continue
        if decision=='QUOTA_ALREADY_FULL':
            check(name+':full_quota_skip:'+str(index),country[c]==0 or cell[k]==0)
            continue
        tc,tk=dict(country),dict(cell);tc[c]-=1;tk[k]-=1
        target=24-len(included)-1
        check(name+':trial_target:'+str(index),min(tc.values())>=0 and min(tk.values())>=0 and trial['remaining_target']==target and trial['current_removed_before_trial'] is True)
        if target==0: zero_seen=True
        if decision=='EXCLUDE_INFEASIBLE_COMPLETION':
            exclusions+=1
            verify_flow_certificate(trial['deficient_completion'],candidates[index+1:],tc,tk,name+':failed_trial:'+str(index))
            check(name+':excluded_not_selected:'+str(index),row['issuer_id'] not in selected_set)
        elif decision=='INCLUDE':
            # The actual final selected suffix is an independently checkable
            # feasible completion witness for this accepted prefix.
            suffix=[r for r in candidates[index+1:] if r['issuer_id'] in selected_set]
            check(name+':accepted_completion_witness:'+str(index),row['issuer_id'] in selected_set
                  and len(suffix)==target and Counter(r['country'] for r in suffix)==Counter({c:v for c,v in tc.items() if v})
                  and Counter(r['cell'] for r in suffix)==Counter({k:v for k,v in tk.items() if v}))
            included.append(row['issuer_id']);country,cell=tc,tk
        else:
            check(name+':known_decision',False,decision)
    check(name+':final_trace',included==intl['selected_issuer_ids'] and len(included)==24 and not any(country.values()) and not any(cell.values()) and zero_seen)
    return exclusions


def main():
    index=json.loads((review.VECTORS/'WIRE_INDEX.json').read_text())
    receipt=json.loads((OUT/'FROZEN_VECTOR_EXECUTION.json').read_text())
    by_id={r['case_id']:r for r in receipt['cases']}
    for case in index['cases']:
        name=case['case_id']; raw=gzip.decompress((OUT/'frozen_outputs'/(name+'.result.json.gz')).read_bytes())
        check(name+':complete_output_binding',review.binding(raw)==by_id[name]['output'])
        check(name+':authority_boundary',not review.authority_errors(json.loads(raw)))
        check(name+':no_exception',by_id[name]['exception'] is None)
    positive=frozen('V01_COMPLETE_MODEL');verify_quota(positive,'balanced')
    check('balanced:42_complete_pools',len(positive['synthetic']['modeled_reference_pools'])==42 and all(p['modeled_N']==4 and p['band_counts']=={'L':2,'M':1,'S':1} for p in positive['synthetic']['modeled_reference_pools']))
    verify_lexicographic_certificates(positive,'balanced')
    hall=frozen('V02_INT_HALL_DEFICIENCY'); h=hall['synthetic']['selection']['INT']['initial_flow']
    check('Hall:18_exact_no_cohort',h['achieved_flow']==18 and h['target']==24 and h['deficient_cut']['capacity']==18 and hall['synthetic']['selection']['selected_issuer_ids'] is None)
    verify_lexicographic_certificates(hall,'Hall')
    for case,bands in [('V03_BOUNDARY_TIE',{'L':3,'M':0,'S':1}),('V04_ALL_TIED',{'L':4,'M':0,'S':0})]:
        r=frozen(case); p=next(p for p in r['synthetic']['modeled_reference_pools'] if p['country']=='US' and p['activity']=='SEMICONDUCTOR_CLOUD')
        check(case+':ties_not_split',p['band_counts']==bands and r['synthetic']['selection']['selected_issuer_ids'] is None)
    required_codes={
        'V05_DUPLICATE_ISSUER':'DUPLICATE_ECONOMIC_ISSUER','V06_FORWARD_SET_MISMATCH':'TARGET_MEMBER_SET_MISMATCH',
        'V07_REVERSE_SET_MISMATCH':'TARGET_MEMBER_SET_MISMATCH','V07_REVERSE_AFTER_STATE':'EVENT_BEFORE_AFTER_STATE_MISMATCH',
        'V08_SAME_FACT_CONFLICT':'CAP_COMPONENT_CONFLICT','V11_PERSISTENT_SCOPE_HOLD':'POINT_MEASUREMENT_REQUIRED',
        'V12_ZERO_MISSING_EVIDENCE':'ZERO_DELTA_EVIDENCE_REQUIRED','V13_SPLIT_MISSING_PRICE_BRIDGE':'EXPLICIT_BRIDGE_EVENT_SET_MISMATCH',
        'V14_ORDINARY':'CAP_COMPONENT_UNAVAILABLE','V14_ZERO_OR_CEASED':'RICHER_CLASS_RIGHTS_OR_CEASED_FACT_NOT_IMPLEMENTED',
        'V17_DUPLICATE_TOP_KEY':'DUPLICATE_JSON_KEY','V17_DUPLICATE_NESTED_KEY':'DUPLICATE_JSON_KEY','V17_INVALID_UTF8':'INVALID_UTF8',
        'V17_NAN':'NON_INTEGER_JSON_NUMBER','V17_INFINITY':'NON_INTEGER_JSON_NUMBER','V17_UNPAIRED_SURROGATE':'NON_JSON_OUTPUT',
        'V18_COUNT_BOOL':'SUPPLIED_COUNT_INVALID_COUNT','V18_COUNT_NEGATIVE':'SUPPLIED_COUNT_INVALID_COUNT',
        'V18_COUNT_FLOAT':'NON_INTEGER_JSON_NUMBER','V18_COUNT_INTEGER_13_DIGITS':'JSON_INTEGER_LIMIT',
        'V18_VALUE_BOOL':'DECIMAL_STRING_REQUIRED','V18_VALUE_FLOAT':'NON_INTEGER_JSON_NUMBER','V18_NONPOSITIVE_PRICE':'STRICTLY_POSITIVE_REQUIRED',
        'V18_SOURCE_262145':'SOURCE_BYTE_LIMIT','V18_ASSERTIONS_17':'ARRAY_SHAPE_OR_LIMIT','V18_REQUEST_2097153':'INPUT_BYTE_LIMIT'}
    for case,code in required_codes.items():
        r=frozen(case);check(case+':intended_reason',code in codes(r))
        s=r.get('synthetic');check(case+':no_completed_selection',s is None or s['selection'] is None or s['selection']['selected_issuer_ids'] is None)
    for case in ('V06_FORWARD_SET_MISMATCH','V07_REVERSE_SET_MISMATCH'):
        h=frozen(case)['synthetic']['modeled_history'];check(case+':offset_counts_do_not_prove_sets',h['anchor_supplied_count']==h['target_supplied_count']==h['reconstructed_model_count']==168 and h['state']=='MODEL_SET_MISMATCH' and any(h['set_difference'].values()))
    for case,value in [('V09_MEASUREMENT_ORDER',1900000000),('V10_POST_K_REVISION',1900000000),('V12_NEGATIVE',1800000000),('V12_ZERO_EVIDENCED',2000000000),('V12_POSITIVE',2200000000),('V13_SPLIT_COMPLETE_BRIDGE',1000000000)]:
        r=frozen(case);check(case+':exact_cap',rational(first_cap(r)['modeled_cap_usd'])==value and not codes(r))
    for case in ('V08_SAME_FACT_CONFLICT','V12_ZERO_MISSING_EVIDENCE','V13_SPLIT_MISSING_PRICE_BRIDGE','V14_ORDINARY','V14_ZERO_OR_CEASED'):
        check(case+':whole_cap_null',first_cap(frozen(case))['modeled_cap_usd'] is None)
    for case in ('V08_SAME_FACT_CONFLICT','V09_MEASUREMENT_ORDER','V10_POST_K_REVISION'):
        bundle=request(case)['records'][0]['classes'][0]['shares']
        output=first_cap(frozen(case))['classes'][0]['shares']
        check(case+':all_assertions_retained',sorted(bundle['assertions'],key=lambda a:a['assertion_id'])==output['supplied_assertions']
              and output['bundle_content_binding']==review.binding(review.canonical(bundle)) and output['source_semantics_authenticated'] is False)
    future=first_cap(frozen('V10_POST_K_REVISION'))['classes'][0]['shares']
    check('V10:post_K_exclusion_and_relation',future['exclusions']==[{'assertion_id':'INDEPENDENT:COMPETING_ASSERTION','reason':'POST_CUTOFF_SOURCE'}]
          and future['relations'][0]['state']=='OUTSIDE_K_OR_APPLICABILITY')
    for case in ('V15_REAL_SOURCE','V15_DEFAULT_REAL'):
        r=frozen(case);check(case+':real_branch_not_run',r['model_state']=='NOT_RUN' and r['synthetic'] is None and r['untrusted_claims']['state']=='UNTRUSTED_CLAIMS_HAVE_NO_AUTHORITY_EFFECT')
    check('V16:synthetic_cannot_fulfill_real_cases',frozen('V16_SYNTHETIC_CLAIMS')['synthetic']['genuine_case_requirement_satisfied'] is False)
    for case in ('V18_SOURCE_262144','V18_REQUEST_2097152'):
        check(case+':full_positive_at_byte_limit',frozen(case)['model_state']=='ARTIFICIAL_MODEL_COMPLETE')
    perm=read_result('boundary_recipes','PERMUTED_COMPLETE_MODEL.result.json.gz')
    for field in ('modeled_reference_pools','selection'):
        check('permutation:'+field,perm['synthetic'][field]==positive['synthetic'][field])
    check('permutation:raw_binding_distinct',perm['request_binding']!=positive['request_binding'])
    forced=read_result('forced_INT_completion','result.json.gz');verify_quota(forced,'forced_INT')
    excluded=verify_lexicographic_certificates(forced,'forced_INT')
    check('forced_INT:10_independent_failure_cuts',excluded==10)
    boundary=json.loads((OUT/'BOUNDARY_RECIPE_EXECUTION.json').read_text())
    for row in boundary['cases']:
        check(row['case_id']+':boundary_authority',not row['observed']['real_authority_errors'])
    for case in ('POLICY_RAW_NEWLINE','ADOPTION_RAW_NEWLINE'):
        r=read_result('boundary_recipes',case+'.result.json.gz')
        check(case+':correct_actual_binding_code','FROZEN_POLICY_BINDING_MISMATCH' in codes(r))
    correction=json.loads((OUT/'RECIPE_INPUT_CORRECTION_EXECUTION.json').read_text())
    for row in correction['cases']:
        check(row['case_id']+':corrected_preconditions_and_oracle',row['independent_oracle_met'] and not row['observed']['real_authority_errors'])
    result={'schema':'independent.wp02.public_output_oracle_verification/v1','pid':os.getpid(),
            'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'public_API_calls_in_this_process':0,
            'private_kernel_helpers_called':0,'matrix_reruns':0,'all_checks_passed':True,'checks':CHECKS,
            'limits':'Checks saved exact public outputs; cutoff precision failures remain separate and unresolved in v1. Four corrected recipe inputs are distinct from their earlier invalid preconditions. No actual issuer/source authority established.'}
    (OUT/'PUBLIC_OUTPUT_ORACLE_VERIFICATION.json').write_bytes(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2).encode()+b'\n')
    print(json.dumps({'pid':os.getpid(),'checks':len(CHECKS),'all_passed':True,'public_API_calls':0,'private_helper_calls':0,'matrix_reruns':0,'forced_exclusion_cuts_checked':excluded},sort_keys=True),flush=True)


if __name__=='__main__':
    main()
