"""One independent public model forcing reachable exclusion certificates.

UK's8 modeled candidates occupy exactly four L cells with2 each. All8 must be
selected. JP/EU candidates in those cells must be rejected despite initial full
feasibility. A concrete24-member witness is checked without calling a solver.
"""
import copy
import datetime
import gzip
import importlib.util
import json
import os
import sys
from collections import Counter
import RUN_FROZEN_VECTORS as review
import RUN_BOUNDARY_RECIPES as fixture


def main():
    pins = review.verify_pins()
    out = review.OUT / 'forced_INT_completion'
    out.mkdir(exist_ok=False)
    x = fixture.load_case()
    forced_activities = ('SEMICONDUCTOR_CLOUD','INDUSTRIALS','CONSUMER','ENERGY_MATERIALS')
    records = []
    for row in x['records']:
        if row['primary_groups'] == ['UK']:
            if row['activity'] not in forced_activities or int(row['issuer_id'].split(':')[-1]) > 1:
                continue
            price = row['classes'][0]['price']['assertions'][0]
            price['value'] = '4'
            price['evidence'] = fixture.token(x,'4')
        records.append(row)
    x['records'] = records
    record_ids = {r['record_id'] for r in records}
    x['history']['anchor_members'] = [m for m in x['history']['anchor_members'] if m['record_id'] in record_ids]
    x['history']['target_members'] = copy.deepcopy(x['history']['anchor_members'])
    fixture.rebind_history(x)
    witness = []
    activities = ('SEMICONDUCTOR_CLOUD','INDUSTRIALS','CONSUMER','ENERGY_MATERIALS','FINANCIALS','HEALTHCARE')
    for row in records:
        country, activity, index = row['primary_groups'][0], row['activity'], int(row['issuer_id'].split(':')[-1])
        if country == 'UK' or (country == 'JP' and (index == 2 or (activity == 'FINANCIALS' and index < 2))) or (country == 'EU' and (index == 3 or (activity == 'HEALTHCARE' and index < 2))):
            if country not in ('UK','JP','EU'):
                continue
            band = 'L' if country == 'UK' or index < 2 else 'M' if index == 2 else 'S'
            witness.append({'issuer_id':row['issuer_id'],'country':country,'cell':activity+'|'+band})
    assert len(witness) == 24
    assert Counter(r['country'] for r in witness) == {'UK':8,'JP':8,'EU':8}
    assert Counter(r['cell'] for r in witness) == {a+'|'+b:q for a in activities for b,q in [('L',2),('M',1),('S',1)]}
    raw = review.canonical(x)
    (out/'request.json.gz').write_bytes(gzip.compress(raw,mtime=0))
    spec = importlib.util.spec_from_file_location('forced_int_review_wp02',review.ROOT/review.PINS['module'][0])
    module = importlib.util.module_from_spec(spec)
    sys.addaudithook(review.audit)
    review.ACTIVE = True
    try:
        spec.loader.exec_module(module)
        result = module.diagnose(raw,policy_bytes=pins['policy'],adoption_bytes=pins['adoption'])
    finally:
        review.ACTIVE = False
    result_raw = review.canonical(result)
    (out/'result.json.gz').write_bytes(gzip.compress(result_raw,mtime=0))
    selection = (result.get('synthetic') or {}).get('selection') or {}
    intl = selection.get('INT') or {}
    exclusions = [r for r in intl.get('trials',[]) if r['decision'] == 'EXCLUDE_INFEASIBLE_COMPLETION']
    passed = result['model_state'] == 'ARTIFICIAL_MODEL_COMPLETE' and len(exclusions)>0
    receipt = {'schema':'independent.wp02.forced_INT_public_execution/v1','pid':os.getpid(),
        'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'api_call_count':1,
        'source':dict(review.binding(pins['module']),path=review.PINS['module'][0]),
        'request':review.binding(raw),'output':review.binding(result_raw),'artificial_records':len(records),
        'independent_feasibility_witness':witness,'model_state':result['model_state'],
        'actual_initial_flow':(intl.get('initial_flow') or {}).get('achieved_flow'),
        'actual_residual_exclusion_count':len(exclusions),'coarse_branch_oracle_met':passed,
        'effect_guard_events':review.EVENTS,'claims':'Artificial public-path branch challenge only; no actual cohort or new source observation.'}
    review.verify_pins()
    (review.OUT/'FORCED_INT_COMPLETION_EXECUTION.json').write_bytes(json.dumps(receipt,ensure_ascii=False,sort_keys=True,indent=2).encode()+b'\n')
    print(json.dumps({'pid':os.getpid(),'api_calls':1,'model_state':result['model_state'],'initial_flow':receipt['actual_initial_flow'],
                      'residual_exclusions':len(exclusions),'coarse_branch_oracle_met':passed,'effect_guard_events':len(review.EVENTS)},sort_keys=True),flush=True)
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
