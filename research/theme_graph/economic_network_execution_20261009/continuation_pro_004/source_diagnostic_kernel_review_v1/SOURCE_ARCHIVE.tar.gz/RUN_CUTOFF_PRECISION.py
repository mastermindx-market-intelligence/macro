"""Four public-API reproductions of exact K ordering, no helper-call oracle."""
import copy
import datetime
import gzip
import importlib.util
import json
import os
import sys
import RUN_FROZEN_VECTORS as review


def load_case(case_id):
    return json.loads(gzip.decompress((review.VECTORS / 'wire' / (case_id + '.request.gz')).read_bytes()))


def main():
    pins = review.verify_pins()
    out = review.OUT / 'cutoff_precision'
    out.mkdir(exist_ok=False)
    spec = importlib.util.spec_from_file_location('cutoff_review_wp02', review.ROOT / review.PINS['module'][0])
    module = importlib.util.module_from_spec(spec)
    sys.addaudithook(review.audit)
    review.ACTIVE = True
    try:
        spec.loader.exec_module(module)
    finally:
        review.ACTIVE = False
    results = []
    for scope in ('anchor', 'correction'):
        for fraction, numerator, denominator in (('000001', 1, 1000000), ('0000001', 1, 10000000)):
            case_id = 'K_PLUS_' + fraction + '_' + scope.upper()
            request = load_case('V01_COMPLETE_MODEL' if scope == 'anchor' else 'V10_POST_K_REVISION')
            timestamp = '2026-10-09T00:00:00.' + fraction + 'Z'
            if scope == 'anchor':
                request['history']['anchor_public_upper'] = timestamp
            else:
                bundle = request['records'][0]['classes'][0]['shares']
                bundle['assertions'][1]['public_upper'] = timestamp
                bundle['relations'][0]['public_upper'] = timestamp
            raw = review.canonical(request)
            (out / (case_id + '.request.json.gz')).write_bytes(gzip.compress(raw, mtime=0))
            review.ACTIVE = True
            try:
                result = module.diagnose(raw, policy_bytes=pins['policy'], adoption_bytes=pins['adoption'])
            finally:
                review.ACTIVE = False
            result_raw = review.canonical(result)
            (out / (case_id + '.result.json.gz')).write_bytes(gzip.compress(result_raw, mtime=0))
            observed = review.summarize(result, raw)
            cap = observed.get('first_supplied_record_cap_receipt')
            cap = cap and cap.get('modeled_cap_usd')
            expected = 'Post-K anchor held (or explicit unsupported timestamp refusal)' if scope == 'anchor' else 'Post-K correction cannot replace 190m shares; cap 1.9b or explicit timestamp refusal'
            passed = ('POST_CUTOFF_ANCHOR' in [h['code'] for h in observed['holds']]) if scope == 'anchor' else cap == {'numerator': '1900000000', 'denominator': '1'}
            row = {'case_id': case_id, 'timestamp': timestamp,
                   'exact_positive_seconds_after_K': {'numerator': str(numerator), 'denominator': str(denominator)},
                   'mutation': 'Only public_upper timestamp(s); bound numeric and membership sources remain unchanged',
                   'request': review.binding(raw), 'result': review.binding(result_raw), 'observed': observed,
                   'expected': expected, 'oracle_met': passed}
            results.append(row)
            print(json.dumps({'case_id': case_id, 'expected_met': passed, 'model_state': result['model_state'], 'first_cap': cap,
                'codes': [r['code'] for r in observed['holds']]}, sort_keys=True), flush=True)
    review.verify_pins()
    receipt = {'schema': 'independent.wp02.cutoff_precision_reproduction/v1', 'pid': os.getpid(),
        'completed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'api_call_count': len(results),
        'module': dict(review.binding(pins['module']), path=review.PINS['module'][0]), 'cases': results,
        'effect_guard_events': review.EVENTS, 'source_pins_unchanged_after': True, 'private_helper_calls': 0,
        'review_finding': 'P2: submicrosecond positive public offset is truncated to exact K; public result incorporates post-K premise'}
    (review.OUT / 'CUTOFF_PRECISION_EXECUTION.json').write_bytes(json.dumps(receipt, ensure_ascii=False, sort_keys=True, indent=2).encode() + b'\n')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
