"""Correct four independently authored recipe preconditions, preserving run001.

Run001's bridge had a Sep15 share coordinate inconsistent with its empty bridge;
its changing anchor/target arrays reused one source ID. Neither early refusal is
evidence about the intended arithmetic/event-label boundary. This run fixes only
those fixture errors; the author's module is unchanged.
"""
import datetime
from fractions import Fraction
import gzip
import importlib.util
import json
import os
import sys
import RUN_FROZEN_VECTORS as review
import RUN_BOUNDARY_RECIPES as fixture


def main():
    pins = review.verify_pins()
    out = review.OUT / 'recipe_input_corrections'
    out.mkdir(exist_ok=False)
    spec = importlib.util.spec_from_file_location('corrected_recipe_wp02', review.ROOT / review.PINS['module'][0])
    module = importlib.util.module_from_spec(spec)
    sys.addaudithook(review.audit)
    review.ACTIVE = True
    try:
        spec.loader.exec_module(module)
    finally:
        review.ACTIVE = False
    rows = []
    for case_id in ('DERIVED_ARITHMETIC_1_CLASSES', 'DERIVED_ARITHMETIC_2_CLASSES', 'EVENT_CONVERSION', 'EVENT_TRANSFER'):
        old_raw = gzip.decompress((review.OUT / 'boundary_recipes' / (case_id + '.request.json.gz')).read_bytes())
        x = json.loads(old_raw)
        if case_id.startswith('DERIVED'):
            for cls in x['records'][0]['classes']:
                cls['shares']['assertions'][0]['coordinate'] = '2026-09-30'
            delta = 'Every target class share coordinate Sep15→D; now empty share bridge is correct, while32 later price splits remain required.'
        else:
            h = x['history']
            h['anchor_source_id'] = 'INDEPENDENT_CORRECTED_ANCHOR_SOURCE'
            fixture.rebind_history(x)
            delta = 'Distinct anchor source ID with exactly bound full anchor array; target/events source bindings independently verified.'
            by_id = {s['source_id']: s for s in x['sources']}
            for field, key in [('anchor_members','anchor_source_id'),('target_members','target_source_id'),('events','events_source_id')]:
                assert json.loads(by_id[h[key]]['content']) == h[field]
        raw = review.canonical(x)
        (out / (case_id + '.request.json.gz')).write_bytes(gzip.compress(raw,mtime=0))
        review.ACTIVE = True
        try:
            result = module.diagnose(raw,policy_bytes=pins['policy'],adoption_bytes=pins['adoption'])
        finally:
            review.ACTIVE = False
        result_raw = review.canonical(result)
        (out / (case_id + '.result.json.gz')).write_bytes(gzip.compress(result_raw,mtime=0))
        observed = review.summarize(result,raw)
        codes = {r['code'] for r in observed['holds']}
        cap = observed['first_supplied_record_cap_receipt']
        cap = cap and cap['modeled_cap_usd']
        if case_id == 'DERIVED_ARITHMETIC_1_CLASSES':
            expected = Fraction(100000000,(10**47+1)**32)
            passed = not codes and cap is not None and Fraction(int(cap['numerator']),int(cap['denominator'])) == expected
        elif case_id == 'DERIVED_ARITHMETIC_2_CLASSES':
            passed = 'EXACT_ARITHMETIC_BUDGET' in codes and cap is None and result['synthetic']['selection'] is None
        elif case_id == 'EVENT_CONVERSION':
            passed = result['model_state'] == 'ARTIFICIAL_MODEL_COMPLETE' and result['synthetic']['modeled_history']['state'] == 'MODEL_SET_MATCH'
        else:
            passed = 'EVENT_KIND_CHANGED_FIELDS_MISMATCH' in codes and result['synthetic']['selection'] is None
        rows.append({'case_id':case_id,'original_run001_request':review.binding(old_raw),'corrected_request':review.binding(raw),
                     'input_correction':delta,'output':review.binding(result_raw),'observed':observed,'independent_oracle_met':passed})
        print(json.dumps({'case_id':case_id,'oracle_met':passed,'codes':sorted(codes),'model_state':result['model_state']},sort_keys=True),flush=True)
    review.verify_pins()
    receipt = {'schema':'independent.wp02.corrected_fixture_execution/v1','pid':os.getpid(),
               'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'api_call_count':len(rows),'cases':rows,
               'module':dict(review.binding(pins['module']),path=review.PINS['module'][0]),
               'previous_fixture_errors_preserved':True,'author_source_unchanged':True,'effect_guard_events':review.EVENTS}
    (review.OUT/'RECIPE_INPUT_CORRECTION_EXECUTION.json').write_bytes(json.dumps(receipt,sort_keys=True,ensure_ascii=False,indent=2).encode()+b'\n')
    return 0 if all(r['independent_oracle_met'] for r in rows) else 1


if __name__ == '__main__':
    raise SystemExit(main())
