"""Independent execution of immutable pre-source-review byte requests.

Writes only its own review directory. Does not run any author test/helper.
"""
import datetime
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path('/workspace/scratch/9fd3d58c239a')
OUT = ROOT / 'lanes/source_diagnostic_kernel_review_v1'
VECTORS = ROOT / 'lanes/source_diagnostic_independent_vectors_v1'
PINS = {
    'module': ('lanes/source_diagnostic_kernel_v1/source_diagnostic.py', 77308, '80b12ec299e861d24c0c23f88805a475f44099af894fbea7d787296c72681d8f'),
    'contract': ('lanes/source_diagnostic_kernel_v1/INPUT_CONTRACT.md', 19018, 'cea9493577f98f8b57a313f20dd7f79f93095dc1ec38d32e9b0452e97f6ee63a'),
    'policy': ('lanes/source_diagnostic_policy_v2/RECOMMENDED_SELECTION_POLICY.json', 60312, 'd41422d76219b1c5d3a3c9cbb19a1bc3124433031200b09499033bd4dc30d522'),
    'adoption': ('lanes/source_diagnostic_policy_adoption_v1/POLICY_ADOPTION.json', 9593, '645a20a39842d9c5a03b4ff39a37280d1aa02c32ef545c061d0aa959f06e0016'),
    'wire_index': ('lanes/source_diagnostic_independent_vectors_v1/WIRE_INDEX.json', 27502, '768dc39863643f6a8365fc2e796ce312af2a19bf053d95c41c03773b5acb1e5f'),
}
BASE_HOLDS = {'SOURCE_AUTHORITY_UNVERIFIED', 'SOURCE_RIGHTS_UNVERIFIED', 'FRAME_HISTORY_UNPROVEN'}


def binding(raw):
    return {'byte_length': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')


def verify_pins():
    raw = {}
    for name, (path, length, digest) in PINS.items():
        value = (ROOT / path).read_bytes()
        assert len(value) == length and hashlib.sha256(value).hexdigest() == digest, name
        raw[name] = value
    return raw


def authority_errors(result):
    errors = []
    for field, expected in [('status', 'STRUCTURAL_ONLY'), ('readiness', 'NOT_READY'), ('actual_F', None)]:
        if result.get(field) != expected:
            errors.append(field)
    authority = result.get('authority', {})
    if authority.get('admission') != 'NOT_ADMITTED' or any(value is not False for key, value in authority.items() if key != 'admission'):
        errors.append('authority')
    if any(value is not None for value in result.get('real_inputs', {}).values()):
        errors.append('real_inputs')
    if not BASE_HOLDS <= {row['code'] for row in result.get('holds', [])}:
        errors.append('unconditional_holds')
    if result.get('request_mode') == 'REAL_SOURCE' and result.get('synthetic') is not None:
        errors.append('real_mode_synthetic_disclosure')
    return errors


def summarize(result, request_raw):
    synthetic = result.get('synthetic') or {}
    selection = synthetic.get('selection') or {}
    int_result = selection.get('INT') or {}
    flow = int_result.get('initial_flow') or {}
    try:
        req = json.loads(request_raw)
        rid = req['records'][0]['record_id']
    except Exception:
        rid = None
    cap = next((r for r in synthetic.get('modeled_cap_receipts', []) if r.get('record_id') == rid), None)
    return {
        'model_state': result.get('model_state'),
        'holds': [r for r in result.get('holds', []) if r['code'] not in BASE_HOLDS],
        'real_authority_errors': authority_errors(result),
        'modeled_population_count': synthetic.get('modeled_population_count'),
        'selection_state': selection.get('state'),
        'selected_count': None if selection.get('selected_issuer_ids') is None else len(selection['selected_issuer_ids']),
        'INT_achieved_flow': flow.get('achieved_flow'),
        'INT_target': flow.get('target'),
        'INT_deficient_cut': flow.get('deficient_cut'),
        'first_supplied_record_cap_receipt': cap,
    }


ACTIVE = False
EVENTS = []


def audit(event, args):
    if not ACTIVE:
        return
    deny = event.startswith(('socket.', 'subprocess.')) or event in {
        'os.system', 'os.posix_spawn', 'os.fork', 'os.forkpty', 'os.exec',
        'os.remove', 'os.rename', 'os.mkdir', 'os.rmdir', 'os.truncate', 'os.chmod', 'os.chown',
        'os.link', 'os.symlink', 'os.utime', 'shutil.copyfile', 'shutil.copymode', 'shutil.copystat',
    }
    if event == 'open':
        mode, flags = args[1], args[2]
        deny = isinstance(mode, str) and any(s in mode for s in 'wax+')
        deny = deny or (isinstance(flags, int) and bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND)))
    if deny:
        EVENTS.append({'event': event, 'phase': 'frozen_module_import_or_diagnose'})
        raise RuntimeError('INDEPENDENT_REVIEW_EFFECT_GUARD:' + event)


def main():
    global ACTIVE
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    raw = verify_pins()
    (OUT / 'frozen_outputs').mkdir(exist_ok=False)
    sys.addaudithook(audit)
    spec = importlib.util.spec_from_file_location('independently_reviewed_wp02', ROOT / PINS['module'][0])
    module = importlib.util.module_from_spec(spec)
    ACTIVE = True
    try:
        spec.loader.exec_module(module)
    finally:
        ACTIVE = False
    cases = json.loads(raw['wire_index'])['cases']
    rows = []
    for case in cases:
        compressed = (VECTORS / case['wire_file']).read_bytes()
        assert binding(compressed) == {'byte_length': case['gzip_byte_length'], 'sha256': case['gzip_sha256']}, case['case_id']
        request = gzip.decompress(compressed)
        assert binding(request) == {'byte_length': case['request_byte_length'], 'sha256': case['request_sha256']}, case['case_id']
        elapsed = time.perf_counter()
        row = {'case_id': case['case_id'], 'input': binding(request), 'api': 'diagnose', 'exception': None}
        ACTIVE = True
        try:
            result = module.diagnose(request, policy_bytes=raw['policy'], adoption_bytes=raw['adoption'])
            result_raw = canonical(result)
        except Exception as exc:
            row['exception'] = {'type': type(exc).__name__, 'message': str(exc)[:2000]}
            result_raw = canonical({'unexpected_exception': row['exception']})
            result = None
        finally:
            ACTIVE = False
        row['duration_seconds'] = round(time.perf_counter() - elapsed, 6)
        output_file = 'frozen_outputs/' + case['case_id'] + '.result.json.gz'
        compressed_result = gzip.compress(result_raw, mtime=0)
        (OUT / output_file).write_bytes(compressed_result)
        row['output'] = binding(result_raw)
        row['compressed_output'] = dict(binding(compressed_result), path=output_file)
        if result is not None:
            row['observed'] = summarize(result, request)
        rows.append(row)
        print(json.dumps({'case_id': case['case_id'], 'exception': row['exception'],
              'model_state': (row.get('observed') or {}).get('model_state'),
              'codes': [r['code'] for r in (row.get('observed') or {}).get('holds', [])],
              'authority_errors': (row.get('observed') or {}).get('real_authority_errors')}, sort_keys=True), flush=True)
    verify_pins()
    receipt = {'schema': 'independent.wp02.frozen_vector_execution/v1', 'pid': os.getpid(),
        'started_utc': start, 'completed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'python': sys.version, 'api_call_count': len(rows), 'cases': rows,
        'source_bindings': {name: dict(binding(value), path=PINS[name][0]) for name, value in raw.items()},
        'effect_guard_events': EVENTS, 'guard_scope': 'Named Python filesystem-mutation/process/socket audit events during actual module import and public calls only; not a universal external trust proof.',
        'source_pins_unchanged_after': True, 'original_vectors_unchanged_by_runner': True,
        'author_suite_or_helper_run': False, 'native_or_real_source_execution': False}
    (OUT / 'FROZEN_VECTOR_EXECUTION.json').write_bytes(json.dumps(receipt, ensure_ascii=False, sort_keys=True, indent=2).encode() + b'\n')
    exceptions = sum(r['exception'] is not None for r in rows)
    authority = sum(bool((r.get('observed') or {}).get('real_authority_errors')) for r in rows)
    print(json.dumps({'pid': os.getpid(), 'api_calls': len(rows), 'unexpected_exceptions': exceptions,
                      'authority_failures': authority, 'effect_guard_events': len(EVENTS)}, sort_keys=True), flush=True)
    return 0 if exceptions == authority == len(EVENTS) == 0 else 1


if __name__ == '__main__':
    raise SystemExit(main())
