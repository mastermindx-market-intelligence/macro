"""Two exact public CLI replays in separate scratch child processes.

The harness owns process launch and review-file writes. The kernel is given only
three explicit regular files. This is not native execution or a transport proof.
"""
import datetime
import gzip
import json
import os
import subprocess
import sys
import RUN_FROZEN_VECTORS as review


def main():
    pins=review.verify_pins()
    out=review.OUT/'fresh_cli_replay';out.mkdir(exist_ok=False)
    raw=gzip.decompress((review.VECTORS/'wire/V01_COMPLETE_MODEL.request.gz').read_bytes())
    input_path=out/'request.json';input_path.write_bytes(raw)
    expected=gzip.decompress((review.OUT/'frozen_outputs/V01_COMPLETE_MODEL.result.json.gz').read_bytes())+b'\n'
    argv=[sys.executable,'-B',str(review.ROOT/review.PINS['module'][0]),'--input',str(input_path),
          '--policy',str(review.ROOT/review.PINS['policy'][0]),'--adoption',str(review.ROOT/review.PINS['adoption'][0])]
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
    rows=[]
    for sequence in (1,2):
        child=subprocess.Popen(argv,cwd=review.ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        try:
            stdout,stderr=child.communicate(timeout=30)
        except subprocess.TimeoutExpired:
            child.kill();stdout,stderr=child.communicate()
            raise AssertionError('SCRATCH_CLI_TIMEOUT')
        (out/('stdout_'+str(sequence)+'.json.gz')).write_bytes(gzip.compress(stdout,mtime=0))
        (out/('stderr_'+str(sequence)+'.log')).write_bytes(stderr)
        result=json.loads(stdout)
        row={'sequence':sequence,'child_pid':child.pid,'returncode':child.returncode,
             'stdout':review.binding(stdout),'stderr':review.binding(stderr),
             'matches_original_complete_API_output_plus_newline':stdout==expected,
             'authority_errors':review.authority_errors(result)}
        rows.append(row)
        assert child.returncode==2 and not stderr and stdout==expected and not row['authority_errors'],row
    review.verify_pins()
    assert input_path.read_bytes()==raw
    receipt={'schema':'independent.wp02.fresh_scratch_CLI_replay/v1','harness_pid':os.getpid(),
             'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,
             'expected_public_exit':2,'actual_public_CLI_calls':2,'request':review.binding(raw),
             'module':dict(review.binding(pins['module']),path=review.PINS['module'][0]),'results':rows,
             'source_and_input_pins_unchanged':True,'all_complete_outputs_identical':True,
             'limit':'Explicit stdlib scratch subprocess/CLI proof, no native application/runtime/source or authority admission.'}
    (review.OUT/'FRESH_CLI_REPLAY_EXECUTION.json').write_bytes(json.dumps(receipt,ensure_ascii=False,sort_keys=True,indent=2).encode()+b'\n')
    print(json.dumps({'harness_pid':os.getpid(),'child_pids':[r['child_pid'] for r in rows],
                      'child_exit_codes':[r['returncode'] for r in rows],'full_output_matches':True},sort_keys=True),flush=True)


if __name__=='__main__':
    main()
