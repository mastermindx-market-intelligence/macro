# RRU full integrity candidate — bounded independent static review

ROUTE: review
RECEIVER_MODE: DIRECT_TARGETED
Child: risk-radar-full-integrity-static-review-20260910-sol-001
Parent: risk-radar-all-regions-upgrade-20260908-sol-001; Macro PR6989 / MAS-258.
This delivery assigns one finite, text-only Opus reviewer invocation on the existing
Claude Code Max subscription. It is not an Executive Job, source writer or Sol seat.
WHY: cross-provider adversarial review of consequential numerical/authority/consumer semantics.
WHY NOT FABLE: the implementation and contract are frozen; no principal orchestration is needed.
Economics: current native auth reports claude.ai, firstParty, Max; no API-key route or fallback.
Current live Chairman direction authorizes continuing the parent; this is a new bounded
review of the new seventeen-path candidate, not replay of any earlier blocked review.

SECTION: MISSION
Find concrete defects that prevent this exact integrity slice from safely entering
source integration. Preserve the full ambition: useful early danger/recovery intelligence,
not a permanently neutral dashboard or a provenance-only product. Do not call it shipped.

SECTION: ARTIFACT TO ATTACK
Source pin: macro@16b6c14cd4791dde7cd7217a6945987805b0fa16.
Seventeen-path patch SHA256: 83846c4e953fedd643e30953da14ee57907f477631d717a06ebef82b853f7108.
Manifest SHA256: 1b9f92be43077aae7af73ce538addb2df3859d3bfd58a1d91f90d21101a80863.
Repository carrier HEAD f5f80aa364f3f180dd4bf63789d70e0bb231e4fc; candidate is uninstalled.
The attached numbered source excerpts and complete modules define the reviewed bytes.
Source ownership/current integration and production release are explicitly NOT granted.

SECTION: REVIEW STANDARD
Authority precedence: current Chairman scope > protected Mastermind Skillpack/source laws
at f3f2d9155796876009f2d427bfdecc7ee7b63e74 > existing Risk Radar decisions and source.
Outcome: partial/unavailable inputs cannot fabricate a calibrated forecast, market recovery,
current sizing, or inherited force authority; a qualified assessment must reach real users
and machine consumers. Existing valid legacy behavior and unrelated protections survive.
No new policy/calendar/ledger/queue. No writes to issued rows or live data. Future promotion
requires separately reviewed method-compatible evidence, never a producer's reviewed label.
Distinguish stateless snapshot caps from named active restrictions; real cutover is still held.

SECTION: SCOPE
Static review of the seventeen-path patch, complete changed core modules, exact changed
caller/template contexts and supplied tests/receipts. Start your result with PICKUP_ACK
for this child and then START/READ_ONLY, keeping these separate from completion.
No tools, shell, file reads/writes, MCP, browser, subagents, provider fallback or network.
The packet is self-contained; absent dependencies are gaps, not permission to fetch them.
No visual-design acceptance: screenshots were inspected by Sol but are not in this text packet.
No market-performance, current-live policy, source-collision census or blocked diagnostic claims.
Do not request or reproduce the prior blocked real-input output or old review packet.

SECTION: NOT DONE UNLESS
Trace availability/arithmetic -> composition/rank reference -> prospective serialization and
legacy evidence selection -> grant attachment -> actual market state/VM -> adapter and card.
Attack the numerical construction and legacy/current split, malformed/null metadata, nested
aliases, implicit import/binding assumptions, stale observation reuse and hidden consumers.
Distinguish blockers from out-of-scope future forecast validation and presentation polish.
A PASS is only static code review of this immutable candidate, never release/production acceptance.

SECTION: EVIDENCE REQUIRED
Each substantive finding needs file/line, actual mechanism, concrete counterexample and
smallest adequate test/repair. Attack whether the tests discriminate the contract; passing
counts alone are not persuasive. Do not invent current market facts or call a fixture live.
The current-pin whole-module invocation passed286 tests. The actual five-route builder
passed45 synthetic page/JSON cases. Historical-pin browser proof passed360 settled-dialog
cases; current-pin browser rerun was blocked, so visual compatibility is not refreshed.
State which claims you actually verified statically and which remain merely reported.

SECTION: RETURN
Return exactly STATUS / RESULT / EVIDENCE / GAPS / DEVIATIONS top-level labels.
Give severity and exact source references; concise findings are preferred to generic advice.
One response then exit. No waiting watcher, open follow-up, self-assigned repair or new child.
Sol will adjudicate outside this finite read-only invocation. No permanent session required.
Stop on any missing required authority or unexpected tool requirement; return BLOCKED honestly.

Failure behavior: an unavailable subscription or provider refusal ends this child without
fallback; tool access is intentionally absent. No grant, capital action or deployment is possible.
Implementation sequence after review remains Sol adjudication -> bounded corrections -> exact
retest -> lawful source integration -> real-input/publication/browser proof -> final acceptance.
This packet is review transport, not a replacement canonical company record or lifecycle.


## Exact source manifest
{
  "source_pin": "16b6c14cd4791dde7cd7217a6945987805b0fa16",
  "capability": "uninstalled_research_candidate",
  "patch_format": "unified_zero_context; exact before hashes required",
  "paths": {
    "engine/international_macro_dashboard.py": {
      "before_sha256": "ba656f2786a54df357009ded2e269431ad3759a421c346fe26990e16282fec4a",
      "after_sha256": "e78539ee31e160af62680f9d121ab49bafb116b42fa1547dc5663ff65bba50c9"
    },
    "engine/intl_run.py": {
      "before_sha256": "dc48bce3bf4f863e39b46e6cac28af0b82e367207fbbc45bc3dd216cd160e55f",
      "after_sha256": "cc34d1ae42444f0f7d2570088cda1f0d9709b512c97fdbd78fcb901aaebc0890"
    },
    "engine/market_state.py": {
      "before_sha256": "4a8634dcfae1703b8adc28f3a027309ba65312dce4e0a8236c1876cc02e2f684",
      "after_sha256": "b2b25c80b928923b4a99fb33140760e1020a49159ed73504d68ae9c80345cb50"
    },
    "engine/risk_radar_intl.py": {
      "before_sha256": "1596e1da4794bf97d49f6f0ae42eaabff7226fa812fb0a96bfb0a6242faf7cd7",
      "after_sha256": "96e00c04580c8cbff5c07ddd0bdf2a3051b7344d6e27e0c08b40333b8ca91b30"
    },
    "engine/risk_radar_intl_audit.py": {
      "before_sha256": "59215f15f68371a114213a9beac5f5d5023725425de37ab9e17e60e34a2870aa",
      "after_sha256": "b651ff21713dcfcc31ac08bf774e85b4ba29be6514c8854ae16b1b31f0d8af15"
    },
    "engine/risk_radar_intl_tune.py": {
      "before_sha256": "a7f3adbf3ea60f62eaf9346300c176c138d90c054cf348d81c0f96ca14ca7f58",
      "after_sha256": "ed9003c72cda9de36201f802c1b5d78248db75428041dee5e58a0f5cfc568a26"
    },
    "engine/risk_radar_recovery.py": {
      "before_sha256": "321545a3cace15f20d23b564e1b43595ccd0804fab3de362eceb5a580695c593",
      "after_sha256": "b817d1fb4d8ba0484bfc3ef8f66c40e35f5762bf5cde02c1d45435277ef9f5a8"
    },
    "scripts/build_canada.py": {
      "before_sha256": "bbf712638c4e378e4af516dfc4dec0033bd98bbae5c386f819ed5553d3876269",
      "after_sha256": "627b32b7f60da9a2762e1e74da2dc651b640661d00cbf3e825e75d489098400b"
    },
    "scripts/build_china.py": {
      "before_sha256": "1e5d0cbfba24f4e44c0e6c8850a16809bcfab6b4e5acf9cb58b2a2bb99b870e6",
      "after_sha256": "3a7da97c320a078803fa3cd9c5523e09e34681199f899062d2b8be1c156dae95"
    },
    "scripts/build_china_risk_state.py": {
      "before_sha256": "3dc2f44d6c1a23e18edaa0c9631d093c06134768add6cc83a22c8f833a481db8",
      "after_sha256": "73f0224b8ceba99d76fa1e55b89913e4d6c51718c7115de74dd0df045e7ee667"
    },
    "scripts/build_hk.py": {
      "before_sha256": "8df616b82725e50d7cd93d7acf3e8a31297d9a98e61cd91a6061c8e3ade0b7ef",
      "after_sha256": "87e9ec5e2ad4a4525f08ada2fb7f2d89808987b81def78e092b8adb62fffe643"
    },
    "scripts/build_international_macro.py": {
      "before_sha256": "98fc3c9a69ad057f9b565335a6b21a5cf39185663d30c721f7c31d9fe6363fdc",
      "after_sha256": "d72412bf5f716fc1c051314ea7d7d78ef52e3ed2d96041a5228be907d803bae2"
    },
    "templates/_risk_radar_card.html.j2": {
      "before_sha256": "fe784862a462a62eae7e76b4c9df32cb2aefb01738a138ce262e2d171188d2d3",
      "after_sha256": "6ca2e9b783f6d8f0f7c0b4496160d6c3a020fd6cdb979fd57c459ca901c5ba48"
    },
    "templates/baskets_desk.js": {
      "before_sha256": "bf97c8ba2ce8198e02a39ea3e2bc3097ed53027f7835e8821e99b320fe1c62dd",
      "after_sha256": "81fd19205af98c7872bfdd1b10397414b7abf7fa899a955470a5d3b0add5262a"
    },
    "templates/china.html.j2": {
      "before_sha256": "cb6e0685b96a6d897e9562418927c0bb5d5e656d4b31c99e843ec5f213fa7031",
      "after_sha256": "236da2e7f7d56913d0308698eab6b65c00d577f8fe7b6ea70a24fecc0606929e"
    },
    "templates/cn_reversal_sleeve.html.j2": {
      "before_sha256": "9056c65d7c1c6361860186361d8b05e036f20928834f52a15dbbd35108f960e4",
      "after_sha256": "dc40baaf1d710b0ef18c7a55a85d1098fb6417d22c552db47003f1a7144531fc"
    },
    "templates/international_macro.html.j2": {
      "before_sha256": "75211045dece285dd2da673733999260b3cb1910165b3417823c21cdc5e360d1",
      "after_sha256": "a6208ec651c37b56780bbad8c9f4d793a199e70a3af8e02a3e8c60cbcb39372a"
    }
  },
  "patch_sha256": "83846c4e953fedd643e30953da14ee57907f477631d717a06ebef82b853f7108",
  "production": false,
  "release_ready": false,
  "remaining_release_gates": [
    "independent full-candidate review",
    "source custody and current integration",
    "real-input applicability",
    "installed-policy cutover",
    "production publication and entitled browser proof"
  ]
}

## COMPLETE CANDIDATE SOURCE: engine/international_macro_dashboard.py
```
1: """Shared view-model contract for first-class international macro dashboards.
2: 
3: The seven-market international engine remains the source of regime, price, FX and
4: calibrated drawdown-risk facts.  This module turns five of those records into a
5: uniform, presentation-ready ``international_macro_dashboard.v1`` payload while
6: keeping regional differences in explicit specs.
7: 
8: Important honesty boundaries:
9: 
10: * ``decision_score`` is a transparent descriptive composite, not a probability.
11: * ``risk_radar.drawdown_prob`` is the separately calibrated forward measure.
12: * An unavailable local official series stays unavailable.  A source catalog entry
13:   never becomes a number merely because the source exists.
14: """
15: 
16: from __future__ import annotations
17: 
18: from dataclasses import dataclass
19: from datetime import date, datetime, timezone
20: from typing import Any
21: 
22: import pandas as pd
23: import yaml
24: 
25: from lib import config
26: 
27: SCHEMA = "international_macro_dashboard.v1"
28: 
29: 
30: @dataclass(frozen=True)
31: class SourceSpec:
32:     key: str
33:     provider: str
34:     url: str
35:     cadence: str
36:     access: str
37:     licence: str
38:     role: str
39: 
40: 
41: @dataclass(frozen=True)
42: class LensSpec:
43:     key: str
44:     title_en: str
45:     title_zh: str
46:     why_en: str
47:     why_zh: str
48:     source_key: str
49:     metric: str | None = None
50:     unit: str = ""
51: 
52: 
53: @dataclass(frozen=True)
54: class RegionSpec:
55:     cc: str
56:     route: str
57:     scope_en: str
58:     scope_zh: str
59:     central_bank: str
60:     central_bank_short: str
61:     index_label: str
62:     currency_label: str
63:     action_en: tuple[str, str, str]
64:     action_zh: tuple[str, str, str]
65:     transitions_en: tuple[str, str, str]
66:     transitions_zh: tuple[str, str, str]
67:     caveat_en: str
68:     caveat_zh: str
69:     sources: tuple[SourceSpec, ...]
70:     lenses: tuple[LensSpec, ...]
71: 
72: 
73: def _src(
74:     key: str,
75:     provider: str,
76:     url: str,
77:     cadence: str,
78:     access: str,
79:     licence: str,
80:     role: str,
81: ) -> SourceSpec:
82:     return SourceSpec(key, provider, url, cadence, access, licence, role)
83: 
84: 
85: COMMON_FRED = _src(
86:     "fred",
87:     "Federal Reserve Bank of St. Louis (official-source republisher)",
88:     "https://fred.stlouisfed.org/",
89:     "Source dependent",
90:     "Keyless CSV",
91:     "FRED terms; underlying series terms retained",
92:     "Operational fallback for OECD, Eurostat and central-bank series",
93: )
94: 
95: 
96: REGIONS: dict[str, RegionSpec] = {
97:     "JP": RegionSpec(
98:         cc="JP",
99:         route="japan.html",
100:         scope_en="Japan national economy; Nikkei 225 is market context, not the macro universe.",
101:         scope_zh="日本全国经济；日经225仅作市场背景，并非宏观统计范围。",
102:         central_bank="Bank of Japan",
103:         central_bank_short="BoJ",
104:         index_label="Nikkei 225",
105:         currency_label="USD/JPY",
106:         action_en=(
107:             "Keep duration and currency risk balanced while growth is soft and inflation pressure persists.",
108:             "Add cyclical risk only after wages, services inflation and activity confirm a cleaner expansion.",
109:             "Defend capital: favour quality balance sheets and avoid unhedged yen assumptions.",
110:         ),
111:         action_zh=(
112:             "增长偏软且通胀压力仍在时，均衡久期与汇率风险。",
113:             "仅在工资、服务通胀与经济活动共同确认更稳健扩张后增加周期风险。",
114:             "以保本为先：偏好优质资产负债表，避免无对冲日元假设。",
115:         ),
116:         transitions_en=(
117:             "Upgrade: activity and wage breadth turn positive while services inflation remains orderly.",
118:             "Policy turn: BoJ guidance and the JGB curve reprice together, not on one headline.",
119:             "Downgrade: yen stress, rising real yields and weaker production fire concurrently.",
120:         ),
121:         transitions_zh=(
122:             "上调：经济活动与工资广度转正，同时服务通胀保持有序。",
123:             "政策转折：日银指引与JGB曲线同步重定价，而非单一头条。",
124:             "下调：日元压力、实际收益率上升与工业生产走弱同时触发。",
125:         ),
126:         caveat_en="Japan CPI fallback coverage is stale; current inflation detail remains explicitly unavailable until the official adapter is production-verified.",
127:         caveat_zh="日本CPI备用序列已陈旧；在官方适配器通过生产验证前，当前通胀细项明确显示为不可用。",
128:         sources=(
129:             _src(
130:                 "boj",
131:                 "Bank of Japan",
132:                 "https://www.stat-search.boj.or.jp/ssi/mtshtml/m_en.html",
133:                 "Daily / monthly / quarterly",
134:                 "Keyless JSON/CSV API",
135:                 "BOJ statistical-data terms",
136:                 "Policy, Tankan, money, rates and balance of payments",
137:             ),
138:             _src(
139:                 "statjp",
140:                 "Statistics Bureau of Japan",
141:                 "https://www.stat.go.jp/english/data/index.html",
142:                 "Monthly / quarterly",
143:                 "Official downloads",
144:                 "Government statistics terms",
145:                 "CPI, labour and household spending",
146:             ),
147:             _src(
148:                 "caojp",
149:                 "Cabinet Office, Japan",
150:                 "https://www.esri.cao.go.jp/en/stat/menu.html",
151:                 "Monthly / quarterly",
152:                 "Official downloads",
153:                 "Government statistics terms",
154:                 "GDP, consumption and leading indicators",
155:             ),
156:             _src(
157:                 "metijp",
158:                 "Ministry of Economy, Trade and Industry",
159:                 "https://www.meti.go.jp/english/statistics/index.html",
160:                 "Monthly",
161:                 "Official downloads",
162:                 "Government statistics terms",
163:                 "Industrial production and services activity",
164:             ),
165:             _src(
166:                 "mofjp",
167:                 "Ministry of Finance, Japan",
168:                 "https://www.mof.go.jp/english/policy/international_policy/reference/balance_of_payments/index.htm",
169:                 "Monthly",
170:                 "Official downloads",
171:                 "Government statistics terms",
172:                 "Trade and external balance",
173:             ),
174:             COMMON_FRED,
175:         ),
176:         lenses=(
177:             LensSpec(
178:                 "policy",
179:                 "BoJ normalization",
180:                 "日银政策正常化",
181:                 "Separate a durable policy shift from meeting-day noise.",
182:                 "区分持久政策转变与会议日噪音。",
183:                 "boj",
184:                 "policy_rate",
185:                 "%",
186:             ),
187:             LensSpec(
188:                 "wages",
189:                 "Wages & services inflation",
190:                 "工资与服务通胀",
191:                 "The key test of a self-sustaining inflation cycle.",
192:                 "检验通胀周期能否自我维持的核心。",
193:                 "statjp",
194:             ),
195:             LensSpec(
196:                 "tankan",
197:                 "Tankan conditions",
198:                 "短观景气",
199:                 "Corporate pricing, capex and labour-intention breadth.",
200:                 "企业定价、资本开支与招聘意向广度。",
201:                 "boj",
202:             ),
203:             LensSpec(
204:                 "jgb",
205:                 "JGB curve",
206:                 "日本国债曲线",
207:                 "Transmission channel for normalization and bank duration risk.",
208:                 "政策正常化与银行久期风险的传导渠道。",
209:                 "boj",
210:                 "curve",
211:                 "pp",
212:             ),
213:             LensSpec(
214:                 "yen",
215:                 "Yen pressure",
216:                 "日元压力",
217:                 "Imported inflation, funding and foreign-flow pressure.",
218:                 "输入性通胀、融资与外资流动压力。",
219:                 "boj",
220:                 "fx",
221:                 "",
222:             ),
223:             LensSpec(
224:                 "production",
225:                 "Production & consumption",
226:                 "生产与消费",
227:                 "Tests whether domestic demand confirms the market tape.",
228:                 "检验内需是否确认市场走势。",
229:                 "metijp",
230:             ),
231:             LensSpec(
232:                 "external",
233:                 "Trade & current account",
234:                 "贸易与经常账户",
235:                 "Separates energy-import drag from export competitiveness.",
236:                 "区分能源进口拖累与出口竞争力。",
237:                 "mofjp",
238:             ),
239:         ),
240:     ),
241:     "KR": RegionSpec(
242:         cc="KR",
243:         route="south_korea.html",
244:         scope_en="Republic of Korea national economy; KOSPI is market context.",
245:         scope_zh="大韩民国全国经济；KOSPI仅作市场背景。",
246:         central_bank="Bank of Korea",
247:         central_bank_short="BOK",
248:         index_label="KOSPI",
249:         currency_label="USD/KRW",
250:         action_en=(
251:             "Stay balanced while exports and domestic credit send mixed signals.",
252:             "Add cyclical exposure only when export breadth and domestic demand improve together.",
253:             "Reduce leverage sensitivity: won stress and household credit can amplify a slowdown.",
254:         ),
255:         action_zh=(
256:             "出口与国内信用信号分化时保持均衡。",
257:             "仅在出口广度与内需同步改善时增加周期暴露。",
258:             "降低杠杆敏感度：韩元压力与家庭信贷可放大下行。",
259:         ),
260:         transitions_en=(
261:             "Upgrade: semiconductor/export momentum broadens into domestic demand.",
262:             "Policy turn: BOK easing arrives without renewed won or housing stress.",
263:             "Downgrade: exports roll over as household-credit and FX stress rise.",
264:         ),
265:         transitions_zh=(
266:             "上调：半导体/出口动能扩散至内需。",
267:             "政策转折：韩银宽松且未重新引发韩元或住房压力。",
268:             "下调：出口回落，同时家庭信贷与汇率压力上升。",
269:         ),
270:         caveat_en="BOK ECOS and KOSIS OpenAPI require registered API keys for reliable automation; the live plane uses explicit OECD/FRED fallbacks where configured.",
271:         caveat_zh="韩银ECOS与KOSIS OpenAPI的可靠自动化需要注册API密钥；当前数据层在已配置处明确使用OECD/FRED备用源。",
272:         sources=(
273:             _src(
274:                 "bok",
275:                 "Bank of Korea ECOS",
276:                 "https://ecos.bok.or.kr/",
277:                 "Daily / monthly / quarterly",
278:                 "Registered OpenAPI key",
279:                 "BOK ECOS terms",
280:                 "Policy, money, credit, rates, current account and FX",
281:             ),
282:             _src(
283:                 "kosis",
284:                 "KOSIS / Statistics Korea",
285:                 "https://kosis.kr/openapi/index/index.jsp",
286:                 "Monthly / quarterly",
287:                 "Registered OpenAPI key",
288:                 "KOSIS terms",
289:                 "CPI, labour, production, housing and population",
290:             ),
291:             _src(
292:                 "motie",
293:                 "Ministry of Trade, Industry and Energy",
294:                 "https://english.motie.go.kr/eng/contents/104",
295:                 "Monthly",
296:                 "Official releases",
297:                 "Government release terms",
298:                 "Exports, imports and industry",
299:             ),
300:             COMMON_FRED,
301:         ),
302:         lenses=(
303:             LensSpec(
304:                 "policy",
305:                 "BOK policy",
306:                 "韩银政策",
307:                 "Policy must balance inflation, FX and household leverage.",
308:                 "政策需平衡通胀、汇率与家庭杠杆。",
309:                 "bok",
310:                 "policy_rate",
311:                 "%",
312:             ),
313:             LensSpec(
314:                 "exports",
315:                 "Exports & semiconductors",
316:                 "出口与半导体",
317:                 "Korea’s fastest global-demand transmission channel.",
318:                 "韩国最敏感的全球需求传导渠道。",
319:                 "motie",
320:             ),
321:             LensSpec(
322:                 "won",
323:                 "Won pressure",
324:                 "韩元压力",
325:                 "A live funding, inflation and foreign-flow stress signal.",
326:                 "融资、通胀与外资流压力的实时信号。",
327:                 "bok",
328:                 "fx",
329:                 "",
330:             ),
331:             LensSpec(
332:                 "household",
333:                 "Household credit",
334:                 "家庭信贷",
335:                 "Leverage can mute consumption and constrain policy.",
336:                 "杠杆可抑制消费并约束政策。",
337:                 "bok",
338:             ),
339:             LensSpec(
340:                 "housing",
341:                 "Housing pulse",
342:                 "住房脉冲",
343:                 "Collateral and household-balance-sheet transmission.",
344:                 "抵押品与家庭资产负债表传导。",
345:                 "kosis",
346:             ),
347:             LensSpec(
348:                 "external",
349:                 "Current account",
350:                 "经常账户",
351:                 "Confirms whether export strength converts into external resilience.",
352:                 "确认出口强势是否转化为外部韧性。",
353:                 "bok",
354:             ),
355:         ),
356:     ),
357:     "EZ": RegionSpec(
358:         cc="EZ",
359:         route="euro_area.html",
360:         scope_en="Euro area aggregate (current EA21 composition), not the European Union. STOXX Europe 600 is broader market context only.",
361:         scope_zh="欧元区当前21国总量（EA21），并非欧盟整体。STOXX Europe 600仅作更广泛市场背景。",
362:         central_bank="European Central Bank",
363:         central_bank_short="ECB",
364:         index_label="Euro STOXX / Europe context",
365:         currency_label="EUR/USD",
366:         action_en=(
367:             "Hold balanced risk while disinflation helps but credit transmission remains restrictive.",
368:             "Add cyclical risk when activity breadth and bank lending turn together.",
369:             "Protect against fragmentation: watch sovereign spreads, energy and bank credit.",
370:         ),
371:         action_zh=(
372:             "通胀回落提供支持但信贷传导仍偏紧时，保持均衡风险。",
373:             "经济活动广度与银行贷款同步转强时增加周期风险。",
374:             "防范碎片化：关注主权利差、能源与银行信贷。",
375:         ),
376:         transitions_en=(
377:             "Upgrade: euro-area growth breadth improves as lending contraction bottoms.",
378:             "Policy turn: ECB easing transmits into household and business borrowing.",
379:             "Downgrade: periphery spreads, energy costs and credit stress rise together.",
380:         ),
381:         transitions_zh=(
382:             "上调：欧元区增长广度改善，贷款收缩见底。",
383:             "政策转折：欧洲央行宽松传导至家庭与企业借贷。",
384:             "下调：外围利差、能源成本与信贷压力同步上升。",
385:         ),
386:         caveat_en="The official unemployment adapter uses current EA21 composition. Legacy EA19/EA20 fallback series remain labelled in provenance until their current-composition official adapters are verified. Broader-Europe equity indexes never substitute for euro-area macro data.",
387:         caveat_zh="官方失业率适配器采用当前EA21口径。旧EA19/EA20备用序列在当前口径官方适配器验证完成前会在来源中明确标注；更广泛欧洲股票指数绝不替代欧元区宏观数据。",
388:         sources=(
389:             _src(
390:                 "ecb",
391:                 "European Central Bank Data Portal",
392:                 "https://data.ecb.europa.eu/help/api/data",
393:                 "Daily / monthly / quarterly",
394:                 "Keyless SDMX API",
395:                 "ECB copyright and reuse policy",
396:                 "Policy, rates, money, credit, bank lending and external balance",
397:             ),
398:             _src(
399:                 "eurostat",
400:                 "Eurostat",
401:                 "https://ec.europa.eu/eurostat/web/user-guides/data-browser/api-data-access/api-introduction",
402:                 "Twice-daily API refresh; release dependent",
403:                 "Keyless Statistics and SDMX APIs",
404:                 "European Commission reuse decision",
405:                 "Euro-area HICP, GDP, labour, industry and trade",
406:             ),
407:             _src(
408:                 "ec",
409:                 "European Commission",
410:                 "https://economy-finance.ec.europa.eu/economic-forecast-and-surveys/business-and-consumer-surveys_en",
411:                 "Monthly / quarterly",
412:                 "Official downloads",
413:                 "European Commission reuse policy",
414:                 "Business surveys and fiscal context",
415:             ),
416:             COMMON_FRED,
417:         ),
418:         lenses=(
419:             LensSpec(
420:                 "policy",
421:                 "ECB transmission",
422:                 "欧洲央行传导",
423:                 "The rate path matters only if financing conditions follow.",
424:                 "只有融资条件跟随，利率路径才有意义。",
425:                 "ecb",
426:                 "policy_rate",
427:                 "%",
428:             ),
429:             LensSpec(
430:                 "hicp",
431:                 "HICP core/services",
432:                 "核心/服务HICP",
433:                 "Tests whether disinflation is broad enough for durable easing.",
434:                 "检验通胀回落是否足够广泛以支持持续宽松。",
435:                 "eurostat",
436:                 "cpi_yoy",
437:                 "% y/y",
438:             ),
439:             LensSpec(
440:                 "credit",
441:                 "Bank lending & credit",
442:                 "银行贷款与信贷",
443:                 "The euro area’s dominant private-sector transmission channel.",
444:                 "欧元区私人部门的主要传导渠道。",
445:                 "ecb",
446:             ),
447:             LensSpec(
448:                 "spreads",
449:                 "Sovereign spreads",
450:                 "主权利差",
451:                 "Fragmentation risk can tighten conditions unevenly.",
452:                 "碎片化风险可导致各国金融条件不均衡收紧。",
453:                 "ecb",
454:             ),
455:             LensSpec(
456:                 "energy",
457:                 "Energy sensitivity",
458:                 "能源敏感度",
459:                 "Separates imported cost shocks from domestic inflation.",
460:                 "区分输入性成本冲击与国内通胀。",
461:                 "eurostat",
462:             ),
463:             LensSpec(
464:                 "external",
465:                 "External balance",
466:                 "外部平衡",
467:                 "Tracks competitiveness and imported-energy drag.",
468:                 "追踪竞争力与能源进口拖累。",
469:                 "ecb",
470:             ),
471:         ),
472:     ),
473:     "GB": RegionSpec(
474:         cc="GB",
475:         route="united_kingdom.html",
476:         scope_en="United Kingdom national economy; FTSE 100 and FTSE 250 are market context.",
477:         scope_zh="英国全国经济；富时100与富时250仅作市场背景。",
478:         central_bank="Bank of England",
479:         central_bank_short="BoE",
480:         index_label="FTSE 100 / FTSE 250",
481:         currency_label="GBP/USD",
482:         action_en=(
483:             "Stay selective while sticky services inflation offsets improving growth.",
484:             "Add domestic cyclicals when real wages, housing and credit improve without reflation.",
485:             "Cut rate-sensitive risk if gilt, mortgage and sterling stress reinforce each other.",
486:         ),
487:         action_zh=(
488:             "服务通胀黏性抵消增长改善时保持精选。",
489:             "实际工资、住房与信贷改善且未再通胀时增加国内周期风险。",
490:             "若国债、按揭与英镑压力相互强化，降低利率敏感风险。",
491:         ),
492:         transitions_en=(
493:             "Upgrade: real-wage gains broaden into consumption and housing stabilization.",
494:             "Policy turn: services inflation and wage growth cool enough for durable BoE easing.",
495:             "Downgrade: gilt yields and mortgage resets tighten into weaker labour demand.",
496:         ),
497:         transitions_zh=(
498:             "上调：实际工资增长扩散至消费与住房企稳。",
499:             "政策转折：服务通胀与工资增速降温，支持持续降息。",
500:             "下调：国债收益率与按揭重定价收紧，并传导至劳动力需求走弱。",
501:         ),
502:         caveat_en="ONS labour-market estimates carry survey-response and methodology uncertainty; the dashboard treats labour as one input, not a standalone trigger.",
503:         caveat_zh="ONS劳动力市场估计受调查回复率与方法变化影响；本看板将就业视为一项输入，而非独立触发器。",
504:         sources=(
505:             _src(
506:                 "boe",
507:                 "Bank of England",
508:                 "https://www.bankofengland.co.uk/boeapps/database/",
509:                 "Daily / monthly",
510:                 "Official IADB downloads",
511:                 "BoE terms of use",
512:                 "Policy, SONIA, gilt curve, money, credit and mortgages",
513:             ),
514:             _src(
515:                 "ons",
516:                 "Office for National Statistics",
517:                 "https://developer.ons.gov.uk/",
518:                 "Release dependent",
519:                 "Keyless v1 beta API",
520:                 "Open Government Licence",
521:                 "CPI, wages, labour, GDP, production, trade and housing",
522:             ),
523:             _src(
524:                 "obr",
525:                 "Office for Budget Responsibility",
526:                 "https://obr.uk/data/",
527:                 "Forecast-event dependent",
528:                 "Official downloads",
529:                 "Open Government Licence",
530:                 "Fiscal context and forecast assumptions",
531:             ),
532:             COMMON_FRED,
533:         ),
534:         lenses=(
535:             LensSpec(
536:                 "policy",
537:                 "BoE policy",
538:                 "英央行政策",
539:                 "Services inflation and wages dominate the reaction function.",
540:                 "服务通胀与工资主导政策反应函数。",
541:                 "boe",
542:                 "policy_rate",
543:                 "%",
544:             ),
545:             LensSpec(
546:                 "services",
547:                 "Services inflation",
548:                 "服务通胀",
549:                 "The clearest domestic persistence test.",
550:                 "最清晰的国内通胀黏性检验。",
551:                 "ons",
552:                 "cpi_yoy",
553:                 "% y/y",
554:             ),
555:             LensSpec(
556:                 "wages",
557:                 "Wage growth",
558:                 "工资增长",
559:                 "Real-income support versus persistence risk.",
560:                 "实际收入支持与通胀黏性风险的平衡。",
561:                 "ons",
562:             ),
563:             LensSpec(
564:                 "gilts",
565:                 "Gilt curve",
566:                 "英国国债曲线",
567:                 "Links policy, fiscal risk and mortgage pricing.",
568:                 "连接货币政策、财政风险与按揭定价。",
569:                 "boe",
570:                 "curve",
571:                 "pp",
572:             ),
573:             LensSpec(
574:                 "housing",
575:                 "Housing & mortgages",
576:                 "住房与按揭",
577:                 "A high-frequency household cash-flow transmission channel.",
578:                 "家庭现金流的高频传导渠道。",
579:                 "boe",
580:             ),
581:             LensSpec(
582:                 "fiscal",
583:                 "Fiscal context",
584:                 "财政背景",
585:                 "Supply, taxes and issuance can alter the rate path.",
586:                 "供给、税收与发债可改变利率路径。",
587:                 "obr",
588:             ),
589:             LensSpec(
590:                 "sterling",
591:                 "Sterling",
592:                 "英镑",
593:                 "Imported inflation and cross-border confidence signal.",
594:                 "输入性通胀与跨境信心信号。",
595:                 "boe",
596:                 "fx",
597:                 "",
598:             ),
599:         ),
600:     ),
601:     "IN": RegionSpec(
602:         cc="IN",
603:         route="india.html",
604:         scope_en="India national economy; Nifty 50 and Sensex are market context.",
605:         scope_zh="印度全国经济；Nifty 50与Sensex仅作市场背景。",
606:         central_bank="Reserve Bank of India",
607:         central_bank_short="RBI",
608:         index_label="Nifty 50 / Sensex",
609:         currency_label="USD/INR",
610:         action_en=(
611:             "Keep growth exposure balanced against food inflation, liquidity and rupee risk.",
612:             "Add cyclicals when industrial activity, credit quality and rural demand broaden together.",
613:             "Reduce leverage if food inflation, liquidity tightness and rupee pressure become concurrent.",
614:         ),
615:         action_zh=(
616:             "在增长暴露与食品通胀、流动性及卢比风险之间保持平衡。",
617:             "工业活动、信贷质量与农村需求同步扩散时增加周期风险。",
618:             "若食品通胀、流动性收紧与卢比压力同时出现，降低杠杆。",
619:         ),
620:         transitions_en=(
621:             "Upgrade: IIP, private credit and consumption broaden beyond public capex.",
622:             "Policy turn: food inflation cools enough for RBI easing without rupee stress.",
623:             "Downgrade: monsoon/food shock, tighter liquidity and weaker external balance coincide.",
624:         ),
625:         transitions_zh=(
626:             "上调：工业生产、私人信贷与消费扩散至公共资本开支之外。",
627:             "政策转折：食品通胀降温，支持RBI宽松且不引发卢比压力。",
628:             "下调：季风/食品冲击、流动性收紧与外部平衡走弱同时出现。",
629:         ),
630:         caveat_en="India’s official data are distributed across MoSPI and RBI systems. Until each adapter passes release-period and unit checks, unavailable fields remain blank rather than backfilled with unrelated proxies.",
631:         caveat_zh="印度官方数据分布于MoSPI与RBI系统。在各适配器通过发布期与单位检查前，不可用字段保持空白，不以无关代理补填。",
632:         sources=(
633:             _src(
634:                 "mospi",
635:                 "Ministry of Statistics and Programme Implementation",
636:                 "https://api.mospi.gov.in/",
637:                 "Monthly / quarterly",
638:                 "Official CPI API and eSankhyiki client",
639:                 "Government data terms",
640:                 "CPI, IIP, GDP and labour",
641:             ),
642:             _src(
643:                 "rbi",
644:                 "Reserve Bank of India DBIE",
645:                 "https://data.rbi.org.in/DBIE/",
646:                 "Daily / weekly / monthly",
647:                 "Official downloads",
648:                 "RBI database terms",
649:                 "Policy, liquidity, credit, rates, reserves and external balance",
650:             ),
651:             _src(
652:                 "commercein",
653:                 "Ministry of Commerce and Industry",
654:                 "https://tradestat.commerce.gov.in/",
655:                 "Monthly",
656:                 "Official downloads",
657:                 "Government data terms",
658:                 "Merchandise trade and WPI context",
659:             ),
660:             _src(
661:                 "imd",
662:                 "India Meteorological Department",
663:                 "https://mausam.imd.gov.in/",
664:                 "Daily / seasonal",
665:                 "Official bulletins",
666:                 "Government data terms",
667:                 "Monsoon timing and rainfall",
668:             ),
669:             COMMON_FRED,
670:         ),
671:         lenses=(
672:             LensSpec(
673:                 "policy",
674:                 "RBI policy & liquidity",
675:                 "RBI政策与流动性",
676:                 "The stance is the rate plus banking-system liquidity.",
677:                 "政策立场由利率与银行体系流动性共同决定。",
678:                 "rbi",
679:                 "policy_rate",
680:                 "%",
681:             ),
682:             LensSpec(
683:                 "food",
684:                 "Food inflation",
685:                 "食品通胀",
686:                 "The main volatility channel into household purchasing power.",
687:                 "影响家庭购买力的主要波动渠道。",
688:                 "mospi",
689:                 "cpi_yoy",
690:                 "% y/y",
691:             ),
692:             LensSpec(
693:                 "wpi",
694:                 "WPI pipeline",
695:                 "WPI价格链",
696:                 "Tracks input-cost pressure before consumer pass-through.",
697:                 "追踪传导至消费者前的投入成本压力。",
698:                 "commercein",
699:             ),
700:             LensSpec(
701:                 "monsoon",
702:                 "Monsoon sensitivity",
703:                 "季风敏感度",
704:                 "Affects food supply, rural income and inflation tails.",
705:                 "影响食品供给、农村收入与通胀尾部。",
706:                 "imd",
707:             ),
708:             LensSpec(
709:                 "iip",
710:                 "Industrial production",
711:                 "工业生产",
712:                 "Tests whether capex and manufacturing breadth are durable.",
713:                 "检验资本开支与制造业广度是否持久。",
714:                 "mospi",
715:             ),
716:             LensSpec(
717:                 "credit",
718:                 "Credit & liquidity",
719:                 "信贷与流动性",
720:                 "Separates healthy expansion from funding pressure.",
721:                 "区分健康扩张与融资压力。",
722:                 "rbi",
723:             ),
724:             LensSpec(
725:                 "external",
726:                 "Rupee, reserves & external balance",
727:                 "卢比、储备与外部平衡",
728:                 "The buffer against oil and global-funding shocks.",
729:                 "抵御油价与全球融资冲击的缓冲。",
730:                 "rbi",
731:                 "fx",
732:                 "",
733:             ),
734:             LensSpec(
735:                 "fiscal",
736:                 "Fiscal capex",
737:                 "财政资本开支",
738:                 "Distinguishes public-investment impulse from private breadth.",
739:                 "区分公共投资脉冲与私人部门广度。",
740:                 "mospi",
741:             ),
742:         ),
743:     ),
744: }
745: 
746: ROUTES = {cc: spec.route for cc, spec in REGIONS.items()}
747: 
748: METRIC_LABELS: dict[str, tuple[str, str, str]] = {
749:     "cpi_yoy": ("Inflation", "通胀", "% y/y"),
750:     "gdp_yoy": ("Real growth", "实际增长", "% y/y"),
751:     "unemployment": ("Unemployment", "失业率", "%"),
752:     "yield_10y": ("10-year yield", "10年期收益率", "%"),
753:     "policy_rate": ("Policy / short rate", "政策/短端利率", "%"),
754:     "curve": ("10y minus short rate", "10年期减短端", "pp"),
755:     "fx": ("FX reference", "汇率参考", ""),
756:     "fx_strength_3m": ("Currency strength, 3m", "货币强弱，3个月", "%"),
757:     "drawdown": ("Index from 52w high", "指数距52周高点", "%"),
758:     "realvol": ("Realized volatility", "实现波动率", "%"),
759: }
760: 
761: 
762: def _finite(value: Any) -> float | None:
763:     try:
764:         value = float(value)
765:         return value if pd.notna(value) else None
766:     except (TypeError, ValueError):
767:         return None
768: 
769: 
770: def _score_parts(
771:     growth: Any,
772:     inflation: Any,
773:     recession: Any,
774:     liquidity: str | None,
775:     risk_state: str | None = None,
776: ) -> dict[str, float]:
777:     """Return transparent descriptive score components.
778: 
779:     The macro history can reproduce the first four terms.  The current score adds
780:     a small, separately labelled risk-radar state adjustment.
781:     """
782:     growth_v = _finite(growth) or 0.0
783:     inflation_v = _finite(inflation) or 0.0
784:     recession_v = _finite(recession)
785:     liquidity_adj = {"expanding": 5.0, "contracting": -5.0}.get(str(liquidity), 0.0)
786:     risk_adj = {"risk": -8.0, "caution": -4.0, "clear": 2.0}.get(str(risk_state), 0.0)
787:     return {
788:         "base": 50.0,
789:         "growth": round(growth_v * 22.0, 2),
790:         "inflation": round(-max(inflation_v, 0.0) * 10.0, 2),
791:         "recession": round(-(recession_v or 0.0) * 0.18, 2),
792:         "liquidity": liquidity_adj,
793:         "risk_state": risk_adj,
794:     }
795: 
796: 
797: def decision_score(record: dict[str, Any]) -> tuple[int, dict[str, float]]:
798:     radar = record.get("risk_radar") or {}
799:     parts = _score_parts(
800:         record.get("growth_score"),
801:         record.get("inflation_score"),
802:         record.get("recession_score"),
803:         record.get("liquidity"),
804:         radar.get("state") if "composition" not in radar else None,
805:     )
806:     return round(max(0.0, min(100.0, sum(parts.values())))), parts
807: 
808: 
809: def _score_state(score: int) -> tuple[str, str, str]:
810:     if score >= 64:
811:         return "constructive", "Constructive", "积极"
812:     if score >= 45:
813:         return "balanced", "Balanced", "均衡"
814:     return "defensive", "Defensive", "防御"
815: 
816: 
817: def _spark(history: pd.DataFrame | None) -> dict[str, Any]:
818:     if history is None or history.empty:
819:         return {"values": [], "points": "", "min": None, "max": None}
820:     d = history.tail(60).copy()
821:     values: list[int] = []
822:     dates: list[str] = []
823:     for idx, row in d.iterrows():
824:         parts = _score_parts(
825:             row.get("growth_score"),
826:             row.get("inflation_score"),
827:             row.get("recession_score"),
828:             row.get("liquidity"),
829:         )
830:         values.append(round(max(0.0, min(100.0, sum(parts.values())))))
831:         dates.append(str(pd.Timestamp(idx).date()))
832:     if len(values) == 1:
833:         points = "0,50 100,50"
834:     else:
835:         points = " ".join(
836:             f"{i * 100 / (len(values) - 1):.2f},{100 - v:.2f}"
837:             for i, v in enumerate(values)
838:         )
839:     return {
840:         "values": values,
841:         "dates": dates,
842:         "points": points,
843:         "min": min(values) if values else None,
844:         "max": max(values) if values else None,
845:         "start": dates[0] if dates else None,
846:         "end": dates[-1] if dates else None,
847:     }
848: 
849: 
850: def _parse_period(raw: Any) -> date | None:
851:     if raw in (None, ""):
852:         return None
853:     try:
854:         text = str(raw)
855:         if len(text) == 7:
856:             text += "-01"
857:         elif len(text) == 4:
858:             text += "-01-01"
859:         return datetime.fromisoformat(text[:10]).date()
860:     except (TypeError, ValueError):
861:         return None
862: 
863: 
864: def _health(metric: str, asof: Any, today: date) -> dict[str, Any]:
865:     parsed = _parse_period(asof)
866:     if parsed is None:
867:         return {"metric": metric, "asof": None, "age_days": None, "state": "missing"}
868:     age = max(0, (today - parsed).days)
869:     threshold = 160 if metric == "gdp" else 80
870:     return {
871:         "metric": metric,
872:         "asof": str(asof),
873:         "age_days": age,
874:         "state": "fresh" if age <= threshold else "stale",
875:     }
876: 
877: 
878: def _format_value(value: Any, unit: str) -> str:
879:     v = _finite(value)
880:     if v is None:
881:         return "Unavailable"
882:     if abs(v) >= 100:
883:         text = f"{v:,.2f}"
884:     else:
885:         text = f"{v:.2f}"
886:     return f"{text}{unit}" if unit else text
887: 
888: 
889: def _events(spec: RegionSpec, today: date) -> list[dict[str, Any]]:
890:     path = config.data_dir() / "intl_risk" / "cb_calendar.yml"
891:     if not path.exists():
892:         return []
893:     raw = yaml.safe_load(path.read_text()) or {}
894:     out: list[dict[str, Any]] = []
895:     for bank_key, bank in (raw.get("banks") or {}).items():
896:         if bank.get("country") not in {spec.cc, "XM" if spec.cc == "EZ" else spec.cc}:
897:             continue
898:         for raw_date in bank.get("dates") or []:
899:             event_date = _parse_period(raw_date)
900:             if event_date is None:
901:                 continue
902:             if event_date < today:
903:                 state, outcome = (
904:                     "released",
905:                     "Decision date passed — verify the official release",
906:                 )
907:             elif event_date == today:
908:                 state, outcome = "today", "Decision due today"
909:             else:
910:                 state, outcome = "upcoming", "Scheduled — no outcome yet"
911:             out.append(
912:                 {
913:                     "date": event_date.isoformat(),
914:                     "bank": bank_key,
915:                     "name_en": bank.get("name_en", bank_key),
916:                     "name_zh": bank.get("name_zh", bank_key),
917:                     "state": state,
918:                     "outcome_en": outcome,
919:                     "outcome_zh": {
920:                         "released": "决议日期已过——请核对官方发布",
921:                         "today": "决议今日公布",
922:                         "upcoming": "已排期——尚无结果",
923:                     }[state],
924:                     "source": bank.get("source"),
925:                 }
926:             )
927:     out.sort(key=lambda item: item["date"])
928:     past = [item for item in out if item["state"] == "released"][-2:]
929:     current = [item for item in out if item["state"] != "released"][:5]
930:     return past + current
931: 
932: 
933: def build_country_view(
934:     record: dict[str, Any],
935:     history: pd.DataFrame | None = None,
936:     *,
937:     today: date | None = None,
938: ) -> dict[str, Any]:
939:     cc = str(record.get("cc") or "")
940:     if cc not in REGIONS:
941:         raise KeyError(f"unsupported international macro dashboard: {cc}")
942:     spec = REGIONS[cc]
943:     today = today or datetime.now(timezone.utc).date()
944:     score, parts = decision_score(record)
945:     state_key, state_en, state_zh = _score_state(score)
946:     state_index = {"constructive": 1, "balanced": 0, "defensive": 2}[state_key]
947:     macro = record.get("macro") or {}
948:     macro_asof = record.get("macro_asof") or {}
949:     radar = record.get("risk_radar") or {}
950:     modern = "composition" in radar
951:     drawdown_prob = {} if modern else (radar.get("drawdown_prob") or {})
952:     from copy import deepcopy
953:     composition_fields = {"composition": deepcopy(radar["composition"])} if modern else {}
954: 
955:     metrics = []
956:     for key in (
957:         "cpi_yoy",
958:         "gdp_yoy",
959:         "unemployment",
960:         "yield_10y",
961:         "policy_rate",
962:         "curve",
963:         "fx",
964:         "fx_strength_3m",
965:         "drawdown",
966:         "realvol",
967:     ):
968:         en, zh, unit = METRIC_LABELS[key]
969:         raw = macro.get(key)
970:         metrics.append(
971:             {
972:                 "key": key,
973:                 "label_en": en,
974:                 "label_zh": zh,
975:                 "raw": _finite(raw),
976:                 "value": _format_value(raw, unit),
977:                 "unit": unit,
978:                 "asof": macro_asof.get("gdp" if key == "gdp_yoy" else key),
979:             }
980:         )
981: 
982:     source_by_key = {source.key: source for source in spec.sources}
983:     lenses = []
984:     for lens in spec.lenses:
985:         source = source_by_key[lens.source_key]
986:         raw_value = macro.get(lens.metric) if lens.metric else None
987:         lenses.append(
988:             {
989:                 "key": lens.key,
990:                 "title_en": lens.title_en,
991:                 "title_zh": lens.title_zh,
992:                 "why_en": lens.why_en,
993:                 "why_zh": lens.why_zh,
994:                 "value": _format_value(raw_value, lens.unit)
995:                 if lens.metric
996:                 else "Awaiting verified official adapter",
997:                 "available": _finite(raw_value) is not None if lens.metric else False,
998:                 "metric": lens.metric,
999:                 "source_key": source.key,
1000:                 "source": source.provider,
1001:                 "source_url": source.url,
1002:             }
1003:         )
1004: 
1005:     health = []
1006:     for metric in ("cpi_yoy", "gdp", "unemployment", "yield_10y"):
1007:         item = _health(metric, macro_asof.get(metric), today)
1008:         item["label_en"] = {
1009:             "cpi_yoy": "Inflation",
1010:             "gdp": "Growth",
1011:             "unemployment": "Labour",
1012:             "yield_10y": "Rates",
1013:         }[metric]
1014:         item["label_zh"] = {
1015:             "cpi_yoy": "通胀",
1016:             "gdp": "增长",
1017:             "unemployment": "就业",
1018:             "yield_10y": "利率",
1019:         }[metric]
1020:         health.append(item)
1021: 
1022:     source_rows = []
1023:     for source in spec.sources:
1024:         is_fallback = source.key == "fred"
1025:         source_rows.append(
1026:             {
1027:                 "key": source.key,
1028:                 "provider": source.provider,
1029:                 "url": source.url,
1030:                 "cadence": source.cadence,
1031:                 "access": source.access,
1032:                 "licence": source.licence,
1033:                 "role": source.role,
1034:                 "status": "active fallback"
1035:                 if is_fallback
1036:                 else "authoritative target / active where mapped",
1037:             }
1038:         )
1039: 
1040:     return {
1041:         "schema": SCHEMA,
1042:         "route": spec.route,
1043:         "cc": cc,
1044:         # The comparative engine's legacy label is "Eurozone"; the first-class
1045:         # route uses the official/product scope name "Euro Area".
1046:         "name": "Euro Area" if cc == "EZ" else record.get("name"),
1047:         "name_zh": "欧元区" if cc == "EZ" else record.get("name_zh"),
1048:         "flag": record.get("flag"),
1049:         "scope_en": spec.scope_en,
1050:         "scope_zh": spec.scope_zh,
1051:         "asof": record.get("date"),
1052:         "built": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
1053:         "regime": {
1054:             "quad": record.get("quad"),
1055:             "name": record.get("quad_name"),
1056:             "growth_score": record.get("growth_score"),
1057:             "inflation_score": record.get("inflation_score"),
1058:             "confidence": record.get("confidence"),
1059:             "liquidity": record.get("liquidity"),
1060:             "recession_score": record.get("recession_score"),
1061:             "recession_band": record.get("recession_band"),
1062:             "data_limited": bool(record.get("data_limited")),
1063:         },
1064:         "decision": {
1065:             "score": score,
1066:             "state": state_key,
1067:             "state_en": state_en,
1068:             "state_zh": state_zh,
1069:             "action_en": spec.action_en[state_index],
1070:             "action_zh": spec.action_zh[state_index],
1071:             "transitions_en": spec.transitions_en,
1072:             "transitions_zh": spec.transitions_zh,
1073:             "parts": parts,
1074:             "method_en": ("Growth, inflation, recession stress and liquidity. Risk observations remain separate; no calibrated forecast is available." if modern else "50 + growth impulse − inflation pressure − recession stress + liquidity + current calibrated-risk state. Descriptive, not a forecast."),
1075:             "method_zh": ("综合增长、通胀、衰退压力与流动性；风险观测单独呈现，当前不提供经校准的预测。" if modern else "50 + 增长脉冲 − 通胀压力 − 衰退压力 + 流动性 + 当前校准风险状态。仅作描述，不是预测。"),
1076:         },
1077:         "history": _spark(history),
1078:         "market": {
1079:             "index_label": spec.index_label,
1080:             "currency_label": spec.currency_label,
1081:             "equity": record.get("equity") or {},
1082:         },
1083:         "policy": {
1084:             "bank": spec.central_bank,
1085:             "short": spec.central_bank_short,
1086:             "rate": _finite(macro.get("policy_rate")),
1087:             "curve": _finite(macro.get("curve")),
1088:         },
1089:         "risk": {
1090:             "state": radar.get("state"),
1091:             "top_score": radar.get("top_score"),
1092:             "dominant_en": radar.get("dominant_label_en"),
1093:             "dominant_zh": radar.get("dominant_label_zh"),
1094:             "h21": _finite(drawdown_prob.get("h21")),
1095:             "measure": drawdown_prob.get("measure"),
1096:             "trajectory": radar.get("trajectory") or {},
1097:             "scares": radar.get("scares") or [],
1098:             "calibrated": _finite(drawdown_prob.get("h21")) is not None,
1099:             **composition_fields,
1100:         },
1101:         "metrics": metrics,
1102:         "lenses": lenses,
1103:         "events": _events(spec, today),
1104:         "health": health,
1105:         "sources": source_rows,
1106:         "caveat_en": spec.caveat_en,
1107:         "caveat_zh": spec.caveat_zh,
1108:         "navigation": [
1109:             {
1110:                 "cc": other.cc,
1111:                 "name": REGIONS[other.cc]
1112:                 .route.replace(".html", "")
1113:                 .replace("_", " ")
1114:                 .title(),
1115:                 "route": other.route,
1116:                 "active": other.cc == cc,
1117:             }
1118:             for other in REGIONS.values()
1119:         ],
1120:     }
1121: 
1122: 
1123: def load_history(cc: str) -> pd.DataFrame | None:
1124:     path = config.data_dir() / "intl_regime" / f"{cc}_history.parquet"
1125:     if not path.exists():
1126:         return None
1127:     try:
1128:         return pd.read_parquet(path)
1129:     except Exception:  # noqa: BLE001 — a missing parquet engine/history degrades the chart
1130:         return None
1131: 
1132: 
1133: def validate_view(view: dict[str, Any]) -> None:
1134:     """Small runtime contract check used by the builder and tests."""
1135:     if view.get("schema") != SCHEMA:
1136:         raise ValueError("unexpected international macro dashboard schema")
1137:     if view.get("cc") not in REGIONS:
1138:         raise ValueError("unknown country code")
1139:     score = (view.get("decision") or {}).get("score")
1140:     if not isinstance(score, int) or not 0 <= score <= 100:
1141:         raise ValueError("decision score must be an integer in [0, 100]")
1142:     if not view.get("metrics") or not view.get("sources") or not view.get("lenses"):
1143:         raise ValueError("dashboard view is missing required evidence planes")
1144: 
1145: 
1146: def source_catalog() -> dict[str, list[dict[str, str]]]:
1147:     """Serializable source registry for documentation/health tooling."""
1148:     return {
1149:         cc: [
1150:             {
1151:                 "key": source.key,
1152:                 "provider": source.provider,
1153:                 "url": source.url,
1154:                 "cadence": source.cadence,
1155:                 "access": source.access,
1156:                 "licence": source.licence,
1157:                 "role": source.role,
1158:             }
1159:             for source in spec.sources
1160:         ]
1161:         for cc, spec in REGIONS.items()
1162:     }
```

## COMPLETE CANDIDATE SOURCE: engine/intl_run.py
```
1: """International dashboard engine entrypoint: per-country features -> uniform
2: regime classification -> cross-country comparison -> data/intl/latest.json (+
3: per-country regime history parquets for the charts). Recomputes full history each
4: run so live == backtest. Every read is descriptive / display-only.
5: """
6: from __future__ import annotations
7: 
8: import json
9: import logging
10: 
11: import pandas as pd
12: 
13: from engine import intl_compare, intl_equity_risk, intl_inputs
14: from engine.intl_regime import classify, recession_band
15: from lib import config
16: 
17: log = logging.getLogger(__name__)
18: 
19: _RADAR_KEYS = {"JP": "jp", "KR": "kr", "TW": "tw", "IN": "in", "AU": "au", "GB": "gb", "EZ": "ez"}
20: 
21: 
22: def _ledger_lane_armed() -> bool:
23:     """True only on the nightly collect lane (COLLECT_LANE=nightly, legacy alias
24:     US_LANE). House law: nightly is the SOLE advancer of data/ forward ledgers —
25:     sentinel intraday (CBF_INTRADAY=1) and the engine-render/render re-render lanes
26:     run build_intl too; on those lanes the radar snapshot still renders but the
27:     forward log / tuner must not advance (a mid-session append is PIT-inconsistent
28:     and, being idempotent-by-asof, would permanently displace the nightly row).
29:     Canonical implementation lives with the ledger writer it guards
30:     (engine.risk_radar_intl_audit.ledger_lane_armed); CN/HK/CA builds share it."""
31:     from engine.risk_radar_intl_audit import ledger_lane_armed
32:     return ledger_lane_armed()
33: 
34: 
35: def _macro_present(snap: dict) -> int:
36:     return sum(1 for k in ("yield_10y", "cpi_yoy", "gdp_yoy", "unemployment")
37:               if snap.get(k) is not None)
38: 
39: 
40: def country_record(cc: str, closes: pd.DataFrame, macro: pd.DataFrame,
41:                    equity: dict) -> tuple[dict | None, pd.DataFrame | None]:
42:     c = intl_inputs.countries()[cc]
43:     f = intl_inputs.country_frame(cc, closes, macro)
44:     if f.empty:
45:         return None, None
46:     reg = classify(f)
47:     asof = reg["quad"].last_valid_index()
48:     if asof is None:
49:         return None, None
50:     row = reg.loc[asof]
51:     snap = intl_inputs.latest_macro_snapshot(cc, f)
52:     g_n = int(row.get("growth_n_components", 0) or 0)
53:     i_n = int(row.get("inflation_n_components", 0) or 0)
54:     rec_score = float(row["recession_score"]) if pd.notna(row.get("recession_score")) else None
55: 
56:     record = {
57:         "cc": cc, "name": c["name"], "name_zh": c.get("name_zh", c["name"]),
58:         "flag": c["flag"], "region": c.get("region"),
59:         "date": str(asof.date()),
60:         "quad": row["quad"], "quad_name": row["quad_name"],
61:         "growth_score": round(float(row["growth_score"]), 3),
62:         "inflation_score": round(float(row["inflation_score"]), 3),
63:         "confidence": round(float(row["regime_confidence"]), 3),
64:         "liquidity": row["liquidity"],
65:         "recession_score": round(rec_score, 0) if rec_score is not None else None,
66:         "recession_band": recession_band(rec_score),
67:         "macro": snap,
68:         "macro_asof": intl_inputs.macro_freshness(cc, macro),
69:         "equity": equity.get(cc, {}),
70:         "data_limited": bool(g_n < 2 or i_n < 2 or _macro_present(snap) < 2),
71:     }
72:     hist = reg[[col for col in reg.columns if not str(col).startswith("c_")]]
73:     return record, hist
74: 
75: 
76: def run() -> dict:
77:     closes = intl_inputs._intl_closes()
78:     macro = intl_inputs._macro_frame()
79:     equity = intl_equity_risk.equity_risk_all()
80:     if closes.empty:
81:         raise RuntimeError("no intl price data in store — run collectors first")
82: 
83:     p = config.data_dir() / "intl_regime"
84:     p.mkdir(parents=True, exist_ok=True)
85: 
86:     records: list[dict] = []
87:     for cc in intl_inputs.countries():
88:         try:
89:             rec, hist = country_record(cc, closes, macro, equity)
90:         except Exception as e:  # noqa: BLE001 — one country can't kill the board
91:             log.warning("intl: %s record failed: %s", cc, e)
92:             continue
93:         if rec is None:
94:             continue
95:         records.append(rec)
96:         if hist is not None:
97:             hist.to_parquet(p / f"{cc}_history.parquet")
98:         # Leading-risk radar (engine/risk_radar_intl.py): calibrated forward-drawdown
99:         # radar per market — US rate shocks + FX depreciation + extension percentile
100:         # (melt-up/KOSPI class). Display-only until this market's own forward log
101:         # matures (can_force); append is idempotent by as-of (nightly is the sole
102:         # advancer; re-render lanes dedupe). Never fatal.
103:         # The snapshot is persisted ADDITIVELY as rec["risk_radar"] and is read by
104:         # engine/risk_radar_intl_audit (forward_log) and by the five international
105:         # dashboards, which render it as the shared .rrx Risk Radar card
106:         # (scripts/build_international_macro._radar_display -> market_state._radar_to_rd).
107:         # A market that raises below keeps its record and simply renders no card.
108:         try:
109:             from engine import risk_radar_intl as _rri
110:             _prof = _rri.PROFILES.get(_RADAR_KEYS.get(cc, ""))
111:             if _prof is not None:
112:                 rec["risk_radar"] = _rri.snapshot(_prof)
113:                 try:
114:                     from engine import risk_radar_intl_audit as _rra
115:                     if _ledger_lane_armed():
116:                         from engine import risk_radar_intl_tune as _rrt
117:                         rec["risk_radar"]["forward_log"] = _rra.snapshot_and_grade(rec["risk_radar"], _prof)
118:                         rec["risk_radar"]["can_force"] = _rra.force_applicable_for_snapshot(rec["risk_radar"], bool(rec["risk_radar"]["forward_log"].get("can_force")))
119:                         _rrt.tune(_prof)
120:                         # RRI Stage-B shadow accrual — 3 ACCRUE variants logged per
121:                         # nightly run for the 7 new-market profiles only (cn/hk/ca
122:                         # are byte-frozen and excluded from scope).  composite_series
123:                         # is called once here; shadow_snapshot derives all 3 variants
124:                         # from the single (B, sub, comp, gate) substrate (budget law).
125:                         # Writes are lane-gated above AND self-gated inside the module.
126:                         try:
127:                             from engine.rri_shadow import MARKETS as _SHD_MARKETS
128:                             from engine import rri_shadow as _shd
129:                             if _prof.key in _SHD_MARKETS:
130:                                 _B, _sub, _comp, _gate = _rri.composite_series(_prof)
131:                                 if _B is not None:
132:                                     _shadow_rows = _shd.shadow_snapshot(
133:                                         _prof, _B, _sub, _comp, _gate)
134:                                     _shd.log_shadow(_prof.key, _shadow_rows)
135:                                     _shd.grade_shadow(_prof.key)
136:                         except Exception as _se:  # noqa: BLE001
137:                             log.warning(
138:                                 "intl %s rri-shadow accrual failed (%s); skipping", cc, _se)
139:                     else:
140:                         # Read-only fast-path: snapshot still renders; ledger/tuner do not advance.
141:                         sc = _rra.scorecard(_prof.key, log_governance=False)
142:                         rec["risk_radar"]["forward_log"] = sc
143:                         rec["risk_radar"]["can_force"] = _rra.force_applicable_for_snapshot(rec["risk_radar"], bool(sc.get("can_force")))
144:                 except Exception as _e:  # noqa: BLE001
145:                     log.warning("intl %s risk-radar audit/tune failed (%s); snapshot only", cc, _e)
146:         except Exception as _e:  # noqa: BLE001
147:             log.warning("intl %s risk-radar failed (%s); skipping", cc, _e)
148: 
149:     if not records:
150:         raise RuntimeError("intl engine produced no country records")
151: 
152:     latest = {
153:         "date": max(r["date"] for r in records),
154:         "summary": intl_compare.global_summary(records),
155:         "records": records,
156:         "rankings": intl_compare.rankings(records),
157:         "heatmap": intl_compare.regime_heatmap(records),
158:         "periphery": intl_compare.periphery_panel(),
159:     }
160:     out = config.data_dir() / "intl"
161:     out.mkdir(parents=True, exist_ok=True)
162:     with open(out / "latest.json", "w") as fh:
163:         json.dump(latest, fh, indent=2, default=str)
164: 
165:     s = latest["summary"]
166:     log.info("intl regime: %d economies, dominant=%s, recession-watch=%d, dd-watch=%d",
167:              s["n"], s["dominant_quad"], s["recession_watch"], s["drawdown_watch"])
168:     return latest
169: 
170: 
171: if __name__ == "__main__":
172:     logging.basicConfig(level=logging.INFO)
173:     import sys
174:     from pathlib import Path
175:     sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
176:     print(json.dumps(run(), indent=2, default=str)[:3000])
```

## COMPLETE CANDIDATE SOURCE: engine/market_state.py
```
1: """Market State — the composite "what kind of market is this?" read.
2: 
3: A DISPLAY-ONLY synthesis (in the same family as fear_euphoria / signal_stack):
4: it never scores, sizes, or feeds any axis / regime / macro_risk. It transparently
5: BLENDS signals the dashboard already computes — the index multi-timeframe tape,
6: cross-asset risk appetite, the volatility regime, market breadth, Fed liquidity &
7: credit, and the downturn-risk guards — into ONE 0-100 risk-on score and a
8: Green / Yellow / Red verdict:
9: 
10:     GREEN  · RISK-ON   — trend, breadth and cross-asset confirmation line up.
11:     YELLOW · MIXED     — signals disagree / a transition is underway. Trade smaller.
12:     RED    · RISK-OFF  — the tape is under stress and trend is down. Defend first.
13: 
14: This is confirmation-over-prediction by construction: every leg reads what has
15: ALREADY turned (price across timeframes, vol term structure, credit, breadth),
16: not a forecast. A handful of evidence-gated OVERRIDES (an 'act' alert, a fresh
17: regime flip, a high/extreme drawdown-risk or acute systemic-stress band) can cap
18: or force the verdict so the headline can never read "risk-on" while a stress
19: gauge is screaming. Risk Radar watch/caution states are sizing advisories; only an
20: above-base loud state backed by confirmed validated evidence earns authority to impose
21: an amplified score CEILING. This keeps a weak prior or unconfirmed leg from replacing
22: the measured blend with a policy constant.
23: 
24: Pure functions, never raises: any shortfall degrades the affected leg (or the
25: whole read) to None and the page still builds. No new data is fetched — the
26: index tape is read off the feature frame already in memory.
27: """
28: from __future__ import annotations
29: 
30: import json
31: import logging
32: from dataclasses import dataclass, field
33: from typing import Callable
34: 
35: import numpy as np
36: import pandas as pd
37: 
38: log = logging.getLogger("market_state")
39: 
40: # component weights (only the legs that resolve are renormalised at blend time)
41: WEIGHTS = {
42:     "trend": 0.24,        # the broad-market tape across timeframes — "the market itself"
43:     "risk": 0.18,         # cross-asset risk appetite (RORO + bonds/FX confirmation)
44:     "vol": 0.16,          # the measured volatility regime (term structure / VRP)
45:     "breadth": 0.16,      # participation — how many stocks are in the move
46:     "liquidity": 0.14,    # the money tide + credit
47:     "stress": 0.12,       # the downturn-risk guard (macro-risk / drawdown / recession)
48: }
49: 
50: # the broad US tape, longest-horizon weighted (a "state" read leans on W/M)
51: _TF_W = {"D": 0.15, "3D": 0.15, "W": 0.40, "M": 0.30}
52: _INDEXES = [
53:     ("SPY", "S&P 500", "标普500"),
54:     ("QQQ", "Nasdaq 100", "纳指100"),
55:     ("IWM", "Russell 2000", "罗素2000"),
56: ]
57: _TF_LABEL = {"D": ("Daily", "日"), "3D": ("3-Day", "3日"), "W": ("Weekly", "周"), "M": ("Monthly", "月")}
58: 
59: 
60: # --------------------------------------------------------- market profile ----
61: # The blender, tape, verdict/cap/flip and override machinery below are all
62: # market-neutral. Only the index tape, the five conditions readers, the radar
63: # source, and which early-warning overrides apply differ per market. A
64: # MarketProfile gathers exactly those so the SAME engine serves the US macro
65: # page and the China / HK / Canada home pages (engine/market_state_cn.py etc.).
66: # US_PROFILE (defined below, once the default readers exist) reproduces today's
67: # behaviour byte-for-byte, so a profile-less call is unchanged.
68: @dataclass(frozen=True)
69: class MarketProfile:
70:     key: str                                    # "us" | "cn" | "hk" | "ca"
71:     indices: tuple                              # ((ticker, en, zh), ...) for the tape
72:     tape_noun_en: str                           # e.g. "US indices" / "China indices"
73:     tape_noun_zh: str
74:     component_readers: tuple                     # (fn(latest)->comp|None, ...) the 5 non-trend legs
75:     radar_override: Callable | None = None       # fn(latest, overrides)->dict ; None = no radar
76:     # which early-warning overrides apply: any of
77:     #   "alert_act" · "new_regime" · "stress_band" · "dislocation"
78:     overrides: frozenset = field(
79:         default_factory=lambda: frozenset({"alert_act", "new_regime", "stress_band", "dislocation"}))
80:     caveat_en: str = ""                          # honest "display-only / lighter than US" board footnote
81:     caveat_zh: str = ""
82: 
83: 
84: def _clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
85:     return max(lo, min(hi, x))
86: 
87: 
88: def _num(v):
89:     try:
90:         f = float(v)
91:         return f if np.isfinite(f) else None
92:     except (TypeError, ValueError):
93:         return None
94: 
95: 
96: def _arrow(sign: int) -> str:
97:     return "▲" if sign > 0 else "▼" if sign < 0 else "▶"
98: 
99: 
100: def _tone_from_score(s01: float) -> str:
101:     if s01 >= 0.60:
102:         return "good"
103:     if s01 >= 0.42:
104:         return "warn"
105:     return "bad"
106: 
107: 
108: # --------------------------------------------------------------- the tape ----
109: 
110: def _tf_sign(st: dict) -> int:
111:     """Up / flat / down for one already-computed _tf_state dict."""
112:     if not st:
113:         return 0
114:     mp = st.get("macd_pos")
115:     rsi = _num(st.get("rsi14"))
116:     if mp is None:
117:         return 0
118:     if mp and (rsi is None or rsi >= 50):
119:         return 1
120:     if (not mp) and (rsi is None or rsi < 50):
121:         return -1
122:     return 0  # macd/rsi disagree → genuinely mixed
123: 
124: 
125: def _index_mtf(close: pd.Series) -> dict | None:
126:     """Per-timeframe arrow read for one index. None if too little history.
127: 
128:     PREMISE REPAIR — R3b (2026-07-18):
129:     The W timeframe now reads the COMPLETED weekly bar only (completed_only=True),
130:     mirroring the IHM-R1 PIT gate in engine/index_momentum.py.
131:     Before this fix the live partial-week resample was used, so the in-progress
132:     bounce week of 07-14..16 produced macd_pos=True / trend=85 GOOD while the
133:     completed 07-10 weekly bar had already rolled over (QQQ hist −0.212,
134:     vel3 −1.324).  07-16 counterfactual: trend 85 → materially lower.
135:     Switch date: 2026-07-18.  See research/RISK_SCORING_REVAMP_MASTERPLAN_BY_FABLE.md §2 R3b.
136:     """
137:     from engine import cycles  # lazy — keeps module import cheap
138:     s = close.dropna().astype(float)
139:     if len(s) < 60:
140:         return None
141:     snap = cycles.mtf_snapshot(s, completed_only=True)
142:     cells, score_num, score_den = {}, 0.0, 0.0
143:     for tf, w in _TF_W.items():
144:         st = snap.get(tf) or {}
145:         if not st:
146:             cells[tf] = None
147:             continue
148:         sign = _tf_sign(st)
149:         cells[tf] = {
150:             "sign": sign, "arrow": _arrow(sign),
151:             "tone": "good" if sign > 0 else "bad" if sign < 0 else "flat",
152:             "rsi": _num(st.get("rsi14")), "macd_pos": bool(st.get("macd_pos")),
153:         }
154:         score_num += w * sign
155:         score_den += w
156:     if score_den == 0:
157:         return None
158:     mean = score_num / score_den               # [-1, 1]
159:     short = _tf_sign(snap.get("D") or {}) + _tf_sign(snap.get("3D") or {})
160:     mid = _tf_sign(snap.get("W") or {})
161:     long = _tf_sign(snap.get("M") or {})
162:     if mean >= 0.34:
163:         conf_en, conf_zh, tone = "Uptrend", "上升趋势", "good"
164:     elif mean <= -0.34:
165:         conf_en, conf_zh, tone = "Downtrend", "下降趋势", "bad"
166:     elif short > 0 >= mid:
167:         conf_en, conf_zh, tone = "Turning up", "转强中", "warn"
168:     elif short < 0 <= mid:
169:         conf_en, conf_zh, tone = "Rolling over", "转弱中", "warn"
170:     else:
171:         conf_en, conf_zh, tone = "Mixed", "分化", "warn"
172:     return {"cells": cells, "mean": mean, "confluence_en": conf_en,
173:             "confluence_zh": conf_zh, "tone": tone}
174: 
175: 
176: def _build_tape(frame, indices=None) -> tuple[dict | None, float | None]:
177:     """The multi-timeframe board + an aggregate trend score01."""
178:     if frame is None:
179:         return None, None
180:     rows, means = [], []
181:     for tkr, en, zh in (indices or _INDEXES):
182:         if tkr not in getattr(frame, "columns", []):
183:             continue
184:         mtf = _index_mtf(frame[tkr])
185:         if mtf is None:
186:             continue
187:         rows.append({"ticker": tkr, "label_en": en, "label_zh": zh, **mtf})
188:         means.append(mtf["mean"])
189:     if not rows:
190:         return None, None
191:     agg = float(np.mean(means))                # [-1, 1]
192:     return {"indices": rows}, _clamp((agg + 1) / 2)
193: 
194: 
195: # ----------------------------------------------------------- the components ----
196: 
197: def _component(key, label_en, label_zh, s01, read_en, read_zh, metrics, mean=None,
198:                degraded=None):
199:     """One blended leg. `degraded` = list of {key, note_en, note_zh} for inputs that have NO
200:     current print, so the leg is carried on fewer gauges than its label implies. The leg still
201:     renders (a null never blocks display tier) but it now SAYS which input is missing instead of
202:     imputing a neutral reading and presenting the result at full confidence."""
203:     if s01 is None:
204:         return None
205:     s01 = _clamp(s01)
206:     if mean is None:
207:         sign = 1 if s01 >= 0.58 else -1 if s01 <= 0.42 else 0
208:     else:
209:         sign = 1 if mean >= 0.25 else -1 if mean <= -0.25 else 0
210:     out = {
211:         "key": key, "label_en": label_en, "label_zh": label_zh,
212:         "score": round(s01 * 100), "weight": WEIGHTS[key],
213:         "tone": _tone_from_score(s01), "arrow": _arrow(sign),
214:         "read_en": read_en, "read_zh": read_zh,
215:         "metrics": [m for m in metrics if m and m.get("v") not in (None, "")],
216:         "degraded": bool(degraded),
217:     }
218:     if degraded:
219:         out["degraded_inputs"] = [d["key"] for d in degraded]
220:         out["degraded_note_en"] = " ".join(d["note_en"] for d in degraded)
221:         out["degraded_note_zh"] = "".join(d["note_zh"] for d in degraded)
222:     return out
223: 
224: 
225: def _metric(k_en, k_zh, v):
226:     return {"k_en": k_en, "k_zh": k_zh, "v": v}
227: 
228: 
229: def _comp_risk(latest: dict) -> dict | None:
230:     C = latest.get("conditions") or {}
231:     ra = C.get("risk_appetite") or {}
232:     state = ra.get("roro_state")
233:     if state is None:
234:         return None
235:     base = {"risk-on": 0.78, "neutral": 0.5, "risk-off": 0.22}.get(state, 0.5)
236:     cac = latest.get("cross_asset_confirm") or {}
237:     agree = _num(cac.get("agree_pct"))
238:     tb = cac.get("to_brain") or {}
239:     adj = 0.0
240:     if agree is not None:
241:         adj += (agree - 50) / 100 * 0.30
242:     if (tb.get("stock_bond_hedge") or "") == "breakdown":
243:         adj -= 0.08
244:     s01 = _clamp(base + adj)
245:     zh_state = {"risk-on": "风险偏好", "neutral": "中性", "risk-off": "避险"}.get(state, state)
246:     read_en = f"Cross-asset RORO {state}"
247:     read_zh = f"跨资产 RORO {zh_state}"
248:     if cac.get("verdict"):
249:         read_en += f"; bonds/FX {cac['verdict']}"
250:         read_zh += f"；债/汇 {cac.get('verdict_zh') or cac['verdict']}"
251:     return _component(
252:         "risk", "Risk appetite", "风险偏好", s01, read_en, read_zh,
253:         [_metric("RORO", "RORO", state),
254:          _metric("Bonds/FX agree", "债/汇一致", f"{int(agree)}%" if agree is not None else None),
255:          _metric("Bond health", "债券健康", tb.get("bond_health")),
256:          _metric("Stock-bond hedge", "股债对冲", tb.get("stock_bond_hedge"))])
257: 
258: 
259: def _comp_vol(latest: dict) -> dict | None:
260:     C = latest.get("conditions") or {}
261:     ra = C.get("risk_appetite") or {}
262:     cmp_ = C.get("complacency") or {}
263:     term = _num(ra.get("vix_term"))
264:     if term is None:
265:         return None
266:     if term < 0.90:
267:         term_s = 0.85
268:     elif term < 1.0:
269:         term_s = 0.62
270:     elif term < 1.05:
271:         term_s = 0.42
272:     else:
273:         term_s = 0.20                              # backwardation = stress
274:     vix_p = _num(cmp_.get("vix_pctile"))
275:     vix_s = 0.6 if vix_p is None else _clamp(1 - vix_p)   # high vol pctile → lower
276:     s01 = 0.62 * term_s + 0.38 * vix_s
277:     # `conditions.complacency` is explicitly display-only. Calm vol is a regime input; the
278:     # narrative "calm but fragile" must not subtract from it a second time without validation.
279:     s01 = _clamp(s01)
280:     contango = term < 1.0
281:     read_en = f"VIX term {'contango (calm)' if contango else 'backwardation (stress)'}"
282:     read_zh = f"VIX 期限{'正向（平静）' if contango else '倒挂（承压）'}"
283:     if vix_p is not None:
284:         read_en += f"; vol {int(vix_p*100)}%ile"
285:         read_zh += f"；波动 {int(vix_p*100)} 百分位"
286:     return _component(
287:         "vol", "Volatility regime", "波动率环境", s01, read_en, read_zh,
288:         [_metric("VIX term", "VIX 期限", f"{term:.2f}"),
289:          _metric("VIX %ile", "VIX 百分位", f"{int(vix_p*100)}%" if vix_p is not None else None),
290:          _metric("VRP %ile", "VRP 百分位",
291:                  f"{int(_num(ra.get('vrp_pctile'))*100)}%" if _num(ra.get("vrp_pctile")) is not None else None),
292:          _metric("Complacency", "自满", cmp_.get("state"))])
293: 
294: 
295: _ZH_YEAR_WORD = {1: "一年", 2: "两年", 3: "三年", 4: "四年", 5: "五年",
296:                  6: "六年", 7: "七年", 8: "八年", 9: "九年", 10: "十年"}
297: 
298: 
299: def _breadth_window_label() -> tuple[str, str]:
300:     """(en, zh) label for the breadth-percentile lookback, derived from the config key the
301:     percentile itself uses (engine.conditions.complacency.breadth_pctile_lookback_d, in TRADING
302:     days ~252/yr). Falls back to the shipped 504d ~= 2y if config is unreadable."""
303:     d = 504
304:     try:
305:         from lib import config  # noqa: PLC0415
306:         d = int(((config.load()["engine"]["conditions"].get("complacency") or {})
307:                  .get("breadth_pctile_lookback_d")) or 504)
308:     except Exception:  # noqa: BLE001 — copy label, never fatal
309:         pass
310:     yrs = max(1, int(round(d / 252)))
311:     return (f"{yrs}y", _ZH_YEAR_WORD.get(yrs, f"{yrs}年"))
312: 
313: 
314: def _comp_breadth(latest: dict) -> dict | None:
315:     C = latest.get("conditions") or {}
316:     cmp_ = C.get("complacency") or {}
317:     b200 = _num(cmp_.get("breadth_above200_pctile"))
318:     if b200 is None:
319:         return None
320:     div = bool(cmp_.get("breadth_div"))
321:     s01 = _clamp(b200 - (0.16 if div else 0.0))
322:     # The percentile window is conditions.complacency.breadth_pctile_lookback_d (504 trading days
323:     # ~= 2 years), NOT five years — the copy said "of 5y" and had since the leg shipped, inflating
324:     # the claimed history by 2.5x (audit 2026-07-29). Read from the SAME config key the percentile
325:     # is computed from so the two can never drift apart again.
326:     win_en, win_zh = _breadth_window_label()
327:     read_en = (f"Breadth {int(b200*100)}%ile of {win_en}; "
328:                + ("a divergence vs price" if div else "confirming price"))
329:     read_zh = (f"广度处于{win_zh} {int(b200*100)} 百分位；" + ("与价格背离" if div else "确认价格"))
330:     return _component(
331:         "breadth", "Breadth & participation", "广度与参与", s01, read_en, read_zh,
332:         [_metric(">200d %ile", ">200日 百分位", f"{int(b200*100)}%"),
333:          _metric("Divergence", "背离", "yes" if div else "no")])
334: 
335: 
336: def _comp_liquidity(latest: dict) -> dict | None:
337:     C = latest.get("conditions") or {}
338:     liq = latest.get("liquidity_overlay")
339:     if liq is None:
340:         return None
341:     base_liq = {"expanding": 0.82, "neutral": 0.5, "contracting": 0.28}.get(liq, 0.5)
342:     cmp_ = C.get("complacency") or {}
343:     fc = C.get("financial_conditions") or {}
344:     ss = C.get("systemic_stress") or {}
345:     credit = 0.5
346:     hy = _num(cmp_.get("hy_oas_chg_21d_bp"))
347:     if hy is not None:
348:         credit += _clamp(-hy / 40 * 0.18, -0.18, 0.18)   # tightening (-bp) → healthier
349:     # DEGRADED-NOT-IMPUTED (audit 2026-07-29). Each of these two terms is an additive OFFSET
350:     # around 0.5, so a missing input contributes 0.0 — arithmetically the only unbiased choice
351:     # (there is no denominator to renormalise), but the leg then PRESENTS at full confidence
352:     # while silently carrying one fewer gauge. Today conditions.financial_conditions is entirely
353:     # None (the NFCI print of 2026-07-17 aged past inputs.py's ffill_limit=7), the metric row
354:     # simply vanished, and nothing on the page said the credit leg had lost a gauge. The
355:     # arithmetic is UNCHANGED — what changes is that the shortfall is now named. Weights and
356:     # offsets are untouched.
357:     degraded = []
358:     if fc.get("state") is None:
359:         degraded.append({
360:             "key": "financial_conditions",
361:             "note_en": "Financial conditions (NFCI) has no current print, so this leg is carried "
362:                        "on the Fed liquidity tide, HY credit and systemic stress only.",
363:             "note_zh": "金融条件（NFCI）暂无最新数据，本项仅由联储流动性、高收益信用与系统性压力构成。",
364:         })
365:     if ss.get("state") is None:
366:         degraded.append({
367:             "key": "systemic_stress",
368:             "note_en": "Systemic stress has no current print, so it is not contributing here.",
369:             "note_zh": "系统性压力暂无最新数据，未参与本项。",
370:         })
371:     credit += {"loose": 0.12, "tight": -0.14, "neutral": 0.0}.get(fc.get("state"), 0.0)
372:     credit += {"calm": 0.06, "normal": 0.0, "elevated": -0.12, "acute": -0.28}.get(ss.get("state"), 0.0)
373:     credit = _clamp(credit)
374:     s01 = _clamp(0.55 * base_liq + 0.45 * credit)
375:     zh_liq = {"expanding": "扩张", "neutral": "中性", "contracting": "收缩"}.get(liq, liq)
376:     read_en = f"Fed liquidity {liq}"
377:     read_zh = f"联储流动性{zh_liq}"
378:     # DIRECTION off the UNROUNDED change (audit 2026-07-29). `hy_oas_chg_21d_bp` is rounded to
379:     # whole bp, so a -0.4bp TIGHTENING becomes -0.0 — and `-0.0 < 0` is False, so the copy read
380:     # "widening" while credit had in fact tightened. conditions now also ships the exact value;
381:     # `credit_widen` (the unrounded > 0 test) is the fallback, the rounded value the last resort.
382:     if hy is not None:
383:         exact = _num(cmp_.get("hy_oas_chg_21d_bp_exact"))
384:         if exact is not None:
385:             dir_en, dir_zh = (("widening", "走阔") if exact > 0 else
386:                               ("tightening", "收窄") if exact < 0 else ("flat", "持平"))
387:         elif cmp_.get("credit_widen") is not None:
388:             dir_en, dir_zh = (("widening", "走阔") if cmp_.get("credit_widen")
389:                               else ("tightening", "收窄"))
390:         else:
391:             dir_en, dir_zh = ("tightening", "收窄") if hy < 0 else ("widening", "走阔")
392:         read_en += f"; HY credit {dir_en}"
393:         read_zh += f"；高收益信用{dir_zh}"
394:     return _component(
395:         "liquidity", "Liquidity & credit", "流动性与信用", s01, read_en, read_zh,
396:         [_metric("Fed liquidity", "联储流动性", liq),
397:          _metric("HY OAS Δ21d", "高收益利差 21日", f"{hy:+.0f}bp" if hy is not None else None),
398:          # an absent NFCI print still drops this row (an EN-only "no print" string in a value
399:          # slot would break the bilingual contract) — the bilingual degraded_note_en/zh below
400:          # is what discloses it, per the house degraded-block idiom.
401:          _metric("Conditions", "金融条件", fc.get("state")),
402:          _metric("Systemic stress", "系统性压力", ss.get("state"))],
403:         degraded=degraded)
404: 
405: 
406: def _comp_stress(latest: dict) -> dict | None:
407:     C = latest.get("conditions") or {}
408:     mr = latest.get("macro_risk") or {}
409:     score = _num(mr.get("score"))               # 0-1 risk-OFF
410:     if score is None:
411:         return None
412:     risk_on = 1 - score
413:     dd = C.get("drawdown_risk") or {}
414:     dd_s = {"low": 0.85, "elevated": 0.5, "high": 0.25, "extreme": 0.1}.get(dd.get("band"), 0.6)
415:     rec = C.get("recession") or {}
416:     rec_score = _num(rec.get("score"))
417:     rec_health = 0.7 if rec_score is None else _clamp(1 - rec_score / 100)
418:     s01 = _clamp(0.5 * risk_on + 0.3 * dd_s + 0.2 * rec_health)
419:     read_en = f"Downturn risk {mr.get('label', '—')}; drawdown band {dd.get('band', '—')}"
420:     read_zh = f"下行风险{ {'low':'低','elevated':'偏高','high':'高'}.get(mr.get('label'), mr.get('label') or '—') }；回撤区间{ {'low':'低','elevated':'偏高','high':'高','extreme':'极高'}.get(dd.get('band'), dd.get('band') or '—') }"
421:     return _component(
422:         "stress", "Downturn-risk guard", "下行风险护栏", s01, read_en, read_zh,
423:         [_metric("Macro-risk", "宏观风险", f"{int(score*100)}/100"),
424:          _metric("Drawdown band", "回撤区间", dd.get("band")),
425:          _metric("P(>10% / 3mo)", "三月内跌超10%", f"{dd.get('dd10_prob_pct')}%" if dd.get("dd10_prob_pct") is not None else None),
426:          _metric("Recession", "衰退", rec.get("label"))])
427: 
428: 
429: # --------------------------------------------------------------- assembly ----
430: 
431: _HEADLINES = {
432:     "RISK_ON": ("Risk-on — the tape, breadth and cross-asset signals line up. Trend-following and adding on strength is supported.",
433:                 "风险偏好 — 价格、广度与跨资产信号一致。顺势交易与逢强加仓得到支持。"),
434:     "MIXED": ("Mixed / transition — the signals disagree. Trade smaller, favour quality, take profits faster; don't position aggressively.",
435:               "混合 / 转换 — 信号分歧。缩小仓位、偏好质量、更快获利了结；勿激进布局。"),
436:     "RISK_OFF": ("Risk-off — stress is elevated; defend capital first.",
437:                  "避险 — 压力升高；优先防守。"),
438: }
439: _POSTURE = {
440:     "RISK_ON": ("Risk-on", "风险偏好"), "MIXED": ("Mixed / transition", "混合 / 转换"),
441:     "RISK_OFF": ("Risk-off", "避险"),
442: }
443: _LABEL = {"RISK_ON": ("Risk-on", "风险偏好"), "MIXED": ("Mixed", "混合"), "RISK_OFF": ("Risk-off", "避险")}
444: _COLOR = {"RISK_ON": "green", "MIXED": "yellow", "RISK_OFF": "red"}
445: _VERDICT_ORDER = ["RISK_OFF", "MIXED", "RISK_ON"]
446: 
447: 
448: def _verdict_from_score(score: int) -> str:
449:     if score >= 60:
450:         return "RISK_ON"
451:     if score >= 42:
452:         return "MIXED"
453:     return "RISK_OFF"
454: 
455: 
456: def _cap(verdict: str, ceiling: str) -> str:
457:     """Lower `verdict` to at most `ceiling` (using risk-off < mixed < risk-on)."""
458:     return verdict if _VERDICT_ORDER.index(verdict) <= _VERDICT_ORDER.index(ceiling) else ceiling
459: 
460: 
461: # Risk Radar bands → plain Chinese + a one-line "what to do" (English, 中文).
462: _RADAR_ZH = {"calm": "平静", "watch": "观察", "caution": "警戒", "elevated": "升高", "risk-off": "避险"}
463: _RADAR_DO = {
464:     "calm": ("Normal exposure.", "正常仓位。"),
465:     "watch": ("A risk is building — stay normal, just watch it.", "风险在积累 — 保持正常，留意即可。"),
466:     "caution": ("Trim chasing; favour good entries over extended leaders.", "减少追高；择优入场而非追逐已延展的龙头。"),
467:     "elevated": ("De-risk: cut size, don't add to froth, honour stops.", "降险：减仓、勿加注泡沫、严守止损。"),
468:     "risk-off": ("Protect capital: raise cash, no new chases.", "保住本金：提高现金、勿追新高。"),
469: }
470: 
471: # ---- amplification calibration (per-corroborator pull, in score points) ----------------
472: # The confluence multiplier started as a flat 6 pts per corroborator. These are now an
473: # OVERLAY that engine/market_state_tune.py rewrites within bounds from the forward-grade
474: # scorecard — so a corroborator that reliably precedes drawdowns pulls harder and one that
475: # does not gets pruned toward zero, WITHOUT a human re-picking the weights. Absent file =>
476: # the original flat-6 behaviour. engine.market_state_tune and the live engine share
477: # _ceiling_for so the backtest can never diverge from production.
478: # `complacency` remains in this compatibility vocabulary because historical ledger rows and
479: # calibration overlays contain it. New live snapshots never fire it: conditions.py owns it as
480: # display-only, and historical tuning must not silently reinterpret old rows.
481: CORROBORATORS = ("conjunction", "two_plus_scares", "complacency", "breadth_div",
482:                  "drawdown_band", "systemic_stress", "turning_point")
483: _DEFAULT_WEIGHTS = {k: 6.0 for k in CORROBORATORS}
484: _DEFAULT_CALIB = {"weights": dict(_DEFAULT_WEIGHTS),
485:                   "base": {"caution": 56, "elevated": 38, "risk-off": 26},
486:                   "severe_bump": 10, "floor": 12}
487: _WEIGHT_BOUNDS = (0.0, 12.0)        # 0 = pruned, 12 = double the default pull
488: # BOUNDED, DO-NO-HARM applies to EVERY overlay field, not just weights (audit 2026-07-29).
489: # `weights` were clamped; `base`, `severe_bump` and `floor` were applied verbatim — an overlay
490: # could ship base={"caution": -500} or floor="x" and the ceiling would go negative or raise
491: # inside the live override. These bounds are the SCORE SCALE itself (0-100) plus the structural
492: # ordering the three bases must satisfy — deliberately NOT new tuning magnitudes, so no
493: # calibration value moves: today's 56/38/26, bump 10, floor 12 all sit inside them untouched.
494: _SCORE_BOUNDS = (0.0, 100.0)
495: _BASE_ORDER = ("caution", "elevated", "risk-off")   # must be monotonically non-increasing
496: 
497: 
498: def _bounded(v, lo: float, hi: float):
499:     """float(v) clamped to [lo, hi]; None when v is not a finite number."""
500:     try:
501:         f = float(v)
502:     except (TypeError, ValueError):
503:         return None
504:     if not np.isfinite(f):
505:         return None
506:     return min(hi, max(lo, f))
507: 
508: 
509: def _ms_calib(root=None) -> dict:
510:     """Read the amplification overlay (data/market_state/calibration.json); fall back to the
511:     flat-6 defaults. Never raises — a bad file degrades to defaults.
512: 
513:     EVERY overlay field is bounded (see _SCORE_BOUNDS / _BASE_ORDER): non-numeric or non-finite
514:     values are DROPPED (the default survives) rather than propagated, scores are clamped to the
515:     0-100 scale, and the three state bases are forced monotonically non-increasing so an overlay
516:     can never make 'risk-off' cap HIGHER than 'caution'."""
517:     c = {"weights": dict(_DEFAULT_WEIGHTS), "base": dict(_DEFAULT_CALIB["base"]),
518:          "severe_bump": _DEFAULT_CALIB["severe_bump"], "floor": _DEFAULT_CALIB["floor"]}
519:     try:
520:         from lib import config
521:         from pathlib import Path
522:         base_dir = config.data_dir() if root is None else (Path(root) / "data")
523:         p = base_dir / "market_state" / "calibration.json"
524:         if p.exists():
525:             ov = json.loads(p.read_text())
526:             for k, v in (ov.get("weights") or {}).items():
527:                 if k in _DEFAULT_WEIGHTS:
528:                     b = _bounded(v, *_WEIGHT_BOUNDS)
529:                     if b is not None:
530:                         c["weights"][k] = b
531:             for k, v in (ov.get("base") or {}).items():
532:                 if k in c["base"]:
533:                     b = _bounded(v, *_SCORE_BOUNDS)
534:                     if b is not None:
535:                         c["base"][k] = b
536:             # a looser state must never cap lower than a tighter one
537:             prev = None
538:             for k in _BASE_ORDER:
539:                 if k in c["base"]:
540:                     if prev is not None:
541:                         c["base"][k] = min(c["base"][k], prev)
542:                     prev = c["base"][k]
543:             for k in ("severe_bump", "floor"):
544:                 if ov.get(k) is not None:
545:                     b = _bounded(ov[k], *_SCORE_BOUNDS)
546:                     if b is not None:
547:                         c[k] = b
548:     except Exception:  # noqa: BLE001
549:         pass
550:     return c
551: 
552: 
553: def _ceiling_for(state: str, severe_gated: bool, amp_keys, calib: dict) -> int | None:
554:     """The amplified score ceiling for a radar-active state under `calib`. Shared by the live
555:     override and the tuner's do-no-harm backtest so they can never disagree. None if calm."""
556:     if state not in ("caution", "elevated", "risk-off"):
557:         return None
558:     base = calib["base"].get(state, _DEFAULT_CALIB["base"][state])
559:     if severe_gated:
560:         base -= calib.get("severe_bump", 10)
561:     pull = sum(calib["weights"].get(k, 6.0) for k in (amp_keys or []))
562:     return int(max(calib.get("floor", 12), round(base - pull)))
563: 
564: 
565: def _rr_scorecard_track(market_key: str) -> dict | None:
566:     """Load the MARKET block from data/risk_radar/scorecard.json for ``market_key``
567:     (one of "us"/"cn"/"hk"/"ca") and return it as-is, or None if the file is absent,
568:     unreadable, or the market key is missing.  Fail-soft: never raises."""
569:     try:
570:         from lib import config  # noqa: PLC0415
571:         p = config.data_dir() / "risk_radar" / "scorecard.json"
572:         if not p.exists():
573:             return None
574:         blob = json.loads(p.read_text(encoding="utf-8"))
575:         markets = blob.get("markets") or {}
576:         return markets.get(market_key) or None
577:     except Exception:  # noqa: BLE001
578:         return None
579: 
580: 
581: def _radar_to_rd(rr: dict) -> dict:
582:     """Map a risk_radar.v2 (US) / risk_radar_intl.v1 (CN/HK/CA) payload into the `rd` dict
583:     the shared .rrx Risk-Radar card consumes. Pure; the amplifying US override and the
584:     display-only override both build on it. `amp`/`ceiling` default to off (the US override
585:     fills them in when the radar is loud)."""
586:     state = rr.get("state")
587:     top = _num(rr.get("top_score"))
588:     dp = rr.get("drawdown_prob") or {}
589:     composition = rr.get("composition")
590:     if "composition" in rr and not isinstance(composition, dict):
591:         composition = {"status": "UNAVAILABLE", "score_current": False,
592:                        "calibration_status": "unreviewed_corrected_construction"}
593:     reference_only = "composition" in rr
594:     legacy_dp = ((rr.get("legacy_calibration_reference") or {}).get("drawdown_prob", dp) if reference_only else None)
595:     if reference_only:
596:         dp = {}
597:     _mkt = rr.get("market") or "us"
598:     _track = _rr_scorecard_track(_mkt)
599:     # Explicit authority is emitted by current radar producers. For older artifacts, only an
600:     # actual loud alert may bind; a legacy caution payload is advisory by construction.
601:     _can_force = (bool(rr.get("can_force")) if "can_force" in rr else
602:                   bool(rr.get("alert") and state in ("elevated", "risk-off")))
603:     _reported_can_force = _can_force
604:     from engine.risk_radar_intl_audit import force_applicable_for_snapshot
605:     _can_force = force_applicable_for_snapshot(rr, _reported_can_force)
606:     _authority = dict(rr.get("authority") or {
607:         "tier": "binding" if _can_force else "advisory",
608:         "can_force": _can_force,
609:         "reason": "legacy_loud_alert" if _can_force else "legacy_early_tier_advisory",
610:         "note_en": ("Binding guard — confirmed leading risk may cap the measured tape." if _can_force
611:                     else "Advisory — sizes risk; does not override the measured tape."),
612:         "note_zh": ("约束性护栏——已确认的领先风险可压低实测盘面评分。" if _can_force
613:                     else "提示性信号——仅调整仓位，不覆盖实测盘面。"),
614:     })
615:     if "composition" in rr:
616:         _authority = {"tier": "descriptive", "can_force": False,
617:                       "reason": "construction_not_promoted",
618:                       "note_en": "Descriptive context; no forecast, sizing or binding permission.",
619:                       "note_zh": "描述性背景；不提供预测、仓位指令或约束权限。"}
620:     # Forward-monitor freshness remains visible in `track`, but it is display provenance. The
621:     # optional, wall-clock scorecard must not silently rewrite an identical producer payload.
622:     return {
623:         "state": state,
624:         "top_score": round(top) if top is not None else None,
625:         "label_en": ("Current reading unavailable" if composition and not composition.get("score_current") else ("Partial-input risk reading" if composition and composition.get("status") == "PARTIAL" else ("Input-based reading; forecast calibration under review" if reference_only else rr.get("dominant_label_en") or "calm"))),
626:         "label_zh": ("当前读数暂缺" if composition and not composition.get("score_current") else ("输入不完整的风险读数" if composition and composition.get("status") == "PARTIAL" else ("输入驱动的读数；预测校准待核验" if reference_only else rr.get("dominant_label_zh") or "平静"))),
627:         "state_zh": _RADAR_ZH.get(state, state or ""),
628:         "do_en": "Review price and breadth alongside this reading." if reference_only else _RADAR_DO.get(state, ("", ""))[0],
629:         "do_zh": "结合价格与市场广度观察此读数。" if reference_only else _RADAR_DO.get(state, ("", ""))[1],
630:         "gross": None if reference_only else _num(rr.get("gross_factor")),
631:         "composition": composition,
632:         "legacy_drawdown_prob": legacy_dp,
633:         "dd5": _num(dp.get("h5")), "dd10": _num(dp.get("h10")), "dd21": _num(dp.get("h21")),
634:         "dd_lift": _num(dp.get("lift_h21")),
635:         # unconditional "normal" base rates per horizon — the reference the radar card draws the
636:         # escalating odds against (so a small near-term bar can't be misread as "no risk").
637:         "dd_base": {"h5": _num(dp.get("base_h5")), "h10": _num(dp.get("base_h10")),
638:                     "h21": _num(dp.get("base_h21"))},
639:         "is_warning": state in ("caution", "elevated", "risk-off"),
640:         "is_loud": state in ("elevated", "risk-off"),
641:         **({"reported_can_force": _reported_can_force} if "composition" in rr else {}),
642:         "can_force": _can_force,
643:         "binding": bool(_can_force and state in ("caution", "elevated", "risk-off")),
644:         "authority": _authority,
645:         # carried so the board can pass ms.radar.scares to the card (the US page passes
646:         # latest.risk_radar.scares separately, so this is harmless duplication there).
647:         "scares": rr.get("scares") or [],
648:         # the radar's own forward-grade scorecard (engine/risk_radar_intl_audit) — drives the
649:         # card's "self-audit" line. None on the US radar (which logs via market_state_audit).
650:         "forward_log": rr.get("forward_log"),
651:         # election-cycle MODULATOR (engine/election_cycle.py) — display chip + sizing prior; only
652:         # set on the US radar (the intl radars carry no midterm prior — the backtest refuted it).
653:         "cycle": rr.get("cycle_context"),
654:         # RC-R11 washout counter-read — display-tier context chip beside the banner (US radar only).
655:         "counterread": rr.get("counterread"),
656:         "amp": 0, "amp_keys": [], "amp_flags_en": [], "amp_flags_zh": [],
657:         "severe_gated": False, "ceiling": None, "candidate_ceiling": None,
658:         # amplification-provenance defaults (the US override fills them in when the radar is
659:         # loud); present here so every consumer can read them unconditionally.
660:         "amp_unavailable": [], "amp_unavailable_keys": [], "amp_n_checked": 0,
661:         "amp_available": 0, "ceiling_base": None, "ceiling_severe_bump": 0,
662:         "ceiling_amp_pull": 0.0, "ceiling_floor": None,
663:         # display-only DE-ESCALATION read ("risk-off may be ending"); the US override fills it in
664:         # below from the radar trajectory + the liquidity tide. Stays None on the intl radars and
665:         # the no-source calm radar, so the card's {% if rd.recovery %} guard simply skips it.
666:         "recovery": None,
667:         # forward-ledger track record for this market (data/risk_radar/scorecard.json).
668:         # Display-only; None when the scorecard is absent (first build, engine builder not yet run).
669:         # The card template guards with {% if radar.track is defined and radar.track %}.
670:         "track": _track,
671:     }
672: 
673: 
674: # Base score ceilings the intl radar applies ONLY once its own graded log validates it. No
675: # corroborator multiplier — China/HK/Canada lack the US conditions gauges (complacency /
676: # systemic_stress / turning_point), so radar intensity alone caps the verdict.
677: _RADAR_INTL_CEIL = {"caution": 56, "elevated": 38, "risk-off": 26}
678: _RADAR_MARKET = {"cn": ("China", "中国"), "hk": ("Hong Kong", "香港"), "ca": ("Canada", "加拿大")}
679: 
680: 
681: def _radar_override_intl(latest: dict, overrides: list) -> dict:
682:     """Radar mapping for the China/HK/Canada radars (engine/risk_radar_intl.py). Always renders
683:     the .rrx card from latest['risk_radar']; HARD-FORCES the Market-State verdict (caps the
684:     score) ONLY once that market's own forward-grade log has matured and cleared the bar
685:     (rr['can_force'], set by engine/risk_radar_intl_audit.scorecard). Until then it is pure
686:     display — accountable by construction, never trusted on faith."""
687:     rr = latest.get("risk_radar") or {}
688:     out = _radar_to_rd(rr)
689:     state = rr.get("state")
690: 
691:     # DE-ESCALATION read (display-only) for the CN/HK/CA radar — has this market's risk peaked +
692:     # rolled over while the global liquidity tide (Fed/PBoC/global CB) turns supportive? Never
693:     # touches the ceiling below. See engine/risk_radar_recovery.py.
694:     try:
695:         from engine import risk_radar_recovery
696:         out["recovery"] = risk_radar_recovery.assess(latest)
697:     except Exception as e:  # noqa: BLE001 — additive, never fatal
698:         log.warning("risk_radar_intl recovery assess failed: %s", e)
699:         out["recovery"] = None
700: 
701:     if out.get("can_force") and state in ("caution", "elevated", "risk-off"):
702:         ceil = _RADAR_INTL_CEIL.get(state)
703:         out["ceiling"] = ceil
704:         out["candidate_ceiling"] = ceil
705:         out["binding"] = ceil is not None
706:         mkt_en, mkt_zh = _RADAR_MARKET.get(rr.get("market"), ("", ""))
707:         if ceil is not None and ceil < 42:
708:             overrides.append({"kind": "radar",
709:                 "note_en": f"{mkt_en} Risk Radar forces Risk-off.",
710:                 "note_zh": f"{mkt_zh}风险雷达强制为「避险」。"})
711:         else:
712:             overrides.append({"kind": "radar",
713:                 "note_en": "Risk Radar caps at Mixed.",
714:                 "note_zh": "风险雷达封顶为「混合」。"})
715:     return out
716: 
717: 
718: def _amp_unavailable(latest: dict) -> list:
719:     """Which confluence corroborators are STRUCTURALLY UNABLE to fire on the current tape.
720: 
721:     Breadth divergence is gated on the index being near its high, and several slow gauges may lack
722:     a current read. Emitting the disarmed set lets the surface distinguish "silent by construction"
723:     from reassuring. Display-only complacency is intentionally absent from this scoring ladder.
724: 
725:     Reads the SAME config keys engine/conditions.py computes the gauges from, so the note can
726:     never claim a threshold the gauge does not use. Never raises."""
727:     out = []
728:     try:
729:         C = latest.get("conditions") or {}
730:         cmp_ = C.get("complacency") or {}
731:         mcfg = {}
732:         try:
733:             from lib import config  # noqa: PLC0415
734:             mcfg = (config.load()["engine"]["conditions"].get("complacency") or {})
735:         except Exception:  # noqa: BLE001
736:             mcfg = {}
737:         prox_thr = mcfg.get("breadth_high_prox", 0.97)
738:         prox = _num(cmp_.get("spy_high_prox"))
739:         if prox is not None and prox < float(prox_thr):
740:             out.append({
741:                 "key": "breadth_div", "reason": "index_not_near_high",
742:                 "note_en": (f"Breadth divergence cannot fire: it is only defined within "
743:                             f"{prox_thr:.0%} of the 1-year high and the index is at "
744:                             f"{prox:.0%}. Silent by construction, not confirming."),
745:                 "note_zh": (f"「广度背离」无法触发：仅在距一年高点 {prox_thr:.0%} 以内才成立，"
746:                             f"当前为 {prox:.0%}。属结构性沉默，并非确认。"),
747:             })
748:         if (C.get("drawdown_risk") or {}).get("band") is None:
749:             out.append({
750:                 "key": "drawdown_band", "reason": "no_current_read",
751:                 "note_en": "Drawdown-risk band has no current read, so it cannot corroborate.",
752:                 "note_zh": "回撤风险区间暂无读数，无法参与确认。",
753:             })
754:         if (C.get("systemic_stress") or {}).get("state") is None:
755:             out.append({
756:                 "key": "systemic_stress", "reason": "no_current_read",
757:                 "note_en": "Systemic stress has no current read, so it cannot corroborate.",
758:                 "note_zh": "系统性压力暂无读数，无法参与确认。",
759:             })
760:         if latest.get("turning_point") is None:
761:             out.append({
762:                 "key": "turning_point", "reason": "no_current_read",
763:                 "note_en": "The turning-point read is unavailable, so it cannot corroborate.",
764:                 "note_zh": "转折点读数暂缺，无法参与确认。",
765:             })
766:     except Exception as e:  # noqa: BLE001 — disclosure block, never fatal
767:         log.warning("market_state amp-availability read failed: %s", e)
768:     return out
769: 
770: 
771: def _radar_override(latest: dict, overrides: list) -> dict:
772:     """Summarise the Risk Radar and compute a transparent candidate ceiling at caution+.
773: 
774:     The candidate becomes a binding Market-State ceiling only when the radar's explicit
775:     `can_force` evidence gate is true. Watch/caution states otherwise remain sizing advisories.
776:     Two things scale a binding ceiling:
777:       • intensity — its gated state, plus a SEVERE-BUT-GATED bump when the radar's own
778:         un-gated read is worse than its label (the context gate keeps the label quiet
779:         until the broad tape breaks, but the underlying drawdown risk is already high);
780:       • a CONFLUENCE MULTIPLIER — every OTHER risk gauge that is flashing at the same
781:         time (a second scare-type, breadth divergence, a stress band) drops the
782:         ceiling further, so a confluence drives the verdict deep into risk-off even
783:         while VIX and trend still look calm.
784:     The caller applies only the returned `ceiling`; `candidate_ceiling` is disclosure."""
785:     rr = latest.get("risk_radar") or {}
786:     state = rr.get("state")
787:     top = _num(rr.get("top_score"))
788:     ungated = rr.get("state_ungated") or state
789:     out = _radar_to_rd(rr)
790: 
791:     # DE-ESCALATION read (display-only): has risk peaked + are the pullback odds rolling over while
792:     # the liquidity tide turns supportive? Computed at EVERY state (also calm/watch) so the "risk-off
793:     # may be ending" panel persists through the cool-down. It NEVER touches the ceiling/amp/verdict
794:     # below — the radar's one-directional guardrail is untouched. See engine/risk_radar_recovery.py.
795:     try:
796:         from engine import risk_radar_recovery
797:         out["recovery"] = risk_radar_recovery.assess(latest)
798:     except Exception as e:  # noqa: BLE001 — additive, never fatal
799:         log.warning("risk_radar recovery assess failed: %s", e)
800:         out["recovery"] = None
801: 
802:     if state not in ("caution", "elevated", "risk-off"):
803:         return out
804: 
805:     # ---- confluence multiplier: the OTHER risk gauges flashing right now. Each carries a
806:     # STABLE key so the forward-grade log (engine/market_state_audit.py) can measure which
807:     # corroborators actually precede drawdowns and prune the ones that don't. ----
808:     C = latest.get("conditions") or {}
809:     cmp_ = C.get("complacency") or {}  # breadth-divergence field only; state is display-only
810:     nhot = sum(1 for s in (rr.get("scares") or [])
811:                if s.get("band") in ("caution", "elevated", "risk-off"))
812:     _checks = [
813:         ("conjunction", bool(rr.get("conjunction")),
814:          "several scare-types firing together", "多个风险类型同时触发"),
815:         ("two_plus_scares", nhot >= 2,
816:          f"{nhot} risk types elevated", f"{nhot} 类风险升高"),
817:         ("breadth_div", bool(cmp_.get("breadth_div")),
818:          "narrowing breadth / leadership", "广度／领导性收窄"),
819:         ("drawdown_band", (C.get("drawdown_risk") or {}).get("band") in ("elevated", "high", "extreme"),
820:          "drawdown-risk band rising", "回撤风险区间上升"),
821:         ("systemic_stress", (C.get("systemic_stress") or {}).get("state") in ("elevated", "acute"),
822:          "systemic stress building", "系统性压力累积"),
823:         ("turning_point", bool((latest.get("turning_point") or {}).get("present")),
824:          "fragile one-factor tape", "脆弱的单因子行情"),
825:     ]
826:     keys = [k for k, on, _e, _z in _checks if on]
827:     flags_en = [e for _k, on, e, _z in _checks if on]
828:     flags_zh = [z for _k, on, _e, z in _checks if on]
829:     amp = len(keys)
830: 
831:     # severe-but-gated: un-gated read worse than the label, or the top scare screaming
832:     severe_gated = state == "caution" and (
833:         ungated in ("elevated", "risk-off") or (top is not None and top >= 85))
834: 
835:     # the amplified ceiling, using the (auto-tuned) per-corroborator weights
836:     calib = _ms_calib()
837:     candidate_ceiling = _ceiling_for(state, severe_gated, keys, calib)
838:     can_force = bool(out.get("can_force"))
839:     ceiling = candidate_ceiling if can_force else None
840: 
841:     # which corroborators are structurally DISARMED on this tape (see _amp_unavailable) — a
842:     # silent gauge is not a quiet one, and the ladder's "N gauges flashing" needs that context.
843:     unavail = _amp_unavailable(latest)
844:     out.update(amp=amp, amp_keys=keys, amp_flags_en=flags_en, amp_flags_zh=flags_zh,
845:                severe_gated=severe_gated, ceiling=ceiling,
846:                candidate_ceiling=candidate_ceiling,
847:                binding=bool(can_force and ceiling is not None),
848:                amp_n_checked=len(_checks),
849:                amp_unavailable=unavail,
850:                amp_unavailable_keys=[u["key"] for u in unavail],
851:                amp_available=len(_checks) - len(unavail),
852:                ceiling_base=calib["base"].get(state),
853:                ceiling_severe_bump=(calib.get("severe_bump", 10) if severe_gated else 0),
854:                ceiling_amp_pull=sum(calib["weights"].get(k, 6.0) for k in keys),
855:                ceiling_floor=calib.get("floor", 12))
856: 
857:     # The Risk Radar banner rendered directly ABOVE this verdict already states the radar's
858:     # name, gated state, score and amp-flag breakdown. So the override note here stays lean —
859:     # it only explains the CONSEQUENCE (forced / capped) plus the severe-but-gated nuance the
860:     # banner doesn't surface. Restating "Risk Radar {state} ({score}/100) amplified by N…"
861:     # duplicated the banner headline word-for-word.
862:     if ceiling is None:
863:         return out
864:     if ceiling < 42:
865:         overrides.append({"kind": "radar",
866:             "note_en": "Risk Radar forces Risk-off.",
867:             "note_zh": "风险雷达强制为「避险」。"})
868:     else:
869:         overrides.append({"kind": "radar",
870:             "note_en": "Capped at Mixed by the Risk Radar above.",
871:             "note_zh": "由上方风险雷达封顶为「混合」。"})
872:     return out
873: 
874: 
875: def _calm_radar() -> dict:
876:     """The neutral radar payload for a market with no Risk-Radar source — the board
877:     simply omits the banner ({% if MS.radar.state %})."""
878:     return {"state": None, "top_score": None, "label_en": "calm", "label_zh": "平静",
879:             "state_zh": "", "do_en": "", "do_zh": "", "gross": None,
880:             "dd5": None, "dd10": None, "dd21": None, "dd_lift": None,
881:             "dd_base": {"h5": None, "h10": None, "h21": None},
882:             "is_warning": False, "is_loud": False, "can_force": False, "binding": False,
883:             "authority": None,
884:             "amp": 0, "amp_keys": [], "amp_flags_en": [], "amp_flags_zh": [],
885:             "severe_gated": False, "ceiling": None, "candidate_ceiling": None,
886:             "recovery": None, "track": None,
887:             "amp_unavailable": [], "amp_unavailable_keys": [], "amp_n_checked": 0,
888:             "amp_available": 0, "ceiling_base": None, "ceiling_severe_bump": 0,
889:             "ceiling_amp_pull": 0.0, "ceiling_floor": None}
890: 
891: 
892: # The default (US) profile — every field reproduces today's hardcoded behaviour, so
893: # market_state_snapshot(latest, frame, alerts) with no profile is byte-identical.
894: US_PROFILE = MarketProfile(
895:     key="us",
896:     indices=tuple(_INDEXES),
897:     tape_noun_en="US indices", tape_noun_zh="美股指数",
898:     component_readers=(_comp_risk, _comp_vol, _comp_breadth, _comp_liquidity, _comp_stress),
899:     radar_override=_radar_override,
900:     overrides=frozenset({"alert_act", "new_regime", "stress_band", "dislocation"}),
901: )
902: 
903: 
904: def market_state_snapshot(latest: dict, frame=None, alerts: list | None = None,
905:                           profile: "MarketProfile | None" = None) -> dict | None:
906:     """Blend the live signal legs into a 0-100 risk-on score + Green/Yellow/Red
907:     verdict. DISPLAY-ONLY; returns None only if nothing at all resolves.
908: 
909:     `profile` selects the market (indices, conditions readers, radar source, which
910:     overrides apply); defaults to US_PROFILE so existing callers are unchanged."""
911:     profile = profile or US_PROFILE
912:     try:
913:         if not isinstance(latest, dict):
914:             return None
915:         tape, trend_s = _build_tape(frame, profile.indices)
916:         comps = []
917:         if trend_s is not None:
918:             comps.append(_component(
919:                 "trend", "Trend & technicals", "趋势与技术", trend_s,
920:                 _tape_read_en(tape, profile.tape_noun_en),
921:                 _tape_read_zh(tape, profile.tape_noun_zh), [], mean=(2 * trend_s - 1)))
922:         for fn in profile.component_readers:
923:             c = fn(latest)
924:             if c:
925:                 comps.append(c)
926:         comps = [c for c in comps if c]
927:         if not comps:
928:             return None
929: 
930:         num = sum(c["score"] / 100 * c["weight"] for c in comps)
931:         den = sum(c["weight"] for c in comps)
932:         raw_score = int(round(100 * num / den)) if den else 50
933:         verdict = _verdict_from_score(raw_score)
934: 
935:         # ---- early-warning overrides (cap or force), each gated by the profile ----
936:         overrides = []
937:         ov = profile.overrides
938:         sev = {(a.get("severity") if isinstance(a, dict) else None) for a in (alerts or [])}
939:         if "alert_act" in ov and "act" in sev:
940:             verdict = _cap(verdict, "MIXED")
941:             overrides.append({"kind": "alert",
942:                               "note_en": "An act-level alert is firing — capped at Mixed pending review.",
943:                               "note_zh": "有行动级警报触发 — 暂封顶为「混合」待复核。"})
944:         if "new_regime" in ov and (latest.get("transition_state") or "") == "NEW_REGIME":
945:             verdict = _cap(verdict, "MIXED")
946:             overrides.append({"kind": "regime",
947:                               "note_en": "The regime just flipped — capped at Mixed until it settles.",
948:                               "note_zh": "周期刚刚翻转 — 在其稳定前封顶为「混合」。"})
949:         C = latest.get("conditions") or {}
950:         dd_band = (C.get("drawdown_risk") or {}).get("band")
951:         ss_state = (C.get("systemic_stress") or {}).get("state")
952:         if "stress_band" in ov and (dd_band in ("high", "extreme") or ss_state == "acute"):
953:             verdict = "RISK_OFF"
954:             overrides.append({"kind": "stress",
955:                               "note_en": "Elevated drawdown / systemic-stress band — forced to Risk-off.",
956:                               "note_zh": "回撤／系统性压力区间偏高 — 强制为「避险」。"})
957:         dl = latest.get("dislocation") or {}
958:         if "dislocation" in ov and dl.get("dislocation_active") and dl.get("verdict") == "stand_aside":
959:             verdict = "RISK_OFF"
960:             overrides.append({"kind": "dislocation",
961:                               "note_en": "A falling-knife dislocation is live — forced to Risk-off.",
962:                               "note_zh": "接飞刀式错位正在发生 — 强制为「避险」。"})
963: 
964:         # ---- Evidence-gated Risk Radar override (runs LAST when it has earned authority) ----
965:         # _radar_override always publishes the radar and its candidate ceiling. It returns an
966:         # actual ceiling only when `can_force` is true; early watch/caution reads remain visible
967:         # sizing advisories and cannot replace the measured blend with a constant.
968:         radar = profile.radar_override(latest, overrides) if profile.radar_override else _calm_radar()
969: 
970:         # Keep the 0-100 dial honest: a forced verdict pulls the displayed score into its
971:         # own band, then an evidence-authorized radar ceiling can pull it lower (never higher).
972:         #
973:         # PROVENANCE (audit 2026-07-29): on every radar-capped day the number the page shows is
974:         # the CEILING CONSTANT (base − amp pull − severe bump), not a measurement of the tape —
975:         # across 21 logged sessions the blend never printed below 61 while the displayed score
976:         # never rose above 56. raw_score was already in the payload but nothing said WHICH of the
977:         # two the dial was showing, so a constant read as a reading. score_source / score_ceiling
978:         # / capped / score_caps make the distinction machine-readable, so a surface can draw the
979:         # blend and the cap as two separate marks. The 2026-08-12 authority gate now prevents
980:         # below-base/unconfirmed early tiers from creating such a cap.
981:         score = raw_score
982:         caps_applied = []
983:         if verdict == "RISK_OFF":
984:             if 41 < score:
985:                 caps_applied.append({"kind": "verdict_force", "limit": 41,
986:                                      "note_en": "forced into the Risk-off band by an override",
987:                                      "note_zh": "被覆盖规则强制进入「避险」区间"})
988:             score = min(score, 41)
989:         elif verdict == "MIXED":
990:             if 59 < score:
991:                 caps_applied.append({"kind": "verdict_cap", "limit": 59,
992:                                      "note_en": "capped into the Mixed band by an override",
993:                                      "note_zh": "被覆盖规则封顶于「混合」区间"})
994:             score = min(score, 59)
995:         ceiling = radar.get("ceiling")
996:         if ceiling is not None:
997:             if ceiling < score:
998:                 caps_applied.append({"kind": "radar_ceiling", "limit": ceiling,
999:                                      "note_en": "held at the Risk Radar's amplified ceiling",
1000:                                      "note_zh": "受风险雷达放大后的上限约束"})
1001:             score = min(score, ceiling)
1002:         # the penalised score now drives the verdict; the radar can only make it more
1003:         # risk-off than the prior overrides, never less.
1004:         verdict = _cap(verdict, _verdict_from_score(score))
1005: 
1006:         binding = min(caps_applied, key=lambda c: c["limit"], default=None)
1007:         score_source = ("blend" if binding is None else
1008:                         {"radar_ceiling": "radar_ceiling",
1009:                          "verdict_force": "hard_force",
1010:                          "verdict_cap": "verdict_cap"}[binding["kind"]])
1011: 
1012:         flip_en, flip_zh = _flip_text(comps, verdict, raw_score=raw_score,
1013:                                       radar=radar, overrides=overrides)
1014:         return {
1015:             "schema": "market_state.v1",
1016:             "asof": latest.get("date"),
1017:             "score": score,
1018:             "raw_score": raw_score,
1019:             # is the dial showing the blend, or a constant that overrode it?
1020:             "score_source": score_source,
1021:             "capped": bool(caps_applied),
1022:             "score_ceiling": ceiling,
1023:             "score_caps": caps_applied,
1024:             "score_gap": (None if not caps_applied else int(raw_score - score)),
1025:             "radar": radar,
1026:             "verdict": verdict,
1027:             "color": _COLOR[verdict],
1028:             "label_en": _LABEL[verdict][0], "label_zh": _LABEL[verdict][1],
1029:             "posture_en": _POSTURE[verdict][0], "posture_zh": _POSTURE[verdict][1],
1030:             "headline_en": _HEADLINES[verdict][0], "headline_zh": _HEADLINES[verdict][1],
1031:             "components": comps,
1032:             "mtf": tape,
1033:             "overrides": overrides,
1034:             "flip_en": flip_en, "flip_zh": flip_zh,
1035:             "alerts_count": len([a for a in (alerts or []) if a]),
1036:             "market": profile.key,
1037:             "caveat_en": profile.caveat_en, "caveat_zh": profile.caveat_zh,
1038:             "is_display_only": True,
1039:             # per-input last-print dates (engine/conditions._input_vintages), carried through so
1040:             # persist()'s freshness stamp can be derived from real store vintages instead of the
1041:             # frame calendar it used to certify itself with. Empty on markets whose conditions
1042:             # reader does not emit them.
1043:             "input_vintages": ((latest.get("conditions") or {}).get("vintages") or {}),
1044:             "stale_inputs": ((latest.get("conditions") or {}).get("stale_inputs") or []),
1045:             # which legs are running on fewer inputs than their label implies
1046:             "degraded_components": [c["key"] for c in comps if c.get("degraded")],
1047:         }
1048:     except Exception as e:  # noqa: BLE001 — additive panel, never fatal
1049:         log.warning("market_state snapshot failed: %s", e)
1050:         return None
1051: 
1052: 
1053: def _tape_read_en(tape, noun: str = "US indices") -> str:
1054:     if not tape:
1055:         return "Broad-market tape unavailable."
1056:     ups = sum(1 for r in tape["indices"] if r["mean"] >= 0.34)
1057:     n = len(tape["indices"])
1058:     lead = ", ".join(r["confluence_en"].lower() for r in tape["indices"][:3])
1059:     return f"{ups}/{n} {noun} in an uptrend across timeframes ({lead})."
1060: 
1061: 
1062: def _tape_read_zh(tape, noun: str = "美股指数") -> str:
1063:     if not tape:
1064:         return "大盘多周期数据暂缺。"
1065:     ups = sum(1 for r in tape["indices"] if r["mean"] >= 0.34)
1066:     n = len(tape["indices"])
1067:     return f"{ups}/{n} 个{noun}多周期呈上升趋势。"
1068: 
1069: 
1070: # ---- "what tips this" — the binding-constraint machinery ------------------------------------
1071: # Score cuts, MIRRORING _verdict_from_score: RISK_ON >= 60, MIXED >= 42, else RISK_OFF.
1072: _FLIP_UP_TARGET = {"MIXED": 60, "RISK_OFF": 42}     # score needed for the next-BETTER verdict
1073: _FLIP_DOWN_TARGET = {"RISK_ON": 59, "MIXED": 41}    # score at/below which the next-WORSE prints
1074: # Which cap each override kind puts on the 0-100 dial — mirrors market_state_snapshot's own
1075: # min() chain, so the flip line can name the constraint that is actually holding the score.
1076: _OVERRIDE_LIMIT = {"alert": 59, "regime": 59, "stress": 41, "dislocation": 41}
1077: _OVERRIDE_CLAIM = {
1078:     "alert": ("the act-level alert clears", "行动级警报解除"),
1079:     "regime": ("the fresh regime flip settles", "新周期企稳"),
1080:     "stress": ("the drawdown / systemic-stress band comes back down", "回撤／系统性压力区间回落"),
1081:     "dislocation": ("the falling-knife dislocation ends", "接飞刀式错位结束"),
1082: }
1083: # prefix + target-tier wording per (verdict, direction). zh names the target TIERS (偏多/避险),
1084: # never colours: under the zh 红涨绿跌 swap the "green" tier paints RED on the board.
1085: _FLIP_SHAPE = {
1086:     ("MIXED", 1): ("→ Green if ", "偏多"),
1087:     ("MIXED", -1): ("→ Red if ", "避险"),
1088:     ("RISK_ON", -1): ("→ Mixed if ", "混合"),
1089:     ("RISK_OFF", 1): ("→ Mixed when ", "混合"),
1090: }
1091: 
1092: 
1093: def _flip_constraints(radar: dict | None, overrides: list | None) -> list:
1094:     """Every cap currently holding the 0-100 dial down, as (limit, claim_en, claim_zh). These are
1095:     the things the blend CANNOT out-run — naming one is the only honest upside claim when it sits
1096:     below the band the flip line is promising."""
1097:     out = []
1098:     for o in overrides or []:
1099:         lim = _OVERRIDE_LIMIT.get((o or {}).get("kind"))
1100:         if lim is not None:
1101:             en, zh = _OVERRIDE_CLAIM[o["kind"]]
1102:             out.append((float(lim), en, zh))
1103:     ceil = _num((radar or {}).get("ceiling"))
1104:     if ceil is not None:
1105:         st = (radar or {}).get("state") or "caution"
1106:         top = (radar or {}).get("top_score")
1107:         now_en = f" (now {top}/100)" if top is not None else ""
1108:         now_zh = f"（现 {top}/100）" if top is not None else ""
1109:         out.append((float(ceil),
1110:                     f"the Risk Radar leaves {st}{now_en}",
1111:                     f"风险雷达退出{_RADAR_ZH.get(st, st)}{now_zh}"))
1112:     return out
1113: 
1114: 
1115: def _legs_to_cross(comps: list, raw_score, target: float, direction: int) -> list | None:
1116:     """The smallest set of legs (most room first) whose FULL move carries the BLEND across
1117:     `target`: direction +1 = every named leg to 100, -1 = to 0. None when even all legs together
1118:     cannot get there; [] when the blend is already across. Weights are renormalised over the legs
1119:     that resolved, exactly as market_state_snapshot blends them."""
1120:     den = sum(float(c.get("weight") or 0.0) for c in comps)
1121:     if den <= 0 or raw_score is None:
1122:         return None
1123:     need = (float(target) - float(raw_score)) if direction > 0 else (float(raw_score) - float(target))
1124:     if need <= 0:
1125:         return []
1126:     room = []
1127:     for c in comps:
1128:         w = float(c.get("weight") or 0.0) / den
1129:         s = float(c.get("score") or 0.0)
1130:         room.append((((100.0 - s) * w) if direction > 0 else (s * w), c))
1131:     room.sort(key=lambda t: -t[0])
1132:     got, picked = 0.0, []
1133:     for r, c in room:
1134:         if r <= 0:
1135:             continue
1136:         picked.append(c)
1137:         got += r
1138:         if got >= need:
1139:             return picked
1140:     return None
1141: 
1142: 
1143: def _legs_claim(legs: list, direction: int, n_total: int) -> tuple[str, str]:
1144:     """Plain-word claim for a leg set. >2 legs stops naming them — "3 of the 6 legs" is the honest
1145:     shape for a move no single reading can deliver."""
1146:     verb_en, verb_zh = ("firms up", "转强") if direction > 0 else ("breaks down", "走坏")
1147:     if len(legs) > 2:
1148:         return (f"{len(legs)} of the {n_total} legs turn together",
1149:                 f"{n_total} 项中有 {len(legs)} 项同时反转")
1150:     names_en = " and ".join(c["label_en"].lower() for c in legs)
1151:     names_zh = "与".join(c["label_zh"] for c in legs)
1152:     scores = ", ".join(str(c["score"]) for c in legs)
1153:     scores_zh = "、".join(str(c["score"]) for c in legs)
1154:     if len(legs) == 1:
1155:         return (f"{names_en} {verb_en} (now {scores}/100)",
1156:                 f"{names_zh}{verb_zh}（现 {scores_zh}/100）")
1157:     both_en = "both firm up" if direction > 0 else "both break down"
1158:     return (f"{names_en} {both_en} (now {scores}/100)",
1159:             f"{names_zh}同时{verb_zh}（现 {scores_zh}/100）")
1160: 
1161: 
1162: def _radar_escalation_claim(radar: dict | None, target: float) -> tuple[str, str] | None:
1163:     """Would an already-authorized radar's NEXT-WORSE state drive the score under `target`?
1164: 
1165:     Advisory radar states have no ceiling, so escalation alone is insufficient: the future read
1166:     would also have to earn confirmed-evidence authority. We do not manufacture that hypothetical.
1167:     Uses the same _ceiling_for as the live override once authority is already established.
1168:     """
1169:     st = (radar or {}).get("state")
1170:     if st not in ("caution", "elevated") or not (radar or {}).get("can_force"):
1171:         return None
1172:     nxt = "elevated" if st == "caution" else "risk-off"
1173:     try:
1174:         ceil = _ceiling_for(nxt, bool((radar or {}).get("severe_gated")),
1175:                             (radar or {}).get("amp_keys") or [], _ms_calib())
1176:     except Exception:  # noqa: BLE001 — claim helper, never fatal
1177:         return None
1178:     if ceil is None or ceil > target:
1179:         return None
1180:     return (f"the Risk Radar escalates to {nxt}",
1181:             f"风险雷达升级至{_RADAR_ZH.get(nxt, nxt)}")
1182: 
1183: 
1184: def _flip_clause(verdict: str, direction: int, claim: tuple[str, str]) -> tuple[str, str]:
1185:     prefix, tier_zh = _FLIP_SHAPE[(verdict, direction)]
1186:     return (f"{prefix}{claim[0]}.", f"→ 若{claim[1]}，则转「{tier_zh}」。")
1187: 
1188: 
1189: def _flip_text(comps: list, verdict: str, *, raw_score=None, radar: dict | None = None,
1190:                overrides: list | None = None) -> tuple[str, str]:
1191:     """A falsifiable 'what tips this' line — every clause must name something that could
1192:     ARITHMETICALLY move the verdict.
1193: 
1194:     IMPOSSIBLE-CLAIM REPAIR (audit 2026-07-29). This was built purely off the weakest/strongest
1195:     leg and never saw raw_score, the radar ceiling, or the hard-force overrides — so on a
1196:     radar-capped day (12 of 21 logged sessions) it printed
1197: 
1198:         "→ Green if risk appetite firms up (now 42/100); → Red if it deteriorates further."
1199: 
1200:     with BOTH clauses unreachable. That leg carries 0.18 of a den-1.0 blend: driving it to 100
1201:     lifts the blend 63 -> 73 and the DISPLAYED score stays min(73, ceiling 56) = 56, still Mixed;
1202:     driving it to 0 pulls the blend only to 55, nowhere near the 41 the Risk-off band needs. The
1203:     line now derives from whichever constraint actually BINDS — the radar ceiling or a hard-force
1204:     override when one of those holds the dial, otherwise the specific legs whose full move really
1205:     does cross the boundary, and the radar's own next-state escalation when that is the shorter
1206:     path down. Called with `comps` alone (no raw_score) it keeps the legacy weakest-leg wording:
1207:     the arithmetic is not available to check, so no claim is manufactured. EN + ZH.
1208:     """
1209:     if not comps:
1210:         return "", ""
1211:     weakest = min(comps, key=lambda c: c["score"])
1212:     strongest = max(comps, key=lambda c: c["score"])
1213:     have_math = (raw_score is not None
1214:                  and sum(float(c.get("weight") or 0.0) for c in comps) > 0)
1215:     if not have_math:
1216:         # legacy shape — unchanged wording, unchanged prefixes (scripts/check_ms_board_coherence)
1217:         if verdict == "RISK_ON":
1218:             return (f"→ Mixed if {weakest['label_en'].lower()} rolls over "
1219:                     f"(now {weakest['score']}/100, the weakest leg).",
1220:                     f"→ 若{weakest['label_zh']}转弱（现 {weakest['score']}/100，最弱项）则转为「混合」。")
1221:         if verdict == "RISK_OFF":
1222:             return (f"→ Mixed when {strongest['label_en'].lower()} stabilises and stress fades.",
1223:                     f"→ 待{strongest['label_zh']}企稳且压力护栏解除后转为「混合」。")
1224:         return (f"→ Green if {weakest['label_en'].lower()} firms up (now {weakest['score']}/100); "
1225:                 f"→ Red if it deteriorates further.",
1226:                 f"→ 若{weakest['label_zh']}转强（现 {weakest['score']}/100）则转「偏多」；"
1227:                 f"进一步恶化则转「避险」。")
1228: 
1229:     caps = _flip_constraints(radar, overrides)
1230:     n = len(comps)
1231:     parts_en, parts_zh = [], []
1232: 
1233:     # ---- UPSIDE: the next-better verdict ------------------------------------------------
1234:     tgt = _FLIP_UP_TARGET.get(verdict)
1235:     if tgt is not None:
1236:         # a cap sitting BELOW the target is what binds — the blend cannot out-run it
1237:         binding = min((c for c in caps if c[0] < tgt), key=lambda c: c[0], default=None)
1238:         claim = None
1239:         if binding is not None:
1240:             claim = (binding[1], binding[2])
1241:         else:
1242:             legs = _legs_to_cross(comps, raw_score, tgt, 1)
1243:             if legs:
1244:                 claim = _legs_claim(legs, 1, n)
1245:         if claim:
1246:             en, zh = _flip_clause(verdict, 1, claim)
1247:             parts_en.append(en)
1248:             parts_zh.append(zh)
1249: 
1250:     # ---- DOWNSIDE: the next-worse verdict -----------------------------------------------
1251:     tgt = _FLIP_DOWN_TARGET.get(verdict)
1252:     if tgt is not None:
1253:         legs = _legs_to_cross(comps, raw_score, tgt, -1)
1254:         esc = _radar_escalation_claim(radar, tgt)
1255:         # prefer whichever route needs FEWER independent things to happen; the radar escalating
1256:         # is one move, so it wins over any multi-leg breakdown.
1257:         claim = None
1258:         if esc is not None and (legs is None or len(legs) > 1):
1259:             claim = esc
1260:         elif legs:
1261:             claim = _legs_claim(legs, -1, n)
1262:         elif esc is not None:
1263:             claim = esc
1264:         if claim:
1265:             en, zh = _flip_clause(verdict, -1, claim)
1266:             parts_en.append(en)
1267:             parts_zh.append(zh)
1268: 
1269:     if not parts_en:
1270:         return "", ""
1271:     return " ".join(parts_en), "".join(parts_zh)
1272: 
1273: 
1274: # --------------------------------------------------------------- store ----
1275: # The verdict is the SINGLE SOURCE OF TRUTH for "how risk-on is the market" across the
1276: # whole site. The macro page computes it (with the full feature frame); persisting it here
1277: # lets OTHER pages (engine/sector_central.py) and the intraday live engine
1278: # (scripts/build_risk_state.py) consume the SAME radar-aware verdict instead of each
1279: # re-deriving a (divergent) read — which is exactly how sector_central used to disagree
1280: # with macro.html. Build order already runs build_site before build_sector_central, so the
1281: # file is fresh when the latter reads it. Never raises.
1282: def _store_path(root=None):
1283:     from pathlib import Path
1284:     from lib import config
1285:     base = config.data_dir() if root is None else (Path(root) / "data")
1286:     return base / "market_state" / "latest.json"
1287: 
1288: 
1289: def persist(snap: dict | None, root=None, now=None) -> None:
1290:     """Write the canonical market-state snapshot to data/market_state/latest.json.
1291: 
1292:     Freshness contract (2026-07-07 stale-regime incident):
1293:     - NO-REGRESS: refuse to overwrite a persisted snapshot whose asof is NEWER than the
1294:       incoming one. Two lanes raced that day (a stale scheduled engine run + a manually
1295:       re-dispatched fresh one); ordering luck decided which verdict the site carried.
1296:       Equal asof always overwrites (same-session recomputes are routine).
1297:     - SELF-DECLARING STALENESS: stamp snap["freshness"] against the NYSE calendar
1298:       (lib.nyse_calendar — independent of every price store, so it still fires when the
1299:       whole collection push dies and all stores agree on the stale date), so downstream
1300:       consumers (build_risk_state's nightly backbone, macro.html) can see a stale read
1301:       without cross-referencing the store. Both legs degrade-never-raise."""
1302:     if not snap:
1303:         return
1304:     try:
1305:         p = _store_path(root)
1306:         incoming = str(snap.get("asof") or "")
1307:         try:
1308:             if incoming and p.exists():
1309:                 existing = str((json.loads(p.read_text()) or {}).get("asof") or "")
1310:                 if existing and incoming < existing:
1311:                     log.warning("market_state persist REFUSED: incoming asof %s < persisted %s "
1312:                                 "(no-regress guard)", incoming, existing)
1313:                     return
1314:         except Exception as e:  # noqa: BLE001 — an unreadable existing file never blocks
1315:             log.warning("market_state no-regress check skipped: %s", e)
1316:         try:
1317:             from lib import nyse_calendar
1318:             expected = str(nyse_calendar.expected_last_session(now))
1319:             fresh = {
1320:                 "data_asof": incoming or None,
1321:                 "expected_asof": expected,
1322:                 # PRICE-calendar staleness — unchanged meaning, unchanged consumers.
1323:                 "stale": bool(incoming) and incoming < expected,
1324:             }
1325:             # NO LONGER SELF-CERTIFYING (audit 2026-07-29). `stale` above is derived from the
1326:             # snapshot's own asof, which comes from the FRAME calendar — and the frame ffills slow
1327:             # macro series onto trading days, so it reported stale:false on a session where the
1328:             # NFCI print was 12 days old and had already dropped out of the drawdown composite and
1329:             # the credit leg. The per-input vintages (engine/conditions._input_vintages) are real
1330:             # per-store last-print dates, so the stamp now carries a claim it can actually back.
1331:             # Surfacing is the template lane's call; this only makes the truth available.
1332:             v = (snap.get("input_vintages") or {})
1333:             stale_inputs = sorted(k for k, d in v.items() if (d or {}).get("stale"))
1334:             ages = [d.get("age_days") for d in v.values()
1335:                     if isinstance(d, dict) and d.get("age_days") is not None]
1336:             fresh["inputs"] = v
1337:             fresh["stale_inputs"] = stale_inputs
1338:             fresh["any_input_stale"] = bool(stale_inputs)
1339:             fresh["worst_input_age_days"] = (max(ages) if ages else None)
1340:             snap["freshness"] = fresh
1341:         except Exception as e:  # noqa: BLE001 — the stamp is additive, never the gate
1342:             log.warning("market_state freshness stamp skipped: %s", e)
1343:         p.parent.mkdir(parents=True, exist_ok=True)
1344:         p.write_text(json.dumps(snap, ensure_ascii=False, default=str))
1345:     except Exception as e:  # noqa: BLE001 — additive, never fatal
1346:         log.warning("market_state persist failed: %s", e)
1347: 
1348: 
1349: def load_persisted(root=None) -> dict | None:
1350:     """Read the persisted canonical snapshot; None if absent/unreadable."""
1351:     try:
1352:         p = _store_path(root)
1353:         if p.exists():
1354:             return json.loads(p.read_text())
1355:     except Exception as e:  # noqa: BLE001
1356:         log.warning("market_state load_persisted failed: %s", e)
1357:     return None
```

## COMPLETE CANDIDATE SOURCE: engine/risk_radar_intl.py
```
1: """Risk Radar (international) — a genuinely-leading, calibrated forward-drawdown radar
2: for China, Hong Kong and Canada, mirroring the US engine.risk_radar but built from the
3: drivers that *do* lead these markets.
4: 
5: WHY THIS EXISTS
6: ---------------
7: The old China/HK/CA conditions layer (engine/china_conditions.py et al.) concluded there
8: was "no forward-drawdown edge" — but it only ever tested China-INTERNAL froth legs (margin
9: balance, turnover mania, valuation extension), which are indeed dead/contrarian (A-shares
10: mean-revert on those). It never tested the EXTERNAL drivers the owner flagged: as China (and,
11: more recently, HK and Canada) has coupled to US policy, drawdowns are led by US rate shocks,
12: a widening US–China yield gap, a strengthening dollar / depreciating yuan, AND a broad-based
13: breadth breakdown (China corrections sink all sectors — "all boats" — unlike the US rotational
14: tape, which makes the breadth leg genuinely leading rather than self-cancelling).
15: 
16: VALIDATION (research harness, causal trailing-504d percentiles, block-permutation p, split-half
17: + 2016+ era; SHCOMP 1997+, confirmed on CSI 300):
18:   breadth collapse (% < 200dMA)     lift 1.97 (≥10%/42d), 2016+ 3.13x, p=0.04, leading (1.67x near highs)
19:   US 2y / real-10y / 10y rate shock 1.5–1.7x full, 2016+ 2.4–3.3x, p≤0.04, sign-stable
20:   US–China 10y differential widening 1.61x, 2016+ 2.78x, p=0.03
21:   USD/CNH depreciation               1.9x, h2 2.6x
22:   composite (this engine)            ≥10%/42d 2.07x (h1/h2 2.28/2.00, p=0.01); CSI300 2.22x
23: HK generalises moderately (≈1.5x, recent-era only — coupling is recent), Canada weakly
24: (≈1.4–1.6x recent, commodity-driven). Honest per-market calibration + caveats below.
25: 
26: HONESTY: the edge is MODEST (~1.4–2x conditional lift at the extremes, not a forecast) and
27: concentrated where it should be (a context gate keeps the LOUD tiers quiet until the broad
28: index is actually below its 200-day line). Every probability here is MEASURED from the market's
29: own history; the de-risk response is SIZING, not selection. All signals are causal/leak-free
30: (trailing-window percentiles). No public function raises into the build.
31: """
32: from __future__ import annotations
33: 
34: import json
35: import logging
36: from dataclasses import dataclass, field
37: from pathlib import Path
38: 
39: import numpy as np
40: import pandas as pd
41: 
42: from engine.indicators import pct_rank_window
43: from lib import config, store
44: 
45: log = logging.getLogger(__name__)
46: 
47: _PCT_WIN = 504                       # ~2y trailing causal percentile window (matches US radar)
48: _EXT_PCT_WIN = 2520                  # ~10y causal window for the raw-extension percentile (long-history, NOT the self-defeating 252d z)
49: _EXT_PARABOLIC = 0.98                # extension percentile at/above which the regime counts as parabolic
50: _GATE_MEMORY = 60                    # sessions the parabolic gate stays open after the last parabolic reading
51: _STATE_ORDER = ["calm", "watch", "caution", "elevated", "risk-off"]
52: # scare-meter colour bands on the 0-100 per-scare score (mean of leg percentiles * 100)
53: _SCARE_BANDS = {"watch": 55.0, "caution": 68.0, "elevated": 78.0, "risk_off": 88.0}
54: _GROSS = {"calm": 1.0, "watch": 0.97, "caution": 0.90, "elevated": 0.78, "risk-off": 0.62}
55: _DISCLAIMER = ("Evidence-gated leading-risk radar — built only from the external drivers (US "
56:                "rate shocks, US–China yield gap, USD/FX) + breadth that MEASURABLY lead this "
57:                "market's drawdowns (not the internal froth legs, which mean-revert). Edge is "
58:                "modest (~1.4–2x at the extremes, not a forecast); odds are measured from the "
59:                "market's own history; de-risk = sizing, not selection.")
60: 
61: 
62: # --- store readers (causal) --------------------------------------------------
63: def _read(group: str, name: str, col: str = "close") -> pd.Series | None:
64:     df = store.read(group, name)
65:     if df is None or getattr(df, "empty", True):
66:         return None
67:     c = col if col in df.columns else df.columns[0]
68:     s = df[c].dropna()
69:     if s.empty:
70:         return None
71:     s.index = pd.to_datetime(s.index)
72:     return s.sort_index()
73: 
74: 
75: def _pct(s: pd.Series | None) -> pd.Series | None:
76:     """Trailing-504d causal percentile (0-1). None-safe."""
77:     if s is None:
78:         return None
79:     s = s.dropna()
80:     return pct_rank_window(s, _PCT_WIN) if len(s) else None
81: 
82: 
83: # --- individual sub-leg builders (each → causal 'risk-rising' percentile on idx) ---
84: _RATE_SUBS = {
85:     "us_rate_2y":  ("fred", "DGS2", "us2y"),
86:     "us_real_rate": ("fred", "DFII10", "us10y_real"),
87:     "us_rate_10y": ("fred", "DGS10", "us10y"),
88: }
89: 
90: 
91: def _sub_legs(idx: pd.DatetimeIndex, profile: "RadarProfile") -> dict:
92:     """{sub_code: causal percentile SERIES on idx} for every sub-leg the profile uses."""
93:     out: dict[str, pd.Series] = {}
94:     # US-rate shocks (21d change percentile) — shared by all markets
95:     for code, (g, n, c) in _RATE_SUBS.items():
96:         s = _read(g, n, c)
97:         if s is not None:
98:             out[code] = _pct(s.reindex(idx).ffill().diff(21))
99:     # USD / FX
100:     if profile.key == "cn":
101:         cnh = _read("yahoo", "CNH_F")
102:         dxy = _read("yahoo", "DX-Y.NYB")
103:         fx = cnh.reindex(idx).ffill().pct_change(21) if cnh is not None else None
104:         if dxy is not None:                                   # DXY 63d ROC fills pre-2013 CNH gap
105:             d = dxy.reindex(idx).ffill().pct_change(63)
106:             fx = d if fx is None else fx.combine_first(d)
107:         out["usd_cnh"] = _pct(fx)
108:         u10 = _read("fred", "DGS10", "us10y")
109:         cgb = store.read("china_property", "cgb")
110:         if u10 is not None and cgb is not None and "cgb_10y" in getattr(cgb, "columns", []):
111:             c10 = cgb["cgb_10y"].dropna(); c10.index = pd.to_datetime(c10.index)
112:             diff = u10.reindex(idx).ffill() - c10.sort_index().reindex(idx).ffill()
113:             out["us_cn_diff"] = _pct(diff.diff(21))           # widening gap = outflow pressure
114:     elif profile.fx_pair is not None:
115:         # per-market FX-depreciation leg: local-currency weakness = outflow pressure.
116:         # fx_risk_sign orients the pair so RISING series = depreciation risk; DXY 63d ROC
117:         # fills the pre-pair era (same stitch the CN leg uses for pre-2013 CNH).
118:         pair = _read(*profile.fx_pair)
119:         fx = pair.reindex(idx).ffill().pct_change(21) * profile.fx_risk_sign if pair is not None else None
120:         dxy = _read("yahoo", "DX-Y.NYB")
121:         if dxy is not None:
122:             d = dxy.reindex(idx).ffill().pct_change(63)
123:             fx = d if fx is None else fx.combine_first(d)
124:         out[profile.fx_code or "fx_depreciation"] = _pct(fx)
125:     else:
126:         dxy = _read("yahoo", "DX-Y.NYB")
127:         if dxy is not None:
128:             out["usd_strength"] = _pct(dxy.reindex(idx).ffill().pct_change(63))
129:     # breadth collapse (% < 200dMA) — where deep history exists
130:     if profile.breadth_group:
131:         br = store.read(profile.breadth_group, "breadth")
132:         if br is not None and "pct_above_200" in getattr(br, "columns", []):
133:             b = br["pct_above_200"].dropna(); b.index = pd.to_datetime(b.index)
134:             if len(b) >= 500:
135:                 out[profile.breadth_code] = _pct(-b.sort_index().reindex(idx).ffill())
136:     # raw-extension percentile legs (melt-up detector): px/200dma-1 ranked in a LONG causal
137:     # window — the 2026 KOSPI class. A trailing-1y z would deflate exactly at the top
138:     # (the parabola inflates its own baseline); the ~10y percentile does not.
139:     for g, names, code in profile.ext_sources:
140:         members = []
141:         for n in (names if isinstance(names, tuple) else (names,)):
142:             s = _read(g, n)
143:             if s is None or len(s) < 300:
144:                 continue
145:             px = s.reindex(idx).ffill()
146:             ma = px.rolling(200, min_periods=120).mean()
147:             p = pct_rank_window((px / ma - 1.0).dropna(), _EXT_PCT_WIN)
148:             members.append(p)
149:         if members:
150:             out[code] = pd.concat(members, axis=1).mean(axis=1) if len(members) > 1 else members[0]
151:     return {k: v for k, v in out.items() if v is not None}
152: 
153: 
154: # --- profile -----------------------------------------------------------------
155: @dataclass(frozen=True)
156: class RadarProfile:
157:     key: str                          # 'cn' | 'hk' | 'ca' | 'kr' | 'jp' | 'tw' | 'in' | 'au' | 'gb' | 'ez'
158:     bench: tuple                      # (store group, name) — the index drawdowns are measured on
159:     breadth_group: str | None         # store group for the breadth frame (None = no breadth leg)
160:     breadth_code: str                 # sub-leg display code for the breadth leg
161:     comp_legs: tuple                  # ((comp_key, (sub_codes...), weight), ...) — composite structure
162:     scares: tuple                     # ((scare_key, tier, label_en, label_zh, (comp_keys), (sub_codes)), ...)
163:     bands: dict                       # {watch,caution,elevated,risk_off} on the 0-100 composite percentile
164:     prob_cal: dict                    # {h5/h10/h21: {state: P(>=5% drawdown within h)}}
165:     prob_base: dict                   # {h5,h10,h21} unconditional base rates
166:     caveat_en: str
167:     caveat_zh: str
168:     # --- 7-market extension fields (2026-07-16). Defaults preserve CN/HK/CA behavior exactly. ---
169:     fx_pair: tuple | None = None      # (store group, name) of the market's FX pair, e.g. ("intl", "USDKRW=X")
170:     fx_risk_sign: int = 1             # +1: pair RISES = local ccy depreciates (USD/local quote); -1: pair FALLS = depreciates (local/USD quote)
171:     fx_code: str = ""                 # sub-leg display code, e.g. "krw_depreciation"
172:     ext_sources: tuple = ()           # ((group, name_or_name_tuple, sub_code), ...) — raw-extension percentile legs; a tuple of names = basket (mean of member percentiles)
173:     gate_mode: str = "below_200dma"   # "below_200dma" (legacy) | "below_or_recent_parabolic" (melt-up markets); INTL-50: no macro gate harms Korea
174:     disclaimer: str | None = None     # per-profile override; None = module _DISCLAIMER (legacy)
175: 
176: 
177: def _band(score, bands: dict) -> str:
178:     if score is None or (isinstance(score, float) and np.isnan(score)):
179:         return "calm"
180:     if score >= bands["risk_off"]:
181:         return "risk-off"
182:     if score >= bands["elevated"]:
183:         return "elevated"
184:     if score >= bands["caution"]:
185:         return "caution"
186:     if score >= bands["watch"]:
187:         return "watch"
188:     return "calm"
189: 
190: 
191: def _last(s: pd.Series | None):
192:     if s is None:
193:         return None
194:     s = s.dropna()
195:     return float(s.iloc[-1]) if len(s) else None
196: 
197: 
198: def _calib(profile: "RadarProfile", root=None) -> dict:
199:     """Per-market calibration = the baked profile surface, OPTIONALLY overlaid by the bounded
200:     tuner (data/risk_radar_intl/<key>_calibration.json, engine/risk_radar_intl_tune.py). The
201:     overlay may adjust the prob surface only (the displayed odds become measured from the
202:     radar's own track record); the bands stay structural. Absent file ⇒ baked defaults."""
203:     cal = {"prob_cal": {h: dict(v) for h, v in profile.prob_cal.items()},
204:            "prob_base": dict(profile.prob_base), "bands": dict(profile.bands)}
205:     try:
206:         base = config.data_dir() if root is None else (Path(root) / "data")
207:         p = base / "risk_radar_intl" / f"{profile.key}_calibration.json"
208:         if p.exists():
209:             ov = json.loads(p.read_text())
210:             for h, d in (ov.get("prob_cal") or {}).items():
211:                 if h in cal["prob_cal"]:
212:                     cal["prob_cal"][h].update({k: float(v) for k, v in d.items()})
213:             if ov.get("prob_base"):
214:                 cal["prob_base"].update({k: float(v) for k, v in ov["prob_base"].items()})
215:     except Exception as e:  # noqa: BLE001
216:         log.warning("risk_radar_intl calib overlay(%s) failed: %s", profile.key, e)
217:     return cal
218: 
219: 
220: def _probs(cal: dict, state: str) -> dict:
221:     pc, base = cal["prob_cal"], cal["prob_base"]
222:     out = {h: pc[h].get(state, base[h]) for h in ("h5", "h10", "h21")}
223:     out["base_h5"], out["base_h10"], out["base_h21"] = base["h5"], base["h10"], base["h21"]
224:     out["lift_h21"] = round(out["h21"] / base["h21"], 2) if base["h21"] else None
225:     out["measure"] = ">=5% index pullback within h business days (measured on this market's own history)"
226:     return out
227: 
228: 
229: def _gate_series(B: pd.Series, sub: dict, profile: "RadarProfile") -> pd.Series:
230:     """True where the context gate is OPEN (loud tiers allowed). Causal. Legacy mode:
231:     index below its 200dma ("all boats" confirmation). Melt-up mode additionally opens
232:     while the extension percentile has printed parabolic (>= _EXT_PARABOLIC) within the
233:     last _GATE_MEMORY sessions — at a parabolic top the index is far ABOVE its 200dma,
234:     so the legacy gate would structurally silence the radar exactly when it matters
235:     (KOSPI 2026-06; INTL-50 ruling: no macro gate, only price/extension context gate)."""
236:     ma = B.rolling(200, min_periods=120).mean()
237:     gate = (B < ma).fillna(False)
238:     if profile.gate_mode == "below_or_recent_parabolic" and profile.ext_sources:
239:         e = sub.get(profile.ext_sources[0][2])
240:         if e is not None:
241:             recent_para = e.rolling(_GATE_MEMORY, min_periods=1).max() >= _EXT_PARABOLIC
242:             gate = gate | recent_para.reindex(B.index).fillna(False)
243:     return gate
244: 
245: 
246: def _composition_coverage(profile, sub, comp, index):
247:     """Availability of derived inputs, not feed freshness or forecast confidence."""
248:     index = pd.Index(index)
249:     current = index[-1] if len(index) else None
250:     complete = pd.Series(True, index=index, dtype=bool)
251:     raw_available = pd.Series(False, index=index, dtype=bool)
252:     groups, members_available, members_expected = [], 0, 0
253:     available_weight = total_weight = 0.0
254:     legs = tuple(getattr(profile, "comp_legs", ()) or ())
255:     for key, codes, weight in legs:
256:         masks = {}
257:         for code in codes:
258:             values = (sub or {}).get(code)
259:             values = (values.reindex(index) if values is not None else
260:                       pd.Series(np.nan, index=index, dtype=float))
261:             masks[code] = pd.Series(np.isfinite(values), index=index)
262:         frame = pd.DataFrame(masks, index=index)
263:         present = [code for code in codes if current is not None and bool(frame.at[current, code])]
264:         complete &= frame.all(axis=1) if len(codes) else False
265:         if weight > 0 and len(codes):
266:             raw_available |= frame.any(axis=1)
267:         groups.append({"key": key, "expected": list(codes), "present": present,
268:                        "missing": [c for c in codes if c not in present], "weight": weight})
269:         members_available += len(present)
270:         members_expected += len(codes)
271:         total_weight += weight
272:         available_weight += weight if present else 0.0
273:     finite_comp = (comp[np.isfinite(comp)] if comp is not None else pd.Series(dtype=float))
274:     if current is not None:
275:         finite_comp = finite_comp.loc[finite_comp.index <= current]
276:     current_score = bool(current is not None and current in finite_comp.index)
277:     score_asof = str(pd.Timestamp(finite_comp.index[-1]).date()) if len(finite_comp) else None
278:     recent = finite_comp.tail(30)
279:     window = index[(index >= recent.index[0]) & (index <= current)] if len(recent) else index[:0]
280:     incomplete_sessions = int((~complete.reindex(window, fill_value=False)).sum())
281:     # _pct drops null raw rows before its trailing _PCT_WIN-observation rank.
282:     # Cover the union feeding the compared ranks, including benchmark gaps in it.
283:     reference_observations = index[raw_available]
284:     reference_window = index[:0]
285:     if len(recent) and current is not None:
286:         first = int(reference_observations.searchsorted(recent.index[0]))
287:         first = max(0, first - _PCT_WIN + 1)
288:         reference_observations = reference_observations[first:]
289:         reference_observations = reference_observations[reference_observations <= current]
290:         if len(reference_observations):
291:             reference_window = index[(index >= reference_observations[0]) & (index <= current)]
292:     else:
293:         reference_observations = reference_observations[:0]
294:     reference_incomplete = int((~complete.reindex(reference_window, fill_value=False)).sum())
295:     status = ("UNAVAILABLE" if not members_available else
296:               "COMPLETE" if members_available == members_expected else "PARTIAL")
297:     return {
298:         "status": status, "freshness": "not_assessed",
299:         "asof": str(pd.Timestamp(current).date()) if current is not None else None,
300:         "score_asof": score_asof, "score_current": current_score,
301:         "groups_expected": len(legs),
302:         "groups_available": sum(bool(g["present"]) for g in groups),
303:         "members_expected": members_expected, "members_available": members_available,
304:         "group_weight_coverage": available_weight / total_weight if total_weight else None,
305:         "groups": groups, "comparison_sessions": len(window),
306:         "comparison_incomplete_sessions": incomplete_sessions,
307:         "comparison_reference_sessions": len(reference_window),
308:         "comparison_reference_observations": len(reference_observations),
309:         "comparison_reference_incomplete_sessions": reference_incomplete,
310:         "comparison_reference_rank_window": _PCT_WIN,
311:         "comparison_comparable": bool(current_score and status == "COMPLETE"
312:                                       and len(recent) >= 10 and not incomplete_sessions
313:                                       and not reference_incomplete),
314:         "calibration_status": "unreviewed_corrected_construction",
315:         "method": "available_group_weight.v1",
316:     }
317: def composite_series(profile: "RadarProfile", root=None):
318:     """(B, sub, comp, gate) — bench closes, sub-leg percentile dict, blended composite
319:     trailing percentile (0-1), and the boolean context-gate series. None when no data.
320:     THE single construction compute() and scripts/calibrate_risk_radar_intl.py share."""
321:     B = _read(*profile.bench)
322:     if B is None or len(B) < 300:
323:         return None, None, None, None
324:     idx = B.index
325:     sub = {c: s.reindex(idx).replace([np.inf, -np.inf], np.nan)
326:            for c, s in (_sub_legs(idx, profile) or {}).items() if s is not None}
327:     if not sub:
328:         return None, None, None, None
329: 
330:     # composite-leg latest percentiles + series (the calibrated structure)
331:     comp_series_parts: dict[str, tuple] = {}
332:     for comp_key, sub_codes, w in profile.comp_legs:
333:         members = [sub[c] for c in sub_codes if c in sub]
334:         if not members:
335:             continue
336:         ser = pd.concat(members, axis=1).mean(axis=1)
337:         comp_series_parts[comp_key] = (ser, w)
338: 
339:     # blended composite → trailing percentile → 0-1 risk score
340:     num = den = None
341:     for ser, w in comp_series_parts.values():
342:         col = ser.fillna(0.0) * w
343:         av = ser.notna().astype(float) * w
344:         num = col if num is None else num + col
345:         den = av if den is None else den + av
346:     if num is None:
347:         return None, None, None, None
348: 
349:     comp = pct_rank_window((num / den.replace(0, np.nan)).dropna(), _PCT_WIN)
350:     gate = _gate_series(B, sub, profile)
351:     return B, sub, comp, gate
352: 
353: 
354: def _trajectory(comp, B, cal, window: int = 30, gate: pd.Series | None = None) -> dict | None:
355:     """Recent PATH of this market's composite radar — has it peaked + started rolling over, and how
356:     fast are the pullback odds dropping? Powers the de-escalation panel (engine/risk_radar_recovery).
357:     Reuses the SHARED classifier (engine/risk_radar._trajectory_from_series) so the phase logic is
358:     identical to the US radar. Leak-free (comp is a causal trailing percentile). Never raises.
359: 
360:     gate: when given, use it in place of the internally-computed below series. For legacy profiles
361:     the passed gate equals the internally-computed below → identical output."""
362:     try:
363:         from engine.risk_radar import _trajectory_from_series
364:         intensity = (comp.dropna() * 100.0)
365:         if len(intensity) < 10:
366:             return None
367:         bands = cal["bands"]
368:         if gate is not None:
369:             below = gate.reindex(intensity.index).fillna(False)
370:         else:
371:             ma = B.rolling(200, min_periods=120).mean()
372:             below = (B < ma).reindex(intensity.index).fillna(False)   # context gate: index < 200dma
373:         win = intensity.tail(window)
374:         states, odds = [], []
375:         for d, v in win.items():
376:             st = _band(v, bands)
377:             if not bool(below.get(d, False)) and _STATE_ORDER.index(st) > _STATE_ORDER.index("caution"):
378:                 st = "caution"                                     # gate caps the loud tiers
379:             states.append(st)
380:             odds.append(_probs(cal, st)["h21"])
381:         return _trajectory_from_series(win, states, pd.Series(odds, index=win.index), bands["caution"])
382:     except Exception as e:  # noqa: BLE001 — additive, never fatal
383:         log.warning("risk_radar_intl trajectory failed: %s", e)
384:         return None
385: 
386: 
387: def _qualify_composition_inference(result):
388:     """Separate unreviewed legacy lookups from current forecasts and sizing."""
389:     quality = result.get("composition") or {}
390:     status = quality.get("calibration_status")
391:     if status != "unreviewed_corrected_construction":
392:         return result
393:     reference = dict(result.get("legacy_calibration_reference") or {})
394:     reference.setdefault("kind", "unreviewed_legacy_surface_lookup")
395:     reference.setdefault("drawdown_prob", result.get("drawdown_prob"))
396:     reference.setdefault("gross_factor", result.get("gross_factor"))
397:     trajectory = result.get("trajectory")
398:     if trajectory:
399:         trajectory = dict(trajectory)
400:         keys = ("odds_now", "odds_peak", "odds_delta")
401:         reference.setdefault("trajectory_odds", {k: trajectory.get(k) for k in keys})
402:         trajectory.update({k: None for k in keys})
403:         trajectory["calibration_status"] = status
404:         result["trajectory"] = trajectory
405:     result["legacy_calibration_reference"] = reference
406:     result["drawdown_prob"] = None
407:     result["gross_factor"] = None
408:     return result
409: 
410: def compute(profile: "RadarProfile", root=None) -> dict:
411:     """Live calibrated radar snapshot for `profile`. Reads the store; never raises a useful
412:     payload away. Returns the (risk_radar_intl.v1) dict the market-state radar mapping consumes."""
413:     effective_disclaimer = profile.disclaimer or _DISCLAIMER
414:     null = {"schema": "risk_radar_intl.v1", "state": None, "market": profile.key,
415:             "degraded_reason": "no_data", "disclaimer": effective_disclaimer}
416:     B, sub, comp, gate = composite_series(profile, root)
417:     coverage = _composition_coverage(profile, sub, comp, B.index if B is not None else [])
418:     null.update(composition=coverage, asof=coverage["asof"])
419:     if B is None or sub is None or comp is None or gate is None:
420:         return null
421:     if not coverage["score_current"]:
422:         null["degraded_reason"] = "no_current_composite"
423:         return null
424:     cal = _calib(profile, root)          # baked surface + the tuner's overlay, if any
425: 
426:     # composite-leg latest percentiles (for scares)
427:     comp_last: dict[str, float] = {}
428:     for comp_key, sub_codes, w in profile.comp_legs:
429:         members = [sub[c] for c in sub_codes if c in sub]
430:         if not members:
431:             continue
432:         ser = pd.concat(members, axis=1).mean(axis=1)
433:         comp_last[comp_key] = _last(ser.reindex([B.index[-1]]))
434: 
435:     top = float(comp.loc[B.index[-1]])
436:     top100 = round(top * 100) if top is not None else None
437: 
438:     # context gate — gate_open uses the shared gate series (legacy profiles: gate == below)
439:     gate_open = bool(gate.iloc[-1]) if len(gate) else False
440:     # also compute the raw price-vs-200dma bool (always present in the payload)
441:     ma = B.rolling(200, min_periods=120).mean()
442:     below_actual = bool(B.iloc[-1] < ma.iloc[-1]) if ma.dropna().size else False
443: 
444:     state_ungated = _band(top * 100 if top is not None else None, cal["bands"])
445:     state = state_ungated
446:     if not gate_open and _STATE_ORDER.index(state) > _STATE_ORDER.index("caution"):
447:         state = "caution"
448: 
449:     # per-scare meters (display) + plain-English firing legs
450:     scares = []
451:     for skey, tier, le, lz, comp_keys, sub_codes in profile.scares:
452:         vals = [comp_last[k] for k in comp_keys if comp_last.get(k) is not None]
453:         if not vals:
454:             continue
455:         sc = float(np.mean(vals)) * 100.0
456:         firing = [{"leg": c, "pctile": round(sub_latest, 3), "confirmed": bool(sub_latest >= 0.85)}
457:                   for c in sub_codes
458:                   if c in sub and (sub_latest := _last(sub[c].reindex([B.index[-1]]))) is not None and sub_latest >= 0.55]
459:         firing.sort(key=lambda d: -d["pctile"])
460:         scares.append({"scare": skey, "tier": tier, "label_en": le, "label_zh": lz,
461:                        "score": round(sc, 1), "band": _band(sc, _SCARE_BANDS),
462:                        "firing_legs": firing})
463:     scares.sort(key=lambda d: -d["score"])
464:     tierA = [s for s in scares if s["tier"] == "A"]
465:     dominant = tierA[0] if tierA else (scares[0] if scares else None)
466:     nhot = sum(1 for s in tierA if s["band"] in ("caution", "elevated", "risk-off"))
467: 
468:     if state == "calm":
469:         dom_en, dom_zh = "Calm — no driver elevated", "平静 — 无驱动升高"
470:     else:
471:         dom_en = dominant["label_en"] if dominant else "calm"
472:         dom_zh = dominant["label_zh"] if dominant else "平静"
473: 
474:     # context_gate payload: keep exact existing keys for ALL profiles; add recent_parabolic
475:     # only for new-mode profiles (gate_mode != "below_200dma") so cn/hk/ca payloads are byte-identical
476:     context_gate: dict = {"met": gate_open, "below_200dma": below_actual}
477:     if profile.gate_mode != "below_200dma" and profile.ext_sources:
478:         # memory semantics, same as _gate_series: parabolic printed within the last
479:         # _GATE_MEMORY sessions — a mid-crash receipt must still say "was parabolic"
480:         # (the memoryless latest-value read is the F1 self-erasing-flag failure)
481:         ext_s = sub.get(profile.ext_sources[0][2])
482:         recent = False
483:         if ext_s is not None:
484:             tail = ext_s.dropna().tail(_GATE_MEMORY)
485:             recent = bool(len(tail) and (tail >= _EXT_PARABOLIC).any())
486:         context_gate["recent_parabolic"] = recent
487: 
488:     return _qualify_composition_inference({
489:         "schema": "risk_radar_intl.v1",
490:         "asof": str(pd.Timestamp(B.index[-1]).date()),
491:         "market": profile.key,
492:         "composition": coverage,
493:         "state": state,
494:         "state_ungated": state_ungated,
495:         "top_score": top100,
496:         "dominant_scare": dominant["scare"] if dominant else None,
497:         "dominant_label_en": dom_en,
498:         "dominant_label_zh": dom_zh,
499:         "scares": scares,
500:         "drawdown_prob": _probs(cal, state),
501:         # de-escalation PATH (peaked? rolling over? how fast?) — reuses the composite series above.
502:         "trajectory": _trajectory(comp, B, cal, gate=gate),
503:         "gross_factor": _GROSS.get(state, 1.0),
504:         "conjunction": bool(nhot >= 2),
505:         "context_gate": context_gate,
506:         "caveat_en": profile.caveat_en,
507:         "caveat_zh": profile.caveat_zh,
508:         "disclaimer": effective_disclaimer,
509:     })
510: 
511: 
512: def snapshot(profile: "RadarProfile", root=None) -> dict:
513:     """IO wrapper the build persists to latest['risk_radar']. Never raises."""
514:     try:
515:         return compute(profile, root)
516:     except Exception as e:  # noqa: BLE001
517:         log.error("risk_radar_intl(%s) failed: %s", getattr(profile, "key", "?"), e)
518:         effective_disclaimer = getattr(profile, "disclaimer", None) or _DISCLAIMER
519:         return {"schema": "risk_radar_intl.v1", "state": None,
520:                 "market": getattr(profile, "key", None), "degraded_reason": "compute_error",
521:                 "composition": _composition_coverage(profile, {}, None, []),
522:                 "disclaimer": effective_disclaimer}
523: 
524: 
525: def cn_sleeve_chip(root=None) -> dict:
526:     """Return a DISPLAY-ONLY sleeve-size chip from the validated CN drawdown radar.
527: 
528:     Called by the five China surfaces (china_stocks board, sector_central, baskets_china,
529:     subsectors_china, sector_cycles_china) to thread the risk_radar_intl gross_factor into
530:     their emitted JSON without re-ranking names or gating inclusion.
531: 
532:     Masterplan W6-CN rule: regime sizes sleeves, never vetoes names.
533: 
534:     Passport:
535:       basis: measured
536:       validation: risk_radar_intl ledger (data/risk_radar_intl/cn_forward_log.jsonl)
537:       consumers: china_stocks board header, sector_central, baskets_china,
538:                  subsectors_china, sector_cycles_china (display chips only)
539:     """
540:     try:
541:         r = snapshot(CN_PROFILE, root)
542:         quality = r.get("composition") or {}
543:         if quality.get("calibration_status") == "unreviewed_corrected_construction":
544:             return {
545:                 "sleeve_factor": None, "sleeve_status": "unavailable",
546:                 "radar_state": r.get("state"), "radar_as_of": r.get("asof"),
547:                 "can_force": bool(r.get("can_force", False)),
548:                 "composition": quality,
549:                 "legacy_calibration_reference": r.get("legacy_calibration_reference"),
550:                 "label_en": "Sizing unavailable — forecast calibration under review",
551:                 "label_zh": "仓位建议暂缺 — 预测校准待核验",
552:                 "dominant_driver_en": r.get("dominant_label_en"),
553:                 "dominant_driver_zh": r.get("dominant_label_zh"),
554:                 "passport": {"basis": "descriptive", "validation": None,
555:                     "display_only": True, "degraded": True,
556:                     "note": "Descriptive context only; not a current sizing instruction."},
557:             }
558:         state = r.get("state") or "unknown"
559:         gross = r.get("gross_factor", 1.0)
560:         as_of = r.get("asof", "")
561:         can_force = bool(r.get("can_force", False))
562:         dominant = r.get("dominant_label_en") or "no driver elevated"
563:         dominant_zh = r.get("dominant_label_zh") or "无驱动升高"
564:         return {
565:             "sleeve_factor": round(float(gross), 2),
566:             "radar_state": state,
567:             "radar_as_of": as_of,
568:             "can_force": can_force,
569:             # Human-readable display string for the board header chip
570:             "label_en": f"Sleeve ×{gross:.2f} — CN drawdown radar: {state}",
571:             "label_zh": f"仓位 ×{gross:.2f} — CN回撤雷达：{state}",
572:             "dominant_driver_en": dominant,
573:             "dominant_driver_zh": dominant_zh,
574:             # Signal passport (research/ENGINE_FIX_MASTERPLAN.md §W6-CN)
575:             "passport": {
576:                 "basis": "measured",
577:                 "validation": "risk_radar_intl ledger (cn_forward_log.jsonl)",
578:                 "consumers": ["china_stocks", "sector_central_china", "baskets_china",
579:                               "subsectors_china", "sector_cycles_china"],
580:                 "display_only": True,
581:                 "note": ("Validated forward-drawdown composite on external drivers (US rate shocks, "
582:                          "USD/CNH, US-China yield gap, breadth). Sizes the SLEEVE, never vetoes names. "
583:                          "Lift: caution 1.97–3.13x, composite 2.07x p=0.01 (2016+ era)."),
584:             },
585:         }
586:     except Exception as e:  # noqa: BLE001 — sleeve chip is additive, never fatal
587:         log.warning("cn_sleeve_chip failed (%s); returning neutral", e)
588:         return {
589:             "sleeve_factor": 1.0, "radar_state": None, "radar_as_of": None,
590:             "can_force": False,
591:             "label_en": "Sleeve ×1.00 — CN drawdown radar: unavailable",
592:             "label_zh": "仓位 ×1.00 — CN回撤雷达：不可用",
593:             "passport": {"basis": "measured", "display_only": True, "degraded": True},
594:         }
595: 
596: 
597: # === per-market profiles =====================================================
598: # Composite-percentile bands shared across markets (calibrated: elevated+ ≈ top ~12% of
599: # history AND gated on a broad break; see research/ harness). Probability surfaces are each
600: # MEASURED from that market's own ≥5% forward-drawdown frequency by band (monotone at the top
601: # where the edge is real; modest, not a forecast).
602: _BANDS = {"watch": 58.0, "caution": 72.0, "elevated": 83.0, "risk_off": 91.0}
603: 
604: CN_PROFILE = RadarProfile(
605:     key="cn",
606:     bench=("china", "000001.SS"),                # Shanghai Composite (longest clean history)
607:     breadth_group="china_breadth", breadth_code="cn_breadth",
608:     comp_legs=(
609:         ("rateshock", ("us_rate_2y", "us_real_rate", "us_rate_10y"), 1.0),
610:         ("usd",       ("usd_cnh",),                                   0.6),
611:         ("diff",      ("us_cn_diff",),                                0.8),
612:         ("breadth",   ("cn_breadth",),                                1.0),
613:     ),
614:     scares=(
615:         ("rate_shock", "A", "US rate shock", "美债利率冲击",
616:          ("rateshock",), ("us_rate_2y", "us_real_rate", "us_rate_10y")),
617:         ("capital_flow", "A", "Capital outflow / FX", "资本外流／汇率",
618:          ("usd", "diff"), ("usd_cnh", "us_cn_diff")),
619:         ("breadth", "A", "Breadth breakdown (all-boats)", "广度普跌（普跌）",
620:          ("breadth",), ("cn_breadth",)),
621:     ),
622:     bands=_BANDS,
623:     prob_base={"h5": 0.072, "h10": 0.160, "h21": 0.305},
624:     prob_cal={
625:         "h5":  {"calm": 0.06, "watch": 0.08, "caution": 0.09, "elevated": 0.12, "risk-off": 0.15},
626:         "h10": {"calm": 0.13, "watch": 0.16, "caution": 0.18, "elevated": 0.21, "risk-off": 0.32},
627:         "h21": {"calm": 0.27, "watch": 0.32, "caution": 0.35, "elevated": 0.40, "risk-off": 0.50},
628:     },
629:     caveat_en=("Validated but modest: China drawdowns are led by US rate shocks, a widening US–China "
630:                "yield gap, dollar strength / yuan weakness, and a broad breadth breakdown (corrections "
631:                "sink all sectors). Odds are measured from A-share history; the internal froth legs are "
632:                "excluded (they mean-revert). Context, sized — not a forecast."),
633:     caveat_zh=("已验证但偏温和：A股回撤由美债利率冲击、中美利差走阔、美元走强／人民币走弱，以及广度普跌（调整时各板块同跌）"
634:                "领先。概率取自A股自身历史；内部拥挤腿已剔除（其均值回归）。用于定仓的背景，而非预测。"),
635: )
636: 
637: HK_PROFILE = RadarProfile(
638:     key="hk",
639:     bench=("hk", "_HSI"),                         # Hang Seng Index
640:     breadth_group=None, breadth_code="hk_breadth",
641:     comp_legs=(
642:         ("rateshock", ("us_rate_2y", "us_real_rate", "us_rate_10y"), 1.0),
643:         ("usd",       ("usd_strength",),                              0.6),
644:     ),
645:     scares=(
646:         ("rate_shock", "A", "US rate shock", "美债利率冲击",
647:          ("rateshock",), ("us_rate_2y", "us_real_rate", "us_rate_10y")),
648:         ("capital_flow", "A", "USD / HKD funding", "美元／港元资金",
649:          ("usd",), ("usd_strength",)),
650:     ),
651:     bands=_BANDS,
652:     prob_base={"h5": 0.077, "h10": 0.174, "h21": 0.309},
653:     prob_cal={
654:         "h5":  {"calm": 0.07, "watch": 0.08, "caution": 0.09, "elevated": 0.10, "risk-off": 0.16},
655:         "h10": {"calm": 0.16, "watch": 0.17, "caution": 0.19, "elevated": 0.22, "risk-off": 0.35},
656:         "h21": {"calm": 0.29, "watch": 0.31, "caution": 0.34, "elevated": 0.42, "risk-off": 0.54},
657:     },
658:     caveat_en=("Lighter than the China read and recent-era only: HK's US-coupling (HKD peg → US rates "
659:                "transmit directly, dollar strength) has only led HSI drawdowns since ~2016; deep HK "
660:                "breadth history is unavailable, so this leans on the external legs. Context, not a forecast."),
661:     caveat_zh=("较A股版更轻量，且仅近年有效：港元联系汇率使美债利率直接传导、美元走强——这种美股联动自约2016年起"
662:                "才领先恒指回撤；港股深度广度历史缺失，故以外部因子为主。仅作背景，而非预测。"),
663: )
664: 
665: CA_PROFILE = RadarProfile(
666:     key="ca",
667:     bench=("canada", "_GSPTSE"),                  # S&P/TSX Composite
668:     breadth_group="canada_breadth", breadth_code="ca_breadth",
669:     comp_legs=(
670:         ("rateshock", ("us_rate_2y", "us_real_rate", "us_rate_10y"), 1.0),
671:         ("usd",       ("usd_strength",),                              0.6),
672:         ("breadth",   ("ca_breadth",),                                1.0),
673:     ),
674:     scares=(
675:         ("rate_shock", "A", "US rate shock", "美债利率冲击",
676:          ("rateshock",), ("us_rate_2y", "us_real_rate", "us_rate_10y")),
677:         ("capital_flow", "A", "USD strength", "美元走强",
678:          ("usd",), ("usd_strength",)),
679:         ("breadth", "A", "Breadth breakdown", "广度破位",
680:          ("breadth",), ("ca_breadth",)),
681:     ),
682:     bands=_BANDS,
683:     prob_base={"h5": 0.027, "h10": 0.068, "h21": 0.155},
684:     prob_cal={
685:         "h5":  {"calm": 0.026, "watch": 0.03, "caution": 0.04, "elevated": 0.07, "risk-off": 0.07},
686:         "h10": {"calm": 0.065, "watch": 0.07, "caution": 0.09, "elevated": 0.12, "risk-off": 0.16},
687:         "h21": {"calm": 0.155, "watch": 0.16, "caution": 0.19, "elevated": 0.25, "risk-off": 0.29},
688:     },
689:     caveat_en=("The lightest read and emerging-only: the TSX is commodity-driven and the least US-coupled "
690:                "of the three; US rate shocks, dollar strength and a breadth breakdown lead its drawdowns "
691:                "only weakly and only in the recent era. Context, sized — not a forecast."),
692:     caveat_zh=("三者中最轻量、且仅近期显现：多伦多指数由大宗商品驱动，与美股联动最弱；美债利率冲击、美元走强与广度破位"
693:                "仅在近年、且较弱地领先其回撤。用于定仓的背景，而非预测。"),
694: )
695: 
696: # ─── 7-market extension profiles (2026-07-16) ────────────────────────────────
697: # Shared disclaimer for all 7 new profiles.
698: _INTL_7_DISCLAIMER = (
699:     "Leading-risk radar under accrual — external-driver legs (US rate shocks, FX depreciation, "
700:     "USD strength) ported from the China/HK/Canada radar research, plus a long-history extension "
701:     "percentile for melt-up regimes (2026 KOSPI class). The edge is unproven on this market until "
702:     "its own forward log matures; odds are measured from the market's own history; de-risk = "
703:     "sizing, not selection."
704: )
705: 
706: KR_PROFILE = RadarProfile(
707:     key="kr",
708:     bench=("intl", "^KS11"),
709:     breadth_group=None, breadth_code="kr_breadth",
710:     comp_legs=(
711:         ("rateshock", ("us_rate_2y", "us_real_rate", "us_rate_10y"), 1.0),
712:         ("fx",        ("krw_depreciation",),                          0.6),
713:         ("extension", ("ext_idx", "ext_etf"),                         1.0),
714:     ),
715:     scares=(
716:         ("rate_shock", "A", "US rate shock", "美债利率冲击",
717:          ("rateshock",), ("us_rate_2y", "us_real_rate", "us_rate_10y")),
718:         ("capital_flow", "A", "Won depreciation / outflows", "韩元贬值／资金外流",
719:          ("fx",), ("krw_depreciation",)),
720:         ("extension", "A", "Parabolic extension / exhaustion", "抛物线伸展／透支",
721:          ("extension",), ("ext_idx", "ext_etf")),
722:     ),
723:     bands=_BANDS,
724:     # prob surfaces: base rates measured from this market's own close history by
725:     # scripts/calibrate_risk_radar_intl.py (2026-07-16, window 1998-02-02..2026-07-16, n_days=7013; n counts overlapping forward windows, not independent samples).
726:     # prob_cal is seeded FLAT AT BASE: the in-sample per-state read of this ported
727:     # construction showed no (or overlap-fragile) loud-tier lift — printed by the
728:     # harness as a descriptive artifact, never baked. The live forward log + bounded
729:     # tuner (risk_radar_intl_tune, do-no-harm Brier) own the surface from n_graded>=25.
730:     prob_base={"h5": 0.092, "h10": 0.179, "h21": 0.289},
731:     prob_cal={
732:         "h5":  {"calm": 0.092, "watch": 0.092, "caution": 0.092, "elevated": 0.092, "risk-off": 0.092},
733:         "h10": {"calm": 0.179, "watch": 0.179, "caution": 0.179, "elevated": 0.179, "risk-off": 0.179},
734:         "h21": {"calm": 0.289, "watch": 0.289, "caution": 0.289, "elevated": 0.289, "risk-off": 0.289},
735:     },
736:     caveat_en=(
737:         "Ported construction, own-history odds: the external-driver legs (US rate shocks, won "
738:         "depreciation, USD strength) are ported from the China/HK/Canada radar research — their "
739:         "lead on KOSPI drawdowns is assumed from that work, not separately tested here; the "
740:         "extension leg tracks melt-up regimes (the 2026 KOSPI class). Odds are measured from "
741:         "KOSPI's own ~29y history; display-only while the forward log accrues. Context, sized "
742:         "— not a forecast."
743:     ),
744:     caveat_zh=(
745:         "构建为移植、赔率取自自身历史：外部驱动腿（美债利率冲击、韩元贬值、美元走强）移植自中国／香港／加拿大雷达研究，"
746:         "其对KOSPI回撤的领先性沿用该研究结论、未在本市场单独检验；伸展腿用于捕捉抛物线式过热行情（2026年KOSPI一类）。"
747:         "赔率测自KOSPI自身约29年历史；前向日志累积期间仅作展示。用于定仓的背景，而非预测。"
748:     ),
749:     fx_pair=("intl", "USDKRW=X"),
750:     fx_risk_sign=1,
751:     fx_code="krw_depreciation",
752:     ext_sources=(
753:         ("intl", "^KS11", "ext_idx"),
754:         ("intl_etf", "EWY", "ext_etf"),
755:     ),
756:     gate_mode="below_or_recent_parabolic",
757:     disclaimer=_INTL_7_DISCLAIMER,
758: )
759: 
760: JP_PROFILE = RadarProfile(
761:     key="jp",
762:     bench=("intl", "^N225"),
763:     breadth_group=None, breadth_code="jp_breadth",
764:     comp_legs=(
765:         ("rateshock", ("us_rate_2y", "us_real_rate", "us_rate_10y"), 1.0),
766:         ("fx",        ("jpy_depreciation",),                          0.6),
767:         ("extension", ("ext_idx", "ext_etf"),                         1.0),
768:     ),
769:     scares=(
770:         ("rate_shock", "A", "US rate shock", "美债利率冲击",
771:          ("rateshock",), ("us_rate_2y", "us_real_rate", "us_rate_10y")),
772:         ("capital_flow", "A", "Yen depreciation / outflows", "日元贬值／资金外流",
773:          ("fx",), ("jpy_depreciation",)),
774:         ("extension", "A", "Parabolic extension / exhaustion", "抛物线伸展／透支",
775:          ("extension",), ("ext_idx", "ext_etf")),
776:     ),
777:     bands=_BANDS,
778:     # prob surfaces: base rates measured from this market's own close history by
779:     # scripts/calibrate_risk_radar_intl.py (2026-07-16, window 1997-07-24..2026-07-16, n_days=7100; n counts overlapping forward windows, not independent samples).
780:     # prob_cal is seeded FLAT AT BASE: the in-sample per-state read of this ported
781:     # construction showed no (or overlap-fragile) loud-tier lift — printed by the
782:     # harness as a descriptive artifact, never baked. The live forward log + bounded
783:     # tuner (risk_radar_intl_tune, do-no-harm Brier) own the surface from n_graded>=25.
784:     prob_base={"h5": 0.073, "h10": 0.170, "h21": 0.307},
785:     prob_cal={
786:         "h5":  {"calm": 0.073, "watch": 0.073, "caution": 0.073, "elevated": 0.073, "risk-off": 0.073},
787:         "h10": {"calm": 0.170, "watch": 0.170, "caution": 0.170, "elevated": 0.170, "risk-off": 0.170},
788:         "h21": {"calm": 0.307, "watch": 0.307, "caution": 0.307, "elevated": 0.307, "risk-off": 0.307},
789:     },
790:     caveat_en=(
791:         "Ported construction, own-history odds: the external-driver legs (US rate shocks, yen "
792:         "depreciation, USD strength) are ported from the China/HK/Canada radar research — their "
793:         "lead on Nikkei 225 drawdowns is assumed from that work, not separately tested here; the "
794:         "extension leg tracks melt-up regimes. Odds are measured from Nikkei 225's own ~30y "
795:         "(capped) history; display-only while the forward log accrues. Context, sized — not a forecast."
796:     ),
797:     caveat_zh=(
798:         "构建为移植、赔率取自自身历史：外部驱动腿（美债利率冲击、日元贬值、美元走强）移植自中国／香港／加拿大雷达研究，"
799:         "其对日经225回撤的领先性沿用该研究结论、未在本市场单独检验；伸展腿用于捕捉抛物线式过热行情。"
800:         "赔率测自日经225自身约30年（上限截取）历史；前向日志累积期间仅作展示。用于定仓的背景，而非预测。"
801:     ),
802:     fx_pair=("intl", "USDJPY=X"),
803:     fx_risk_sign=1,
804:     fx_code="jpy_depreciation",
805:     ext_sources=(
806:         ("intl", "^N225", "ext_idx"),
807:         ("intl_etf", "EWJ", "ext_etf"),
808:     ),
809:     gate_mode="below_or_recent_parabolic",
810:     disclaimer=_INTL_7_DISCLAIMER,
811: )
812: 
813: TW_PROFILE = RadarProfile(
814:     key="tw",
815:     bench=("intl", "^TWII"),
816:     breadth_group=None, breadth_code="tw_breadth",
817:     comp_legs=(
818:         ("rateshock", ("us_rate_2y", "us_real_rate", "us_rate_10y"), 1.0),
819:         ("fx",        ("twd_depreciation",),                          0.6),
820:         ("extension", ("ext_idx", "ext_etf"),                         1.0),
821:     ),
822:     scares=(
823:         ("rate_shock", "A", "US rate shock", "美债利率冲击",
824:          ("rateshock",), ("us_rate_2y", "us_real_rate", "us_rate_10y")),
825:         ("capital_flow", "A", "TWD depreciation / outflows", "新台币贬值／资金外流",
826:          ("fx",), ("twd_depreciation",)),
827:         ("extension", "A", "Parabolic extension / exhaustion", "抛物线伸展／透支",
828:          ("extension",), ("ext_idx", "ext_etf")),
829:     ),
830:     bands=_BANDS,
831:     # prob surfaces: base rates measured from this market's own close history by
832:     # scripts/calibrate_risk_radar_intl.py (2026-07-16, window 1998-08-13..2026-07-16, n_days=6843; n counts overlapping forward windows, not independent samples).
833:     # prob_cal is seeded FLAT AT BASE: the in-sample per-state read of this ported
834:     # construction showed no (or overlap-fragile) loud-tier lift — printed by the
835:     # harness as a descriptive artifact, never baked. The live forward log + bounded
836:     # tuner (risk_radar_intl_tune, do-no-harm Brier) own the surface from n_graded>=25.
837:     prob_base={"h5": 0.070, "h10": 0.154, "h21": 0.272},
838:     prob_cal={
839:         "h5":  {"calm": 0.070, "watch": 0.070, "caution": 0.070, "elevated": 0.070, "risk-off": 0.070},
840:         "h10": {"calm": 0.154, "watch": 0.154, "caution": 0.154, "elevated": 0.154, "risk-off": 0.154},
841:         "h21": {"calm": 0.272, "watch": 0.272, "caution": 0.272, "elevated": 0.272, "risk-off": 0.272},
842:     },
843:     caveat_en=(
844:         "Ported construction, own-history odds: the external-driver legs (US rate shocks, TWD "
845:         "depreciation, USD strength) are ported from the China/HK/Canada radar research — their "
846:         "lead on TAIEX drawdowns is assumed from that work, not separately tested here; the "
847:         "extension leg tracks melt-up regimes. Odds are measured from TAIEX's own ~29y history; "
848:         "display-only while the forward log accrues. Context, sized — not a forecast."
849:     ),
850:     caveat_zh=(
851:         "构建为移植、赔率取自自身历史：外部驱动腿（美债利率冲击、新台币贬值、美元走强）移植自中国／香港／加拿大雷达研究，"
852:         "其对台湾加权指数回撤的领先性沿用该研究结论、未在本市场单独检验；伸展腿用于捕捉抛物线式过热行情。"
853:         "赔率测自台湾加权指数自身约29年历史；前向日志累积期间仅作展示。用于定仓的背景，而非预测。"
854:     ),
855:     fx_pair=("intl", "USDTWD=X"),
856:     fx_risk_sign=1,
857:     fx_code="twd_depreciation",
858:     ext_sources=(
859:         ("intl", "^TWII", "ext_idx"),
860:         ("intl_etf", "EWT", "ext_etf"),
861:     ),
862:     gate_mode="below_or_recent_parabolic",
863:     disclaimer=_INTL_7_DISCLAIMER,
864: )
865: 
866: IN_PROFILE = RadarProfile(
867:     key="in",
868:     bench=("intl", "^NSEI"),
869:     breadth_group=None, breadth_code="in_breadth",
870:     comp_legs=(
871:         ("rateshock", ("us_rate_2y", "us_real_rate", "us_rate_10y"), 1.0),
872:         ("fx",        ("inr_depreciation",),                          0.6),
873:         ("extension", ("ext_idx", "ext_etf"),                         1.0),
874:     ),
875:     scares=(
876:         ("rate_shock", "A", "US rate shock", "美债利率冲击",
877:          ("rateshock",), ("us_rate_2y", "us_real_rate", "us_rate_10y")),
878:         ("capital_flow", "A", "Rupee depreciation / outflows", "卢比贬值／资金外流",
879:          ("fx",), ("inr_depreciation",)),
880:         ("extension", "A", "Parabolic extension / exhaustion", "抛物线伸展／透支",
881:          ("extension",), ("ext_idx", "ext_etf")),
882:     ),
883:     bands=_BANDS,
884:     # prob surfaces: base rates measured from this market's own close history by
885:     # scripts/calibrate_risk_radar_intl.py (2026-07-16, window 2008-10-22..2026-07-16, n_days=4346; n counts overlapping forward windows, not independent samples).
886:     # prob_cal is seeded FLAT AT BASE: the in-sample per-state read of this ported
887:     # construction showed no (or overlap-fragile) loud-tier lift — printed by the
888:     # harness as a descriptive artifact, never baked. The live forward log + bounded
889:     # tuner (risk_radar_intl_tune, do-no-harm Brier) own the surface from n_graded>=25.
890:     prob_base={"h5": 0.032, "h10": 0.089, "h21": 0.185},
891:     prob_cal={
892:         "h5":  {"calm": 0.032, "watch": 0.032, "caution": 0.032, "elevated": 0.032, "risk-off": 0.032},
893:         "h10": {"calm": 0.089, "watch": 0.089, "caution": 0.089, "elevated": 0.089, "risk-off": 0.089},
894:         "h21": {"calm": 0.185, "watch": 0.185, "caution": 0.185, "elevated": 0.185, "risk-off": 0.185},
895:     },
896:     caveat_en=(
897:         "Ported construction, own-history odds: the external-driver legs (US rate shocks, rupee "
898:         "depreciation, USD strength) are ported from the China/HK/Canada radar research — their "
899:         "lead on Nifty 50 drawdowns is assumed from that work, not separately tested here; the "
900:         "extension leg tracks melt-up regimes. Odds are measured from Nifty 50 index's own "
901:         "~19y — the shortest history here; display-only while the forward log accrues. Context, "
902:         "sized — not a forecast."
903:     ),
904:     caveat_zh=(
905:         "构建为移植、赔率取自自身历史：外部驱动腿（美债利率冲击、卢比贬值、美元走强）移植自中国／香港／加拿大雷达研究，"
906:         "其对Nifty 50指数回撤的领先性沿用该研究结论、未在本市场单独检验；伸展腿用于捕捉抛物线式过热行情。"
907:         "赔率测自Nifty 50指数自身约19年（本组中最短）历史；前向日志累积期间仅作展示。用于定仓的背景，而非预测。"
908:     ),
909:     fx_pair=("intl", "USDINR=X"),
910:     fx_risk_sign=1,
911:     fx_code="inr_depreciation",
912:     ext_sources=(
913:         ("intl", "^NSEI", "ext_idx"),
914:         ("intl_etf", "INDA", "ext_etf"),
915:     ),
916:     gate_mode="below_or_recent_parabolic",
917:     disclaimer=_INTL_7_DISCLAIMER,
918: )
919: 
920: AU_PROFILE = RadarProfile(
921:     key="au",
922:     bench=("intl", "^AXJO"),
923:     breadth_group=None, breadth_code="au_breadth",
924:     comp_legs=(
925:         ("rateshock", ("us_rate_2y", "us_real_rate", "us_rate_10y"), 1.0),
926:         ("fx",        ("aud_depreciation",),                          0.6),
927:         ("extension", ("ext_idx", "ext_etf"),                         1.0),
928:     ),
929:     scares=(
930:         ("rate_shock", "A", "US rate shock", "美债利率冲击",
931:          ("rateshock",), ("us_rate_2y", "us_real_rate", "us_rate_10y")),
932:         ("capital_flow", "A", "AUD depreciation / outflows", "澳元贬值／资金外流",
933:          ("fx",), ("aud_depreciation",)),
934:         ("extension", "A", "Parabolic extension / exhaustion", "抛物线伸展／透支",
935:          ("extension",), ("ext_idx", "ext_etf")),
936:     ),
937:     bands=_BANDS,
938:     # prob surfaces: base rates measured from this market's own close history by
939:     # scripts/calibrate_risk_radar_intl.py (2026-07-16, window 1997-07-24..2026-07-16, n_days=7325; n counts overlapping forward windows, not independent samples).
940:     # prob_cal is seeded FLAT AT BASE: the in-sample per-state read of this ported
941:     # construction showed no (or overlap-fragile) loud-tier lift — printed by the
942:     # harness as a descriptive artifact, never baked. The live forward log + bounded
943:     # tuner (risk_radar_intl_tune, do-no-harm Brier) own the surface from n_graded>=25.
944:     prob_base={"h5": 0.024, "h10": 0.064, "h21": 0.154},
945:     prob_cal={
946:         "h5":  {"calm": 0.024, "watch": 0.024, "caution": 0.024, "elevated": 0.024, "risk-off": 0.024},
947:         "h10": {"calm": 0.064, "watch": 0.064, "caution": 0.064, "elevated": 0.064, "risk-off": 0.064},
948:         "h21": {"calm": 0.154, "watch": 0.154, "caution": 0.154, "elevated": 0.154, "risk-off": 0.154},
949:     },
950:     caveat_en=(
951:         "Ported construction, own-history odds: the external-driver legs (US rate shocks, AUD "
952:         "depreciation, USD strength) are ported from the China/HK/Canada radar research — their "
953:         "lead on ASX 200 drawdowns is assumed from that work, not separately tested here; the "
954:         "extension leg tracks melt-up regimes. Odds are measured from ASX 200 index's own "
955:         "~30y (capped) history; display-only while the forward log accrues. Context, sized "
956:         "— not a forecast."
957:     ),
958:     caveat_zh=(
959:         "构建为移植、赔率取自自身历史：外部驱动腿（美债利率冲击、澳元贬值、美元走强）移植自中国／香港／加拿大雷达研究，"
960:         "其对ASX 200指数回撤的领先性沿用该研究结论、未在本市场单独检验；伸展腿用于捕捉抛物线式过热行情。"
961:         "赔率测自ASX 200指数自身约30年（上限截取）历史；前向日志累积期间仅作展示。用于定仓的背景，而非预测。"
962:     ),
963:     fx_pair=("intl", "AUDUSD=X"),
964:     fx_risk_sign=-1,
965:     fx_code="aud_depreciation",
966:     ext_sources=(
967:         ("intl", "^AXJO", "ext_idx"),
968:         ("intl_etf", "EWA", "ext_etf"),
969:     ),
970:     gate_mode="below_or_recent_parabolic",
971:     disclaimer=_INTL_7_DISCLAIMER,
972: )
973: 
974: GB_PROFILE = RadarProfile(
975:     key="gb",
976:     bench=("intl", "^FTSE"),
977:     breadth_group=None, breadth_code="gb_breadth",
978:     comp_legs=(
979:         ("rateshock", ("us_rate_2y", "us_real_rate", "us_rate_10y"), 1.0),
980:         ("fx",        ("gbp_depreciation",),                          0.6),
981:         ("extension", ("ext_idx", "ext_etf"),                         1.0),
982:     ),
983:     scares=(
984:         ("rate_shock", "A", "US rate shock", "美债利率冲击",
985:          ("rateshock",), ("us_rate_2y", "us_real_rate", "us_rate_10y")),
986:         ("capital_flow", "A", "Sterling depreciation / outflows", "英镑贬值／资金外流",
987:          ("fx",), ("gbp_depreciation",)),
988:         ("extension", "A", "Parabolic extension / exhaustion", "抛物线伸展／透支",
989:          ("extension",), ("ext_idx", "ext_etf")),
990:     ),
991:     bands=_BANDS,
992:     # prob surfaces: base rates measured from this market's own close history by
993:     # scripts/calibrate_risk_radar_intl.py (2026-07-16, window 1997-07-23..2026-07-15, n_days=7319; n counts overlapping forward windows, not independent samples).
994:     # prob_cal is seeded FLAT AT BASE: the in-sample per-state read of this ported
995:     # construction showed no (or overlap-fragile) loud-tier lift — printed by the
996:     # harness as a descriptive artifact, never baked. The live forward log + bounded
997:     # tuner (risk_radar_intl_tune, do-no-harm Brier) own the surface from n_graded>=25.
998:     prob_base={"h5": 0.037, "h10": 0.087, "h21": 0.186},
999:     prob_cal={
1000:         "h5":  {"calm": 0.037, "watch": 0.037, "caution": 0.037, "elevated": 0.037, "risk-off": 0.037},
1001:         "h10": {"calm": 0.087, "watch": 0.087, "caution": 0.087, "elevated": 0.087, "risk-off": 0.087},
1002:         "h21": {"calm": 0.186, "watch": 0.186, "caution": 0.186, "elevated": 0.186, "risk-off": 0.186},
1003:     },
1004:     caveat_en=(
1005:         "Ported construction, own-history odds: the external-driver legs (US rate shocks, sterling "
1006:         "depreciation, USD strength) are ported from the China/HK/Canada radar research — their "
1007:         "lead on FTSE 100 drawdowns is assumed from that work, not separately tested here; the "
1008:         "extension leg tracks melt-up regimes. Odds are measured from FTSE 100 index's own "
1009:         "~30y (capped) history; display-only while the forward log accrues. Context, sized "
1010:         "— not a forecast."
1011:     ),
1012:     caveat_zh=(
1013:         "构建为移植、赔率取自自身历史：外部驱动腿（美债利率冲击、英镑贬值、美元走强）移植自中国／香港／加拿大雷达研究，"
1014:         "其对富时100指数回撤的领先性沿用该研究结论、未在本市场单独检验；伸展腿用于捕捉抛物线式过热行情。"
1015:         "赔率测自富时100指数自身约30年（上限截取）历史；前向日志累积期间仅作展示。用于定仓的背景，而非预测。"
1016:     ),
1017:     fx_pair=("intl", "GBPUSD=X"),
1018:     fx_risk_sign=-1,
1019:     fx_code="gbp_depreciation",
1020:     ext_sources=(
1021:         ("intl", "^FTSE", "ext_idx"),
1022:         ("intl_etf", "EWU", "ext_etf"),
1023:     ),
1024:     gate_mode="below_or_recent_parabolic",
1025:     disclaimer=_INTL_7_DISCLAIMER,
1026: )
1027: 
1028: EZ_PROFILE = RadarProfile(
1029:     key="ez",
1030:     bench=("intl", "^STOXX"),
1031:     breadth_group=None, breadth_code="ez_breadth",
1032:     comp_legs=(
1033:         ("rateshock", ("us_rate_2y", "us_real_rate", "us_rate_10y"), 1.0),
1034:         ("fx",        ("eur_depreciation",),                          0.6),
1035:         ("extension", ("ext_idx", "ext_etf"),                         1.0),
1036:     ),
1037:     scares=(
1038:         ("rate_shock", "A", "US rate shock", "美债利率冲击",
1039:          ("rateshock",), ("us_rate_2y", "us_real_rate", "us_rate_10y")),
1040:         ("capital_flow", "A", "Euro depreciation / outflows", "欧元贬值／资金外流",
1041:          ("fx",), ("eur_depreciation",)),
1042:         ("extension", "A", "Parabolic extension / exhaustion", "抛物线伸展／透支",
1043:          ("extension",), ("ext_idx", "ext_etf")),
1044:     ),
1045:     bands=_BANDS,
1046:     # prob surfaces: base rates measured from this market's own close history by
1047:     # scripts/calibrate_risk_radar_intl.py (2026-07-16, window 2005-05-18..2026-07-15, n_days=5314; n counts overlapping forward windows, not independent samples).
1048:     # prob_cal is seeded FLAT AT BASE: the in-sample per-state read of this ported
1049:     # construction showed no (or overlap-fragile) loud-tier lift — printed by the
1050:     # harness as a descriptive artifact, never baked. The live forward log + bounded
1051:     # tuner (risk_radar_intl_tune, do-no-harm Brier) own the surface from n_graded>=25.
1052:     prob_base={"h5": 0.043, "h10": 0.102, "h21": 0.200},
1053:     prob_cal={
1054:         "h5":  {"calm": 0.043, "watch": 0.043, "caution": 0.043, "elevated": 0.043, "risk-off": 0.043},
1055:         "h10": {"calm": 0.102, "watch": 0.102, "caution": 0.102, "elevated": 0.102, "risk-off": 0.102},
1056:         "h21": {"calm": 0.200, "watch": 0.200, "caution": 0.200, "elevated": 0.200, "risk-off": 0.200},
1057:     },
1058:     caveat_en=(
1059:         "Ported construction, own-history odds: the external-driver legs (US rate shocks, euro "
1060:         "depreciation, USD strength) are ported from the China/HK/Canada radar research — their "
1061:         "lead on STOXX Europe 600 drawdowns is assumed from that work, not separately tested here; "
1062:         "the extension leg tracks melt-up regimes across a basket of country ETFs (EWG/EWQ/EWI/EWP "
1063:         "— no single deep-history eurozone ETF is available). Odds are measured from the STOXX "
1064:         "Europe 600 index's own ~22y history; display-only while the forward log accrues. Context, "
1065:         "sized — not a forecast."
1066:     ),
1067:     caveat_zh=(
1068:         "构建为移植、赔率取自自身历史：外部驱动腿（美债利率冲击、欧元贬值、美元走强）移植自中国／香港／加拿大雷达研究，"
1069:         "其对斯托克欧洲600指数回撤的领先性沿用该研究结论、未在本市场单独检验；伸展腿通过国家ETF篮子（EWG／EWQ／EWI／EWP）"
1070:         "捕捉欧元区整体过热行情（无单一长历史欧元区ETF可用）。赔率测自斯托克欧洲600指数自身约22年历史；"
1071:         "前向日志累积期间仅作展示。用于定仓的背景，而非预测。"
1072:     ),
1073:     fx_pair=("intl", "EURUSD=X"),
1074:     fx_risk_sign=-1,
1075:     fx_code="eur_depreciation",
1076:     ext_sources=(
1077:         ("intl", "^STOXX", "ext_idx"),
1078:         ("intl_etf", ("EWG", "EWQ", "EWI", "EWP"), "ext_etf"),
1079:     ),
1080:     gate_mode="below_or_recent_parabolic",
1081:     disclaimer=_INTL_7_DISCLAIMER,
1082: )
1083: 
1084: PROFILES = {
1085:     "cn": CN_PROFILE,
1086:     "hk": HK_PROFILE,
1087:     "ca": CA_PROFILE,
1088:     "kr": KR_PROFILE,
1089:     "jp": JP_PROFILE,
1090:     "tw": TW_PROFILE,
1091:     "in": IN_PROFILE,
1092:     "au": AU_PROFILE,
1093:     "gb": GB_PROFILE,
1094:     "ez": EZ_PROFILE,
1095: }
```

## COMPLETE CANDIDATE SOURCE: engine/risk_radar_intl_audit.py
```
1: """International Risk Radar — per-market forward-outcome log + deterministic grading.
2: 
3: The sibling of engine/risk_radar_audit.py (US) for the China / HK / Canada radars
4: (engine/risk_radar_intl.py). Every daily snapshot is APPENDED to
5: data/risk_radar_intl/<market>_forward_log.jsonl (idempotent by as-of). Once an entry's
6: horizon matures it is GRADED against that market's OWN realized index path: did a
7: >=5% drawdown actually occur within H business days? Each loud call is then a true- or
8: false-positive. The rolling scorecard (realized precision / per-state hit-rate /
9: predicted-vs-realized odds) is what the card surfaces, what the bounded tuner
10: (engine/risk_radar_intl_tune.py) recalibrates from, and what gates whether a market's
11: radar has earned the right to HARD-FORCE the Market-State verdict (`can_force`).
12: 
13: These radars ship DISPLAY-ONLY (verdict untouched) until each one's own log matures and
14: clears the bar — accountable by construction, never trusted on faith. Never raises.
15: 
16: CAN_FORCE — ARTICLE-3 GATE (W7a)
17: ---------------------------------
18: `can_force` is now gated by a Wilson-CI lower-bound lift (Article 3) rather than a
19: point-estimate threshold.  The Wilson lower bound at the 90%-confidence level (z=1.645)
20: must exceed 1.25× the base drawdown rate — matching the retired point-estimate floor of
21: 1.25 but measured on the CI lower bound instead of the point estimate.  Because
22: wilson_lb <= point_estimate always, the CI gate is strictly tighter everywhere: zero
23: grant-more cases across the full (k, n, base) space.  At minimum sample sizes (n_alerts=8)
24: the old point-estimate gate false-granted ~44% of the time under the null; the Wilson
25: gate reduces this to ~5.8%.  This is the conservative / authority-revoking direction:
26: markets that previously cleared the point-estimate gate may lose can_force; no market
27: can gain force authority it did not have under the old gate.
28: 
29: When the grant state changes vs the previous scorecard call, authority_grant or
30: authority_lapse events are appended to data/neuralweb/governance.jsonl via
31: engine.neuralweb.governance (fail-open — a governance-write failure never aborts the
32: audit).
33: """
34: from __future__ import annotations
35: 
36: import json
37: import logging
38: from datetime import datetime, timezone
39: from pathlib import Path
40: 
41: import pandas as pd
42: 
43: from lib import config, store
44: 
45: log = logging.getLogger(__name__)
46: 
47: HORIZONS = {"h5": 5, "h10": 10, "h21": 21}        # business-day forward windows
48: DD_THRESHOLDS = (0.05, 0.08)
49: PRIMARY_DD = 0.05
50: ALERT_STATES = ("elevated", "risk-off")            # the loud tiers, for precision
51: # --- gate for earning the right to hard-force the verdict (Article 3) ---
52: MIN_GRADED_FORCE = 30      # need this many matured calls before forcing is even considered
53: MIN_ALERTS_FORCE = 8       # and this many loud calls among them
54: # NOTE: MIN_FORCE_LIFT (point-estimate 1.25) REMOVED — replaced by Wilson CI lift > 1.25
55: # The Wilson lower-bound gate (z=1.645, 90% one-sided) is evaluated inside scorecard().
56: # Threshold 1.25 matches the retired point-estimate floor; because wilson_lb <= point_estimate
57: # always, the CI gate is strictly tighter everywhere (zero grant-more cases, verified in tests).
58: # At n_alerts=8 the old gate false-granted ~44% under the null; Wilson reduces this to ~5.8%.
59: 
60: 
61: def ledger_lane_armed() -> bool:
62:     """True only on the nightly collect lane (COLLECT_LANE=nightly, legacy alias
63:     US_LANE). House law: nightly is the SOLE advancer of data/ forward ledgers —
64:     the engine-render/render re-render lanes and closing-bell run the CN/HK/CA/intl
65:     builds too; on those lanes the radar snapshot still renders but snapshot_and_grade
66:     and the tuner must not advance (a mid-session append is PIT-inconsistent and,
67:     being idempotent-by-asof, would permanently displace the nightly row). Canonical
68:     home for the gate; engine/intl_run._ledger_lane_armed delegates here."""
69:     import os
70:     lane = os.environ.get("COLLECT_LANE", "") or os.environ.get("US_LANE", "")
71:     return lane.lower() == "nightly"
72: 
73: 
74: def _path(market: str, root=None) -> Path:
75:     base = config.data_dir() if root is None else (Path(root) / "data")
76:     p = base / "risk_radar_intl" / f"{market}_forward_log.jsonl"
77:     p.parent.mkdir(parents=True, exist_ok=True)
78:     return p
79: 
80: 
81: def _read(p: Path) -> list[dict]:
82:     if not p.exists():
83:         return []
84:     rows = []
85:     for line in p.read_text().splitlines():
86:         line = line.strip()
87:         if not line:
88:             continue
89:         try:
90:             rows.append(json.loads(line))
91:         except Exception:  # noqa: BLE001
92:             continue
93:     return rows
94: 
95: 
96: def _write(p: Path, rows: list[dict]) -> None:
97:     p.write_text("\n".join(json.dumps(r, separators=(",", ":"), default=str) for r in rows) + "\n")
98: 
99: 
100: def _entry_from_snapshot(snap: dict) -> dict | None:
101:     if not snap or not snap.get("asof") or snap.get("state") is None:
102:         return None
103:     if "composition" in snap:
104:         composition = snap["composition"]
105:         if (not isinstance(composition, dict) or composition.get("score_current") is not True
106:                 or composition.get("status") not in ("COMPLETE", "PARTIAL")):
107:             return None
108:         import json
109:         try:
110:             json.dumps(composition, allow_nan=False)
111:         except (TypeError, ValueError):
112:             return None
113:     entry = {
114:         "asof": str(snap["asof"]),
115:         "market": snap.get("market"),
116:         "state": snap.get("state"),
117:         "alert": snap.get("state") in ALERT_STATES,
118:         "dominant_scare": snap.get("dominant_scare"),
119:         "top_score": snap.get("top_score"),
120:         "conjunction": bool(snap.get("conjunction")),
121:         "scares": {s["scare"]: {"score": s.get("score"), "band": s.get("band")}
122:                    for s in (snap.get("scares") or [])},
123:         "drawdown_prob": snap.get("drawdown_prob"),
124:         # de-escalation trajectory (engine/risk_radar_intl._trajectory) — for a future recovery audit.
125:         "traj_phase": (snap.get("trajectory") or {}).get("phase"),
126:         "traj_intensity": (snap.get("trajectory") or {}).get("intensity"),
127:         "traj_off_peak": (snap.get("trajectory") or {}).get("off_peak"),
128:         "traj_odds_now": (snap.get("trajectory") or {}).get("odds_now"),
129:         "logged_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
130:         "graded": None,
131:     }
132:     if "composition" in snap:
133:         from copy import deepcopy
134:         entry["composition"] = deepcopy(snap["composition"])
135:     return entry
136: 
137: 
138: def log_snapshot(snap: dict, market: str, root=None) -> bool:
139:     """Append today's snapshot to the market's forward log (idempotent by as-of)."""
140:     try:
141:         entry = _entry_from_snapshot(snap)
142:         if entry is None:
143:             return False
144:         p = _path(market, root)
145:         rows = _read(p)
146:         if any(r.get("asof") == entry["asof"] for r in rows):
147:             return False
148:         rows.append(entry)
149:         _write(p, rows)
150:         return True
151:     except Exception as e:  # noqa: BLE001
152:         log.warning("risk_radar_intl_audit log(%s) failed: %s", market, e)
153:         return False
154: 
155: 
156: def _bench(profile) -> pd.Series | None:
157:     try:
158:         df = store.read(*profile.bench)
159:         if df is None or getattr(df, "empty", True):
160:             return None
161:         c = "close" if "close" in df.columns else df.columns[0]
162:         s = df[c].dropna()
163:         s.index = pd.to_datetime(s.index)
164:         return s.sort_index()
165:     except Exception:  # noqa: BLE001
166:         return None
167: 
168: 
169: def _grade_entry(entry: dict, px: pd.Series) -> dict | None:
170:     """Realized forward max-drawdown per horizon from the as-of date; mark hit + outcome.
171:     None until the longest horizon has matured."""
172:     asof = pd.Timestamp(entry["asof"])
173:     loc = px.index.searchsorted(asof, side="right")
174:     maxH = max(HORIZONS.values())
175:     if loc + maxH > len(px):
176:         return None
177:     base_px = float(px.iloc[max(0, loc - 1)])
178:     fwd_dd, hit = {}, {}
179:     for hk, hd in HORIZONS.items():
180:         w = px.iloc[loc: loc + hd]
181:         dd = float(w.min() / base_px - 1.0) if len(w) else None
182:         fwd_dd[hk] = None if dd is None else round(dd, 4)
183:         hit[hk] = {f"dd{int(t*100)}": (dd is not None and dd <= -t) for t in DD_THRESHOLDS}
184:     any_primary = any(fwd_dd[hk] is not None and fwd_dd[hk] <= -PRIMARY_DD for hk in HORIZONS)
185:     st = entry.get("state")
186:     if st in ALERT_STATES:
187:         outcome = "true_positive" if any_primary else "false_positive"
188:     elif st in ("watch", "caution"):
189:         outcome = "tp_watch" if any_primary else "tn_watch"
190:     else:
191:         outcome = "calm_dd" if any_primary else "calm_quiet"
192:     return {"base_px": round(base_px, 2), "fwd_dd": fwd_dd, "hit": hit,
193:             "outcome": outcome, "any_dd5_within_h21": bool(any_primary),
194:             "graded_at": datetime.now(timezone.utc).isoformat(timespec="seconds")}
195: 
196: 
197: def grade_log(profile, root=None) -> int:
198:     """Grade every matured, ungraded entry against the market's realized index path."""
199:     try:
200:         p = _path(profile.key, root)
201:         rows = _read(p)
202:         if not rows:
203:             return 0
204:         px = _bench(profile)
205:         if px is None:
206:             return 0
207:         n = 0
208:         for r in rows:
209:             if r.get("graded"):
210:                 continue
211:             g = _grade_entry(r, px)
212:             if g is not None:
213:                 r["graded"] = g
214:                 n += 1
215:         if n:
216:             _write(p, rows)
217:         return n
218:     except Exception as e:  # noqa: BLE001
219:         log.warning("risk_radar_intl_audit grade(%s) failed: %s", getattr(profile, "key", "?"), e)
220:         return 0
221: 
222: 
223: def _legacy_graded_cohort(rows):
224:     """One legacy-only evidence selection; never rewrites or promotes issued rows.
225: 
226:     Explicit composition, even null or malformed, is not the pre-migration schema.
227:     Selecting legacy rows does not certify their data quality or authorize a new
228:     construction to inherit this cohort's resulting grant.
229:     """
230:     graded = [row for row in rows if row.get("graded")]
231:     legacy = [row for row in graded if "composition" not in row]
232:     return legacy, len(graded) - len(legacy)
233: def realized_odds(market: str, root=None) -> dict:
234:     """Per-state realized P(>=5% drawdown within h) from the graded log — the empirical truth
235:     the tuner recalibrates the prob surface toward. {state: {h5,h10,h21, n}}."""
236:     rows, _excluded = _legacy_graded_cohort(_read(_path(market, root)))
237:     out: dict[str, dict] = {}
238:     for r in rows:
239:         st = r.get("state")
240:         d = out.setdefault(st, {"n": 0, "h5": 0, "h10": 0, "h21": 0})
241:         d["n"] += 1
242:         g = r["graded"]
243:         for hk in HORIZONS:
244:             fdd = (g.get("fwd_dd") or {}).get(hk)
245:             d[hk] += int(fdd is not None and fdd <= -PRIMARY_DD)
246:     return {st: {"n": d["n"], **{hk: round(d[hk] / d["n"], 3) for hk in HORIZONS}}
247:             for st, d in out.items() if d["n"]}
248: 
249: 
250: def _load_previous_can_force(market: str, root=None) -> bool | None:
251:     """Read the last can_force value written for this market (for change detection).
252: 
253:     Returns None when no previous scorecard exists.  Never raises.
254:     """
255:     try:
256:         if root is None:
257:             base = config.data_dir()
258:         else:
259:             base = Path(root) / "data"
260:         # Previous can_force lives in the risk_radar payload inside latest.json
261:         for region_dir in ("", "china_regime/", "hk_regime/", "canada_regime/"):
262:             p = Path(base) / f"{region_dir}latest.json"
263:             if p.exists():
264:                 try:
265:                     obj = json.loads(p.read_text())
266:                     fwd = (obj.get("risk_radar") or {}).get("forward_log") or {}
267:                     if fwd.get("market") == market and "can_force" in fwd:
268:                         return bool(fwd["can_force"])
269:                 except Exception:  # noqa: BLE001
270:                     pass
271:         # 7-market intl payload: data/intl/latest.json records[*].risk_radar.forward_log
272:         p = Path(base) / "intl" / "latest.json"
273:         if p.exists():
274:             try:
275:                 obj = json.loads(p.read_text())
276:                 for rec in (obj.get("records") or []):
277:                     fwd = ((rec.get("risk_radar") or {}).get("forward_log") or {})
278:                     if fwd.get("market") == market and "can_force" in fwd:
279:                         return bool(fwd["can_force"])
280:             except Exception:  # noqa: BLE001
281:                 pass
282:     except Exception:  # noqa: BLE001
283:         pass
284:     return None
285: 
286: 
287: def _log_can_force_governance(
288:     market: str,
289:     can_force: bool,
290:     prev_can_force: bool | None,
291:     hits: int,
292:     n_alerts: int,
293:     base: float,
294:     wilson_lb: float | None,
295:     lift_lb: float | None,
296:     grant_reason: str,
297:     evidence_asof: str | None,
298:     root=None,
299: ) -> None:
300:     """Append authority_grant or authority_lapse to the governance ledger when can_force changes.
301: 
302:     Fail-open: exceptions are logged but never propagated.
303:     """
304:     try:
305:         if prev_can_force is None or can_force == prev_can_force:
306:             return  # no state change — nothing to log
307:         from engine.neuralweb.governance import append_event  # type: ignore[import]
308:         event_type = "authority_grant" if can_force else "authority_lapse"
309:         target = f"engine/risk_radar_intl_audit.can_force:{market}"
310:         append_event(
311:             event_type,
312:             target,
313:             article=3,
314:             authored_by="risk_radar_intl_audit",
315:             evidence={
316:                 "hits": hits,
317:                 "n_alerts": n_alerts,
318:                 "base_rate": round(base, 4),
319:                 "wilson_lb": wilson_lb,
320:                 "lift_lb": lift_lb,
321:                 "evidence_asof": evidence_asof,
322:             },
323:             before={"can_force": prev_can_force},
324:             after={"can_force": can_force},
325:             note=grant_reason,
326:             root=root,
327:         )
328:     except Exception as exc:  # noqa: BLE001
329:         log.warning("risk_radar_intl_audit: governance log failed for %s: %s", market, exc)
330: 
331: 
332: def force_applicable_for_snapshot(snap: dict, proposed: bool) -> bool:
333:     """Qualify this snapshot's legacy force grant; never transition a capital policy.
334: 
335:     No composition-bearing construction is promoted in this release. Declared
336:     calibration/status labels cannot grant authority. A future promotion must
337:     change this owner under reviewed construction-compatible evidence, not by
338:     changing producer prose or reusing the legacy scorecard.
339:     """
340:     if not isinstance(snap, dict) or "composition" in snap:
341:         return False
342:     return bool(proposed)
343: 
344: 
345: def scorecard(market: str, root=None, log_governance: bool = True) -> dict:
346:     """Rolling realized-accuracy scorecard from the graded log. Carries `can_force`: whether this
347:     market's radar has earned the right to hard-force the Market-State verdict. Never raises.
348: 
349:     ARTICLE-3 GATE (W7a): can_force is now granted via Wilson CI lower-bound lift > 1.25
350:     at z=1.645 (90% one-sided).  Threshold 1.25 matches the retired point-estimate floor;
351:     because wilson_lb <= point_estimate always, the CI gate is strictly tighter everywhere
352:     (zero grant-more cases across all k/n/base — verified in tests).  Additive scorecard
353:     fields: wilson_lift_lb, grant_reason, evidence_asof.  Existing consumers read only
354:     the can_force bool — these additions are backward-compatible.
355: 
356:     ``log_governance=False`` makes the call fully READ-ONLY: the authority_grant/lapse
357:     append to the governance ledger is skipped. The intraday live fast-path
358:     (scripts/build_china_risk_state.py) uses this to reproduce the board's can_force
359:     without writing — the nightly snapshot_and_grade remains the sole governance writer.
360:     """
361:     try:
362:         rows, excluded = _legacy_graded_cohort(_read(_path(market, root)))
363:     except Exception:  # noqa: BLE001
364:         rows, excluded = [], 0
365:     if not rows:
366:         return {"market": market, "n_graded": 0, "can_force": False,
367:                 "evidence_construction": "legacy_implicit", "excluded_composition_rows": excluded,
368:                 "wilson_lift_lb": None, "grant_reason": "accruing",
369:                 "evidence_asof": None,
370:                 "note": "accruing — grades begin once calls mature (~21 trading days)"}
371:     n = len(rows)
372:     base = sum(int(r["graded"].get("any_dd5_within_h21")) for r in rows) / n
373:     alerts = [r for r in rows if r.get("alert")]
374:     tp = [r for r in alerts if r["graded"]["outcome"] == "true_positive"]
375:     alert_hit_count = sum(int(r["graded"].get("any_dd5_within_h21")) for r in alerts)
376:     alert_hit = alert_hit_count / len(alerts) if alerts else None
377:     by_state = {}
378:     for r in rows:
379:         d = by_state.setdefault(r.get("state"), {"n": 0, "dd": 0})
380:         d["n"] += 1
381:         d["dd"] += int(bool(r["graded"].get("any_dd5_within_h21")))
382:     by_state = {k: {"n": v["n"], "hit_rate": round(v["dd"] / v["n"], 3)} for k, v in by_state.items()}
383:     # point-estimate lift kept for display only (not the gate)
384:     force_lift = round(alert_hit / base, 2) if (alert_hit is not None and base) else None
385: 
386:     # Article-3 Wilson CI gate (replaces point-estimate >= 1.25)
387:     evidence_asof = rows[-1]["asof"] if rows else None
388:     wilson_lb: float | None = None
389:     lift_lb: float | None = None
390:     grant_reason: str = "accruing"
391:     can_force: bool = False
392: 
393:     n_alerts = len(alerts)
394:     if n >= MIN_GRADED_FORCE and n_alerts >= MIN_ALERTS_FORCE:
395:         try:
396:             from engine.neuralweb.constitution import grant_authority  # type: ignore[import]
397:             result = grant_authority(
398:                 evidence={
399:                     "hits": alert_hit_count,
400:                     "n": n_alerts,
401:                     "base_rate": base,
402:                     "evidence_asof": evidence_asof,
403:                 },
404:                 floors={"min_n": MIN_GRADED_FORCE, "min_events": MIN_ALERTS_FORCE},
405:             )
406:             can_force = result.granted
407:             wilson_lb = result.wilson_lb
408:             lift_lb = result.lift_lb
409:             grant_reason = result.reason
410:         except Exception as exc:  # noqa: BLE001
411:             log.warning("risk_radar_intl_audit: constitution gate failed for %s: %s", market, exc)
412:             grant_reason = f"gate-error: {exc}"
413:     else:
414:         grant_reason = (f"n-floors-not-met: n_graded={n} (need {MIN_GRADED_FORCE}), "
415:                         f"n_alerts={n_alerts} (need {MIN_ALERTS_FORCE})")
416: 
417:     # Governance ledger: log when grant state changes (skipped on read-only calls)
418:     if log_governance:
419:         try:
420:             prev_cf = _load_previous_can_force(market, root)
421:             _log_can_force_governance(
422:                 market=market,
423:                 can_force=can_force,
424:                 prev_can_force=prev_cf,
425:                 hits=alert_hit_count,
426:                 n_alerts=n_alerts,
427:                 base=base,
428:                 wilson_lb=wilson_lb,
429:                 lift_lb=lift_lb,
430:                 grant_reason=grant_reason,
431:                 evidence_asof=evidence_asof,
432:                 root=root,
433:             )
434:         except Exception as exc:  # noqa: BLE001
435:             log.warning("risk_radar_intl_audit: governance logging failed for %s: %s", market, exc)
436: 
437:     mistakes = [{"asof": r["asof"], "state": r["state"], "dominant_scare": r.get("dominant_scare"),
438:                  "fwd_dd_h21": r["graded"]["fwd_dd"].get("h21"), "kind": r["graded"]["outcome"]}
439:                 for r in rows if r["graded"]["outcome"] == "false_positive"
440:                 or (not r.get("alert") and r["graded"].get("any_dd5_within_h21"))]
441:     return {
442:         "market": market,
443:         "n_graded": n,
444:         "evidence_construction": "legacy_implicit",
445:         "excluded_composition_rows": excluded,
446:         "base_rate_dd5_h21": round(base, 3),
447:         "alert_precision": round(len(tp) / len(alerts), 3) if alerts else None,
448:         "n_alerts": n_alerts,
449:         "alert_hit_rate": round(alert_hit, 3) if alert_hit is not None else None,
450:         "force_lift": force_lift,
451:         "can_force": can_force,
452:         # Additive Article-3 fields (existing consumers read only the bool above)
453:         "wilson_lift_lb": lift_lb,
454:         "grant_reason": grant_reason,
455:         "evidence_asof": evidence_asof,
456:         "by_state": by_state,
457:         "realized_odds": realized_odds(market, root),
458:         "recent_mistakes": sorted(mistakes, key=lambda m: m["asof"], reverse=True)[:20],
459:         "asof_range": [rows[0]["asof"], rows[-1]["asof"]],
460:     }
461: 
462: 
463: def snapshot_and_grade(snap: dict, profile, root=None) -> dict:
464:     """Log today's snapshot, grade matured entries, return the scorecard (attached to
465:     latest['risk_radar']['forward_log'] by the build)."""
466:     log_snapshot(snap, profile.key, root=root)
467:     grade_log(profile, root=root)
468:     return scorecard(profile.key, root=root)
```

## COMPLETE CANDIDATE SOURCE: engine/risk_radar_intl_tune.py
```
1: """International Risk Radar — bounded, do-no-harm auto-calibration of the prob surface.
2: 
3: Closes the evergreen loop the audit (engine/risk_radar_intl_audit.py) opens. It reads the
4: GRADED forward-outcome log and nudges each market's displayed pullback-odds toward the odds
5: the radar ACTUALLY realized in that state — so the number on the card becomes measured from
6: the radar's own track record, not a hand-set prior. Deterministic, no LLM, fully auditable.
7: 
8: THREE GUARDS so a self-tuning gauge can't tune itself off a cliff:
9:   1. GATED — nothing until >= MIN_GRADED matured calls; a state's odds move only once it has
10:      fired on >= MIN_STATE_SAMPLES of them.
11:   2. CLAMPED + MONOTONE — every odds value stays in [0, .95], moves <= MAX_STEP per run, and
12:      the surface is forced non-decreasing calm→risk-off (a louder state can't imply calmer odds).
13:   3. DO-NO-HARM — the candidate surface must not WORSEN the Brier score on the graded log.
14: 
15: Accepted surfaces are written to data/risk_radar_intl/<key>_calibration.json (the overlay
16: engine/risk_radar_intl.compute reads); every proposal is appended to <key>_tune_log.jsonl.
17: Bands are left structural (only the displayed odds are tuned). Never raises.
18: """
19: from __future__ import annotations
20: 
21: import json
22: import logging
23: from datetime import datetime, timezone
24: from pathlib import Path
25: 
26: from engine import risk_radar_intl as R
27: from engine import risk_radar_intl_audit as A
28: from lib import config
29: 
30: log = logging.getLogger(__name__)
31: 
32: MIN_GRADED = 25
33: MIN_STATE_SAMPLES = 6
34: MAX_STEP = 0.05            # max odds move per (state, horizon) per run
35: BLEND = 0.5               # target = halfway between current odds and realized odds
36: STATES = ["calm", "watch", "caution", "elevated", "risk-off"]
37: HK = ("h5", "h10", "h21")
38: 
39: 
40: def _clamp(x, lo=0.0, hi=0.95):
41:     return max(lo, min(hi, x))
42: 
43: 
44: def _monotone(pc: dict) -> dict:
45:     """Force odds non-decreasing along calm→risk-off within each horizon."""
46:     for h in HK:
47:         run = 0.0
48:         for s in STATES:
49:             if s in pc[h]:
50:                 run = max(run, pc[h][s])
51:                 pc[h][s] = round(run, 3)
52:     return pc
53: 
54: 
55: def _brier(rows: list[dict], pc: dict) -> float:
56:     """Mean squared error of the h21 odds vs the realized 0/1 outcome over the graded log."""
57:     se = n = 0.0
58:     for r in rows:
59:         st = r.get("state")
60:         g = r.get("graded") or {}
61:         fdd = (g.get("fwd_dd") or {}).get("h21")
62:         if fdd is None:
63:             continue
64:         actual = 1.0 if fdd <= -A.PRIMARY_DD else 0.0
65:         p = pc.get("h21", {}).get(st)
66:         if p is None:
67:             continue
68:         se += (p - actual) ** 2
69:         n += 1
70:     return se / n if n else 1.0
71: 
72: 
73: def _calib_path(key: str, root=None) -> Path:
74:     base = config.data_dir() if root is None else (Path(root) / "data")
75:     p = base / "risk_radar_intl" / f"{key}_calibration.json"
76:     p.parent.mkdir(parents=True, exist_ok=True)
77:     return p
78: 
79: 
80: def _log_review(key: str, root, record: dict) -> None:
81:     try:
82:         p = _calib_path(key, root).parent / f"{key}_tune_log.jsonl"
83:         with p.open("a") as fh:
84:             fh.write(json.dumps(record, separators=(",", ":"), default=str) + "\n")
85:     except Exception:  # noqa: BLE001
86:         pass
87: 
88: 
89: def _append_governance_a6(key: str, root, decision: str, n_graded: int,
90:                            brier_cur: float, brier_cand: float) -> None:
91:     """Append a6_auto_apply governance event for this market's intl radar tune. Fail-open."""
92:     try:
93:         from engine.neuralweb.governance import append_event  # type: ignore[import]
94:         calib_ref = f"data/risk_radar_intl/{key}_calibration.json"
95:         append_event(
96:             "a6_auto_apply",
97:             calib_ref,
98:             article=6,
99:             authored_by="risk_radar_intl_tune",
100:             evidence={
101:                 "market": key,
102:                 "n_graded": n_graded,
103:                 "do_no_harm_evidence": {
104:                     "brier_before": round(brier_cur, 4),
105:                     "brier_after": round(brier_cand, 4),
106:                     "improves": brier_cand <= brier_cur + 1e-9,
107:                 },
108:             },
109:             after={"action": decision, "lane": "i", "engine": "risk_radar_intl_tune",
110:                    "calibration_ref": calib_ref},
111:             note="ratified standing A6 lane-i; quarterly re-audit required",
112:             root=root,
113:         )
114:     except Exception as exc:  # noqa: BLE001
115:         log.warning("risk_radar_intl_tune(%s): governance append failed: %s", key, exc)
116: 
117: 
118: def tune(profile, root=None) -> dict:
119:     """One bounded calibration step for `profile`. Returns a status dict; never raises."""
120:     key = profile.key
121:     try:
122:         rows, excluded = A._legacy_graded_cohort(A._read(A._path(key, root)))
123:         if len(rows) < MIN_GRADED:
124:             return {"status": "accruing", "n_graded": len(rows), "need": MIN_GRADED,
125:                     "evidence_construction": "legacy_implicit", "excluded_composition_rows": excluded}
126:         cal = R._calib(profile, root)
127:         cur_pc, base = cal["prob_cal"], cal["prob_base"]
128:         realized = A.realized_odds(key, root)
129:         cand = {h: dict(cur_pc[h]) for h in HK}
130:         for h in HK:
131:             for s in STATES:
132:                 cur = cur_pc[h].get(s, base[h])
133:                 r = realized.get(s)
134:                 if not r or r["n"] < MIN_STATE_SAMPLES:
135:                     cand[h][s] = round(cur, 3)
136:                     continue
137:                 target = (1 - BLEND) * cur + BLEND * r[h]
138:                 step = max(-MAX_STEP, min(MAX_STEP, target - cur))
139:                 cand[h][s] = round(_clamp(cur + step), 3)
140:         cand = _monotone(cand)
141:         changed = any(abs(cand[h].get(s, 0) - cur_pc[h].get(s, base[h])) >= 0.005
142:                       for h in HK for s in STATES)
143:         brier_cur, brier_cand = _brier(rows, cur_pc), _brier(rows, cand)
144:         improves = brier_cand <= brier_cur + 1e-9
145:         decision = "apply" if (changed and improves) else "hold"
146:         if decision == "apply":
147:             payload = {"prob_cal": cand, "n_graded": len(rows),
148:                        "brier_before": round(brier_cur, 4), "brier_after": round(brier_cand, 4),
149:                        "updated": datetime.now(timezone.utc).isoformat(timespec="seconds")}
150:             _calib_path(key, root).write_text(json.dumps(payload, indent=2))
151:         rec = {"asof": rows[-1]["asof"], "ts": datetime.now(timezone.utc).isoformat(timespec="seconds"),
152:                "n_graded": len(rows), "decision": decision,
153:                "brier": {"current": round(brier_cur, 4), "candidate": round(brier_cand, 4)},
154:                "realized": realized}
155:         _log_review(key, root, rec)
156:         # A6 lane-(i) governance event — ratified standing approval; fail-open
157:         _append_governance_a6(key, root, decision, len(rows), brier_cur, brier_cand)
158:         return {"status": decision, "n_graded": len(rows),
159:                 "evidence_construction": "legacy_implicit", "excluded_composition_rows": excluded,
160:                 "brier": rec["brier"], "realized": realized}
161:     except Exception as e:  # noqa: BLE001
162:         log.warning("risk_radar_intl_tune(%s) failed: %s", key, e)
163:         return {"status": "error", "reason": str(e)}
```

## COMPLETE CANDIDATE SOURCE: engine/risk_radar_recovery.py
```
1: """Risk Radar DE-ESCALATION — the "risk has peaked / the risk-off may be ending" read.
2: 
3: DISPLAY-ONLY · LEAF · NEVER RAISES. The mirror image of the rising-risk radar. It surfaces
4: ONLY after the radar has been genuinely hot, when two things line up:
5: 
6:   (a) RISK DERATING — the radar's own intensity has peaked and the pullback odds are rolling
7:       over (engine/risk_radar.trajectory; leak-free, from the same causal sub-score history); and
8:   (b) a LIQUIDITY TURN — the macro money tide is turning supportive: Fed net liquidity expanding
9:       (TGA drawdown / reserves rising), the Fed pricing or signalling cuts (incl. an emergency
10:       cut), the PBoC easing (RRR / LPR), or the global central-bank balance-sheet tide
11:       (Fed + ECB + BoJ) expanding.
12: 
13: When risk DERATES while liquidity is INJECTED, history says the risk-off is often nearing its
14: end — so we ILLUSTRATE that turn (a "↘ receding / TURN" panel on the .rrx card) rather than
15: leave the user staring at a still-red alert.
16: 
17: HONESTY (this never moves money on its own):
18:   • The rising radar earns the right to CAP Market State because its legs cleared a strict
19:     forward-lift bar. This recovery read has NOT been forward-tested to that bar yet, so it is
20:     a CONTEXT ILLUSTRATION only. It is wired in as a display-only sibling field on the radar
21:     view-model and DOES NOT relax the radar's one-directional score ceiling
22:     (engine/market_state._radar_override) — the guardrail stays intact.
23:   • The de-risk → re-risk response is SIZING: scale exposure back in deliberately, in tranches,
24:     keep stops, let price confirm. Never a single buy call.
25:   • BoJ has no isolated easing detector freely available, so it enters ONLY via the aggregate
26:     global central-bank tide (global_liquidity, which sums Fed+ECB+BoJ); the chip says so.
27:   • Every input is display-only context already on the page; every field degrades to absent,
28:     never crashes the build.
29: 
30: MARKET CHANNEL (added W1, RRX-R2..R7):
31:   • engine/risk_radar_market_catalysts.py adds 7 market-internal confirmation chips (C1–C7)
32:     plus a vol-instability veto (C8). Each chip is ACCRUING / display-only — not forward-tested
33:     yet. Forward-grading is managed by engine/risk_radar_recovery_audit.py on the rebound ruler
34:     pre-declared in research/RISK_RADAR_EXPANSION_MASTERPLAN_BY_FABLE.md §3.
35:   • turn_confirmed_full (new sibling key) = liquidity channel AND market channel confirmed.
36:     The existing turn_confirmed field is UNCHANGED for backward compat.
37:   • channels dict (new sibling key) exposes {liquidity, market, veto} booleans separately.
38: """
39: from __future__ import annotations
40: 
41: import json
42: import logging
43: from datetime import date, datetime
44: from pathlib import Path
45: 
46: log = logging.getLogger(__name__)
47: 
48: 
49: def _load_liquidity_plumbing() -> dict:
50:     """Load data/neuralweb/liquidity_plumbing.json via lib.config — fail-open to empty dict.
51: 
52:     Uses the same loader pattern as _us_latest(): lib.config.data_dir() for the
53:     data root, silent exception swallow, never raises.
54:     """
55:     try:
56:         from lib import config  # noqa: PLC0415
57:         p = config.data_dir() / "neuralweb" / "liquidity_plumbing.json"
58:         return json.loads(p.read_text()) if p.exists() else {}
59:     except Exception as e:  # noqa: BLE001
60:         log.debug("recovery: liquidity_plumbing unavailable (%s)", e)
61:         return {}
62: 
63: 
64: def _num(v):
65:     try:
66:         if v is None:
67:             return None
68:         f = float(v)
69:         return f if f == f else None   # drop NaN
70:     except (TypeError, ValueError):
71:         return None
72: 
73: 
74: def _recent(date_str: str | None, days: int = 60) -> bool:
75:     """True if an ISO date string is within `days` of today (for the 'fresh' catalyst flag)."""
76:     if not date_str:
77:         return False
78:     try:
79:         d = datetime.strptime(str(date_str)[:10], "%Y-%m-%d").date()
80:         return (date.today() - d).days <= days
81:     except (TypeError, ValueError):
82:         return False
83: 
84: 
85: def _us_latest() -> dict:
86:     """The US regime latest.json — canonical source of the Fed net-liquidity overlay + reaction
87:     function. The intl (CN/HK/CA) latests don't carry these, but the Fed is a GLOBAL liquidity
88:     driver (US rate shocks are the #1 external lead in every intl radar profile), so the intl
89:     recovery reads them from here. Never raises."""
90:     try:
91:         import json
92:         from lib import config
93:         p = config.data_dir() / "regime" / "latest.json"
94:         return json.loads(p.read_text()) if p.exists() else {}
95:     except Exception as e:  # noqa: BLE001
96:         log.debug("recovery: US latest unavailable (%s)", e)
97:         return {}
98: 
99: 
100: # --- liquidity-injection catalysts -------------------------------------------------------------
101: def _market_catalysts(latest: dict | None = None) -> dict | None:
102:     """Lazy import of engine/risk_radar_market_catalysts. Returns the compute() dict or None on
103:     any failure. latest is passed for future context-gating but currently unused by compute().
104:     NEVER raises.
105: 
106:     Hot-path note: this function is called on both the intraday fast-path
107:     (build_risk_state.py → market_state.market_state_snapshot → assess) and the nightly path
108:     (engine/run.py).  compute() itself is read-only (no ledger writes) and the result is
109:     stripped from risk_state.json by _verdict_block's key whitelist, so no ledger or banner
110:     mutation occurs intraday.  The per-tick I/O cost is ~4 store.read calls (breadth/SPY/_VIX
111:     /FRED) plus rolling/EMA/pct_rank_window; acceptable on the current 4-core box given the
112:     intraday tick rate (~1/min), but operator should revisit if tick frequency increases.
113:     """
114:     try:
115:         from engine import risk_radar_market_catalysts as _rmc
116:         return _rmc.compute()
117:     except Exception as e:  # noqa: BLE001
118:         log.debug("recovery: market catalysts unavailable (%s)", e)
119:         return None
120: 
121: 
122: def _fed_netliq_detail() -> tuple[str, str]:
123:     """Build enriched EN+ZH detail strings for the fed_netliq catalyst chip (RLT-R5).
124: 
125:     Reads liquidity_plumbing.json for netliq Δ20d and tga_impulse magnitude.
126:     Falls back to the prior generic string if the artifact is absent or the
127:     fields are null. NEVER raises.
128:     """
129:     try:
130:         lp = _load_liquidity_plumbing()
131:         if not lp:
132:             raise ValueError("empty")
133: 
134:         # Strip envelope if present (same pattern as world_state._compose_liquidity_plumbing)
135:         try:
136:             from engine.neuralweb.envelope import strip_envelope  # noqa: PLC0415
137:             payload = strip_envelope(lp)
138:         except Exception:  # noqa: BLE001
139:             payload = lp
140: 
141:         qty = payload.get("quantity") or {}
142:         treasury = payload.get("treasury") or {}
143:         chg20 = qty.get("netliq_chg_20d_bn")
144:         tga_imp = treasury.get("tga_impulse") or {}
145: 
146:         parts_en = ["Net liquidity (WALCL − RRP − TGA) rising"]
147:         parts_zh = ["净流动性（WALCL − RRP − TGA）上升"]
148: 
149:         if chg20 is not None:
150:             sign = "+" if chg20 >= 0 else ""
151:             parts_en.append(f"({sign}${chg20:.0f}B/20d)")
152:             parts_zh.append(f"（{sign}{chg20*10:.0f}亿美元/20日）")
153: 
154:         if tga_imp.get("active") and tga_imp.get("magnitude_bn") is not None:
155:             mag = tga_imp["magnitude_bn"]
156:             direction = tga_imp.get("direction", "drawdown")
157:             since = tga_imp.get("since", "")
158:             since_str = ""
159:             if since:
160:                 try:
161:                     from datetime import datetime as _dt  # noqa: PLC0415
162:                     d = _dt.strptime(since[:10], "%Y-%m-%d")
163:                     since_str = f" since {d.strftime('%b %-d')}"
164:                     since_zh = f"自{d.month}月{d.day}日起"
165:                 except Exception:  # noqa: BLE001
166:                     since_str = f" since {since[:10]}"
167:                     since_zh = f"自{since[:10]}起"
168:             else:
169:                 since_zh = ""
170: 
171:             if direction == "drawdown":
172:                 parts_en.append(
173:                     f"— Treasury spent down ${mag:.0f}B{since_str} "
174:                     "(cash flows into system)"
175:                 )
176:                 parts_zh.append(
177:                     f"— 财政部{since_zh}动用现金账户{mag*10:.0f}亿美元（资金流入系统）"
178:                 )
179:             else:
180:                 # direction == "build": TGA refilling absorbs cash, but net-liq is
181:                 # expanding via WALCL growth — describe that channel, not a drawdown.
182:                 parts_en.append("— WALCL expansion driving net-liq rise")
183:                 parts_zh.append("— WALCL扩表推动净流动性上升")
184:         else:
185:             parts_en.append("— TGA drawdown / reserves added")
186:             parts_zh.append("— TGA 回落／准备金注入")
187: 
188:         detail_en = " ".join(parts_en) + "."
189:         detail_zh = "".join(parts_zh) + "。"
190:         return detail_en, detail_zh
191: 
192:     except Exception:  # noqa: BLE001
193:         return (
194:             "Net liquidity (WALCL − RRP − TGA) rising — TGA drawdown / reserves added.",
195:             "净流动性（WALCL − RRP − TGA）上升 — TGA 回落／准备金注入。",
196:         )
197: 
198: 
199: def _liquidity_catalysts(latest: dict, market: str = "us") -> list[dict]:
200:     """The supportive-liquidity legs that are firing right now, as display chips. All read the
201:     display-only context already on the page; each degrades to absent. `fresh` = a genuinely
202:     recent turn (drives the chip glow). For the intl radars (market != 'us') the Fed legs are read
203:     from the US regime latest (a global driver). NEVER raises."""
204:     latest = latest or {}
205:     # Fed net-liq + reaction function: the US latest has them; the intl latests don't, so fall back
206:     # to the US regime latest (the Fed is a global liquidity driver for CN/HK/CA too).
207:     fed_src = latest if (market == "us" or latest.get("fed_stance")) else _us_latest()
208:     cats: list[dict] = []
209: 
210:     # 1) Fed net liquidity (WALCL − RRP − TGA). 'expanding' = the 20d ROC is positive, i.e. the
211:     #    balance sheet is adding reserves and/or the Treasury is drawing its account down (TGA
212:     #    drop). engine/regime.py classifies this into latest['liquidity_overlay'].
213:     lo = fed_src.get("liquidity_overlay")
214:     if lo == "expanding":
215:         # RLT-R5: enrich detail with netliq Δ20d magnitude and TGA impulse when available.
216:         # Fail-open: falls back to the generic string when the artifact is absent.
217:         detail_en, detail_zh = _fed_netliq_detail()
218:         cats.append({
219:             "key": "fed_netliq", "icon": "💵", "region": "US", "fresh": True,
220:             "label_en": "Fed liquidity expanding", "label_zh": "美联储流动性扩张",
221:             "detail_en": detail_en,
222:             "detail_zh": detail_zh,
223:             # RLT-R5: salience — measured odds edge from LIQUIDITY_LADDER, plain words,
224:             # never 'validated' (CI guard). Shown only when the catalyst is fresh/active.
225:             "salience_en": (
226:                 "When liquidity is expanding like this, buying dips has historically "
227:                 "worked ~6pp more often over the next month "
228:                 "(a measured odds edge, not a promise)."
229:             ),
230:             "salience_zh": (
231:                 "历史上，在流动性扩张期间逢低买入的成功率比平均高约6个百分点（次月维度）"
232:                 "——这是一个经过回测的概率优势，不是承诺。"
233:             ),
234:         })
235: 
236:     # 2) Fed policy easing / emergency cut — market pricing + reaction-function read (display-only;
237:     #    engine/fed_path.py + engine/fed_stance.py). A large cut count = the emergency-cut case.
238:     fs = fed_src.get("fed_stance") or {}
239:     fp = fed_src.get("fed_path") or {}
240:     cuts = _num(fs.get("implied_cuts_12m"))
241:     if cuts is None:
242:         cuts = _num(fp.get("implied_cuts_12m"))
243:     dovish = (fs.get("stance") == "dovish")
244:     easing_guide = ((fs.get("guidance") or "") == "easing")
245:     if dovish or easing_guide or (cuts is not None and cuts >= 1.5):
246:         big = cuts is not None and cuts >= 3
247:         if cuts is not None and cuts >= 1:
248:             det_en = f"Market prices ~{cuts:.0f} cut{'s' if cuts >= 2 else ''} over 12m — dovish reaction function."
249:             det_zh = f"市场为未来12个月定价约{cuts:.0f}次降息 — 鸽派反应函数。"
250:         else:
251:             det_en = "Dovish Fed guidance — policy turning supportive."
252:             det_zh = "美联储鸽派指引 — 政策转向宽松。"
253:         cats.append({
254:             "key": "fed_policy", "icon": "🏛", "region": "US",
255:             "fresh": bool(easing_guide or big),
256:             "label_en": "Fed easing — aggressive" if big else "Fed easing / cuts priced",
257:             "label_zh": "美联储宽松（大幅）" if big else "美联储宽松／降息定价",
258:             "detail_en": det_en, "detail_zh": det_zh,
259:         })
260: 
261:     # 3) PBoC easing (RRR / LPR / money-market) — engine/china_pboc_stance.py. Relevant to the
262:     #    global liquidity tide, not just China. Lazy import: it is a China leaf the US latest may
263:     #    not carry.
264:     try:
265:         from engine import china_pboc_stance
266:         pb = china_pboc_stance.snapshot()
267:     except Exception as e:  # noqa: BLE001
268:         log.debug("recovery: pboc stance unavailable (%s)", e)
269:         pb = None
270:     if pb and pb.get("stance") == "easing":
271:         moves = pb.get("last_moves") or []
272:         fresh = any(m.get("easing") and _recent(m.get("date")) for m in moves)
273:         rat = pb.get("rationale") or {}
274:         cats.append({
275:             "key": "pboc", "icon": "🇨🇳", "region": "CN", "fresh": bool(fresh),
276:             "label_en": "PBoC easing", "label_zh": "中国央行宽松",
277:             "detail_en": rat.get("en") or "RRR / LPR cuts — PBoC adding liquidity.",
278:             "detail_zh": rat.get("zh") or "降准／降息 — 央行注入流动性。",
279:         })
280: 
281:     # 4) Global central-bank balance-sheet tide (Fed + ECB + BoJ, USD-summed) — engine/
282:     #    global_liquidity.py. This is the ONLY freely-available read of BoJ liquidity, so the BoJ
283:     #    leg lives here (the chip says so). Lazy import (not wired into the US latest).
284:     try:
285:         from engine import global_liquidity
286:         gl = global_liquidity.snapshot()
287:     except Exception as e:  # noqa: BLE001
288:         log.debug("recovery: global liquidity unavailable (%s)", e)
289:         gl = None
290:     if gl and gl.get("state") == "expanding":
291:         accel = gl.get("accel")
292:         imp = (gl.get("impulse_pct") or {}).get("13w")
293:         imp_txt = f"+{imp}%" if isinstance(imp, (int, float)) and imp > 0 else (f"{imp}%" if imp is not None else "")
294:         cats.append({
295:             "key": "global_cb", "icon": "🌊", "region": "GLOBAL",
296:             "fresh": (accel == "accelerating"),
297:             "label_en": "Global CB liquidity expanding", "label_zh": "全球央行流动性扩张",
298:             "detail_en": f"Fed + ECB + BoJ balance-sheet tide {imp_txt} (13w), {accel}.".replace("  ", " "),
299:             "detail_zh": f"美欧日央行资产负债表 13周 {imp_txt}（{accel}）。",
300:         })
301: 
302:     return cats
303: 
304: 
305: # --- the assembled recovery read ---------------------------------------------------------------
306: def assess(latest: dict) -> dict | None:
307:     """The display-only recovery view-model attached to market_state.radar.recovery. Returns
308:     {'present': False} when there is nothing to show, the full dict when the risk-off looks to be
309:     peaking / receding, or None when there is no trajectory at all. NEVER raises."""
310:     try:
311:         rr = (latest or {}).get("risk_radar") or {}
312:         composition = rr.get("composition")
313:         if composition and not composition.get("comparison_comparable"):
314:             market = rr.get("market") or "us"
315:             cats = _liquidity_catalysts(latest, market)
316:             mkt = _market_catalysts(latest) if market == "us" else None
317:             return {"present": False, "assessment_status": "unavailable",
318:                     "degraded_reason": "composition_not_comparable",
319:                     "catalysts": cats, "market": mkt,
320:                     "n_catalysts": len(cats), "n_fresh": sum(bool(c.get("fresh")) for c in cats),
321:                     "receding": False, "turn_confirmed": False,
322:                     "turn_confirmed_full": False if market == "us" else None}
323:         traj = rr.get("trajectory")
324:         if not traj:
325:             return None
326:         market = rr.get("market") or "us"   # 'us' | 'cn' | 'hk' | 'ca' (intl reads Fed legs globally)
327:         phase = traj.get("phase")
328:         reached = bool(traj.get("reached_risk"))
329:         cats = _liquidity_catalysts(latest, market)
330:         n_cat = len(cats)
331:         n_fresh = sum(1 for c in cats if c.get("fresh"))
332: 
333:         # Market-internal confirmation channel (W1, accruing — not yet forward-tested).
334:         # US-ONLY: the chips read US stores (S&P breadth, SPY, VIX term, HY OAS) — attaching
335:         # them to the CN/HK/CA radar latests would render US internals on intl cards
336:         # (assess() serves BOTH call sites in engine/market_state.py). Intl ports are a
337:         # W5 docket (masterplan §5); until then the intl market channel is N/A, not False.
338:         mkt = _market_catalysts(latest) if market == "us" else None
339: 
340:         # Show ONLY once there was genuine risk to recede FROM, and it is no longer rising — OR a
341:         # broad liquidity turn is underway while the radar sits at/just past its peak.
342:         present = (reached and phase in ("peaking", "receding")) or \
343:                   (reached and phase != "rising" and n_fresh >= 2)
344:         if not present:
345:             return {"present": False}
346: 
347:         # ONE risk voice per page (2026-07-02 incident): the radar publishes the
348:         # de-escalation verdict beside its scares (risk_radar.deescalation); this
349:         # panel is a DERIVATIVE of it, not an independent opinion. When the radar
350:         # says not eligible (dominant risk-off scare escalating / pullback odds
351:         # rising), the green "receding" presentation is suppressed — the panel may
352:         # still narrate what IS fading, never an all-clear. Absent block (older
353:         # artifact) degrades to the standalone behavior.
354:         deesc = rr.get("deescalation")
355:         suppressed = bool(deesc) and deesc.get("eligible") is False
356: 
357:         receding = (phase == "receding") and not suppressed
358:         peaking = (phase == "peaking") and not suppressed
359:         turn_confirmed = bool(receding and n_fresh >= 1)   # risk derating + liquidity injection (UNCHANGED)
360: 
361:         # Market channel: accruing, not yet forward-tested. On intl radars (mkt is None by
362:         # the scoping above) the channel is N/A: channels.market / turn_confirmed_full stay
363:         # None so the card can distinguish "not confirmed" from "not applicable".
364:         if market == "us":
365:             mkt_confirmed = bool(mkt and mkt.get("market_confirmed"))
366:             mkt_veto = bool(mkt and mkt.get("veto", {}).get("active"))
367:             # turn_confirmed_full requires BOTH liquidity AND market channels
368:             turn_confirmed_full = bool(turn_confirmed and mkt_confirmed)
369:         else:
370:             mkt_confirmed = mkt_veto = turn_confirmed_full = None
371:         channels = {
372:             "liquidity": bool(n_fresh >= 1),
373:             "market": mkt_confirmed,
374:             "veto": mkt_veto,
375:         }
376: 
377:         off = traj.get("off_peak") or 0.0
378:         vel = traj.get("velocity") or 0.0
379:         # Modest, illustrative 0-100 strength: distance off the peak + how fast it is falling +
380:         # how broad the liquidity turn is. Capped; never implies precision it doesn't have.
381:         strength = int(max(0, min(100, round(
382:             off * 3.0 + max(0.0, -vel) * 3.5 + n_cat * 11 + n_fresh * 6 + (14 if receding else 0)))))
383: 
384:         odds_now = _num(traj.get("odds_now"))
385:         odds_peak = _num(traj.get("odds_peak"))
386:         odds_delta = _num(traj.get("odds_delta"))
387:         days = int(traj.get("peak_days_ago") or 0)
388: 
389:         # ---- bilingual copy ----
390:         if suppressed:
391:             dom_en = rr.get("dominant_label_en") or (rr.get("dominant_scare") or "risk")
392:             dom_zh = rr.get("dominant_label_zh") or "风险"
393:             fading = (deesc or {}).get("receding_scare")
394:             if fading:
395:                 head_en = f"Mixed: {fading} scare fading — {dom_en} still escalating"
396:                 head_zh = f"分化：{fading} 风险消退 — {dom_zh}仍在升级"
397:             else:
398:                 head_en = f"Not receding — {dom_en} still escalating"
399:                 head_zh = f"风险未回落 — {dom_zh}仍在升级"
400:         elif turn_confirmed:
401:             head_en, head_zh = "Risk receding — liquidity turning supportive", "风险回落 — 流动性转向支持"
402:         elif receding:
403:             head_en, head_zh = "Risk receding — pullback odds rolling over", "风险回落 — 回撤概率见顶回落"
404:         else:
405:             head_en, head_zh = "Risk may be peaking", "风险或已见顶"
406: 
407:         # one-line sub headline with the concrete odds turn
408:         if suppressed:
409:             sub_en = (deesc or {}).get("reason") or "The dominant scare is still escalating."
410:             sub_zh = "主导风险仍在升级，回撤概率上行。"
411:         elif odds_now is not None and odds_peak is not None and odds_peak > odds_now:
412:             sub_en = (f"Pullback odds {round(odds_peak*100)}% → {round(odds_now*100)}% "
413:                       f"(peaked {days} day{'s' if days != 1 else ''} ago).")
414:             sub_zh = f"回撤概率 {round(odds_peak*100)}% → {round(odds_now*100)}%（{days} 日前见顶）。"
415:         elif peaking:
416:             sub_en = f"Pullback odds have stopped climbing (peaked {days} day{'s' if days != 1 else ''} ago)."
417:             sub_zh = f"回撤概率已停止攀升（{days} 日前见顶）。"
418:         else:
419:             sub_en = "The radar's intensity is rolling over."
420:             sub_zh = "雷达强度正见顶回落。"
421: 
422:         if suppressed:
423:             do_en = ("An older scare is fading but the dominant one is still escalating — this is "
424:                      "rotation, not recovery. No all-clear: keep the de-risked posture and stops.")
425:             do_zh = ("旧风险消退但主导风险仍在升级 — 这是轮动而非复苏。并非解除警报：维持降险仓位与止损。")
426:         elif turn_confirmed:
427:             do_en = ("The risk-off may be nearing its end. Begin scaling exposure back in tranches — "
428:                      "keep stops, let price confirm the low. Don't chase the first bounce.")
429:             do_zh = ("避险或已接近尾声。可分批逐步回补敞口 — 保留止损，待价格确认低点，切勿追逐首次反弹。")
430:         elif receding:
431:             do_en = ("Odds are rolling over but no liquidity catalyst yet. Stop forced de-grossing; "
432:                      "ready a buy plan and wait for a liquidity turn to confirm.")
433:             do_zh = ("概率回落，但尚无流动性催化。停止被动减仓；备好买入计划，待流动性转向确认。")
434:         else:
435:             do_en = ("Risk has stopped climbing. Don't de-gross into the hole — ready a buy list and "
436:                      "wait for the roll-over (and a liquidity turn) before adding.")
437:             do_zh = ("风险已停止攀升。勿在低位被动减仓 — 备好买入清单，待见顶回落（及流动性转向）再加仓。")
438: 
439:         caveat_en = ("Illustrative context, not a buy trigger. It reads the radar's own intensity "
440:                      "trajectory (leak-free) plus the display-only central-bank liquidity series; "
441:                      "unlike the alert legs it is not forward-tested yet, and risk can re-accelerate. "
442:                      "The de-risk → re-risk response is sizing, scaled in deliberately. BoJ enters "
443:                      "only via the aggregate global central-bank tide (no isolated BoJ feed).")
444:         caveat_zh = ("仅为示意性背景，并非买入信号。它读取雷达自身的强度轨迹（无未来函数）以及仅供展示的"
445:                      "央行流动性序列；不同于警报腿，此读数尚未经前瞻检验，风险可能再度加速。降险→回补的"
446:                      "应对是仓位管理、分批进行。日本央行仅通过全球央行总潮汐体现（无独立日本数据源）。")
447: 
448:         if composition and composition.get("calibration_status") == "unreviewed_corrected_construction":
449:             odds_now = odds_peak = odds_delta = None
450:             if not suppressed:
451:                 head_en = "Risk reading easing" if receding else "Risk reading stabilizing"
452:                 head_zh = "风险读数回落" if receding else "风险读数趋稳"
453:                 sub_en = "The input-based reading changed; forecast calibration remains under review."
454:                 sub_zh = "输入驱动的读数出现变化；预测校准仍待核验。"
455:                 do_en = "Watch price and participation; this does not confirm a market low."
456:                 do_zh = "观察价格与参与广度；此读数不能确认市场低点。"
457:             turn_confirmed = False
458:             turn_confirmed_full = False if market == "us" else None
459:         # RRX2 WA-3: mirror the drivers block (which scares faded / warm) from trajectory.
460:         # Old artifacts without a drivers key → None → template renders nothing.
461:         drivers = traj.get("drivers")
462: 
463:         return {
464:             "present": True,
465:             "phase": phase, "receding": receding, "peaking": peaking,
466:             # radar-derived gate (one risk voice): green suppressed while the
467:             # dominant scare escalates; mirrored for the template/bot to read
468:             "suppressed": suppressed, "deescalation": deesc,
469:             "turn_confirmed": turn_confirmed, "strength": strength,
470:             # --- W1 market-channel additions (sibling keys, never wrappers — RRX-R7) ---
471:             # market_confirmed_raw and market_confirmed are the raw chip outputs
472:             "market": mkt,
473:             "turn_confirmed_full": turn_confirmed_full,
474:             "channels": channels,
475:             # the odds turn + velocity (mirrored from the trajectory so the template reads one dict)
476:             "odds_now": odds_now, "odds_peak": odds_peak, "odds_delta": odds_delta,
477:             "peak_days_ago": days, "velocity": vel, "off_peak": off,
478:             "intensity": _num(traj.get("intensity")), "peak": _num(traj.get("peak")),
479:             # sparkline (pre-scaled in engine/risk_radar.trajectory)
480:             "spark": traj.get("spark"), "spark_pts": traj.get("spark_pts"),
481:             "spark_peak": traj.get("spark_peak"), "spark_last": traj.get("spark_last"),
482:             "spark_w": traj.get("spark_w"), "spark_h": traj.get("spark_h"),
483:             # catalysts
484:             "catalysts": cats, "n_catalysts": n_cat, "n_fresh": n_fresh,
485:             # RRX2 WA-3: drivers line (which scares faded / still warm); None on old artifacts
486:             "drivers": drivers,
487:             # copy
488:             "headline_en": head_en, "headline_zh": head_zh,
489:             "sub_en": sub_en, "sub_zh": sub_zh,
490:             "do_en": do_en, "do_zh": do_zh,
491:             "caveat_en": caveat_en, "caveat_zh": caveat_zh,
492:         }
493:     except Exception as e:  # noqa: BLE001 — additive, never fatal
494:         log.warning("risk_radar_recovery assess failed: %s", e)
495:         return None
```

## EXACT CHANGED CONTEXT: scripts/build_canada.py
```diff
--- baseline/scripts/build_canada.py
+++ candidate/scripts/build_canada.py
@@ -1308,57 +1308,57 @@
             latest["conditions"] = _cac.snapshot(_f, latest.get("overlay") or {})
             # precompute the % >200d-MA 5y percentile + a price/breadth divergence flag for F4
             _b = _f["pct_above_200"].dropna() if "pct_above_200" in getattr(_f, "columns", []) else None
             if _b is not None and len(_b) >= 60:
                 _win = _b.tail(252 * 5)
                 _pctile = float((_win <= _win.iloc[-1]).mean())
                 _px = _f["market_index"].dropna() if "market_index" in _f.columns else None
                 _div = bool(_px is not None and len(_px) > 21 and len(_b) > 21
                             and _b.iloc[-1] < _b.iloc[-22] and _px.iloc[-1] > _px.iloc[-22])
                 latest["conditions"]["breadth"] = {"above200_pctile": _pctile, "div": _div}
             # external-driver Risk Radar (engine/risk_radar_intl.py: US rate shocks, dollar
             # strength + breadth — the TSX is the least US-coupled of the three, so this is the
             # lightest read). Populated BEFORE market_state so CA_PROFILE.radar_override surfaces
             # it. None-safe; display-only.
             from engine import risk_radar_intl as _rri
             latest["risk_radar"] = _rri.snapshot(_rri.CA_PROFILE)
             # forward-grade self-audit + bounded auto-tune (vs realized TSX path); hard-forces the
             # verdict only once Canada's own log validates (can_force). Display-only until then.
             # Ledger/tuner advance ONLY on the nightly lane (house law: nightly is the sole
             # advancer); re-render lanes take the read-only scorecard fast-path.
             try:
                 from engine import risk_radar_intl_audit as _rra
                 if _rra.ledger_lane_armed():
                     from engine import risk_radar_intl_tune as _rrt
                     latest["risk_radar"]["forward_log"] = _rra.snapshot_and_grade(latest["risk_radar"], _rri.CA_PROFILE)
-                    latest["risk_radar"]["can_force"] = bool(latest["risk_radar"]["forward_log"].get("can_force"))
+                    latest["risk_radar"]["can_force"] = _rra.force_applicable_for_snapshot(latest["risk_radar"], bool(latest["risk_radar"]["forward_log"].get("can_force")))
                     _rrt.tune(_rri.CA_PROFILE)
                 else:
                     # Read-only fast-path: snapshot still renders; ledger/tuner do not advance.
                     _sc = _rra.scorecard(_rri.CA_PROFILE.key, log_governance=False)
                     latest["risk_radar"]["forward_log"] = _sc
-                    latest["risk_radar"]["can_force"] = bool(_sc.get("can_force"))
+                    latest["risk_radar"]["can_force"] = _rra.force_applicable_for_snapshot(latest["risk_radar"], bool(_sc.get("can_force")))
             except Exception as _e:  # noqa: BLE001
                 log.warning("canada risk-radar audit/tune failed (%s); skipping", _e)
             # Write the scorecard immediately after the CA ledger is updated so the
             # same-build card reflects today's just-appended row. Never fatal.
             try:
                 from engine import risk_radar_scorecard as _rrs  # noqa: PLC0415
                 _rrs.write()
             except Exception as _e:  # noqa: BLE001
                 log.warning("build_canada: risk-radar scorecard write (pre-render) failed: %s", _e)
             # CGL W1: load the contagion artifact so the directed-pressure table
             # (template CGL var) is available; the actual per-market pressure block
             # is attached to vm["market_state"]["radar"] AFTER market_state_snapshot
             # builds the post-transform rd dict (_radar_to_rd rebuilds from scratch
             # so pre-transform attachments to latest["risk_radar"] are discarded).
             vm.setdefault("CGL", None)
             _cgl_art_ca: dict | None = None
             try:
                 _cgl_path = config.data_dir() / "contagion_links" / "latest.json"
                 if _cgl_path.exists():
                     _cgl_art_ca = json.loads(_cgl_path.read_text(encoding="utf-8"))
                     vm["CGL"] = _cgl_art_ca
             except Exception:  # noqa: BLE001 — additive, never fatal
                 pass
             vm["market_state"] = _ms.market_state_snapshot(
                 latest, _f, latest.get("alerts") or [], profile=CA_PROFILE)

```

## EXACT CHANGED CONTEXT: scripts/build_china.py
```diff
--- baseline/scripts/build_china.py
+++ candidate/scripts/build_china.py
@@ -1423,57 +1423,57 @@
             # precompute the % >200d-MA 5y percentile + a price/breadth divergence flag for F4
             _b = _f["pct_above_200"].dropna() if "pct_above_200" in getattr(_f, "columns", []) else None
             if _b is not None and len(_b) >= 60:
                 _win = _b.tail(252 * 5)
                 _pctile = float((_win <= _win.iloc[-1]).mean())
                 _px = _f["510300.SS"].dropna() if "510300.SS" in _f.columns else None
                 _div = bool(_px is not None and len(_px) > 21 and len(_b) > 21
                             and _b.iloc[-1] < _b.iloc[-22] and _px.iloc[-1] > _px.iloc[-22])
                 latest.setdefault("conditions", {})["breadth"] = {"above200_pctile": _pctile, "div": _div}
             # validated external-driver Risk Radar (engine/risk_radar_intl.py: US rate shocks,
             # US–China yield gap, USD/CNH + breadth — the legs that MEASURABLY lead A-share
             # drawdowns). Populated BEFORE market_state so CN_PROFILE.radar_override surfaces it
             # on the board. None-safe; display-only (does not force the verdict).
             from engine import risk_radar_intl as _rri
             latest["risk_radar"] = _rri.snapshot(_rri.CN_PROFILE)
             # forward-grade self-audit + bounded auto-tune: log+grade today's call against the
             # realized SHCOMP path, attach the scorecard, and let the radar hard-force the verdict
             # ONLY once its own log validates (can_force). Display-only until then. Never fatal.
             # Ledger/tuner advance ONLY on the nightly lane (house law: nightly is the sole
             # advancer); re-render lanes take the read-only scorecard fast-path.
             try:
                 from engine import risk_radar_intl_audit as _rra
                 if _rra.ledger_lane_armed():
                     from engine import risk_radar_intl_tune as _rrt
                     latest["risk_radar"]["forward_log"] = _rra.snapshot_and_grade(latest["risk_radar"], _rri.CN_PROFILE)
-                    latest["risk_radar"]["can_force"] = bool(latest["risk_radar"]["forward_log"].get("can_force"))
+                    latest["risk_radar"]["can_force"] = _rra.force_applicable_for_snapshot(latest["risk_radar"], bool(latest["risk_radar"]["forward_log"].get("can_force")))
                     _rrt.tune(_rri.CN_PROFILE)
                 else:
                     # Read-only fast-path: snapshot still renders; ledger/tuner do not advance.
                     _sc = _rra.scorecard(_rri.CN_PROFILE.key, log_governance=False)
                     latest["risk_radar"]["forward_log"] = _sc
-                    latest["risk_radar"]["can_force"] = bool(_sc.get("can_force"))
+                    latest["risk_radar"]["can_force"] = _rra.force_applicable_for_snapshot(latest["risk_radar"], bool(_sc.get("can_force")))
             except Exception as _e:  # noqa: BLE001
                 log.warning("china risk-radar audit/tune failed (%s); skipping", _e)
             # Write the scorecard immediately after the CN ledger is updated so the
             # same-build card reflects today's just-appended row. Never fatal.
             try:
                 from engine import risk_radar_scorecard as _rrs  # noqa: PLC0415
                 _rrs.write()
             except Exception as _e:  # noqa: BLE001
                 log.warning("build_china: risk-radar scorecard write (pre-render) failed: %s", _e)
             # CGL W1: load the contagion artifact so the directed-pressure table
             # (template CGL var) is available; the actual per-market pressure block
             # is attached to vm["market_state"]["radar"] AFTER market_state_snapshot
             # builds the post-transform rd dict (_radar_to_rd rebuilds from scratch
             # so pre-transform attachments to latest["risk_radar"] are discarded).
             vm.setdefault("CGL", None)
             _cgl_art_cn: dict | None = None
             try:
                 _cgl_path = config.data_dir() / "contagion_links" / "latest.json"
                 if _cgl_path.exists():
                     _cgl_art_cn = json.loads(_cgl_path.read_text(encoding="utf-8"))
                     vm["CGL"] = _cgl_art_cn
             except Exception:  # noqa: BLE001 — additive, never fatal
                 pass
             vm["market_state"] = _ms.market_state_snapshot(
                 latest, _f, latest.get("alerts") or [], profile=CN_PROFILE)

```

## EXACT CHANGED CONTEXT: scripts/build_china_risk_state.py
```diff
--- baseline/scripts/build_china_risk_state.py
+++ candidate/scripts/build_china_risk_state.py
@@ -40,51 +40,51 @@
   breadth          — china_breadth/breadth last date (nightly-only, requires full store)
   vol_qvix         — china_qvix/qvix300 last date (nightly)
   risk_roro        — nightly_asof (RORO composite is nightly)
   liquidity_pboc   — nightly_asof (PBoC overlay is nightly)
   stress_guards    — nightly_asof (slowdown / drawdown gauges are nightly)
 
 Fail-safe: any error in the live recompute logs and falls back to nightly; the JSON
 always emits. --offline forces the no-network path (live == nightly). NO writes
 anywhere except site/live/china_risk_state.json.
 """
 from __future__ import annotations
 
 import argparse
 import copy
 import json
 import logging
 import sys
 from datetime import datetime, timezone
 from pathlib import Path
 
 import pandas as pd
 
 _ROOT = Path(__file__).resolve().parent.parent
 sys.path.insert(0, str(_ROOT))
 
-from engine import live_overlay, live_quotes, market_state, risk_radar_intl  # noqa: E402
+from engine import live_overlay, live_quotes, market_state, risk_radar_intl, risk_radar_intl_audit  # noqa: E402
 from engine.market_state_cn import CN_PROFILE  # noqa: E402
 from lib import config  # noqa: E402
 from lib import store as store_mod  # noqa: E402
 
 log = logging.getLogger("china_risk_state_build")
 
 # Store (group, name) -> live-quote symbol. The radar + market-state tape read
 # these off the price store; only the FAST, intraday-available A-share and
 # FX/capital-flow symbols are here. The SLOW legs (FRED rates, PBoC, breadth)
 # are NOT here — they carry forward nightly.
 #
 # 000001.SS / 510300.SS / 399001.SZ  — the 3-index CN tape (_CN_INDICES in
 #   engine/market_state_cn.py); these are the tape/trend leg
 # 510300.SS is also the price-side of the breadth divergence check
 #   (F4 in build_china): live splice makes the divergence flag reactive intraday
 # 159915.SZ / 510880.SS / 511010.SS / 512400.SS / 518880.SS — the GTAA ETFs;
 #   any engine read of those store names now goes live (feeds movers)
 # ("yahoo","CNH_F") -> "CNH=F"  — USD/CNH: the primary capital-flow leg for the
 #   CN radar; live splice makes radar_capital_flow reactive intraday
 # ("yahoo","DX-Y.NYB") -> "DX-Y.NYB" — DXY: secondary FX leg (fills CNH gap
 #   pre-2013, combined in risk_radar_intl._sub_legs)
 # ("hk","_HSI") -> "^HSI" — Hang Seng index; NO CN state leg reads it today
 #   (it has no role in CN_PROFILE or CN_RADAR), but it feeds the movers block
 #   and provides HK context on the China board
 SPLICE: dict[tuple[str, str], str] = {
@@ -266,92 +266,92 @@
     # All CN/HK symbols go to Yahoo spark (keyless), same as live_overlay intl_source
     quotes = live_quotes.fetch_quotes(
         sorted({sym for sym in SPLICE.values()}),
         offline=offline, diag=diag
     )
     spliced, live_close, nightly_close = _spliced_frames_cn(
         quotes, max_chg, stale_after, now, session_open
     )
     live_active = bool(spliced)
 
     # ---- nightly baseline (run WITHOUT store patch to reproduce rendered board) ----
     # There is no persisted CN market_state snapshot (persist() is US-only), so we
     # reproduce the nightly read by running the same pipeline on the fresh-checkout
     # stores, which equal the Asia-close state the rendered board reflects.
     nightly_ms: dict | None = None
     can_force = _readonly_can_force()   # same authority read for both passes
     try:
         from engine.china_inputs import build_features as _build_features
         _f_nightly = _build_features()
         _latest_nightly = copy.deepcopy(latest)
         # F4 breadth precompute for nightly (feature-frame columns, as build_china does)
         _br_nightly = _precompute_breadth(_f_nightly)
         if _br_nightly is not None:
             _latest_nightly.setdefault("conditions", {})["breadth"] = _br_nightly
         _latest_nightly["risk_radar"] = risk_radar_intl.compute(risk_radar_intl.CN_PROFILE)
-        _latest_nightly["risk_radar"]["can_force"] = can_force
+        _latest_nightly["risk_radar"]["can_force"] = risk_radar_intl_audit.force_applicable_for_snapshot(_latest_nightly["risk_radar"], can_force)
         # build_china passes the full feature frame; _build_tape reads the 3 index columns
         nightly_ms = market_state.market_state_snapshot(
             _latest_nightly, _f_nightly,
             latest.get("alerts") or [], profile=CN_PROFILE
         )
     except Exception as e:  # noqa: BLE001
         log.warning("china_risk_state: nightly baseline failed (%s); nightly block will be empty", e)
 
     # ---- recompute the engine on the spliced store (NO logic duplication) ----
     live_ms: dict | None = None
     _orig_read = store_mod.read
     try:
         def _patched(group, name, *a, **k):
             key = (group, name)
             if key in spliced:
                 return spliced[key]
             return _orig_read(group, name, *a, **k)
         store_mod.read = _patched  # risk_radar_intl + market_state now see live prices
 
         # Build features from the patched store (china_inputs.build_features reads
         # the china price store, which the monkeypatch now redirects for our spliced
         # tickers — so the frame's 510300.SS / index columns carry the live price)
         from engine.china_inputs import build_features as _build_features_live
         _f_live = _build_features_live()
 
         latest_live = copy.deepcopy(latest)
 
         # (a) Replicate the F4 breadth precompute verbatim (build_china lines 808-816):
         # feature-frame columns for both sides; the breadth column is nightly-only
         # (derived store, no live splice) while the price side is live via the splice.
         _br_live = _precompute_breadth(_f_live)
         if _br_live is not None:
             latest_live.setdefault("conditions", {})["breadth"] = _br_live
 
         # (b) External-driver Risk Radar — the patched store makes the USD/CNH and
         # DX-Y.NYB legs reactive to live prices. can_force parity via the read-only
         # scorecard (see _readonly_can_force). NEVER call:
         # risk_radar_intl_audit.snapshot_and_grade, _intl_tune.tune,
         # risk_radar_scorecard.write — those advance nightly ledgers.
         latest_live["risk_radar"] = risk_radar_intl.compute(risk_radar_intl.CN_PROFILE)
-        latest_live["risk_radar"]["can_force"] = can_force
+        latest_live["risk_radar"]["can_force"] = risk_radar_intl_audit.force_applicable_for_snapshot(latest_live["risk_radar"], can_force)
 
         # (c) Same market_state_snapshot the nightly build calls, on the same full
         # feature frame (build_china passes _f; _build_tape reads the 3 index columns)
         live_ms = market_state.market_state_snapshot(
             latest_live, _f_live,
             latest.get("alerts") or [], profile=CN_PROFILE
         )
     except Exception as e:  # noqa: BLE001 — never abort; fall back to nightly
         log.error("china_risk_state: live recompute failed: %s", e)
     finally:
         store_mod.read = _orig_read   # ALWAYS restore, even on exception
 
     live_blk = _verdict_block(live_ms)
     nightly_blk = _verdict_block(nightly_ms)
 
     # Per-leg freshness ledger (honest as-of stamps per-leg)
     legs = []
     for c in (live_ms or nightly_ms or {}).get("components", []):
         key = c.get("key")
         is_live = live_active and key in _LIVE_LEGS
         legs.append({
             "key": key, "label_en": c.get("label_en"), "score": c.get("score"),
             "basis": "live" if is_live else "carried",
             "asof": "live" if is_live else nightly_asof,
         })

```

## EXACT CHANGED CONTEXT: scripts/build_hk.py
```diff
--- baseline/scripts/build_hk.py
+++ candidate/scripts/build_hk.py
@@ -1343,57 +1343,57 @@
             from engine.hk_inputs import build_features as _hk_feats
             _f = _hk_feats()
             # precompute the % >50d-MA 5y percentile + a price/breadth divergence flag for F4
             _b = _f["pct_above_50"].dropna() if "pct_above_50" in getattr(_f, "columns", []) else None
             if _b is not None and len(_b) >= 60:
                 _win = _b.tail(252 * 5)
                 _pctile = float((_win <= _win.iloc[-1]).mean())
                 _px = _f["^HSI"].dropna() if "^HSI" in _f.columns else None
                 _div = bool(_px is not None and len(_px) > 21 and len(_b) > 21
                             and _b.iloc[-1] < _b.iloc[-22] and _px.iloc[-1] > _px.iloc[-22])
                 latest.setdefault("conditions", {})["breadth"] = {"above200_pctile": _pctile, "div": _div}
             # external-driver Risk Radar (engine/risk_radar_intl.py: US rate shocks + dollar
             # strength — HK's US-coupling is recent but real). Populated BEFORE market_state so
             # HK_PROFILE.radar_override surfaces it. None-safe; display-only.
             from engine import risk_radar_intl as _rri
             latest["risk_radar"] = _rri.snapshot(_rri.HK_PROFILE)
             # forward-grade self-audit + bounded auto-tune (vs realized HSI path); hard-forces the
             # verdict only once HK's own log validates (can_force). Display-only until then.
             # Ledger/tuner advance ONLY on the nightly lane (house law: nightly is the sole
             # advancer); re-render lanes take the read-only scorecard fast-path.
             try:
                 from engine import risk_radar_intl_audit as _rra
                 if _rra.ledger_lane_armed():
                     from engine import risk_radar_intl_tune as _rrt
                     latest["risk_radar"]["forward_log"] = _rra.snapshot_and_grade(latest["risk_radar"], _rri.HK_PROFILE)
-                    latest["risk_radar"]["can_force"] = bool(latest["risk_radar"]["forward_log"].get("can_force"))
+                    latest["risk_radar"]["can_force"] = _rra.force_applicable_for_snapshot(latest["risk_radar"], bool(latest["risk_radar"]["forward_log"].get("can_force")))
                     _rrt.tune(_rri.HK_PROFILE)
                 else:
                     # Read-only fast-path: snapshot still renders; ledger/tuner do not advance.
                     _sc = _rra.scorecard(_rri.HK_PROFILE.key, log_governance=False)
                     latest["risk_radar"]["forward_log"] = _sc
-                    latest["risk_radar"]["can_force"] = bool(_sc.get("can_force"))
+                    latest["risk_radar"]["can_force"] = _rra.force_applicable_for_snapshot(latest["risk_radar"], bool(_sc.get("can_force")))
             except Exception as _e:  # noqa: BLE001
                 log.warning("hk risk-radar audit/tune failed (%s); skipping", _e)
             # Write the scorecard immediately after the HK ledger is updated so the
             # same-build card reflects today's just-appended row. Never fatal.
             try:
                 from engine import risk_radar_scorecard as _rrs  # noqa: PLC0415
                 _rrs.write()
             except Exception as _e:  # noqa: BLE001
                 log.warning("build_hk: risk-radar scorecard write (pre-render) failed: %s", _e)
             # CGL W1: load the contagion artifact so the directed-pressure table
             # (template CGL var) is available; the actual per-market pressure block
             # is attached to vm["market_state"]["radar"] AFTER market_state_snapshot
             # builds the post-transform rd dict (_radar_to_rd rebuilds from scratch
             # so pre-transform attachments to latest["risk_radar"] are discarded).
             vm.setdefault("CGL", None)
             _cgl_art_hk: dict | None = None
             try:
                 _cgl_path = config.data_dir() / "contagion_links" / "latest.json"
                 if _cgl_path.exists():
                     _cgl_art_hk = json.loads(_cgl_path.read_text(encoding="utf-8"))
                     vm["CGL"] = _cgl_art_hk
             except Exception:  # noqa: BLE001 — additive, never fatal
                 pass
             vm["market_state"] = _ms.market_state_snapshot(
                 latest, _f, latest.get("alerts") or [], profile=HK_PROFILE)

```

## COMPLETE CANDIDATE SOURCE: scripts/build_international_macro.py
```
1: """Render five first-class international macro dashboards from one view contract.
2: 
3: Usage:
4:     python -m scripts.build_international_macro
5: 
6: The normal pipeline invokes this after ``engine.intl_run`` has refreshed
7: ``data/intl/latest.json`` and the per-country history parquets.
8: """
9: 
10: from __future__ import annotations
11: 
12: import json
13: import logging
14: import sys
15: from pathlib import Path
16: 
17: from jinja2 import Environment, FileSystemLoader
18: 
19: sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
20: 
21: from engine.international_macro_dashboard import (
22:     REGIONS,
23:     build_country_view,
24:     load_history,
25:     validate_view,
26: )
27: from lib import config, site_assets
28: from lib.pages import write_page
29: 
30: log = logging.getLogger("build_international_macro")
31: 
32: ASSETS = (
33:     "theme.css",
34:     "product-nav-icons.css",
35:     "navigation-refresh.css",
36:     "theme.js",
37: )
38: 
39: 
40: def _load_latest() -> dict:
41:     path = config.data_dir() / "intl" / "latest.json"
42:     if not path.exists():
43:         raise FileNotFoundError(f"international engine output missing: {path}")
44:     return json.loads(path.read_text())
45: 
46: 
47: def _radar_display(record: dict) -> dict | None:
48:     """Normalize this market's nightly ``risk_radar_intl`` snapshot into the ``rd`` shape
49:     the shared .rrx Risk Radar card consumes (``engine/market_state._radar_to_rd`` — the
50:     one transform already used by the US modal and the China / HK / Canada boards, so the
51:     five international dashboards show the same radar layer, not a second dialect).
52: 
53:     Display-only: the transform reads what ``engine/intl_run.py`` already persisted on the
54:     record (``record["risk_radar"]``) and computes nothing new. Returns ``None`` — the page
55:     then renders with no card and keeps its own pullback tile — when the market carries no
56:     snapshot yet (a profile that raised inside intl_run, or a ``latest.json`` written before
57:     the radar was wired), so a missing radar can never fail or empty a dashboard.
58:     """
59:     radar = record.get("risk_radar") or {}
60:     if not isinstance(radar, dict):
61:         return None
62:     if "composition" not in radar:
63:         if not radar.get("state"):
64:             return None
65:         if (radar.get("drawdown_prob") or {}).get("h21") is None:
66:             return None
67:     # Explicit input quality is a displayable assessment, not a promise of odds.
68:     try:
69:         from engine.market_state import _radar_to_rd
70: 
71:         return _radar_to_rd(radar)
72:     except Exception:  # noqa: BLE001 — additive display layer, never fatal
73:         log.warning(
74:             "risk radar card transform failed for %s; rendering without it",
75:             record.get("cc"),
76:         )
77:         return None
78: 
79: 
80: def build_all(latest: dict | None = None) -> list[Path]:
81:     latest = latest or _load_latest()
82:     records = {
83:         str(record.get("cc")): record
84:         for record in (latest.get("records") or [])
85:         if record.get("cc")
86:     }
87:     missing = sorted(set(REGIONS) - set(records))
88:     if missing:
89:         raise RuntimeError(
90:             f"international engine missing required markets: {', '.join(missing)}"
91:         )
92: 
93:     root = Path(config.ROOT)
94:     site = Path(config.load()["storage"]["site_dir"])
95:     site.mkdir(parents=True, exist_ok=True)
96:     data_out = config.data_dir() / "international_macro"
97:     data_out.mkdir(parents=True, exist_ok=True)
98: 
99:     env = Environment(
100:         loader=FileSystemLoader(str(root / "templates")),
101:         autoescape=False,
102:         trim_blocks=True,
103:         lstrip_blocks=True,
104:     )
105:     template = env.get_template("international_macro.html.j2")
106:     outputs: list[Path] = []
107:     for cc, spec in REGIONS.items():
108:         view = build_country_view(records[cc], load_history(cc))
109:         validate_view(view)
110:         (data_out / f"{cc}_latest.json").write_text(
111:             json.dumps(view, indent=2, ensure_ascii=False, default=str) + "\n"
112:         )
113:         page = site / spec.route
114:         # RADAR is a render-time display variable, deliberately outside the
115:         # international_macro_dashboard.v1 payload written above: it is a re-shaping of
116:         # data/intl/latest.json for one card, not a new term of the data contract.
117:         write_page(page, template.render(D=view, RADAR=_radar_display(records[cc])))
118:         outputs.append(page)
119:         log.info("wrote %s (%s, score=%s)", page.name, cc, view["decision"]["score"])
120: 
121:     for asset in ASSETS:
122:         src = root / "templates" / asset
123:         if src.exists():
124:             site_assets.copy_asset(asset, src, site)
125:     return outputs
126: 
127: 
128: def main() -> int:
129:     try:
130:         outputs = build_all()
131:     except Exception as exc:
132:         print(
133:             f"::error title=international macro dashboards failed::{exc}",
134:             flush=True,
135:         )
136:         log.exception("international macro dashboard build failed")
137:         return 1
138:     log.info("international macro dashboards: %d routes rendered", len(outputs))
139:     return 0
140: 
141: 
142: if __name__ == "__main__":
143:     logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
144:     raise SystemExit(main())
```

## COMPLETE CANDIDATE SOURCE: templates/_risk_radar_card.html.j2
```
1: {# ============================================================================
2:    SHARED Risk Radar card (.rrx) — the one redesigned alert used on BOTH the US
3:    Macro / US-Stocks pages (engine/risk_radar.py) AND the China / HK / Canada
4:    home-page Market-State boards (engine/risk_radar_intl.py). Import it:
5: 
6:        {% import "_risk_radar_card.html.j2" as rrc %}
7:        {{ rrc.risk_radar_card(rd, scares) }}
8: 
9:    It is self-contained (defines its own t()/help() so imported macros resolve),
10:    token-only with an inline --rc state accent so it renders identically in the
11:    page-macro, page-stocks, and china/hk/canada scopes. The matching CSS lives in
12:    _risk_radar_card.css.j2 (included by dashboard.html.j2 + _market_state.css.j2).
13:    ============================================================================ #}
14: {% macro help(en, zh='') -%}
15: <span class="help">?<span class="tip"><span class="l-en">{{ en }}</span><span class="l-zh">{{ zh if zh else en }}</span></span></span>
16: {%- endmacro %}
17: {% macro t(en, zh='') -%}
18: <span class="l-en">{{ en }}</span><span class="l-zh">{{ zh if zh else en }}</span>
19: {%- endmacro %}
20: {# plain-English name for a raw radar firing-leg code (US engine/risk_radar.py keys +
21:    the international engine/risk_radar_intl.py keys) so the evidence reads like English,
22:    not engine internals. An UNMAPPED key falls back to the raw slug, which is a Tier-1
23:    machine slug (DESIGN_DOCTRINE §2 Law 2) — the 7-market extension/FX block at the end
24:    was added when the five international dashboards started rendering this card and
25:    printed "ext_etf" at glance. Any new profile leg in engine/risk_radar_intl.py needs a
26:    row here. #}
27: {% macro rr_leg(leg) -%}
28: {%- set m = {
29:   'credit_oas_roc':   ('HY credit spreads widening','高收益利差走阔'),
30:   'credit_hyg_tlt':   ('HY bonds lagging Treasuries','高收益债跑输国债'),
31:   'rates_move':       ('Bond-market volatility (MOVE)','债市波动率（MOVE）'),
32:   'rates_realrate':   ('Real yields jumping','实际利率跳升'),
33:   'bubble_ext':       ('S&P trend extension vs 200-day','标普相对200日线趋势延伸'),
34:   'bubble_leadership':('Narrow leadership (semis)','领涨过窄（半导体）'),
35:   'growth_defensives':('Defensives outperforming','防御股跑赢'),
36:   'growth_cyc_def':   ('Cyclicals fading vs defensives','周期股弱于防御'),
37:   'vol_term':         ('VIX term-structure stress','VIX 期限结构紧张'),
38:   'vol_putcall':      ('Put/call skew','认沽/认购偏斜'),
39:   'vol_gex':          ('Dealer gamma (GEX)','做市商 Gamma'),
40:   'global_breadth':   ('Global breadth < 200-day (C3)','全球广度跌破200日（C3）'),
41:   'us_rate_2y':       ('US 2-year yield jump','美债2年利率跳升'),
42:   'us_rate_10y':      ('US 10-year yield jump','美债10年利率跳升'),
43:   'us_real_rate':     ('US real yield jump','美债实际利率跳升'),
44:   'us_cn_diff':       ('US–China yield gap widening','中美利差走阔'),
45:   'usd_cnh':          ('Yuan depreciation (USD/CNH)','人民币贬值'),
46:   'usd_strength':     ('US dollar strength','美元走强'),
47:   'cn_breadth':       ('A-share breadth < 200-day','A股广度跌破200日'),
48:   'ca_breadth':       ('TSX breadth < 200-day','多指广度跌破200日'),
49:   'ext_idx':          ('Index stretched vs 200-day','指数超买（>200日线）'),
50:   'ext_etf':          ('Market ETF stretched vs 200-day','市场ETF超买（>200日线）'),
51:   'jpy_depreciation': ('Yen depreciation','日元贬值'),
52:   'krw_depreciation': ('Won depreciation','韩元贬值'),
53:   'eur_depreciation': ('Euro depreciation','欧元贬值'),
54:   'gbp_depreciation': ('Sterling depreciation','英镑贬值'),
55:   'inr_depreciation': ('Rupee depreciation','卢比贬值'),
56:   'twd_depreciation': ('Taiwan dollar depreciation','新台币贬值'),
57:   'aud_depreciation': ('Australian dollar depreciation','澳元贬值'),
58: } -%}{%- set p = m.get(leg, (leg, leg)) -%}{{ t(p[0], p[1]) }}
59: {%- endmacro %}
60: {# A firing leg's percentile rank, rendered per language. Two defects this fixes, both
61:    shipped live on the five international dashboards (the only surface that shows the
62:    Leading row — the US #dlg-risk and the country dialogs both hide .rrx-ev):
63:      1. the suffix was a hard-coded "th", so a rank ending in 1/2/3 printed "73th"
64:         (euro_area.html) and "21th"; 11/12/13 still take "th".
65:      2. the whole token was language-invariant, so the ZH view read "73th" — an English
66:         ordinal dropped into Chinese copy (DESIGN_DOCTRINE §5.5). ZH takes the shape the
67:         rest of the site uses for a rank (第N百分位 / N 分位).
68:    Absent-safe: a leg with no pctile renders nothing rather than raising on Undefined. #}
69: {% macro rr_pctile(p) -%}
70: {%- if p is not none -%}
71: {%- set n = (p * 100) | round | int -%}
72: {%- set _t = n % 100 -%}{%- set _u = n % 10 -%}
73: {%- set sfx = 'th' if (_t > 10 and _t < 14) else ('st' if _u == 1 else ('nd' if _u == 2 else ('rd' if _u == 3 else 'th'))) -%}
74: <span class="l-en">{{ n }}{{ sfx }}</span><span class="l-zh">第{{ n }}百分位</span>
75: {%- endif -%}
76: {%- endmacro %}
77: {# The card itself. Built only from a radar (rd = market_state.radar) + its scares.
78:    Replaces the old cramped "Pullback odds · 5d.. 10d.. 21d.." text run with an
79:    escalating odds ramp drawn against the normal base rate, a state-coloured header,
80:    compact threat meters + plain-English evidence, and the action line. #}
81: {% macro risk_radar_card(rd, scares=none, show_threats=true) -%}
82: {%- set _q = rd.composition if rd.composition is defined else none -%}
83: {%- set _unreviewed = (rd.authority and rd.authority.reason == 'construction_not_promoted') or (_q and _q.calibration_status == 'unreviewed_corrected_construction') -%}
84: {%- set _unknown = _unreviewed and (_q is not mapping or _q.score_current is not sameas true or _q.status not in ['COMPLETE', 'PARTIAL']) -%}
85: {%- set _partial = not _unknown and _q and _q.status == 'PARTIAL' -%}
86: {%- set _limited = _unknown or _partial or _unreviewed -%}
87: {%- set rc = 'var(--muted)' if _limited else 'var(--act)' if rd.state=='risk-off' else ('var(--orange)' if rd.state=='elevated' else ('var(--warn)' if rd.state=='caution' else ('var(--info)' if rd.state=='watch' else 'var(--ok)'))) -%}
88: {#- icon ladder (RRX2 WA-1): 👀 retired; watch shows 🌤️ when recovery panel is receding else 📡.
89:    Truthiness-only on rd.recovery.receding — never `is not none` (crashes on missing keys, Jinja codebase law). -#}
90: {%- set _rec_receding = rd.recovery and rd.recovery.present and rd.recovery.receding -%}
91: {%- set ic = '—' if _limited else '🛑' if rd.state=='risk-off' else ('🚨' if rd.state=='elevated' else ('⚠️' if rd.state=='caution' else ('🌤️' if (rd.state=='watch' and _rec_receding) else ('📡' if rd.state=='watch' else '✅')))) -%}
92: {#- Optional numeric fields are guarded `is defined and is not none`, never `is not none`
93:    alone: in Jinja a MISSING key is Undefined, and `Undefined is not none` evaluates TRUE, so
94:    the guard passes and the arithmetic behind it raises UndefinedError — taking the whole page
95:    with it. `_radar_to_rd` always emits every key, so this is unreachable in production today;
96:    it is the trap tests/test_risk_radar_dlg_partial.py exists to pin, and the reason the dialog
97:    partial has to sniff `r.dd21 is defined` before it dares embed this card at all. -#}
98: {%- set base = rd.dd_base if (rd.dd_base and rd.dd_base.h21 is defined and rd.dd_base.h21 is not none) else {'h5':0.036,'h10':0.086,'h21':0.178} -%}
99: {%- set hmax = (rd.dd21 / 0.82) if (rd.dd21 is defined and rd.dd21 is not none and rd.dd21 > 0) else 0.25 -%}
100: <div class="rrx rrx-{{ 'unavailable' if _unknown else ('partial' if _partial else ('descriptive' if _unreviewed else rd.state)) }}{{ ' rrx-loud' if rd.is_loud }}" style="--rc:{{ rc }}">
101:   {# .rrx-main / .rrx-side are display:contents by default (no layout change on the China/HK/
102:      Canada/stocks cards); only the macro front-page promotes them to a 2-column banner. #}
103:   <div class="rrx-main">
104:   <div class="rrx-hd">
105:     <span class="rrx-ic">{{ ic }}</span>
106:     <div class="rrx-id">
107:       <div class="rrx-ttl">{{ t('Risk Radar','风险雷达') }}
108:         <span class="rrx-badge">{{ t('Reading unavailable','读数暂缺') if _unknown else (t('Partial reading','输入不完整') if _partial else (t('Descriptive reading','描述性读数') if _unreviewed else t(rd.state|upper, rd.state_zh))) }}{% if rd.top_score is defined and rd.top_score is not none %} · {{ rd.top_score }}/100{% endif %}</span>
109:         {{ help('Descriptive input-based reading; not a calibrated forecast or sizing instruction.' if _unreviewed else 'Pullback-risk gauge. Use high readings to trim risk, not to pick stocks.', '输入驱动的描述性读数，并非经校准的预测或仓位指令。' if _unreviewed else '回撤风险仪表。高读数用于降风险，不用于选股。') }}
110:       </div>
111:       {% if rd.label_en %}<div class="rrx-dom">{{ t(rd.label_en, rd.label_zh) }}</div>{% endif %}
112:       {% if rd.authority and rd.state in ['watch','caution','elevated','risk-off'] %}
113:       <div class="rrx-authority{{ ' is-binding' if rd.binding else ' is-advisory' }}">
114:         {{ t(rd.authority.note_en, rd.authority.note_zh) }}
115:       </div>
116:       {% endif %}
117:       {% if _q %}
118:       <div class="rrx-authority is-advisory" data-composition-status="{{ _q.status }}">
119:         {{ t('Input coverage','输入覆盖') }}: {{ _q.members_available|default('—') }} / {{ _q.members_expected|default('—') }}.
120:         {% if _q.status != 'COMPLETE' %}{{ t('Some inputs unavailable.','部分输入暂缺。') }}{% endif %}
121:         {% if not _q.comparison_comparable %}{{ t('Recovery comparison unavailable.','复苏对比暂不可用。') }}{% endif %}
122:         <details><summary>{{ t('Data details','数据详情') }}</summary>
123:           <div>{{ t('Groups available','可用输入组') }}: {{ _q.groups_available|default('—') }} / {{ _q.groups_expected|default('—') }}.</div>
124:           {% for group in _q.groups %}
125:           <div>{% for code in group.expected %}{{ rr_leg(code) }}: {{ t('Available','可用') if code in group.present else t('Unavailable','暂缺') }}{{ '; ' if not loop.last }}{% endfor %}</div>
126:           {% endfor %}
127:           <div>{{ t('Availability does not establish freshness.','输入可用不代表来源及时。') }}</div>
128:         </details>
129:         {% if _q.calibration_status == 'unreviewed_corrected_construction' %}<div>{{ t('Forecast calibration under review.','预测校准待核验。') }}</div>{% endif %}
130:       </div>
131:       {% endif %}
132:       {% if rd.amp and rd.amp > 0 %}<div class="rrx-amp">▲ {{ t('Amplified','放大') }} — <span class="l-en">{{ rd.amp_flags_en|join(' · ') }}</span><span class="l-zh">{{ rd.amp_flags_zh|join(' · ') }}</span></div>{% endif %}
133:     </div>
134:     {% if rd.gross is defined and rd.gross is not none and rd.gross < 1 %}<div class="rrx-gross"><span class="gv">×{{ '%.2f'|format(rd.gross) }}</span><span class="gn">{{ t('gross','建议仓位') }}</span></div>{% endif %}
135:   </div>
136: 
137:   {% if rd.dd21 is defined and rd.dd21 is not none %}
138:   <div class="rrx-odds">
139:     <div class="rrx-odds-l">
140:       <div class="rrx-cap">{{ t('Pullback odds','回撤概率') }} <span class="rrx-cap-sub">{{ t('≥5% drop · measured vs normal','≥5% · 实测对比常态') }}</span></div>
141:       <div class="rrx-big">{{ (rd.dd21*100)|round|int }}<span class="pct">%</span><span class="rrx-hz">{{ t('within 21 days','21 日内') }}</span></div>
142:       <div class="rrx-vsn">{% if rd.dd_lift is not none %}<b>{{ rd.dd_lift }}×</b> {% endif %}{{ t('vs normal','对比常态') }} {{ (base.h21*100)|round|int }}%</div>
143:     </div>
144:     <div class="rrx-ramp">
145:       {%- set _d5 = rd.dd5 if rd.dd5 is defined else none -%}
146:       {%- set _d10 = rd.dd10 if rd.dd10 is defined else none -%}
147:       {% for h in [ ('5d','5日',_d5,base.h5), ('10d','10日',_d10,base.h10), ('21d','21日',rd.dd21,base.h21) ] %}
148:       {%- set odd = h[2] if h[2] is not none else 0 -%}
149:       {%- set bs = h[3] if h[3] is not none else 0 -%}
150:       <div class="rrx-col{{ ' is-hd' if loop.last }}">
151:         <span class="rrx-v">{{ (odd*100)|round|int }}%</span>
152:         <div class="rrx-tk">
153:           <div class="rrx-norm" style="height:{{ [(bs/hmax*100)|round|int, 2]|max }}%"></div>
154:           <div class="rrx-fill" style="height:{{ [(odd/hmax*100)|round|int, 6]|max }}%"></div>
155:         </div>
156:         <span class="rrx-hl">{{ t(h[0], h[1]) }}</span>
157:       </div>
158:       {% endfor %}
159:       <span class="rrx-leg"><span class="rrx-leg-n"></span>{{ t('normal','常态') }}</span>
160:     </div>
161:   </div>
162:   {% endif %}
163:   </div>{# /.rrx-main #}
164: 
165:   <div class="rrx-side">
166:   {# DE-ESCALATION panel (engine/risk_radar_recovery.py) — "risk has peaked / the risk-off may be
167:      ending". DISPLAY-ONLY: it never relaxes the radar's one-directional score ceiling. Shows the
168:      pullback-odds turn (peak → now) as a sparkline + the supportive-liquidity catalysts firing now
169:      (Fed net-liq/TGA, Fed cuts, PBoC easing, the global Fed+ECB+BoJ tide). Persists through the
170:      cool-down so the "it may be over soon" read stays visible after the loud alert fades. #}
171:   {% if rd.recovery and rd.recovery.present %}{% set rv = rd.recovery %}
172:   {%- set rvc = 'var(--ok)' if rv.receding else 'var(--info)' -%}
173:   <div class="rrx-rec{{ ' is-turn' if rv.turn_confirmed }}" style="--rvc:{{ rvc }}">
174:     <div class="rrx-rec-hd">
175:       <span class="rrx-rec-ar">{{ '↘' if rv.receding else '◔' }}</span>
176:       <span class="rrx-rec-ttl">{{ t(rv.headline_en, rv.headline_zh) }}</span>
177:       {% if rv.turn_confirmed %}<span class="rrx-rec-tag">{{ t('TURN','转向') }}</span>{% endif %}{% if rv.turn_confirmed_full %}<span class="rrx-rec-tag">{{ t('INTERNALS ✓','内部确认 ✓') }}</span>{% endif %}
178:       {{ help(rv.caveat_en, rv.caveat_zh) }}
179:     </div>
180:     <div class="rrx-rec-mid">
181:       {% if rv.spark_pts %}
182:       <svg class="rrx-rec-spark" viewBox="0 0 {{ rv.spark_w }} {{ rv.spark_h }}" preserveAspectRatio="none" aria-hidden="true">
183:         <polyline points="{{ rv.spark_pts }}" fill="none" stroke="var(--rvc)" stroke-width="1.4" stroke-linejoin="round" stroke-linecap="round"/>
184:         {% if rv.spark_peak %}<circle class="pk" cx="{{ rv.spark_peak.x }}" cy="{{ rv.spark_peak.y }}" r="1.6"/>{% endif %}
185:         {% if rv.spark_last %}<circle class="lx" cx="{{ rv.spark_last.x }}" cy="{{ rv.spark_last.y }}" r="2.1"/>{% endif %}
186:       </svg>
187:       {% endif %}
188:       <span class="rrx-rec-sub">{{ t(rv.sub_en, rv.sub_zh) }}</span>
189:     </div>
190:     {% if rv.catalysts %}
191:     <div class="rrx-rec-cats">
192:       {#- RRX2 WA-2: row names WHO (Central banks); chips name WHAT — kills "Liquidity: Fed liquidity expanding" redundancy -#}
193:       <span class="rrx-rec-k">{{ t('Central banks','央行') }}</span>
194:       {% for c in rv.catalysts %}<span class="rrx-rec-chip{{ ' fresh' if c.fresh }}">{{ c.icon }} {{ t(c.label_en, c.label_zh) }}{{ help(c.detail_en, c.detail_zh) }}</span>{% endfor %}
195:     </div>
196:     {#- RLT-R5: Liquidity salience line — measured odds edge from LIQUIDITY_LADDER.
197:        Renders when fed_netliq catalyst is present AND carries salience_en.
198:        Display-only, glance tier. 'backtested' not 'validated' (CI guard). -#}
199:     {%- set _netliq_cat = rv.catalysts | selectattr('key', 'equalto', 'fed_netliq') | first | default(none) -%}
200:     {%- if _netliq_cat and _netliq_cat.salience_en %}
201:     <div class="rrx-rec-sal">
202:       <span class="l-en">{{ _netliq_cat.salience_en }}</span>
203:       <span class="l-zh">{{ _netliq_cat.salience_zh }}</span>
204:     </div>
205:     {%- endif %}
206:     {% else %}
207:     <div class="rrx-rec-cats none">{{ t('No liquidity catalyst yet — risk easing on its own; watch for a policy / liquidity turn to confirm.','尚无流动性催化 — 风险自行回落；留意政策／流动性转向以确认。') }}</div>
208:     {% endif %}
209:     {#- Market-INTERNAL confirmation channel (engine/risk_radar_market_catalysts.py, W1) — the
210:        second leg of the two-channel turn read (RRX masterplan §4A). US radar only (the intl
211:        payloads carry market=None by scoping). ACCRUING: forward-graded on the rebound ruler
212:        (risk_radar_recovery_audit) before it is ever trusted; the fired chips are context, not
213:        an all-clear. Old artifacts lack rv.market entirely -> this block renders NOTHING (the
214:        whitespace-control below keeps the no-market output byte-identical to the prior card).
215:        RRX2 WA: channel field added to chips — filter to channel=='internals' (C1–C7) so new
216:        mood/tape chips never appear in this row. Old artifacts without channel fall through
217:        selectattr gracefully (undefined channel = not equal to 'internals' = excluded from filter,
218:        so old artifacts render no internals chips here; new artifacts filter correctly). -#}
219:     {%- if rv.market and rv.market.chips %}
220:     {%- set internals_chips = rv.market.chips | selectattr('channel', 'defined') | selectattr('channel', 'equalto', 'internals') | list %}
221:     {#- Legacy fallback: old artifacts have no 'channel' key; treat ALL chips as internals in that case -#}
222:     {%- set legacy_chips = rv.market.chips | rejectattr('channel', 'defined') | list %}
223:     {%- set fired_internals = (internals_chips if internals_chips else legacy_chips) | selectattr('fired') | list %}
224:     <div class="rrx-rec-cats">
225:       <span class="rrx-rec-k">{{ t('Internals','市场内部') }}{{ help('Market-internal confirmation chips (breadth thrusts, follow-through, capitulation-resolution, credit rollover). Accruing — every read is forward-graded before the channel is trusted; not an all-clear.','市场内部确认信号（广度推进、放量确认、恐慌解除、信用利差回落）。积累中 — 每次读取均做前瞻评分后方可信任；并非解除警报。') }}</span>
226:       {% if fired_internals %}{% for c in fired_internals %}<span class="rrx-rec-chip{{ ' fresh' if c.fresh }}">{{ t(c.label_en, c.label_zh) }}</span>{% endfor %}
227:       {% else %}<span class="rrx-rec-chip">{{ t('no internal confirmation yet','尚无内部确认') }}</span>{% endif %}
228:       {% if rv.market.veto and rv.market.veto.active %}<span class="rrx-rec-chip">⚠ {{ t('vol still unstable — turn not trusted','波动仍未稳定 — 转向暂不可信') }}</span>{% endif %}
229:     </div>
230:     {#- RRX2 WA-3: drivers line ("what faded / still warm") — from rv.drivers injected by trajectory.
231:        Absent on old artifacts (no drivers key) → render nothing. -#}
232:     {%- if rv.drivers %}
233:     {%- set faded = rv.drivers.faded if rv.drivers.faded else [] %}
234:     {%- set warm = rv.drivers.warm if rv.drivers.warm else [] %}
235:     {%- if faded or warm %}
236:     <div class="rrx-rec-drv">
237:       {%- if faded %}<span class="l-en">What faded: {% for d in faded %}{% if not loop.first %} · {% endif %}{{ d.label_en }} {{ d.peak|round|int }}→{{ d.now|round|int }}{% endfor %}</span><span class="l-zh">已消退：{% for d in faded %}{% if not loop.first %} · {% endif %}{{ d.label_zh }} {{ d.peak|round|int }}→{{ d.now|round|int }}{% endfor %}</span>{% endif %}
238:       {%- if warm %}<span class="l-en">{{ ' — still warm: ' if faded else 'Still warm: ' }}{% for d in warm %}{% if not loop.first %} · {% endif %}{{ d.label_en }} {{ d.now|round|int }}{% endfor %}</span><span class="l-zh">{{ ' — 仍处高温：' if faded else '仍处高温：' }}{% for d in warm %}{% if not loop.first %} · {% endif %}{{ d.label_zh }} {{ d.now|round|int }}{% endfor %}</span>{% endif %}
239:     </div>
240:     {%- endif %}
241:     {%- endif %}
242:     {#- RRX2 WA-4: Mood channel (C9–C11: NAAIM, FRBSF DNSI, COT ES). US radar only (rv.market).
243:        Intl payloads: rv.market is None → this block is never reached.
244:        Old artifacts without channel field: internals_chips and legacy_chips logic above handles
245:        them; mood_chips below will be empty (no chip has channel='mood') → row suppressed. -#}
246:     {%- set mood_chips = rv.market.chips | selectattr('channel', 'defined') | selectattr('channel', 'equalto', 'mood') | list %}
247:     {%- if mood_chips %}
248:     {%- set fired_mood = mood_chips | selectattr('fired') | list %}
249:     <div class="rrx-rec-cats">
250:       <span class="rrx-rec-k">{{ t('Mood','情绪') }}{{ help('Accruing — forward-graded on the rebound ruler before the channel is trusted; not an all-clear.','积累中 — 在信任该渠道前均做前瞻评分；并非解除警报。') }}</span>
251:       {% if fired_mood %}{% for c in fired_mood %}<span class="rrx-rec-chip{{ ' fresh' if c.fresh }}">{{ t(c.label_en, c.label_zh) }}</span>{% endfor %}
252:       {% else %}<span class="rrx-rec-chip muted">{{ t('no signal yet','尚无信号') }}</span>{% endif %}
253:     </div>
254:     {%- endif %}
255:     {#- RRX2 WA-4: Tape channel (C12: fast reclaim / V-recovery) + morphology label. -#}
256:     {%- set tape_chips = rv.market.chips | selectattr('channel', 'defined') | selectattr('channel', 'equalto', 'tape') | list %}
257:     {%- if tape_chips %}
258:     {%- set fired_tape = tape_chips | selectattr('fired') | list %}
259:     <div class="rrx-rec-cats">
260:       <span class="rrx-rec-k">{{ t('Tape','盘面') }}{{ help('Accruing — forward-graded on the rebound ruler before the channel is trusted; not an all-clear.','积累中 — 在信任该渠道前均做前瞻评分；并非解除警报。') }}</span>
261:       {% if fired_tape %}{% for c in fired_tape %}<span class="rrx-rec-chip{{ ' fresh' if c.fresh }}">{{ t(c.label_en, c.label_zh) }}</span>{% endfor %}
262:       {% else %}<span class="rrx-rec-chip muted">{{ t('no signal yet','尚无信号') }}</span>{% endif %}
263:     </div>
264:     {#- Morphology label: one line explaining the recovery shape, from rv.market.morphology.
265:        Absent on old artifacts (no morphology key) → render nothing. -#}
266:     {%- if rv.market.morphology %}
267:     {%- set mph = rv.market.morphology %}
268:     <div class="rrx-rec-drv">{{ t(mph.detail_en, mph.detail_zh) }}</div>
269:     {%- endif %}
270:     {%- endif %}
271:     {%- endif %}
272:     {% if rv.do_en %}<div class="rrx-rec-do"><span class="rrx-rec-do-k">{{ t('Do','应对') }}</span>{{ t(rv.do_en, rv.do_zh) }}</div>{% endif %}
273:   </div>
274:   {% endif %}
275:   {% if scares %}
276:   {% if show_threats %}
277:   <div class="rrx-threats">
278:     {% for s in scares %}{% if s.score is not none %}
279:     {%- set sb = 'var(--act)' if s.band=='risk-off' else ('var(--orange)' if s.band=='elevated' else ('var(--warn)' if s.band=='caution' else ('var(--info)' if s.band=='watch' else 'var(--muted)'))) -%}
280:     {%- set dom = (s.label_en == rd.label_en) -%}
281:     {%- set dim = (s.tier == 'B') -%}
282:     <span class="rrx-th{{ ' dom' if dom }}{{ ' dim' if dim }}" style="--sb:{{ sb }}">
283:       <span class="rrx-th-n">{{ t(s.label_en, s.label_zh) }}</span>
284:       <span class="rrx-meter">{% for i in range(10) %}<i class="{{ 'on' if i < (s.score/10)|round(0,'floor')|int }}"></i>{% endfor %}</span>
285:       <b class="rrx-th-s">{{ s.score|round|int }}</b>{% if dim %}<span class="rrx-tag">{{ t('display','仅展示') }}</span>{% endif %}
286:     </span>
287:     {% endif %}{% endfor %}
288:   </div>
289:   {% endif %}{# /show_threats — the chip strip only; the Leading-evidence line below
290:      stays visible even when the host dedupes the strip against its own scare ladder #}
291:   {% for s in scares %}{% if s.label_en == rd.label_en and s.firing_legs %}
292:   <div class="rrx-ev"><span class="rrx-ev-k">{{ t('Leading','领先信号') }}</span>{% for l in s.firing_legs[:2] %}{% if not loop.first %} · {% endif %}{{ rr_leg(l.leg) }} <span class="rrx-ev-p">{{ rr_pctile(l.pctile if (l.pctile is defined and l.pctile is not none) else none) }}{% if l.confirmed %} ✓{% endif %}</span>{% endfor %}</div>
293:   {% endif %}{% endfor %}
294:   {% endif %}
295: 
296:   {# Stance on EVERY state, not only the loud ones (DESIGN_DOCTRINE Law 1 — "a panel that
297:      shows a state with no stance makes the user do the analyst's job"; "watch — don't
298:      chase" is a complete, honest stance). The old gate meant the calm and watch cards
299:      shipped with no action line at all: japan.html (watch), south_korea.html and
300:      india.html (calm) all rendered the state and the odds ramp and then stopped.
301:      The wording is the ENGINE's own calm/watch stance (`_RADAR_DO` in
302:      engine/market_state.py) — nothing is invented here; an empty do_en still renders
303:      nothing. This does not grant authority: the current `rd.authority` block above still
304:      distinguishes advisory sizing from a binding, evidence-gated override. The US
305:      #dlg-risk and country dialogs hide .rrx-do in CSS because their headline carries the
306:      same stance, so this reaches only the international boards that had none. #}
307:   {% if rd.do_en %}
308:   <div class="rrx-do"><span class="rrx-do-k">{{ t('Do','应对') }}</span>{{ t(rd.do_en, rd.do_zh) }}</div>
309:   {% endif %}
310: 
311:   {# Election-cycle context (US radar only; engine/election_cycle.py) — a calendar MODULATOR,
312:      never an alert originator. Lens content law (memory hover-popup-doctrine): the tip body
313:      carries the plain stat + slice only (Tier-2 word budget); the machine receipt (n / p≈ /
314:      the never-alarms rule) rides the data-tip-rc line that Lens renders in mono under a
315:      dashed perforation. The caveat's dollar-folk-story debunk stays on Tier-3 surfaces. #}
316:   {% if rd.cycle and rd.cycle.show %}{% set cy = rd.cycle %}
317:   <div class="rrx-cyc">
318:     <span class="rrx-cyc-k">{{ t(cy.label_en, cy.label_zh) }}{% if cy.in_drawdown_window %} · {{ t('Apr–Oct window','4–10月窗口') }}{% endif %}</span><button class="lens-q" type="button" aria-label="Explain" data-lens-kind="record" data-tip-en="{{ cy.stat_en }} {{ cy.slice_en }}" data-tip-zh="{{ cy.stat_zh }} {{ cy.slice_zh }}" data-tip-rc-en="8 midterm cases · weak edge (p≈.09) · calendar adjusts sizing only — never raises an alarm" data-tip-rc-zh="8 个中期年样本 · 优势较弱（p≈.09）· 日历仅微调仓位，绝不单独报警">?</button>
319:     {% if cy.modulation and cy.modulation.gross_applied %}<span class="rrx-cyc-tag">{{ t('sizing prior only','仅仓位先验') }}</span>{% endif %}
320:     {% if cy.trough_window_en %}<div class="rrx-cyc-sub">{{ t(cy.trough_window_en, cy.trough_window_zh) }}</div>{% endif %}
321:     {% if cy.sector_bias %}{% set sb = cy.sector_bias %}
322:     <div class="rrx-cyc-sec">{{ t('Favor','偏好') }} {% for f in sb.favor %}{% if not loop.first %} · {% endif %}{{ f.ticker }}{% endfor %} · {{ t('trim','减持') }} {% for a in sb.avoid %}{% if not loop.first %} · {% endif %}{{ a.ticker }}{% endfor %}</div>
323:     {% endif %}
324:   </div>
325:   {% endif %}
326: 
327:   {# RC-R11 washout counter-read (engine/oracle/washout_counterread.py) — a display-tier CONTEXT
328:      chip beside the banner, never an alert originator and never a banner suppressor. Appears only
329:      when a growth-scare extreme co-occurs with an index/cohort depth extreme (the growth scare
330:      peaked on the exact 2026-06-26 Mag-7 bottom). The honest two-sided caveat + the depth detail
331:      live in the tooltip so the chip can't overclaim. #}
332:   {% if rd.counterread and rd.counterread.show %}{% set wc = rd.counterread %}
333:   <div class="rrx-cyc rrx-washout">
334:     <span class="rrx-cyc-k">🌀 {{ t('Capitulation-zone reading — two-sided','投降区读数 — 双向') }}</span>{{ help(wc.message_en, wc.message_zh) }}
335:     <span class="rrx-cyc-tag">{{ t('context only','仅上下文') }}</span>
336:   </div>
337:   {% endif %}
338: 
339:   {# The self-audit line that used to live here is MERGED into the one track-record row at
340:      the end of this card (see the "ONE honesty line" block below) — DESIGN_DOCTRINE Law 4,
341:      one footnote per panel, merge never stack. #}
342:   {# ── Track record (forward-ledger scorecard, data/risk_radar/scorecard.json).
343:      Display-only context accrual — deterministic math over graded ledger rows.
344:      Glance tier: ONE plain-word line. Tier-2: per-scare (top 3 by n) +
345:      watch/caution + recovery detail inside the help() tooltip, rendered from
346:      the live by_sc_y1, wc_y1, and y1-window recovery data.
347:      Guards: rd.track must be defined AND truthy
348:      (older renders / first build before engine builder runs = zero output). #}
349:   {# ── Contagion pressure strip (CGL W1 display lane, 2026-07-17).
350:      Resolves the per-market block from:
351:        1. rd.contagion  (engine sets this directly on the radar dict)
352:        2. CGL.pressure[rd.market] (global artifact, intl radars)
353:      Guard: if neither is present the card is byte-identical to today.
354:      Level map: low→Low/低, moderate→Building/升温, high→High/高 (plain, no jargon).
355:      Stance: high pressure appends "Watch — don't chase" (Law 1, Design Doctrine).
356:      All receipts (linkage weight, drawdown, 10-session return) live in the help()
357:      tooltip only — never at glance tier. Shadow-vs-incumbent divergence disclosed
358:      honestly when it exists. #}
359:   {%- set _cgl_blk = none -%}
360:   {%- if rd.contagion -%}
361:     {%- set _cgl_blk = rd.contagion -%}
362:   {%- endif -%}
363:   {%- if _cgl_blk %}
364:   {#- level → glance word -#}
365:   {%- set _cgl_lv = _cgl_blk.level if _cgl_blk.level is defined else none -%}
366:   {%- set _cgl_lv_en = 'High' if _cgl_lv == 'high' else ('Building' if _cgl_lv == 'moderate' else 'Low') -%}
367:   {%- set _cgl_lv_zh = '高' if _cgl_lv == 'high' else ('升温' if _cgl_lv == 'moderate' else '低') -%}
368:   {%- set _cgl_chip = 'warn' if _cgl_lv == 'high' else ('caut' if _cgl_lv == 'moderate' else 'ok') -%}
369:   {#- stance for high level -#}
370:   {%- set _cgl_stance_en = ' — watch, don\'t chase' if _cgl_lv == 'high' else '' -%}
371:   {%- set _cgl_stance_zh = ' — 观望，勿追入' if _cgl_lv == 'high' else '' -%}
372:   {#- top-1 exporter chip -#}
373:   {%- set _cgl_top = (_cgl_blk.top_exporters[0]) if (_cgl_blk.top_exporters is defined and _cgl_blk.top_exporters) else none -%}
374:   {#- build Tier-2 tooltip (receipts, exporters, shadow divergence) -#}
375:   {%- set _ns2 = namespace(tip_en='', tip_zh='') -%}
376:   {%- if _cgl_blk.top_exporters is defined and _cgl_blk.top_exporters -%}
377:     {%- for exp in _cgl_blk.top_exporters[:3] -%}
378:       {%- set _wt = (exp.weight * 100) | round(1) | string if exp.weight is defined and exp.weight is not none else '—' -%}
379:       {%- set _dd = ((exp.dd21 * 100) | round(1) | string ~ '%') if exp.dd21 is defined and exp.dd21 is not none else '—' -%}
380:       {%- set _r10 = ((exp.ret10 * 100) | round(1) | string ~ '%') if exp.ret10 is defined and exp.ret10 is not none else '—' -%}
381:       {%- set _nm_en = exp.name_en if exp.name_en is defined else (exp.market if exp.market is defined else '—') -%}
382:       {%- set _nm_zh = exp.name_zh if (exp.name_zh is defined and exp.name_zh) else _nm_en -%}
383:       {%- set _ns2.tip_en = _ns2.tip_en ~ (' | ' if _ns2.tip_en else '') ~ _nm_en ~ ': connection ' ~ _wt ~ '%, ' ~ _dd ~ ' off its 21-day high, ' ~ _r10 ~ ' in 10 sessions' -%}
384:       {%- set _ns2.tip_zh = _ns2.tip_zh ~ ('；' if _ns2.tip_zh else '') ~ _nm_zh ~ '：关联' ~ _wt ~ '%，近21日高点回落' ~ _dd ~ '，近10日' ~ _r10 -%}
385:     {%- endfor -%}
386:   {%- endif -%}
387:   {#- shadow divergence disclosure -#}
388:   {%- set _cgl_shadow = _cgl_blk.shadow_state if _cgl_blk.shadow_state is defined else none -%}
389:   {%- set _cgl_incumbent = _cgl_blk.incumbent_state if _cgl_blk.incumbent_state is defined else none -%}
390:   {%- set _cgl_show_shadow = _cgl_shadow and _cgl_incumbent and _cgl_shadow != _cgl_incumbent -%}
391:   {#- ZH state vocab (mirrors _RADAR_ZH in engine/market_state.py) -#}
392:   {%- set _cgl_state_zh_map = {'calm':'平静','watch':'观察','caution':'警戒','elevated':'升高','risk-off':'避险'} -%}
393:   {%- if _cgl_show_shadow -%}
394:     {%- set _shd_zh = _cgl_state_zh_map.get(_cgl_shadow, _cgl_shadow) -%}
395:     {%- set _ns2.tip_en = _ns2.tip_en ~ (' | ' if _ns2.tip_en else '') ~ 'With imported pressure applied this radar would read ' ~ _cgl_shadow ~ ' — shown for transparency, not yet moving the live state.' -%}
396:     {%- set _ns2.tip_zh = _ns2.tip_zh ~ ('；' if _ns2.tip_zh else '') ~ '叠加海外传导压力后，本雷达将显示' ~ _shd_zh ~ ' — 仅作透明展示，尚未影响正式状态。' -%}
397:   {%- endif -%}
398:   {#- render strip — one row matching .rrx-cyc idiom (compact, no extra CSS needed) -#}
399:   <div class="rrx-cyc rrx-cgl">
400:     <span class="rrx-cyc-k">{{ t('Overseas pressure','境外传导') }}</span>
401:     <span class="chip {{ _cgl_chip }}" style="font-size:10px;padding:1px 6px;">{{ t(_cgl_lv_en, _cgl_lv_zh) }}</span>
402:     {%- if _cgl_blk.line_en is defined and _cgl_blk.line_en %}
403:     <span class="l-en">{{ _cgl_blk.line_en }}{{ _cgl_stance_en }}</span>
404:     <span class="l-zh">{{ _cgl_blk.line_zh if (_cgl_blk.line_zh is defined and _cgl_blk.line_zh) else _cgl_blk.line_en }}{{ _cgl_stance_zh }}</span>
405:     {%- endif %}
406:     {%- if _cgl_top %}
407:     <span class="rrx-rec-chip">{{ t((_cgl_top.name_en if _cgl_top.name_en is defined else (_cgl_top.market if _cgl_top.market is defined else '—')), (_cgl_top.name_zh if (_cgl_top.name_zh is defined and _cgl_top.name_zh) else (_cgl_top.name_en if _cgl_top.name_en is defined else '—'))) }}</span>
408:     {%- endif %}
409:     {%- if _ns2.tip_en %}
410:     {{ help(_ns2.tip_en, _ns2.tip_zh) }}
411:     {%- endif %}
412:     {%- if _cgl_blk.stale is defined and _cgl_blk.stale and _cgl_blk.built_date is defined and _cgl_blk.built_date %}
413:     <span class="muted" style="font-size:9.5px;"><span class="l-en">as of {{ _cgl_blk.built_date }}</span><span class="l-zh">截至 {{ _cgl_blk.built_date }}</span></span>
414:     {%- endif %}
415:   </div>
416:   {%- endif %}
417:   {# ── FX context strip (MSX-1, 2026-07-18, Tier-2 placement inside radar dialog).
418:      Source: rd.fx_context attached by build_china/build_hk post-transform (mirrors
419:      CGL pattern). Guard: entire block absent when rd.fx_context is not present —
420:      no data renders nothing. Two row-pairs: (1) CNH pressure plain-word; (2) dollar
421:      direction chip. Dual-span l-en/l-zh idiom; never put translated text in title=.
422:      Trap: jinja set-in-for is LOOP-LOCAL; never <svg><text> spans. #}
423:   {%- if rd.fx_context is defined and rd.fx_context -%}
424:   {%- set _fxc = rd.fx_context -%}
425:   {#- CNH basis → plain-word map -#}
426:   {%- set _cnh_st = _fxc.cnh_basis_state if _fxc.cnh_basis_state is defined else none -%}
427:   {%- set _cnh_en = 'Offshore yuan: outflow pressure' if _cnh_st == 'outflow_stress' else ('Offshore yuan: inflow bid' if _cnh_st == 'inflow' else 'Offshore yuan: no unusual pressure') -%}
428:   {%- set _cnh_zh = '离岸人民币：资金外流压力' if _cnh_st == 'outflow_stress' else ('离岸人民币：资金流入' if _cnh_st == 'inflow' else '离岸人民币：无异常压力') -%}
429:   {%- set _cnh_chip = 'warn' if _cnh_st == 'outflow_stress' else ('caut' if _cnh_st == 'inflow' else 'ok') -%}
430:   {%- set _cnh_chip_en = 'Stress' if _cnh_st == 'outflow_stress' else ('Inflow' if _cnh_st == 'inflow' else 'Normal') -%}
431:   {%- set _cnh_chip_zh = '压力' if _cnh_st == 'outflow_stress' else ('流入' if _cnh_st == 'inflow' else '正常') -%}
432:   {#- dollar direction → plain-word map -#}
433:   {%- set _usd = _fxc.usd_dir if _fxc.usd_dir is defined else none -%}
434:   {%- set _usd_en = 'Dollar rising — headwind for EM' if _usd == 'strengthening' else ('Dollar falling — tailwind for EM' if _usd == 'weakening' else 'Dollar: mixed') -%}
435:   {%- set _usd_zh = '美元走强 — 新兴市场逆风' if _usd == 'strengthening' else ('美元走弱 — 新兴市场顺风' if _usd == 'weakening' else '美元：方向混乱') -%}
436:   {%- set _usd_chip = 'warn' if _usd == 'strengthening' else ('ok' if _usd == 'weakening' else 'muted') -%}
437:   {%- set _usd_chip_en = 'Rising' if _usd == 'strengthening' else ('Falling' if _usd == 'weakening' else 'Mixed') -%}
438:   {%- set _usd_chip_zh = '走强' if _usd == 'strengthening' else ('走弱' if _usd == 'weakening' else '混合') -%}
439:   {#- row 1: CNH pressure -#}
440:   <div class="rrx-cyc rrx-fxc">
441:     <span class="rrx-cyc-k">{{ t('Yuan pressure','人民币压力') }}</span>
442:     <span class="chip {{ _cnh_chip }}" style="font-size:10px;padding:1px 6px;">{{ t(_cnh_chip_en, _cnh_chip_zh) }}</span>
443:     <span class="l-en">{{ _cnh_en }}</span><span class="l-zh">{{ _cnh_zh }}</span>
444:     {%- if _fxc.cnh_basis_bps is defined and _fxc.cnh_basis_bps is not none %}
445:     <span class="rrx-rec-chip">{{ '%.0f'|format(_fxc.cnh_basis_bps) }}bp</span>
446:     {%- endif %}
447:     {%- if _fxc.stale is defined and _fxc.stale and _fxc.built_date is defined and _fxc.built_date %}
448:     <span class="muted" style="font-size:9.5px;"><span class="l-en">as of {{ _fxc.built_date }}</span><span class="l-zh">截至 {{ _fxc.built_date }}</span></span>
449:     {%- endif %}
450:   </div>
451:   {#- row 2: dollar direction -#}
452:   <div class="rrx-cyc rrx-fxc">
453:     <span class="rrx-cyc-k">{{ t('Dollar','美元') }}</span>
454:     <span class="chip {{ _usd_chip }}" style="font-size:10px;padding:1px 6px;">{{ t(_usd_chip_en, _usd_chip_zh) }}</span>
455:     <span class="l-en">{{ _usd_en }}</span><span class="l-zh">{{ _usd_zh }}</span>
456:   </div>
457:   {%- endif %}
458: 
459:   {# ── Cross-asset concentration chip (CA-W3 display lane).
460:      Source: rd.cross_asset (set by build_site CA-W3 attach from data/regime/latest.json["cross_asset"]).
461:      Only renders for verdict 'concentrated' or 'converging' — silent for diversified/unknown.
462:      At rest: plain word only. Receipts (absorption pctile, cluster) in hover tooltip.
463:      Shadow escalated: appended to hover only, never at rest.
464:      Bilingual: l-en / l-zh via t() dual-span idiom. Display-only, never gates anything. #}
465:   {%- set _cax_blk = rd.cross_asset if (rd.cross_asset is defined and rd.cross_asset) else none -%}
466:   {%- set _cax_verdict = (_cax_blk.verdict if (_cax_blk and _cax_blk.verdict is defined) else none) -%}
467:   {%- if _cax_blk and _cax_verdict in ['concentrated', 'converging'] -%}
468:   {%- set _cax_en = 'Markets moving as one' if _cax_verdict == 'concentrated' else 'Markets syncing up' -%}
469:   {%- set _cax_zh = '多市场同涨同跌' if _cax_verdict == 'concentrated' else '市场联动升温' -%}
470:   {%- set _cax_pctile = _cax_blk.absorption_pctile if (_cax_blk.absorption_pctile is defined and _cax_blk.absorption_pctile is not none) else none -%}
471:   {%- set _cax_cluster = _cax_blk.dominant_cluster if (_cax_blk.dominant_cluster is defined and _cax_blk.dominant_cluster) else [] -%}
472:   {%- set _cax_shadow = _cax_blk.shadow_escalated if (_cax_blk.shadow_escalated is defined and _cax_blk.shadow_escalated) else false -%}
473:   {#- Build Tier-2 hover tooltip with receipts -#}
474:   {%- set _cax_tip_en = '' -%}
475:   {%- set _cax_tip_zh = '' -%}
476:   {%- if _cax_pctile is not none -%}
477:     {%- set _cax_tip_en = 'Absorption ' ~ (_cax_pctile * 100) | round(0) | int | string ~ 'th pctile (5y)' -%}
478:     {%- set _cax_tip_zh = '吸收率 ' ~ (_cax_pctile * 100) | round(0) | int | string ~ '分位（5年）' -%}
479:   {%- endif -%}
480:   {%- if _cax_cluster -%}
481:     {%- set _cax_tip_en = _cax_tip_en ~ (' · ' if _cax_tip_en else '') ~ 'Cluster: ' ~ _cax_cluster | join(', ') -%}
482:     {%- set _cax_tip_zh = _cax_tip_zh ~ ('；' if _cax_tip_zh else '') ~ '集群：' ~ _cax_cluster | join('、') -%}
483:   {%- endif -%}
484:   {%- if _cax_shadow -%}
485:     {%- set _cax_tip_en = _cax_tip_en ~ (' · ' if _cax_tip_en else '') ~ 'fragility test lane armed' -%}
486:     {%- set _cax_tip_zh = _cax_tip_zh ~ ('；' if _cax_tip_zh else '') ~ '脆弱性测试通道已触发' -%}
487:   {%- endif -%}
488:   <div class="rrx-cyc rrx-cax">
489:     <span class="rrx-cyc-k"><span class="l-en">{{ _cax_en }}</span><span class="l-zh">{{ _cax_zh }}</span></span>
490:     {%- if _cax_tip_en %}
491:     {{ help(_cax_tip_en, _cax_tip_zh) }}
492:     {%- endif %}
493:   </div>
494:   {%- endif %}
495: 
496:   {# ── ONE honesty line: this radar's own graded record (DESIGN_DOCTRINE Law 4 — one
497:      footnote per panel, MERGE never stack).
498:      Until 2026-08-11 this was TWO adjacent lines that said the same thing on a young
499:      ledger. Measured on the shipped international dashboards: japan.html and
500:      south_korea.html printed "🧾 Self-audit  accruing — grades begin once calls mature
501:      (~21 trading days)" immediately above "Graded calls accruing — check back once
502:      alerts mature (~21 trading days)"; euro_area / united_kingdom / india printed the
503:      same self-audit line above "Monitoring paused — ledger stale", which CONTRADICTS it
504:      at glance tier and leaks the internal word "ledger" (Law 2).
505:      One row now. Precedence: this market's own graded log (rd.forward_log, set by
506:      engine/risk_radar_intl_audit — intl radars only) -> the scorecard's past-year alert
507:      window (rd.track, data/risk_radar/scorecard.json) -> the plain accrual sentence.
508:      A log that has not been appended lately rides the SAME line as a plain-word clause.
509:      Class stays `.rrx-trk` so every existing scope keeps working unchanged: the US
510:      #dlg-risk hides the whole .rrx-side, the country dialogs hide .rrx-trk by name, and
511:      the .ms-front boards show it. Guards: with neither source present (older renders,
512:      first build before the scorecard exists) the card is byte-identical to before.
513:      Glance tier: ONE plain-word line. Tier-2: per-scare (top 3 by n) + watch/caution +
514:      recovery detail inside the help() tooltip, rendered from the live by_sc_y1, wc_y1
515:      and y1-window recovery data. #}
516:   {%- set _fl = rd.forward_log if rd.forward_log else none -%}
517:   {% if (rd.track is defined and rd.track) or _fl %}
518:   {%- set trk = rd.track if (rd.track is defined and rd.track) else {} -%}
519:   {%- set mon = trk.get('monitoring') if trk.get is defined else trk.monitoring if trk.monitoring is defined else {} -%}
520:   {%- set win_y1 = trk.get('windows', {}).get('y1', {}) if trk.get is defined else {} -%}
521:   {%- set al_y1 = win_y1.get('alerts', {}) if win_y1.get is defined else {} -%}
522:   {%- set wc_y1 = win_y1.get('watch_caution', {}) if win_y1.get is defined else {} -%}
523:   {%- set rv_y1 = win_y1.get('recovery') if win_y1.get is defined else none -%}
524:   {%- set by_sc_y1 = win_y1.get('by_scare', {}) if win_y1.get is defined else {} -%}
525:   {%- set hit_rate = al_y1.get('hit_rate') if al_y1.get is defined else none -%}
526:   {%- set al_tp = al_y1.get('tp', 0) if al_y1.get is defined else 0 -%}
527:   {%- set al_n = al_y1.get('n', 0) if al_y1.get is defined else 0 -%}
528:   {%- set log_fresh = mon.get('log_fresh', true) if mon.get is defined else true -%}
529:   {#- Build per-scare string for Tier-2 tooltip (top 3 scares by alert count, n>0). -#}
530:   {%- set _sc_map = {
531:     'credit_oas_roc':'HY credit spreads widening','credit_hyg_tlt':'HY bonds lagging Treasuries',
532:     'rates_move':'Bond-market vol (MOVE)','rates_realrate':'Real yields jumping',
533:     'bubble_ext':'S&P stretched','bubble_leadership':'Narrow leadership',
534:     'growth_defensives':'Defensives outperforming','growth_cyc_def':'Cyclicals fading',
535:     'vol_term':'VIX term-structure stress','vol_putcall':'Put/call skew','vol_gex':'Dealer gamma',
536:     'global_breadth':'Global breadth','us_rate_2y':'US 2y yield jump','us_rate_10y':'US 10y yield jump',
537:     'us_real_rate':'US real yield jump','us_cn_diff':'US–China yield gap','usd_cnh':'Yuan depreciation',
538:     'usd_strength':'Dollar strength','cn_breadth':'A-share breadth','ca_breadth':'TSX breadth'} -%}
539:   {%- set _sc_map_zh = {
540:     'credit_oas_roc':'高收益利差走阔','credit_hyg_tlt':'高收益债跑输国债',
541:     'rates_move':'债市波动率','rates_realrate':'实际利率跳升',
542:     'bubble_ext':'标普超买','bubble_leadership':'领涨过窄',
543:     'growth_defensives':'防御股跑赢','growth_cyc_def':'周期股弱于防御',
544:     'vol_term':'VIX期限结构紧张','vol_putcall':'认沽/认购偏斜','vol_gex':'做市商Gamma',
545:     'global_breadth':'全球广度','us_rate_2y':'美债2年利率','us_rate_10y':'美债10年利率',
546:     'us_real_rate':'美债实际利率','us_cn_diff':'中美利差走阔','usd_cnh':'人民币贬值',
547:     'usd_strength':'美元走强','cn_breadth':'A股广度','ca_breadth':'多指广度'} -%}
548:   {%- set _ns = namespace(sc_en='', sc_zh='', seen=0) -%}
549:   {%- for sk, sv in by_sc_y1.items() | sort(attribute='1.n', reverse=true) -%}
550:     {%- if _ns.seen < 3 and sv and sv.get('n', 0) > 0 -%}
551:       {%- set _label_en = _sc_map.get(sk, sk) -%}
552:       {%- set _label_zh = _sc_map_zh.get(sk, sk) -%}
553:       {%- set _ns.sc_en = _ns.sc_en ~ (' | ' if _ns.sc_en else '') ~ 'on ' ~ (sv.get('tp', 0)|string) ~ ' of ' ~ (sv.get('n', 0)|string) ~ ' ' ~ _label_en ~ ' days' -%}
554:       {%- set _ns.sc_zh = _ns.sc_zh ~ ('；' if _ns.sc_zh else '') ~ (sv.get('n', 0)|string) ~ ' 个' ~ _label_zh ~ '日中有 ' ~ (sv.get('tp', 0)|string) ~ ' 天' -%}
555:       {%- set _ns.seen = _ns.seen + 1 -%}
556:     {%- endif -%}
557:   {%- endfor -%}
558:   {%- set _fl_n = _fl.n_graded if (_fl and _fl.n_graded) else 0 -%}
559:   {%- set _lag = mon.get('last_logged_days_ago') if mon.get is defined else none -%}
560:   <div class="rrx-trk">
561:     <span class="rrx-audit-k">🧾 {{ t('Track record','往绩') }}</span>
562:     {%- if rd.authority and rd.authority.reason == 'construction_not_promoted' %}
563:     <span data-record-applicability="earlier-construction">{{ t('Earlier construction record; not current validation.','旧构造往绩；不构成当前读数的验证。') }}{% if _fl_n > 0 %} {{ _fl_n }} {{ t('graded','已评分') }}.{% endif %}</span>
564:     {%- elif _fl_n > 0 %}
565:     {#- this market's OWN graded log (intl radars). "not yet moving the verdict" replaces
566:         the old "display-only" chip — that phrase is banned glance-tier vocabulary
567:         (DESIGN_DOCTRINE Law 2, "display-tier / display context only"). -#}
568:     <span>{{ _fl_n }} {{ t('graded','已评分') }}{% if _fl.force_lift is defined and _fl.force_lift is not none %} · <b>{{ _fl.force_lift }}×</b> {{ t('vs base rate','对比基准') }}{% endif %} · {% if _fl.can_force %}{{ t('moving the verdict','参与定调') }} ✓{% else %}{{ t('not yet moving the verdict','尚未参与定调') }}{% endif %}</span>
569:     {%- elif hit_rate is not none %}
570:     {# Glance tier: "on N of M elevated days a ≥5% drop followed within a month (past year)" #}
571:     <span class="l-en">on {{ al_tp }} of {{ al_n }} elevated days in the past year, a ≥5% drop followed within a month</span><span class="l-zh">过去一年 {{ al_n }} 个警报日中有 {{ al_tp }} 天在一个月内出现 ≥5% 下跌</span>
572:     {%- elif al_n > 0 %}
573:     <span class="l-en">too few elevated alerts to judge yet — {{ al_n }} graded</span><span class="l-zh">已评分警报尚少，暂无定论 — {{ al_n }} 条</span>
574:     {%- else %}
575:     <span class="l-en">grading begins once these calls mature — about 21 trading days</span><span class="l-zh">这些判断成熟后开始评分 — 约21个交易日</span>
576:     {%- endif %}
577:     {%- if trk and not log_fresh %}
578:     {#- Staleness rides THIS line, in plain words. It used to REPLACE the sentence above
579:         with "Monitoring paused — ledger stale", which contradicted the self-audit line
580:         beside it and told the reader our monitoring had stopped when the log had simply
581:         not been appended for a few sessions. State the fact, not a verdict. -#}
582:     <span class="l-en">· no new entries {{ ('for ' ~ _lag ~ ' days') if (_lag is not none) else 'lately' }}</span><span class="l-zh">· {{ ('已 ' ~ _lag ~ ' 天') if (_lag is not none) else '近期' }}无新增记录</span>
583:     {%- endif %}
584:     {# Tier-2 detail in the help() tooltip: per-scare rows + watch/caution + recovery #}
585:     {{ help(
586:       'Past-year hit rate: '
587:         ~ (('on ' ~ (al_tp|string) ~ ' of ' ~ (al_n|string) ~ ' elevated days (' ~ ((hit_rate * 100)|round|int|string) ~ '%) a ≥5% drop followed within 21 days') if hit_rate is not none else 'too few graded alerts yet')
588:         ~ (' | by scare: ' ~ _ns.sc_en if _ns.sc_en else '')
589:         ~ ' (daily readings — consecutive days overlap)'
590:         ~ ' | Watch/caution: '
591:         ~ (('on ' ~ (wc_y1.get('tp', 0)|string) ~ ' of ' ~ (wc_y1.get('n', 0)|string) ~ ' watch/caution days a drop followed') if wc_y1.get is defined and wc_y1.get('n', 0) >= 5 else 'too few graded')
592:         ~ ' | Recovery: '
593:         ~ (((rv_y1.get('ok', 0)|string) ~ ' of ' ~ (rv_y1.get('n', 0)|string) ~ ' recovery calls were higher 21 days later') if rv_y1 is not none and rv_y1.get is defined and rv_y1.get('n', 0) >= 5 else 'too few graded'),
594:       '过去一年命中率：'
595:         ~ ((al_n|string) ~ ' 个警报日中有 ' ~ (al_tp|string) ~ ' 天（' ~ ((hit_rate * 100)|round|int|string) ~ '%）在21天内出现 ≥5% 下跌' if hit_rate is not none else '暂无足够评分记录')
596:         ~ ('；按类别：' ~ _ns.sc_zh if _ns.sc_zh else '')
597:         ~ '（按日读数——连续日期相互重叠）'
598:         ~ ' | 观察/谨慎：'
599:         ~ ((wc_y1.get('n', 0)|string) ~ ' 个观察/谨慎日中有 ' ~ (wc_y1.get('tp', 0)|string) ~ ' 天先于下跌' if wc_y1.get is defined and wc_y1.get('n', 0) >= 5 else '暂无足够评分')
600:         ~ ' | 修复信号：'
601:         ~ ((rv_y1.get('n', 0)|string) ~ ' 次中有 ' ~ (rv_y1.get('ok', 0)|string) ~ ' 次21天后上涨' if rv_y1 is not none and rv_y1.get is defined and rv_y1.get('n', 0) >= 5 else '暂无足够评分')
602:     ) }}
603:   </div>
604:   {% endif %}
605:   </div>{# /.rrx-side #}
606: </div>
607: {%- endmacro %}
```

## EXACT CHANGED CONTEXT: templates/baskets_desk.js
```diff
--- baseline/templates/baskets_desk.js
+++ candidate/templates/baskets_desk.js
@@ -524,51 +524,61 @@
     ${anCol('red',`🔻 ${L('Reduce / avoid','减仓 / 回避')}`,red,L('none','无'),rowReduce)}
     ${conflictedCol}
   </div>`;
   // MLC-W2b footnote: merge one sentence into the existing footnote (never stack a new one).
   // The footnote element is written by the Jinja host; we append here.
   // note is already an L() output (a bilingual l-en/l-zh span pair) — append it directly
   // inside a plain wrapper; do NOT esc() the span pair or re-wrap with L().
   try{
     const fn=document.getElementById('actnow-footnote');
     if(fn&&conflicted.length){
       const note=L(
         'Conflicted = in favour on its own read, but its sector view says Reduce.',
         '观点冲突 = 自身信号看好，但所属板块评级为减配。'
       );
       if(!fn.innerHTML.includes('actnow-conflict-note')){
         fn.insertAdjacentHTML('beforeend',`<span class="actnow-conflict-note">${note}</span>`);
       }
     }
   }catch(e){}
 }
 // sleeve-size chip (validated drawdown-control channel; payload-gated so only markets that
 // publish BASKETS.sleeve_chip — e.g. the curated China overview — render anything).
 function renderSleeveChip(){
   const host=document.getElementById('sleeve-chip'); if(!host) return;
   const sc=(typeof BASKETS!=='undefined'&&BASKETS)?BASKETS.sleeve_chip:null;
-  if(!sc||sc.sleeve_factor==null){ host.innerHTML=''; return; }
+  if(!sc){ host.innerHTML=''; return; }
+  if(sc.sleeve_status==='unavailable'||sc.sleeve_factor==null){
+    const explained=sc.sleeve_status==='unavailable';
+    const en=explained?(sc.label_en||'Sizing unavailable'):'Sizing unavailable';
+    const zh=explained?(sc.label_zh||'仓位建议暂缺'):'仓位建议暂缺';
+    host.innerHTML=`<div class="sleeve-chip" data-sleeve-status="unavailable" style="border-left:3px solid var(--muted)">
+      <span class="sl-main"><b>${L(esc(en),esc(zh))}</b></span>
+      <span class="sl-tag muted">${L('No current sizing instruction.','当前不提供仓位指令。')}</span>
+    </div>`;
+    return;
+  }
   const st=String(sc.radar_state||'').toLowerCase();
   const sev=/stress|risk_off|riskoff|high/.test(st)?'var(--down)':/caution|elevated|warn/.test(st)?'var(--warn)':'var(--muted)';
   host.innerHTML=`<div class="sleeve-chip" style="border-left:3px solid ${sev}" title="${esc((sc.passport&&sc.passport.note)||'')}">
     <span class="sl-main">🛰️ <b>${L(esc(sc.label_en||''),esc(sc.label_zh||sc.label_en||''))}</b></span>
     ${sc.dominant_driver_en?`<span class="muted sm">· ${L(esc(sc.dominant_driver_en),esc(sc.dominant_driver_zh||sc.dominant_driver_en))}</span>`:''}
     <span class="sl-tag muted">${L('Drawdown-control sizing; not a return forecast.','回撤控制仓位；并非收益预测。')}</span>
   </div>`;
 }
 // renderRegimeSizing() — returns the sizing pill HTML string ('' when calm / inactive).
 // Called from actNowPulseBar(); no longer writes to a standalone DOM element.
 //
 // PROVENANCE (why the copy names the US): THEME.regime_sizing is NOT computed per market.
 // engine/theme_scoring.py calls vol_regime.published_snapshot() with no region argument, so
 // the single global snapshot (CBOE VIX complex) is stamped onto all five basket pages —
 // us / china / hk / canada / intl carry byte-identical regime_sizing. The tip therefore says
 // whose volatility it is reading; without that, "volatility target 75%" on an A-share page
 // reads as a statement about A-share volatility, which was never measured.
 //
 // The caution note is a NULL DISCLOSURE (house epistemics: nulls printed, not hidden). The
 // regime-state caution is computed but withheld from gross because basket_overlay_gate.json
 // says it adds nothing over plain vol-targeting. That gate was measured on US books only
 // (scripts/backtest_vol_overlay.py — SPY primary + a US basket book), so the body claims only
 // "no measured edge" and the Tier-2 receipt carries the scope. Keep this text BYTE-IDENTICAL
 // to the US page's own copy in templates/sector_central.html.j2 (the US flagship since the
 // 2026-08 Sector Intelligence merge) — that page cannot load baskets_desk.js (this file's

```

## EXACT CHANGED CONTEXT: templates/china.html.j2
```diff
--- baseline/templates/china.html.j2
+++ candidate/templates/china.html.j2
@@ -1665,51 +1665,56 @@
         </span>
         {% if pb and pb.dial %}{% set pzh = {'DEFENSIVE':'防御','CAREFUL':'谨慎','NEUTRAL':'中性','CONSTRUCTIVE':'积极','AGGRESSIVE':'进取'} %}<span class="stk-status">
           <span class="l-en">Posture</span><span class="l-zh">姿态</span> <strong>{{ t(pb.dial.posture, pzh.get(pb.dial.posture, pb.dial.posture)) }}</strong>{{ lens.lens(
           kind='read', ill=lens.ILL_DIAL,
           kick=('Position size','仓位'),
           title=('How hard to lean in','该用多大力度'),
           body=('A dial from <b>defensive</b> to <b>aggressive</b> that sets how much risk to carry today. It sizes your positions — it does not pick stocks and it is not a buy or sell call. The full dial and its reasoning live on the China macro dashboard.','一个从<b>防御</b>到<b>进取</b>的刻度，决定今天承担多少风险。它只调整仓位大小 — 不选股，也不是买卖建议。完整刻度与推理见中国宏观看板。'),
           receipt=('Defensive · Careful · Neutral · Constructive · Aggressive','防御 · 谨慎 · 中性 · 建设性 · 进取')) }}
         </span>{% endif %}
       </div>
     </div>
     <div class="stk-header-links">
       <a href="china.html">← <span class="l-en">China macro dashboard</span><span class="l-zh">中国宏观看板</span></a>
       <a href="china_stocks_lab.html">🧪 <span class="l-en">Pick Lab</span><span class="l-zh">选股实验室</span> →</a>
     </div>
     {# W5b EDGE-1 — CN drawdown-radar RISK-BACKDROP cue. Source: engine/risk_radar_intl.py
        cn_sleeve_chip(), wired into setups.sleeve_chip by build_china_library.main().
        Plain-word rebuild of the old "Sleeve ×0.62" chip: the "sleeve" multiplier was
        jargon. Coloured from the zh-flipping direction pair --down/--warn/--up (operator
        ruling 2026-07-21, reverses #2947's no-flip): the risk backdrop is a market-
        direction read, so risk-off shows green in zh per the Asia convention, matching
        theme.css's .rrx remap and the macro-board state gauge. This is the ONLY risk read on the
        stocks page (Pullback-Risk card is macro-mode only). Degrades: hidden when
        sleeve_chip absent or radar_state None. CN-SYS-R7: display context, never board-sort. #}
     {% set _sc = setups.sleeve_chip if setups else none %}
-    {% if _sc and _sc.radar_state and _sc.radar_state != 'None' %}
+    {% if _sc and _sc.sleeve_status == 'unavailable' %}
+    <div class="muted" data-sleeve-status="unavailable">
+      <span>{{ t('Risk backdrop', '风险背景') }}: {{ t(_sc.label_en, _sc.label_zh) }}</span>
+      {% if _sc.radar_as_of %}<small> · {{ t('as of', '截至') }} {{ _sc.radar_as_of }}</small>{% endif %}
+    </div>
+    {% elif _sc and _sc.radar_state and _sc.radar_state != 'None' %}
     {% set _rs = _sc.radar_state %}
     {% set _rs_col = 'var(--down)' if _rs in ('elevated','risk-off') else ('var(--warn)' if _rs == 'caution' else 'var(--up)') %}
     {% set _rs_en = {'risk-off':'RISK-OFF','elevated':'ELEVATED','caution':'CAUTION','calm':'CALM'}.get(_rs, _rs|upper) %}
     {% set _rs_zh = {'risk-off':'避险','elevated':'偏高','caution':'谨慎','calm':'平静'}.get(_rs, _rs) %}
     {% set _rs_act_en = {'risk-off':'trade smaller','elevated':'trade smaller','caution':'avoid chasing','calm':'normal sizing'}.get(_rs, '') %}
     {% set _rs_act_zh = {'risk-off':'减小仓位','elevated':'减小仓位','caution':'谨慎追高','calm':'正常仓位'}.get(_rs, '') %}
     {% set _rs_idx = {'calm':0,'caution':1,'elevated':2,'risk-off':3}.get(_rs, 1) %}
     <div style="margin:11px 0 0;padding:7px 11px;border-radius:8px;font-size:11.5px;line-height:1.5;display:flex;align-items:center;flex-wrap:wrap;gap:4px 10px;border:1px solid var(--line);border-left:3px solid {{ _rs_col }};background:color-mix(in srgb,{{ _rs_col }} 6%,var(--panel))">
       <span style="font-weight:600;color:var(--muted)"><span class="l-en">Risk backdrop</span><span class="l-zh">风险背景</span></span>
       <span aria-hidden="true" style="display:inline-flex;gap:3px;align-items:center">{% for _i in range(4) %}<span style="width:{{ 15 if _i == _rs_idx else 9 }}px;height:6px;border-radius:3px;background:{{ _rs_col if _i == _rs_idx else 'var(--line)' }}"></span>{% endfor %}</span>
       <span style="color:{{ _rs_col }};font-weight:700"><span class="l-en">{{ _rs_en }} — {{ _rs_act_en }}</span><span class="l-zh">{{ _rs_zh }} — {{ _rs_act_zh }}</span></span>
       {% if _sc.dominant_driver_en %}<span class="muted" style="font-size:10.5px">· <span class="l-en">main risk: {{ _sc.dominant_driver_en.split(' (')[0] }}</span><span class="l-zh">主要风险：{{ (_sc.dominant_driver_zh or _sc.dominant_driver_en).split('（')[0] }}</span></span>{% endif %}
       {% if _sc.radar_as_of %}<span class="muted" style="font-size:10px">· {{ t('as of', '截至') }} {{ _sc.radar_as_of }}</span>{% endif %}
       {{ lens.lens(
         kind='caution', ill=lens.ILL_RADAR,
         kick=('Outside risk','外部风险'),
         title=('What could hit from abroad','外部可能的冲击'),
         body=('Pressure coming from <b>outside China</b> — US interest rates, the yuan, the gap between US and Chinese yields, and how many stocks are joining in. It sets the backdrop for <b>how big to trade</b>. It never removes a name and never changes the board&#39;s order.','来自<b>中国以外</b>的压力 — 美国利率、人民币汇率、中美利差，以及有多少个股在参与。它决定<b>该用多大仓位</b>，但绝不剔除任何标的，也不改变看板排序。'),
         receipt=('US rate shocks · USD/CNH · US-China yield gap · market breadth · context only (CN-SYS-R7)','美债利率冲击 · 美元/离岸人民币 · 中美利差 · 市场广度 · 仅供参考（CN-SYS-R7）')) }}
     </div>
     {% endif %}
   </div>
 
   {# CN Breathing Platform strip (CN-PR-3). Hidden until the live artifact
      qualifies. data-cn-session is the SSR board's settled session — the client

```

## EXACT CHANGED CONTEXT: templates/cn_reversal_sleeve.html.j2
```diff
--- baseline/templates/cn_reversal_sleeve.html.j2
+++ candidate/templates/cn_reversal_sleeve.html.j2
@@ -82,57 +82,64 @@
   /* W5-B survivorship-honest re-derivation block */
   .rederive { border:2px solid color-mix(in srgb,var(--up) 40%,var(--line)); border-radius:12px;
     background:color-mix(in srgb,var(--up) 5%,var(--panel)); padding:14px 16px; margin:0 0 16px; max-width:980px; }
   .rederive .rd-head { font-size:15px; font-weight:700; margin:0 0 4px; }
   .rederive .rd-sub { font-size:12px; color:var(--muted); margin:0 0 10px; max-width:88ch; }
   .rederive .rd-verdict { display:inline-block; font-size:12px; font-weight:800; letter-spacing:.04em;
     color:var(--ink-up, var(--up)); border:1px solid color-mix(in srgb,var(--up) 45%,var(--line));
     background:color-mix(in srgb,var(--up) 10%,transparent); padding:2px 9px; border-radius:7px; margin:0 0 10px; }
   .rederive .rd-grid { display:flex; flex-wrap:wrap; gap:8px; margin:0 0 8px; }
   .rederive .rd-stat { font-size:12px; color:var(--muted); padding:4px 10px;
     border:1px solid var(--line); border-radius:8px; background:var(--panel); }
   .rederive .rd-stat b { color:var(--text); font-size:13px; font-variant-numeric:tabular-nums; }
   .rederive .rd-warn { font-size:11.5px; color:var(--ink-warn, var(--warn)); margin:6px 0 0; }
   .rederive .rd-ub { font-size:11px; color:var(--muted); border-top:1px dashed var(--line); margin:8px 0 0; padding-top:6px; }
   code { font-size:11px; background:color-mix(in srgb,var(--muted) 12%,transparent); padding:1px 4px; border-radius:4px; }
 </style>
 </head>
 <body>
 {% include "_site_nav.html.j2" %}
 <h1>{{ t('CN Reversal Sleeve','A股反转组合') }}<span class="shadow-tag">{{ t('beta · accruing grades','Beta · 成绩累积中') }}</span></h1>
 <p class="lead-p">{{ t(
   'The validated A-share edge — deepest-quintile 3-month WITHIN-SECTOR reversal — shipped at its own product unit: a MONTHLY-rebalanced, EQUAL-WEIGHT, small-per-name BASKET with NO confirmation gate (every gate tested flips the edge negative). This is a PORTFOLIO, not stock tips. Sleeve-level stats only.',
   '已验证的A股优势——季度内“同板块最深回撤”反转（最深五分位）——以其自身产品单元交付：按月再平衡、等权、单只小仓位的组合，且无任何确认门槛（每一个门槛都会让优势转负）。这是一个组合，不是个股建议。仅展示组合层面统计。') }}</p>
 
 {# ---- SLEEVE SIZE chip (risk_radar_intl — SLEEVE-level, never per-name) ---- #}
+{% if d.sizing.sleeve_factor is not number %}
+<div class="sleeve-chip" data-state="unavailable" data-sleeve-status="unavailable">
+  <span>{{ t(d.sizing.label_en or 'Sizing unavailable', d.sizing.label_zh or '仓位建议暂缺') }}</span>
+  {% if d.sizing.radar_as_of %}<span class="prov">{{ d.sizing.radar_as_of }}</span>{% endif %}
+</div>
+{% else %}
 <div class="sleeve-chip" data-state="{{ d.sizing.radar_state or 'unknown' }}">
   <span class="fac">×{{ '%.2f'|format(d.sizing.sleeve_factor) }}</span>
   <span>{{ t('sleeve gross','组合仓位') }}</span>
   <span class="prov">· {{ t('CN drawdown radar','A股回撤雷达') }}: {{ d.sizing.radar_state or '—' }}
     · can_force <code>{{ 'yes' if d.sizing.can_force else 'no' }}</code>
     {% if d.sizing.radar_as_of %}· {{ d.sizing.radar_as_of }}{% endif %}</span>
 </div>
+{% endif %}
 
 <div class="strip">
   <span class="stat">{{ t('as of','截至') }} <b>{{ d.as_of }}</b></span>
   <span class="stat">{{ t('data through','数据截至') }} <b>{{ d.data_through }}</b></span>
   <span class="stat">{{ t('members','成分') }} <b>{{ d.n_members }}</b></span>
   <span class="stat">{{ t('universe','可选池') }} <b>{{ d.n_universe }}</b></span>
   <span class="stat">{{ t('sectors','行业') }} <b>{{ d.sectors|length }}</b></span>
   <span class="stat">{{ t('equal weight','等权') }} <b>{{ (d.equal_weight*100)|round(2) }}%</b></span>
   <span class="stat">{{ t('rebalance','再平衡') }} <b>{{ t('monthly','按月') }}</b></span>
 </div>
 
 {# ---- HONEST DISCLOSURE (portfolio, not tips) ---- #}
 <div class="disc warn">
   <b>{{ t('Read this as a portfolio, not stock tips.','请把它当作组合，而非个股建议。') }}</b>
   <ul>
     <li>{{ t('Per-name drawdowns are deep — the validated construction saw','单只回撤很深——已验证构造的历史') }}
       <span class="neg">{{ '%.1f'|format(d.presentation.maxdd_disclosure_pct) }}%</span>
       {{ t('maximum drawdown. It BUYS into weakness.','最大回撤。它是在买入弱势。') }}</li>
     <li>{{ t('Expected monthly hit rate ≈','预期月度胜率约') }} <b>{{ d.presentation.expected_monthly_hit_pct }}%</b>
       — {{ t('roughly a coin-flip that beats the index each month; the edge is small and cumulative.','约等于每月略胜指数的概率；优势小而累积。') }}</li>
     <li>{{ d.presentation.one_bet_note }}</li>
     <li>{{ d.presentation.fill_note }}</li>
     <li><b>{{ t('Historical stats below are an UPPER BOUND','下方历史统计为上界') }}</b> —
       {{ t('reconstructed on the current plane, which under-represents delisted / dropped names (survivorship). The forward ledger is the real record.','在当前面板上重建，低估了退市/剔除的名称（幸存者偏差）。前瞻记录簿才是真实记录。') }}</li>
   </ul>

```

## COMPLETE CANDIDATE SOURCE: templates/international_macro.html.j2
```
1: {# Shared Risk Radar card (.rrx) — the SAME macro the US modal and the China / HK / Canada
2:    boards render; fed here by RADAR (scripts/build_international_macro._radar_display, which
3:    normalizes this market's nightly engine/risk_radar_intl snapshot). Absent-safe: RADAR is
4:    None when the market has no snapshot and every use below is guarded. #}
5: {% import "_risk_radar_card.html.j2" as rrc %}
6: {% set _qualified_radar = RADAR and RADAR.authority and RADAR.authority.reason == 'construction_not_promoted' %}
7: {% macro t(en, zh='') -%}<span class="l-en">{{ en|safe }}</span><span class="l-zh">{{ (zh if zh else en)|safe }}</span>{%- endmacro %}
8: {% macro value(raw, suffix='') -%}
9:   {%- if raw is none -%}<span class="na">{{ t('Unavailable','不可用') }}</span>
10:   {%- elif raw|abs >= 100 -%}{{ "{:,.2f}".format(raw) }}{{ suffix }}
11:   {%- else -%}{{ "{:.2f}".format(raw) }}{{ suffix }}{%- endif -%}
12: {%- endmacro %}
13: <!DOCTYPE html>
14: <html lang="en">
15: <head>
16: <meta charset="utf-8">
17: <meta name="viewport" content="width=device-width, initial-scale=1">
18: {% set seo_title = D.name ~ " Macro Dashboard — MastermindX" %}
19: {% set seo_desc = D.name ~ " macro regime, policy, inflation, growth, labour, credit, rates, FX, external balance and calibrated market risk." %}
20: {% set seo_path = D.route %}
21: <title>{{ seo_title }}</title>
22: {% include "_seo_head.html.j2" %}
23: <script>
24: try{
25:   var mt=localStorage.getItem('theme');document.documentElement.setAttribute('data-theme',mt||'dark');
26:   var ml=localStorage.getItem('lang');if(ml)document.documentElement.setAttribute('data-lang',ml);
27: }catch(e){}
28: </script>
29: <link rel="stylesheet" href="theme.css">
30: <link rel="stylesheet" href="product-nav-icons.css">
31: <style>
32: *{box-sizing:border-box}
33: :root{color-scheme:dark}
34: html[data-theme="light"]{color-scheme:light}
35: body.imd-page{
36:   --imd-bg:#0a0c11;--imd-panel:rgba(16,22,30,.62);--imd-panel-strong:rgba(13,18,26,.94);
37:   --imd-border:rgba(255,255,255,.12);--imd-hair:color-mix(in srgb,var(--line) 74%,transparent);
38:   --imd-shadow:0 8px 32px rgba(0,0,0,.48),inset 0 1px 0 rgba(255,255,255,.055);
39:   --imd-radius:18px;--imd-num:var(--font-mono,ui-monospace,"SF Mono",Menlo,monospace);
40:   margin:0;padding:20px;color:var(--text);background:var(--imd-bg);
41:   font:14px/1.55 var(--font-ui,Inter,-apple-system,"Segoe UI",sans-serif);
42:   min-height:100vh;
43: }
44: html[data-theme="light"] body.imd-page{
45:   --imd-bg:#f5f7fb;--imd-panel:rgba(255,255,255,.84);--imd-panel-strong:rgba(255,255,255,.98);
46:   --imd-border:rgba(14,23,38,.09);--imd-shadow:0 8px 30px rgba(18,35,62,.09),inset 0 1px 0 #fff;
47: }
48: html[data-lang="zh"] body.imd-page{font-family:"PingFang SC","Microsoft YaHei","Noto Sans CJK SC",sans-serif}
49: body.imd-page a{color:var(--ink-link, var(--link));text-decoration:none}
50: body.imd-page button{font:inherit}
51: .imd-aurora{position:fixed;inset:0;z-index:0;pointer-events:none;overflow:hidden}
52: .imd-aurora::before,.imd-aurora::after,.imd-aurora b{content:"";position:absolute;border-radius:50%;filter:blur(100px)}
53: .imd-aurora::before{width:820px;height:560px;left:6%;top:-260px;background:radial-gradient(ellipse,color-mix(in srgb,var(--link) 15%,transparent),transparent 70%)}
54: .imd-aurora::after{width:680px;height:560px;right:-160px;bottom:-220px;background:radial-gradient(ellipse,color-mix(in srgb,var(--up) 11%,transparent),transparent 70%)}
55: .imd-aurora b{width:560px;height:460px;left:45%;top:34%;background:radial-gradient(ellipse,rgba(99,102,241,.08),transparent 70%)}
56: html[data-theme="light"] .imd-aurora{opacity:.42}
57: nav.site-nav{position:relative;z-index:20}
58: .imd-shell{position:relative;z-index:1;max-width:1480px;margin:18px auto 80px}
59: .imd-card{
60:   position:relative;background:var(--imd-panel);border:1px solid var(--imd-border);
61:   border-radius:var(--imd-radius);box-shadow:var(--imd-shadow);backdrop-filter:blur(20px);
62:   -webkit-backdrop-filter:blur(20px);padding:20px;min-width:0;
63: }
64: .imd-eyebrow{display:flex;align-items:center;gap:8px;color:var(--muted);font-size:10px;font-weight:800;letter-spacing:.13em;text-transform:uppercase}
65: .imd-dot{width:7px;height:7px;border-radius:50%;background:var(--up);box-shadow:0 0 14px color-mix(in srgb,var(--up) 65%,transparent)}
66: .imd-hero{display:grid;grid-template-columns:minmax(0,1.08fr) minmax(360px,.92fr);gap:16px;margin-bottom:16px}
67: .imd-hero-main{overflow:hidden;padding:26px}
68: .imd-hero-main::after{content:"";position:absolute;width:340px;height:340px;border-radius:50%;right:-120px;top:-170px;background:radial-gradient(circle,color-mix(in srgb,var(--link) 14%,transparent),transparent 68%);pointer-events:none}
69: .imd-title-row{display:flex;align-items:flex-start;justify-content:space-between;gap:18px;margin-top:12px}
70: .imd-title{margin:0;font-size:clamp(27px,4vw,48px);line-height:1.03;letter-spacing:-.045em}
71: .imd-title .flag{font-size:.75em;margin-right:8px}
72: .imd-scope{color:var(--muted);font-size:12px;margin:10px 0 0;max-width:720px}
73: .imd-asof{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:16px;font-size:11px;color:var(--muted)}
74: .imd-chip{display:inline-flex;align-items:center;gap:6px;padding:4px 10px;border-radius:999px;border:1px solid var(--imd-border);background:color-mix(in srgb,var(--text) 4%,transparent);font-size:10px;font-weight:750}
75: .imd-chip.constructive,.imd-chip.clear{color:var(--ink-up, var(--up));border-color:color-mix(in srgb,var(--up) 35%,var(--imd-border));background:color-mix(in srgb,var(--up) 9%,transparent)}
76: .imd-chip.stale,.imd-chip.today,.imd-chip.balanced,.imd-chip.caution{color:var(--ink-warn, var(--warn));border-color:color-mix(in srgb,var(--warn) 38%,var(--imd-border));background:color-mix(in srgb,var(--warn) 9%,transparent)}
77: .imd-chip.defensive,.imd-chip.risk{color:var(--ink-down, var(--down));border-color:color-mix(in srgb,var(--down) 36%,var(--imd-border));background:color-mix(in srgb,var(--down) 8%,transparent)}
78: .imd-chip.released{color:var(--muted)}
79: /* Data-health states (fresh / stale / missing) say how CURRENT a datum is, never which way a market
80:    moved, so they sit on the language-invariant status plane (--ok/--warn/--act) and never on --up/--down:
81:    the "Confirmed <date>" chip must read the same in EN and ZH (theme.css swaps --up/--down under zh). */
82: .imd-chip.fresh{color:var(--ink-ok, var(--ok));border-color:color-mix(in srgb,var(--ok) 35%,var(--imd-border));background:color-mix(in srgb,var(--ok) 9%,transparent)}
83: .imd-chip.missing{color:var(--ink-act, var(--act));border-color:color-mix(in srgb,var(--act) 36%,var(--imd-border));background:color-mix(in srgb,var(--act) 8%,transparent)}
84: .imd-score-wrap{display:grid;grid-template-columns:164px minmax(0,1fr);gap:20px;align-items:center;margin-top:24px}
85: .imd-gauge{
86:   width:154px;aspect-ratio:1;border-radius:50%;display:grid;place-items:center;
87:   background:conic-gradient(var(--gauge) calc(var(--score)*1%),color-mix(in srgb,var(--text) 9%,transparent) 0);
88:   position:relative;filter:drop-shadow(0 0 25px color-mix(in srgb,var(--gauge) 18%,transparent));
89: }
90: .imd-gauge::before{content:"";position:absolute;inset:11px;border-radius:50%;background:var(--imd-panel-strong);border:1px solid var(--imd-border)}
91: .imd-gauge-value{position:relative;text-align:center;font:800 48px/.9 var(--imd-num);color:var(--gauge);letter-spacing:-.06em}
92: .imd-gauge-value small{display:block;margin-top:9px;font:700 9px/1 var(--font-ui,Inter,sans-serif);color:var(--muted);letter-spacing:.08em;text-transform:uppercase}
93: .imd-score-constructive{--gauge:var(--up)}.imd-score-balanced{--gauge:var(--warn)}.imd-score-defensive{--gauge:var(--down)}
94: .imd-verdict{font-size:21px;font-weight:800;letter-spacing:-.02em}
95: .imd-action{margin-top:7px;color:var(--text);font-size:13px;max-width:560px}
96: .imd-method{color:var(--muted);font-size:10.5px;margin:9px 0 0}
97: .imd-transition{display:grid;gap:8px}
98: .imd-transition h2,.imd-section-head h2{font-size:16px;line-height:1.25;margin:0;letter-spacing:-.015em}
99: .imd-transition h2::before,.imd-section-head h2::before{content:"";display:inline-block;width:3px;height:16px;border-radius:2px;background:linear-gradient(var(--link),color-mix(in srgb,var(--link) 28%,transparent));margin-right:9px;vertical-align:-2px}
100: .imd-transition-list{display:grid;gap:8px;margin-top:8px}
101: .imd-condition{display:flex;gap:10px;align-items:flex-start;padding:10px 12px;border:1px solid var(--imd-hair);border-radius:12px;background:color-mix(in srgb,var(--text) 3%,transparent);font-size:11.5px}
102: .imd-condition b{display:grid;place-items:center;flex:0 0 22px;height:22px;border-radius:7px;color:var(--ink-link, var(--link));background:color-mix(in srgb,var(--link) 12%,transparent);font:750 10px var(--imd-num)}
103: /* auto-fit, not repeat(5): the pullback tile stands down when the Risk Radar card below
104:    owns that number, and the remaining tiles still span the row evenly. */
105: .imd-trust{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin-bottom:16px}
106: .imd-trust-item{padding:13px 15px}
107: .imd-trust-label{font-size:9px;text-transform:uppercase;letter-spacing:.1em;color:var(--muted);font-weight:800}
108: .imd-trust-value{margin-top:5px;font:750 15px var(--imd-num);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
109: .imd-trust-value.word{font-family:inherit}
110: .imd-section{margin-top:25px}
111: .imd-section-head{display:flex;align-items:end;justify-content:space-between;gap:16px;margin:0 2px 11px}
112: .imd-section-head p{margin:0;color:var(--muted);font-size:11px;text-align:right}
113: .imd-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}
114: button.imd-face{color:inherit;text-align:left;cursor:pointer;width:100%;transition:transform .18s,border-color .18s,background .18s}
115: button.imd-face:hover{transform:translateY(-2px);border-color:color-mix(in srgb,var(--link) 32%,var(--imd-border));background:color-mix(in srgb,var(--link) 5%,var(--imd-panel))}
116: button.imd-face:focus-visible,.imd-close:focus-visible{outline:2px solid var(--link);outline-offset:3px}
117: .imd-face-top{display:flex;align-items:flex-start;justify-content:space-between;gap:12px}
118: .imd-face-icon{display:grid;place-items:center;width:36px;height:36px;border:1px solid var(--imd-border);border-radius:11px;background:color-mix(in srgb,var(--link) 10%,transparent);font-size:17px}
119: .imd-open{font-size:9px;color:var(--muted);letter-spacing:.07em;text-transform:uppercase}
120: .imd-face h3{margin:13px 0 4px;font-size:14px}
121: .imd-face p{margin:0;color:var(--muted);font-size:11px;min-height:34px}
122: .imd-face-kpi{display:flex;align-items:end;justify-content:space-between;gap:12px;margin-top:15px;padding-top:12px;border-top:1px solid var(--imd-hair)}
123: .imd-face-kpi strong{font:800 25px/1 var(--imd-num);letter-spacing:-.045em}
124: .imd-face-kpi span{color:var(--muted);font-size:9px;text-align:right}
125: .imd-kpi-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-top:14px}
126: .imd-mini{border-top:1px solid var(--imd-hair);padding-top:9px;min-width:0}
127: .imd-mini span{display:block;color:var(--muted);font-size:9px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
128: .imd-mini strong{display:block;margin-top:3px;font:750 14px var(--imd-num)}
129: .imd-chart-card{padding:24px}
130: .imd-chart-wrap{height:210px;margin-top:13px;position:relative;border:1px solid var(--imd-hair);border-radius:14px;overflow:hidden;background:linear-gradient(180deg,color-mix(in srgb,var(--link) 6%,transparent),transparent)}
131: .imd-chart-wrap::before,.imd-chart-wrap::after{content:"";position:absolute;left:0;right:0;border-top:1px dashed var(--imd-hair)}
132: .imd-chart-wrap::before{top:36%}.imd-chart-wrap::after{top:62%}
133: .imd-chart{position:absolute;inset:16px;width:calc(100% - 32px);height:calc(100% - 32px);overflow:visible}
134: .imd-chart polygon{fill:url(#scoreFill)}
135: .imd-chart polyline{fill:none;stroke:var(--link);stroke-width:2.4;vector-effect:non-scaling-stroke;filter:drop-shadow(0 0 5px color-mix(in srgb,var(--link) 50%,transparent))}
136: .imd-chart-meta{display:flex;justify-content:space-between;color:var(--muted);font:10px var(--imd-num);margin-top:9px}
137: .imd-lenses{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}
138: .imd-lens{padding:16px}
139: .imd-lens h3{font-size:12px;margin:0 0 6px}
140: .imd-lens p{font-size:10.5px;color:var(--muted);margin:0;min-height:48px}
141: .imd-lens-v{font:750 14px var(--imd-num);margin-top:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
142: .imd-lens-src{font-size:9px;color:var(--muted);margin-top:5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
143: .imd-calendar{display:grid;gap:8px}
144: .imd-event{display:grid;grid-template-columns:105px 1fr auto;gap:14px;align-items:center;padding:13px 15px}
145: .imd-event-date{font:750 12px var(--imd-num)}
146: .imd-event h3{margin:0;font-size:12px}.imd-event p{margin:3px 0 0;color:var(--muted);font-size:10px}
147: .imd-health{overflow:auto;padding:0}
148: .imd-table{width:100%;border-collapse:collapse;min-width:760px;font-size:11px}
149: .imd-table th,.imd-table td{padding:12px 14px;border-bottom:1px solid var(--imd-hair);text-align:left;vertical-align:top}
150: .imd-table th{color:var(--muted);font-size:9px;letter-spacing:.08em;text-transform:uppercase}
151: .imd-table tr:last-child td{border-bottom:0}
152: .imd-table .source-role{max-width:340px;color:var(--muted)}
153: .imd-caveat{margin-top:12px;padding:13px 15px;border-radius:13px;border:1px solid color-mix(in srgb,var(--warn) 32%,var(--imd-border));background:color-mix(in srgb,var(--warn) 7%,transparent);font-size:11px}
154: .imd-next{display:flex;flex-wrap:wrap;gap:8px}
155: .imd-next a{display:inline-flex;padding:8px 13px;border:1px solid var(--imd-border);border-radius:999px;color:var(--text);font-size:11px;background:var(--imd-panel)}
156: .imd-next a.active{color:var(--ink-link, var(--link));border-color:color-mix(in srgb,var(--link) 40%,var(--imd-border))}
157: .imd-next a:hover{background:color-mix(in srgb,var(--link) 8%,var(--imd-panel))}
158: .imd-footer{display:flex;justify-content:space-between;gap:18px;margin-top:22px;padding:16px 4px;color:var(--muted);font-size:10px}
159: .imd-dlg{position:fixed;inset:0;z-index:1000;display:none;align-items:center;justify-content:center;padding:18px}
160: .imd-dlg.open{display:flex}
161: .imd-backdrop{position:absolute;inset:0;background:rgba(3,7,13,.68);backdrop-filter:blur(8px)}
162: .imd-panel{position:relative;width:min(900px,94vw);max-height:88vh;overflow:auto;background:var(--imd-panel-strong);border:1px solid var(--imd-border);border-radius:22px;box-shadow:0 32px 100px rgba(0,0,0,.65);opacity:0;transform:translateY(12px) scale(.975);transition:opacity .22s,transform .28s}
163: .imd-dlg.in .imd-panel{opacity:1;transform:none}
164: .imd-dlg-head{position:sticky;top:0;z-index:2;display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid var(--imd-hair);background:var(--imd-panel-strong);backdrop-filter:blur(20px)}
165: .imd-dlg-head h2{margin:0;font-size:15px}
166: .imd-close{display:grid;place-items:center;width:34px;height:34px;border-radius:50%;border:1px solid var(--imd-border);background:color-mix(in srgb,var(--text) 5%,transparent);color:var(--text);cursor:pointer}
167: .imd-dlg-body{padding:20px}
168: .imd-cols{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:12px}
169: .imd-receipt{border:1px solid var(--imd-hair);border-radius:13px;padding:13px}
170: .imd-receipt h3{font-size:11px;margin:0 0 7px}.imd-receipt p{font-size:10.5px;color:var(--muted);margin:0}
171: .imd-breakdown{display:grid;gap:7px}
172: .imd-part{display:grid;grid-template-columns:90px 1fr 56px;align-items:center;gap:10px;font-size:10px}
173: .imd-bar{height:7px;border-radius:5px;background:color-mix(in srgb,var(--text) 7%,transparent);overflow:hidden}
174: .imd-bar i{display:block;height:100%;background:var(--link);transform-origin:left}
175: body.imd-lock{overflow:hidden}
176: /* help "?" tip — the pre-upgrade fallback for the shared card's help() icons. theme.js
177:    promotes canonical icons to the site popover (.help-upgraded hides .tip); these rules
178:    keep the tooltip body hidden until then, and hover-usable with JS off. */
179: .help{display:inline-flex;align-items:center;justify-content:center;width:15px;height:15px;border-radius:50%;border:1px solid var(--muted);color:var(--muted);font-size:10px;font-weight:600;cursor:help;position:relative;vertical-align:middle;margin-left:4px}
180: .help .tip{display:none;position:absolute;top:140%;left:50%;transform:translateX(-50%);width:280px;background:var(--panel);border:1px solid var(--line);padding:9px 11px;border-radius:8px;z-index:60;font-size:12px;line-height:1.45;color:var(--text);font-weight:400;text-transform:none;letter-spacing:normal;box-shadow:var(--popover-shadow);max-height:min(60vh,420px);overflow-y:auto;overscroll-behavior:contain}
181: .help:hover::before{content:'';position:absolute;top:100%;left:-30px;right:-30px;height:10px}
182: .help:hover .tip{display:block}
183: /* Risk Radar section — the shared .rrx card wears this page's glass-card skin by remapping
184:    --panel, so the card's own tokens (loud wash, chips, meters) all follow one swap instead
185:    of a fork. Left accent + every internal rule stay exactly as the shared partial ships. */
186: .imd-radar .rrx{--panel:var(--imd-panel);margin:0;padding:20px;border-radius:var(--imd-radius);border-color:var(--imd-border);box-shadow:var(--imd-shadow);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);border-left:4px solid var(--rc)}
187: {% include "_risk_radar_card.css.j2" %}
188: /* after the include: a class-pair selector outranks the card's own phone rule, so the
189:    mobile padding has to be restated at this specificity to survive. */
190: @media(max-width:560px){.imd-radar .rrx{padding:16px}}
191: @media(max-width:1100px){
192:   body.imd-page{padding:16px}
193:   .imd-hero{grid-template-columns:1fr}.imd-transition-list{grid-template-columns:repeat(3,minmax(0,1fr))}
194:   .imd-grid{grid-template-columns:repeat(2,minmax(0,1fr))}
195:   .imd-lenses{grid-template-columns:repeat(3,minmax(0,1fr))}
196: }
197: @media(max-width:760px){
198:   body.imd-page{padding:12px}.imd-shell{margin-top:12px}
199:   .imd-title-row{display:block}.imd-score-wrap{grid-template-columns:120px minmax(0,1fr);gap:14px}
200:   .imd-gauge{width:116px}.imd-gauge-value{font-size:37px}
201:   .imd-transition-list,.imd-grid,.imd-lenses,.imd-cols{grid-template-columns:1fr}
202:   .imd-trust{grid-template-columns:repeat(2,minmax(0,1fr))}
203:   .imd-section-head{display:block}.imd-section-head p{text-align:left;margin-top:5px}
204:   .imd-event{grid-template-columns:88px 1fr}.imd-event .imd-chip{grid-column:2;justify-self:start}
205:   .imd-dlg{align-items:flex-end;padding:0}.imd-panel{width:100%;max-width:none;max-height:90vh;border-radius:22px 22px 0 0;transform:translateY(100%)}
206:   .imd-dlg.in .imd-panel{transform:none}.imd-close{width:42px;height:42px}
207:   .imd-footer{display:block}.imd-footer span{display:block;margin-top:5px}
208: }
209: @media(max-width:430px){
210:   .imd-hero-main,.imd-card{padding:16px}.imd-title{font-size:30px}
211:   .imd-score-wrap{grid-template-columns:1fr}.imd-gauge{width:130px}
212:   .imd-trust{grid-template-columns:1fr}.imd-face-kpi strong{font-size:22px}
213: }
214: @media(prefers-reduced-motion:reduce){
215:   *,*::before,*::after{scroll-behavior:auto!important;animation:none!important;transition:none!important}
216: }
217: </style>
218: </head>
219: <body class="imd-page imd-score-{{ D.decision.state }}">
220: <div class="imd-aurora" aria-hidden="true"><b></b></div>
221: 
222: {% include "_site_nav.html.j2" %}
223: 
224: <main class="imd-shell">
225:   <section class="imd-hero">
226:     <article class="imd-card imd-hero-main">
227:       <div class="imd-eyebrow"><span class="imd-dot"></span>{{ t('International macro command center','国际宏观指挥中心') }}</div>
228:       <div class="imd-title-row">
229:         <div>
230:           <h1 class="imd-title"><span class="flag">{{ D.flag }}</span>{{ t(D.name ~ ' Macro',D.name_zh ~ '宏观') }}</h1>
231:           <p class="imd-scope">{{ t(D.scope_en,D.scope_zh) }}</p>
232:         </div>
233:         <span class="imd-chip {{ D.decision.state }}">{{ t(D.decision.state_en,D.decision.state_zh) }}</span>
234:       </div>
235:       <div class="imd-asof">
236:         <span>{{ t('Data through','数据截至') }} <b>{{ D.asof }}</b></span>
237:         <span>·</span><span>{{ t('Built','生成') }} {{ D.built }}</span>
238:         {% if D.regime.data_limited %}<span class="imd-chip missing">{{ t('Limited coverage','覆盖有限') }}</span>{% endif %}
239:       </div>
240:       <div class="imd-score-wrap">
241:         <div class="imd-gauge" style="--score:{{ D.decision.score }}" role="img" aria-label="Decision score {{ D.decision.score }} out of 100">
242:           <div class="imd-gauge-value">{{ D.decision.score }}<small>{{ t('Decision score','决策分') }}</small></div>
243:         </div>
244:         <div>
245:           <div class="imd-verdict">{{ t(D.decision.state_en ~ ' posture',D.decision.state_zh ~ '姿态') }}</div>
246:           <div class="imd-action">{{ t(D.decision.action_en,D.decision.action_zh) }}</div>
247:           <p class="imd-method">{{ t(D.decision.method_en,D.decision.method_zh) }}</p>
248:         </div>
249:       </div>
250:     </article>
251:     <aside class="imd-card imd-transition">
252:       <div class="imd-eyebrow">{{ t('What changes the call','哪些条件会改变判断') }}</div>
253:       <h2>{{ t('Regime transition conditions','周期转折条件') }}</h2>
254:       <div class="imd-transition-list">
255:         {% for item in D.decision.transitions_en %}
256:         <div class="imd-condition"><b>0{{ loop.index }}</b><span>{{ t(item,D.decision.transitions_zh[loop.index0]) }}</span></div>
257:         {% endfor %}
258:       </div>
259:     </aside>
260:   </section>
261: 
262:   <section class="imd-trust" aria-label="Current macro status">
263:     <div class="imd-card imd-trust-item"><div class="imd-trust-label">{{ t('Regime','周期') }}</div><div class="imd-trust-value word">{{ D.regime.name }}</div></div>
264:     <div class="imd-card imd-trust-item"><div class="imd-trust-label">{{ t('Liquidity','流动性') }}</div><div class="imd-trust-value word">{{ D.regime.liquidity|title }}</div></div>
265:     <div class="imd-card imd-trust-item"><div class="imd-trust-label">{{ t('Recession stress','衰退压力') }}</div><div class="imd-trust-value">{{ value(D.regime.recession_score,'') }}<small>/100</small></div></div>
266:     {# The bare pullback tile stands down when the Risk Radar card renders below: the card
267:        carries the same 21-session number with its escalation ladder and its normal base
268:        rate, so printing it twice would just be one constant on two tiers. #}
269:     {% if not RADAR %}
270:     <div class="imd-card imd-trust-item"><div class="imd-trust-label">{{ t('21-session pullback','21交易日回撤') }}</div><div class="imd-trust-value">{% if D.risk.h21 is not none %}{{ (D.risk.h21*100)|round(1) }}%{% else %}<span class="na">N/A</span>{% endif %}</div></div>
271:     {% endif %}
272:     <div class="imd-card imd-trust-item"><div class="imd-trust-label">{{ t('Source state','数据状态') }}</div><div class="imd-trust-value word">{% set stale = D.health|selectattr('state','equalto','stale')|list %}{% set missing = D.health|selectattr('state','equalto','missing')|list %}{% if missing %}{{ t('Gaps visible','缺口可见') }}{% elif stale %}{{ t('Stale inputs','输入陈旧') }}{% else %}{{ t('Current','当前') }}{% endif %}</div></div>
273:   </section>
274: 
275:   {% if RADAR %}
276:   <section class="imd-section imd-radar" aria-label="Risk Radar">
277:     {# Section names the topic; the card names the instrument ("Risk Radar" + state badge) —
278:        heading and card must not print the same three words twice, 40px apart. #}
279:     <div class="imd-section-head"><h2>{{ t('Pullback risk','回撤风险') }}</h2><p>{{ t('Read the inputs; a calibrated forecast is not available.','观察输入；当前不提供经校准的预测。') if _qualified_radar else t("Odds measured on this market's own history — windows, not certainties, re-drawn nightly.",'概率基于本市场自身历史测算 — 是概率窗口而非定论，每晚重算。') }}</p></div>
280:     {{ rrc.risk_radar_card(RADAR, RADAR.scares) }}
281:   </section>
282:   {% endif %}
283: 
284:   <section class="imd-section">
285:     <div class="imd-section-head"><h2>{{ t('Command cards','指挥卡片') }}</h2><p>{{ t('Open any card for evidence, definitions and provenance.','打开任一卡片查看证据、定义与来源。') }}</p></div>
286:     <div class="imd-grid">
287:       <button class="imd-card imd-face" data-dialog="dlg-regime" aria-haspopup="dialog">
288:         <div class="imd-face-top"><span class="imd-face-icon">◈</span><span class="imd-open">{{ t('Open evidence','打开证据') }} ↗</span></div>
289:         <h3>{{ t('Regime & action','周期与行动') }}</h3><p>{{ t('Growth, inflation, confidence and the current operating posture.','增长、通胀、置信度与当前操作姿态。') }}</p>
290:         <div class="imd-face-kpi"><strong>{{ D.regime.name }}</strong><span>{{ t('confidence','置信度') }} {{ (D.regime.confidence*100)|round(0)|int }}%</span></div>
291:       </button>
292:       <button class="imd-card imd-face" data-dialog="dlg-economy" aria-haspopup="dialog">
293:         <div class="imd-face-top"><span class="imd-face-icon">⌁</span><span class="imd-open">{{ t('Open evidence','打开证据') }} ↗</span></div>
294:         <h3>{{ t('Inflation · growth · labour','通胀 · 增长 · 就业') }}</h3><p>{{ t('The macro core, with release period and missing-state semantics.','宏观核心，包含发布期与缺失状态语义。') }}</p>
295:         <div class="imd-kpi-grid">
296:           {% for key in ['cpi_yoy','gdp_yoy','unemployment','realvol'] %}{% set m=D.metrics|selectattr('key','equalto',key)|first %}
297:           <div class="imd-mini"><span>{{ t(m.label_en,m.label_zh) }}</span><strong>{{ m.value }}</strong></div>{% endfor %}
298:         </div>
299:       </button>
300:       <button class="imd-card imd-face" data-dialog="dlg-policy" aria-haspopup="dialog">
301:         <div class="imd-face-top"><span class="imd-face-icon">⌂</span><span class="imd-open">{{ t('Open policy','打开政策') }} ↗</span></div>
302:         <h3>{{ D.policy.bank }}</h3><p>{{ t('Policy rate, curve transmission and the next verified decisions.','政策利率、曲线传导与下一次已核实决议。') }}</p>
303:         <div class="imd-face-kpi"><strong>{{ value(D.policy.rate,'%') }}</strong><span>{{ t('curve','曲线') }} {{ value(D.policy.curve,'pp') }}</span></div>
304:       </button>
305:       <button class="imd-card imd-face" data-dialog="dlg-market" aria-haspopup="dialog">
306:         <div class="imd-face-top"><span class="imd-face-icon">⌁</span><span class="imd-open">{{ t('Open context','打开背景') }} ↗</span></div>
307:         <h3>{{ t('Rates · FX · market context','利率 · 汇率 · 市场背景') }}</h3><p>{{ D.market.index_label }} · {{ D.market.currency_label }}</p>
308:         <div class="imd-kpi-grid">
309:           {% for key in ['yield_10y','curve','fx','drawdown'] %}{% set m=D.metrics|selectattr('key','equalto',key)|first %}
310:           <div class="imd-mini"><span>{{ t(m.label_en,m.label_zh) }}</span><strong>{{ m.value }}</strong></div>{% endfor %}
311:         </div>
312:       </button>
313:       <button class="imd-card imd-face" data-dialog="dlg-risk" aria-haspopup="dialog">
314:         <div class="imd-face-top"><span class="imd-face-icon">⌾</span><span class="imd-open">{{ t('Open risk','打开风险') }} ↗</span></div>
315:         <h3>{{ t('Risk evidence','风险证据') if _qualified_radar else t('Calibrated risk monitor','校准风险监测') }}</h3><p>{{ t('Check the observations and what remains unknown.','查看已观测的信息与仍未知的部分。') if _qualified_radar else t('Forward pullback odds stay separate from the descriptive macro score.','前瞻回撤概率与描述性宏观分数严格分开。') }}</p>
316:         {# With the radar card on the page this face stops repeating its headline odds and
317:            its dominant label, and counts what the receipt behind it actually adds.
318:            COUNT THE LIVE ONES (2026-08-11): `D.risk.scares|length` is the size of the
319:            PROFILE — every family the radar tracks, including the ones sitting at calm —
320:            so it printed "3 · Active scare families" on japan.html while one of the three
321:            scored 16 and banded calm, and on south_korea.html it printed "3 active" beside
322:            a card reading "Calm — no driver elevated". The band comes from the engine; this
323:            only filters and shows the denominator so the number carries its meaning
324:            (DESIGN_DOCTRINE Law 3). No new statistic is computed here. #}
325:         {% if _qualified_radar %}
326:         <div class="imd-face-kpi"><strong>{{ RADAR.composition.members_available|default('—') }} / {{ RADAR.composition.members_expected|default('—') }}</strong><span>{{ t('Input coverage','输入覆盖') }}</span></div>
327:         {% elif RADAR %}
328:         {% set _live = (D.risk.scares or []) | rejectattr('band', 'equalto', 'calm') | list %}
329:         <div class="imd-face-kpi"><strong>{{ _live|length }} / {{ (D.risk.scares or [])|length }}</strong><span>{{ t('risk families above calm','高于平静的风险类别') }}</span></div>
330:         {% else %}
331:         <div class="imd-face-kpi"><strong>{% if D.risk.h21 is not none %}{{ (D.risk.h21*100)|round(1) }}%{% else %}N/A{% endif %}</strong><span>{{ t(D.risk.dominant_en or 'No dominant scare',D.risk.dominant_zh or '无主导风险') }}</span></div>
332:         {% endif %}
333:       </button>
334:       <button class="imd-card imd-face" data-dialog="dlg-health" aria-haspopup="dialog">
335:         <div class="imd-face-top"><span class="imd-face-icon">✓</span><span class="imd-open">{{ t('Open receipt','打开凭证') }} ↗</span></div>
336:         <h3>{{ t('Source health & provenance','数据健康与来源') }}</h3><p>{{ t('Official-source targets, operational fallbacks, timestamps and access blockers.','官方目标源、运行备用源、时间戳与访问障碍。') }}</p>
337:         <div class="imd-kpi-grid">{% for h in D.health %}<div class="imd-mini"><span>{{ t(h.label_en,h.label_zh) }}</span><strong class="{{ h.state }}">{{ h.state|title }}</strong></div>{% endfor %}</div>
338:       </button>
339:     </div>
340:   </section>
341: 
342:   <section class="imd-section">
343:     <div class="imd-section-head"><h2>{{ t('60-session decision path','60交易日决策路径') }}</h2><p>{{ t('Same descriptive scoring rule through history; the current risk-state adjustment is excluded from prior points.','历史沿用同一描述性规则；过往点位不含当前风险状态调整。') }}</p></div>
344:     <div class="imd-card imd-chart-card">
345:       <div class="imd-chart-wrap" role="img" aria-label="60-session decision score history">
346:         {% if D.history.points %}
347:         <svg class="imd-chart" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
348:           <defs><linearGradient id="scoreFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--link)" stop-opacity=".24"/><stop offset="1" stop-color="var(--link)" stop-opacity="0"/></linearGradient></defs>
349:           <polygon points="0,100 {{ D.history.points }} 100,100"></polygon><polyline points="{{ D.history.points }}"></polyline>
350:         </svg>
351:         {% else %}<div class="na" style="padding:20px">{{ t('History unavailable','历史不可用') }}</div>{% endif %}
352:       </div>
353:       <div class="imd-chart-meta"><span>{{ D.history.start or '—' }}</span><span>{{ t('range','区间') }} {{ D.history.min or '—' }}–{{ D.history.max or '—' }}</span><span>{{ D.history.end or '—' }}</span></div>
354:     </div>
355:   </section>
356: 
357:   <section class="imd-section">
358:     <div class="imd-section-head"><h2>{{ t('Local macro lenses','本地宏观视角') }}</h2><p>{{ t('Country-specific questions, not generic labels with the flag changed.','国家专属问题，而非仅替换国旗的通用标签。') }}</p></div>
359:     <div class="imd-lenses">
360:       {% for lens in D.lenses %}
361:       <article class="imd-card imd-lens">
362:         <h3>{{ t(lens.title_en,lens.title_zh) }}</h3><p>{{ t(lens.why_en,lens.why_zh) }}</p>
363:         <div class="imd-lens-v{% if not lens.available %} na{% endif %}">{{ lens.value }}</div>
364:         <div class="imd-lens-src"><a href="{{ lens.source_url }}" target="_blank" rel="noopener">{{ lens.source }}</a></div>
365:       </article>
366:       {% endfor %}
367:     </div>
368:   </section>
369: 
370:   <section class="imd-section">
371:     <div class="imd-section-head"><h2>{{ t('Verified policy calendar','已核实政策日历') }}</h2><p>{{ t('Past dates show a released state; the dashboard does not invent the decision outcome.','过去日期显示已发布状态；看板不虚构决议结果。') }}</p></div>
372:     <div class="imd-calendar">
373:       {% for event in D.events %}
374:       <article class="imd-card imd-event">
375:         <div class="imd-event-date">{{ event.date }}</div>
376:         <div><h3>{{ t(event.name_en,event.name_zh) }}</h3><p>{{ t(event.outcome_en,event.outcome_zh) }} · <a href="{{ event.source }}" target="_blank" rel="noopener">{{ t('official calendar','官方日历') }}</a></p></div>
377:         <span class="imd-chip {{ event.state }}">{{ event.state|title }}</span>
378:       </article>
379:       {% else %}<div class="imd-card na">{{ t('No verified dates available.','暂无已核实日期。') }}</div>{% endfor %}
380:     </div>
381:   </section>
382: 
383:   <section class="imd-section">
384:     <div class="imd-section-head"><h2>{{ t('Source health & data contract','数据健康与数据契约') }}</h2><p>{{ t('Official where practical; every fallback and gap remains visible.','尽可能采用官方源；每项备用源与缺口均保持可见。') }}</p></div>
385:     <div class="imd-card imd-health">
386:       <table class="imd-table">
387:         <thead><tr><th>{{ t('Provider','提供方') }}</th><th>{{ t('Role','用途') }}</th><th>{{ t('Cadence','频率') }}</th><th>{{ t('Access','访问') }}</th><th>{{ t('Status','状态') }}</th></tr></thead>
388:         <tbody>{% for src in D.sources %}<tr><td><a href="{{ src.url }}" target="_blank" rel="noopener">{{ src.provider }}</a></td><td class="source-role">{{ src.role }}</td><td>{{ src.cadence }}</td><td>{{ src.access }}</td><td>{{ src.status }}</td></tr>{% endfor %}</tbody>
389:       </table>
390:     </div>
391:     <div class="imd-caveat"><b>{{ t('Known limitation:','已知限制：') }}</b> {{ t(D.caveat_en,D.caveat_zh) }}</div>
392:   </section>
393: 
394:   <section class="imd-section">
395:     <div class="imd-section-head"><h2>{{ t('Where next','下一站') }}</h2><p>{{ t('All five dashboards share this contract and interaction model.','五个看板共享此数据契约与交互模型。') }}</p></div>
396:     <div class="imd-next">
397:       <a href="intl.html">{{ t('World comparison','全球对比') }}</a>
398:       {% for n in D.navigation %}<a href="{{ n.route }}" class="{% if n.active %}active{% endif %}">{{ n.name }}</a>{% endfor %}
399:     </div>
400:   </section>
401:   <footer class="imd-footer"><span>MastermindX · {{ D.schema }}</span><span>{{ t('Descriptive research, not investment advice.','描述性研究，不构成投资建议。') }}</span></footer>
402: </main>
403: 
404: {% macro dialog(id,title_en,title_zh) -%}
405: <div class="imd-dlg" id="{{ id }}" role="dialog" aria-modal="true" aria-labelledby="{{ id }}-title" aria-hidden="true">
406:   <div class="imd-backdrop" data-close></div>
407:   <div class="imd-panel" tabindex="-1">
408:     <div class="imd-dlg-head"><h2 id="{{ id }}-title">{{ t(title_en,title_zh) }}</h2><button class="imd-close" data-close aria-label="Close dialog">×</button></div>
409:     <div class="imd-dlg-body">{{ caller() }}</div>
410:   </div>
411: </div>
412: {%- endmacro %}
413: 
414: {% call dialog('dlg-regime','Regime & decision receipt','周期与决策凭证') %}
415: <div class="imd-cols">
416:   <div class="imd-receipt"><h3>{{ t('Current regime','当前周期') }}</h3><p>{{ D.regime.name }} · {{ D.regime.quad }} · {{ t('confidence','置信度') }} {{ (D.regime.confidence*100)|round(1) }}% · {{ t('liquidity','流动性') }} {{ D.regime.liquidity }}</p></div>
417:   <div class="imd-receipt"><h3>{{ t('Current action','当前行动') }}</h3><p>{{ t(D.decision.action_en,D.decision.action_zh) }}</p></div>
418: </div>
419: <h3 style="margin-top:18px">{{ t('Score construction','分数构成') }}</h3>
420: <div class="imd-breakdown">{% for key,val in D.decision.parts.items() %}<div class="imd-part"><span>{{ key|replace('_',' ')|title }}</span><div class="imd-bar"><i style="width:{{ [val|abs*3,100]|min }}%"></i></div><b>{{ '%+.1f'|format(val) }}</b></div>{% endfor %}</div>
421: <p class="imd-method">{{ t(D.decision.method_en,D.decision.method_zh) }}</p>
422: {% endcall %}
423: 
424: {% call dialog('dlg-economy','Inflation, growth & labour evidence','通胀、增长与就业证据') %}
425: <div class="imd-cols">{% for m in D.metrics if m.key in ['cpi_yoy','gdp_yoy','unemployment'] %}<div class="imd-receipt"><h3>{{ t(m.label_en,m.label_zh) }}</h3><p><b>{{ m.value }}</b><br>{{ t('Release period','发布期') }}: {{ m.asof or t('unavailable','不可用') }}</p></div>{% endfor %}</div>
426: <div class="imd-caveat">{{ t('A missing or stale release is a state, not zero. It cannot silently vote in the regime.','缺失或陈旧发布是一种状态，并非零值；不得无声参与周期投票。') }}</div>
427: {% endcall %}
428: 
429: {% call dialog('dlg-policy','Policy monitor','政策监测') %}
430: <div class="imd-cols">
431:   <div class="imd-receipt"><h3>{{ D.policy.bank }}</h3><p>{{ t('Policy / short rate','政策/短端利率') }}: <b>{{ value(D.policy.rate,'%') }}</b><br>{{ t('10y minus short rate','10年期减短端') }}: <b>{{ value(D.policy.curve,'pp') }}</b></p></div>
432:   <div class="imd-receipt"><h3>{{ t('Interpretation','解读') }}</h3><p>{{ t('The policy monitor reads the rate, curve, inflation and credit transmission together. A meeting headline alone does not change the regime.','政策监测同时读取利率、曲线、通胀与信贷传导；单一会议头条不会改变周期。') }}</p></div>
433: </div>
434: <h3 style="margin-top:18px">{{ t('Verified decisions','已核实决议日') }}</h3>
435: {% for event in D.events %}<div class="imd-condition"><b>{{ loop.index }}</b><span>{{ event.date }} · {{ t(event.outcome_en,event.outcome_zh) }}</span></div>{% endfor %}
436: {% endcall %}
437: 
438: {% call dialog('dlg-market','Rates, FX & market context','利率、汇率与市场背景') %}
439: <div class="imd-cols">{% for m in D.metrics if m.key in ['yield_10y','curve','fx','fx_strength_3m','drawdown','realvol'] %}<div class="imd-receipt"><h3>{{ t(m.label_en,m.label_zh) }}</h3><p><b>{{ m.value }}</b>{% if m.asof %}<br>{{ t('Release period','发布期') }}: {{ m.asof }}{% endif %}</p></div>{% endfor %}</div>
440: <div class="imd-caveat">{{ t(D.scope_en,D.scope_zh) }}</div>
441: {% endcall %}
442: 
443: {% call dialog('dlg-risk','Risk evidence' if _qualified_radar else 'Calibrated risk receipt','风险证据' if _qualified_radar else '校准风险凭证') %}
444: <div class="imd-cols">
445:   {% if _qualified_radar %}
446:   <div class="imd-receipt"><h3>{{ t('Forecast not available','预测暂不可用') }}</h3><p>{{ t('The current inputs do not provide a calibrated pullback forecast.','当前输入不提供经校准的回撤预测。') }}</p></div>
447:   <div class="imd-receipt"><h3>{{ t('Input reading','输入读数') }}</h3><p><b>{{ t('Reading unavailable','读数暂缺') if not RADAR.composition.score_current else (t('Partial reading','输入不完整') if RADAR.composition.status == 'PARTIAL' else t('Descriptive reading','描述性读数')) }}</b><br>{{ t(RADAR.label_en,RADAR.label_zh) }}</p></div>
448:   {% else %}
449:   <div class="imd-receipt"><h3>{{ t('21-session pullback probability','21交易日回撤概率') }}</h3><p><b>{% if D.risk.h21 is not none %}{{ (D.risk.h21*100)|round(1) }}%{% else %}N/A{% endif %}</b><br>{{ D.risk.measure or t('Calibration unavailable','校准不可用') }}</p></div>
450:   <div class="imd-receipt"><h3>{{ t('Risk state','风险状态') }}</h3><p><b>{{ D.risk.state or 'N/A' }}</b><br>{{ t(D.risk.dominant_en or 'No dominant scare',D.risk.dominant_zh or '无主导风险') }}</p></div>
451:   {% endif %}
452: </div>
453: <h3 style="margin-top:18px">{{ t('Risk drivers','风险驱动') if _qualified_radar else t('Active scare families','活跃风险类别') }}</h3>
454: <div class="imd-cols">{% for scare in D.risk.scares %}<div class="imd-receipt"><h3>{{ t(scare.label_en,scare.label_zh) }}</h3><p>{{ t('Score','分数') }} {{ scare.score }} · {{ scare.band }}{% if scare.firing_legs %}<br>{{ scare.firing_legs|length }} {{ t('confirming legs','项确认指标') }}{% endif %}</p></div>{% else %}<div class="imd-receipt na">{{ t('Risk observations unavailable','风险观测暂缺') if _qualified_radar else t('No calibrated scare data','无校准风险数据') }}</div>{% endfor %}</div>
455: {% endcall %}
456: 
457: {% call dialog('dlg-health','Source health & provenance','数据健康与来源') %}
458: <div class="imd-cols">{% for h in D.health %}<div class="imd-receipt"><h3>{{ t(h.label_en,h.label_zh) }} <span class="imd-chip {{ h.state }}">{{ h.state }}</span></h3><p>{{ t('Release period','发布期') }}: {{ h.asof or t('unavailable','不可用') }}{% if h.age_days is not none %}<br>{{ h.age_days }} {{ t('days old','天前') }}{% endif %}</p></div>{% endfor %}</div>
459: <div class="imd-caveat"><b>{{ t('Known limitation:','已知限制：') }}</b> {{ t(D.caveat_en,D.caveat_zh) }}</div>
460: {% endcall %}
461: 
462: <script>
463: (function(){
464:   'use strict';
465:   var last=null,closeTimer=null;
466:   function focusables(d){return Array.prototype.slice.call(d.querySelectorAll('button,[href],input,select,textarea,[tabindex]:not([tabindex="-1"])')).filter(function(x){return !x.disabled&&x.offsetParent!==null;});}
467:   function openDialog(id,trigger){
468:     var d=document.getElementById(id);if(!d)return;last=trigger||document.activeElement;
469:     if(closeTimer){clearTimeout(closeTimer);closeTimer=null}
470:     d.classList.add('open');d.setAttribute('aria-hidden','false');document.body.classList.add('imd-lock');
471:     requestAnimationFrame(function(){d.classList.add('in');var f=focusables(d);(f[0]||d.querySelector('.imd-panel')).focus();});
472:   }
473:   function closeDialog(d){
474:     if(!d)return;d.classList.remove('in');d.setAttribute('aria-hidden','true');document.body.classList.remove('imd-lock');
475:     closeTimer=setTimeout(function(){d.classList.remove('open');if(last&&last.focus)last.focus();},220);
476:   }
477:   document.querySelectorAll('[data-dialog]').forEach(function(b){b.addEventListener('click',function(){openDialog(b.getAttribute('data-dialog'),b);});});
478:   document.querySelectorAll('.imd-dlg [data-close]').forEach(function(b){b.addEventListener('click',function(){closeDialog(b.closest('.imd-dlg'));});});
479:   document.addEventListener('keydown',function(e){
480:     var d=document.querySelector('.imd-dlg.open');if(!d)return;
481:     if(e.key==='Escape'){e.preventDefault();closeDialog(d);return}
482:     if(e.key==='Tab'){var f=focusables(d);if(!f.length)return;var first=f[0],end=f[f.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();end.focus()}else if(!e.shiftKey&&document.activeElement===end){e.preventDefault();first.focus()}}
483:   });
484: })();
485: </script>
486: <script src="theme.js"></script>
487: </body>
488: </html>
```

## REPORTED TEST/EVIDENCE: RRU_COMPOSITION_ACCEPTANCE_2026_09_08.py
```
"""Actual-module, synthetic-input composition-to-consumer acceptance; no product writes."""
from __future__ import annotations
import argparse
import ast
from contextlib import ExitStack
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import unittest
from unittest.mock import patch
import numpy as np
import pandas as pd
from jinja2 import Environment, DictLoader, ChainableUndefined

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from engine import risk_radar_intl as radar, market_state, risk_radar_recovery as recovery
from engine import risk_radar_intl_audit as radar_audit
from engine import risk_radar_intl_tune as radar_tune
from engine import international_macro_dashboard as intl_dashboard
from scripts import build_international_macro as intl_builder
# Test-only immutable source selection; historical receipts retain their default pin.
import os
PIN = os.environ.get("RRU_SOURCE_PIN", "eb9e91961ddc4f3043d0dad358602525e66eccda")
if len(PIN) != 40 or any(c not in "0123456789abcdef" for c in PIN):
    raise ValueError("RRU_SOURCE_PIN must be a full immutable lowercase commit SHA")
PATHS = ("engine/risk_radar_intl.py", "engine/market_state.py",
         "engine/risk_radar_recovery.py", "templates/_risk_radar_card.html.j2")

def committed(path):
    p = subprocess.run(["git", "show", f"{PIN}:{path}"], cwd=ROOT,
                       capture_output=True, check=True, timeout=30)
    return p.stdout.decode()

SOURCES = {path: committed(path) for path in PATHS}
TEMPLATE = SOURCES[PATHS[-1]]
RENDER_SOURCES = {PATHS[-1]: TEMPLATE}
RUNNER_SOURCES = {}
RUNNER_PATHS = {"engine/intl_run.py", "scripts/build_china.py", "scripts/build_hk.py", "scripts/build_canada.py", "scripts/build_china_risk_state.py"}

def apply_bundle(bundle):
    global TEMPLATE
    modules = {PATHS[0]: radar, PATHS[1]: market_state, PATHS[2]: recovery,
               "engine/risk_radar_intl_audit.py": radar_audit,
               "engine/risk_radar_intl_tune.py": radar_tune,
               "engine/international_macro_dashboard.py": intl_dashboard,
               "scripts/build_international_macro.py": intl_builder}
    for path, entry in bundle.items():
        text = SOURCES.get(path) or committed(path)
        if hashlib.sha256(text.encode()).hexdigest() != entry["base_sha256"]:
            raise ValueError(f"Wrong source identity: {path}")
        for delta in entry["replacements"]:
            if text.count(delta["old"]) != 1:
                raise ValueError(f"Nonunique replacement: {path}")
            text = text.replace(delta["old"], delta["new"], 1)
        if path not in modules:
            if path in RUNNER_PATHS:
                ast.parse(text)
                RUNNER_SOURCES[path] = text
                continue
            if not path.startswith("templates/"):
                raise ValueError(f"Unsupported research bundle path: {path}")
            RENDER_SOURCES[path] = text
            if path == PATHS[-1]:
                TEMPLATE = text
            continue
        nodes = [n for n in ast.parse(text).body if isinstance(n, ast.FunctionDef)
                 and n.name in entry["functions"]]
        assert {n.name for n in nodes} == set(entry["functions"])
        future = ast.ImportFrom(module="__future__", names=[ast.alias(name="annotations")], level=0)
        code = ast.fix_missing_locations(ast.Module(body=[future, *nodes], type_ignores=[]))
        exec(compile(code, path, "exec"), modules[path].__dict__)

INDEX = pd.bdate_range("2023-01-02", periods=620)
BENCH = pd.Series(np.linspace(100, 140, len(INDEX)), index=INDEX)

def fixture(profile):
    codes = sorted({c for _, members, _ in profile.comp_legs for c in members})
    rng = np.random.default_rng(20260908)
    return {c: pd.Series(rng.uniform(.1, .9, len(INDEX)), index=INDEX) for c in codes}

def compute(profile, sub, bench=BENCH):
    with ExitStack() as stack:
        stack.enter_context(patch.object(radar, "_read", return_value=bench))
        stack.enter_context(patch.object(radar, "_sub_legs", return_value=sub))
        stack.enter_context(patch.object(radar, "_gate_series", return_value=pd.Series(True, index=INDEX)))
        stack.enter_context(patch.object(radar, "_calib", side_effect=lambda p, *a:
            dict(bands=dict(radar._BANDS), prob_cal=p.prob_cal, prob_base=p.prob_base)))
        return radar.compute(profile)

def project(out):
    with patch.object(market_state, "_rr_scorecard_track", return_value=None):
        rd = market_state._radar_to_rd(out)
    with patch.object(recovery, "_liquidity_catalysts", return_value=[]), \
         patch.object(recovery, "_market_catalysts", return_value=None):
        rd["recovery"] = recovery.assess({"risk_radar": out})
    return rd

def render(rd):
    env = Environment(loader=DictLoader({"card": TEMPLATE}),
                      undefined=ChainableUndefined, autoescape=True)
    return env.get_template("card").module.risk_radar_card(rd, [])

class CompositionAcceptance(unittest.TestCase):
    pass

def case_test(profile, case):
    def test(self):
        sub = fixture(profile)
        group = max(profile.comp_legs, key=lambda item: len(item[1]))[1]
        if case == "member_missing":
            sub[group[0]].iloc[-1] = np.nan
        elif case == "group_missing":
            for code in group:
                sub[code].iloc[-1] = np.nan
        elif case in ("all_missing", "old_score"):
            for series in sub.values():
                series.iloc[-1 if case == "all_missing" else -5:] = np.nan
        elif case == "restored":
            for code in group:
                sub[code].iloc[-20:-10] = np.nan
        elif case == "nonfinite":
            sub[group[0]].iloc[-1] = np.inf
        elif case == "structural_missing":
            del sub[group[0]]
        out = compute(profile, sub, None if case == "no_benchmark" else BENCH)
        self.assertIn("composition", out, "Producer must supply input composition")
        q = out["composition"]
        wanted = "UNAVAILABLE" if case in ("all_missing", "old_score", "no_benchmark") else (
            "COMPLETE" if case in ("complete", "restored") else "PARTIAL")
        self.assertEqual(q["status"], wanted)
        self.assertEqual(q["freshness"], "not_assessed")
        self.assertEqual(q["groups_expected"], len(profile.comp_legs))
        self.assertEqual(q["members_expected"], sum(len(x[1]) for x in profile.comp_legs))
        self.assertEqual(q["comparison_comparable"], case == "complete")
        self.assertEqual(q["members_available"], sum(len(x["present"]) for x in q["groups"]))
        rd = project(out)
        self.assertEqual(rd.get("composition"), q)
        html = render(rd)
        self.assertIn("Input coverage", html)
        self.assertIn("输入覆盖", html)
        if case != "complete":
            self.assertFalse((rd.get("recovery") or {}).get("receding", False))
            self.assertIn("Recovery comparison unavailable", html)
        if wanted == "UNAVAILABLE":
            self.assertIsNone(out.get("state"))
            self.assertIsNone(out.get("top_score"))
            self.assertIsNone(rd.get("dd21"))
            self.assertIn("Reading unavailable", html)
            self.assertNotIn("rrx-calm", html)
        if case not in ("all_missing", "old_score", "no_benchmark", "nonfinite"):
            self.assertIsNotNone(out.get("top_score"))
            self.assertIsNone(rd.get("dd21"), "Unreviewed old calibration is not a current forecast")
            self.assertIsNone(out.get("drawdown_prob"))
            self.assertIsNone(out.get("gross_factor"))
            self.assertEqual(rd.get("legacy_drawdown_prob"),
                             out["legacy_calibration_reference"]["drawdown_prob"])
        json.dumps(out, allow_nan=False)
    return test

for p in radar.PROFILES.values():
    for case in ("complete", "member_missing", "group_missing", "all_missing",
                 "old_score", "restored", "nonfinite", "structural_missing", "no_benchmark"):
        setattr(CompositionAcceptance, f"test_{p.key}_{case}", case_test(p, case))

class LegacyAcceptance(unittest.TestCase):
    def test_legacy_projection_retains_numbers_and_authority(self):
        out = dict(state="elevated", top_score=88, can_force=True,
                   gross_factor=.78, drawdown_prob=dict(h21=.4), market="us")
        rd = project(out)
        self.assertEqual((rd["dd21"], rd["gross"], rd["can_force"]), (.4, .78, True))

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--bundle", type=Path)
    parser.add_argument("--candidate", action="store_true", help="Use the existing in-memory candidate module")
    args = parser.parse_args()
    before = {path: (ROOT / path).read_bytes() for path in PATHS[:3]}
    for path, raw in before.items():
        if raw.decode() != SOURCES[path]:
            raise SystemExit(f"Current source differs from the pinned fixture: {path}")
    if args.bundle and args.candidate:
        parser.error("Choose either --bundle or --candidate")
    if args.bundle:
        apply_bundle(json.loads(args.bundle.read_text()))
    if args.candidate:
        from RRU_COMPOSITION_BUILD_BUNDLE_2026_09_08 import bundle
        apply_bundle(bundle)
    suite = unittest.TestSuite([
        unittest.defaultTestLoader.loadTestsFromTestCase(CompositionAcceptance),
        unittest.defaultTestLoader.loadTestsFromTestCase(LegacyAcceptance)])
    result = unittest.TextTestRunner(verbosity=1).run(suite)
    unchanged = all((ROOT / p).read_bytes() == raw for p, raw in before.items())
    print(json.dumps(dict(tests=result.testsRun, failures=len(result.failures),
          errors=len(result.errors), source_unchanged=unchanged,
          candidate=bool(args.bundle or args.candidate), synthetic_inputs=True)))
    raise SystemExit(0 if result.wasSuccessful() and unchanged else 1)

if __name__ == "__main__":
    main()

```

## REPORTED TEST/EVIDENCE: RRU_REFERENCE_WINDOW_TESTS_2026_09_09.py
```
"""Reference-union membership tests against actual profiles and consumers."""
from __future__ import annotations
import json
import unittest
import RRU_COMPOSITION_ACCEPTANCE_2026_09_08 as a
import RRU_COMPOSITION_BUILD_BUNDLE_2026_09_08 as candidate

OBSERVED = []
class ReferenceWindowTests(unittest.TestCase):
    pass

def case_test(profile, case):
    def test(self):
        sub = a.fixture(profile)
        if case == 'outside':
            next(iter(sub.values())).iloc[0] = a.np.nan
        elif case == 'member':
            next(iter(sub.values())).iloc[-100] = a.np.nan
        else:
            for values in sub.values():
                values.iloc[-100] = a.np.nan
        out = a.compute(profile, sub)
        q = out['composition']
        OBSERVED.append({'market': profile.key, 'case': case,
            'comparison_comparable': q['comparison_comparable'],
            'recent_incomplete': q['comparison_incomplete_sessions'],
            'reference_sessions': q.get('comparison_reference_sessions'),
            'reference_incomplete': q.get('comparison_reference_incomplete_sessions')})
        self.assertEqual(q['status'], 'COMPLETE')
        self.assertTrue(q['score_current'])
        self.assertEqual(q['comparison_incomplete_sessions'], 0)
        self.assertEqual(q['comparison_comparable'], case == 'outside',
            'Latest-30 completeness does not establish the ranks reference composition')
        rd = a.project(out)
        self.assertEqual(rd['composition'], q)
        if case != 'outside':
            self.assertFalse((rd.get('recovery') or {}).get('receding', False))
            self.assertIn('Recovery comparison unavailable', a.render(rd))
        self.assertEqual(q['freshness'], 'not_assessed')
        self.assertEqual(q['calibration_status'], 'unreviewed_corrected_construction')
    return test

for profile in a.radar.PROFILES.values():
    for case in ('member', 'all_null', 'outside'):
        setattr(ReferenceWindowTests, f'test_{profile.key}_{case}', case_test(profile, case))

if __name__ == '__main__':
    before = {p: (a.ROOT / p).read_bytes() for p in a.PATHS[:3]}
    a.apply_bundle(candidate.bundle)
    result = unittest.TextTestRunner(verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromTestCase(ReferenceWindowTests))
    unchanged = all((a.ROOT / p).read_bytes() == raw for p, raw in before.items())
    print(json.dumps({'tests': result.testsRun, 'failures': len(result.failures),
        'errors': len(result.errors), 'source_unchanged': unchanged,
        'synthetic_only': True, 'cases': OBSERVED}))
    raise SystemExit(0 if result.wasSuccessful() and unchanged else 1)

```

## REPORTED TEST/EVIDENCE: RRU_LEGACY_COHORT_TESTS_2026_09_09.py
```
"""Synthetic actual-audit/tuner cohort tests; no ledger IO or policy effects."""
from __future__ import annotations
from contextlib import ExitStack
from copy import deepcopy
from pathlib import Path
import json
import argparse
import unittest
from unittest.mock import patch
import RRU_COMPOSITION_ACCEPTANCE_2026_09_08 as a
import RRU_COMPOSITION_BUILD_BUNDLE_2026_09_08 as candidate
from engine import risk_radar_intl_audit as audit, risk_radar_intl_tune as tuner

ABSENT = object()
MODERN = {'method': 'available_group_weight.v1', 'status': 'COMPLETE',
          'calibration_status': 'unreviewed_corrected_construction'}

def rows(n=50, composition=ABSENT):
    result = []
    for i, date in enumerate(a.pd.bdate_range('2026-05-01', periods=n)):
        alert = i % 5 == 0
        hit = alert if composition is ABSENT else not alert
        r = {'asof': str(date.date()), 'state': 'risk-off' if alert else 'calm',
             'alert': alert, 'graded': {'any_dd5_within_h21': hit,
             'outcome': ('true_positive' if hit else 'false_positive') if alert else ('calm_dd' if hit else 'calm_quiet'),
             'fwd_dd': {h: -.06 if hit else .01 for h in audit.HORIZONS}}}
        if composition is not ABSENT:
            r['composition'] = deepcopy(composition)
        result.append(r)
    return result

class MemorySink:
    def __init__(self):
        self.payloads = []
    def write_text(self, text):
        self.payloads.append(text)
        return len(text)

class CohortTests(unittest.TestCase):
    def invoke(self, method, fixture):
        before = deepcopy(fixture)
        sink = MemorySink()
        with ExitStack() as stack:
            stack.enter_context(patch.object(audit, '_path', return_value=Path('SYNTHETIC_UNUSED')))
            stack.enter_context(patch.object(audit, '_read', return_value=fixture))
            stack.enter_context(patch.object(audit, '_write', side_effect=AssertionError('No ledger write')))
            stack.enter_context(patch.object(audit, '_log_can_force_governance', side_effect=AssertionError('No grant write')))
            stack.enter_context(patch.object(tuner, '_calib_path', return_value=sink))
            stack.enter_context(patch.object(tuner, '_log_review', return_value=None))
            stack.enter_context(patch.object(tuner, '_append_governance_a6', return_value=None))
            p = a.radar.CN_PROFILE
            stack.enter_context(patch.object(tuner.R, '_calib', return_value=deepcopy(
                {'prob_cal': p.prob_cal, 'prob_base': p.prob_base})))
            result = (tuner.tune(p) if method == 'tune' else
                      audit.scorecard('cn', log_governance=False) if method == 'scorecard' else
                      audit.realized_odds('cn'))
        self.assertEqual(fixture, before, 'Cohort selection must not rewrite issued rows')
        return result, sink.payloads

    def test_legacy_scorecard_control_keeps_actual_counts(self):
        result, _ = self.invoke('scorecard', rows())
        self.assertEqual((result['n_graded'], result['n_alerts']), (50, 10))
        self.assertEqual(result['base_rate_dd5_h21'], .2)
        self.assertEqual(result['realized_odds']['risk-off']['h21'], 1.0)

    def test_modern_only_cannot_supply_legacy_eligibility(self):
        result, _ = self.invoke('scorecard', rows(composition=MODERN))
        self.assertEqual(result['n_graded'], 0)
        self.assertFalse(result['can_force'])

    def test_mixed_scorecard_keeps_legacy_statistics(self):
        old, _ = self.invoke('scorecard', rows())
        mixed, _ = self.invoke('scorecard', rows() + rows(100, MODERN))
        for key in ('n_graded', 'base_rate_dd5_h21', 'n_alerts', 'can_force',
                    'by_state', 'realized_odds', 'recent_mistakes'):
            self.assertEqual(mixed[key], old[key], key)
        self.assertEqual(mixed.get('excluded_composition_rows'), 100)

    def test_realized_odds_share_the_legacy_cohort(self):
        old, _ = self.invoke('odds', rows())
        mixed, _ = self.invoke('odds', rows() + rows(100, MODERN))
        self.assertEqual(mixed, old)
        modern, _ = self.invoke('odds', rows(composition=MODERN))
        self.assertEqual(modern, {})

    def test_modern_only_cannot_start_legacy_tuning(self):
        result, writes = self.invoke('tune', rows(100, MODERN))
        self.assertEqual(result['status'], 'accruing')
        self.assertEqual(result['n_graded'], 0)
        self.assertEqual(writes, [])

    def test_mixed_tuner_sample_and_brier_share_legacy_cohort(self):
        old, old_writes = self.invoke('tune', rows())
        mixed, mixed_writes = self.invoke('tune', rows() + rows(100, MODERN))
        for key in ('status', 'n_graded', 'brier', 'realized'):
            self.assertEqual(mixed.get(key), old.get(key), key)
        self.assertEqual(mixed.get('excluded_composition_rows'), 100)
        self.assertEqual(len(mixed_writes), len(old_writes))
        for left, right in zip(old_writes, mixed_writes):
            old_payload, mixed_payload = json.loads(left), json.loads(right)
            for key in ('prob_cal', 'n_graded', 'brier_before', 'brier_after'):
                self.assertEqual(old_payload[key], mixed_payload[key], key)

    def test_explicit_invalid_composition_never_becomes_implicit_legacy(self):
        for value in (None, {}, [], True, {'method': 'future_unknown'}):
            with self.subTest(composition=value):
                result, _ = self.invoke('scorecard', rows(composition=value))
                self.assertEqual(result['n_graded'], 0)

if __name__ == '__main__':
    before = {p: (a.ROOT / p).read_bytes() for p in (
        'engine/risk_radar_intl_audit.py', 'engine/risk_radar_intl_tune.py')}
    parser = argparse.ArgumentParser()
    parser.add_argument('--baseline', action='store_true')
    args = parser.parse_args()
    if not args.baseline:
        a.apply_bundle(candidate.bundle)
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(CohortTests))
    unchanged = all((a.ROOT / p).read_bytes() == raw for p, raw in before.items())
    print(json.dumps({'tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
                     'source_unchanged': unchanged, 'ledger_io': False, 'synthetic_only': True}))
    raise SystemExit(0 if result.wasSuccessful() and unchanged else 1)

```

## REPORTED TEST/EVIDENCE: RRU_FORCE_APPLICABILITY_TESTS_2026_09_09.py
```
"""Synthetic force-compatibility proof through actual functions and source assignments.

Runner probes execute the exact assignment AST, not an entire production pipeline.
No ledger, feed, policy store, real position, or production writer is used.
"""
from __future__ import annotations
import ast
from copy import deepcopy
import json
import unittest
from unittest.mock import patch
import RRU_COMPOSITION_ACCEPTANCE_2026_09_08 as a
import RRU_COMPOSITION_BUILD_BUNDLE_2026_09_08 as candidate

RUNNERS = ('engine/intl_run.py', 'scripts/build_china.py', 'scripts/build_hk.py',
           'scripts/build_canada.py', 'scripts/build_china_risk_state.py')

def override(payload, overrides=None):
    entries = [] if overrides is None else overrides
    with patch.object(a.market_state, '_rr_scorecard_track', return_value=None), \
         patch.object(a.recovery, 'assess', return_value=None):
        return a.market_state._radar_override_intl(payload, entries)

def sample(composition=True):
    out = dict(market='cn', state='risk-off', top_score=99, can_force=True,
               forward_log=dict(market='cn', n_graded=200, can_force=True))
    if composition:
        out['composition'] = dict(method='available_group_weight.v1', score_current=True,
            status='COMPLETE', calibration_status='unreviewed_corrected_construction')
    return out

class ForceTests(unittest.TestCase):
    def test_foreign_grant_cannot_override_named_policies_or_mutate_inputs(self):
        policy = dict(policy_id='fixture-only-existing-policy', action='NO_ADD',
                      expiry='2026-10-01', authority_basis='fixture')
        latest = dict(risk_radar=sample(), risk_envelope=dict(policies=[policy]))
        entries = [dict(kind='independent_policy', policy=deepcopy(policy))]
        saved, original_entries = deepcopy(latest), deepcopy(entries)
        rd = override(latest, entries)
        self.assertFalse(rd['can_force'])
        self.assertFalse(rd['binding'])
        self.assertIsNone(rd['ceiling'])
        self.assertEqual(entries, original_entries)
        self.assertEqual(latest, saved)
        self.assertTrue(latest['risk_radar']['forward_log']['can_force'])

    def test_reported_binding_object_cannot_bypass_effective_projection(self):
        out = sample()
        out['authority'] = dict(tier='binding', can_force=True, reason='old-fixture')
        saved = deepcopy(out)
        rd = override(dict(risk_radar=out))
        self.assertFalse(rd['authority']['can_force'])
        self.assertNotEqual(rd['authority']['tier'], 'binding')
        self.assertEqual(out, saved)
        html = a.render(rd)
        self.assertNotIn('Binding guard', html)
        self.assertNotIn('仅调整仓位', html)

def metadata_case(value):
    def test(self):
        out = sample()
        out['composition'] = deepcopy(value)
        saved = deepcopy(out)
        rd = override(dict(risk_radar=out))
        self.assertFalse(rd['can_force'])
        self.assertFalse(rd['binding'])
        self.assertEqual(out, saved)
    return test

for name, value in dict(null=None, empty={}, list=[], boolean=True,
        unknown={'method': 'future.v99'}, reviewed_claim={'method': 'available_group_weight.v1',
        'calibration_status': 'reviewed', 'status': 'COMPLETE', 'score_current': True}).items():
    setattr(ForceTests, 'test_modern_' + name + '_is_not_legacy_permission', metadata_case(value))

def producer_case(profile):
    def test(self):
        sub = a.fixture(profile)
        for values in sub.values():
            values.iloc[-1] = .99
        out = a.compute(profile, sub)
        self.assertIn(out['state'], ('caution', 'elevated', 'risk-off'))
        out['can_force'] = True
        rd = override(dict(risk_radar=out))
        self.assertFalse(rd['can_force'])
        self.assertFalse(rd['binding'])
    return test

for profile in a.radar.PROFILES.values():
    setattr(ForceTests, 'test_producer_' + profile.key, producer_case(profile))

def runner_case(path, modern):
    def test(self):
        raw = getattr(a, 'RUNNER_SOURCES', {}).get(path) or a.committed(path)
        nodes = [n for n in ast.walk(ast.parse(raw)) if isinstance(n, ast.Assign)
                 and len(n.targets) == 1 and isinstance(n.targets[0], ast.Subscript)
                 and isinstance(n.targets[0].slice, ast.Constant)
                 and n.targets[0].slice.value == 'can_force']
        self.assertEqual(len(nodes), 2, 'Every selected runner has exactly two grant assignments')
        for i, node in enumerate(nodes):
            for proposed in (False, True):
                with self.subTest(path=path, assignment=i, grant=proposed):
                    snap = sample(modern)
                    snap['forward_log']['can_force'] = proposed
                    rec = dict(risk_radar=snap)
                    ns = dict(rec=rec, latest=rec, _latest_nightly=rec, latest_live=rec,
                              _sc=snap['forward_log'], sc=snap['forward_log'],
                              can_force=proposed, _rra=a.radar_audit,
                              risk_radar_intl_audit=a.radar_audit)
                    code = ast.fix_missing_locations(ast.Module(body=[node], type_ignores=[]))
                    exec(compile(code, path, 'exec'), ns)
                    self.assertEqual(snap['can_force'], False if modern else proposed)
                    self.assertEqual(snap['forward_log']['can_force'], proposed)
    return test

for i, path in enumerate(RUNNERS):
    for modern in (True, False):
        setattr(ForceTests, f'test_runner_{i}_' + ('modern' if modern else 'legacy'),
                runner_case(path, modern))

def legacy_test(self):
    for state, ceiling in (('caution', 56), ('elevated', 38), ('risk-off', 26)):
        out = sample(False)
        out['state'] = state
        saved = deepcopy(out)
        rd = override(dict(risk_radar=out))
        self.assertTrue(rd['binding'])
        self.assertEqual(rd['ceiling'], ceiling)
        self.assertNotIn('reported_can_force', rd, 'Keep legacy projection free of new provenance fields')
        self.assertEqual(out, saved)
ForceTests.test_legacy_ceiling_and_source_preserved = legacy_test

def record_display_test(self):
    out = sample()
    rd = override(dict(risk_radar=out))
    html = a.render(rd)
    self.assertIn('Earlier construction record', html)
    self.assertNotIn('moving the verdict', html)
    self.assertNotIn('参与定调', html)
    self.assertTrue(out['forward_log']['can_force'])
ForceTests.test_prior_record_is_not_current_force_claim = record_display_test

if __name__ == '__main__':
    from pathlib import Path
    paths = set(candidate.bundle) | set(RUNNERS)
    before = {p: (a.ROOT / p).read_bytes() if (a.ROOT / p).exists() else None for p in paths}
    a.apply_bundle(candidate.bundle)
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ForceTests))
    unchanged = all(((a.ROOT / p).read_bytes() if (a.ROOT / p).exists() else None) == v for p, v in before.items())
    print(json.dumps(dict(tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
                         source_unchanged=unchanged, synthetic_only=True, full_pipeline=False)))
    raise SystemExit(0 if result.wasSuccessful() and unchanged else 1)

```

## REPORTED TEST/EVIDENCE: RRU_FORCE_FULL_CONSUMER_2026_09_09.py
```
"""Full market-state consumer proof; synthetic observations, no policy/ledger IO.

CN_PROFILE's actual component readers are used with a declared no-tape fixture.
Separate harness profiles enable existing independent guards ONLY to exercise
composition; that is not a claim those guards are enabled on the CN product.
"""
from __future__ import annotations
import argparse
from copy import deepcopy
from dataclasses import replace
import importlib
import json
import unittest
from unittest.mock import patch
import RRU_COMPOSITION_ACCEPTANCE_2026_09_08 as a
import RRU_COMPOSITION_BUILD_BUNDLE_2026_09_08 as candidate
from RRU_FORCE_APPLICABILITY_TESTS_2026_09_09 import sample

class FullConsumerTests(unittest.TestCase):
    def setUp(self):
        from engine import market_state_cn
        # Mirror fresh module import binding after installing the in-memory source.
        self.cn = importlib.reload(market_state_cn)
        self.profile = self.cn.CN_PROFILE
        self.latest = dict(date='2026-09-08', conditions=dict(roro=dict(roro_state='risk-on')),
                           risk_radar=sample())
        self.assertIs(self.profile.radar_override, a.market_state._radar_override_intl)

    def run_consumer(self, profile=None, alerts=None):
        saved = deepcopy(self.latest)
        with patch.object(a.market_state, '_rr_scorecard_track', return_value=None), \
             patch.object(a.recovery, '_liquidity_catalysts', return_value=[]), \
             patch.object(a.recovery, '_market_catalysts', return_value=None):
            result = a.market_state.market_state_snapshot(self.latest, frame=None,
                       alerts=alerts, profile=profile or self.profile)
        self.assertIsNotNone(result, 'Full consumer must return a usable result')
        self.assertEqual(self.latest, saved, 'Consumer must not mutate input or policy evidence')
        return result

    def test_actual_cn_profile_preserves_measured_score_for_unpromoted_reading(self):
        result = self.run_consumer()
        self.assertEqual((result['raw_score'], result['score']), (78, 78))
        self.assertEqual(result['score_source'], 'blend')
        self.assertEqual(result['overrides'], [])
        self.assertFalse(result['radar']['binding'])

    def test_actual_cn_profile_preserves_legacy_authorized_ceiling(self):
        self.latest['risk_radar'] = sample(False)
        result = self.run_consumer()
        self.assertEqual((result['raw_score'], result['score']), (78, 26))
        self.assertEqual(result['score_source'], 'radar_ceiling')
        self.assertTrue(result['radar']['binding'])
        self.assertEqual(result['score_caps'][-1]['limit'], 26)

    def test_missing_current_radar_does_not_remove_the_measured_component(self):
        self.latest['risk_radar'].update(state=None, top_score=None)
        self.latest['risk_radar']['composition'].update(status='UNAVAILABLE', score_current=False)
        result = self.run_consumer()
        self.assertEqual(result['score'], result['raw_score'])
        self.assertEqual(result['components'][0]['key'], 'risk')
        self.assertFalse(result['radar']['can_force'])

    def test_actual_cn_profile_does_not_gain_harness_override_authority(self):
        self.assertEqual(self.profile.overrides, frozenset())
        self.latest['conditions']['systemic_stress'] = {'state': 'acute'}
        result = self.run_consumer(alerts=[{'severity': 'act'}])
        self.assertEqual(result['score'], 78)
        self.assertEqual(result['overrides'], [])

def independent_case(kind, limit):
    def test(self):
        profile = replace(self.profile, overrides=frozenset({'alert_act', 'new_regime', 'stress_band', 'dislocation'}))
        alerts = [{'severity': 'act'}] if kind == 'alert' else []
        if kind == 'stress': self.latest['conditions']['systemic_stress'] = {'state': 'acute'}
        if kind == 'regime': self.latest['transition_state'] = 'NEW_REGIME'
        if kind == 'dislocation': self.latest['dislocation'] = dict(dislocation_active=True, verdict='stand_aside')
        result = self.run_consumer(profile, alerts)
        self.assertEqual(result['score'], limit)
        self.assertEqual([v['kind'] for v in result['overrides']], [kind])
        self.assertNotIn('radar_ceiling', [v['kind'] for v in result['score_caps']])
    return test

for kind, limit in (('stress', 41), ('dislocation', 41), ('alert', 59), ('regime', 59)):
    setattr(FullConsumerTests, 'test_independent_harness_' + kind + '_guard_survives', independent_case(kind, limit))

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--original-consumer', action='store_true')
    original = parser.parse_args().original_consumer
    paths = set(candidate.bundle) | {'engine/market_state_cn.py'}
    before = {p:(a.ROOT/p).read_bytes() if (a.ROOT/p).exists() else None for p in paths}
    a.apply_bundle(candidate.bundle)
    text = a.committed('engine/market_state.py') if original else candidate.edited['engine/market_state.py']
    exec(compile(text, 'engine/market_state.py', 'exec'), a.market_state.__dict__)
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(FullConsumerTests))
    unchanged = all(((a.ROOT/p).read_bytes() if (a.ROOT/p).exists() else None)==v for p,v in before.items())
    print(json.dumps(dict(tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
        original_consumer=original, source_unchanged=unchanged, full_consumer=True,
        full_pipeline=False, synthetic_only=True, independent_guards_use_harness_profile=True)))
    raise SystemExit(0 if result.wasSuccessful() and unchanged else 1)

```

## REPORTED TEST/EVIDENCE: RRU_INTL_JOURNEY_TESTS_2026_09_09.py
```
"""Complete international view/adapter/template tests; synthetic, no production IO."""
from __future__ import annotations
from copy import deepcopy
from datetime import date
from functools import lru_cache
import hashlib
import json
import unittest
from unittest.mock import patch
from jinja2 import BaseLoader, Environment, TemplateNotFound
import RRU_COMPOSITION_ACCEPTANCE_2026_09_08 as a
import RRU_COMPOSITION_BUILD_BUNDLE_2026_09_08 as candidate
from scripts import build_international_macro as builder
from engine import international_macro_dashboard as dashboard

TEMPLATE = 'templates/international_macro.html.j2'
BUILDER = 'scripts/build_international_macro.py'
VIEW = 'engine/international_macro_dashboard.py'
LABELS = {'JP': ('Japan', '日本'), 'KR': ('South Korea', '韩国'),
          'EZ': ('Euro Area', '欧元区'), 'GB': ('United Kingdom', '英国'),
          'IN': ('India', '印度')}
READ_SOURCES = {}

class PinnedLoader(BaseLoader):
    def get_source(self, environment, template):
        path = 'templates/' + template
        raw = a.RENDER_SOURCES.get(path) or pinned(path)
        READ_SOURCES[path] = hashlib.sha256(raw.encode()).hexdigest()
        return raw, path, lambda: True

@lru_cache(maxsize=80)
def pinned(path):
    return a.committed(path)

def snapshot(profile, case):
    sub = a.fixture(profile)
    if case == 'partial': next(iter(sub.values())).iloc[-1] = a.np.nan
    if case == 'unavailable':
        for values in sub.values(): values.iloc[-1] = a.np.nan
    return a.compute(profile, sub)

def record(cc, radar):
    en, zh = LABELS[cc]
    return dict(cc=cc, name=en, name_zh=zh, flag='', date='2026-09-09',
        quad='Q1', quad_name='Goldilocks', growth_score=.35, inflation_score=.1,
        confidence=.7, liquidity='neutral', recession_score=15, recession_band='low',
        macro=dict(cpi_yoy=2., gdp_yoy=2.1, unemployment=4., yield_10y=3.,
                   policy_rate=2.5, curve=.5, fx=1., drawdown=-2., realvol=12.),
        macro_asof={k:'2026-08-31' for k in ('cpi_yoy','gdp','unemployment','yield_10y')},
        risk_radar=radar)

def adapt(rec):
    with patch.object(a.market_state, '_rr_scorecard_track', return_value=None):
        return builder._radar_display(rec)

def render(rec, force_direct=False):
    view = dashboard.build_country_view(rec, today=date(2026,9,9))
    dashboard.validate_view(view)
    if force_direct:
        with patch.object(a.market_state, '_rr_scorecard_track', return_value=None):
            rd = a.market_state._radar_to_rd(rec['risk_radar'])
    else:
        rd = adapt(rec)
    env = Environment(loader=PinnedLoader(), autoescape=False,
                      trim_blocks=True, lstrip_blocks=True)
    return view, rd, env.get_template('international_macro.html.j2').render(D=view,RADAR=rd)

class AdapterJourney(unittest.TestCase):
    pass

def adapter_case(profile, case):
    def test(self):
        snap = snapshot(profile, case)
        rec = dict(cc=profile.key.upper(), risk_radar=snap)
        before = deepcopy(rec)
        rd = adapt(rec)
        self.assertIsNotNone(rd, 'Explicit assessment disappears in outer adapter')
        self.assertEqual(rd['composition'], snap['composition'])
        self.assertIsNone(rd['dd21'])
        self.assertFalse(rd['can_force'])
        self.assertEqual(rec, before)
    return test

for profile in a.radar.PROFILES.values():
    for case in ('complete','partial','unavailable'):
        setattr(AdapterJourney, 'test_'+profile.key+'_'+case, adapter_case(profile,case))

class CompletePage(unittest.TestCase):
    pass

def page_case(cc, case):
    def test(self):
        snap = snapshot(a.radar.PROFILES[cc.lower()],case)
        view,rd,html = render(record(cc,snap), force_direct=True)
        self.assertEqual(html.count('class="rrx '),1)
        self.assertNotIn('Calibrated risk monitor',html)
        self.assertNotIn('Calibrated risk receipt',html)
        self.assertNotIn("Odds measured on this market's own history",html)
        self.assertNotIn('current calibrated-risk state',html)
        self.assertIn('Forecast not available',html)
        self.assertIn('Input coverage',html)
        self.assertIsNone(view['risk']['h21'])
        self.assertFalse(view['risk']['calibrated'])
        self.assertEqual(view['risk'].get('composition'),snap['composition'])
        if case=='unavailable': self.assertIn('Reading unavailable',html)
    return test

for cc in dashboard.REGIONS:
    for case in ('complete','partial','unavailable'):
        setattr(CompletePage,'test_'+cc+'_'+case,page_case(cc,case))

class ViewIntegrity(unittest.TestCase):
    def test_modern_caution_does_not_adjust_measured_score(self):
        rec = record('JP', snapshot(a.radar.PROFILES['jp'],'complete'))
        rec['risk_radar']['state']='caution'
        measured = dashboard.decision_score({**rec,'risk_radar':{}})
        self.assertEqual(dashboard.decision_score(rec),measured)

    def test_legacy_caution_keeps_original_adjustment(self):
        rec=record('JP',dict(state='caution',drawdown_prob=dict(h21=.42)))
        score,parts=dashboard.decision_score(rec)
        self.assertEqual(parts['risk_state'],-4.)
        view,rd,html=render(rec)
        self.assertEqual(view['risk']['h21'],.42)
        self.assertTrue(view['risk']['calibrated'])
        self.assertIn('Calibrated risk monitor',html)
        self.assertIsNotNone(rd)
        self.assertNotIn('composition',view['risk'])

    def test_explicit_modern_metadata_never_advertises_raw_old_odds(self):
        for q in (None,{},[],True,{'method':'future'}):
            with self.subTest(metadata=q):
                rec=record('JP',dict(state='caution',composition=q,drawdown_prob=dict(h21=.42)))
                saved=deepcopy(rec)
                view=dashboard.build_country_view(rec,today=date(2026,9,9))
                self.assertIsNone(view['risk']['h21'])
                self.assertFalse(view['risk']['calibrated'])
                self.assertEqual(view['decision']['parts']['risk_state'],0.)
                self.assertEqual(rec,saved)

    def test_composition_is_published_without_aliasing(self):
        rec=record('JP',snapshot(a.radar.PROFILES['jp'],'partial'))
        view=dashboard.build_country_view(rec,today=date(2026,9,9))
        self.assertEqual(view['risk'].get('composition'),rec['risk_radar']['composition'])
        view['risk']['composition']['groups'][0]['missing'].append('changed-copy')
        self.assertNotIn('changed-copy',rec['risk_radar']['composition']['groups'][0]['missing'])

    def test_legacy_absent_snapshot_remains_absent(self):
        self.assertIsNone(adapt(dict(cc='JP')))
        self.assertIsNone(adapt(dict(cc='JP',risk_radar={'state':'calm'})))

    def test_real_adapter_reaches_complete_page(self):
        rec=record('JP',snapshot(a.radar.PROFILES['jp'],'complete'))
        view,rd,html=render(rec)
        self.assertIsNotNone(rd)
        self.assertIn('Input coverage',html)
        self.assertNotIn('Calibrated risk monitor',html)
        json.dumps(view,allow_nan=False)

if __name__=='__main__':
    paths=set(candidate.bundle)|{BUILDER,VIEW,TEMPLATE}
    def state(p):
        f=a.ROOT/p
        return f.read_bytes() if f.exists() else None
    before={p:state(p) for p in paths}
    a.apply_bundle(candidate.bundle)
    suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromTestCase(c)
                           for c in (AdapterJourney,CompletePage,ViewIntegrity))
    result=unittest.TextTestRunner(verbosity=1).run(suite)
    unchanged=all(state(p)==v for p,v in before.items())
    print(json.dumps(dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),
        source_unchanged=unchanged,synthetic_only=True,full_template=True,production=False,
        template_sources=READ_SOURCES)),flush=True)
    raise SystemExit(0 if result.wasSuccessful() and unchanged else 1)

```

## REPORTED TEST/EVIDENCE: RRU_INTL_BUILD_PROOF_2026_09_10.py
```
"""Actual five-route builder; all inputs synthetic, all outputs private research.

Baseline mode restores the original two consumers and complete outer template.
No ledger, live feed, production data, deployed file or authenticated browser is used.
"""
from __future__ import annotations
import argparse
from contextlib import ExitStack
from copy import deepcopy
import hashlib
import json
from pathlib import Path
from unittest.mock import patch
from bs4 import BeautifulSoup
import RRU_INTL_JOURNEY_TESTS_2026_09_09 as j
from lib import config, pages

HERE = Path(__file__).resolve().parent
TEMPLATES = ('international_macro.html.j2', '_risk_radar_card.html.j2',
             '_risk_radar_card.css.j2', '_seo_head.html.j2',
             '_site_nav.html.j2', '_navlinks.html.j2')
ASSETS = ('theme.css', 'product-nav-icons.css', 'navigation-refresh.css',
          'theme.js', 'data_base.js')
CASES = ('complete', 'partial', 'unavailable', 'legacy', 'absent',
         'old_odds', 'metadata_null', 'metadata_empty', 'claimed_reviewed')

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def bind(baseline=False):
    j.a.apply_bundle(j.candidate.bundle)
    for module in (j.a.radar, j.a.market_state, j.a.recovery,
                   j.a.radar_audit, j.a.radar_tune, j.dashboard, j.builder):
        path = ('scripts/' if module is j.builder else 'engine/') + module.__name__.rsplit('.',1)[-1]+'.py'
        raw = j.candidate.edited.get(path) or j.pinned(path)
        if baseline and module in (j.dashboard, j.builder):
            raw = j.pinned(path)
        exec(compile(raw, path, 'exec'), module.__dict__)
    if baseline:
        j.a.RENDER_SOURCES[j.TEMPLATE] = j.pinned(j.TEMPLATE)
    assert j.builder.build_country_view is j.dashboard.build_country_view

def payload(cc, case):
    if case == 'absent':
        return j.record(cc, {})
    if case == 'legacy':
        return j.record(cc, dict(market=cc.lower(), state='caution',
            drawdown_prob=dict(h21=.42), dominant_label_en='Legacy fixture'))
    snap = j.snapshot(j.a.radar.PROFILES[cc.lower()], case)
    if case in ('old_odds','metadata_null','metadata_empty','claimed_reviewed'):
        snap['drawdown_prob'] = dict(h21=.42, measure='Synthetic older record')
        snap['state'] = 'calm'
    if case == 'metadata_null': snap['composition'] = None
    if case == 'metadata_empty': snap['composition'] = {}
    if case == 'claimed_reviewed': snap['composition']['calibration_status'] = 'reviewed'
    return j.record(cc, snap)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--baseline-consumers',action='store_true')
    parser.add_argument('--label',default='candidate-v1')
    args=parser.parse_args()
    if not args.label or any(c not in 'abcdefghijklmnopqrstuvwxyz0123456789-' for c in args.label):
        raise ValueError('label must be a simple fixture name')
    out=HERE/('rru_intl_build_20260910_'+args.label)
    out.mkdir(exist_ok=False)
    def state(p):
        f=j.a.ROOT/p
        return sha(f.read_bytes()) if f.exists() else None
    before={p:state(p) for p in set(j.candidate.bundle)|{j.BUILDER,j.VIEW}}
    bind(args.baseline_consumers)
    sources={name:j.a.RENDER_SOURCES.get('templates/'+name) or j.pinned('templates/'+name)
             for name in (*TEMPLATES,*ASSETS)}
    result=[]
    for case in CASES:
        root=out/case; site=root/'site'; data=root/'data'; templates=root/'templates'
        for folder in (site,data,templates): folder.mkdir(parents=True)
        for name,raw in sources.items(): (templates/name).write_text(raw)
        records=[payload(cc,case) for cc in j.dashboard.REGIONS]
        saved=deepcopy(records)
        settings={'storage':{'site_dir':str(site),'data_dir':str(data)},'watchlist':{}}
        with ExitStack() as stack:
            stack.enter_context(patch.object(config,'ROOT',root))
            stack.enter_context(patch.object(config,'load',return_value=settings))
            stack.enter_context(patch.object(j.builder,'load_history',return_value=None))
            stack.enter_context(patch.object(j.a.market_state,'_rr_scorecard_track',return_value=None))
            stack.enter_context(patch.object(pages,'_shim_checked',False))
            paths=j.builder.build_all({'records':records})
        assert len(paths)==5 and records==saved
        for rec,path in zip(records,paths):
            cc=rec['cc']; modern=case not in ('legacy','absent')
            html=path.read_text(); soup=BeautifulSoup(html,'html.parser')
            view=json.loads((data/'international_macro'/f'{cc}_latest.json').read_text())
            cards=soup.select('.rrx'); card_text=cards[0].get_text(' ',strip=True) if cards else ''
            checks=dict(five_routes=len(paths)==5, shim='data-dbase' in html,
                        input_unchanged=records==saved, json_schema=view['schema']=='international_macro_dashboard.v1')
            if modern:
                checks.update(card_present=len(cards)==1, odds_withheld=view['risk']['h21'] is None,
                    not_calibrated=view['risk']['calibrated'] is False,
                    composition_preserved='composition' in view['risk'] and view['risk']['composition']==rec['risk_radar']['composition'],
                    no_score_adjustment=view['decision']['parts']['risk_state']==0,
                    no_false_calm='CALM' not in card_text and 'Normal exposure' not in card_text,
                    forecast_unavailable='Forecast not available' in soup.select_one('#dlg-risk').get_text(' ',strip=True),
                    no_old_probability='42.0%' not in soup.select_one('#dlg-risk').get_text(' ',strip=True))
            else:
                checks.update(legacy_card_count=len(cards)==(1 if case=='legacy' else 0),
                    legacy_odds=view['risk']['h21']==(.42 if case=='legacy' else None),
                    legacy_adjustment=view['decision']['parts']['risk_state']==(-4. if case=='legacy' else 0.),
                    no_new_legacy_field='composition' not in view['risk'])
            result.append(dict(cc=cc,case=case,route=path.name,checks=checks,
                html_sha256=sha(path.read_bytes()),view_sha256=sha((data/'international_macro'/f'{cc}_latest.json').read_bytes())))
    unchanged=all(state(p)==v for p,v in before.items())
    failures=[dict(cc=r['cc'],case=r['case'],failed=[k for k,v in r['checks'].items() if not v])
              for r in result if not all(r['checks'].values())]
    receipt=dict(kind='actual_builder_synthetic_inputs_private_outputs',
        source_pin=j.a.PIN, original_consumers=args.baseline_consumers,
        routes=len(result), cases=result, failures=failures, source_unchanged=unchanged,
        candidate_source_hashes={p:sha(raw.encode()) for p,raw in j.candidate.edited.items() if p in j.candidate.bundle},
        actual_template_hashes={n:sha(raw.encode()) for n,raw in sources.items()},
        renderer='scripts.build_international_macro.build_all -> lib.pages.write_page',
        replaced_seams=['config output roots; no auth config','history=None','read-only scorecard=None'],
        full_builder=True, authenticated=False, synthetic_only=True, production=False)
    (out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(routes=len(result),failures=failures,source_unchanged=unchanged,
                         full_builder=True,production=False,receipt=str(out/'receipt.json'))))
    return 0 if not failures and unchanged else 1

if __name__=='__main__':
    raise SystemExit(main())

```

## REPORTED TEST/EVIDENCE: RRU_INTL_CURRENT_COMBINED_2026_09_10.txt
```
{"source_pin": "16b6c14cd4791dde7cd7217a6945987805b0fa16", "mode": "whole_modules", "counts": {"RRU_COMPOSITION_ACCEPTANCE_2026_09_08": 91, "RRU_COMPOSITION_EDGE_TESTS_2026_09_08": 8, "RRU_COMPOSITION_CONSUMER_CLOSURE_2026_09_09": 7, "RRU_COMPOSITION_NUMERICAL_TESTS_2026_09_08": 20, "RRU_DOWNSTREAM_ACCEPTANCE_2026_09_09": 8, "RRU_CONSTRUCTION_SERIALIZATION_2026_09_09": 10, "RRU_REFERENCE_WINDOW_TESTS_2026_09_09": 30, "RRU_LEGACY_COHORT_TESTS_2026_09_09": 7, "RRU_FORCE_APPLICABILITY_TESTS_2026_09_09": 30, "RRU_FORCE_BLOCK_TESTS_2026_09_09": 16, "RRU_FORCE_FULL_CONSUMER_2026_09_09": 8, "RRU_INTL_JOURNEY_TESTS_2026_09_09": 51}, "source_hashes": {"engine/risk_radar_intl.py": "96e00c04580c8cbff5c07ddd0bdf2a3051b7344d6e27e0c08b40333b8ca91b30", "engine/market_state.py": "b2b25c80b928923b4a99fb33140760e1020a49159ed73504d68ae9c80345cb50", "engine/risk_radar_recovery.py": "b817d1fb4d8ba0484bfc3ef8f66c40e35f5762bf5cde02c1d45435277ef9f5a8", "templates/_risk_radar_card.html.j2": "6ca2e9b783f6d8f0f7c0b4496160d6c3a020fd6cdb979fd57c459ca901c5ba48", "templates/china.html.j2": "236da2e7f7d56913d0308698eab6b65c00d577f8fe7b6ea70a24fecc0606929e", "templates/cn_reversal_sleeve.html.j2": "dc40baaf1d710b0ef18c7a55a85d1098fb6417d22c552db47003f1a7144531fc", "templates/baskets_desk.js": "81fd19205af98c7872bfdd1b10397414b7abf7fa899a955470a5d3b0add5262a", "engine/risk_radar_intl_audit.py": "b651ff21713dcfcc31ac08bf774e85b4ba29be6514c8854ae16b1b31f0d8af15", "engine/risk_radar_intl_tune.py": "ed9003c72cda9de36201f802c1b5d78248db75428041dee5e58a0f5cfc568a26", "engine/intl_run.py": "cc34d1ae42444f0f7d2570088cda1f0d9709b512c97fdbd78fcb901aaebc0890", "scripts/build_china.py": "3a7da97c320a078803fa3cd9c5523e09e34681199f899062d2b8be1c156dae95", "scripts/build_hk.py": "87e9ec5e2ad4a4525f08ada2fb7f2d89808987b81def78e092b8adb62fffe643", "scripts/build_canada.py": "627b32b7f60da9a2762e1e74da2dc651b640661d00cbf3e825e75d489098400b", "scripts/build_china_risk_state.py": "73f0224b8ceba99d76fa1e55b89913e4d6c51718c7115de74dd0df045e7ee667", "templates/international_macro.html.j2": "a6208ec651c37b56780bbad8c9f4d793a199e70a3af8e02a3e8c60cbcb39372a", "scripts/build_international_macro.py": "d72412bf5f716fc1c051314ea7d7d78ef52e3ed2d96041a5228be907d803bae2", "engine/international_macro_dashboard.py": "e78539ee31e160af62680f9d121ab49bafb116b42fa1547dc5663ff65bba50c9"}}
............................................................................................risk_radar_intl(?) failed: 'NoneType' object has no attribute 'disclaimer'
......risk_radar_intl(cn) failed: synthetic unavailable source
............................................................................................................................................................................................
----------------------------------------------------------------------
Ran 286 tests in 16.905s

OK
{"tests": 286, "failures": 0, "errors": 0, "source_unchanged": true, "synthetic_only": true, "production": false, "full_pipeline": false, "force_probe_included": true}

```
