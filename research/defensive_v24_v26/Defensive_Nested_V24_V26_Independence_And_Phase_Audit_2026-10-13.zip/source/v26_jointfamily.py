"""V26 phase-aware, shared-block simultaneous max-t diagnostic across 48
predeclared comparisons. No network, production, or strategy-setting selection.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
VARIANTS=['confirmed_2w_phase0','confirmed_2w_phase1','developing_2w_phase0','developing_2w_phase1']
PANELS=['CORE5','PEERS13']
FRAMES=['1D','2D']
CONTROLS=['TWO_WEEK_ONLY','WEEKLY_ONLY','NEITHER']
def compute(data,rep=4000,block=4):
    if set(data.variant)!=set(VARIANTS):raise ValueError('Incomplete or unexpected slow-timeframe conventions')
    d=data.copy();d['q']=pd.to_datetime(d.signal_date).dt.to_period('Q')
    periods=pd.period_range(d.q.min(),d.q.max(),freq='Q')
    n=len(periods);rng=np.random.default_rng(261013)
    starts=rng.integers(0,n,size=(rep,int(np.ceil(n/block))))
    pick=((starts[:,:,None]+np.arange(block))%n).reshape(rep,-1)[:,:n]
    cached={}
    for (variant,panel,frame,cell),g in d.groupby(['variant','panel','frame','cell']):
        v=g.groupby('q').beta_spread.agg(['sum','count']).reindex(periods,fill_value=0)
        cached[(variant,panel,frame,cell)]={
          'sum':v['sum'].to_numpy(float),'count':v['count'].to_numpy(float),
          'n':len(g),'active':int((v['count']>0).sum()),'mean':float(g.beta_spread.mean())}
    rows=[];vectors=[];stds=[]
    for variant in VARIANTS:
      for panel in PANELS:
        for frame in FRAMES:
          treat=cached.get((variant,panel,frame,'JOINT'))
          for control in CONTROLS:
            comp=cached.get((variant,panel,frame,control))
            eligible=bool(treat and comp and treat['active']>=8 and comp['active']>=8)
            point=(treat['mean']-comp['mean']) if treat and comp else np.nan
            row={'variant':variant,'panel':panel,'frame':frame,'control':control,'point':point,
              'n_joint':treat['n'] if treat else 0,'n_control':comp['n'] if comp else 0,
              'active_quarters_joint':treat['active'] if treat else 0,'active_quarters_control':comp['active'] if comp else 0,
              'eligible':eligible,'single_low':np.nan,'single_high':np.nan,'simul_low':np.nan,'simul_high':np.nan,'quantile_max_t':np.nan,'valid_draws':0}
            vec=None;sd=0.
            if eligible:
                aa=treat['sum'][pick].sum(axis=1);bb=treat['count'][pick].sum(axis=1)
                cc=comp['sum'][pick].sum(axis=1);dd=comp['count'][pick].sum(axis=1)
                valid=(bb>0)&(dd>0)
                row['valid_draws']=int(valid.sum())
                if row['valid_draws']<int(.95*rep):row['eligible']=False
                else:
                    vec=np.full(rep,np.nan)
                    vec[valid]=aa[valid]/bb[valid]-cc[valid]/dd[valid]
                    sd=float(np.std(vec[valid],ddof=1))
                    row['single_low']=float(np.quantile(vec[valid],.025))
                    row['single_high']=float(np.quantile(vec[valid],.975))
            rows.append(row);vectors.append(vec if row['eligible'] else None);stds.append(sd)
    idx=[i for i,row in enumerate(rows) if row['eligible']]
    if idx:
        common=np.ones(rep,bool)
        for i in idx:common &= np.isfinite(vectors[i])
        if int(common.sum()) >= int(.90*rep):
            t=[]
            for i in idx:
                vals=vectors[i][common]
                t.append(abs((vals-rows[i]['point'])/stds[i]) if stds[i]>1e-14 else np.zeros(len(vals)))
            threshold=float(np.quantile(np.stack(t).max(axis=0),.95))
            for i in idx:
                row=rows[i];radius=threshold*stds[i]
                # Expand, rather than replace, percentile CIs if finite-sample skew is wide.
                row['simul_low']=float(min(row['single_low'],row['point']-radius))
                row['simul_high']=float(max(row['single_high'],row['point']+radius))
                row['quantile_max_t']=threshold
                row['eligible_family_size']=len(idx)
                row['common_valid_draws']=int(common.sum())
        else:
            for i in idx:rows[i]['eligible']=False
    return pd.DataFrame(rows)
def run():
    inp=Path('/Volumes/Mastermind/research/defensive_nested_v12_20261013/v25/results/V25_RELABELED_CROSS_EVENTS.csv')
    d=pd.read_csv(inp)
    assert len(d)==11084 and d.groupby('variant').size().eq(2771).all()
    d=d[d.cell!='UNKNOWN']
    out=compute(d)
    assert len(out)==48
    out.to_csv(ROOT/'results/V26_FAMILY_PHASE_ADJUSTMENT.csv',index=False)
    summary={'original_events_each_variant':2771,'variants':len(VARIANTS),'possible_comparisons':len(out),
      'eligible_family':int(out.eligible.sum()),'shared_quarter_bootstrap_replicates':4000,
      'four_consecutive_calendar_quarters':True,
      'adjusts_only_this_48_contrast_family':True,'does_not_adjust_all_prior_v1_to_v25_research':True,
      'raw_prices_read':False,'production_changes':False,'unobserved_chart_parity':True}
    (ROOT/'results/VERIFICATION.json').write_text(json.dumps(summary,indent=2))
    print('V26_CORE_DAILY',out[(out.panel=='CORE5')&(out.frame=='1D')&(out.control=='TWO_WEEK_ONLY')][['variant','n_joint','n_control','point','single_low','single_high','simul_low','simul_high','eligible','eligible_family_size','quantile_max_t']].round(6).to_json(orient='records'))
    print('V26_VERIFICATION',json.dumps(summary))
if __name__=='__main__':run()
