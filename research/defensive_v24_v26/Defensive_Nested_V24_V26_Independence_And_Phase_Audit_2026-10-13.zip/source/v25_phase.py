"""V25 relabel originally fixed lower RSI-MACD crossovers under four legal
weekly/2W timeframe conventions. Endpoints/returns NOT recomputed or fitted.
"""
from pathlib import Path
import json,sys
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[2]
V=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source'))
sys.path.insert(0,str(ROOT/'v11_published/source'))
sys.path.insert(0,str(ROOT/'v24/source'))
import v12_engine as inputs
import empirical as e
import v24_overlap as family
def cells(w,b):
    if not w.index.equals(b.index):raise ValueError('Misaligned long-timeframe series')
    known=(w['count']>=200)&(b['count']>=200)&w.k.notna()&b.k.notna()&w.recent3.notna()&b.recent2.notna()
    wk=w.recent3.le(20)
    two=b.recent2.le(20)&b.k.lt(60)
    return pd.Series(np.where(~known,'UNKNOWN',np.where(wk&two,'JOINT',np.where(wk,'WEEKLY_ONLY',np.where(two,'TWO_WEEK_ONLY','NEITHER')))),index=w.index)
def changed(orig,relabel):
    if len(orig)!=len(relabel):raise ValueError('Different population')
    return int((orig.to_numpy()!=relabel.to_numpy()).sum())
def run():
    d=pd.read_csv(ROOT/'v22/results/V22_ALL_CROSS_EVENTS.csv')
    assert len(d)==2771
    frames=['1D','2D']
    keep=[]
    for sym in e.STOCKS:
        names=d[d.symbol==sym].copy()
        px=inputs.load_daily(sym)
        cal=px.index.append(pd.DatetimeIndex(inputs.CALENDAR_TAIL))
        dates=pd.to_datetime(names.signal_date)
        # All 4 variants are evaluated on the identical lower crossover dates.
        for mode in ['confirmed','developing']:
            week=e.snapshots(px.close,cal,'1W',mode,phase=0)
            for phase in [0,1]:
                two=e.snapshots(px.close,cal,'2W',mode,phase=phase)
                state=cells(week,two)
                assign=state.reindex(dates)
                if assign.isna().any():raise ValueError('Missing signal state '+sym+mode+str(phase))
                n=names.copy()
                n['original_cell']=names.cell
                n['cell']=assign.to_numpy()
                n['long_mode']=mode
                n['phase']=phase
                n['variant']=f'{mode}_2w_phase{phase}'
                keep.append(n)
        print('SLOW_PHASE_SOURCE',sym,flush=True)
    result=pd.concat(keep,ignore_index=True)
    assert len(result)==4*len(d)
    assert not result.duplicated(['symbol','frame','signal_date','variant']).any()
    baseline=result[(result.long_mode=='confirmed')&(result.phase==0)]
    mismatch=changed(baseline.original_cell,baseline.cell)
    if mismatch:raise RuntimeError(f'Original V22 baseline labels do not reproduce: {mismatch}/{len(baseline)}')
    result.to_csv(V/'results/V25_RELABELED_CROSS_EVENTS.csv',index=False)
    audits=[];contrasts=[]
    for (variant,panel,frame),g in result.groupby(['variant','panel','frame']):
        flips=changed(g.original_cell,g.cell)
        audits.append({'variant':variant,'panel':panel,'frame':frame,'total_original_events':len(g),'different_state':flips,
                      'flip_fraction':flips/len(g),'unknown_new':int((g.cell=='UNKNOWN').sum()),
                      'joint_new':int((g.cell=='JOINT').sum()),
                      'two_week_only_new':int((g.cell=='TWO_WEEK_ONLY').sum()),
                      'weekly_only_new':int((g.cell=='WEEKLY_ONLY').sum()),
                      'neither_new':int((g.cell=='NEITHER').sum())})
    for variant,g in result.groupby('variant'):
        valid=g[g.cell!='UNKNOWN'].copy()
        # Family engine resamples common identical quarter blocks across all cohorts.
        fam=family.family_intervals(valid,rep=4000,block=4)
        fam.insert(0,'variant',variant)
        contrasts.append(fam)
    pd.DataFrame(audits).to_csv(V/'results/V25_PHASE_STATE_CHANGES.csv',index=False)
    pd.concat(contrasts,ignore_index=True).to_csv(V/'results/V25_PHASE_CONTRASTS.csv',index=False)
    summary=pd.concat(contrasts,ignore_index=True)
    for var in ['confirmed_2w_phase0','confirmed_2w_phase1','developing_2w_phase0','developing_2w_phase1']:
        x=summary[(summary.variant==var)&(summary.panel=='CORE5')&(summary.frame=='1D')&(summary.control=='TWO_WEEK_ONLY')]
        print('V25_CORE_DAILY_PHASE',var,x[['point','n_joint','n_control','single_low','single_high','simul_low','simul_high','eligible']].round(6).to_json(orient='records'),flush=True)
    check={'original_V22_events':len(d),'relabelled_rows':len(result),'baseline_phase0_confirmed_mismatch':mismatch,
         'user_chart_parity':'UNVERIFIED','classifications_are_at_original_lower_signal_close':True,
         '2w_phases':[0,1],'long_bar_modes':['confirmed','developing'],'input_series_original_unchanged':True,
         'null_or_undefined_long_state_kept_unknown':True,'no_new_market_acquisition':True,'not_alpha_or_live_validation':True}
    (V/'results/V25_VERIFICATION.json').write_text(json.dumps(check,indent=2))
    print('V25_VERIFIED',json.dumps(check))
if __name__=='__main__':run()
