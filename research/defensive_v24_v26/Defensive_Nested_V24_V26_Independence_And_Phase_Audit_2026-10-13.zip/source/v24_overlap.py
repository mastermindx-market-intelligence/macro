"""V24 independent-event and common bootstrap-family challenge.
Uses only accepted V22 derived event outcomes; no raw data acquisition, broker,
production strategy or new RSI/STOCH variants. Historical and posthoc.
"""
from pathlib import Path
import json,sys
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[2]
V=Path(__file__).resolve().parents[1]
CELLS=['JOINT','TWO_WEEK_ONLY','WEEKLY_ONLY','NEITHER']
PANELS=['CORE5','PEERS13']
FRAMES=['1D','2D']
CONTROLS=['TWO_WEEK_ONLY','WEEKLY_ONLY','NEITHER']
def first_after_embargo(indices,embargo):
    ix=[int(x) for x in indices]
    if embargo<1 or ix!=sorted(ix) or len(set(ix))!=len(ix):raise ValueError('Indices must be strictly increasing and embargo positive')
    kept=[];last=-10**12
    for i in ix:
        if i-last>=embargo:kept.append(i);last=i
    return kept
def select_events(d,embargo):
    chosen=[]
    if 'signal_i' not in d:raise ValueError('Actual session index required')
    for (s,frame),g in d.groupby(['symbol','frame']):
        group=g.sort_values('signal_i')
        allowed=set(first_after_embargo(group.signal_i,embargo))
        chosen.append(group[group.signal_i.isin(allowed)])
    return pd.concat(chosen,ignore_index=True) if chosen else d.iloc[:0].copy()
def family_intervals(data,rep=4000,block=4):
    if data.empty:raise ValueError('No events')
    d=data.copy()
    d['q']=pd.to_datetime(d.signal_date).dt.to_period('Q')
    q=pd.period_range(d.q.min(),d.q.max(),freq='Q')
    n=len(q)
    rng=np.random.default_rng(241013)
    st=rng.integers(0,n,size=(rep,int(np.ceil(n/block))))
    indices=((st[:,:,None]+np.arange(block))%n).reshape(rep,-1)[:,:n]
    cached={}
    for (panel,frame,cell),g in d.groupby(['panel','frame','cell']):
        x=g.groupby('q').beta_spread.agg(['sum','count']).reindex(q,fill_value=0)
        cached[(panel,frame,cell)]=(
          x['sum'].to_numpy(float),x['count'].to_numpy(float),
          int((x['count']>0).sum()),float(g.beta_spread.mean()),len(g))
    rows=[];vectors=[];valid_mask=[];sigmas=[]
    for panel in PANELS:
      for frame in FRAMES:
        joint=cached.get((panel,frame,'JOINT'))
        for control in CONTROLS:
          other=cached.get((panel,frame,control))
          n_joint=joint[4] if joint else 0;n_control=other[4] if other else 0
          active_joint=joint[2] if joint else 0;active_control=other[2] if other else 0
          eligible=active_joint>=8 and active_control>=8
          pt=(joint[3]-other[3]) if joint and other else np.nan
          record={'panel':panel,'frame':frame,'control':control,'point':pt,
                  'n_joint':n_joint,'n_control':n_control,
                  'active_quarters_joint':active_joint,'active_quarters_control':active_control,
                  'eligible':bool(eligible),'single_low':np.nan,'single_high':np.nan,
                  'simul_low':np.nan,'simul_high':np.nan,'valid_replicates':0,'simul_quantile':np.nan}
          vec=None;sd=0.
          if eligible:
            a,b=joint[0:2];c,e=other[0:2]
            aa=a[indices].sum(axis=1);bb=b[indices].sum(axis=1)
            cc=c[indices].sum(axis=1);ee=e[indices].sum(axis=1)
            valid=(bb>0)&(ee>0)
            vec=np.full(rep,np.nan)
            vec[valid]=aa[valid]/bb[valid]-cc[valid]/ee[valid]
            valid_count=int(valid.sum());record['valid_replicates']=valid_count
            if valid_count<round(rep*.95):
                record['eligible']=False
            else:
                vv=vec[valid];sd=float(np.std(vv,ddof=1))
                record['single_low']=float(np.quantile(vv,.025))
                record['single_high']=float(np.quantile(vv,.975))
          vectors.append(vec if record['eligible'] else None)
          sigmas.append(sd)
          rows.append(record)
    eligible_idx=[i for i,r in enumerate(rows) if r['eligible']]
    if eligible_idx:
      eligible=np.ones(rep,dtype=bool)
      for i in eligible_idx:eligible &= np.isfinite(vectors[i])
      if int(eligible.sum())>=round(rep*.90):
        standardized=[]
        for i in eligible_idx:
          se=sigmas[i];v=vectors[i][eligible]
          standardized.append(np.abs((v-rows[i]['point'])/se) if se>1e-15 else np.zeros(len(v)))
        qmax=float(np.quantile(np.max(np.stack(standardized),axis=0),.95))
        for i in eligible_idx:
          r=rows[i]
          width=qmax*sigmas[i]
          r['simul_low']=float(min(r['point']-width,r['single_low']))
          r['simul_high']=float(max(r['point']+width,r['single_high']))
          r['simul_quantile']=qmax
          r['family_size_eligible']=len(eligible_idx)
          r['common_valid_replicates']=int(eligible.sum())
    return pd.DataFrame(rows)
def run():
    d=pd.read_csv(ROOT/'v22/results/V22_ALL_CROSS_EVENTS.csv')
    assert len(d)==2771
    sys.path.insert(0,str(ROOT/'source'))
    import v12_engine as v
    ref=v.load_daily('MCD').index
    m=pd.Series(np.arange(len(ref),dtype=int),index=ref)
    d['signal_i']=pd.to_datetime(d.signal_date).map(m)
    if d.signal_i.isna().any():raise ValueError('Unmatched event session')
    d['signal_i']=d.signal_i.astype(int)
    assert not d.duplicated(['symbol','frame','signal_i']).any()
    data={}
    tables=[]
    for label,s in [('ALL',d),('EMBARGO63',select_events(d,63)),('EMBARGO126',select_events(d,126))]:
        s.to_csv(V/'results'/f'V24_{label}_EVENTS.csv',index=False)
        frame=family_intervals(s,rep=4000,block=4)
        frame.insert(0,'selection',label)
        tables.append(frame);data[label]=len(s)
        for item in ['CORE5','PEERS13']:
          a=frame[(frame.panel==item)&(frame.frame=='1D')&(frame.control=='TWO_WEEK_ONLY')]
          print('PRIMARY',label,item,a[['n_joint','n_control','point','eligible','single_low','single_high','simul_low','simul_high','family_size_eligible']].round(6).to_dict('records'),flush=True)
    result=pd.concat(tables,ignore_index=True)
    result.to_csv(V/'results/V24_FAMILY_INTERVALS.csv',index=False)
    # Explicit event counts and independent calendar quarters; do not pretend they are trade samples.
    stats=[]
    for (sel,panel,frame,cell),g in pd.concat([x.assign(selection=n) for n,x in [('ALL',d),('EMBARGO63',pd.read_csv(V/'results/V24_EMBARGO63_EVENTS.csv')),('EMBARGO126',pd.read_csv(V/'results/V24_EMBARGO126_EVENTS.csv'))]]).groupby(['selection','panel','frame','cell']):
        stats.append({'selection':sel,'panel':panel,'frame':frame,'cell':cell,'n':len(g),'n_symbol':g.symbol.nunique(),'n_calendar_quarters':pd.to_datetime(g.signal_date).dt.to_period('Q').nunique(),'mean_beta_spread':float(g.beta_spread.mean())})
    pd.DataFrame(stats).to_csv(V/'results/V24_STATE_COUNTS.csv',index=False)
    baseline=result[(result.selection=='ALL')&(result.panel=='CORE5')&(result.frame=='1D')&(result.control=='TWO_WEEK_ONLY')].iloc[0]
    assert abs(baseline.point-.0230746399578884)<1e-10
    proof={'original_event_count':2771,'cohorts':data,'all_raw_inputs_original_unchanged':True,
      'source':'Original V22 beta-residual event CSV; session map from already accepted V12 input only',
      'embargo_unit':'Completed XNYS trading sessions, first eligible per stock & frame',
      'bootstrap':'4000 shared four-calendar-quarter circular blocks, one draw matrix for 12 contrasts',
      'bootstrap_eligible_rule':'>=8 event-active quarters for each group and >=95% valid draws',
      'maxT':'Approximate simultaneous 95% intervals across eligible family, NOT whole historical research program',
      'known_biases':['survivor-stock selection','overlapping horizons and shared shock','all years previously reviewed','factor beta proxy','posthoc contrast family'],
      'no_external_data_or_broker':True}
    (V/'results/V24_VERIFICATION.json').write_text(json.dumps(proof,indent=2))
    print('V24_COMPLETE',json.dumps(proof))
if __name__=='__main__':run()
