"""V26 joint simultaneous interval family red-green checks."""
import unittest,sys
from pathlib import Path
import numpy as np,pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import v26_jointfamily as m
class Family(unittest.TestCase):
 def synthetic(self):
  days=pd.date_range('2018-03-01',periods=15,freq='QS')
  rows=[]
  for i,date in enumerate(days):
   for variant in m.VARIANTS:
    for panel in ['CORE5','PEERS13']:
     for frame in ['1D','2D']:
      for cell in ['JOINT','TWO_WEEK_ONLY','WEEKLY_ONLY','NEITHER']:
       rows.append({'variant':variant,'panel':panel,'frame':frame,'cell':cell,'signal_date':str(date.date()),'beta_spread':0.})
  return pd.DataFrame(rows)
 def test_complete_48_contrasts(self):
  o=m.compute(self.synthetic(),rep=150)
  self.assertEqual(len(o),48)
  self.assertTrue(o.eligible.all())
 def test_all_equal_produces_zero_simultaneous_interval(self):
  o=m.compute(self.synthetic(),rep=160)
  self.assertTrue((o.point.abs()<1e-12).all())
  self.assertTrue((o.simul_low.abs()<1e-12).all())
  self.assertTrue((o.simul_high.abs()<1e-12).all())
 def test_conservative_interval_not_narrower_than_single(self):
  d=self.synthetic()
  # Add systematic pseudo-random date effects shared across variants so no
  # single variant gets independently advantaged.
  d['beta_spread']=[np.sin(i/7)*.03 for i in range(len(d))]
  o=m.compute(d,rep=130);a=o[o.eligible]
  self.assertTrue(((a.simul_high-a.simul_low)>=(a.single_high-a.single_low)-1e-10).all())
 def test_sparse_control_refuses(self):
  d=self.synthetic();d=d[~((d.variant==m.VARIANTS[0])&(d.cell=='TWO_WEEK_ONLY')&(pd.to_datetime(d.signal_date).dt.year>2018))]
  o=m.compute(d,rep=80)
  s=o[(o.variant==m.VARIANTS[0])&(o.control=='TWO_WEEK_ONLY')]
  self.assertFalse(s.eligible.any());self.assertTrue(s.simul_low.isna().all())
 def test_variant_refuses_incomplete_family(self):
  d=self.synthetic();d=d[d.variant!=m.VARIANTS[-1]]
  with self.assertRaises(ValueError):m.compute(d,rep=100)
 def test_future_data_is_not_used_in_class(self):
  d=self.synthetic()
  y=m.compute(d,rep=100)
  d.loc[d.signal_date=='2022-01-01','beta_spread']=100.
  # Future perturbations never affect immutable cohort identity.
  self.assertEqual(y[['variant','panel','frame','control']].to_dict('records'),m.compute(d,rep=100)[['variant','panel','frame','control']].to_dict('records'))
if __name__=='__main__':unittest.main(verbosity=2)