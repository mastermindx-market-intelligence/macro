"""V24 strict dependency and overlap challenge. Write first, verify red, then implement."""
import unittest,sys
from pathlib import Path
import numpy as np,pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import v24_overlap as v
class V24(unittest.TestCase):
 def test_first_after_63_daily_sessions(self):
  ix=[0,10,62,63,120,127,190]
  self.assertEqual(v.first_after_embargo(ix,63),[0,63,127,190])
 def test_first_after_126_daily_sessions(self):
  self.assertEqual(v.first_after_embargo([0,62,63,126,140,252],126),[0,126,252])
 def test_outcomes_cannot_change_chosen_events(self):
  a=[0,10,90,91,155]
  b=v.first_after_embargo(a,63)
  prices=np.array([.02,.31,-.4,.99,-.11])
  prices*=100
  self.assertEqual(b,v.first_after_embargo(a,63))
 def test_all_grouping_preserves_shared_calendar(self):
  d=self.make_synthetic()
  out=v.select_events(d,63)
  self.assertTrue((out.groupby(['symbol','frame']).signal_i.diff().dropna()>=63).all())
  self.assertFalse(out.duplicated(['symbol','frame','signal_i']).any())
 def test_cell_counts_sum_to_events(self):
  d=self.make_synthetic()
  out=v.select_events(d,63)
  self.assertEqual(out.groupby(['symbol','frame']).size().sum(),len(out))
 def make_synthetic(self):
  ix=pd.bdate_range('2018-01-02',periods=2400)
  rows=[]
  for panel,sym in [('CORE5','MCD'),('CORE5','COST'),('PEERS13','KO'),('PEERS13','HSY')]:
   for frame in ['1D','2D']:
    for i in range(50,2350,38):
     rows.append({'symbol':sym,'panel':panel,'frame':frame,'signal_date':str(ix[i].date()),'signal_i':i,'cell':['JOINT','TWO_WEEK_ONLY','WEEKLY_ONLY','NEITHER'][(i//38)%4],'beta_spread':float((i%230)/10000)})
  return pd.DataFrame(rows)
 def test_single_quarter_cannot_claim_interval(self):
  d=self.make_synthetic()
  d.loc[:,'signal_date']='2020-03-01'
  z=v.family_intervals(d,rep=40)
  self.assertTrue((z.eligible==False).all())
 def test_identical_zero_effect_no_fake_significance(self):
  d=self.make_synthetic();d.loc[:,'beta_spread']=0.
  a=v.family_intervals(d,rep=100)
  eligible=a[a.eligible]
  self.assertTrue((eligible.point.abs()<1e-12).all())
  self.assertTrue((eligible.simul_low.abs()<1e-12).all())
  self.assertTrue((eligible.simul_high.abs()<1e-12).all())
 def test_simultaneous_not_narrower_than_individual(self):
  d=self.make_synthetic()
  a=v.family_intervals(d,rep=120)
  x=a[a.eligible]
  self.assertTrue((x.simul_high-x.simul_low>=x.single_high-x.single_low-1e-10).all())
 def test_missing_2w_group_not_zero_imputed(self):
  d=self.make_synthetic();d=d[d.cell!='TWO_WEEK_ONLY']
  x=v.family_intervals(d,rep=80)
  a=x[x.control=='TWO_WEEK_ONLY']
  self.assertTrue((a.eligible==False).all())
  self.assertTrue(a.simul_low.isna().all())
if __name__=='__main__':unittest.main(verbosity=2)
