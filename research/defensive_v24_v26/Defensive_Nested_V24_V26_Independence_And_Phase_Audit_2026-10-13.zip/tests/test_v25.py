"""V25 native phase/parity red-green tests, no real return selection."""
import unittest,sys
from pathlib import Path
import numpy as np,pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import v25_phase as x
class Phase(unittest.TestCase):
 def fixture(self):
  ix=pd.bdate_range('2026-01-02',periods=5)
  w=pd.DataFrame({'count':[201]*5,'k':[12.,18.,27.,50.,72.],'recent3':[12.,12.,12.,18.,27.]},index=ix)
  b=pd.DataFrame({'count':[201]*5,'k':[11.,22.,47.,60.,5.],'recent2':[11.,11.,22.,47.,5.]},index=ix)
  return w,b
 def test_all_four_disjoint_categories(self):
  w,b=self.fixture()
  self.assertEqual(x.cells(w,b).tolist(),['JOINT','JOINT','WEEKLY_ONLY','WEEKLY_ONLY','TWO_WEEK_ONLY'])
 def test_unknown_warmup_not_no_washout(self):
  w,b=self.fixture();w.loc[w.index[0],'count']=199
  self.assertEqual(x.cells(w,b).iloc[0],'UNKNOWN')
 def test_unknown_missing_two_week_stoch(self):
  w,b=self.fixture();b.loc[b.index[0],'k']=np.nan
  self.assertEqual(x.cells(w,b).iloc[0],'UNKNOWN')
 def test_altering_b_only_can_flip_joint_to_weekly(self):
  w,b=self.fixture();a=x.cells(w,b).iloc[1]
  b.loc[b.index[1],'recent2']=40.
  self.assertEqual(a,'JOINT');self.assertEqual(x.cells(w,b).iloc[1],'WEEKLY_ONLY')
 def test_lookahead_end_values_dont_change_previous_labels(self):
  w,b=self.fixture();a=x.cells(w,b)
  b.loc[b.index[-1],['k','recent2']]=[99.,99.]
  pd.testing.assert_series_equal(a.iloc[:-1],x.cells(w,b).iloc[:-1])
 def test_changes_share_total_matches(self):
  a=pd.Series(['JOINT','NEITHER','JOINT'],name='old');b=pd.Series(['JOINT','WEEKLY_ONLY','UNKNOWN'],name='new')
  self.assertEqual(x.changed(a,b),2)
 def test_variant_select_doesnt_use_outcome_for_labels(self):
  w,b=self.fixture();a=x.cells(w,b)
  returns=pd.Series([10.,-10.,100.,.5,-100.],index=w.index)
  returns*=1000
  pd.testing.assert_series_equal(a,x.cells(w,b))
if __name__=='__main__':unittest.main(verbosity=2)