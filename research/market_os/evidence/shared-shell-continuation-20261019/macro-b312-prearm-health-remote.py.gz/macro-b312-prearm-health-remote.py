import datetime,hashlib,json,pathlib,subprocess,urllib.request,os,stat
B=pathlib.Path('/opt/terminal/beta')
def command(a):
 p=subprocess.run(a,capture_output=True,text=True,timeout=25)
 return {'argv':a,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
def file(p):
 p=pathlib.Path(p);raw=p.read_bytes();st=p.stat()
 return {'path':str(p),'resolved':str(p.resolve()),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'uid':st.st_uid,'gid':st.st_gid,'mode':oct(st.st_mode & 0o777),'nlink':st.st_nlink}
def identity(p):
 x=file(p);x['text']=pathlib.Path(p).read_text().strip();return x

R93_SHA="c6759cc653e0f19102a015ec52842795bde24eb85766d2e73f3024b4eefe409d"
LOCK=pathlib.Path("/opt/terminal/.terminal-build-resource.lock")
def lmeta(p):
 try:
  s=p.lstat()
  return {"path":str(p),"exists":True,"type":"symlink" if stat.S_ISLNK(s.st_mode) else "directory" if stat.S_ISDIR(s.st_mode) else "regular" if stat.S_ISREG(s.st_mode) else "other","dev":s.st_dev,"ino":s.st_ino,"uid":s.st_uid,"gid":s.st_gid,"mode":oct(s.st_mode&0o777),"nlink":s.st_nlink,"bytes":s.st_size,"mtime_ns":s.st_mtime_ns}
 except FileNotFoundError:return {"path":str(p),"exists":False,"error":"ENOENT"}
 except OSError as ex:return {"path":str(p),"exists":None,"error":type(ex).__name__,"errno":ex.errno}
def hold_snapshot():
 out={"parent":lmeta(LOCK),"hold":lmeta(LOCK/"hold"),"owner":lmeta(LOCK/"hold"/"owner"),"archive_residue":[]}
 o=out["owner"];p=LOCK/"hold"/"owner"
 if o.get("type")=="regular" and o["bytes"]<=8192:
  try:
   fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
   try:
    before=os.fstat(fd);b=os.read(fd,8193);after=os.fstat(fd)
   finally:os.close(fd)
   shape=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns)
   o["read_identity_stable"]=shape(before)==shape(after) and before.st_dev==o["dev"] and before.st_ino==o["ino"] and len(b)==o["bytes"]
   o["sha256"]=hashlib.sha256(b).hexdigest()
   fields={}
   for line in b.decode("utf-8",errors="replace").splitlines():
    k,sep,v=line.partition("=")
    if sep and k in {"pid","uid","target","shared","started"}:
     if k in fields:o["duplicate_field"]=True
     fields[k]=v[:1024]
   o["declared_fields"]=fields
  except OSError as ex:o["read_error"]={"type":type(ex).__name__,"errno":ex.errno}
 if out["parent"].get("type")=="directory":
  try:out["archive_residue"]=[lmeta(p) for p in sorted(LOCK.glob("beta-bootstrap.*"))]
  except OSError as ex:out["archive_scan_error"]={"type":type(ex).__name__,"errno":ex.errno}
 return out
def release_process_snapshot():
 found=[];errors=[];vanished=0;shells=0
 for proc in pathlib.Path("/proc").iterdir():
  if not proc.name.isdigit():continue
  try:
   args=(proc/"cmdline").read_bytes()[:16384].split(b"\0")
   args=[a.decode("utf-8",errors="replace") for a in args if a]
   if not args or pathlib.Path(args[0]).name.lstrip("-") not in {"bash","sh","dash","zsh"}:continue
   shells+=1;i=1;inline=False
   while i<len(args) and args[i].startswith("-"):
    flag=args[i]
    if flag=="--":i+=1;break
    if not flag.startswith("--") and "c" in flag[1:]:inline=True;break
    i+=1
   if inline or i>=len(args):continue
   script=pathlib.Path(args[i])
   if not script.is_absolute():script=pathlib.Path(os.readlink(proc/"cwd"))/script
   st=script.stat()
   if not stat.S_ISREG(st.st_mode) or st.st_size>2097152:continue
   sha=hashlib.sha256(script.read_bytes()).hexdigest()
   if script.name!="terminal-build.sh" and sha!=R93_SHA:continue
   status=(proc/"stat").read_text();tail=status[status.rfind(")")+2:].split()
   found.append({"pid":int(proc.name),"uid":proc.stat().st_uid,"start_ticks":tail[19],"executable":os.readlink(proc/"exe"),"script":str(script),"script_sha256":sha,"matches_accepted_R93":sha==R93_SHA})
  except (FileNotFoundError,ProcessLookupError):vanished+=1
  except OSError as ex:errors.append({"pid":int(proc.name),"error":type(ex).__name__,"errno":ex.errno})
 return {"owners":found,"scan_errors":errors,"transient_vanished":vanished,"shell_processes_observed":shells,"matcher":"shell script argument: global basename terminal-build.sh or exact accepted R93 content SHA, including a private script-only copy; no environments or unrelated command lines retained","limitations":"Sample only; inline shell commands are not canonical script-owner invocations. No reservation or continuous-exclusion claim."}
def release_observation():
 return {"observed_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"lock":hold_snapshot(),"processes":release_process_snapshot()}

out={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'fresh read-only service, source, runtime pointer, public DNS/TLS observation; no bootstrap or repair'}
out['scope']='read-only beta continuity, production before/after, and sampled canonical owner/hold; no installer, cleanup, browser/TLS bypass or reservation'
out['release_before']=release_observation()
props='ActiveState,SubState,UnitFileState,MainPID,ExecMainStartTimestampMonotonic'
out['services']={n:command(['systemctl','show',n,'--property='+props]) for n in ['terminal.service','terminal-beta.service']}
out['beta_source_HEAD']=command(['git','--no-optional-locks','-C','/opt/terminal/.gitsrc-beta','rev-parse','HEAD'])
out['runtime_pointer']=file(B/'.runtime-accepted')
out['source_pointer']=file(B/'.source-provisioned')
out['beta_build']=[identity(B/'terminal'/n) for n in ['.deployment-id','.next/BUILD_ID']]
out['production_build']=[identity(pathlib.Path('/opt/terminal/terminal')/n) for n in ['.deployment-id','.next/BUILD_ID']]
out['production_owner']=file('/opt/terminal/terminal-build.sh')
out['caddy']=file('/etc/caddy/Caddyfile')
with urllib.request.urlopen('http://127.0.0.1:3001/api/shared-shell/status',timeout=15) as r:
 raw=r.read(65536);out['status']={'status':r.status,'headers':dict(r.headers),'raw_sha256':hashlib.sha256(raw).hexdigest(),'body':json.loads(raw)}
out['pending_exists']=os.path.lexists(B/'.release-pending')
out['beta_stages']=[str(x) for x in B.glob('.stage.*')]
out['root_free']=os.statvfs('/').f_bavail*os.statvfs('/').f_frsize
out['terminal_mount_free']=os.statvfs('/opt/terminal').f_bavail*os.statvfs('/opt/terminal').f_frsize
out['beta_after']=command(['systemctl','show','terminal-beta.service','--property='+props])
M=pathlib.Path('/opt/macro')
out['macro']={'head_before':command(['git','--no-optional-locks','-C',str(M),'rev-parse','HEAD']),'services':{n:command(['systemctl','show',n,'--property='+props]) for n in ['macro-api.service','caddy.service']},'files':[]}
for path in ['/usr/local/bin/macro-update','/etc/caddy/Caddyfile','/opt/macro/app/deploy/update.sh','/opt/macro/app/deploy/Caddyfile','/opt/macro/site/shared_shell_bridge.js','/opt/macro/site/shared_shell.css','/opt/macro/site/index.html','/opt/macro/site/sector_central.html','/opt/macro/site.served/shared_shell_bridge.js','/opt/macro/site.served/shared_shell.css','/opt/macro/site.served/index.html','/opt/macro/site.served/sector_central.html']:
 p=pathlib.Path(path)
 out['macro']['files'].append(file(p) if p.is_file() else {'path':path,'exists':False})
lp=pathlib.Path('/var/log/macro-update.log')
if lp.is_file():
 st=lp.stat()
 with lp.open('rb') as fh:
  start=max(0,st.st_size-262144);fh.seek(start);data=fh.read(262144)
 lines=data.decode('utf-8',errors='replace').splitlines()[1 if start else 0:]
 prefixes=('macro-update 20','macro-api restarted pid ','macro-api restart retry succeeded pid ','macro-api restart ANOMALY ','macro-api restart RETRY FAILED ')
 out['macro']['update_log']={'dev':st.st_dev,'ino':st.st_ino,'bytes':st.st_size,'tail_start':start,'selected_lines':[line for line in lines if line.startswith(prefixes)][-16:]}
out['macro']['head_after']=command(['git','--no-optional-locks','-C',str(M),'rev-parse','HEAD'])

out["production_after"]={"service":command(["systemctl","show","terminal.service","--property="+props]),"build":[identity(pathlib.Path("/opt/terminal/terminal")/n) for n in [".deployment-id",".next/BUILD_ID"]],"owner":file("/opt/terminal/terminal-build.sh")}
out["caddy_after"]=file("/etc/caddy/Caddyfile")
out["release_after"]=release_observation()
out["finished_at"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
print(json.dumps(out,indent=2))


