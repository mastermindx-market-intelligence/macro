from pathlib import Path
import subprocess,json,hashlib,datetime,os,sys
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");D=E/"macro-da4d-987-html-final-preview";G=["git","--no-optional-locks","-C",str(W)]
B="3b49d6a5c8a6330652a926a8e5061e0dbb3d0387";H="da4df7d1e1ac709055c6fa1d482304a875e81824";M="9875169102cc6f36a64d465fe7c06f6bb8fb0220"
def git(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
assert not D.exists();D.mkdir()
assert git("rev-parse","HEAD").decode().strip()==H and git("rev-parse","MERGE_HEAD").decode().strip()==M
theme=json.loads((E/"macro-da4d-987-theme-owner-resolution.json").read_text());assert theme["state"]=="OWNER_EMITTED_STAGED" and dg((W/"site/theme.js").read_bytes())==theme["candidate_sha256"]
os.chdir(W);sys.path.insert(0,str(W))
from scripts.optimize_assets import make_optimizer
from lib.shared_shell import inject_shared_shell_text
from lib.pages import dbase_prefix
opt=make_optimizer(W/"site");closure=dict(zip(opt.__code__.co_freevars,[x.cell_contents for x in opt.__closure__]))
versions=[dg((W/"site"/p).read_bytes())[:8] for p in ["shared_shell_bridge.js","shared_shell.css"]]
def canon(raw,p):
 q=W/("site/chat.html" if p=="templates/chat.html" else p)
 return opt(inject_shared_shell_text(raw.decode(),dbase_prefix(q),version=versions[0],css_version=versions[1],site_dir=W/"site"),q.parent)
plain="try{ window.MDXAuth.open('signin'); }catch(e){ location.href = 'plans.html'; }";shared="if (window.MMXSharedShell) { window.MMXSharedShell.openAuth('signin'); return; } "+plain
whole={"site/us_stocks.html":[("        location.href = 'stock.html#' + encodeURIComponent(tk);","        var _d = 'stock.html#' + encodeURIComponent(tk); var _ss = window.MMXSharedShell; if (_ss) { _ss.navigate(_d, 'push'); } else { location.href = _d; }"),("    window.addEventListener('hashchange', fromHash);","    window.addEventListener('hashchange', fromHash);\n    window.addEventListener('mmx:shell-location', fromHash);"),("          try{ window.MDXAuth.open('signin'); }catch(e2){ location.href = 'plans.html'; }","          if(window.MMXSharedShell){ window.MMXSharedShell.openAuth('signin'); return; }\n          try{ window.MDXAuth.open('signin'); }catch(e2){ location.href = 'plans.html'; }")],**{p:[(plain,shared)] for p in ["site/etfs.html","site/special_situations.html","site/china_special_situations.html"]}}
prior=json.loads((E/"macro-da4d-987-whole-render-preview/receipt.json").read_text());proof=json.loads((E/"macro-da4d-987-whole-render-adapter-proof.json").read_text())
for row in prior["rows"]:
 p=E/"macro-da4d-987-whole-render-preview"/(Path(row["path"]).name+"."+row["parent"]+".canonical.html");assert dg(p.read_bytes())==row["canonical_sha256"]
for row in proof["rows"]:assert dg(Path(row["candidate_file"]).read_bytes())==row["candidate_sha256"]
paths=[p for p in git("diff","--name-only","--diff-filter=U").decode().splitlines() if p.endswith(".html") and p!="site/macro_labor_markets.html"]
rows=[]
for p in paths:
 texts={};parent={}
 for label,rev in [("B",B),("H",H),("M",M)]:
  raw=git("show",rev+":"+p);texts[label]=canon(raw,p);f=D/(p.replace("/","_")+"."+label);f.write_text(texts[label]);parent[label]={"commit":rev,"original_sha256":dg(raw),"canonical_sha256":dg(texts[label].encode()),"file":str(f)}
 if p in whole:
  def apply(text):
   for old,new in whole[p]:
    assert text.count(old)==1 and new not in text,(p,old)
    text=text.replace(old,new,1)
   return text
  assert apply(texts["B"])==texts["H"],p
  candidate=apply(texts["M"]);back=candidate
  for old,new in reversed(whole[p]):assert back.count(new)==1;back=back.replace(new,old,1)
  assert back==texts["M"]
  code=0;method="complete incoming generation + exact source-proven adapters; inverse recovers canonical M"
 else:
  r=subprocess.run(["git","merge-file","-p","--diff3","-L","H","-L","B","-L","M",parent["H"]["file"],parent["B"]["file"],parent["M"]["file"]],capture_output=True)
  code=r.returncode;candidate=r.stdout.decode();method="existing canonical normalization + ordinary three-way text merge"
 target=D/(p.replace("/","_")+".candidate");target.write_text(candidate)
 row={"path":p,"method":method,"parents":parent,"exit":code,"candidate":str(target),"candidate_sha256":dg(candidate.encode()),"candidate_bytes":len(candidate.encode()),"conflict_markers":candidate.count("<<<<<<< H")}
 if p in ("templates/chat.html","site/chat.html"):row["canonical_incoming_equals_base"]=texts["M"]==texts["B"]
 rows.append(row);print(json.dumps({k:row[k] for k in ["path","method","exit","conflict_markers"]}),flush=True)
assets=[]
for p,h in sorted(closure["cache"].items()):
 if h is None:assets.append({"path":str(p),"missing":True});continue
 b=p.read_bytes();assert dg(b)[:8]==h
 assets.append({"path":str(p.relative_to(W)),"bytes":len(b),"sha256":dg(b),"staged_blob":git("rev-parse",":"+str(p.relative_to(W))).decode().strip()})
assert dg((W/"site/theme.js").read_bytes())==theme["candidate_sha256"]
out={"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"head":H,"base":B,"incoming":M,"actual_theme_sha256":theme["candidate_sha256"],"old_scratch_BHM_and_four_candidate_hashes_verified":True,"worktree_or_index_written":False,"rows":rows,"assets":assets,"all_clean":all(r["exit"]==0 for r in rows)}
(D/"receipt.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps({"all_clean":out["all_clean"],"rows":len(rows),"conflicted":[r["path"] for r in rows if r["exit"]!=0],"asset_count":len(assets)},indent=2),flush=True)
