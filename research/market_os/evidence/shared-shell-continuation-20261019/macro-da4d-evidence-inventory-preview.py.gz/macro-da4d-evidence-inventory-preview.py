from pathlib import Path
import json,hashlib,gzip,datetime,subprocess
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27")
E=Path("/tmp/shared-shell-css-visual-20261019T1107")
P=W/"research/market_os/evidence/shared-shell-continuation-20261019"
OUT=E/"macro-da4d-evidence-inventory-preview.json"
assert not OUT.exists()
dg=lambda b:hashlib.sha256(b).hexdigest()
oldraw=(P/"MANIFEST.json").read_bytes()
assert dg(oldraw)=="eafb91bd7ffb2bf6e8b9cecfe72eae2627ce01175d3ddd13a8f57f32e5031dc6"
mf=json.loads(oldraw);rows=mf["files"];assert len(rows)==509
for row in rows:
 raw=(P/row["file"]).read_bytes()
 assert len(raw)==row["bytes"] and dg(raw)==row["sha256"],row["file"]
 if row.get("encoding")=="gzip":
  original=gzip.decompress(raw)
  assert len(original)==row["original_bytes"] and dg(original)==row["original_sha256"],row["file"]
assert {str(p.relative_to(P)) for p in P.rglob("*") if p.is_file()}=={r["file"] for r in rows}|{"MANIFEST.json"}
prefixes=("about-footer-","labor-copy-","b312-","macro-b312-","macro-da4d-","macro-full-checkpoint-b312-","macro-full-checkpoint-987-","beta-loaded-unit-")
exact={"macro-140bd-3b49-proof-import.json","macro-140bd-3b49-proof-review.md","macro-140bd-3b49-commit.py","macro-140bd-3b49-commit.json","macro-140bd-3b49-commit.log","macro-140bd-3b49-commit-message.txt"}
live={"macro-da4d-987-merge.json","macro-da4d-987-merge.log"}
candidates=[];skipped=[]
for p in sorted(E.rglob("*")):
 if not p.is_file() or p==OUT:continue
 rel=str(p.relative_to(E))
 if not (rel.startswith(prefixes) or rel in exact):continue
 assert not p.is_symlink(),rel
 if rel in live:skipped.append({"file":rel,"reason":"Owned merge still active; final bytes must be captured after completion."});continue
 raw=p.read_bytes();target=rel.replace("/","--")
 candidates.append({"relative_source":rel,"source":str(p),"target_base":target,"bytes":len(raw),"sha256":dg(raw),"encoding_suggestion":"gzip" if p.suffix!=".json" or len(raw)>65536 or raw.endswith(b"\n\n") else "utf-8"})
assert len({x["target_base"] for x in candidates})==len(candidates)
assert (P/"MANIFEST.json").read_bytes()==oldraw
out={"observed_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"scope":"Read-only existing509-file proof verification and scratch-only inventory preview; no W/index write, not a final post-987 source binding.","existing_manifest_sha256":dg(oldraw),"existing_indexed_files":509,"existing_all_raw_and_original_hashes_pass":True,"candidate_files":len(candidates),"candidate_raw_bytes":sum(x["bytes"] for x in candidates),"excluded_live":skipped,"files":candidates}
OUT.write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps({k:v for k,v in out.items() if k!="files"},indent=2),flush=True)
