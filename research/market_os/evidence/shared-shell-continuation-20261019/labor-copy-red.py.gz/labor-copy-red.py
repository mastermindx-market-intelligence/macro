from pathlib import Path
import subprocess,json,hashlib,datetime
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27")
E=Path("/tmp/shared-shell-css-visual-20261019T1107")
head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=W,text=True).strip()
assert head=="8b51fb46d18739a4d10d1ef07dce3ca0f989f0da"
assert subprocess.check_output(["git","status","--porcelain=v1"],cwd=W,text=True)==""
cmd=[str(W/".venv-shared-shell/bin/python"),"-B","-m","pytest","-q","tests/test_macro_command_copy_law.py::test_all_fifteen_built_pages_are_clean_outside_details","tests/test_macro_command_copy_law.py::test_user_facing_numbers_have_no_machine_floats"]
r={"source_head":head,"command":cmd,"started_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"expected":"reproduce exact inherited axis copy-law assertions"}
log=E/"labor-copy-red.log"
with log.open("wb") as f:p=subprocess.run(cmd,cwd=W,stdout=f,stderr=subprocess.STDOUT)
r.update({"exit":p.returncode,"finished_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"log_bytes":log.stat().st_size,"log_sha256":hashlib.sha256(log.read_bytes()).hexdigest(),"head_after":subprocess.check_output(["git","rev-parse","HEAD"],cwd=W,text=True).strip(),"status_after":subprocess.check_output(["git","status","--porcelain=v1"],cwd=W,text=True)})
(E/"labor-copy-red.json").write_text(json.dumps(r,indent=2)+"\n")
print(json.dumps(r,indent=2))
