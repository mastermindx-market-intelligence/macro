from pathlib import Path
import subprocess,json,hashlib,datetime,os,sys
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","--no-optional-locks","-C",str(W)]
H="2ae6498d0b9f2a088af2e827abf6527799757f8c";M="7a6e21cb7d6a38855b7e06432c94f61acb0fe6f1";OUT=E/"macro-2ae-7a6-composed-tests.json";PY=str(W/".venv-shared-shell/bin/python")
def git(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def snap():
 return {"head":git("rev-parse","HEAD").decode().strip(),"merge_head":git("rev-parse","MERGE_HEAD").decode().strip(),"index_tree":git("write-tree").decode().strip(),"unstaged":git("diff","--name-only").decode().splitlines(),"unmerged":git("ls-files","-u").decode()}
assert not OUT.exists()
adoption=json.loads((E/"macro-2ae-7a6-labor-adoption.json").read_text());before=snap()
assert adoption["state"]=="ADOPTED_STAGED" and before["index_tree"]==adoption["index_tree"]
assert before["head"]==H and before["merge_head"]==M and not before["unstaged"] and not before["unmerged"]
paths=[".github/ci/legacy-jobs.yml","tests/test_ci_pack.py","app/deploy/update.sh","templates/stock.html.j2","lib/macro_suite_labels.py","site/macro_labor_markets.html","tests/test_macro_command_copy_law.py","site/etfs.html","site/us_stocks.html","templates/sector_central.html.j2","site/sector_central.html"]
frozen={p:dg((W/p).read_bytes()) for p in paths}
changed=E/"macro-2ae-7a6-source-changed-paths.txt";assert not changed.exists();changed.write_bytes(git("diff","--cached","--name-only",M))
packing=["test_the_curated_exclusive_set_is_actually_declared","test_curated_exclusive_scopes_cover_their_own_import_closure","test_curated_exclusivity_drops_only_the_opaque_fallback_tier","test_exclusive_curation_narrows_ordinary_code_prs"]
commands=[
 ("packing",[PY,"-B","-m","pytest","-q","--tb=short",*["tests/test_ci_pack.py::"+n for n in packing]]),
 ("affected-source",[PY,"-B","-m","pytest","-q","--tb=short","tests/test_deploy_update_self_heal.py","tests/test_export_shared_shell_routes.py","tests/test_shared_shell_injection.py","tests/test_sector_central_gate.py","tests/test_macro_command_copy_law.py","tests/test_medtech_deployment.py"]),
 ("shell-js",["node","--test",*["tests/js/"+n for n in ["shared_shell_bridge.test.cjs","shared_shell_navigation_adapters.test.cjs","shared_shell_owner_adapters.test.cjs","shared_shell_terminal_handoff.test.cjs"]]]),
 ("p0b-closure",[PY,"-B","scripts/check_p0b_receipt_closure.py","--diff-file",str(changed),"--event","pull_request"]),
 ("template-sync",[PY,"-B","scripts/check_template_site_sync.py"]),
 ("owned-whitespace",G+["diff","--cached","--check",M])
]
out={"started_at":now(),"before":before,"scope":"Actual MedTech7a6 composed CI-scope/packing and affected updater, Shell, Sector, labor-copy checks. Unchanged P0B producing proof reused via separate exact lineage; local checks do not confer hosted/public/Terminal acceptance.","python":subprocess.check_output([PY,"--version"],text=True).strip(),"source_sha256":frozen,"commands":[]}
def save():OUT.write_text(json.dumps(out,indent=2)+"\n")
save()
for name,args in commands:
 log=E/("macro-2ae-7a6-composed-"+name+".log");assert not log.exists()
 row={"name":name,"args":args,"started_at":now(),"log":str(log)};out["commands"].append(row);save();print(json.dumps({"started":name,"at":row["started_at"]}),flush=True)
 with log.open("xb") as f:r=subprocess.run(args,cwd=W,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,"PYTHONDONTWRITEBYTECODE":"1"})
 raw=log.read_bytes();row.update(exit=r.returncode,finished_at=now(),log_bytes=len(raw),log_sha256=dg(raw));save()
 print(json.dumps({"finished":name,"exit":r.returncode,"tail":raw.decode(errors="replace").splitlines()[-15:]}),flush=True)
out["after"]=snap();out["index_unchanged"]=before==out["after"];out["source_unchanged"]=all(dg((W/p).read_bytes())==v for p,v in frozen.items())
out["pass"]=out["index_unchanged"] and out["source_unchanged"] and all(x["exit"]==0 for x in out["commands"]);out["finished_at"]=now();save()
print(json.dumps({"receipt":str(OUT),"sha256":dg(OUT.read_bytes()),"pass":out["pass"],"finished_at":out["finished_at"]}),flush=True)
sys.exit(0 if out["pass"] else 1)
