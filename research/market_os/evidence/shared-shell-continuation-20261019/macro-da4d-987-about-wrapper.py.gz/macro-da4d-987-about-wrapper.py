from pathlib import Path
import subprocess,json,hashlib,datetime,time,urllib.request,sys,signal
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");K=Path("/tmp/shared-shell-local-browser-r7-20261019/kit")
OUT=E/"macro-da4d-987-about-wrapper.json";MF=E/"macro-da4d-987-about-manifest.json";assert not OUT.exists() and not MF.exists()
def dg(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*a):return subprocess.check_output(["git","--no-optional-locks","-C",str(W),*a])
c=json.loads((E/"macro-da4d-987-source-commit.json").read_text());assert c["state"]=="SOURCE_COMMITTED_LOCAL_ONLY"
H=c["head_after"];assert git("rev-parse","HEAD").decode().strip()==H and not git("status","--porcelain=v1").strip()
PY=str(W/".venv-shared-shell/bin/python")
source={str(p):dg(p.read_bytes()) for p in [K/"fixture_manifest.py",K/"serve-readonly-macro.py",E/"macro-da4d-987-about-replay.py",W/"scripts/capture_page_evidence.py"]}
out={"started_at":now(),"source_head":H,"source_tree":c["source_tree"],"scope":"Existing source-bound About fixture replay after merged theme changed; same capture owner, no Terminal/public beta/auth proof","sources":source,"commands":[]}
def save():OUT.write_text(json.dumps(out,indent=2)+"\n")
def run(name,args):
 log=E/("macro-da4d-987-about-"+name+".log");assert not log.exists();row={"name":name,"args":args,"started_at":now()};out["commands"].append(row);save()
 with log.open("xb") as f:r=subprocess.run(args,cwd=W,stdout=f,stderr=subprocess.STDOUT)
 row.update(exit=r.returncode,finished_at=now(),log_bytes=log.stat().st_size,log_sha256=dg(log.read_bytes()));save();print(json.dumps({"name":name,"exit":r.returncode,"tail":log.read_text(errors="replace").splitlines()[-10:]}),flush=True);assert r.returncode==0
save();server=None;stream=None
def interrupted(signum,frame):raise InterruptedError("About wrapper signal "+str(signum))
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
try:
 run("manifest",[PY,"-B",str(K/"fixture_manifest.py"),"--macro-root",str(W),"--macro-head",H,"--out",str(MF)])
 mf=json.loads(MF.read_text());out["manifest"]={"sha256":dg(MF.read_bytes()),"files":len(mf["files"]),"total_bytes":mf["total_bytes"]};save()
 log=E/"macro-da4d-987-about-server.log";stream=log.open("xb")
 args=[PY,"-B",str(K/"serve-readonly-macro.py"),"--site-dir",str(W/"site"),"--manifest",str(MF)]
 server=subprocess.Popen(args,stdout=stream,stderr=subprocess.STDOUT);out["server"]={"pid":server.pid,"args":args,"started_at":now()};save()
 ready=False
 for i in range(30):
  assert server.poll() is None,"fixture server exited"
  try:
   with urllib.request.urlopen("http://127.0.0.1:3110/about.html",timeout=1) as r:
    body=r.read();ready=r.status==200 and dg(body)==mf["files"]["/about.html"]["sha256"] and r.headers.get("X-MMX-Fixture-Manifest")==out["manifest"]["sha256"]
  except (OSError,urllib.error.URLError):pass
  if ready:break
  time.sleep(.2)
 assert ready
 run("capture",[PY,"-B",str(E/"macro-da4d-987-about-replay.py"),"--head",H])
 result=json.loads((E/"macro-da4d-987-about-replay/actual.json").read_text())
 assert result["passed"] and result["contexts_closed"] and len(result["cells"])==8 and result["source_head"]==H and result["head_after"]==H
 for cell in result["cells"]:
  assert cell["passed"] and len(cell["keyboard"])==18
  for r in cell["responses"]:
   assert r["status"]==200 and r["sha256"]==mf["files"][r["path"]]["sha256"] and r["fixture_header"]==out["manifest"]["sha256"]
 out["capture"]={"sha256":dg((E/"macro-da4d-987-about-replay/actual.json").read_bytes()),"cells":8,"ordered_tabs_per_cell":18,"browser":result["browser_version"],"pass":True}
 out["pass"]=True
except BaseException as error:out["pass"]=False;out["error"]=repr(error)
finally:
 if server is not None:
  if server.poll() is None:server.terminate()
  server.wait(timeout=10);out["server"]["exit"]=server.returncode;out["server"]["closed_at"]=now()
 if stream is not None:stream.close()
 out["source_unchanged"]=all(dg(Path(p).read_bytes())==h for p,h in source.items())
 out["head_unchanged"]=git("rev-parse","HEAD").decode().strip()==H
 out["worktree_clean"]=not git("status","--porcelain=v1").strip()
 out["pass"]=bool(out.get("pass") and out["source_unchanged"] and out["head_unchanged"] and out["worktree_clean"])
 out["finished_at"]=now();save()
print(json.dumps(out,indent=2),flush=True)
sys.exit(0 if out["pass"] else 1)
