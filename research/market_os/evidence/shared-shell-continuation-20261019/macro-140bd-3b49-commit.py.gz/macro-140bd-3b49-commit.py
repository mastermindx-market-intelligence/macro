import datetime,hashlib,json,pathlib,subprocess
W=pathlib.Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=pathlib.Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","-C",str(W)]
H="140bd1ee79a44859915595fdf12c958c07a60e2b";M="3b49d6a5c8a6330652a926a8e5061e0dbb3d0387";R="e2d10f933587f58be8716505529a37f8839901f7";B="sol/market-os-shared-shell-design-20260924";T="5ffad38270d85abe5e7ace03f3c291ce405145a4"
out=E/"macro-140bd-3b49-commit.json";log=E/"macro-140bd-3b49-commit.log";assert not out.exists() and not log.exists()
def git(*a):return subprocess.check_output(G+list(a),text=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
v=json.loads((E/"macro-140bd-3b49-proof-import.json").read_text())
assert v["all_checks_pass"] and v["all_hashes_and_coverage_pass"] and v["final_index"]==T
assert git("rev-parse","HEAD").strip()==H and git("rev-parse","MERGE_HEAD").strip()==M
assert git("branch","--show-current").strip()==B and git("write-tree").strip()==T
assert not git("diff","--name-only").strip() and not git("ls-files","-u").strip()
assert git("ls-remote","--heads","origin","refs/heads/"+B).split()[0]==R
p=json.loads(subprocess.check_output(["gh","pr","view","7949","--json","url,state,headRefOid,labels,autoMergeRequest"],cwd=W,text=True))
assert p["url"]=="https://github.com/mastermindx-market-intelligence/macro/pull/7949"
assert p["state"]=="OPEN" and p["headRefOid"]==R and p["autoMergeRequest"] is None
assert not any(x["name"]=="merge-on-green" for x in p["labels"])
r={"started_at":now(),"head_before":H,"incoming":M,"expected_tree":T,"remote_before":R,"branch":B,"pr_precondition":p,"operation":"ordinary original-worktree merge completion; no push or arm","commit_attempted":True}
out.write_text(json.dumps(r,indent=2)+"\n")
with log.open("xb") as f:c=subprocess.run(G+["commit","-F",str(E/"macro-140bd-3b49-commit-message.txt")],stdout=f,stderr=subprocess.STDOUT)
r["exit"]=c.returncode;r["log"]={"path":str(log),"bytes":log.stat().st_size,"sha256":hashlib.sha256(log.read_bytes()).hexdigest()};out.write_text(json.dumps(r,indent=2)+"\n")
assert c.returncode==0,log.read_text()
r["head_after"]=git("rev-parse","HEAD").strip();r["parents"]=git("show","-s","--format=%P","HEAD").strip().split();r["tree_after"]=git("show","-s","--format=%T","HEAD").strip()
assert r["parents"]==[H,M] and r["tree_after"]==T
assert not git("status","--porcelain=v1").strip()
r.update(finished_at=now(),status="COMMITTED_NOT_PUSHED",clean=True)
out.write_text(json.dumps(r,indent=2)+"\n");print(json.dumps(r,indent=2),flush=True)
