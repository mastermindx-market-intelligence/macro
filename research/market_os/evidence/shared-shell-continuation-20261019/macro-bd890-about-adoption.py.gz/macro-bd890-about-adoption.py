import datetime,hashlib,json,pathlib,shutil,subprocess
W=pathlib.Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=pathlib.Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","-C",str(W)]
H="bd89047e4e403a93183c6a4763274e09acfdd044";M="7a6e21cb7d6a38855b7e06432c94f61acb0fe6f1"
R="mockups/evidence/shared-shell-css-20261019/about-footer";SRC=E/"macro-bd890-about-canonical";DST=W/R
OUT=E/"macro-bd890-about-adoption.json"
def dg(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def g(*a):return subprocess.check_output(G+list(a))
def save():OUT.write_text(json.dumps(o,indent=2)+"\n")
assert not OUT.exists() and not DST.exists(),"existing partial adoption must be reconciled"
assert g("rev-parse","HEAD").decode().strip()==H
assert not g("diff","--cached","--name-only").strip() and not g("ls-files","-u").strip()
assert set(g("diff","--name-only").decode().splitlines())=={"scripts/run_press.py","tests/test_press_run.py"}
expected={"scripts/run_press.py":"c435e0d33b7672a9f5b792ace3d05c2bc3eaa8a5d6dc134cd6879be1f1c03968","tests/test_press_run.py":"5fdf6e0bedb6add7bf31309b79ead1c1504004fd46a18f58d55dd4e5cab7ddee"}
for p,h in expected.items():assert dg((W/p).read_bytes())==h,p
capture=json.loads((E/"macro-bd890-about-canonical.json").read_text())
assert capture["capture_completed"] and capture["source_unchanged"] and capture["source_head"]==H
manifest_raw=(SRC/"manifest.json").read_bytes();assert dg(manifest_raw)==capture["manifest"]["sha256"]
fixture_raw=(E/"macro-bd890-about-fixture-manifest.json").read_bytes()
assert dg(fixture_raw)==capture["fixture_inventory"]["sha256"]
fixture=json.loads(fixture_raw)
assert len(fixture["files"])==53
def verify_fixture():
 for rel,row in fixture["files"].items():
  b=(W/"site"/rel.lstrip("/")).read_bytes()
  assert len(b)==row["bytes"] and dg(b)==row["sha256"],rel
verify_fixture()
owner=W/capture["capture_owner"]["path"];assert dg(owner.read_bytes())==capture["capture_owner"]["sha256"]
oldreceipt=W/"mockups/evidence/shared-shell-css-20261019/EVIDENCE.yml";oldraw=oldreceipt.read_bytes()
files=sorted(p for p in SRC.rglob("*") if p.is_file())
assert len(files)==6 and all(not p.is_symlink() for p in files)
o={"started_at":now(),"state":"ADOPTION_INTENT","source_head":H,"source_tree":capture["source_tree"],"capture_receipt_sha256":dg((E/"macro-bd890-about-canonical.json").read_bytes()),"source_files":expected,"adopted_files":[],"previous_receipt_sha256":dg(oldraw),"canonical_matrix":{"states":8,"unique_pngs":4,"palette":"LIGHT_ONLY","auth":"anonymous","public":False},"visual_review":"Principal inspected all four distinct canonical PNGs; footer wraps and no visible clipping was found. This is bounded visual inspection, not independent geometry or auth qualification."}
save()
shutil.copytree(SRC,DST)
for p in files:
 rel=p.relative_to(SRC);b=p.read_bytes();assert (DST/rel).read_bytes()==b
 o["adopted_files"].append({"path":R+"/"+str(rel),"bytes":len(b),"sha256":dg(b)})
(DST/"EVIDENCE.yml").write_text("schema: mastermind.page_evidence_receipt.v1\nchanged_paths:\n  - templates/landing.css\nmanifest: "+R+"/manifest.json\n")
(DST/"LIMITS.md").write_text("""# About footer evidence: scope and limits

This child receipt owns the existing narrow-screen footer rule in `templates/landing.css`. It preserves the canonical capture output bytes from `scripts/capture_page_evidence.py` version 1.3.0. The parent Shared Shell receipt and its evidence remain unchanged.

The actual capture at 2026-10-20 23:26 UTC contains eight anonymous REST states: desktop/mobile, EN/ZH, and requested light/dark. Requested and applied root states match. There are four unique content-addressed PNGs: each locale/viewport pair has byte-identical light and dark images. **LIGHT_ONLY** describes the observed visual palette. This does not establish a dark palette or a public theme-control journey.

The manifest and smell report preserve the local static-fixture HTTP 404 and console error for `/api/billing/offers/founding_pro`. They are not network-error-free evidence. Authenticated tiers and loading, empty, stale, and error states remain declared gaps.

Geometry summaries report no horizontal overflow and no overwide elements in the producer's reference observations. The producer records `measured_in` as EN/light/desktop with viewport summaries; these are not eight independent geometry measurements.

The wrapper receipt `macro-bd890-about-canonical.json` and the 53-file `macro-bd890-about-fixture-manifest.json`, retained in the original Shared Shell continuation proof pack, bind the actual capture to unchanged input bytes at head `bd89047e4e403a93183c6a4763274e09acfdd044`. The canonical manifest's original target/provenance fields are not rewritten.

Earlier 320/390/820/1440 EN/ZH diagnostics and 18 ordered Tab targets per cell remain separate supplemental evidence. This capture adds no public beta, Terminal, authentication, actual 200% zoom, keyboard, service recovery, or publication acceptance.
""")
for name in ("EVIDENCE.yml","LIMITS.md"):
 b=(DST/name).read_bytes();o["adopted_files"].append({"path":R+"/"+name,"bytes":len(b),"sha256":dg(b)})
assert oldreceipt.read_bytes()==oldraw
verify_fixture()
subprocess.run(G+["add","--","scripts/run_press.py","tests/test_press_run.py",R],check=True)
before=g("write-tree").decode().strip()
diff=E/"macro-bd890-ui-evidence-full-pr.diff"
assert not diff.exists()
diff.write_bytes(g("diff","--cached","--no-ext-diff",M,"--"))
cmd=[str(W/".venv-shared-shell/bin/python"),"-B","scripts/check_ui_visual_evidence.py","--diff-file",str(diff),"--repo-root",str(W)]
log=E/"macro-bd890-ui-evidence-gate.log";assert not log.exists()
o.update(state="CANONICAL_BYTES_ADOPTED_GATE_INTENT",staged_tree=before,guard_sha256=dg((W/"scripts/check_ui_visual_evidence.py").read_bytes()),diff={"base":M,"bytes":diff.stat().st_size,"sha256":dg(diff.read_bytes())},command=cmd);save()
with log.open("xb") as f:r=subprocess.run(cmd,cwd=W,stdout=f,stderr=subprocess.STDOUT)
o.update(gate_exit=r.returncode,gate_log={"path":str(log),"bytes":log.stat().st_size,"sha256":dg(log.read_bytes())},gate_finished_at=now());save()
print(log.read_text(errors="replace"),flush=True)
assert r.returncode==0,"actual visual guard failed; preserve result"
assert g("write-tree").decode().strip()==before and not g("diff","--name-only").strip()
assert g("rev-parse","HEAD").decode().strip()==H and oldreceipt.read_bytes()==oldraw
verify_fixture()
for p,h in expected.items():assert dg((W/p).read_bytes())==h,p
o.update(state="CANONICAL_ABOUT_ADOPTED_VISUAL_GATE_PASS",source_inputs_unchanged=True,index_unchanged_during_gate=True,old_receipt_unchanged=True,finished_at=now());save()
print(json.dumps(o,indent=2))
