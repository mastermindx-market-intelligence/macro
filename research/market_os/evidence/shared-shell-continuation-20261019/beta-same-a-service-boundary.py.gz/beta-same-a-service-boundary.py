from pathlib import Path
import subprocess,json,hashlib,datetime,sys
E=Path("/tmp/shared-shell-css-visual-20261019T1107");A="e45bde2cac07ac3b29285ff70c40d68900fad62c"
BASE=["ssh","-i","/Users/chriswong/.ssh/macro_dashboard_deploy_v2","-o","BatchMode=yes","-o","IdentitiesOnly=yes","-o","IdentityAgent=none","-o","StrictHostKeyChecking=yes","-o","ConnectTimeout=8","root@146.190.142.17"]
SOURCES={"health":("macro-b312-prearm-health-remote-v3.py","ae53acf844cca7a86559643ba26d2b9a7db29d6d01f59093a6dc1fbd2acda21e"),"unit":("beta-loaded-unit-root-observer-v2.py","09568929c4e580b9a40e71d1ef936c69beed0ac0feafb1b01bbaf4f953c8221c")}
def dg(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def run_read(kind,phase):
 name,sha=SOURCES[kind];raw=(E/name).read_bytes();assert dg(raw)==sha
 stem="beta-same-a-"+phase+"-"+kind;out=E/(stem+".stdout.json");err=E/(stem+".stderr.log");rec=E/(stem+".json")
 assert not any(p.exists() for p in [out,err,rec])
 row={"started_at":now(),"source":name,"source_sha256":sha,"command":BASE+["python3 -I -B -"],"scope":"Read-only action-boundary observation; no reservation or service effect"}
 with out.open("xb") as f,err.open("xb") as e:
  p=subprocess.run(BASE+["python3 -I -B -"],input=raw,stdout=f,stderr=e,timeout=45)
 row.update(exit=p.returncode,finished_at=now(),stdout={"bytes":out.stat().st_size,"sha256":dg(out.read_bytes())},stderr={"bytes":err.stat().st_size,"sha256":dg(err.read_bytes())})
 rec.write_text(json.dumps(row,indent=2)+"\n")
 assert p.returncode==0 and not err.read_bytes(),row
 return json.loads(out.read_text()),row
def props(r):
 assert r["exit"]==0 and not r["stderr"] and not r["truncated"] and not r["timed_out"],r
 return dict(x.split("=",1) for x in r["stdout"].splitlines() if "=" in x)
def complete(r):assert r["read_complete"] and r["ancestor_trusted"] and r["metadata"]["uid"]==0 and r["metadata"]["gid"]==0 and r["metadata"]["kind"]=="regular" and r["metadata"]["nlink"]==1,r["path"]
def validate_health(h,active):
 for key in ["release_before","release_after"]:
  r=h[key];assert r["sample_clear"] and not r["lock"]["archives"] and r["reservation"] is False
 assert not h["pending_exists"] and h["beta_stages"]=={"entries":[],"truncated":False}
 for key,sha,target in [
  ("runtime_pointer","698204ef4ad72a1bfa896110af875df080bf773687150890e8a2322bd6b452d7","runtime-accepted-"+A+"-c62950826aca6fd8.json"),
  ("source_pointer","9aac8ec8c132eecf4d2664d8f1e18e8a6bffce5f6d7176e4021b15d6d953cfa4","source-provisioned-"+A+"-efb499b6d0108d69.json")]:
  r=h[key];complete(r);assert r["sha256"]==sha and r["resolved"]=="/var/lib/mastermind-terminal-beta/source-provisioned/"+target
  assert r["pointer_stable"] and r["target_ancestor_trusted"] and r["pointer_ancestor_trusted"] and r["pointer_metadata"]["uid"]==0 and r["pointer_metadata"]["gid"]==0 and r["metadata"]["mode"]=="0o640"
 r=h["beta_source_HEAD"];assert r["exit"]==0 and r["stdout"].strip()==A and not r["stderr"] and not r["truncated"] and not r["timed_out"]
 for r,expected in zip(h["beta_build"],[A,"build-TfctsWXpff2fKS"]):complete(r);assert r["text"]==expected and r["metadata"]["mode"]=="0o644"
 assert len(h["beta_build"])==2
 b=props(h["services"]["terminal-beta.service"]);assert b==props(h["beta_after"]) and b["UnitFileState"]=="enabled"
 if active:
  assert b["ActiveState"]=="active" and b["SubState"]=="running" and int(b["MainPID"])>0 and int(b["ExecMainStartTimestampMonotonic"])>0
  s=h["status"];assert s.get("status")==200 and not s["truncated"] and s["proxy_disabled"] and s["redirects_disabled"]
  assert s["body"]=={"enabled":True,"protocol":"mmx.shared-shell.v1","buildId":A,"bridgeVersion":"20261018.1","documentVersion":"20261018.1","registrySha256":"5307ea5a7964fde609a8f20f1af30b6bf483b7631f7232e5db74f9ef1d710023"}
  assert s["headers"]["cache-control"]=="private, no-store, max-age=0"
 else:assert b["ActiveState"]=="inactive" and b["SubState"]=="dead" and b["MainPID"]=="0"
 assert h["production_build"]==h["production_after"]["build"] and h["production_owner"]==h["production_after"]["owner"] and h["caddy"]==h["caddy_after"]
 assert props(h["services"]["terminal.service"])==props(h["production_after"]["service"])
 for r in h["production_build"]+[h["production_owner"],h["caddy"]]:complete(r)
 assert h["production_owner"]["sha256"]=="c6759cc653e0f19102a015ec52842795bde24eb85766d2e73f3024b4eefe409d"
 for r in [h["services"]["terminal.service"],*h["macro"]["services"].values()]:
  q=props(r);assert q["ActiveState"]=="active" and q["SubState"]=="running" and int(q["MainPID"])>0
 return b
def validate_unit(u,active):
 assert u["observations_stable"] and u["before"]==u["after"] and len(u["files"])==1
 f=u["files"][0];assert f["path"]=="/etc/systemd/system/terminal-beta.service" and f["bytes"]==5832 and f["sha256"]=="50e577a4651268ef377a1d3d5d00d90a36b7ae821847656c2a2125bdecc64d84" and f["git_blob"]=="3ee44fc8762b3e5d661e1eadc2780a0e5200f574"
 assert f["uid"]==f["gid"]==0 and f["mode"]=="0o644" and f["path_binding_stable"]
 d=u["before"]["properties"]
 for k,v in {"Id":"terminal-beta.service","Names":"terminal-beta.service","LoadState":"loaded","UnitFileState":"enabled","DropInPaths":"","NeedDaemonReload":"no","User":"terminal-beta","Group":"terminal-beta","Restart":"no","KillMode":"control-group","KillSignal":"15","TimeoutStopUSec":"30s","SendSIGKILL":"yes","StopWhenUnneeded":"no","RefuseManualStop":"no"}.items():assert d[k]==v,(k,d.get(k))
 for k in ["Requisite","RequisiteOf","BindsTo","PartOf","RequiredBy","BoundBy","ConsistsOf","ConflictedBy","PropagatesStopTo","StopPropagatedFrom","OnFailure","OnSuccess"]:assert d[k]=="",(k,d.get(k))
 for k in ["SuccessAction","FailureAction","JobTimeoutAction","StartLimitAction"]:assert d[k]=="none"
 assert all(not x["nonempty"] for x in u["before"]["command_hooks"].values())
 assert set(d["Requires"].split())=={"system.slice","opt-terminal.mount","sysinit.target","-.mount"} and set(d["Wants"].split())=={"network-online.target","tmp.mount"}
 assert d["Conflicts"]=="shutdown.target" and d["WantedBy"]=="multi-user.target"
 assert d["ActiveState"]==("active" if active else "inactive") and d["SubState"]==("running" if active else "dead")
 return {k:v for k,v in d.items() if k not in ["ActiveState","SubState","MainPID","ExecMainStartTimestampMonotonic"]}
def production(h):
 return {"service":props(h["services"]["terminal.service"]),"build":h["production_build"],"owner":h["production_owner"],"caddy_file":h["caddy"],"macro_caddy_services":{k:props(v) for k,v in h["macro"]["services"].items()}}
def beta_identity(h):return {k:h[k] for k in ["beta_source_HEAD","runtime_pointer","source_pointer","beta_build"]}
def main():
 phase="preflight";OUT=E/"beta-same-a-preflight.json";assert not OUT.exists()
 h,hr=run_read("health",phase);u,ur=run_read("unit",phase)
 b=validate_health(h,True);static=validate_unit(u,True)
 assert all(u["before"]["properties"][k]==b[k] for k in b)
 out={"started_at":hr["started_at"],"finished_at":now(),"state":"READ_ONLY_PREFLIGHT_PASS","accepted_A":A,"service":b,"unit_static":static,"production_baseline":production(h),"beta_identity":beta_identity(h),"health_receipt":hr,"unit_receipt":ur,"reservation":False,"stop_or_start_executed":False,"public_acceptance":False,"full_hostname_withdrawal":False,"A_to_B_to_A":False}
 OUT.write_text(json.dumps(out,indent=2)+"\n");print(json.dumps({"state":out["state"],"service":b,"production_service":out["production_baseline"]["service"],"RequisiteOf":static["RequisiteOf"],"receipt":str(OUT),"sha256":dg(OUT.read_bytes())},indent=2))
if __name__=="__main__":main()
