from pathlib import Path
import datetime,difflib,hashlib,json,subprocess,sys
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107")
D=E/"macro-bd890-press-replay-red";OUT=E/"macro-bd890-press-replay-red.json";H="bd89047e4e403a93183c6a4763274e09acfdd044"
def dg(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*a):return subprocess.check_output(["git","--no-optional-locks","-C",str(W),*a])
assert not D.exists() and not OUT.exists()
assert git("rev-parse","HEAD").decode().strip()==H and not git("status","--porcelain").strip()
before={str(p.relative_to(W)):dg(p.read_bytes()) for p in (W/"site/blog").rglob("*") if p.is_file()}
D.mkdir();S=D/"site";S.mkdir();sys.path.insert(0,str(W))
from scripts import build_free_content as B
from scripts import run_press as R
from lib import shared_shell as C
out={"started_at":now(),"source_head":H,"scope":"Actual existing estate owner in scratch only; compare press projection without invoking emit or writing tracked output.","source_sha256":{p:dg((W/p).read_bytes()) for p in ["scripts/run_press.py","scripts/build_free_content.py","lib/shared_shell.py","lib/pages.py","scripts/optimize_assets.py"]},"changed":[]}
OUT.write_text(json.dumps(out,indent=2)+"\n")
B.render_all(S);seeded=B._seed_hashable_assets(S);B._normalize_like_render_lane(S)
for src in sorted((S/"blog").rglob("*")):
 if not src.is_file():continue
 rel=src.relative_to(S);dst=W/"site"/rel
 if R._same_page(src,dst):continue
 a=src.read_bytes();b=dst.read_bytes() if dst.is_file() else b""
 row={"path":str(rel),"built_bytes":len(a),"built_sha256":dg(a),"committed_bytes":len(b),"committed_sha256":dg(b)}
 if src.suffix==".html":
  aa=B._comparable(a.decode());bb=B._comparable(b.decode())
  row["only_owned_shell_block"]=C.BLOCK.sub("",aa)==C.BLOCK.sub("",bb)
  row["built_blocks"]=aa.count(C.START);row["committed_blocks"]=bb.count(C.START)
  norm=lambda t:C.inject_shared_shell_text(t,"/",version="00000000",css_version="00000000")
  try:row["canonical_owner_projection_equal"]=B._comparable(norm(a.decode()))==B._comparable(norm(b.decode()))
  except ValueError as ex:row["canonical_owner_projection_error"]=str(ex)
  diff="".join(difflib.unified_diff(bb.splitlines(True),aa.splitlines(True),fromfile="committed/"+str(rel),tofile="built/"+str(rel)))
  path=D/(str(rel).replace("/","--")+".diff");path.write_text(diff)
  row["projected_diff"]={"file":path.name,"bytes":path.stat().st_size,"sha256":dg(path.read_bytes())}
  backup=D/(str(rel).replace("/","--")+".committed.html");backup.write_bytes(b)
 out["changed"].append(row)
after={str(p.relative_to(W)):dg(p.read_bytes()) for p in (W/"site/blog").rglob("*") if p.is_file()}
out.update(finished_at=now(),tracked_blog_unchanged=before==after,worktree_clean=not git("status","--porcelain").strip(),head_unchanged=git("rev-parse","HEAD").decode().strip()==H,seeded_assets=len(seeded))
OUT.write_text(json.dumps(out,indent=2)+"\n");print(json.dumps(out,indent=2))
assert out["tracked_blog_unchanged"] and out["worktree_clean"] and out["head_unchanged"]
