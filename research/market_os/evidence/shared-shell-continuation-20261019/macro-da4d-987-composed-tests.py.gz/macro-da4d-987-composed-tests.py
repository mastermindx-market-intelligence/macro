from pathlib import Path
import subprocess,json,hashlib,datetime,os,sys
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","--no-optional-locks","-C",str(W)]
H="da4df7d1e1ac709055c6fa1d482304a875e81824";M="9875169102cc6f36a64d465fe7c06f6bb8fb0220";OUT=E/"macro-da4d-987-composed-tests.json";PY=str(W/".venv-shared-shell/bin/python")
def git(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def snap():
 return {"head":git("rev-parse","HEAD").decode().strip(),"merge_head":git("rev-parse","MERGE_HEAD").decode().strip(),"index_tree":git("write-tree").decode().strip(),"unstaged":git("diff","--name-only").decode().splitlines(),"unmerged":git("ls-files","-u").decode()}
assert not OUT.exists()
bind=json.loads((E/"macro-da4d-987-p0b-binding.json").read_text());before=snap()
assert bind["state"]=="ACTUAL_PROOF_BOUND_STAGED" and before["index_tree"]==bind["index_tree"]
assert before["head"]==H and before["merge_head"]==M and not before["unstaged"] and not before["unmerged"]
paths=[".github/ci/legacy-jobs.yml","tests/test_ci_pack.py","lib/macro_suite_labels.py","site/macro_labor_markets.html","tests/test_macro_command_copy_law.py","site/theme.js","site/mm_brain.js","templates/chat.html","site/chat.html","templates/sector_central.html.j2","site/sector_central.html"]
frozen={p:dg((W/p).read_bytes()) for p in paths}
changed=E/"macro-da4d-987-source-changed-paths.txt";assert not changed.exists();changed.write_bytes(git("diff","--cached","--name-only",M))
packing=["test_the_curated_exclusive_set_is_actually_declared","test_curated_exclusive_scopes_cover_their_own_import_closure","test_curated_exclusivity_drops_only_the_opaque_fallback_tier","test_exclusive_curation_narrows_ordinary_code_prs"]
suite=["tests/test_macro_rates_curves_route.py","tests/test_macro_monetary_hub.py","tests/test_macro_suite_pages.py","tests/test_macro_workspace_prior_publication.py","tests/test_macro_command_shell.py","tests/test_macro_command_copy_law.py","tests/test_macro_command_read_strip.py","tests/test_macro_command_panels.py","tests/test_macro_command_empty_states.py","tests/test_macro_command_p4_copy.py","tests/test_macro_command_capture_guards.py"]
shell=["tests/test_export_shared_shell_routes.py","tests/test_shared_shell_injection.py"]
access=["tests/test_sector_central_gate.py","tests/test_site_access_boundary.py","tests/test_regwall.py","tests/test_regwall_json_gate.py"]
p0b=["test_rendered_fixture_recipe_is_committed_self_binding_and_deterministic","test_committed_browser_receipts_are_self_binding_fixture_proof","test_visual_manifest_preserves_history_and_appends_bounded_repair"]
commands=[
 ("packing",[PY,"-B","-m","pytest","-q","--tb=short",*["tests/test_ci_pack.py::"+n for n in packing]]),
 ("labor-suite",[PY,"-B","-m","pytest","-q","--tb=short",*suite]),
 ("shell-access",[PY,"-B","-m","pytest","-q","--tb=short",*shell,*access]),
 ("shell-js",["node","--test",*["tests/js/"+n for n in ["shared_shell_bridge.test.cjs","shared_shell_navigation_adapters.test.cjs","shared_shell_owner_adapters.test.cjs","shared_shell_terminal_handoff.test.cjs"]]]),
 ("p0b-binding",[PY,"-B","-m","pytest","-q","--tb=short",*["tests/test_stock_dashboard_first_frame.py::"+n for n in p0b]]),
 ("p0b-closure",[PY,"-B","scripts/check_p0b_receipt_closure.py","--diff-file",str(changed),"--event","pull_request"]),
 ("template-sync",[PY,"-B","scripts/check_template_site_sync.py"]),
 ("owned-whitespace",G+["diff","--cached","--check",M])
]
out={"started_at":now(),"before":before,"scope":"Actual composed candidate checks; local Python is separate from hosted admission. Original fixture/browser proof already executed; no Terminal or public acceptance.","python":subprocess.check_output([PY,"--version"],text=True).strip(),"source_sha256":frozen,"commands":[]}
def save():OUT.write_text(json.dumps(out,indent=2)+"\n")
save()
for name,args in commands:
 log=E/("macro-da4d-987-composed-"+name+".log");assert not log.exists()
 row={"name":name,"args":args,"started_at":now(),"log":str(log)};out["commands"].append(row);save();print(json.dumps({"started":name,"at":row["started_at"]}),flush=True)
 with log.open("xb") as f:r=subprocess.run(args,cwd=W,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,"PYTHONDONTWRITEBYTECODE":"1"})
 raw=log.read_bytes();row.update(exit=r.returncode,finished_at=now(),log_bytes=len(raw),log_sha256=dg(raw));save()
 print(json.dumps({"finished":name,"exit":r.returncode,"tail":raw.decode(errors="replace").splitlines()[-15:]}),flush=True)
out["after"]=snap();out["index_unchanged"]=before==out["after"];out["source_unchanged"]=all(dg((W/p).read_bytes())==v for p,v in frozen.items())
out["pass"]=out["index_unchanged"] and out["source_unchanged"] and all(x["exit"]==0 for x in out["commands"]);out["finished_at"]=now();save()
print(json.dumps({"receipt":str(OUT),"sha256":dg(OUT.read_bytes()),"pass":out["pass"],"finished_at":out["finished_at"]}),flush=True)
sys.exit(0 if out["pass"] else 1)
