## Why

Shared Shell keeps navigation, account ownership, preferences and the content host in the existing Terminal application while Macro's current HTML pages remain usable inside that host. Native page conversion can then proceed incrementally.

The Chairman's 2026-10-18 production commission supersedes the historical design-only hold. This is the Macro integration half of the original WS:MARKET-OS commission, paired with the already merged and browser-qualified Terminal #859 application `e45bde2cac07ac3b29285ff70c40d68900fad62c`.

## What changes

- Add the opt-in Shared Shell bridge to generated Macro documents while preserving standalone page behavior.
- Export the finite page registry and give the parent application authority over cross-page navigation and browser history. Preserve same-document query/hash state, canonical return destinations and Terminal handoffs.
- Keep account/settings actions with native owners and reject credential-bearing or authentication-token URLs at the bridge boundary.
- Require a completed document lifecycle, applied theme/language and exact protocol/document versions before READY; handle acknowledgements, repeated context, cleanup and retained document lifecycle.
- Add narrowly scoped Caddy embedding headers and beta data routing while retaining ordinary-document framing protection.
- Preserve the existing Sector Central views—overview, map, moving, money, explore and confluence—and sector-to-basket flow. The Paper redesign remains REVISE.
- Reconcile incoming main content through this same branch and worktree, and retain the architecture, migration plan, implementation reviews and producing evidence.

## Current delivery state

Published on the original branch: **b312bc4c08cf7633bf8fd259d2d46ec545fa120f**, ordinary merge parents `140bd1ee79a44859915595fdf12c958c07a60e2b` and current-main snapshot `3b49d6a5c8a6330652a926a8e5061e0dbb3d0387`. The normal push and remote readback completed on 2026-10-20 at 14:57 UTC. The original worktree is clean. The PR remains open and merge-on-green is unarmed while this head's hosted checks complete.

The interrupted proof finalizer had not committed or pushed. This continuation repaired its two EOF findings without discarding evidence: one newly appended README blank line was removed, and the original host-reader bytes were retained losslessly as gzip. The failed whitespace result and recovery receipts remain in the same proof pack.

The subsequent main integration preserves all 336 CI jobs, incoming content and both parent dependency intents. Its only generated conflicts were ETF and US Stocks, resolved through normalized-parent three-way composition and the existing page writer. Actual dependency-closure analysis identified three missing paths across two new CI jobs; only those paths were added. No further test ceilings, suite selectors, coverage requirements, authority policy or inventory limits were changed.

Installer/storage recovery remains complete through Terminal #1080 at protected owner revision `93e303cc32566e72fb086af6d04ba3aa41866c5c`. The accepted #859 application A remains active with its existing source/runtime receipts. The 14:42 read-only health observation confirms continuity. Production has a newly observed deployment/owner baseline, retained separately without attributing external changes or claiming continuous stability. No installer repeat is needed.

## Verification and durable evidence

- The four existing CI scope/packing tests passed in **210.00 seconds** on frozen source index `4e8952ea930e29d38874eee2c5ef60c5bc9fdaeb`; source and index remained unchanged.
- Earlier **334 deployment tests** and actual **128 P0B cases / 16 screenshots** remain bound to unchanged inputs. The current composition compares all **82** recorded P0B producing/output identities. Those results are reused, not presented as fresh runs.
- Fresh documentation/publication checks passed: AgentOS **0 errors** with 153 advisory warnings; **134 template/site pairs**; P0B receipt closure; and owned whitespace.
- The completed [proof pack](https://github.com/mastermindx-market-intelligence/macro/tree/b312bc4c08cf7633bf8fd259d2d46ec545fa120f/research/market_os/evidence/shared-shell-continuation-20261019) contains **509 indexed files**. Previous evidence/history, raw-source hashes, gzip round trips and exact directory coverage are preserved. Manifest SHA-256: `eafb91bd7ffb2bf6e8b9cecfe72eae2627ce01175d3ddd13a8f57f32e5031dc6`.
- Bounded independent reviews found the actual source composition, three-path repair and proof import NONBLOCKING, with their read scopes and limits retained.
- New-head [CI](https://github.com/mastermindx-market-intelligence/macro/actions/runs/39443974109), [fences](https://github.com/mastermindx-market-intelligence/macro/actions/runs/39443973732) and applicable authority remain the hosted admission boundary. The existing MOG owner determines applicable checks; the inactive merge-queue-pilot context does not become a main-branch requirement.

The [current full checkpoint](https://github.com/mastermindx-market-intelligence/macro/pull/7949#issuecomment-6264440177) binds the exact published head, effect receipts and live frontier, and preserves the complete earlier history. [Accepted beta recovery proof](https://github.com/mastermindx-market-intelligence/macro/pull/7949#issuecomment-6281354124).

## Remaining acceptance gates

Land through the existing Macro merge-on-green owner, consume the existing covering render/generated-main publication and actual served-tree proof, then complete public beta DNS/TLS, authentication, browser journeys at the required sizes and applicable rollback acceptance. The public hostname still reaches its previous DNS destination; public browser acceptance is not claimed. First-install containment and recovery of original application A are supported. Its previous accepted runtime is null; a future rollback baseline is recorded, but an executed upgrade rollback is not claimed.

C4 overlay/readiness/history suggestions remain SPEC_ONLY / UNAPPLIED / UNRUN. No replacement PR, renderer, source carrier or watcher is introduced.

Programme: `WS:MARKET-OS`. Root: `market-os-shared-shell-design-20260924-sol-001`. Attended parent: `shared-shell-production-20261018-c1`. Protected compatible INDEX and required-laws pin: `065b7fe719bb07407eae965ffb15e300ae2395f6`.
