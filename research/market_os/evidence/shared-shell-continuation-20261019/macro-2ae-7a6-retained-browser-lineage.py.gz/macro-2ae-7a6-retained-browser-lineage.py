from pathlib import Path
import subprocess,json,hashlib,datetime
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","--no-optional-locks","-C",str(W)]
H="2ae6498d0b9f2a088af2e827abf6527799757f8c";M="7a6e21cb7d6a38855b7e06432c94f61acb0fe6f1";OUT=E/"macro-2ae-7a6-retained-browser-lineage.json";P=E/"macro-608-df3-retained-browser-lineage.json"
def git(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
assert not OUT.exists() and dg(P.read_bytes())=="45640fc392162b589154e3aae278371647caaa6e2d7944782e337c245f48dd97"
previous=json.loads(P.read_text());assert previous["state"]=="RETAINED_FIXTURE_LINEAGE_VERIFIED"
assert git("rev-parse","HEAD").decode().strip()==H and git("rev-parse","MERGE_HEAD").decode().strip()==M
tree=git("write-tree").decode().strip();adopt=json.loads((E/"macro-2ae-7a6-labor-adoption.json").read_text());assert tree==adopt["index_tree"]
assert not git("ls-files","-u").strip() and not git("diff","--name-only").strip()
expected={}
groups={**{k:previous["p0b"][k] for k in ["source_inputs","bound_inputs","outputs"]},"about_unchanged":previous["about"]["unchanged_files"]}
for group in groups.values():
 for p,r in group.items():
  if p in expected:assert expected[p]["sha256"]==r["sha256"]
  expected[p]=r
expected["site/macro.html"]=previous["about"]["changed_manifest_members"]["site/macro.html"]["current"]
stage={}
for entry in git("ls-files","--stage","-z","--",*sorted(expected)).split(b"\0"):
 if not entry:continue
 left,p=entry.split(b"\t",1);mode,blob,index=left.decode().split();assert index=="0";stage[p.decode()]=blob
assert set(stage)==set(expected)
actual={}
for p,r in expected.items():
 b=(W/p).read_bytes();oid=hashlib.sha1(("blob "+str(len(b))+"\0").encode()+b).hexdigest()
 assert len(b)==r["bytes"] and dg(b)==r["sha256"] and oid==stage[p],p
 actual[p]={"bytes":len(b),"sha256":dg(b),"git_blob":oid}
assert git("write-tree").decode().strip()==tree and not git("diff","--name-only").strip()
out={"observed_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"head":H,"incoming":M,"source_index":tree,"state":"RETAINED_FIXTURE_LINEAGE_VERIFIED","index_and_source_unchanged":True,"preceding_lineage":{"source":str(P),"sha256":dg(P.read_bytes())},"group_counts":{k:len(v) for k,v in groups.items()},"unique_current_raw_stage_bindings":actual,"fresh_browser_execution":False,"p0b_claim":"Exact prior67 producer inputs,56 bound inputs and20 accepted outputs remain unchanged. Retain actual128cases/16screens/12historical entries; no new producer or restamp.","about_claim":"Exact52 prior presentation files and prior macro route observation remain unchanged in this7a6 merge. Reuse actual8cell/18Tab presentation proof; original6d56653-file manifest remains historical because macro.html had already changed atdf3.","public_beta_acceptance":False,"terminal859_requalification":False}
OUT.write_text(json.dumps(out,indent=2)+"\n");print(json.dumps({k:v for k,v in out.items() if k!="unique_current_raw_stage_bindings"},indent=2));print("receipt_sha256",dg(OUT.read_bytes()))
