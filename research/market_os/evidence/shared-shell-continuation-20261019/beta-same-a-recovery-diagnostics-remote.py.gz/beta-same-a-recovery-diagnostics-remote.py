import subprocess,json,socket,errno,datetime
p=subprocess.run(["systemctl","show","terminal-beta.service","--property=ActiveState,SubState,MainPID,ExecMainStartTimestampMonotonic,ExecMainExitTimestampMonotonic,ExecMainCode,ExecMainStatus,Result,StatusErrno,NRestarts,Job,ControlPID,ControlGroup"],capture_output=True,text=True,timeout=10)
r={"observed_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"command_exit":p.returncode,"stdout":p.stdout,"stderr":p.stderr}
try:
 s=socket.create_connection(("127.0.0.1",3001),timeout=5);s.close();r["connection"]={"connected":True}
except OSError as e:r["connection"]={"connected":False,"errno":e.errno,"type":type(e).__name__,"connection_refused":e.errno==errno.ECONNREFUSED}
print(json.dumps(r,indent=2))
