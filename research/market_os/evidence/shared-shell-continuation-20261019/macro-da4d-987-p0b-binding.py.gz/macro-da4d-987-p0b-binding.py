from pathlib import Path
import subprocess,json,hashlib,datetime,copy
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");P="mockups/evidence/prophet-p0b-zero-fouc/"
H="da4df7d1e1ac709055c6fa1d482304a875e81824";M="9875169102cc6f36a64d465fe7c06f6bb8fb0220";G=["git","--no-optional-locks","-C",str(W)]
OUT=E/"macro-da4d-987-p0b-binding.json"
def git(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def rd(p):
 b=(W/p).read_bytes();return {"bytes":len(b),"sha256":dg(b)}
assert not OUT.exists()
assert git("rev-parse","HEAD").decode().strip()==H and git("rev-parse","MERGE_HEAD").decode().strip()==M
prodpath=E/"macro-da4d-987-p0b-actual.json";prod=json.loads(prodpath.read_text())
assert prod["pass"] and prod["source_unchanged"] and len(prod["commands"])==3 and all(x["exit"]==0 for x in prod["commands"])
assert prod["head"]==H and prod["incoming"]==M
assert [x["name"] for x in prod["commands"]]==["render","hk","ca"]
assert prod["finished_at"]
for key in ["source_after","outputs_after"]:
 for p,row in prod[key].items():assert rd(p)==row,p
mpath=P+"manifest.json";old=(W/mpath).read_bytes();manifest=json.loads(old)
hp=json.loads(git("show",H+":"+mpath));mp=json.loads(git("show",M+":"+mpath))
base=lambda m:{k:v for k,v in m.items() if k not in ("repair_extension","repair_extension_history")}
assert base(manifest)==base(hp)==base(mp)
hist=manifest["repair_extension_history"];assert len(hist)==12 and hist[:10]==hp["repair_extension_history"]
for row,(r,m) in zip(hist[-2:],[(H,hp),(M,mp)]):
 assert row=={"extension":m["repair_extension"],"prior_manifest_sha256":dg(git("show",r+":"+mpath)),"source_head":r}
ext=copy.deepcopy(hp["repair_extension"]);ext["generated_at"]=now();ext["fixture_receipt"]={"path":P+"rendered-fixture.json","sha256":rd(P+"rendered-fixture.json")["sha256"]}
bindings={};shots=[];totals={"markets":0,"owner_cases_per_market":3,"primary_cases":0,"degraded_control_cases":0,"total_cases":0,"screenshots":0};bound_inputs={}
for market,name in [("hk","mobile-layout.json"),("ca","mobile-layout-canada.json")]:
 path=P+name;d=json.loads((W/path).read_text());pr=d["owner_projection_matrix"]
 assert d["pass"] is True and pr["pass"] is True and d["fixture_market"]==market
 assert d["claims"]==ext["claims"] and d["fixture_receipt"]["sha256"]==ext["fixture_receipt"]["sha256"]
 assert pr["primary_passed"]==48 and pr["degraded_controls_passed"]==16 and pr["screenshot_count"]==8
 assert len(pr["cases"])==64 and all(x["pass"] for x in pr["cases"])
 for key in ["loaded_assets","construction_inputs"]:
  for p,h in d[key].items():
   assert rd(p)["sha256"]==h,p
   if p in bound_inputs:assert bound_inputs[p]==h
   bound_inputs[p]=h
 localshots=[x["screenshot"] for x in pr["cases"] if x.get("screenshot")];assert len(localshots)==8
 for shot in localshots:
  assert rd(shot["path"])["sha256"]==shot["sha256"]
  shots.append({"path":shot["path"],"sha256":shot["sha256"]})
 bindings[market]={"path":path,"sha256":rd(path)["sha256"],"pass":d["pass"],"primary_cases":pr["primary_passed"],"degraded_control_cases":pr["degraded_controls_passed"],"screenshots":pr["screenshot_count"]}
 totals["markets"]+=1;totals["primary_cases"]+=pr["primary_passed"];totals["degraded_control_cases"]+=pr["degraded_controls_passed"];totals["total_cases"]+=len(pr["cases"]);totals["screenshots"]+=pr["screenshot_count"]
assert len({x["path"] for x in shots})==16 and totals["total_cases"]==128
ext.update(browser_receipts=bindings,screenshots=sorted(shots,key=lambda x:x["path"]),totals=totals)
ext["pass"]=all(x["pass"] for x in bindings.values())
new=copy.deepcopy(manifest);new["repair_extension"]=ext
assert {k:v for k,v in new.items() if k!="repair_extension"}=={k:v for k,v in manifest.items() if k!="repair_extension"}
raw=(json.dumps(new,indent=2,ensure_ascii=False)+"\n").encode()
selected=sorted(set([P+n for n in ["manifest.json","rendered-fixture.json","mobile-layout.json","mobile-layout-canada.json"]]+[x["path"] for x in shots]))
assert len(selected)==20
before_index=git("ls-files","--stage","-z")
out={"started_at":now(),"head":H,"incoming":M,"state":"BINDING_PREPARED","producer":{"path":str(prodpath),"sha256":dg(prodpath.read_bytes())},"manifest_before_sha256":dg(old),"manifest_after_sha256":dg(raw),"history_entries":12,"all_twelve_history_entries_and_basefields_unchanged":True,"current_extension":ext,"bound_inputs":bound_inputs,"selected_paths":selected,"before_index_sha256":dg(before_index)}
def save():OUT.write_text(json.dumps(out,indent=2)+"\n")
save();(W/mpath).write_bytes(raw)
subprocess.run(G+["add","--",*selected],check=True)
assert not git("ls-files","-u").strip()
for p in selected:assert git("show",":"+p)==(W/p).read_bytes(),p
for p,h in bound_inputs.items():
 assert rd(p)["sha256"]==h,p
 assert dg(git("show",":"+p))==h,p
assert not git("diff","--name-only").strip()
out.update(state="ACTUAL_PROOF_BOUND_STAGED",finished_at=now(),index_tree=git("write-tree").decode().strip(),actual_cases=128,screenshots=16,selected_staged_equal_raw=True,all_loaded_and_construction_inputs_raw_equal_staged=True,remaining_unmerged=[],unstaged_paths=[])
out["changed_paths_vs_incoming"]=len(git("diff","--cached","--name-only",M).decode().splitlines())
save();print(json.dumps({k:out[k] for k in ["state","index_tree","actual_cases","screenshots","changed_paths_vs_incoming","finished_at"]},indent=2))
