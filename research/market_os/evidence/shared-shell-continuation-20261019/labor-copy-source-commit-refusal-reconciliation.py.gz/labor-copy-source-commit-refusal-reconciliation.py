from pathlib import Path
import json,hashlib,subprocess,datetime
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107")
def git(*a):return subprocess.check_output(["git","-C",str(W),*a]).decode().strip()
assert git("rev-parse","HEAD")=="8b51fb46d18739a4d10d1ef07dce3ca0f989f0da"
assert not git("diff","--cached","--name-only")
assert not (E/"labor-copy-source-commit.json").exists()
p=E/"labor-copy-proof-lineage.json";assert hashlib.sha256(p.read_bytes()).hexdigest()=="a5a4e0f6b52b61752b70e7d3c63d0d613e8174b4fbc46c9675561ead749c1a31"
out={"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"earlier_pid":43815,"earlier_exit":1,"failure":"FileNotFoundError reading labor-copy-proof-lineage.json at source-commit.py line14, before staging or any commit/evidence mutation","cause":"Commit precondition invoked while lineage process41455 was still completing; no source write occurred.","lineage_now_complete":{"pid":41455,"exit":0,"sha256":hashlib.sha256(p.read_bytes()).hexdigest()},"head_unchanged":True,"index_unchanged":True,"source_commit_receipt_absent":True,"next":"Execute unchanged fenced source-commit script once"}
r=E/"labor-copy-source-commit-refusal-reconciliation.json";assert not r.exists();r.write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps(out,indent=2),flush=True)
subprocess.run(["python3","-B","-u",str(E/"labor-copy-source-commit.py")],check=True)
