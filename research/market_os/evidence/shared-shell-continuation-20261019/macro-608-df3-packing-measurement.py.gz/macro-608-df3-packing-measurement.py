from pathlib import Path
import subprocess,json,hashlib,datetime,ast,os,sys
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","-C",str(W)];H="608dfad299e2e48ab7703bf0b180e0dca1318229";M="df3cba80e5ff43e3411209381b32d9d4df06bd1f";OUT=E/"macro-608-df3-packing-measurement.json";D=E/"macro-608-df3-packing";PY=str(W/".venv-shared-shell/bin/python")
def git(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert not OUT.exists() and not D.exists()
assert git("rev-parse","HEAD").decode().strip()==H and git("rev-parse","MERGE_HEAD").decode().strip()==M and not git("ls-files","-u").strip() and not git("diff","--name-only").strip()
D.mkdir();before=git("write-tree").decode().strip();frozen={p:dg((W/p).read_bytes()) for p in [".github/ci/legacy-jobs.yml","tests/test_ci_pack.py","scripts/run_ci_pack.py","scripts/ci_scope_dependencies.py"]}
os.chdir(W);sys.path.insert(0,str(W))
from scripts.run_ci_pack import packing_probe_measurements,packing_probe_breaches,load_legacy_jobs
tree=ast.parse((W/"tests/test_ci_pack.py").read_text());vals={}
for n in tree.body:
 if isinstance(n,ast.Assign):
  for t in n.targets:
   if isinstance(t,ast.Name) and t.id in ["PACKING_PROBES","PACKING_PROBE_MAX_PACKS"]:vals[t.id]=ast.literal_eval(n.value)
out={"started_at":now(),"head":H,"incoming":M,"source_tree":before,"frozen_sources":frozen,"provisional_bounds":vals,"state":"MEASURING_ACTUAL_COMPOSITION","scope":"Existing canonical planner on actual merged tree; incoming weights below applied to same selected IDs, not a full incoming-tree selection replay"}
def save():OUT.write_text(json.dumps(out,indent=2)+"\n")
save()
rows=packing_probe_measurements(W/".github/ci/legacy-jobs.yml",vals["PACKING_PROBES"],max_packs=vals["PACKING_PROBE_MAX_PACKS"])
out["rows"]=rows;out["breaches"]=packing_probe_breaches(rows)
incoming=git("show",M+":.github/ci/legacy-jobs.yml");mp=D/"incoming.yml";mp.write_bytes(incoming);basejobs={j.job_id:j for j in load_legacy_jobs(mp)};current={j.job_id:j for j in load_legacy_jobs(W/".github/ci/legacy-jobs.yml")}
out["incoming_manifest_sha256"]=dg(incoming);out["weight_attribution"]=[]
for row in rows:
 assert all(j in basejobs for j in row["job_ids"])
 diff=[{"job":j,"incoming_weight":basejobs[j].weight,"candidate_weight":current[j].weight,"delta":current[j].weight-basejobs[j].weight} for j in row["job_ids"] if basejobs[j].weight!=current[j].weight]
 out["weight_attribution"].append({"probe":row["probe"],"same_candidate_selected_ids":row["job_ids"],"incoming_weight_on_same_ids":sum(basejobs[j].weight for j in row["job_ids"]),"candidate_weight":row["weight"],"deltas":diff,"ticker_news_selected":"ticker-news-qbus" in row["job_ids"],"ticker_news_incoming_weight":basejobs["ticker-news-qbus"].weight})
out.update(finished_at=now(),source_index_unchanged=git("write-tree").decode().strip()==before and not git("diff","--name-only").strip(),frozen_sources_unchanged=all(dg((W/p).read_bytes())==v for p,v in frozen.items()),state="ACTUAL_MEASUREMENT_COMPLETE")
assert out["source_index_unchanged"] and out["frozen_sources_unchanged"];save()
print(json.dumps({"state":out["state"],"rows":[{k:v for k,v in r.items() if k!="job_ids"} for r in rows],"breaches":out["breaches"],"attribution":[{k:v for k,v in r.items() if k!="same_candidate_selected_ids"} for r in out["weight_attribution"]],"receipt_sha256":dg(OUT.read_bytes())},indent=2))
