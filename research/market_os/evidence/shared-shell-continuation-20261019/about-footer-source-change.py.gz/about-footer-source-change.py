#!/usr/bin/env python3
"""Bounded About footer correction through the incumbent asset helpers."""
from pathlib import Path
import subprocess, sys, json, hashlib, difflib, datetime
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27")
E=Path("/tmp/shared-shell-css-visual-20261019T1107")
H="b312bc4c08cf7633bf8fd259d2d46ec545fa120f"
OUT=E/"about-footer-source"
OUT.mkdir(exist_ok=False)
def git(*args): return subprocess.check_output(["git",*args],cwd=W,text=True)
def sha(b): return hashlib.sha256(b).hexdigest()
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert git("rev-parse","HEAD").strip()==H
assert git("status","--porcelain=v1")==""
paths=["templates/landing.css","site/landing.css","templates/about.html","site/about.html","templates/index.html","site/index.html","site/products/market-terminal.html","site/products/market-dashboards.html","site/products/mastermind-ai.html"]
before={p:(W/p).read_bytes() for p in paths}
assert before["templates/landing.css"]==before["site/landing.css"]
assert sha(before["templates/landing.css"]).startswith("a44e4256")
needle=b"@media (max-width:680px){\n"
assert before["templates/landing.css"].count(needle)==1
candidate=before["templates/landing.css"].replace(needle,needle+b"  .f-cols{flex-wrap:wrap;min-width:0;max-width:100%}\n",1)
for rel,data in before.items():
 p=OUT/"before"/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
sys.path.insert(0,str(W))
from scripts.optimize_assets import make_optimizer
from lib.shared_shell import inject_shared_shell_text
from lib.pages import dbase_prefix, write_page
old_optimizer=make_optimizer(W/"site")
before_canonical={p:old_optimizer(before[p].decode(),W/"site" if p.startswith("templates/") else (W/p).parent) for p in paths if p.endswith(".html")}
receipt={"schema":"mastermind.about_footer_source_change.v1","started_at":now(),"base_head":H,"owner":"templates/landing.css plus incumbent scripts.optimize_assets.make_optimizer/lib.shared_shell/lib.pages","writes":[],"new_renderer":False}
def journal():
 (E/"about-footer-source-change.json").write_text(json.dumps(receipt,indent=2)+"\n")
def record(rel):
 b=(W/rel).read_bytes();receipt["writes"].append({"path":rel,"before_sha256":sha(before[rel]),"after_sha256":sha(b),"bytes":len(b)});journal()
journal()
for rel in paths[:2]:
 (W/rel).write_bytes(candidate);record(rel)
optimized=make_optimizer(W/"site")
for name in ["about.html","index.html"]:
 tpl=W/"templates"/name; site=W/"site"/name
 text=tpl.read_text()
 new=optimized(inject_shared_shell_text(text,dbase_prefix(site),site_dir=W/"site",response_kind="content"),W/"site")
 tpl.write_text(new);record("templates/"+name)
 site.write_text(new);record("site/"+name)
for rel in paths[6:]:
 p=W/rel;text=p.read_text()
 new=optimized(inject_shared_shell_text(text,dbase_prefix(p),site_dir=W/"site",response_kind="content"),p.parent)
 write_page(p,new);record(rel)
changed=git("diff","--name-only").splitlines()
assert set(changed)==set(paths),(changed,paths)
receipt["preexisting_canonical_stamp_drift"]=[p for p,t in before_canonical.items() if t.encode()!=before[p]]
receipt["css_sha256"]=sha(candidate)
receipt["diff_stat"]=git("diff","--stat")
patch=git("diff","--",*paths)
(E/"about-footer-source.patch").write_text(patch)
receipt["diff_sha256"]=sha(patch.encode())
receipt["whitespace_check"]=subprocess.run(["git","diff","--check"],cwd=W,capture_output=True,text=True).__dict__
receipt["whitespace_check"]={k:receipt["whitespace_check"][k] for k in ["returncode","stdout","stderr"]}
assert receipt["whitespace_check"]["returncode"]==0
for name in ["landing.css","about.html","index.html"]:
 assert (W/"templates"/name).read_bytes()==(W/"site"/name).read_bytes()
receipt["finished_at"]=now();receipt["complete"]=True;journal()
print(json.dumps({k:receipt[k] for k in ["base_head","css_sha256","preexisting_canonical_stamp_drift","diff_stat","complete"]},indent=2))
