import ast,collections,copy,datetime,hashlib,json,os,pathlib,subprocess,sys,yaml
W=pathlib.Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=pathlib.Path("/tmp/shared-shell-css-visual-20261019T1107");D=E/"macro-140bd-3b49-html-canonical-merge";G=["git","-C",str(W)]
H="140bd1ee79a44859915595fdf12c958c07a60e2b";B="5c2d0a04afd19642d2dab483885d46c73b7baed4";M="3b49d6a5c8a6330652a926a8e5061e0dbb3d0387"
outpath=E/"macro-140bd-3b49-composition.json"
def git(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save():outpath.write_text(json.dumps(out,indent=2)+"\n")
def sub(a,b):
 it=iter(b)
 return all(any(x==v for v in it) for x in a)
assert not outpath.exists()
assert git("rev-parse","HEAD").decode().strip()==H and git("rev-parse","MERGE_HEAD").decode().strip()==M
assert git("diff","--name-only","--diff-filter=U").decode().splitlines()==["site/etfs.html","site/us_stocks.html"]
manifest=".github/ci/legacy-jobs.yml"
b,h,m=[yaml.safe_load(git("show",r+":"+manifest))["jobs"] for r in [B,H,M]]
current_raw=(W/manifest).read_bytes();c=yaml.safe_load(current_raw)["jobs"]
assert len(c)==len(m)==336 and list(c)==list(m)
assert set(h)<=set(c) and set(c)==set(h)|set(m)
for k in c:
 if k not in h:assert c[k]==m[k],k;continue
 hb={a:v for a,v in h[k].items() if a!="paths"};mb={a:v for a,v in m[k].items() if a!="paths"};bb={a:v for a,v in b[k].items() if a!="paths"};cb={a:v for a,v in c[k].items() if a!="paths"}
 if hb==bb:assert cb==mb,k
 elif mb==bb:assert cb==hb,k
 else:assert hb==mb==cb,k
 hp=h[k].get("paths",[]);mp=m[k].get("paths",[]);cp=c[k].get("paths",[])
 assert collections.Counter(cp)==collections.Counter(hp)|collections.Counter(mp),k
 assert sub(hp,cp) and sub(mp,cp),k
assert git("show",":"+manifest)==current_raw
test="tests/test_ci_pack.py";incoming_test=git("show",M+":"+test).decode();test_raw=(W/test).read_bytes();actual=ast.parse(test_raw);expected=ast.parse(incoming_test);counts={5822:0,5697:0}
for node in ast.walk(expected):
 if isinstance(node,ast.Constant) and isinstance(node.value,int) and node.value in counts:
  counts[node.value]+=1;node.value={5822:5829,5697:5704}[node.value]
assert counts=={5822:1,5697:1}
fn="test_exclusive_curation_narrows_ordinary_code_prs"
ef=next(n for n in expected.body if isinstance(n,ast.FunctionDef) and n.name==fn);af=next(n for n in actual.body if isinstance(n,ast.FunctionDef) and n.name==fn)
hf=next(n for n in ast.parse(git("show",H+":"+test).decode()).body if isinstance(n,ast.FunctionDef) and n.name==fn)
assert sub(ast.get_docstring(hf,clean=False).splitlines(),ast.get_docstring(af,clean=False).splitlines())
assert sub(ast.get_docstring(ef,clean=False).splitlines(),ast.get_docstring(af,clean=False).splitlines())
ef.body[0]=copy.deepcopy(af.body[0])
assert ast.dump(expected,include_attributes=False)==ast.dump(actual,include_attributes=False)
plan=json.loads((D/"receipt.json").read_text());assert plan["all_clean"] and plan["head"]==H and plan["incoming"]==M
os.chdir(W);sys.path.insert(0,str(W))
from scripts.optimize_assets import make_optimizer
from scripts.check_template_site_sync import _STAMP_RE
from lib.shared_shell import inject_shared_shell_text,START,END
from lib.pages import dbase_prefix,write_page
opt=make_optimizer((W/"site").resolve())
versions=[dg((W/"site"/p).read_bytes())[:8] for p in ["shared_shell_bridge.js","shared_shell.css"]]
prepared={}
for row in plan["rows"]:
 p=row["path"];raw=pathlib.Path(row["result"]).read_bytes();assert dg(raw)==row["result_sha256"]
 text=inject_shared_shell_text(raw.decode(),dbase_prefix(W/p),version=versions[0],css_version=versions[1],site_dir=W/"site")
 text=opt(text,(W/p).parent.resolve())
 assert not any(mark in text for mark in ["<<<<<<< H","||||||| B",">>>>>>> M"])
 assert text.count(START)==text.count(END)==1 and not any(x.group(2)=="00000000" for x in _STAMP_RE.finditer(text))
 prepared[p]=text
out={"started_at":now(),"head":H,"base":B,"incoming":M,"manifest_jobs":len(c),"manifest_three_way_all_fields_and_ids_pass":True,"incoming_and_head_path_sequences_and_exact_counter_union_preserved":True,"all_new_jobs_preserved":sorted(set(c)-set(h)),"test_ast_equals_incoming_except_two_previously_measured_constants_and_preserved_history":True,"manifest_sha256":dg(current_raw),"test_sha256":dg(test_raw),"canonical_merge_receipt_sha256":dg((D/"receipt.json").read_bytes()),"source_writes_started":True};save()
for p,text in prepared.items():write_page(W/p,text)
subprocess.run(G+["add","--",*prepared],check=True)
assert not git("diff","--name-only").strip() and not git("ls-files","-u").strip()
out["index"]=git("write-tree").decode().strip()
out["resolved_files"]={p:{"bytes":(W/p).stat().st_size,"sha256":dg((W/p).read_bytes())} for p in prepared}
lineage=json.loads((E/"macro-ae3-5c2d-p0b-lineage-v2.json").read_text())
bound=lineage["bound_paths"]
assert len(bound)==82
for row in bound:
 p=row["path"];raw=(W/p).read_bytes();assert dg(raw)==row["sha256"],p
 assert git("rev-parse",":"+p).decode().strip()==row["git_blob"],p
out["p0b82_stage_and_raw_bindings_unchanged"]=True
out["deployment_paths_unchanged_vs_accepted_N2"]=git("diff","--name-only",H,out["index"],"--","app/deploy/","config/site_access.yml","tests/test_regwall_json_gate.py","tests/test_site_access_boundary.py","tests/test_deploy_update_self_heal.py").decode().splitlines()
assert not out["deployment_paths_unchanged_vs_accepted_N2"]
out["candidate_paths_vs_incoming"]=len(git("diff","--name-only",M,out["index"]).splitlines())
out["finished_at"]=now();save()
source=(W/test).read_text();tree=ast.parse(source)
closure=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=="test_curated_exclusive_scopes_cover_their_own_import_closure")
print(json.dumps(out,indent=2),flush=True)
print("EXISTING_CLOSURE_TEST_SOURCE\n"+ast.get_source_segment(source,closure),flush=True)
