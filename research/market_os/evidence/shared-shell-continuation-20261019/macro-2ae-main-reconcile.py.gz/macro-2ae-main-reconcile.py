from pathlib import Path
import subprocess,json,datetime,hashlib
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","-C",str(W)];H="2ae6498d0b9f2a088af2e827abf6527799757f8c";B="sol/market-os-shared-shell-design-20260924";BASE="df3cba80e5ff43e3411209381b32d9d4df06bd1f";OUT=E/"macro-2ae-main-reconcile.json"
def g(*a):return subprocess.check_output(G+list(a)).decode().strip()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert not OUT.exists()
assert g("rev-parse","HEAD")==H and g("branch","--show-current")==B and not g("status","--porcelain")
assert g("ls-remote","origin","refs/heads/"+B).split()[0]==H
assert subprocess.run(G+["rev-parse","--verify","MERGE_HEAD"],capture_output=True).returncode!=0
pr=json.loads(subprocess.check_output(["gh","api","repos/mastermindx-market-intelligence/macro/pulls/7949"],cwd=W))
assert pr["head"]["sha"]==H and pr["state"]=="open" and not pr["draft"] and pr["auto_merge"] is None and "merge-on-green" not in [x["name"] for x in pr["labels"]]
assert pr["mergeable"] is False and pr["mergeable_state"]=="dirty"
out={"started_at":now(),"head":H,"integrated_main":BASE,"remote_before":g("ls-remote","origin","refs/heads/main","refs/heads/"+B),"pr_before":{"head":pr["head"]["sha"],"mergeable":pr["mergeable"],"mergeable_state":pr["mergeable_state"],"labels":[x["name"] for x in pr["labels"]]},"scope":"One original-owner main-only fetch after new actual dirty state while previous exact-head CI continues; no merge yet"}
def save():OUT.write_text(json.dumps(out,indent=2)+"\n")
save();log=E/"macro-2ae-main-fetch.log"
with log.open("xb") as f:p=subprocess.run(G+["fetch","--no-tags","origin","main"],stdout=f,stderr=subprocess.STDOUT)
out.update(fetch_exit=p.returncode,log_bytes=log.stat().st_size,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest());save();assert p.returncode==0
M=g("rev-parse","FETCH_HEAD");out["incoming"]=M;out["merge_base"]=g("merge-base",H,M);out["new_main_changes"]=g("diff","--name-status",BASE,M);out["commits"]=g("log","--format=%H %s",BASE+".."+M)
out.update(finished_at=now(),head_unchanged=g("rev-parse","HEAD")==H,clean=not g("status","--porcelain"));save()
print(json.dumps(out,indent=2))
