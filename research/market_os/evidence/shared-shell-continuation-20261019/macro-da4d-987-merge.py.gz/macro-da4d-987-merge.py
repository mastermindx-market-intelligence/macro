from pathlib import Path
import subprocess,json,hashlib,datetime,shutil
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","-C",str(W)]
H="da4df7d1e1ac709055c6fa1d482304a875e81824";M="9875169102cc6f36a64d465fe7c06f6bb8fb0220";B="3b49d6a5c8a6330652a926a8e5061e0dbb3d0387";BR="sol/market-os-shared-shell-design-20260924";OUT=E/"macro-da4d-987-merge.json"
def git(*a):return subprocess.check_output(G+list(a))
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert not OUT.exists()
assert git("rev-parse","HEAD").decode().strip()==H and git("branch","--show-current").decode().strip()==BR and not git("status","--porcelain=v1").strip()
assert git("rev-parse","origin/main").decode().strip()==M and git("merge-base",H,M).decode().strip()==B
assert subprocess.run(G+["rev-parse","-q","--verify","MERGE_HEAD"],capture_output=True).returncode==1
remote=git("ls-remote","--exit-code","origin","refs/heads/"+BR).decode().strip()
assert remote.split()[0]=="b312bc4c08cf7633bf8fd259d2d46ec545fa120f"
free=shutil.disk_usage(W).free;assert free>8*1024**3
out={"started_at":now(),"head":H,"incoming":M,"merge_base":B,"branch":BR,"remote_branch_before":remote,"free_bytes_before":free,"worktree_clean_before":True,"state":"PRECHECKS_COMPLETE_ORDINARY_MERGE_BEGIN"}
def save():OUT.write_text(json.dumps(out,indent=2)+"\n")
save()
log=E/"macro-da4d-987-merge.log"
with log.open("xb") as f:r=subprocess.run(G+["merge","--no-ff","--no-commit",M],stdout=f,stderr=subprocess.STDOUT)
out.update(merge_exit=r.returncode,finished_at=now(),head_after=git("rev-parse","HEAD").decode().strip(),merge_head=git("rev-parse","MERGE_HEAD").decode().strip(),unmerged=git("diff","--name-only","--diff-filter=U").decode().splitlines(),log_bytes=log.stat().st_size,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),state="MERGE_ACTIVE_RECONCILIATION_REQUIRED")
assert out["head_after"]==H and out["merge_head"]==M and r.returncode in (0,1)
save();print(json.dumps(out,indent=2),flush=True)
