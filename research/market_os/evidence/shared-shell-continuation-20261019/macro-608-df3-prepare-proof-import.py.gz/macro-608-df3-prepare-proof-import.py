from pathlib import Path
import ast,hashlib,json
E=Path("/tmp/shared-shell-css-visual-20261019T1107")
src=E/"macro-da4d-987-proof-import.py";dst=E/"macro-608-df3-proof-import.py"
assert not dst.exists()
s=src.read_text()
def replace(a,b,n=None):
 global s
 if n is not None:assert s.count(a)==n,(a,s.count(a),n)
 else:assert a in s,a
 s=s.replace(a,b)
replace("macro-da4d-987","macro-608-df3")
replace("9875169102cc6f36a64d465fe7c06f6bb8fb0220","df3cba80e5ff43e3411209381b32d9d4df06bd1f",1)
old='about=readj("macro-608-df3-about-wrapper.json")\nassert about["pass"] and about["source_head"]==H and about["source_tree"]==SOURCE and about["capture"]["cells"]==8'
new='lineage=readj("macro-608-df3-retained-browser-lineage.json")\nassert lineage["state"]=="RETAINED_FIXTURE_LINEAGE_VERIFIED" and lineage["source_index"]==SOURCE and lineage["index_and_source_unchanged"]'
replace(old,new,1)
replace("eafb91bd7ffb2bf6e8b9cecfe72eae2627ce01175d3ddd13a8f57f32e5031dc6","078e3047795a2b0b311060c5639065b1ef8ebd3031d4a338b008649aec1c9ecd",1)
replace("509","1013")
replace('prefixes=("macro-140bd-","macro-3b49-","macro-b312-","macro-da4d-","macro-ae3-5c2d-complete-merge","macro-full-checkpoint-","about-footer-","labor-copy-","beta-loaded-unit-root-","beta-same-a-")','prefixes=("macro-608-",)',1)
replace('exclude={OUT,E/"macro-608-df3-proof-validation.json",E/"macro-608-df3-final-changed-paths.txt"}','exclude={OUT,E/"macro-608-df3-proof-validation.json",E/"macro-608-df3-final-changed-paths.txt",E/"macro-608-main-reachable-objects.txt",E/"macro-608-main-current-tree.txt",E/"macro-608-df3-proof-config-draft.json"}',1)
replace('p.name.startswith(("macro-608-df3-","about-footer-","labor-copy-"))','p.name.startswith(("macro-608-df3-",))',1)
replace('include(E/"macro-ae3-5c2d-proof-finalize.json")','for n in ["macro-da4d-987-proof-import.json","macro-da4d-987-proof-commit-push.py","macro-da4d-987-proof-commit-push.json","macro-da4d-987-proof-commit-message.txt","macro-da4d-987-proof-commit.log","macro-da4d-987-proof-push.log"]:include(E/n)\nmf["external_bulk_read_products"]=[{"source":str(E/n),"bytes":(E/n).stat().st_size,"sha256":dg((E/n).read_bytes()),"disposition":state,"reason":"Reproducible Git object inventory, not an effect receipt. Complete operation/exit/identity receipts are included; bulk listing stays in native evidence scratch."} for n,state in [("macro-608-main-reachable-objects.txt","ABORTED_READ_ONLY_NOT_COMPLETE"),("macro-608-main-current-tree.txt","COMPLETE_CURRENT_TREE_READ")]]',1)
replace("previous_frontier_before_987","previous_frontier_before_df3")
replace('"latest_confirmed_macro_publication":"b312bc4c08cf7633bf8fd259d2d46ec545fa120f"','"latest_confirmed_macro_publication":"608dfad299e2e48ab7703bf0b180e0dca1318229"',1)
replace("after local ordinary987 merge","after local ordinarydf3 merge",1)
ast.parse(s);dst.write_text(s)
out={"source":str(src),"source_sha256":hashlib.sha256(src.read_bytes()).hexdigest(),"derived":str(dst),"derived_sha256":hashlib.sha256(dst.read_bytes()).hexdigest(),"changes":"Same proof-pack importer: df3/current1013 manifest, exact retained browser lineage, current receipt prefix, previous608 push proof, named bounded exclusions for bulk reproducible inventories. No import executed."}
(E/"macro-608-df3-proof-import-preparation.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps(out,indent=2))
