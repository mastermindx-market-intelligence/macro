from pathlib import Path
import subprocess,os,signal,json,datetime,hashlib
E=Path("/tmp/shared-shell-css-visual-20261019T1107");W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");G=["git","-C",str(W)]
r=json.loads((E/"macro-608-main-reconcile.json").read_text());M=r["incoming"];B=r["merge_base"]
p=subprocess.run(["ps","-p","94572","-o","pid=,ppid=,command="],capture_output=True,text=True)
expected="git -C "+str(W)+" rev-list --objects --no-object-names --missing=print "+M
row={"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"scope":"Terminate only our optional all-history read census; no Git writer/service/installer effect","ps":p.stdout,"signalled":False}
if p.returncode==0 and p.stdout.strip():
 parts=p.stdout.strip().split(None,2);assert parts[0]=="94572" and parts[1]=="94506" and parts[2]==expected
 os.kill(94572,signal.SIGTERM);row["signalled"]=True
(E/"macro-608-owned-read-census-bound.json").write_text(json.dumps(row,indent=2)+"\n")
f=E/"macro-608-main-new-objects.txt";er=E/"macro-608-main-new-objects.stderr.log"
cmd=G+["rev-list","--objects","--no-object-names","--missing=print",M,"--not",B]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with f.open("xb") as o,er.open("xb") as e:q=subprocess.run(cmd,stdout=o,stderr=e,timeout=60)
missing=[s for s in f.read_text().splitlines() if s.startswith("?")]
out={"started_at":start,"finished_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"scope":"Complete new reachable object delta M excluding already-integrated B; prior all-history census intentionally stopped and not accepted","incoming":M,"base":B,"command":cmd,"exit":q.returncode,"bytes":f.stat().st_size,"sha256":hashlib.sha256(f.read_bytes()).hexdigest(),"stderr_bytes":er.stat().st_size,"missing_count":len(missing),"missing":missing}
(E/"macro-608-main-new-objects.json").write_text(json.dumps(out,indent=2)+"\n");print(json.dumps(out,indent=2))
