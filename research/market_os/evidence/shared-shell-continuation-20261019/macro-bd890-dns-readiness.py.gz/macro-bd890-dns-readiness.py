from pathlib import Path
import datetime,hashlib,json,subprocess
E=Path("/tmp/shared-shell-css-visual-20261019T1107");OUT=E/"macro-bd890-dns-readiness.json"
assert not OUT.exists()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def run(args):
 p=subprocess.run(args,capture_output=True,text=True,timeout=12)
 return {"command":args,"exit":p.returncode,"stdout":p.stdout,"stderr":p.stderr}
r={"started_at":now(),"scope":"Read-only public authoritative DNS readiness for beta; no record edit, credential lookup, HTTP request or TLS bypass","queries":[]}
for name,typ in [("mastermind-x.com","NS"),("mastermind-x.com","CAA"),("mastermind-x.com","A"),("www.mastermind-x.com","CNAME"),("www.mastermind-x.com","A"),("beta.mastermind-x.com","CNAME"),("beta.mastermind-x.com","A"),("beta.mastermind-x.com","AAAA")]:
 r["queries"].append(run(["dig","+time=3","+tries=1","+noall","+answer",name,typ]))
nss=[line.split()[-1] for line in r["queries"][0]["stdout"].splitlines() if len(line.split())>=5 and line.split()[3]=="NS"]
r["authoritative"]=[]
for ns in nss[:4]:
 for typ in ["CNAME","A","AAAA","CAA"]:
  r["authoritative"].append(run(["dig","@"+ns,"+time=3","+tries=1","+noall","+answer","beta.mastermind-x.com",typ]))
r.update(finished_at=now(),expected_beta_origin="146.190.142.17",production_records_not_changed=True,public_tls_or_browser_acceptance=False)
OUT.write_text(json.dumps(r,indent=2)+"\n")
print(json.dumps(r,indent=2));print(json.dumps({"receipt_sha256":hashlib.sha256(OUT.read_bytes()).hexdigest()}))
