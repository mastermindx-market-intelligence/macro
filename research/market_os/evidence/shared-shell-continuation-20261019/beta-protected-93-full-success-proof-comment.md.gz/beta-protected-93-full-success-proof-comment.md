## ACTUAL R93 BETA ACCEPTED RUNTIME — FULL INVOCATION AND POSTREAD PROOF — 2026-10-20

Same **WS:MARKET-OS**, original root `market-os-shared-shell-design-20260924-sol-001`, attended parent `shared-shell-production-20261018-c1`, sole Macro#7949. This records one completed original-owner effect; it is not a new PR, source carrier, renderer or watcher.

**Terminal #859 application A remains e45bde2cac07ac3b29285ff70c40d68900fad62c, already merged/browser-qualified; DO NOT REDO.** Protected release owner R93e303cc32566e72fb086af6d04ba3aa41866c5c came from merged#1080 with all13CIjobs green. Exact ownerSHA c6759cc653e0f19102a015ec52842795bde24eb85766d2e73f3024b4eefe409d.

**Canonical bootstrap ran ONCE01:22:30.178711–01:31:21.932840Z and exited0.** It resumed the original source-provisioned receipt; attempt5099c71dba9f4fb78a3088308688a9a4, stage/opt/terminal/beta/.stage.0frO0j, explicit transaction commit followed by lock release. It prepared2565 generated entries and converted2109 explained modes through the reviewed owner.

**Independent reviewed V3 postread ran01:37:44.235492–01:37:46.379068Z, exit0; all36requiredchecksTRUE, errors/failed/unobservedempty; ACCEPTED_RUNTIME_POSTREAD_PASS.** Beta active/running/enabledPID2427329/start7560285026653, applicationA/status200 with private/no-store/noindex headers. Accepted recordc62950826aca6fd8aa98c393097d22efd12639228a5c62db4e821eabb948c0dc binds finalCLEANpreflightd1d41bea5d47e17b7b1c44c25c1fea24cf95c30806f0046fcde528ebfd6788bb and inneraudit1bcd1ef2c5eb51a68793d3e7407fa46955e517689d06c318d6f0952418c0acc2. Original source receipt and policy preserved; pending/hold/ownedstage/allbetastages/marker scratch absent; archive parentempty; production service/markers/globalowner/Caddy match actual entry. Historical quarantined failed build remains diagnostic.

The empty observed_archive_paths list does not invent an individual archive name; the actual entry separately recorded the empty resource parent, and canonical finalexit0 plus postempty state are retained. A committing immutable attempt record with historical live_inputs_dirty=true is valid after successful commit; no committedJSON is fabricated. First accepted runtime establishes future rollback eligibility, **not an executed accepted-runtime rollback**.

**Scope remains open:** namespace/cache/shared-data, DNS/TLS/auth/public browser/nativehandoff/errors/applicable rollback and original Macro merge/render/served-tree acceptance. Macrob98 remains UNARMED; its new contract-delta job118399691090 failed in run39352502392 and is under exact-candidate diagnosis. SixSectorviews and PaperREVISE are preserved; C4 suggestions remain SPEC_ONLY/UNAPPLIED/UNRUN. No production mutation or blind bootstrap retry.

The following are complete original native files. JSON blocks preserve raw integer text. The bootstrap log is encoded as one JSON string so its original carriage returns and line feeds remain recoverable; JSON-decode that string, then UTF-8 encode to verify its stated raw SHA256. No output has been reconstructed from excerpts.

<details>
<summary>beta-protected-93-bootstrap-invocation.json — 1154 bytes — SHA256 217a8eaebde011a2245b4fd6b4977079c9d943fb44968b8c25c808741d13daff</summary>

```json
{
  "schema": "mastermind.attended.canonical_beta_bootstrap_invocation.v1",
  "started_at": "2026-10-20T01:22:30.178711+00:00",
  "protected_owner_R": "93e303cc32566e72fb086af6d04ba3aa41866c5c",
  "application_A": "e45bde2cac07ac3b29285ff70c40d68900fad62c",
  "protected_owner_artifact": "/root/mastermind-beta-owner-93e303cc-ucmhwhpm/terminal-build.sh",
  "owner_sha256": "c6759cc653e0f19102a015ec52842795bde24eb85766d2e73f3024b4eefe409d",
  "entry_program_sha256": "13f0a8b871f3b33a8e51645c56cac7ee95a99e3545644b1c3d16f45ee35182a5",
  "postreader_program_sha256": "b0b87c37bc3cdf07900b51fc60025f756ac40a6663bddbafda027dc30a51d899",
  "entry_review": "NONBLOCKING static source13f0a8; canonical installer retains atomic gates",
  "postreader_review": "NONBLOCKING static sourceb0b87c37 against canonical ownerc6759; no operational acceptance yet",
  "canonical_arguments": [
    "--target",
    "beta",
    "--bootstrap",
    "--target-sha",
    "e45bde2cac07ac3b29285ff70c40d68900fad62c"
  ],
  "single_invocation": true,
  "log": "/tmp/shared-shell-css-visual-20261019T1107/beta-protected-93-bootstrap.log",
  "production_mutation_requested": false
}
```

</details>

<details>
<summary>beta-protected-93-bootstrap-result.json — 746 bytes — SHA256 67a37686d231e063a9f06897bf755a9788605be874c85e6a10cb06cb15f6c51b</summary>

```json
{
  "schema": "mastermind.attended.canonical_beta_bootstrap_result.v1",
  "started_at": "2026-10-20T01:22:30.178711+00:00",
  "finished_at": "2026-10-20T01:31:21.932840+00:00",
  "protected_owner_R": "93e303cc32566e72fb086af6d04ba3aa41866c5c",
  "application_A": "e45bde2cac07ac3b29285ff70c40d68900fad62c",
  "exit": 0,
  "log": "/tmp/shared-shell-css-visual-20261019T1107/beta-protected-93-bootstrap.log",
  "log_bytes": 15043,
  "log_sha256": "b4de2cac7cbc581a44a9ee7c46af7e250d0cb28c5be453bb81054a5c911b2afa",
  "invocation_sha256": "217a8eaebde011a2245b4fd6b4977079c9d943fb44968b8c25c808741d13daff",
  "canonical_owner_output_observed": true,
  "entry_refusal_observed": false,
  "postread_due": true,
  "bootstrap_retry_authorized": false
}
```

</details>

<details>
<summary>beta-protected-93-bootstrap.log — 15043 bytes — SHA256 b4de2cac7cbc581a44a9ee7c46af7e250d0cb28c5be453bb81054a5c911b2afa</summary>

```json
"PROTECTED_R_ENTRY_FENCE {\"application_A\": \"e45bde2cac07ac3b29285ff70c40d68900fad62c\", \"artifact\": {\"dev\": 64769, \"gid\": 0, \"ino\": 340869, \"mode\": \"0o700\", \"nlink\": 1, \"path\": \"/root/mastermind-beta-owner-93e303cc-ucmhwhpm/terminal-build.sh\", \"sha256\": \"c6759cc653e0f19102a015ec52842795bde24eb85766d2e73f3024b4eefe409d\", \"size\": 207242, \"uid\": 0}, \"artifact_parent\": {\"dev\": 64769, \"gid\": 0, \"ino\": 340839, \"mode\": \"0o700\", \"nlink\": 2, \"path\": \"/root/mastermind-beta-owner-93e303cc-ucmhwhpm\", \"size\": 4096, \"uid\": 0}, \"beta_service\": {\"ActiveState\": \"inactive\", \"ExecMainStartTimestampMonotonic\": \"0\", \"MainPID\": \"0\", \"SubState\": \"dead\", \"UnitFileState\": \"disabled\"}, \"canonical_pointer_checked\": \".runtime-accepted\", \"dependency_pair\": [{\"dev\": 2048, \"gid\": 0, \"ino\": 336939, \"mode\": \"0o744\", \"nlink\": 1, \"path\": \"/opt/terminal/beta/terminal/node_modules/esbuild/bin/esbuild\", \"size\": 9707520, \"uid\": 0}, {\"dev\": 2048, \"gid\": 0, \"ino\": 330749, \"mode\": \"0o744\", \"nlink\": 1, \"path\": \"/opt/terminal/beta/terminal/node_modules/@esbuild/linux-x64/bin/esbuild\", \"size\": 9707520, \"uid\": 0}], \"entry_fenced_at\": \"2026-10-20T01:22:30.989949+00:00\", \"next_effect\": \"exec exact protected owner once with canonical --target beta --bootstrap --target-sha A; owner retains all locks, admission, publication and cleanup authority\", \"owner_invoked_at_receipt\": false, \"production_entry\": {\"caddy_sha256\": \"6de6d01adbe40a5c71f8d80472f3d0deca5a02a99c4e27779984b3bff4d274b1\", \"deployment_sha\": \"50a8c01553ee92731a53dfcff36256308cfb5f0e\", \"next_build_id\": \"build-TfctsWXpff2fKS\", \"owner_sha256\": \"6d05d3d5745e0e0a29262c89ba61cf881c2605201cce5b0fc85a52bde0e42ec8\", \"pid\": \"2336355\", \"start_monotonic\": \"7552363880288\"}, \"production_service\": {\"ActiveState\": \"active\", \"ExecMainStartTimestampMonotonic\": \"7552363880288\", \"MainPID\": \"2336355\", \"SubState\": \"running\", \"UnitFileState\": \"enabled\"}, \"protected_owner_R\": \"93e303cc32566e72fb086af6d04ba3aa41866c5c\", \"protected_owner_artifact\": \"/root/mastermind-beta-owner-93e303cc-ucmhwhpm/terminal-build.sh\", \"release_owners\": {\"checked_processes\": 61, \"complete\": true, \"matches\": [], \"scope\": \"Executable/script argv of ordinary shell release owners; no whole-command substring matching or environment read\"}, \"schema\": \"mastermind.attended.beta_protected_entry.v2\", \"shared_resource_parent\": {\"dev\": 2048, \"gid\": 0, \"ino\": 1591358, \"mode\": \"0o700\", \"nlink\": 2, \"path\": \"/opt/terminal/.terminal-build-resource.lock\", \"size\": 4096, \"uid\": 0}, \"shared_resource_parent_entries\": [], \"source_receipt\": {\"dev\": 64769, \"gid\": 0, \"ino\": 3943348, \"mode\": \"0o640\", \"nlink\": 1, \"path\": \"/var/lib/mastermind-terminal-beta/source-provisioned/source-provisioned-e45bde2cac07ac3b29285ff70c40d68900fad62c-efb499b6d0108d69.json\", \"sha256\": \"9aac8ec8c132eecf4d2664d8f1e18e8a6bffce5f6d7176e4021b15d6d953cfa4\", \"size\": 1841, \"uid\": 0}, \"space\": {\"/\": 36908949504, \"/opt/terminal\": 16296738816}}\n[build] profile environment: beta; MMX_SHARED_SHELL=1 declared by this owner\n[build] target profile resolved: target=beta app=/opt/terminal/beta/terminal src=/opt/terminal/.gitsrc-beta service=terminal-beta health=http://127.0.0.1:3001/\n[build] target profile resolved: receipts=/var/lib/mastermind-terminal-beta/release-preflight policy=terminal_source_audit.beta.json lock=/opt/terminal/.terminal-build-resource.lock installs_global_runtime=0\n[build] beta lifecycle state tree: /var/lib/mastermind-terminal-beta/source-provisioned; build-time env source: /var/lib/mastermind-terminal-beta/host (secret values are never logged and never live in the audited beta target)\n[build] entrance: beta bootstrap — provisions SOURCE, then must still earn runtime acceptance\n[build] build lock acquired: shared=/opt/terminal/.terminal-build-resource.lock/hold target=beta pid=2419943\n[build] preflight bundle selected: script_sha256=a8d1db606afed780cf43b5471ef27d127621eb5de843d36d8d310ba62a8a0b23 policy_digest=99f76cb211b086d1f83bb86c10747e2711a4c318fa4bd5dab1b94e84d46fe1d6 runtime_sha256=e4308b10b0712ee17e4a1410d01a495b3992442bc414576ca6f183a2a3399c52\n[build] beta unit settings verified: terminal-beta declares MMX_SHARED_SHELL=1 (presence only; the environment is never logged)\n[build] beta bootstrap admitted: resuming verified source-provisioned state /var/lib/mastermind-terminal-beta/source-provisioned/source-provisioned-e45bde2cac07ac3b29285ff70c40d68900fad62c-efb499b6d0108d69.json\n[build] fetching accepted ref origin/master for exact target admission (bootstrap: before any source provisioning) ...\n[build] accepted ref observed: before=38ddfcb127103869c1ad601e519650407a982f14 after=93e303cc32566e72fb086af6d04ba3aa41866c5c\n[build] beta bootstrap resume verified: recorded SHA, digest, paths and trees all match\n[build] beta provisioning archive verified: 5498 members, every one inside /opt/terminal/beta\n[build] provisioned SOURCE identity recorded (unchanged); it is never a runtime or rollback claim\n[build] beta bootstrap: the current-generation W2A gate now runs against the provisioned generation\n[build] source preflight CLEAN: accepted=e45bde2cac07ac3b29285ff70c40d68900fad62c receipt=/var/lib/mastermind-terminal-beta/release-preflight/20261020T012243Z-e45bde2cac07ac3b29285ff70c40d68900fad62c-30f800cfdab6d2aa20d0eb6f58141191331f2db4cbe9f30bbfd93960636c1c4e.json policy_digest=99f76cb211b086d1f83bb86c10747e2711a4c318fa4bd5dab1b94e84d46fe1d6\n[build] beta unit settings verified: terminal-beta declares MMX_SHARED_SHELL=1 (presence only; the environment is never logged)\n[build] beta transaction pending: attempt=5099c71dba9f4fb78a3088308688a9a4 prior=<first-install> target=e45bde2cac07ac3b29285ff70c40d68900fad62c; automatic startup disabled\n[build] node v20.20.2\n[build] GIT-GATED: deploying accepted target e45bde2cac07ac3b29285ff70c40d68900fad62c from origin/master for target=beta (working-tree edits in /opt/terminal/beta/terminal are IGNORED)\n[build] deps unchanged — skipping npm ci\n[build] target=beta gated stage paths: ingest hub signal_layer config contracts scripts\n[build] beta stage: scripts/ is taken from the admitted commit inside the stage; no link onto a live runtime directory\n[build] staging origin/master:terminal in /opt/terminal/beta/.stage.0frO0j/terminal (+ gated ingest/hub/signal_layer/config/contracts beside it)\n[build] beta stage identity: GIT_SHA/NEXT_DEPLOYMENT_ID come from the admitted commit; env files are read only from the beta app root\n[build] beta stage runtime data: staged only from beta-owned /opt/terminal/beta/terminal/public/data; production runtime data is never hardlinked, copied or prebuilt into beta\n[build] next build (staging) ...\n\n> terminal@0.1.0 prebuild\n> python3 ../scripts/build_data_coverage.py\n\n[coverage] wrote /opt/terminal/beta/.stage.0frO0j/terminal/public/data/coverage.json — intel:2 fund:0 opts:0 ohlc:56 generation:1792459410\n\n> terminal@0.1.0 build\n> next build\n\n▲ Next.js 16.2.9 (Turbopack)\n- Environments: .env.local, .env\n\n  Creating an optimized production build ...\nTurbopack build encountered 1 warnings:\n./next.config.ts\nEncountered unexpected file in NFT list\nA file was traced that indicates that the whole project was traced unintentionally. Somewhere in the import trace below, there are:\n- filesystem operations (like path.join, path.resolve or fs.readFile), or\n- very dynamic requires (like require('./' + foo)).\nTo resolve this, you can\n- remove them if possible, or\n- only use them in development, or\n- make sure they are statically scoped to some subfolder: path.join(process.cwd(), 'data', bar), or\n- add ignore comments: path.join(/*turbopackIgnore: true*/ process.cwd(), bar)\n\nImport trace:\n  App Route:\n    ./next.config.ts\n    ./lib/flowSource.ts\n    ./app/api/flow/stream/route.ts\n\n\n✓ Compiled successfully in 2.1min\n  Running TypeScript ...\n  Finished TypeScript in 4.7min ...\n  Collecting page data using 1 worker ...\n  Generating static pages using 1 worker (0/65) ...\n  Generating static pages using 1 worker (16/65) \r\n  Generating static pages using 1 worker (32/65) \r\n  Generating static pages using 1 worker (48/65) \r\n✓ Generating static pages using 1 worker (65/65) in 2.1s\n  Finalizing page optimization ...\n\nRoute (app)                                                                    Revalidate  Expire\n┌ ○ /\n├ ○ /_not-found\n├ ƒ /[...legacyPath]\n├ ƒ /admin\n├ ƒ /alerts\n├ ƒ /analysis\n├ ƒ /api/account/alert-prefs\n├ ƒ /api/account/api-keys\n├ ƒ /api/account/api-keys/[id]\n├ ƒ /api/account/deletion\n├ ƒ /api/account/export\n├ ƒ /api/accuracy\n├ ƒ /api/accuracy/claims\n├ ƒ /api/admin/searches\n├ ƒ /api/alerts\n├ ƒ /api/alerts/dry-run\n├ ƒ /api/alerts/receipts\n├ ƒ /api/billing/config\n├ ƒ /api/billing/portal\n├ ƒ /api/billing/subscribe/complete\n├ ƒ /api/billing/subscribe/init\n├ ƒ /api/brain/[...path]\n├ ƒ /api/briefs/deliveries\n├ ƒ /api/briefs/subscriptions\n├ ƒ /api/briefs/subscriptions/[id]\n├ ƒ /api/collect\n├ ƒ /api/company-institutional-context/[symbol]\n├ ƒ /api/company-intelligence/[symbol]\n├ ƒ /api/company-intelligence/private/company-context\n├ ƒ /api/company-intelligence/private/issuers/[issuerId]/product-integrations\n├ ƒ /api/company-intelligence/private/product-integrations/[factId]\n├ ƒ /api/company-source-search/[ticker]\n├ ƒ /api/company-theme-context/[symbol]\n├ ƒ /api/copilot\n├ ƒ /api/drawings\n├ ƒ /api/event-impact\n├ ƒ /api/event-workspace/[symbol]\n├ ƒ /api/ext-quote\n├ ƒ /api/flow\n├ ƒ /api/flow/stream\n├ ƒ /api/futures\n├ ƒ /api/futures/cot\n├ ƒ /api/grants\n├ ƒ /api/intraday\n├ ƒ /api/investigations\n├ ƒ /api/investigations/baseline\n├ ƒ /api/large-trades\n├ ƒ /api/layouts\n├ ƒ /api/me\n├ ƒ /api/news/[symbol]\n├ ƒ /api/news/stories/[storyId]\n├ ƒ /api/news/stream\n├ ƒ /api/nw\n├ ƒ /api/options/issue-desk\n├ ƒ /api/options/issue-desk/reviews\n├ ƒ /api/portfolio\n├ ƒ /api/portfolio-brief\n├ ƒ /api/portfolio/risk-history\n├ ƒ /api/portfolio/targets\n├ ƒ /api/quote\n├ ƒ /api/scripts/delete\n├ ƒ /api/scripts/list\n├ ƒ /api/scripts/save\n├ ƒ /api/sector-intelligence\n├ ƒ /api/shared-shell/status\n├ ƒ /api/smart-screens\n├ ƒ /api/snapshot\n├ ƒ /api/study-templates\n├ ƒ /api/teams\n├ ƒ /api/teams/[id]/accuracy/rollup\n├ ƒ /api/teams/[id]/members\n├ ƒ /api/teams/[id]/settings\n├ ƒ /api/teams/[id]/transfer-ownership\n├ ƒ /api/teams/invitations\n├ ƒ /api/theses\n├ ƒ /api/thesis-fire-status\n├ ƒ /api/thesis-saved-views\n├ ƒ /api/thesis/[thesisId]/proposals\n├ ƒ /api/thesis/[thesisId]/proposals/[proposalId]\n├ ƒ /api/track/search\n├ ƒ /api/v1\n├ ƒ /api/v1/alerts\n├ ƒ /api/v1/alerts/[id]/fires\n├ ƒ /api/v1/claims\n├ ƒ /api/v1/dislocations\n├ ƒ /api/v1/me\n├ ƒ /api/v1/openapi.json\n├ ƒ /api/v1/positions\n├ ƒ /api/v1/theses\n├ ƒ /api/v1/theses/[id]\n├ ƒ /api/v1/theses/[id]/versions\n├ ƒ /api/v1/watchlists\n├ ƒ /api/v1/watchlists/[id]\n├ ƒ /api/v1/watchlists/[id]/symbols\n├ ƒ /api/watchlist\n├ ƒ /api/watchlist/annotations\n├ ƒ /api/webhooks\n├ ƒ /api/webhooks/[id]\n├ ƒ /api/webhooks/[id]/deliveries\n├ ƒ /api/webhooks/[id]/test\n├ ƒ /auth/callback\n├ ƒ /auth/signout\n├ ○ /dev/chart-bench\n├ ○ /dev/futures\n├ ○ /dev/futures-sample\n├ ○ /dev/settings\n├ ○ /dev/theater\n├ ○ /dev/workspaces\n├ ƒ /discover\n├ ƒ /dislocations\n├ ƒ /docs/api/contract\n├ ƒ /embed/chart\n├ ƒ /invite\n├ ○ /learn                                                                             5m      1y\n├ ƒ /login\n├ ƒ /options\n├ ƒ /options/futures\n├ ƒ /portfolio\n├ ƒ /reset-password\n├ ƒ /scripts\n├ ƒ /terminal\n└ ƒ /x/[slug]\n\n\nƒ Proxy (Middleware)\n\n○  (Static)   prerendered as static content\nƒ  (Dynamic)  server-rendered on demand\n\n[build] new build OK: BUILD_ID=build-TfctsWXpff2fKS sha=e45bde2cac07ac3b29285ff70c40d68900fad62c\n[build] beta build output prepared: inspected=2565 converted=2109; bytes, inodes and custody preserved\n[build] beta bootstrap: no deploy generation is opened; a provisioned source marker is never a rollback baseline\n[build] swapped .next (previous build kept as .next.bak)\n[build] beta runtime published read-only for the service user: directories+446 files+4729 symlinks-skipped=32 secret-names-skipped=1; read/traverse only, never group/other write\n[build] beta Next cache prepared: /opt/terminal/beta/terminal/.next/cache and 3 descendants owned by terminal-beta (987:981)\nbeta status verified against the admitted tuple: protocol=mmx.shared-shell.v1 bridge=20261018.1 document=20261018.1 registry=5307ea5a7964... build=e45bde2cac07\n[build] beta unit settings verified: terminal-beta declares MMX_SHARED_SHELL=1 (presence only; the environment is never logged)\n[build] beta candidate active but pending: e45bde2cac07ac3b29285ff70c40d68900fad62c; accepted pointer has not advanced\n[build] runtime sync <- target=beta origin/master: ingest scripts config contracts hub signal_layer -> /opt/terminal/beta/\n[build] beta profile: no hub dependency detection, no hub npm ci, no quote-hub effect\n[build] beta profile: no nightly cron wrapper, no owner self-install, no global cron bundles\n[build] syncing /opt/terminal/beta/terminal source <- origin/master:terminal\n[build] beta runtime published read-only for the service user: directories+446 files+4729 symlinks-skipped=32 secret-names-skipped=1; read/traverse only, never group/other write\n[build] beta Next cache prepared: /opt/terminal/beta/terminal/.next/cache and 3 descendants owned by terminal-beta (987:981)\nbeta status verified against the admitted tuple: protocol=mmx.shared-shell.v1 bridge=20261018.1 document=20261018.1 registry=5307ea5a7964... build=e45bde2cac07\n[build] source preflight CLEAN: accepted=e45bde2cac07ac3b29285ff70c40d68900fad62c receipt=/var/lib/mastermind-terminal-beta/release-preflight/20261020T013119Z-e45bde2cac07ac3b29285ff70c40d68900fad62c-d1d41bea5d47e17b7b1c44c25c1fea24cf95c30806f0046fcde528ebfd6788bb.json policy_digest=99f76cb211b086d1f83bb86c10747e2711a4c318fa4bd5dab1b94e84d46fe1d6\n[build] beta unit settings verified: terminal-beta declares MMX_SHARED_SHELL=1 (presence only; the environment is never logged)\n[build] beta generation runtime-accepted: /var/lib/mastermind-terminal-beta/source-provisioned/runtime-accepted-e45bde2cac07ac3b29285ff70c40d68900fad62c-c62950826aca6fd8.json\nCreated symlink /etc/systemd/system/multi-user.target.wants/terminal-beta.service → /etc/systemd/system/terminal-beta.service.\n[build] beta unit settings verified: terminal-beta declares MMX_SHARED_SHELL=1 (presence only; the environment is never logged)\n[build] beta transaction committed: accepted=e45bde2cac07ac3b29285ff70c40d68900fad62c attempt=5099c71dba9f4fb78a3088308688a9a4\n[build] beta profile: the suite-alerts, personal-accuracy and fundamental-scan cron bundles are NOT built, installed or run\n[build] DONE — target=beta live = origin/master @ e45bde2cac07 (app + runtime code, git-gated, healthy)\n[build] build lock released: /opt/terminal/.terminal-build-resource.lock/hold\n"
```

</details>

<details>
<summary>beta-protected-93-success-postread-v3.binding.json — 808 bytes — SHA256 6e89ce1ac148cfec9e26163c344f0986b2fb41955950030a5ee0bea3748ddf92</summary>

```json
{
  "schema": "mastermind.attended.beta_success_postread_binding.v1",
  "protected_owner_R": "93e303cc32566e72fb086af6d04ba3aa41866c5c",
  "attempt_id": "5099c71dba9f4fb78a3088308688a9a4",
  "owned_stage": "/opt/terminal/beta/.stage.0frO0j",
  "owned_archive_paths": [],
  "protected_owner_artifact": "/root/mastermind-beta-owner-93e303cc-ucmhwhpm/terminal-build.sh",
  "production_entry": {
    "caddy_sha256": "6de6d01adbe40a5c71f8d80472f3d0deca5a02a99c4e27779984b3bff4d274b1",
    "deployment_sha": "50a8c01553ee92731a53dfcff36256308cfb5f0e",
    "next_build_id": "build-TfctsWXpff2fKS",
    "owner_sha256": "6d05d3d5745e0e0a29262c89ba61cf881c2605201cce5b0fc85a52bde0e42ec8",
    "pid": "2336355",
    "start_monotonic": "7552363880288"
  },
  "installer_exit": 0,
  "transaction_commit_observed": true
}
```

</details>

<details>
<summary>beta-protected-93-success-postread-v3.receipt.json — 898 bytes — SHA256 1fc6e31ff35d38eb75050f881811f4f9d99a36d910b51eaf0ba9ee28f24d02ec</summary>

```json
{
  "schema": "mastermind.attended.beta_postread_invocation_receipt.v1",
  "started_at": "2026-10-20T01:37:44.235492+00:00",
  "finished_at": "2026-10-20T01:37:46.379068+00:00",
  "exit": 0,
  "source_sha256": "b0b87c37bc3cdf07900b51fc60025f756ac40a6663bddbafda027dc30a51d899",
  "binding_sha256": "6e89ce1ac148cfec9e26163c344f0986b2fb41955950030a5ee0bea3748ddf92",
  "owner_result_sha256": "67a37686d231e063a9f06897bf755a9788605be874c85e6a10cb06cb15f6c51b",
  "owner_log_sha256": "b4de2cac7cbc581a44a9ee7c46af7e250d0cb28c5be453bb81054a5c911b2afa",
  "stdout_bytes": 39295,
  "stdout_sha256": "d18c7b0ffe2c7dbe988a5fcdf96a66385df66b27ba0307d55e38360fb92286f2",
  "stderr_bytes": 0,
  "stderr_sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
  "all_checks_pass": true,
  "acceptance_disposition": "ACCEPTED_RUNTIME_POSTREAD_PASS",
  "bootstrap_retry_authorized": false
}
```

</details>

<details>
<summary>beta-protected-93-success-postread-v3.stdout.json — 39295 bytes — SHA256 d18c7b0ffe2c7dbe988a5fcdf96a66385df66b27ba0307d55e38360fb92286f2</summary>

```json
{
  "Caddy": {
    "ctime_ns": 1792440191463329649,
    "dev": 64769,
    "gid": 0,
    "ino": 262161,
    "mode": "0o644",
    "mtime_ns": 1792440191463329649,
    "nlink": 1,
    "path": "/etc/caddy/Caddyfile",
    "sha256": "6de6d01adbe40a5c71f8d80472f3d0deca5a02a99c4e27779984b3bff4d274b1",
    "size": 73943,
    "type": "regular",
    "uid": 0
  },
  "acceptance_disposition": "ACCEPTED_RUNTIME_POSTREAD_PASS",
  "acceptance_scope": "Bound installed-runtime postread only. Independent source, namespace, public browser, auth and rollback acceptance are separate.",
  "accepted_preflight": {
    "ctime_ns": 1792459880725099047,
    "dev": 64769,
    "exact_record_retained_at": "/var/lib/mastermind-terminal-beta/release-preflight/20261020T013119Z-e45bde2cac07ac3b29285ff70c40d68900fad62c-d1d41bea5d47e17b7b1c44c25c1fea24cf95c30806f0046fcde528ebfd6788bb.json",
    "gid": 0,
    "ino": 3946425,
    "mode": "0o640",
    "mtime_ns": 1792459880721099023,
    "nlink": 1,
    "path": "/var/lib/mastermind-terminal-beta/release-preflight/20261020T013119Z-e45bde2cac07ac3b29285ff70c40d68900fad62c-d1d41bea5d47e17b7b1c44c25c1fea24cf95c30806f0046fcde528ebfd6788bb.json",
    "record_summary": {
      "accepted_sha": "e45bde2cac07ac3b29285ff70c40d68900fad62c",
      "canonical_repo": "/opt/terminal/.gitsrc-beta",
      "generated_at": "2026-10-20T01:31:19.283128Z",
      "policy_digest": "99f76cb211b086d1f83bb86c10747e2711a4c318fa4bd5dab1b94e84d46fe1d6",
      "policy_path": "/opt/terminal/.gitsrc-beta/ops/terminal_source_audit.beta.json",
      "receipt_id": "d1d41bea5d47e17b7b1c44c25c1fea24cf95c30806f0046fcde528ebfd6788bb",
      "result": "CLEAN",
      "schema": "mastermind.terminal.release_preflight_receipt.v1",
      "source_audit": {
        "accepted_sha": "e45bde2cac07ac3b29285ff70c40d68900fad62c",
        "canonical_repo_head": "e45bde2cac07ac3b29285ff70c40d68900fad62c",
        "findings": [],
        "policy_digest": "99f76cb211b086d1f83bb86c10747e2711a4c318fa4bd5dab1b94e84d46fe1d6",
        "receipt_id": "1bcd1ef2c5eb51a68793d3e7407fa46955e517689d06c318d6f0952418c0acc2",
        "schema": "mastermind.terminal.source_audit_receipt.v1",
        "status": "CLEAN",
        "summary": {
          "allowed_paths": 4,
          "allowed_tracked_absences": 0,
          "allowed_tracked_runtime_files": 0,
          "allowed_tracked_runtime_subtrees": 1,
          "blocking_findings": 0,
          "tracked_paths": 5037
        }
      },
      "source_audit_receipt_id": "1bcd1ef2c5eb51a68793d3e7407fa46955e517689d06c318d6f0952418c0acc2"
    },
    "sha256": "f329e789f5ea353e7a9bd4ab72450de9b4d798c5deddc153ede4c317ff20f38a",
    "size": 5969,
    "type": "regular",
    "uid": 0
  },
  "all_checks_pass": true,
  "application_A": "e45bde2cac07ac3b29285ff70c40d68900fad62c",
  "archive_proof_scope": "Checks cover observed archive-path absence, postread resource-parent emptiness, and caller-bound canonical-owner final exit. This probe makes no pre-empty-parent claim; an empty observed-path list does not identify an individually observed archive.",
  "attempt_records": [
    {
      "ctime_ns": 1792459837978842677,
      "dev": 64769,
      "gid": 0,
      "ino": 3946423,
      "mode": "0o640",
      "mtime_ns": 1792459837973842647,
      "nlink": 1,
      "path": "/var/lib/mastermind-terminal-beta/source-provisioned/attempt-5099c71dba9f4fb78a3088308688a9a4-activation-857c567cf8354c66.json",
      "record": {
        "app_root": "/opt/terminal/beta/terminal",
        "attempt_id": "5099c71dba9f4fb78a3088308688a9a4",
        "build_id": "build-TfctsWXpff2fKS",
        "canonical_repo": "/opt/terminal/.gitsrc-beta",
        "live_inputs_dirty": false,
        "mode": "bootstrap",
        "phase": "activation",
        "policy_digest": "99f76cb211b086d1f83bb86c10747e2711a4c318fa4bd5dab1b94e84d46fe1d6",
        "prior_build_id": null,
        "prior_runtime_record": null,
        "prior_runtime_record_id": null,
        "prior_sha": null,
        "record_id": "857c567cf8354c66b336a9b71b2299a3c327393aec78be6e5efb37b9484338fa",
        "schema": "mastermind.terminal.beta_release_attempt.v1",
        "source_provisioned_record": "/var/lib/mastermind-terminal-beta/source-provisioned/source-provisioned-e45bde2cac07ac3b29285ff70c40d68900fad62c-efb499b6d0108d69.json",
        "source_provisioned_record_id": "efb499b6d0108d69d3eedba424f7ef6ecea26c957c5378fbef4f9b6b997365d9",
        "target": "beta",
        "target_root": "/opt/terminal/beta",
        "target_sha": "e45bde2cac07ac3b29285ff70c40d68900fad62c"
      },
      "sha256": "1e9b115343c144763ccb67605f51db083be4950de9284f5a774a4ff0927db732",
      "size": 999,
      "type": "regular",
      "uid": 0
    },
    {
      "ctime_ns": 1792459881041100939,
      "dev": 64769,
      "gid": 0,
      "ino": 3946427,
      "mode": "0o640",
      "mtime_ns": 1792459881039100927,
      "nlink": 1,
      "path": "/var/lib/mastermind-terminal-beta/source-provisioned/attempt-5099c71dba9f4fb78a3088308688a9a4-committing-e5c1267af89e61e7.json",
      "record": {
        "app_root": "/opt/terminal/beta/terminal",
        "attempt_id": "5099c71dba9f4fb78a3088308688a9a4",
        "build_id": "build-TfctsWXpff2fKS",
        "canonical_repo": "/opt/terminal/.gitsrc-beta",
        "live_inputs_dirty": true,
        "mode": "bootstrap",
        "phase": "committing",
        "policy_digest": "99f76cb211b086d1f83bb86c10747e2711a4c318fa4bd5dab1b94e84d46fe1d6",
        "prior_build_id": null,
        "prior_runtime_record": null,
        "prior_runtime_record_id": null,
        "prior_sha": null,
        "record_id": "e5c1267af89e61e746b4825bee5fdeacee2e4a4f8f225e24ec99ca6f919972a3",
        "schema": "mastermind.terminal.beta_release_attempt.v1",
        "source_provisioned_record": "/var/lib/mastermind-terminal-beta/source-provisioned/source-provisioned-e45bde2cac07ac3b29285ff70c40d68900fad62c-efb499b6d0108d69.json",
        "source_provisioned_record_id": "efb499b6d0108d69d3eedba424f7ef6ecea26c957c5378fbef4f9b6b997365d9",
        "target": "beta",
        "target_root": "/opt/terminal/beta",
        "target_sha": "e45bde2cac07ac3b29285ff70c40d68900fad62c"
      },
      "sha256": "957da0f779da0eb8fee6146243c855b44d83835e3a078607b83d7550a3f1c2fe",
      "size": 998,
      "type": "regular",
      "uid": 0
    },
    {
      "ctime_ns": 1792459858529966053,
      "dev": 64769,
      "gid": 0,
      "ino": 3946424,
      "mode": "0o640",
      "mtime_ns": 1792459858525966029,
      "nlink": 1,
      "path": "/var/lib/mastermind-terminal-beta/source-provisioned/attempt-5099c71dba9f4fb78a3088308688a9a4-inputs-dirty-a034cc0a795cd72d.json",
      "record": {
        "app_root": "/opt/terminal/beta/terminal",
        "attempt_id": "5099c71dba9f4fb78a3088308688a9a4",
        "build_id": "build-TfctsWXpff2fKS",
        "canonical_repo": "/opt/terminal/.gitsrc-beta",
        "live_inputs_dirty": true,
        "mode": "bootstrap",
        "phase": "inputs-dirty",
        "policy_digest": "99f76cb211b086d1f83bb86c10747e2711a4c318fa4bd5dab1b94e84d46fe1d6",
        "prior_build_id": null,
        "prior_runtime_record": null,
        "prior_runtime_record_id": null,
        "prior_sha": null,
        "record_id": "a034cc0a795cd72dc913e26cc3b2ebb0e45be631700d0f8bfb5ead3379a4e4c3",
        "schema": "mastermind.terminal.beta_release_attempt.v1",
        "source_provisioned_record": "/var/lib/mastermind-terminal-beta/source-provisioned/source-provisioned-e45bde2cac07ac3b29285ff70c40d68900fad62c-efb499b6d0108d69.json",
        "source_provisioned_record_id": "efb499b6d0108d69d3eedba424f7ef6ecea26c957c5378fbef4f9b6b997365d9",
        "target": "beta",
        "target_root": "/opt/terminal/beta",
        "target_sha": "e45bde2cac07ac3b29285ff70c40d68900fad62c"
      },
      "sha256": "500362017daef882227d0e4a5ef971ea875abc389f919a6bc180437fef86bcc3",
      "size": 1000,
      "type": "regular",
      "uid": 0
    },
    {
      "ctime_ns": 1792459367503930671,
      "dev": 64769,
      "gid": 0,
      "ino": 3946412,
      "mode": "0o640",
      "mtime_ns": 1792459367502930665,
      "nlink": 1,
      "path": "/var/lib/mastermind-terminal-beta/source-provisioned/attempt-5099c71dba9f4fb78a3088308688a9a4-staging.json",
      "record": {
        "app_root": "/opt/terminal/beta/terminal",
        "attempt_id": "5099c71dba9f4fb78a3088308688a9a4",
        "build_id": null,
        "canonical_repo": "/opt/terminal/.gitsrc-beta",
        "live_inputs_dirty": false,
        "mode": "bootstrap",
        "phase": "staging",
        "policy_digest": "99f76cb211b086d1f83bb86c10747e2711a4c318fa4bd5dab1b94e84d46fe1d6",
        "prior_build_id": null,
        "prior_runtime_record": null,
        "prior_runtime_record_id": null,
        "prior_sha": null,
        "record_id": "d3f630faa01bdc9d338c3ff0bfd16bf2062c1398f66a2a1ecaf15a8ffc4ed7ff",
        "schema": "mastermind.terminal.beta_release_attempt.v1",
        "source_provisioned_record": "/var/lib/mastermind-terminal-beta/source-provisioned/source-provisioned-e45bde2cac07ac3b29285ff70c40d68900fad62c-efb499b6d0108d69.json",
        "source_provisioned_record_id": "efb499b6d0108d69d3eedba424f7ef6ecea26c957c5378fbef4f9b6b997365d9",
        "target": "beta",
        "target_root": "/opt/terminal/beta",
        "target_sha": "e45bde2cac07ac3b29285ff70c40d68900fad62c"
      },
      "sha256": "ffdb6adaeb39c953edc5aaedfca0b0ff4aaf3783c44427a584bdbb8891a2a2db",
      "size": 978,
      "type": "regular",
      "uid": 0
    },
    {
      "ctime_ns": 1792459880954100418,
      "dev": 64769,
      "gid": 0,
      "ino": 3946426,
      "mode": "0o640",
      "mtime_ns": 1792459880953100412,
      "nlink": 1,
      "path": "/var/lib/mastermind-terminal-beta/source-provisioned/attempt-5099c71dba9f4fb78a3088308688a9a4-validated-2741fdb8fdb90e71.json",
      "record": {
        "app_root": "/opt/terminal/beta/terminal",
        "attempt_id": "5099c71dba9f4fb78a3088308688a9a4",
        "build_id": "build-TfctsWXpff2fKS",
        "canonical_repo": "/opt/terminal/.gitsrc-beta",
        "live_inputs_dirty": true,
        "mode": "bootstrap",
        "phase": "validated",
        "policy_digest": "99f76cb211b086d1f83bb86c10747e2711a4c318fa4bd5dab1b94e84d46fe1d6",
        "prior_build_id": null,
        "prior_runtime_record": null,
        "prior_runtime_record_id": null,
        "prior_sha": null,
        "record_id": "2741fdb8fdb90e715cdf1dc02fafcd8f5806c8334ae251d52594d8b488c4f788",
        "schema": "mastermind.terminal.beta_release_attempt.v1",
        "source_provisioned_record": "/var/lib/mastermind-terminal-beta/source-provisioned/source-provisioned-e45bde2cac07ac3b29285ff70c40d68900fad62c-efb499b6d0108d69.json",
        "source_provisioned_record_id": "efb499b6d0108d69d3eedba424f7ef6ecea26c957c5378fbef4f9b6b997365d9",
        "target": "beta",
        "target_root": "/opt/terminal/beta",
        "target_sha": "e45bde2cac07ac3b29285ff70c40d68900fad62c"
      },
      "sha256": "bfc741fb71b9b17b3c0a845fce6facc7fb00211c3229606fc7e0bb3fc836a5ea",
      "size": 997,
      "type": "regular",
      "uid": 0
    }
  ],
  "attempt_scope": "Canonical successful finish leaves a committing immutable record, removes pending, and does not write a committed JSON record.",
  "beta_children": [
    {
      "ctime_ns": 1792459881135101501,
      "dev": 2048,
      "gid": 0,
      "ino": 1598476,
      "mode": "0o777",
      "mtime_ns": 1792459881135101501,
      "nlink": 1,
      "path": "/opt/terminal/beta/.runtime-accepted",
      "size": 132,
      "type": "symlink",
      "uid": 0
    },
    {
      "ctime_ns": 1792383936443604029,
      "dev": 2048,
      "gid": 0,
      "ino": 1597725,
      "mode": "0o777",
      "mtime_ns": 1792383936443604029,
      "nlink": 1,
      "path": "/opt/terminal/beta/.source-provisioned",
      "size": 134,
      "type": "symlink",
      "uid": 0
    },
    {
      "ctime_ns": 1792459859246970353,
      "dev": 2048,
      "gid": 0,
      "ino": 1597724,
      "mode": "0o700",
      "mtime_ns": 1792383133000000000,
      "nlink": 2,
      "path": "/opt/terminal/beta/config",
      "size": 4096,
      "type": "directory",
      "uid": 0
    },
    {
      "ctime_ns": 1792459859262970449,
      "dev": 2048,
      "gid": 0,
      "ino": 1597729,
      "mode": "0o700",
      "mtime_ns": 1792383133000000000,
      "nlink": 3,
      "path": "/opt/terminal/beta/contracts",
      "size": 4096,
      "type": "directory",
      "uid": 0
    },
    {
      "ctime_ns": 1792459859291970623,
      "dev": 2048,
      "gid": 0,
      "ino": 1597742,
      "mode": "0o700",
      "mtime_ns": 1792383133000000000,
      "nlink": 5,
      "path": "/opt/terminal/beta/hub",
      "size": 4096,
      "type": "directory",
      "uid": 0
    },
    {
      "ctime_ns": 1792459859321970803,
      "dev": 2048,
      "gid": 0,
      "ino": 1597808,
      "mode": "0o700",
      "mtime_ns": 1792383133000000000,
      "nlink": 4,
      "path": "/opt/terminal/beta/ingest",
      "size": 4096,
      "type": "directory",
      "uid": 0
    },
    {
      "ctime_ns": 1792459859328970845,
      "dev": 2048,
      "gid": 0,
      "ino": 1598346,
      "mode": "0o700",
      "mtime_ns": 1792383133000000000,
      "nlink": 2,
      "path": "/opt/terminal/beta/scripts",
      "size": 4096,
      "type": "directory",
      "uid": 0
    },
    {
      "ctime_ns": 1792459859332970869,
      "dev": 2048,
      "gid": 0,
      "ino": 1598401,
      "mode": "0o700",
      "mtime_ns": 1792383133000000000,
      "nlink": 2,
      "path": "/opt/terminal/beta/signal_layer",
      "size": 4096,
      "type": "directory",
      "uid": 0
    },
    {
      "ctime_ns": 1792459870024034958,
      "dev": 2048,
      "gid": 0,
      "ino": 1598413,
      "mode": "0o755",
      "mtime_ns": 1792383879173315136,
      "nlink": 17,
      "path": "/opt/terminal/beta/terminal",
      "size": 4096,
      "type": "directory",
      "uid": 0
    }
  ],
  "beta_identity": [
    {
      "ctime_ns": 1792388000709822539,
      "dev": 2048,
      "gid": 0,
      "ino": 1602523,
      "mode": "0o644",
      "mtime_ns": 1792388000692822476,
      "nlink": 1,
      "path": "/opt/terminal/beta/terminal/.deployment-id",
      "sha256": "50b75a482303cb7ee99bd439d6d1a002aa0cc9c2d120e210655cf097c7509675",
      "size": 41,
      "text": "e45bde2cac07ac3b29285ff70c40d68900fad62c",
      "type": "regular",
      "uid": 0
    },
    {
      "ctime_ns": 1792459828979788577,
      "dev": 2048,
      "gid": 0,
      "ino": 426044,
      "mode": "0o644",
      "mtime_ns": 1792459828979788577,
      "nlink": 1,
      "path": "/opt/terminal/beta/terminal/.next/BUILD_ID",
      "sha256": "5906afd2adf8c7ee74a5032731fef083ad51f4f690d04a57a116ec5aba7b3230",
      "size": 20,
      "text": "build-TfctsWXpff2fKS",
      "type": "regular",
      "uid": 0
    }
  ],
  "beta_identity_after": [
    {
      "ctime_ns": 1792388000709822539,
      "dev": 2048,
      "gid": 0,
      "ino": 1602523,
      "mode": "0o644",
      "mtime_ns": 1792388000692822476,
      "nlink": 1,
      "path": "/opt/terminal/beta/terminal/.deployment-id",
      "sha256": "50b75a482303cb7ee99bd439d6d1a002aa0cc9c2d120e210655cf097c7509675",
      "size": 41,
      "text": "e45bde2cac07ac3b29285ff70c40d68900fad62c",
      "type": "regular",
      "uid": 0
    },
    {
      "ctime_ns": 1792459828979788577,
      "dev": 2048,
      "gid": 0,
      "ino": 426044,
      "mode": "0o644",
      "mtime_ns": 1792459828979788577,
      "nlink": 1,
      "path": "/opt/terminal/beta/terminal/.next/BUILD_ID",
      "sha256": "5906afd2adf8c7ee74a5032731fef083ad51f4f690d04a57a116ec5aba7b3230",
      "size": 20,
      "text": "build-TfctsWXpff2fKS",
      "type": "regular",
      "uid": 0
    }
  ],
  "beta_service_after": {
    "error": "",
    "exit": 0,
    "out": "MainPID=2427329\nExecMainStartTimestampMonotonic=7560285026653\nActiveState=active\nSubState=running\nUnitFileState=enabled"
  },
  "beta_source_HEAD": {
    "error": "",
    "exit": 0,
    "out": "e45bde2cac07ac3b29285ff70c40d68900fad62c"
  },
  "bootstrap_retry_authorized": false,
  "checks": {
    "Caddy_preserved": true,
    "archive_parent_empty": true,
    "attempt_records_valid": true,
    "beta_HEAD_A": true,
    "beta_active_enabled": true,
    "beta_service_stable_across_read": true,
    "binding_valid": true,
    "caller_observed_installer_exit_zero": true,
    "caller_observed_transaction_commit": true,
    "collection_complete": true,
    "committing_attempt_present": true,
    "generation_marker_scratch_absent": true,
    "lifecycle_and_build_stable_across_read": true,
    "live_build_binding": true,
    "no_beta_stage_remains": true,
    "observed_archives_absent": true,
    "owned_hold_absent": true,
    "owned_stage_absent": true,
    "owner_process_absent": true,
    "owner_process_scan_complete": true,
    "pending_absent": true,
    "policy_preserved": true,
    "preflight_valid": true,
    "production_build_identity": true,
    "production_owner_preserved": true,
    "production_service_identity": true,
    "protected_owner_artifact_bytes": true,
    "runtime_pointer_present": true,
    "runtime_record_valid": true,
    "services_read_successful": true,
    "source_provenance_binding": true,
    "source_provenance_hash": true,
    "source_record_valid": true,
    "status_cache_private_no_store": true,
    "status_contract": true,
    "status_robots_noindex_nofollow": true
  },
  "errors": [],
  "failed_checks": [],
  "historical_quarantine": {
    "BUILD_ID": {
      "ctime_ns": 1792413313886776118,
      "dev": 2048,
      "gid": 0,
      "ino": 361395,
      "mode": "0o644",
      "mtime_ns": 1792413313886776118,
      "nlink": 1,
      "path": "/opt/terminal/beta/terminal/.next.broken/BUILD_ID",
      "sha256": "5906afd2adf8c7ee74a5032731fef083ad51f4f690d04a57a116ec5aba7b3230",
      "size": 20,
      "text": "build-TfctsWXpff2fKS",
      "type": "regular",
      "uid": 0
    },
    "acceptance_gate": false,
    "metadata": {
      "ctime_ns": 1792413327866820868,
      "dev": 2048,
      "gid": 0,
      "ino": 359191,
      "mode": "0o755",
      "mtime_ns": 1792413316516784512,
      "nlink": 8,
      "path": "/opt/terminal/beta/terminal/.next.broken",
      "size": 4096,
      "type": "directory",
      "uid": 0
    },
    "nft": {
      "ctime_ns": 1792412993332864529,
      "dev": 2048,
      "gid": 0,
      "ino": 361054,
      "mode": "0o664",
      "mtime_ns": 1792412993332864529,
      "nlink": 1,
      "path": "/opt/terminal/beta/terminal/.next.broken/next-minimal-server.js.nft.json",
      "sha256": "ee2a73cb8400562bc5477d002c028da6d362e640925701c4cd4a21312004d544",
      "size": 5527,
      "type": "regular",
      "uid": 0
    }
  },
  "invocation_binding": {
    "attempt_id": "5099c71dba9f4fb78a3088308688a9a4",
    "installer_exit": 0,
    "owned_archive_paths": [],
    "owned_stage": "/opt/terminal/beta/.stage.0frO0j",
    "production_entry": {
      "caddy_sha256": "6de6d01adbe40a5c71f8d80472f3d0deca5a02a99c4e27779984b3bff4d274b1",
      "deployment_sha": "50a8c01553ee92731a53dfcff36256308cfb5f0e",
      "next_build_id": "build-TfctsWXpff2fKS",
      "owner_sha256": "6d05d3d5745e0e0a29262c89ba61cf881c2605201cce5b0fc85a52bde0e42ec8",
      "pid": "2336355",
      "start_monotonic": "7552363880288"
    },
    "protected_owner_R": "93e303cc32566e72fb086af6d04ba3aa41866c5c",
    "protected_owner_artifact": "/root/mastermind-beta-owner-93e303cc-ucmhwhpm/terminal-build.sh",
    "schema": "mastermind.attended.beta_success_postread_binding.v1",
    "transaction_commit_observed": true
  },
  "lifecycle_after": {
    "runtime": {
      "ctime_ns": 1792459881135101501,
      "destination": {
        "ctime_ns": 1792459881135101501,
        "dev": 64769,
        "gid": 0,
        "ino": 3946428,
        "mode": "0o640",
        "mtime_ns": 1792459881132101484,
        "nlink": 1,
        "path": "/var/lib/mastermind-terminal-beta/source-provisioned/runtime-accepted-e45bde2cac07ac3b29285ff70c40d68900fad62c-c62950826aca6fd8.json",
        "sha256": "698204ef4ad72a1bfa896110af875df080bf773687150890e8a2322bd6b452d7",
        "size": 1481,
        "type": "regular",
        "uid": 0
      },
      "dev": 2048,
      "gid": 0,
      "ino": 1598476,
      "mode": "0o777",
      "mtime_ns": 1792459881135101501,
      "nlink": 1,
      "path": "/opt/terminal/beta/.runtime-accepted",
      "size": 132,
      "symlink": "/var/lib/mastermind-terminal-beta/source-provisioned/runtime-accepted-e45bde2cac07ac3b29285ff70c40d68900fad62c-c62950826aca6fd8.json",
      "type": "symlink",
      "uid": 0
    },
    "source": {
      "ctime_ns": 1792383936443604029,
      "destination": {
        "ctime_ns": 1792383936443604029,
        "dev": 64769,
        "gid": 0,
        "ino": 3943348,
        "mode": "0o640",
        "mtime_ns": 1792383936440604014,
        "nlink": 1,
        "path": "/var/lib/mastermind-terminal-beta/source-provisioned/source-provisioned-e45bde2cac07ac3b29285ff70c40d68900fad62c-efb499b6d0108d69.json",
        "sha256": "9aac8ec8c132eecf4d2664d8f1e18e8a6bffce5f6d7176e4021b15d6d953cfa4",
        "size": 1841,
        "type": "regular",
        "uid": 0
      },
      "dev": 2048,
      "gid": 0,
      "ino": 1597725,
      "mode": "0o777",
      "mtime_ns": 1792383936443604029,
      "nlink": 1,
      "path": "/opt/terminal/beta/.source-provisioned",
      "size": 134,
      "symlink": "/var/lib/mastermind-terminal-beta/source-provisioned/source-provisioned-e45bde2cac07ac3b29285ff70c40d68900fad62c-efb499b6d0108d69.json",
      "type": "symlink",
      "uid": 0
    }
  },
  "lifecycle_directories": {
    "/opt/terminal/beta": {
      "ctime_ns": 1792459881922106212,
      "dev": 2048,
      "gid": 0,
      "ino": 1597716,
      "mode": "0o755",
      "mtime_ns": 1792459881922106212,
      "nlink": 9,
      "path": "/opt/terminal/beta",
      "size": 4096,
      "type": "directory",
      "uid": 0
    },
    "/var/lib/mastermind-terminal-beta": {
      "ctime_ns": 1792383934778595649,
      "dev": 64769,
      "gid": 0,
      "ino": 3688023,
      "mode": "0o750",
      "mtime_ns": 1792383934778595649,
      "nlink": 6,
      "path": "/var/lib/mastermind-terminal-beta",
      "size": 4096,
      "type": "directory",
      "uid": 0
    },
    "/var/lib/mastermind-terminal-beta/release-preflight": {
      "ctime_ns": 1792459880725099047,
      "dev": 64769,
      "gid": 0,
      "ino": 3943347,
      "mode": "0o750",
      "mtime_ns": 1792459880725099047,
      "nlink": 2,
      "path": "/var/lib/mastermind-terminal-beta/release-preflight",
      "size": 4096,
      "type": "directory",
      "uid": 0
    },
    "/var/lib/mastermind-terminal-beta/source-provisioned": {
      "ctime_ns": 1792459881135101501,
      "dev": 64769,
      "gid": 0,
      "ino": 3943264,
      "mode": "0o750",
      "mtime_ns": 1792459881135101501,
      "nlink": 2,
      "path": "/var/lib/mastermind-terminal-beta/source-provisioned",
      "size": 4096,
      "type": "directory",
      "uid": 0
    }
  },
  "observed_at": "2026-10-20T01:37:46.052091+00:00",
  "owner_processes": {
    "complete": true,
    "error_count": 0,
    "errors": [],
    "nonexecuting": 95,
    "owners": [],
    "scanned": 62,
    "vanished": 0
  },
  "policy": {
    "ctime_ns": 1792383875520296662,
    "dev": 2048,
    "gid": 0,
    "ino": 18270,
    "mode": "0o600",
    "mtime_ns": 1792383875520296662,
    "nlink": 1,
    "path": "/opt/terminal/.gitsrc-beta/ops/terminal_source_audit.beta.json",
    "sha256": "9b6c95d2f3134f37640312106fcf10dd2be5a1d4c01002e959ac5cb71614fae9",
    "size": 3190,
    "type": "regular",
    "uid": 0
  },
  "production_identity": [
    {
      "ctime_ns": 1792451950404929142,
      "dev": 2048,
      "gid": 0,
      "ino": 1606277,
      "mode": "0o644",
      "mtime_ns": 1792451950399929026,
      "nlink": 1,
      "path": "/opt/terminal/terminal/.deployment-id",
      "sha256": "a1de37a5aa06f0ccc88262e926da53a5825264fa6eccfa56812fc7746a9db241",
      "size": 41,
      "text": "50a8c01553ee92731a53dfcff36256308cfb5f0e",
      "type": "regular",
      "uid": 0
    },
    {
      "ctime_ns": 1792451948290879818,
      "dev": 2048,
      "gid": 0,
      "ino": 1606238,
      "mode": "0o644",
      "mtime_ns": 1792451948290879818,
      "nlink": 1,
      "path": "/opt/terminal/terminal/.next/BUILD_ID",
      "sha256": "5906afd2adf8c7ee74a5032731fef083ad51f4f690d04a57a116ec5aba7b3230",
      "size": 20,
      "text": "build-TfctsWXpff2fKS",
      "type": "regular",
      "uid": 0
    }
  ],
  "production_owner": {
    "ctime_ns": 1792451958608119145,
    "dev": 2048,
    "gid": 0,
    "ino": 1605099,
    "mode": "0o755",
    "mtime_ns": 1792451958605119076,
    "nlink": 1,
    "path": "/opt/terminal/terminal-build.sh",
    "sha256": "6d05d3d5745e0e0a29262c89ba61cf881c2605201cce5b0fc85a52bde0e42ec8",
    "size": 196115,
    "type": "regular",
    "uid": 0
  },
  "protected_owner_R": "93e303cc32566e72fb086af6d04ba3aa41866c5c",
  "protected_owner_artifact": {
    "ctime_ns": 1792457977617852035,
    "dev": 64769,
    "gid": 0,
    "ino": 340869,
    "mode": "0o700",
    "mtime_ns": 1792457977617852035,
    "nlink": 1,
    "path": "/root/mastermind-beta-owner-93e303cc-ucmhwhpm/terminal-build.sh",
    "sha256": "c6759cc653e0f19102a015ec52842795bde24eb85766d2e73f3024b4eefe409d",
    "size": 207242,
    "type": "regular",
    "uid": 0
  },
  "readonly": true,
  "release_pending": {
    "exists": false,
    "path": "/opt/terminal/beta/.release-pending"
  },
  "rollback_scope": "First accepted installation. rollback_baseline=true is future eligibility, not an executed accepted-runtime rollback.",
  "runtime_accepted": {
    "ctime_ns": 1792459881135101501,
    "destination": {
      "ctime_ns": 1792459881135101501,
      "dev": 64769,
      "gid": 0,
      "ino": 3946428,
      "mode": "0o640",
      "mtime_ns": 1792459881132101484,
      "nlink": 1,
      "path": "/var/lib/mastermind-terminal-beta/source-provisioned/runtime-accepted-e45bde2cac07ac3b29285ff70c40d68900fad62c-c62950826aca6fd8.json",
      "sha256": "698204ef4ad72a1bfa896110af875df080bf773687150890e8a2322bd6b452d7",
      "size": 1481,
      "type": "regular",
      "uid": 0
    },
    "dev": 2048,
    "exact_record_retained_at": "/var/lib/mastermind-terminal-beta/source-provisioned/runtime-accepted-e45bde2cac07ac3b29285ff70c40d68900fad62c-c62950826aca6fd8.json",
    "gid": 0,
    "ino": 1598476,
    "mode": "0o777",
    "mtime_ns": 1792459881135101501,
    "nlink": 1,
    "path": "/opt/terminal/beta/.runtime-accepted",
    "record_summary": {
      "acceptance_attempt_id": "5099c71dba9f4fb78a3088308688a9a4",
      "accepted_sha": "e45bde2cac07ac3b29285ff70c40d68900fad62c",
      "app_root": "/opt/terminal/beta/terminal",
      "build_id": "build-TfctsWXpff2fKS",
      "canonical_repo": "/opt/terminal/.gitsrc-beta",
      "generated_at": "2026-10-20T01:31:21.128427Z",
      "policy_digest": "99f76cb211b086d1f83bb86c10747e2711a4c318fa4bd5dab1b94e84d46fe1d6",
      "policy_path": "/opt/terminal/.gitsrc-beta/ops/terminal_source_audit.beta.json",
      "previous_runtime_record": null,
      "previous_runtime_record_id": null,
      "record_id": "c62950826aca6fd8aa98c393097d22efd12639228a5c62db4e821eabb948c0dc",
      "release_receipt_id": "d1d41bea5d47e17b7b1c44c25c1fea24cf95c30806f0046fcde528ebfd6788bb",
      "release_receipt_path": "/var/lib/mastermind-terminal-beta/release-preflight/20261020T013119Z-e45bde2cac07ac3b29285ff70c40d68900fad62c-d1d41bea5d47e17b7b1c44c25c1fea24cf95c30806f0046fcde528ebfd6788bb.json",
      "rollback_baseline": true,
      "runtime_accepted": true,
      "schema": "mastermind.terminal.beta_runtime_accepted.v1",
      "source_audit_receipt_id": "1bcd1ef2c5eb51a68793d3e7407fa46955e517689d06c318d6f0952418c0acc2",
      "source_provisioned_record": "/var/lib/mastermind-terminal-beta/source-provisioned/source-provisioned-e45bde2cac07ac3b29285ff70c40d68900fad62c-efb499b6d0108d69.json",
      "source_provisioned_record_id": "efb499b6d0108d69d3eedba424f7ef6ecea26c957c5378fbef4f9b6b997365d9",
      "target": "beta",
      "target_root": "/opt/terminal/beta"
    },
    "size": 132,
    "symlink": "/var/lib/mastermind-terminal-beta/source-provisioned/runtime-accepted-e45bde2cac07ac3b29285ff70c40d68900fad62c-c62950826aca6fd8.json",
    "type": "symlink",
    "uid": 0
  },
  "runtime_pointer_observation": {
    "ctime_ns": 1792459881135101501,
    "dev": 2048,
    "gid": 0,
    "ino": 1598476,
    "mode": "0o777",
    "mtime_ns": 1792459881135101501,
    "nlink": 1,
    "path": "/opt/terminal/beta/.runtime-accepted",
    "size": 132,
    "symlink": "/var/lib/mastermind-terminal-beta/source-provisioned/runtime-accepted-e45bde2cac07ac3b29285ff70c40d68900fad62c-c62950826aca6fd8.json",
    "type": "symlink",
    "uid": 0
  },
  "schema": "mastermind.attended.beta_success_postread.v3",
  "services": {
    "terminal-beta.service": {
      "error": "",
      "exit": 0,
      "out": "MainPID=2427329\nExecMainStartTimestampMonotonic=7560285026653\nUMask=0022\nWorkingDirectory=/opt/terminal/beta/terminal\nCapabilityBoundingSet=\nAmbientCapabilities=\nUser=terminal-beta\nGroup=terminal-beta\nSupplementaryGroups=\nReadWritePaths=/opt/terminal/beta/terminal/.next/cache\nReadOnlyPaths=/opt/terminal/terminal/public/data\nInaccessiblePaths=\nPrivateTmp=yes\nPrivateDevices=yes\nProtectHome=read-only\nProtectSystem=strict\nNoNewPrivileges=yes\nSystemCallFilter=_llseek _newselect accept accept4 access add_key alarm arch_prctl arm_fadvise64_64 bind brk cacheflush capget capset chdir chmod chown chown32 clock_getres clock_getres_time64 clock_gettime clock_gettime64 clock_nanosleep clock_nanosleep_time64 clone clone3 close close_range connect copy_file_range creat dup dup2 dup3 epoll_create epoll_create1 epoll_ctl epoll_ctl_old epoll_pwait epoll_pwait2 epoll_wait epoll_wait_old eventfd eventfd2 execve execveat exit exit_group faccessat faccessat2 fadvise64 fadvise64_64 fallocate fchdir fchmod fchmodat fchmodat2 fchown fchown32 fchownat fcntl fcntl64 fdatasync fgetxattr flistxattr flock fork fremovexattr fsetxattr fstat fstat64 fstatat64 fstatfs fstatfs64 fsync ftruncate ftruncate64 futex futex_time64 futex_waitv futimesat get_mempolicy get_robust_list get_thread_area getcpu getcwd getdents getdents64 getegid getegid32 geteuid geteuid32 getgid getgid32 getgroups getgroups32 getitimer getpeername getpgid getpgrp getpid getppid getpriority getrandom getresgid getresgid32 getresuid getresuid32 getrlimit getrusage getsid getsockname getsockopt gettid gettimeofday getuid getuid32 getxattr inotify_add_watch inotify_init inotify_init1 inotify_rm_watch io_cancel io_destroy io_getevents io_pgetevents io_pgetevents_time64 io_setup io_submit io_uring_enter io_uring_register io_uring_setup ioctl ioprio_get ioprio_set ipc kcmp keyctl kill lchown lchown32 lgetxattr link linkat listen listxattr llistxattr lremovexattr lseek lsetxattr lstat lstat64 madvise mbind membarrier memfd_create migrate_pages mkdir mkdirat mknod mknodat mlock mlock2 mlockall mmap mmap2 move_pages mprotect mq_getsetattr mq_notify mq_open mq_timedreceive mq_timedreceive_time64 mq_timedsend mq_timedsend_time64 mq_unlink mremap msgctl msgget msgrcv msgsnd msync munlock munlockall munmap name_to_handle_at nanosleep newfstatat nice oldfstat oldlstat oldolduname oldstat olduname open openat openat2 pause personality pidfd_open pidfd_send_signal pipe pipe2 poll ppoll ppoll_time64 prctl pread64 preadv preadv2 prlimit64 process_madvise process_vm_readv process_vm_writev pselect6 pselect6_time64 pwrite64 pwritev pwritev2 read readahead readdir readlink readlinkat readv recv recvfrom recvmmsg recvmmsg_time64 recvmsg remap_file_pages removexattr rename renameat renameat2 request_key restart_syscall riscv_flush_icache rmdir rseq rt_sigaction rt_sigpending rt_sigprocmask rt_sigqueueinfo rt_sigreturn rt_sigsuspend rt_sigtimedwait rt_sigtimedwait_time64 rt_tgsigqueueinfo sched_get_priority_max sched_get_priority_min sched_getaffinity sched_getattr sched_getparam sched_getscheduler sched_rr_get_interval sched_rr_get_interval_time64 sched_setaffinity sched_setattr sched_setparam sched_setscheduler sched_yield select semctl semget semop semtimedop semtimedop_time64 send sendfile sendfile64 sendmmsg sendmsg sendto set_mempolicy set_mempolicy_home_node set_robust_list set_thread_area set_tid_address set_tls setfsgid setfsgid32 setfsuid setfsuid32 setgid setgid32 setgroups setgroups32 setitimer setns setpgid setpriority setregid setregid32 setresgid setresgid32 setresuid setresuid32 setreuid setreuid32 setrlimit setsid setsockopt setuid setuid32 setxattr shmat shmctl shmdt shmget shutdown sigaction sigaltstack signal signalfd signalfd4 sigpending sigprocmask sigreturn sigsuspend socket socketcall socketpair splice stat stat64 statfs statfs64 statx swapcontext symlink symlinkat sync sync_file_range sync_file_range2 syncfs sysinfo tee tgkill time timer_create timer_delete timer_getoverrun timer_gettime timer_gettime64 timer_settime timer_settime64 timerfd_create timerfd_gettime timerfd_gettime64 timerfd_settime timerfd_settime64 times tkill truncate truncate64 ugetrlimit umask uname unlink unlinkat unshare userfaultfd utime utimensat utimensat_time64 utimes vfork vmsplice wait4 waitid waitpid write writev\nRestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX\nRestrictNamespaces=yes\nBindReadOnlyPaths=/opt/terminal/terminal/public/data:/opt/terminal/beta/terminal/public/data:rbind\nActiveState=active\nSubState=running\nFragmentPath=/etc/systemd/system/terminal-beta.service\nDropInPaths=\nUnitFileState=enabled"
    },
    "terminal.service": {
      "error": "",
      "exit": 0,
      "out": "MainPID=2336355\nExecMainStartTimestampMonotonic=7552363880288\nUMask=0022\nWorkingDirectory=/opt/terminal/terminal\nCapabilityBoundingSet=cap_chown cap_dac_override cap_dac_read_search cap_fowner cap_fsetid cap_kill cap_setgid cap_setuid cap_setpcap cap_linux_immutable cap_net_bind_service cap_net_broadcast cap_net_admin cap_net_raw cap_ipc_lock cap_ipc_owner cap_sys_module cap_sys_rawio cap_sys_chroot cap_sys_ptrace cap_sys_pacct cap_sys_admin cap_sys_boot cap_sys_nice cap_sys_resource cap_sys_time cap_sys_tty_config cap_mknod cap_lease cap_audit_write cap_audit_control cap_setfcap cap_mac_override cap_mac_admin cap_syslog cap_wake_alarm cap_block_suspend cap_audit_read cap_perfmon cap_bpf cap_checkpoint_restore\nAmbientCapabilities=\nUser=\nGroup=\nSupplementaryGroups=\nReadWritePaths=\nReadOnlyPaths=\nInaccessiblePaths=\nPrivateTmp=no\nPrivateDevices=no\nProtectHome=no\nProtectSystem=no\nNoNewPrivileges=no\nSystemCallFilter=~\nRestrictAddressFamilies=~\nRestrictNamespaces=no\nBindReadOnlyPaths=\nActiveState=active\nSubState=running\nFragmentPath=/etc/systemd/system/terminal.service\nDropInPaths=/etc/systemd/system/terminal.service.d/boats-history.conf /etc/systemd/system/terminal.service.d/hardening.conf /etc/systemd/system/terminal.service.d/storage.conf /etc/systemd/system/terminal.service.d/ticker-news-rail.conf\nUnitFileState=enabled"
    }
  },
  "shared_lock_entries": [],
  "shared_lock_parent": {
    "ctime_ns": 1792459881972106512,
    "dev": 2048,
    "gid": 0,
    "ino": 1591358,
    "mode": "0o700",
    "mtime_ns": 1792459881972106512,
    "nlink": 2,
    "path": "/opt/terminal/.terminal-build-resource.lock",
    "size": 4096,
    "type": "directory",
    "uid": 0
  },
  "source_provisioned": {
    "ctime_ns": 1792383936443604029,
    "destination": {
      "ctime_ns": 1792383936443604029,
      "dev": 64769,
      "gid": 0,
      "ino": 3943348,
      "mode": "0o640",
      "mtime_ns": 1792383936440604014,
      "nlink": 1,
      "path": "/var/lib/mastermind-terminal-beta/source-provisioned/source-provisioned-e45bde2cac07ac3b29285ff70c40d68900fad62c-efb499b6d0108d69.json",
      "sha256": "9aac8ec8c132eecf4d2664d8f1e18e8a6bffce5f6d7176e4021b15d6d953cfa4",
      "size": 1841,
      "type": "regular",
      "uid": 0
    },
    "dev": 2048,
    "exact_record_retained_at": "/var/lib/mastermind-terminal-beta/source-provisioned/source-provisioned-e45bde2cac07ac3b29285ff70c40d68900fad62c-efb499b6d0108d69.json",
    "gid": 0,
    "ino": 1597725,
    "mode": "0o777",
    "mtime_ns": 1792383936443604029,
    "nlink": 1,
    "path": "/opt/terminal/beta/.source-provisioned",
    "record_summary": {
      "accepted_runtime": false,
      "accepted_sha": "e45bde2cac07ac3b29285ff70c40d68900fad62c",
      "app_root": "/opt/terminal/beta/terminal",
      "canonical_repo": "/opt/terminal/.gitsrc-beta",
      "deployment_marker": "/opt/terminal/beta/terminal/.deployment-id",
      "generated_at": "2026-10-19T04:25:36.437915Z",
      "policy_digest": "99f76cb211b086d1f83bb86c10747e2711a4c318fa4bd5dab1b94e84d46fe1d6",
      "policy_path": "/opt/terminal/.gitsrc-beta/ops/terminal_source_audit.beta.json",
      "provision_authorized": true,
      "provisioned": [
        {
          "git_tree": "840d6407d68b8f60211cdd734f169d92f12c5555",
          "live_path": "/opt/terminal/beta/terminal",
          "repo_path": "terminal"
        },
        {
          "git_tree": "331c5f6a5dd833909ffad53e66d9760ce6b762c1",
          "live_path": "/opt/terminal/beta/ingest",
          "repo_path": "ingest"
        },
        {
          "git_tree": "043397cd506a4840728d0c261404c8937a942d2f",
          "live_path": "/opt/terminal/beta/scripts",
          "repo_path": "scripts"
        },
        {
          "git_tree": "7893be6de08e09b2e3bbc1558b6eaebae2dee3e1",
          "live_path": "/opt/terminal/beta/config",
          "repo_path": "config"
        },
        {
          "git_tree": "6903e776d394e1151b256f9bd897aa3151d8083f",
          "live_path": "/opt/terminal/beta/contracts",
          "repo_path": "contracts"
        },
        {
          "git_tree": "a6e912a645929aaf4887593afbbd4e05fc407f73",
          "live_path": "/opt/terminal/beta/hub",
          "repo_path": "hub"
        },
        {
          "git_tree": "5395976e3612affe1a8292788209b32b8cd8c8a0",
          "live_path": "/opt/terminal/beta/signal_layer",
          "repo_path": "signal_layer"
        }
      ],
      "record_id": "efb499b6d0108d69d3eedba424f7ef6ecea26c957c5378fbef4f9b6b997365d9",
      "rollback_baseline": false,
      "schema": "mastermind.terminal.beta_source_provisioned.v1",
      "target": "beta",
      "target_root": "/opt/terminal/beta"
    },
    "size": 134,
    "symlink": "/var/lib/mastermind-terminal-beta/source-provisioned/source-provisioned-e45bde2cac07ac3b29285ff70c40d68900fad62c-efb499b6d0108d69.json",
    "type": "symlink",
    "uid": 0
  },
  "status": {
    "body": {
      "bridgeVersion": "20261018.1",
      "buildId": "e45bde2cac07ac3b29285ff70c40d68900fad62c",
      "documentVersion": "20261018.1",
      "enabled": true,
      "protocol": "mmx.shared-shell.v1",
      "registrySha256": "5307ea5a7964fde609a8f20f1af30b6bf483b7631f7232e5db74f9ef1d710023"
    },
    "effective_url": "http://127.0.0.1:3001/api/shared-shell/status",
    "headers": {
      "Cache-Control": "private, no-store, max-age=0",
      "Content-Type": "application/json",
      "X-Robots-Tag": "noindex, nofollow"
    },
    "http_status": 200
  },
  "unobserved_checks": []
}
```

</details>

