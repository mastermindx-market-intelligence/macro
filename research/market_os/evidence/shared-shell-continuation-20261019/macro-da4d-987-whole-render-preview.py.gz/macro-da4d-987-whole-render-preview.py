from pathlib import Path
import subprocess,json,hashlib,datetime,sys,os,difflib
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");D=E/"macro-da4d-987-whole-render-preview";G=["git","--no-optional-locks","-C",str(W)]
B="3b49d6a5c8a6330652a926a8e5061e0dbb3d0387";H="da4df7d1e1ac709055c6fa1d482304a875e81824";M="9875169102cc6f36a64d465fe7c06f6bb8fb0220"
def git(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
def oid(b):return hashlib.sha1(("blob "+str(len(b))+"\0").encode()+b).hexdigest()
assert not D.exists();D.mkdir()
owners=["lib/pages.py","lib/shared_shell.py","scripts/optimize_assets.py"]
source={p:git("show",H+":"+p) for p in owners}
assert all((W/p).read_bytes()==v for p,v in source.items())
os.chdir(W);sys.path.insert(0,str(W))
from scripts.optimize_assets import make_optimizer
from lib.shared_shell import inject_shared_shell_text
from lib.pages import dbase_prefix
opt=make_optimizer(W/"site")
closure=dict(zip(opt.__code__.co_freevars,[c.cell_contents for c in opt.__closure__]))
versions=[dg((W/"site"/p).read_bytes())[:8] for p in ["shared_shell_bridge.js","shared_shell.css"]]
paths=["site/us_stocks.html","site/etfs.html","site/special_situations.html","site/china_special_situations.html"]
rows=[]
for p in paths:
 texts={}
 for label,rev in [("B",B),("H",H),("M",M)]:
  raw=git("show",rev+":"+p)
  value=opt(inject_shared_shell_text(raw.decode(),dbase_prefix(W/p),version=versions[0],css_version=versions[1],site_dir=W/"site"),(W/p).parent)
  texts[label]=value
  (D/(Path(p).name+"."+label+".canonical.html")).write_text(value)
  rows.append({"path":p,"parent":label,"commit":rev,"original_bytes":len(raw),"original_sha256":dg(raw),"canonical_bytes":len(value.encode()),"canonical_sha256":dg(value.encode())})
 diff="".join(difflib.unified_diff(texts["B"].splitlines(True),texts["H"].splitlines(True),fromfile="B-owner-normalized",tofile="H-owner-normalized"))
 (D/(Path(p).name+".head-minus-base.patch")).write_text(diff)
 print(json.dumps({"path":p,"normalized_H_equals_B":texts["H"]==texts["B"],"remaining_difference_bytes":len(diff.encode()),"remaining_difference_first_lines":diff.splitlines()[:20]}),flush=True)
assets=[]
for p,value in sorted(closure["cache"].items()):
 if value is None:assets.append({"path":str(p),"missing":True});continue
 raw=p.read_bytes();assert dg(raw)[:8]==value
 rel=str(p.relative_to(W));h_oid=git("rev-parse",H+":"+rel).decode().strip()
 assert oid(raw)==h_oid,rel
 assets.append({"path":rel,"bytes":len(raw),"sha256":dg(raw),"git_blob":h_oid})
assert all((W/p).read_bytes()==v for p,v in source.items())
out={"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"base":B,"head":H,"incoming":M,"scope":"Scratch-only immutable whole-render resolution preview; no W/index writes or actual resolution. Current H source/asset bytes checked before and after. Four .gitattributes -merge pages select complete incoming M; only existing shared-shell injector/asset optimizer transformation proposed.","owners":{p:dg(v) for p,v in source.items()},"rows":rows,"assets":assets}
(D/"receipt.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps({"receipt":str(D/"receipt.json"),"asset_count":len(assets)},indent=2),flush=True)
