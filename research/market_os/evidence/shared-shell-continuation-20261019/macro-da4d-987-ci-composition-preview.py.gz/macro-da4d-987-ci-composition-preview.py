from pathlib import Path
import ast,copy,collections,subprocess,hashlib,json,datetime
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","--no-optional-locks","-C",str(W)]
B="3b49d6a5c8a6330652a926a8e5061e0dbb3d0387";H="da4df7d1e1ac709055c6fa1d482304a875e81824";M="9875169102cc6f36a64d465fe7c06f6bb8fb0220";T="11ad3c513bc73c9f03a06363ea9b810e0308b574"
import yaml
def git(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
def sub(a,b):
 it=iter(b);return all(any(x==v for v in it) for x in a)
manifest=".github/ci/legacy-jobs.yml";test="tests/test_ci_pack.py"
raw={r:{p:git("show",r+":"+p) for p in (manifest,test)} for r in (B,H,M,T)}
b,h,m,a=[yaml.safe_load(raw[r][manifest])["jobs"] for r in (B,H,M,T)]
assert list(a)==list(m) and set(a)==set(h)|set(m)
for k in a:
 if k not in h:assert a[k]==m[k],k;continue
 hb={x:y for x,y in h[k].items() if x!="paths"};mb={x:y for x,y in m[k].items() if x!="paths"};bb={x:y for x,y in b[k].items() if x!="paths"};ab={x:y for x,y in a[k].items() if x!="paths"}
 if hb==bb:assert ab==mb,k
 elif mb==bb:assert ab==hb,k
 else:assert hb==mb==ab,k
 hp=h[k].get("paths",[]);mp=m[k].get("paths",[]);ap=a[k].get("paths",[])
 assert collections.Counter(ap)==collections.Counter(hp)|collections.Counter(mp),k
 assert sub(hp,ap) and sub(mp,ap),k
expected=ast.parse(raw[M][test]);actual=ast.parse(raw[T][test]);head=ast.parse(raw[H][test]);counts={5822:0,5697:0}
for node in ast.walk(expected):
 if isinstance(node,ast.Constant) and isinstance(node.value,int) and node.value in counts:
  counts[node.value]+=1;node.value={5822:5829,5697:5704}[node.value]
assert counts=={5822:1,5697:1}
fn="test_exclusive_curation_narrows_ordinary_code_prs"
ef=next(n for n in expected.body if isinstance(n,ast.FunctionDef) and n.name==fn);hf=next(n for n in head.body if isinstance(n,ast.FunctionDef) and n.name==fn);af=next(n for n in actual.body if isinstance(n,ast.FunctionDef) and n.name==fn)
assert ast.get_docstring(af,clean=False)==ast.get_docstring(hf,clean=False)
ef.body[0]=copy.deepcopy(hf.body[0])
assert ast.dump(actual,include_attributes=False)==ast.dump(expected,include_attributes=False)
out={"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"base":B,"head":H,"incoming":M,"read_only_merge_tree":T,"actual_worktree_or_index_accepted":False,"jobs":len(a),"new_jobs":sorted(set(m)-set(h)),"all_ids_order_new_jobs_and_nonpath_intents_preserved":True,"all_parent_path_counter_union_and_sequences_preserved":True,"test_AST_equals_incoming_plus_only_prior_two_measured_constants_and_preserved_H_history":True,"manifest_sha256":dg(raw[T][manifest]),"test_sha256":dg(raw[T][test]),"scope":"Immutable read-only merge-tree composition preview. Match actual staged files after the in-progress ordinary merge completes; not producing tests or hosted admission."}
p=E/"macro-da4d-987-ci-composition-preview.json";assert not p.exists();p.write_text(json.dumps(out,indent=2)+"\n");print(json.dumps(out,indent=2),flush=True)
