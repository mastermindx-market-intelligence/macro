from pathlib import Path
import subprocess,json,hashlib,datetime,re,copy,yaml,ast
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","-C",str(W)]
B="df3cba80e5ff43e3411209381b32d9d4df06bd1f";H="2ae6498d0b9f2a088af2e827abf6527799757f8c";M="7a6e21cb7d6a38855b7e06432c94f61acb0fe6f1";OUT=E/"macro-2ae-7a6-source-resolution.json";BACK=E/"macro-2ae-7a6-source-before"
def git(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
def dump(n):return ast.dump(n,include_attributes=False)
assert not OUT.exists() and not BACK.exists()
assert git("rev-parse","HEAD").decode().strip()==H and git("rev-parse","MERGE_HEAD").decode().strip()==M
paths=[".github/ci/legacy-jobs.yml","app/deploy/update.sh","lib/macro_suite_labels.py","tests/test_macro_command_copy_law.py"]
census={r["path"]:r for r in json.loads((E/"macro-2ae-7a6-conflict-census.json").read_text())}
parents={p:{r:git("show",r+":"+p).decode() for r in [B,H,M]} for p in paths}
pat=re.compile(r"^<<<<<<< HEAD\n(.*?)^=======\n(.*?)^>>>>>>> "+M+r"\n",re.M|re.S)
candidates={};checks={}
for p in paths:assert dg((W/p).read_bytes())==census[p]["raw_sha256"],p
p=paths[0];raw=(W/p).read_text();matches=list(pat.finditer(raw));assert len(matches)==7
for hit in matches:
 assert hit.group(1)=='      - "lib/shared_shell.py"\n      - "lib/site_assets.py"\n'
 assert hit.group(2)=='      - "app/medtech.py"\n      - "engine/medtech/__init__.py"\n      - "engine/medtech/events.py"\n      - "engine/medtech/publication.py"\n'
candidates[p]=pat.sub(lambda m:m.group(1)+m.group(2),raw)
b,h,m=(yaml.safe_load(parents[p][rev]) for rev in [B,H,M]);c=yaml.safe_load(candidates[p]);assert set(c)==set(b)==set(h)==set(m)
assert set(c["jobs"])==set(h["jobs"])|set(m["jobs"]) and list(c["jobs"])==list(m["jobs"]);both=[]
for job,v in c["jobs"].items():
 if job not in b["jobs"]:
  assert v==h["jobs"].get(job,m["jobs"].get(job)),job;continue
 bv=b["jobs"][job];hv=h["jobs"][job];mv=m["jobs"][job]
 for key in set(bv)|set(hv)|set(mv):
  x=bv.get(key);y=hv.get(key);z=mv.get(key);actual=v.get(key)
  if y==x:assert actual==z,(job,key,"incoming")
  elif z==x:assert actual==y,(job,key,"head")
  elif y==z:assert actual==y,(job,key,"identical")
  elif key=="paths":
   assert set(x or [])<=set(y or []) and set(x or [])<=set(z or []) and set(actual)==set(y)|set(z),(job,key)
   assert all((x or []).count(q)<=min((y or []).count(q),(z or []).count(q)) and max((y or []).count(q),(z or []).count(q))<=actual.count(q)<=(y or []).count(q)+(z or []).count(q)-(x or []).count(q) for q in set(actual)),(job,key,"unattributed multiplicity")
   both.append(job)
  else:raise AssertionError((job,key,"concurrent nonpath change"))
checks["manifest"]={"jobs":len(c["jobs"]),"incoming_order_preserved":True,"all_parent_fields_preserved":True,"concurrent_path_unions":both,"multiplicities_attributed_to_parent_additions":True}
p=paths[1];raw=(W/p).read_text();matches=list(pat.finditer(raw));assert len(matches)==1
a=matches[0].group(1);z=matches[0].group(2);base=next(s+"\n" for s in parents[p][B].splitlines() if s.startswith('if [ "$API_UNIT_UPDATED" -eq 1 ] || ! mm_api_fence_marker_ready'))
old="|lib/(config|ai_costs";new="|lib/(config|shared_shell|ai_costs";before=r"|engine/sector_intelligence/.*\.py|engine/company_intelligence";after=r"|engine/sector_intelligence/.*\.py|engine/medtech/(events|publication)\.py|engine/company_intelligence"
assert base.count(old)==base.count(before)==1 and a==base.replace(old,new,1) and z==base.replace(before,after,1)
joined=z.replace(old,new,1);assert joined==a.replace(before,after,1);candidates[p]=pat.sub(lambda _:joined,raw)
checks["updater"]={"independent_additions":["lib/shared_shell.py","engine/medtech/(events|publication).py"],"all_other_incoming_changes_retained":True,"execution":False}
p=paths[2];raw=(W/p).read_text();matches=list(pat.finditer(raw));assert len(matches)==1
candidate=pat.sub(lambda hit:hit.group(2),raw);assert candidate==parents[p][M]
key="US labor-market state cannot be classified: axis coverage is below the disclosed floor. No quadrant is asserted rather than defaulting to a neutral state."
def without_mapping(s,expected):
 t=ast.parse(s);n=next(n for n in t.body if isinstance(n,ast.AnnAssign) and isinstance(n.target,ast.Name) and n.target.id=="PLAIN_PRODUCER")
 found=[i for i,v in enumerate(n.value.elts) if isinstance(v,ast.Tuple) and isinstance(v.elts[0],ast.Constant) and v.elts[0].value==key]
 assert len(found)==expected
 for i in reversed(found):n.value.elts.pop(i)
 return t
assert dump(without_mapping(parents[p][H],1))==dump(without_mapping(parents[p][M],1))==dump(without_mapping(parents[p][B],0))
candidates[p]=candidate;checks["labels"]={"canonical":"incoming exact bytes","single_equivalent_lookup_key":True,"outside_mapping_ast_unchanged_from_both_parents":True}
p=paths[3];hs=parents[p][H];ms=parents[p][M];local_name="test_labor_coverage_refusal_is_plain_without_claiming_neutral";incoming_name="test_labor_coverage_refusal_has_plain_copy_without_changing_source"
ht=ast.parse(hs);mt=ast.parse(ms);fn=next(n for n in ht.body if isinstance(n,ast.FunctionDef) and n.name==local_name)
local="\n".join(hs.splitlines()[fn.lineno-1:fn.end_lineno])
assert local.count('"not treated as neutral"')==1 and local.count('"不把信息缺失视为中性"')==1
local=local.replace('"not treated as neutral"','"not treated as a neutral reading"',1).replace('"不把信息缺失视为中性"','"缺失数据不会被当作中性读数"',1)
anchor="def "+incoming_name+"(";assert ms.count(anchor)==1
candidate=ms.replace(anchor,local+"\n\n\n"+anchor,1);ct=ast.parse(candidate)
cn=next(n for n in ct.body if isinstance(n,ast.FunctionDef) and n.name==local_name)
expected_fn=copy.deepcopy(fn)
for n in ast.walk(expected_fn):
 if isinstance(n,ast.Constant) and n.value=="not treated as neutral":n.value="not treated as a neutral reading"
 elif isinstance(n,ast.Constant) and n.value=="不把信息缺失视为中性":n.value="缺失数据不会被当作中性读数"
assert dump(cn)==dump(expected_fn)
ct.body=[n for n in ct.body if not(isinstance(n,ast.FunctionDef) and n.name==local_name)];assert dump(ct)==dump(mt)
ht.body=[n for n in ht.body if not(isinstance(n,ast.FunctionDef) and n.name==local_name)]
mt.body=[n for n in mt.body if not(isinstance(n,ast.FunctionDef) and n.name==incoming_name)]
assert dump(ht)==dump(mt)==dump(ast.parse(parents[p][B]))
candidates[p]=candidate;checks["tests"]={"both_regressions_retained":True,"incoming_test_and_all_other_nodes_exact":True,"local_only_changes":"Two wording-specific EN/ZH assertion constants match incoming canonical copy; all source preservation, nonfallback, separate-original identity, real guard and ordinary-noop checks retained"}
assert (W/"tests/test_ci_pack.py").read_bytes()==git("show",H+":tests/test_ci_pack.py")==git("show",":tests/test_ci_pack.py")
checks["packing_bounds_and_test_source_unchanged"]=True
for p,s in candidates.items():assert not re.search(r"^(<<<<<<<|=======|>>>>>>>)",s,re.M),p
index=git("ls-files","--stage","-z");BACK.mkdir()
out={"started_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"head":H,"incoming":M,"base":B,"state":"PREFLIGHT_PASS","checks":checks,"rows":[]}
def save():OUT.write_text(json.dumps(out,indent=2,ensure_ascii=False)+"\n")
for p,s in candidates.items():
 raw=(W/p).read_bytes();backup=BACK/p.replace("/","_");backup.write_bytes(raw);out["rows"].append({"path":p,"before_sha256":dg(raw),"candidate_sha256":dg(s.encode()),"backup":str(backup)})
save()
for p,s in candidates.items():(W/p).write_text(s)
assert git("ls-files","--stage","-z")==index
bash=subprocess.run(["bash","-n",str(W/"app/deploy/update.sh")],capture_output=True);out["bash_syntax"]={"exit":bash.returncode,"stderr":bash.stderr.decode()};assert bash.returncode==0
subprocess.run(G+["add","--",*paths],check=True)
for p,s in candidates.items():assert git("show",":"+p)==s.encode()
out.update(state="FOUR_SOURCE_CONFLICTS_RESOLVED_STAGED",finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),remaining_unmerged=git("diff","--name-only","--diff-filter=U").decode().splitlines());save();print(json.dumps(out,indent=2,ensure_ascii=False))
