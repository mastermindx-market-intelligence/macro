import datetime,hashlib,json,pathlib,subprocess
E=pathlib.Path("/tmp/shared-shell-css-visual-20261019T1107");stem="macro-3b49-beta-health-20261020T1443";source=E/"macro-beta-before-e2d-publication-20261020T0536-remote.py"
remote=source.read_bytes();assert hashlib.sha256(remote).hexdigest()=="c53b62c77cc27142fc31f20e771a50428be6311af72249eec6140e5a068e78c0"
result=E/(stem+".json");assert not result.exists() and not (E/(stem+".stdout.json")).exists()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def dg(b):return hashlib.sha256(b).hexdigest()
r={"started_at":now(),"remote_source_path":str(source),"remote_source_sha256":dg(remote),"host_mutation":False,"owner_invoked":False,"queries":[]}
result.write_text(json.dumps(r,indent=2)+"\n")
p=subprocess.run(["ssh","-i","/Users/chriswong/.ssh/macro_dashboard_deploy_v2","-o","BatchMode=yes","-o","ConnectTimeout=15","-o","StrictHostKeyChecking=yes","root@146.190.142.17","python3 -"],input=remote,capture_output=True,timeout=90)
for suffix,data in [(".stdout.json",p.stdout),(".stderr",p.stderr)]:
 with (E/(stem+suffix)).open("xb") as f:f.write(data)
r.update({"ssh_finished_at":now(),"ssh_exit":p.returncode,"stdout_sha256":dg(p.stdout),"stdout_bytes":len(p.stdout),"stderr_sha256":dg(p.stderr),"stderr_bytes":len(p.stderr)})
result.write_text(json.dumps(r,indent=2)+"\n")
if p.returncode==0:
 h=json.loads(p.stdout)
 r["beta_identity_checks"]={"source_A":h["beta_source_HEAD"]["stdout"].strip()=="e45bde2cac07ac3b29285ff70c40d68900fad62c","runtime_receipt":h["runtime_pointer"]["sha256"]=="698204ef4ad72a1bfa896110af875df080bf773687150890e8a2322bd6b452d7","source_receipt":h["source_pointer"]["sha256"]=="9aac8ec8c132eecf4d2664d8f1e18e8a6bffce5f6d7176e4021b15d6d953cfa4","status_200":h["status"]["status"]==200,"service_stable":h["services"]["terminal-beta.service"]==h["beta_after"],"no_pending":not h["pending_exists"],"no_stages":not h["beta_stages"]}
 r["summary"]={"observed_at":h["observed_at"],"beta_service":h["services"]["terminal-beta.service"],"production_service":h["services"]["terminal.service"],"root_free":h["root_free"],"terminal_mount_free":h["terminal_mount_free"],"production_owner_sha256":h["production_owner"]["sha256"],"caddy_sha256":h["caddy"]["sha256"],"macro_head_before":h["macro"]["head_before"]["stdout"].strip(),"macro_head_after":h["macro"]["head_after"]["stdout"].strip()}
for args in [["dig","+noall","+answer","beta.mastermind-x.com","A"],["dig","+noall","+answer","beta.mastermind-x.com","CNAME"],["curl","--disable","--noproxy","*","--proto","=https","--head","--max-time","20","--silent","--show-error","https://beta.mastermind-x.com/api/shared-shell/status"]]:
 q=subprocess.run(args,capture_output=True,text=True,timeout=25)
 r["queries"].append({"argv":args,"exit":q.returncode,"stdout":q.stdout,"stderr":q.stderr})
r["finished_at"]=now();result.write_text(json.dumps(r,indent=2)+"\n")
print(json.dumps(r,indent=2),flush=True)
raise SystemExit(p.returncode)
