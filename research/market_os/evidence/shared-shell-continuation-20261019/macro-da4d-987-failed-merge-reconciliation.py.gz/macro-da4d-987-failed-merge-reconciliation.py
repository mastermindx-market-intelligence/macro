from pathlib import Path
import subprocess,json,hashlib,datetime,os
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","--no-optional-locks","-C",str(W)]
OUT=E/"macro-da4d-987-failed-merge-reconciliation.json"
assert not OUT.exists()
out={"started_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"operation":"Read-only census after original merge wrapper60909 completed exit1; no retry/abort/index/source mutation","wrapper_exit":1,"wrapper_runtime_seconds":2565.13,"actual_git_exit":"Not separately persisted: wrapper failed while resolving absent MERGE_HEAD before updating journal.","reads":[]}
def save():OUT.write_text(json.dumps(out,indent=2)+"\n")
save()
for name,args in [("head",["rev-parse","HEAD"]),("branch",["branch","--show-current"]),("merge_head",["rev-parse","-q","--verify","MERGE_HEAD"]),("orig_head",["rev-parse","-q","--verify","ORIG_HEAD"]),("unmerged",["ls-files","-u"]),("status",["status","--porcelain=v1"]),("staged_delta",["diff","--cached","--name-status","HEAD"])]:
 r=subprocess.run(G+args,capture_output=True,timeout=60)
 log=E/("macro-da4d-987-failed-merge-"+name+".txt");assert not log.exists();log.write_bytes(r.stdout)
 row={"name":name,"argv":G+args,"exit":r.returncode,"bytes":len(r.stdout),"sha256":hashlib.sha256(r.stdout).hexdigest(),"stdout":r.stdout.decode(errors="replace") if len(r.stdout)<12000 else "See raw log "+str(log),"stderr":r.stderr.decode(errors="replace")}
 out["reads"].append(row);save();print(json.dumps(row),flush=True)
for label,rev in [("H","da4df7d1e1ac709055c6fa1d482304a875e81824"),("M","9875169102cc6f36a64d465fe7c06f6bb8fb0220"),("T","11ad3c513bc73c9f03a06363ea9b810e0308b574")]:
 r=subprocess.run(G+["ls-tree","-r",rev],capture_output=True,timeout=60)
 assert r.returncode==0
 wanted=[line for line in r.stdout.decode().splitlines() if any(oid in line for oid in ["30d1e9578fdd46cc944321c84b1075e75088be7b","4034805ee69b3c416899a2cf412b4b796b27146f"])]
 out.setdefault("diagnostic_object_paths",{})[label]=wanted;save()
out["merge_log"]={"bytes":(E/"macro-da4d-987-merge.log").stat().st_size,"sha256":hashlib.sha256((E/"macro-da4d-987-merge.log").read_bytes()).hexdigest(),"text":(E/"macro-da4d-987-merge.log").read_text()}
out["finished_at"]=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps({"diagnostic_object_paths":out["diagnostic_object_paths"],"merge_log":out["merge_log"],"finished_at":out["finished_at"]},indent=2),flush=True)
