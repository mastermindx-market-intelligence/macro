import pathlib,subprocess,json,hashlib,datetime
W=pathlib.Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27")
E=pathlib.Path("/tmp/shared-shell-css-visual-20261019T1107")
G=["git","-C",str(W)]
AE="ae3e6bc547361b632223e7e9bde73128b399035e";N="5c2d0a04afd19642d2dab483885d46c73b7baed4";T="de860bd0a15f83f9b530bd6c1fe7f932f078d5a6"
outpath=E/"macro-ae3-5c2d-complete-merge.json"
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
def save():outpath.write_text(json.dumps(out,indent=2)+"\n")
assert not outpath.exists()
assert git("rev-parse","HEAD").decode().strip()==AE and git("rev-parse","MERGE_HEAD").decode().strip()==N
assert git("write-tree").decode().strip()==T and not git("diff","--name-only").strip() and not git("ls-files","-u").strip()
assert git("branch","--show-current").decode().strip()=="sol/market-os-shared-shell-design-20260924"
proof=json.loads((E/"macro-ae3-5c2d-proof-finalize.json").read_text())
assert proof["final_index"]==T and proof["all_hashes_and_coverage_pass"] and proof["all_documentation_checks_exit0_after_repair"]
assert not git("diff","--cached","--check",N,"--").strip()
pr=json.loads(subprocess.check_output(["gh","pr","view","7949","--repo","mastermindx-market-intelligence/macro","--json","state,headRefOid,labels,autoMergeRequest"],cwd=W))
assert pr["state"]=="OPEN" and pr["headRefOid"]=="e2d10f933587f58be8716505529a37f8839901f7" and pr["autoMergeRequest"] is None
assert "merge-on-green" not in [x["name"] for x in pr["labels"]] and "merge-blocked" in [x["name"] for x in pr["labels"]]
out={"started_at":now(),"head_before":AE,"incoming":N,"expected_tree":T,"proof_receipt_sha256":dg((E/"macro-ae3-5c2d-proof-finalize.json").read_bytes()),"remote_pr":pr,"commit_attempted":False,"purpose":"Complete original pending ordinary N2 merge and preserve exact proof; newer main preflight and single normal same-branch push remain pending."};save()
msg=E/"macro-ae3-5c2d-complete-merge-message.txt"
assert not msg.exists()
msg.write_text("Merge main 5c2d0a04 and preserve Shared Shell recovery proof\n\nRetain the accepted source composition and measured CI packing correction.\nAdd actual fixture/browser, deployment, lineage and installer recovery receipts\nto the existing evidence pack, preserving failed attempts and full history.\n\nComplete the interrupted proof packaging with lossless evidence compression\nand the exact documentation-only whitespace repair. Current hosted admission,\nincumbent publication and public beta acceptance remain separate gates.\n")
log=E/"macro-ae3-5c2d-complete-merge.log";assert not log.exists()
out["commit_attempted"]=True;out["commit_started_at"]=now();save()
with log.open("xb") as f:p=subprocess.run(G+["commit","--file",str(msg)],cwd=W,stdout=f,stderr=subprocess.STDOUT)
out.update({"finished_at":now(),"commit_exit":p.returncode,"head_after":git("rev-parse","HEAD").decode().strip(),"parents_after":git("show","-s","--format=%P","HEAD").decode().strip().split(),"tree_after":git("rev-parse","HEAD^{tree}").decode().strip(),"status_after":git("status","--porcelain=v1","--untracked-files=no").decode().splitlines(),"log":{"path":str(log),"bytes":log.stat().st_size,"sha256":dg(log.read_bytes())}})
save()
print(json.dumps({**out,"log_tail":log.read_text(errors="replace")[-1800:]},indent=2),flush=True)
assert p.returncode==0 and out["parents_after"]==[AE,N] and out["tree_after"]==T and not out["status_after"]
