from pathlib import Path
import subprocess,json,hashlib,datetime,os,shutil
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","-C",str(W)]
H="da4df7d1e1ac709055c6fa1d482304a875e81824";M="9875169102cc6f36a64d465fe7c06f6bb8fb0220";BR="sol/market-os-shared-shell-design-20260924";OUT=E/"macro-da4d-987-reconciled-merge.json"
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def read(*a):return subprocess.check_output(G+list(a))
assert not OUT.exists()
assert read("rev-parse","HEAD").decode().strip()==H and read("branch","--show-current").decode().strip()==BR and not read("status","--porcelain=v1").strip()
assert subprocess.run(G+["rev-parse","-q","--verify","MERGE_HEAD"],capture_output=True).returncode==1
assert subprocess.run(G+["rev-parse","-q","--verify","AUTO_MERGE"],capture_output=True).returncode==1
recon=json.loads((E/"macro-da4d-987-object-availability-reconciliation.json").read_text())
assert recon["previously_unavailable_remote_blob"]["native_now_available_and_object_id_verified"] and recon["head"]==H and not recon["status"]
objects=read("rev-list","--objects","--missing=print",M,"^"+H)
assert not any(x.startswith(b"?") for x in objects.splitlines())
remote=read("ls-remote","--exit-code","origin","refs/heads/"+BR).decode().strip();assert remote.split()[0]=="b312bc4c08cf7633bf8fd259d2d46ec545fa120f"
out={"started_at":now(),"head":H,"incoming":M,"remote_branch_before":remote,"worktree_clean_before":True,"prior_failure_reconciled":"Wrapper1, no MERGE_HEAD/AUTO_MERGE/unmerged/staged/raw changes; both source commits safe. No abort/reset or config mutation. Missing-object census now0; exact403 blob now verified available. No actor or cause of object arrival inferred.","immediate_missing_count":0,"object_census_sha256":hashlib.sha256(objects).hexdigest(),"state":"RECONCILED_ORDINARY_MERGE_BEGIN"}
def save():OUT.write_text(json.dumps(out,indent=2)+"\n")
save();print(json.dumps({k:v for k,v in out.items() if k!="prior_failure_reconciled"}),flush=True)
log=E/"macro-da4d-987-reconciled-merge.log";trace=E/"macro-da4d-987-reconciled-merge.trace2.jsonl";assert not log.exists() and not trace.exists()
with log.open("xb") as f:r=subprocess.run(G+["merge","--no-ff","--no-commit",M],stdout=f,stderr=subprocess.STDOUT,env={**os.environ,"GIT_TRACE2_EVENT":str(trace)})
out.update(merge_exit=r.returncode,merge_finished_at=now(),log_bytes=log.stat().st_size,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),state="MERGE_EXIT_RECORDED_RECONCILING");save()
out["head_after"]=read("rev-parse","HEAD").decode().strip()
m=subprocess.run(G+["rev-parse","-q","--verify","MERGE_HEAD"],capture_output=True,text=True);out["merge_head"]={"exit":m.returncode,"stdout":m.stdout.strip(),"stderr":m.stderr.strip()}
out["unmerged"]=read("diff","--name-only","--diff-filter=U").decode().splitlines()
out["finished_at"]=now();out["state"]="MERGE_ACTIVE_READY_FOR_RESOLUTION" if r.returncode in (0,1) and m.stdout.strip()==M and out["head_after"]==H else "FAILED_EFFECT_REQUIRES_RECONCILIATION"
save();print(json.dumps(out,indent=2),flush=True)
assert out["state"]=="MERGE_ACTIVE_READY_FOR_RESOLUTION"
