from pathlib import Path
import subprocess,json,hashlib,datetime,ast,copy
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","-C",str(W)]
H="608dfad299e2e48ab7703bf0b180e0dca1318229";M="df3cba80e5ff43e3411209381b32d9d4df06bd1f";OUT=E/"macro-608-df3-measured-packing-repair.json";BACK=E/"macro-608-df3-packing-before.py"
def git(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert not OUT.exists() and not BACK.exists()
assert git("rev-parse","HEAD").decode().strip()==H and git("rev-parse","MERGE_HEAD").decode().strip()==M
assert not git("ls-files","-u").strip() and not git("diff","--name-only").strip()
measurement=E/"macro-608-df3-packing-measurement.json";raw=measurement.read_bytes();r=json.loads(raw)
assert dg(raw)=="51a7fea06c976d46db9d64898629ce97eb0039f93f588c28406cc32c2809b34e"
beforetree=git("write-tree").decode().strip()
assert r["state"]=="ACTUAL_MEASUREMENT_COMPLETE" and r["source_tree"]==beforetree
assert r["source_index_unchanged"] and r["frozen_sources_unchanged"]
assert r["breaches"]==[["scripts/build_free_content.py","weight",5802,5795]]
assert [(x["jobs"],x["weight"],x["packs"]) for x in r["rows"]]==[(135,5829,10),(135,5802,10),(128,5578,10)]
for x in r["weight_attribution"]:
 assert x["deltas"]==[{"job":"data-base-shim","incoming_weight":7,"candidate_weight":12,"delta":5},{"job":"unrun-nav-chrome","incoming_weight":30,"candidate_weight":32,"delta":2}]
assert r["weight_attribution"][1]["ticker_news_selected"] and r["weight_attribution"][1]["ticker_news_incoming_weight"]==98
procedure={p:{"head":git("rev-parse",H+":"+p).decode().strip(),"incoming":git("rev-parse",M+":"+p).decode().strip()} for p in ["AGENTS.md","CLAUDE.md"]}
assert all(v["head"]==v["incoming"] for v in procedure.values()),procedure
p=W/"tests/test_ci_pack.py";old=p.read_bytes();s=old.decode()
assert dg(old)==r["frozen_sources"]["tests/test_ci_pack.py"] and old==git("show",":tests/test_ci_pack.py")
needle='("scripts/build_free_content.py", 135, 5_795)'
assert s.count(needle)==1
s=s.replace(needle,'("scripts/build_free_content.py", 135, 5_802)',1)
anchor='    """The measured before/after this wave exists to produce.\n\n'
assert s.count(anchor)==1
note="""    2026-10-20 Shared Shell composition with protected df3cba80: the actual
    canonical planner on the composed tree measured index 135 jobs / 5,829,
    free-content 135 / 5,802 and plan-book 128 / 5,578, all at ten packs.
    Applying the incoming manifest's weights to those same selected job IDs
    gives 5,822 / 5,795 / 5,571. The only weight differences are the retained
    data-base-shim 7 -> 12 and unrun-nav-chrome 30 -> 32. Free-content also
    selects the incoming ticker-news-qbus job at its unchanged weight of 98.
    This same-ID attribution is not a fresh incoming-tree selection replay.
    Compose that measured +7 with the incoming news allowance below: change
    only free-content's 5,795 -> 5,802. Keep its 135-job ceiling, the other
    probe ceilings, ten packs, selectors, declarations and suites unchanged.

"""
s=s.replace(anchor,anchor+note,1);new=s.encode()
a=ast.parse(old);b=ast.parse(new);aa=copy.deepcopy(a);bb=copy.deepcopy(b)
for tree in (aa,bb):
 for n in tree.body:
  if isinstance(n,ast.FunctionDef) and n.name=="test_exclusive_curation_narrows_ordinary_code_prs":
   assert isinstance(n.body[0],ast.Expr) and isinstance(n.body[0].value,ast.Constant)
   n.body[0].value.value="DOCSTRING"
for n in aa.body:
 if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="PACKING_PROBES" for t in n.targets):
  assert ast.literal_eval(n.value)==(("templates/index.html",136,5829),("scripts/build_free_content.py",135,5795),("engine/prophet/plan_book.py",130,5600))
  n.value.elts[1].elts[2].value=5802
assert ast.dump(aa,include_attributes=False)==ast.dump(bb,include_attributes=False)
out={"started_at":now(),"state":"PRECHECKS_COMPLETE","head":H,"incoming":M,"index_before":beforetree,"measurement_sha256":dg(raw),"procedure_unchanged":procedure,"old_sha256":dg(old),"new_sha256":dg(new),"sole_executable_change":"free-content max_weight 5795 -> 5802","docstring_note":note,"scope":"Observed composed planner result; same-ID incoming weight attribution, not incoming-tree selection replay"}
OUT.write_text(json.dumps(out,indent=2)+"\n");BACK.write_bytes(old);p.write_bytes(new)
subprocess.run(G+["add","--","tests/test_ci_pack.py"],check=True)
assert not git("diff","--name-only").strip() and not git("ls-files","-u").strip()
assert git("diff","--name-only",beforetree,git("write-tree").decode().strip()).decode().splitlines()==["tests/test_ci_pack.py"]
assert not git("diff","--cached","--check",M).strip()
out.update(finished_at=now(),state="MEASURED_BOUND_RECORDED_STAGED",index_after=git("write-tree").decode().strip(),ast_only_measured_bound_changed=True)
OUT.write_text(json.dumps(out,indent=2)+"\n");print(json.dumps(out,indent=2))
