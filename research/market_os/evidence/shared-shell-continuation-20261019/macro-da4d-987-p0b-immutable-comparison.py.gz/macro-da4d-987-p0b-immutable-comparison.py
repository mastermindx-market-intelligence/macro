from pathlib import Path
import subprocess,json,hashlib,datetime
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","--no-optional-locks","-C",str(W)]
revs={"B":"3b49d6a5c8a6330652a926a8e5061e0dbb3d0387","H":"da4df7d1e1ac709055c6fa1d482304a875e81824","M":"9875169102cc6f36a64d465fe7c06f6bb8fb0220","T":"11ad3c513bc73c9f03a06363ea9b810e0308b574"}
def git(*a):return subprocess.check_output(G+list(a))
dg=lambda b:hashlib.sha256(b).hexdigest()
lineage=json.loads((E/"macro-ae3-5c2d-p0b-lineage-v2.json").read_text());bound=lineage["bound_paths"];assert len(bound)==82
paths=[x["path"] for x in bound]
maps={}
for label,rev in revs.items():
 result={}
 for rec in git("ls-tree","-rz",rev,"--",*paths).split(b"\0"):
  if not rec:continue
  left,name=rec.split(b"\t",1);mode,kind,obj=left.decode().split();result[name.decode()]={"mode":mode,"kind":kind,"blob":obj}
 maps[label]=result
assert set(maps["H"])==set(paths)
for row in bound:assert maps["H"][row["path"]]["blob"]==row["git_blob"],row["path"]
changes={label:[{"path":p,"roles":next(r["roles"] for r in bound if r["path"]==p),"B":maps["B"].get(p),"H":maps["H"].get(p),"value":maps[label].get(p)} for p in paths if maps[label].get(p)!=maps["H"].get(p)] for label in ["B","M","T"]}
prefix="mockups/evidence/prophet-p0b-zero-fouc/"
D=E/"macro-da4d-987-p0b-immutable-parents";assert not D.exists();D.mkdir()
aliases={}
for label in ["B","H","M"]:
 aliases[label]={}
 for name in ["manifest.json","mobile-layout.json","mobile-layout-canada.json"]:
  raw=git("show",revs[label]+":"+prefix+name);(D/(label+"-"+name)).write_bytes(raw)
  obj=json.loads(raw);aliases[label][name]={"bytes":len(raw),"sha256":dg(raw),"top_keys":list(obj),"history":obj.get("history"),"generated_at":obj.get("generated_at")}
out={"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"revisions":revs,"bound_path_count":82,"H_all82_git_blobs_match_accepted_lineage":True,"complete_intersection_not_API_capped":True,"differences_from_H":changes,"aliases":aliases,"scope":"Immutable finite-input/provenance comparison only, not resolved-source acceptance or new producer run."}
p=E/"macro-da4d-987-p0b-immutable-comparison.json";assert not p.exists();p.write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps({"at":out["at"],"H_all82_git_blobs_match_accepted_lineage":True,"differences_from_H":changes,"alias_metadata":{k:{n:{a:b for a,b in v.items() if a!="history"} for n,v in z.items()} for k,z in aliases.items()}},indent=2),flush=True)
