import datetime,gzip,hashlib,json,pathlib,subprocess,yaml
W=pathlib.Path('/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27')
E=pathlib.Path('/tmp/shared-shell-css-visual-20261019T1107');P=W/'research/market_os/evidence/shared-shell-continuation-20261019'
H=W/'agentos/handoffs/MARKET-OS-SHARED-SHELL-2026-09-24.md'
def sha(b):return hashlib.sha256(b).hexdigest()
def g(*a):return subprocess.check_output(['git','-C',str(W),*a],text=True).strip()
r=json.loads((E/'macro-92c51-packing-after.json').read_text())
assert r['exit']==0 and r['source_and_index_unchanged']
assert g('rev-parse','HEAD')==r['head'] and g('rev-parse','MERGE_HEAD')==r['incoming'] and g('write-tree')==r['index']
assert not g('diff','--name-only') and not g('ls-files','-u')
mp=P/'MANIFEST.json';m=json.loads(mp.read_text());old_rows=json.loads(json.dumps(m['files']));assert len(old_rows)==280
def verify(rows):
 for row in rows:
  raw=(P/row['file']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],row['file']
  if row.get('encoding')=='gzip':
   raw=gzip.decompress(raw);assert len(raw)==row['original_bytes'] and sha(raw)==row['original_sha256'],row['file']
 assert {x.name for x in P.iterdir() if x.is_file()}=={x['file'] for x in rows}|{'MANIFEST.json'}
verify(old_rows)
names='''macro-8cc-92c51-preflight.json
macro-8cc-92c51-prepare.py
macro-8cc-92c51-candidates.json
macro-8cc-92c51-merge.py
macro-8cc-92c51-merge-invocation.json
macro-8cc-92c51-merge.log
macro-8cc-92c51-actual-merge.json
macro-92c51-focused-before-runner.py
macro-92c51-focused-before-invocation.json
macro-92c51-focused-before.json
macro-92c51-focused-before-process.json
macro-92c51-focused-before.log
macro-92c51-focused-before-probes.json
macro-92c51-focused-before-attribution.json
macro-92c51-measurement-summary.json
macro-92c51-measured-budget-repair.py
macro-92c51-budget-repair.diff
macro-92c51-budget-repair.json
macro-92c51-packing-after-runner.py
macro-92c51-packing-after-invocation.json
macro-92c51-packing-after.log
macro-92c51-packing-after.json
macro-92c51-candidate-independent-review.md
macro-92c51-ci-independent-review.md
macro-full-checkpoint-0454-published8cc.md
macro-full-checkpoint-0511-merging92c.md
macro-8cc-hosted-contract-delta.log
macro-8cc-ci-before92c-publication.json
macro-8cc-main-92c51-compare-summary.json
macro-8cc-publication-owner-review.md
macro-8cc-merge-owner-interface-review.md
macro-8cc-public-capture-interface-review.md
macro-0f05-final-commit.json
macro-0f05-final-commit.log
macro-0f05-final-push.json
macro-0f05-final-push.log
macro-0f05-final-proof-index.json
macro-92c51-to-3667-prepublish-compare.json'''.splitlines()
assert len(names)==len(set(names))
payloads=[];already=[]
for name in names:
 source=E/name;raw=source.read_bytes();compressed=name.endswith(('.diff','.log','.txt')) or len(raw)>12000
 dest=name+('.gz' if compressed else '');payload=gzip.compress(raw,mtime=0) if compressed else raw
 if (P/dest).exists():
  assert (P/dest).read_bytes()==payload,dest;already.append(dest);continue
 row={'file':dest,'source':str(source),'bytes':len(payload),'sha256':sha(payload),'encoding':'gzip' if compressed else 'identity'}
 if compressed:row.update(original_bytes=len(raw),original_sha256=sha(raw));assert gzip.decompress(payload)==raw
 payloads.append((dest,payload,row))
add=('''
## 2026-10-20 continuation — incoming92c51 composition, same PR7949

Same WS:MARKET-OS/root market-os-shared-shell-design-20260924-sol-001/parent shared-shell-production-20261018-c1; originalbranch/shared-shell-r27. Compatible protectedINDEX/laws065b7fe719bb07407eae965ffb15e300ae2395f6. OriginalbetaA e45bde2cac07ac3b29285ff70c40d68900fad62c remains accepted afterR93 recovery. No bootstrap/#859redo.

Published8ccfa5ddba6770cef48f2f162c08474d023e094e hostedcontract-delta118461289660/run39371861641 passed05:04:39:0introduced/0inherited againstactualbase73ca987b5907034653d33cbdae1577a57e67120e/testmerge0f39b48d. Its rows135/5793/10,134/5668/10,128/5542/10 wereconfirmed. Authority/fencespassed; later snapshotpacks2/8/11successful/restpending. Historical8cc results do notqualifynewsource.

Main92c51f1ff800b36fc63e7869243945996ac7315c addedbond/SEC closure, scorecardstep andsource/generatedpages. Immutablefetch exit0/no warnings. Normalmergebase0f058428/previewb750bc4f/exactly2conflicts. Threeadditive manifesthunks preserveall329IDs/order/fields/pathmultiplicities/parentsubsequences. Testkeepsincoming5664 executablebehavior andbothhistories. SixteenShell/Caddy/updater/access/Sector/checkerbindings unchanged. Candidate receiptbb68045eab58efbd20bc1ad5991dc6ee0a4ffdda729b8c94eaa19997b863f5c7.

Ordinarymerge05:10:21–05:10:40 resolvesexact2files, stage1/2/3pinsmatch, no unmerged/unstagedfiles; index6670398b2e04ee6b571522cf7d2151385386fcf3, only2resolutionsdifferpreview, completeownedwhitespacePASS. ActualPython3.12 four-node run05:11:06.713662–05:14:34.874291Z:3PASS/1FAIL203.68s, sole5671>5664. Rows135/5796/10,134/5671/10,128/5545/10. CompleteIDs/order matchprior0f05, weight+3each; incomingcommandweightsforthosesameIDs5789/5664/5538. OnlyShelljobdeltas+5/+2 explainseven. No independentincoming-selection runclaimed.

Minimal5664->5671 plus10linehistory, allotherexecutableASTequal; patch1807B/SHA52d4d20ec4df2448ace557eee0c71e4309455243522ea9822e037089b4ac393c. Sourcegateindex9f468349fe2bd9b27eede0003fcfd62051f0d25f. Candidate andactualmeasurement/patch reviewsNONBLOCKING, scopesretained; adviser didnotconsume packing-afterresult.
'''+'\nRootconsumed finalexistingpacking-only: '+r['started_at']+' through '+r['finished_at']+',1PASS/exit0, source/indexunchanged; logSHA'+r['log_sha256']+'. Prior3scopepassesbindunchangedmanifest. Earlieradapter/boundary resultsremainhistorical withunchangedownerinputs; notrerun. No newfull-localdifferential/currentheadhostedgreenclaimed.\n'+'''
Freshmain3667000ca153496d8ff69e8864b159ac1e7b9de0 adds2unrelatedpanelPRs/sixpaths. Sourcepatchesread: noCI manifest/packingtest/Shell/Caddy/updater/Sector/checkerchanges. No additionalmergechase; finalheadmergeability andactualGitHubtestedmerge remainrequired.

Publicationreview: coalescingrender needs actualsourceancestry/finalguards/finalpushedcommit; workflowgreenalonecanmaskresilientbuilderfailures. macro-update serves site.served byper-filersync; comparecanonicalgeneratedHTML/Shell/linkedassets withstablebeforeafterread. Existing canonicalsite injector --check withPython-B is nonwriting; directsite.served has incorrectnestedprefixsemantics, so willnotbeused. Runtime logo_config.js rewrite isintentional. CurrentMOGworkflow usesubuntu-latest; oldguideM2sentenceisstale. Existinglabelowner only, armLAST/no post-armpush/nativeauto. SNI MOGdiscovery aborted771.3s/nooutput/PID, explicitlyunqualified; rootreadexistingguide/workflow. Captureowner supportsanonymous1440x900/820x1180/390x844; inspecteverymanifestcell, exit0canbepartial; noauthcontextreuse. Caddyverifier isisolatedsourceproof, notpublicheaders.

Latesthost04:42: betaA/PID2427329/runtime698204ef/HTTP200, productionPID2336355/build50a8/globalowner6d05. Caddy17aefed exactlyincoming0f05 changedexternally. DNSstillEdgeOne/strictTLShostnamefailure; DNSPodTencentWeChatiframeSiteUnavailable aftersecuremethodchoice. Human sign-inremainsafterindependentMacrodelivery. First-installcontainment/recovery qualifies; previousruntimeNULL/futurebaseline isnotexecutedupgrade rollback.

Precommit/prepushsnapshot; originalPRcheckpointbindseventualcommit/push/head. ProgrammeOPEN: currentheadhostedCI/review, freshbeta/DNSidentity, existingMOG/coveringrender/actualservedproof, thenDNS/TLS/auth/publicnavigation/history/theme/language/nativehandoff/visibleerrors/applicablerecovery. PreserveSectoroverview/map/moving/money/explore/confluence andsector-to-basket, PaperREVISE. C4comments6255134033..6255716294 SPEC_ONLY/UNAPPLIED/UNRUN. HistoricalCSSfixture/currentgeneratedpixels/AboutLIGHTONLY/mobileEN406overflow remainseparate/unaccepted. No duplicatePR/renderer/sourcecarrier/watcher.
''').encode()
old_h=H.read_text();parts=old_h.split('---',2);assert len(parts)==3 and parts[0]==''
fm=yaml.safe_load(parts[1]);body=parts[2]
fm['state_before']='Remote8cc published/contractgreen against73ca. Originalworktree composed92c51 atsourceindex9f468349; exactmeasured5671repair locallyPASS. Newcommit/push/hostedgatesremain. OriginalbetaA recoverycomplete; no retry.'
fm['changed'].append({'path':'.github/ci/legacy-jobs.yml; tests/test_ci_pack.py; same evidence and handoff','what':'Ordinary92c51 merge preservesincomingbond/SECclosure/scorecardstep. Exactly2CI conflictsresolved; actual5671fundsonlyShell7, histories/othergatespreserved.'})
fm['verified'].append({'claim':'Actual92c51composition passes scopedlocalgates aftermeasuredrepair.','command':'Existing4scope/packingnodes; packing-onlyafterexactliteral/historychange; three-way/AST/IDproofs.','result':'3scopePASS; sole5671>5664reproduced; exact5664->5671thenpackingPASS/indexstable. Rows135/5796/10,134/5671/10,128/5545/10. IndependentreviewsNONBLOCKING; newheadhostednotinferred.'})
fm['verified'].append({'claim':'Historical8cc hostedcontract passedonactualtestedmerge.','command':'GitHubjob118461289660/run39371861641 logs/jobmetadata.','result':'0introduced/0inherited against73ca,05:04:39. Authority/fencesPASS; packs2/8/11PASS/restpendingatsnapshot. Doesnotqualifynew92ccomposition.'})
fm['unresolved']=[
'ProgrammeOPEN. Local92c51/sourceindex9f468349 awaitsproofcommit/push/currentheadhostedgates; remotePR7949 remains8cc/unarmed.',
'R93 originalbetaA recovery/runtime/filesystemaccepted. No bootstrap/#859redo. PublicDNS/TLS/auth/browser unaccepted; prearmfreshhealthrequired.',
'DNSPodWeChatiframeSiteUnavailable aftersecuremethodchoice; humanloginboundary. NoDNSmutation/securitygrant/TLSbypass.',
'ActualMOGworkflowubuntu-latest supersedesoldguideM2sentence. ArmexistinglabelLAST; staythroughlandedbytes/coveringrender/servedproof.',
'Sector6views/sector-to-basket preserved; PaperREVISE; C4SPEC_ONLY/UNAPPLIED/UNRUN; historicalpixels/Aboutmobilegapunaccepted.',
'SessionBridgebackend_unavailable exceptionretained; advisersboundedconsultations, notreplacementFabricworkers. IncompleteSNI MOGread unqualified; rootclosedinterface read.'
]
fm['next_actions']=[
'Commit/pushsamebranch/proofpack; inspectactualnewheadhostedCI/review andrepaironlyconcretereds.',
'Refreshbetahealth/DNS/main/testedsurface; armexistingMOG LAST afterfinalgates, no nativeauto/post-armpush.',
'Consumeincumbentcoveringrender andmacro-update generated/servedassets/capabilities/headers; no duplicateowner/watcher.',
'CompleteDNSPodsign-in, reviewedbetaDNS/publicTLS/auth/responsivejourneys/applicablerecovery; persistactualoutcomes inoriginalcheckpoint.'
]
new_h=('---\n'+yaml.safe_dump(fm,sort_keys=False,allow_unicode=True,width=110)+'---'+body).encode()+add
assert new_h.decode().split('---',2)[2]==body+add.decode()
old_readme=(P/'README.md').read_bytes()
keys=['indexed_at','macro_source_head','macro_incoming_main','latest_confirmed_macro_publication','macro_integrated_index_tree_before_proof','documentation_validation','focused_current_composition','publication_of_this_package']
m['previous_frontier_before_92c51']={k:m.get(k) for k in keys}
m.update(indexed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),macro_source_head=r['head'],macro_incoming_main=r['incoming'],latest_confirmed_macro_publication=r['head'],macro_integrated_index_tree_before_proof=r['index'],publication_of_this_package='Precommit/prepush92c51; originalPR7949 checkpoint binds eventualhead. Newheadhostednotyetgreen.')
m['focused_current_composition']={'source_index':r['index'],'incoming':r['incoming'],'scope_passes':3,'packing_exit':0,'packing_receipt':'macro-92c51-packing-after.json','hosted_admission':False}
m['historical_8cc_hosted_contract']={'run_id':39371861641,'job_id':118461289660,'base':'73ca987b5907034653d33cbdae1577a57e67120e','introduced':0,'inherited':0,'head':r['head'],'does_not_qualify_92c51':True}
m['documentation_validation']={'status':'pending beforecommit'}
for dest,payload,row in payloads:
 with (P/dest).open('xb') as f:f.write(payload)
H.write_bytes(new_h);(P/'README.md').write_bytes(old_readme+add);m['files'].extend([row for _,_,row in payloads])
for row in m['files']:
 if row['file']=='README.md':row.update(bytes=len(old_readme+add),sha256=sha(old_readme+add))
m['files'].sort(key=lambda x:x['file']);mp.write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n')
assert len({x['file'] for x in m['files']})==len(m['files']);verify(m['files'])
assert all(row==next(n for n in m['files'] if n['file']==row['file']) for row in old_rows if row['file']!='README.md')
paths=[str((P/dest).relative_to(W)) for dest,_,_ in payloads]+[str((P/'README.md').relative_to(W)),str(mp.relative_to(W)),str(H.relative_to(W))]
g('add','--',*paths);I=g('write-tree');changed=g('diff','--name-only',r['index'],I).splitlines();assert set(changed)==set(paths)
assert not g('diff','--name-only') and not g('ls-files','-u')
out={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_index_before':r['index'],'index_after':I,'old_files':280,'new_files':len(m['files']),'added_files':[row for _,_,row in payloads],'already_identical':already,'all_hashes_and_roundtrips_pass':True,'old_rows_preserved_except_readme':True,'historical_handoff_body_preserved':True,'only_proof_handoff_paths_differ':True,'manifest_sha256':sha(mp.read_bytes()),'handoff_sha256':sha(new_h),'committed':False,'pushed':False}
raw=(json.dumps(out,indent=2)+'\n').encode();dest=E/'macro-92c51-proof-import.json';assert not dest.exists();dest.write_bytes(raw)
print(json.dumps({k:v for k,v in out.items() if k!='added_files'},indent=2));print('receipt_sha256',sha(raw))
