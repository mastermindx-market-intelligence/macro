from pathlib import Path
import subprocess,json,hashlib,datetime,os,sys
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","--no-optional-locks","-C",str(W)]
H="da4df7d1e1ac709055c6fa1d482304a875e81824";M="9875169102cc6f36a64d465fe7c06f6bb8fb0220";OUT=E/"macro-da4d-987-labor-owner-render.json";D=E/"macro-da4d-987-labor-render"/"site"
def git(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert not OUT.exists() and not D.exists()
assert git("rev-parse","HEAD").decode().strip()==H and git("rev-parse","MERGE_HEAD").decode().strip()==M
source_paths=["lib/macro_suite_labels.py","scripts/build_macro_suite_pages.py","scripts/check_macro_command_copy.py","tests/test_macro_command_copy_law.py"]
source={p:(W/p).read_bytes() for p in source_paths}
for p in ["lib/macro_suite_labels.py","tests/test_macro_command_copy_law.py"]:assert source[p]==git("show",H+":"+p),p
data={}
for entry in git("ls-files","--stage","-z","--","site/macrodata").split(b"\0"):
 if not entry:continue
 left,p=entry.split(b"\t",1);mode,blob,stage=left.decode().split();assert stage=="0" and mode=="100644"
 name=p.decode();raw=(W/name).read_bytes();actual=hashlib.sha1(("blob "+str(len(raw))+"\0").encode()+raw).hexdigest();assert actual==blob,name
 data[name]={"bytes":len(raw),"sha256":dg(raw),"git_blob":blob}
os.chdir(W);sys.path.insert(0,str(W))
from scripts import build_macro_suite_pages as builder
from scripts import check_macro_command_copy as guard
stamp=datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
out={"started_at":now(),"head":H,"incoming":M,"owner":"scripts.build_macro_suite_pages.render","source_inputs":{p:{"bytes":len(b),"sha256":dg(b)} for p,b in source.items()},"data_inputs":data,"page_built_at":stamp,"worktree_or_index_written":False,"adopted":False,"state":"PRODUCER_BEGIN"}
def save():OUT.write_text(json.dumps(out,indent=2)+"\n")
save()
pages=builder.render(W,data_root=W/"site/macrodata",out_dir=D,page_built_at=stamp)
out["pages"]=[{"name":p.name,"path":str(p),"bytes":p.stat().st_size,"sha256":dg(p.read_bytes()),"copy_guard":guard.find_violations(p.read_text())} for p in pages]
assert all((W/p).read_bytes()==b for p,b in source.items())
for p,row in data.items():assert dg((W/p).read_bytes())==row["sha256"],p
out.update(source_and_data_unchanged=True,finished_at=now(),state="RENDERED_NOT_ADOPTED",all_copy_guards_pass=all(not r["copy_guard"] for r in out["pages"]));save()
print(json.dumps({"pages":len(out["pages"]),"data_inputs":len(data),"all_copy_guards_pass":out["all_copy_guards_pass"],"labor":next(x for x in out["pages"] if x["name"]=="macro_labor_markets.html"),"adopted":False},indent=2),flush=True)
