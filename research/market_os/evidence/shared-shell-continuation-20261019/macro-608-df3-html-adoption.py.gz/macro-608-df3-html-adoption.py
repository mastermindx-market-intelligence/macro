from pathlib import Path
import subprocess,json,hashlib,datetime,os,sys
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","-C",str(W)];D=E/"macro-608-df3-html-preview";OUT=E/"macro-608-df3-html-adoption.json";BACK=E/"macro-608-df3-html-before-adoption"
H="608dfad299e2e48ab7703bf0b180e0dca1318229";M="df3cba80e5ff43e3411209381b32d9d4df06bd1f";B="9875169102cc6f36a64d465fe7c06f6bb8fb0220"
def git(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def ident(p):
 b=(W/p).read_bytes();return {"bytes":len(b),"sha256":dg(b)}
assert not OUT.exists() and not BACK.exists()
assert git("rev-parse","HEAD").decode().strip()==H and git("rev-parse","MERGE_HEAD").decode().strip()==M
source=json.loads((E/"macro-608-df3-source-conflict-resolution.json").read_text());assert source["state"]=="THREE_SOURCE_CONFLICTS_RESOLVED_STAGED_MEASUREMENT_PENDING"
preview=json.loads((D/"receipt.json").read_text());labor=json.loads((E/"macro-608-df3-labor-owner-render.json").read_text())
assert preview["all_clean"] and preview["head"]==H and preview["incoming"]==M and len(preview["rows"])==2
assert labor["state"]=="RENDERED_NOT_ADOPTED" and labor["all_copy_guards_pass"] and labor["source_and_data_unchanged"]
for p,r in {**labor["source_inputs"],**labor["data_inputs"]}.items():assert ident(p)=={k:r[k] for k in ["bytes","sha256"]},p
for a in preview["assets"]:
 assert ident(a["path"])=={k:a[k] for k in ["bytes","sha256"]} and git("rev-parse",":"+a["path"]).decode().strip()==a["git_blob"],a["path"]
selected=[r["path"] for r in preview["rows"]]+["site/macro_labor_markets.html"]
assert set(git("diff","--name-only","--diff-filter=U").decode().splitlines())==set(selected)
for p in selected:
 for stage,rev in [("1",B),("2",H),("3",M)]:assert git("rev-parse",":"+stage+":"+p)==git("rev-parse",rev+":"+p)
os.chdir(W);sys.path.insert(0,str(W))
from lib.pages import write_page,inject_text,dbase_prefix
from lib.shared_shell import inject_shared_shell_text
from scripts.optimize_assets import make_optimizer
from scripts.check_macro_command_copy import find_violations
opt=make_optimizer(W/"site")
def final(text,p):
 q=W/p;prefix=dbase_prefix(q);return opt(inject_shared_shell_text(inject_text(text,prefix),prefix,site_dir=W/"site"),q.parent)
candidates={}
for row in preview["rows"]:
 raw=Path(row["candidate"]).read_bytes();assert len(raw)==row["candidate_bytes"] and dg(raw)==row["candidate_sha256"]
 for v in row["parents"].values():assert dg(Path(v["file"]).read_bytes())==v["canonical_sha256"]
 assert "<<"+"<<<<< " not in raw.decode() and final(raw.decode(),row["path"])==raw.decode()
 candidates[row["path"]]=raw
lp=next(x for x in labor["pages"] if x["name"]=="macro_labor_markets.html");raw=Path(lp["path"]).read_bytes();assert dg(raw)==lp["sha256"];candidates["site/macro_labor_markets.html"]=final(raw.decode(),"site/macro_labor_markets.html").encode();assert not find_violations(candidates["site/macro_labor_markets.html"].decode())
out={"started_at":now(),"head":H,"incoming":M,"base":B,"state":"PREFLIGHT_PASS","preview_sha256":dg((D/"receipt.json").read_bytes()),"selected":selected,"rows":[]}
def save():OUT.write_text(json.dumps(out,indent=2)+"\n")
save();BACK.mkdir()
for p in selected:
 raw=(W/p).read_bytes();f=BACK/p.replace("/","_");f.write_bytes(raw);out["rows"].append({"path":p,"before_sha256":dg(raw),"backup":str(f),"candidate_bytes":len(candidates[p]),"candidate_sha256":dg(candidates[p])})
save()
for p in selected:
 q=W/p;write_page(q,candidates[p].decode(),encoding="utf-8");q.write_text(opt(q.read_text(),q.parent),encoding="utf-8");assert q.read_bytes()==candidates[p],p
for p,r in preview["source_owners"].items():assert ident(p)=={k:r[k] for k in ["bytes","sha256"]},p
for a in preview["assets"]:assert ident(a["path"])=={k:a[k] for k in ["bytes","sha256"]},a["path"]
subprocess.run(G+["add","--",*selected],check=True)
for p in selected:assert git("show",":"+p)==candidates[p]
out.update(state="ADOPTED_STAGED",finished_at=now(),index_tree=git("write-tree").decode().strip(),remaining_unmerged=git("diff","--name-only","--diff-filter=U").decode().splitlines(),unstaged=git("diff","--name-only").decode().splitlines());save();print(json.dumps(out,indent=2))
