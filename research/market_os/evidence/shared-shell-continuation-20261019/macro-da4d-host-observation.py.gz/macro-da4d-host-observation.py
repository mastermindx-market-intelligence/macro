from pathlib import Path
import subprocess,json,hashlib,datetime,sys
E=Path("/tmp/shared-shell-css-visual-20261019T1107");W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27")
stem="macro-da4d-host-observation";P=E/"macro-b312-prearm-health-remote-v3.py";raw=P.read_bytes()
sha=hashlib.sha256(raw).hexdigest();assert sha=="ae53acf844cca7a86559643ba26d2b9a7db29d6d01f59093a6dc1fbd2acda21e"
assert subprocess.check_output(["git","-C",str(W),"rev-parse","HEAD"],text=True).strip()=="da4df7d1e1ac709055c6fa1d482304a875e81824"
OUT=E/(stem+".json");assert not OUT.exists()
cmd=["ssh","-i","/Users/chriswong/.ssh/macro_dashboard_deploy_v2","-o","BatchMode=yes","-o","StrictHostKeyChecking=yes","root@146.190.142.17","python3 -B -"]
r={"started_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"observer":str(P),"observer_bytes":len(raw),"observer_sha256":sha,"macro_local_head":"da4df7d1e1ac709055c6fa1d482304a875e81824","scope":"read-only sampled continuity and owner/hold evidence; not MOG arm or reservation","command":cmd}
with (E/(stem+".stdout.json")).open("xb") as out,(E/(stem+".stderr.log")).open("xb") as err:
 p=subprocess.run(cmd,input=raw,stdout=out,stderr=err,timeout=120)
r.update(remote_exit=p.returncode,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
for name in ("stdout.json","stderr.log"):
 b=(E/(stem+"."+name)).read_bytes();r[name]={"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}
OUT.write_text(json.dumps(r,indent=2)+"\n");print(json.dumps(r,indent=2),flush=True)
if p.returncode==0:
 x=json.loads((E/(stem+".stdout.json")).read_text())
 print(json.dumps({"observed_at":x["observed_at"],"finished_at":x["finished_at"],"release_samples":{k:{"clear":x[k]["sample_clear"],"lock":x[k]["lock"],"processes":x[k]["processes"]} for k in ("release_before","release_after")},"services":x["services"],"runtime_pointer":x["runtime_pointer"],"source_pointer":x["source_pointer"],"status":x["status"],"production_after":x["production_after"],"pending_exists":x["pending_exists"],"stages":x["beta_stages"],"free":x["free_bytes"]},indent=2),flush=True)
sys.exit(p.returncode)
