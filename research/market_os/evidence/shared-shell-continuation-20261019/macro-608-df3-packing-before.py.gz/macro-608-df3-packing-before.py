from __future__ import annotations

import ast
from copy import deepcopy
import errno
import importlib.util
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
from types import SimpleNamespace
from pathlib import Path

import pytest

from scripts import audit_unrun_tests as AUDIT
from scripts import ci_scope_dependencies as DEPS
from scripts.ci_scope_dependencies import suite_dependency_closure
# Plain package import (not the importlib-from-path PACK below) so this test and
# scripts/check_contract_delta.py's own import of the same names resolve to the
# identical `scripts.run_ci_pack` module object — see
# test_curated_exclusive_closure_findings_is_the_shared_implementation in
# tests/test_contract_delta.py, which pins that identity.
from scripts.run_ci_pack import (
    curated_exclusive_closure_findings,
    inferred_as_if_not_exclusive,
    packing_probe_breaches,
    packing_probe_measurements,
)
import yaml


ROOT = Path(__file__).resolve().parents[1]
WORKFLOW = ROOT / ".github" / "workflows" / "ci.yml"
MANIFEST = ROOT / ".github" / "ci" / "legacy-jobs.yml"
FENCES = ROOT / ".github" / "workflows" / "fences.yml"

# A `ci-trigger-closure: data` marker on a path in this file flags a NAME that a test
# hands to the planner: a select_jobs() diff, a closure-membership assert, a fake
# manifest's paths. The test never reads that file itself, so
# check_ci_trigger_closure.py, which gates direct reads only, must not demand it
# among ci-control-plane-contracts' paths. The planner is another matter. A test
# that runs it over the real tree (infer_job_scopes on MANIFEST,
# suite_dependency_closure on a real suite) parses every suite and import chain it
# reaches, so its verdict depends on the whole tree, and no exclusive paths list
# can name the whole tree. The job's note in .github/ci/legacy-jobs.yml says where
# that residual is caught.

SPEC = importlib.util.spec_from_file_location(
    "run_ci_pack", ROOT / "scripts" / "run_ci_pack.py"
)
assert SPEC and SPEC.loader
PACK = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = PACK
SPEC.loader.exec_module(PACK)


def _yaml(path: Path) -> dict:
    return yaml.safe_load(path.read_text())


def _closure_of(source: str) -> SimpleNamespace:
    """Classify a synthetic module the way the selector classifies a real one.

    ``_source_ambiguities`` reads the parsed tree and uses the path only to label
    findings, so a probe needs no file on disk — and must not leave one behind in
    a checkout the pack runner hard-resets between jobs.
    """
    import ast

    from scripts import ci_scope_dependencies as DEPS

    findings = DEPS._source_ambiguities(
        ROOT / "engine" / "_ci_scope_probe.py", ast.parse(source)
    )
    return SimpleNamespace(ambiguities=tuple(sorted(findings)))


def _manifest_scope_reader(manifest: Path):
    """Lazily snapshot one immutable test manifest; never share mutable results.

    This is test setup only, scoped to one reader in one pytest process. The
    production planner and synthetic/mutating planner tests keep recomputing.
    A new reader (including a new pytest invocation) reads the source afresh.
    Exceptions propagate; a failed derivation never becomes an empty snapshot.
    """
    snapshot = None

    def read():
        nonlocal snapshot
        if snapshot is None:
            snapshot = PACK.infer_job_scopes(PACK.load_legacy_jobs(manifest))
        return deepcopy(snapshot)

    return read


@pytest.fixture(scope="module")
def _real_manifest_scope_reader():
    # Construction is deliberately lazy: function-level environment isolation
    # must run before the first real derivation, not after a module fixture.
    return _manifest_scope_reader(MANIFEST)


@pytest.fixture
def real_manifest_scopes(_real_manifest_scope_reader, _isolate_pack_runner_planner_env):
    # Every opted-in assertion receives its own list, LegacyJobs and nested
    # definition dictionaries. It cannot poison another test's scope snapshot.
    return _real_manifest_scope_reader()


def _scope_reader_probe_manifest(tmp_path: Path, job_id: str) -> Path:
    manifest = tmp_path / "scope-reader.yml"
    manifest.write_text(yaml.safe_dump({"jobs": {job_id: {
        "if": PACK.DISABLED_IF,
        "runs-on": "ubuntu-latest",
        "steps": [{"name": "scope reader fixture", "run": "echo fixture"}],
    }}}), encoding="utf-8")
    return manifest


def test_manifest_scope_reader_is_lazy_and_derives_once(tmp_path, monkeypatch):
    monkeypatch.setattr(AUDIT, "ROOT", tmp_path)
    monkeypatch.setattr(DEPS, "ROOT", tmp_path)
    manifest = _scope_reader_probe_manifest(tmp_path, "fixture")
    actual_inference = PACK.infer_job_scopes
    calls = []

    def measured(jobs):
        result = actual_inference(jobs)
        calls.append(result)
        return result

    monkeypatch.setattr(PACK, "infer_job_scopes", measured)
    reader = _manifest_scope_reader(manifest)
    assert calls == [], "module fixture construction must not infer before env isolation"
    first, second = reader(), reader()
    assert len(calls) == 1
    assert first == second
    assert [job.job_id for job in first[0]] == ["fixture"]


def test_manifest_scope_reader_returns_deeply_isolated_jobs(tmp_path, monkeypatch):
    monkeypatch.setattr(AUDIT, "ROOT", tmp_path)
    monkeypatch.setattr(DEPS, "ROOT", tmp_path)
    reader = _manifest_scope_reader(_scope_reader_probe_manifest(tmp_path, "fixture"))
    first, second = reader(), reader()
    assert first == second
    assert first[0] is not second[0]
    assert first[0][0] is not second[0][0]
    assert first[0][0].definition is not second[0][0].definition
    first[0][0].definition["steps"][0]["run"] = "echo poisoned"
    first[0].clear()
    assert reader() == second
    assert second[0][0].definition["steps"][0]["run"] == "echo fixture"


def test_new_manifest_scope_reader_reads_changed_source(tmp_path, monkeypatch):
    monkeypatch.setattr(AUDIT, "ROOT", tmp_path)
    monkeypatch.setattr(DEPS, "ROOT", tmp_path)
    manifest = _scope_reader_probe_manifest(tmp_path, "before")
    original = _manifest_scope_reader(manifest)
    assert original()[0][0].job_id == "before"
    _scope_reader_probe_manifest(tmp_path, "after")
    fresh = _manifest_scope_reader(manifest)
    assert fresh()[0][0].job_id == "after"
    assert original()[0][0].job_id == "before"


def test_manifest_scope_reader_propagates_invalid_source(tmp_path, monkeypatch):
    monkeypatch.setattr(AUDIT, "ROOT", tmp_path)
    monkeypatch.setattr(DEPS, "ROOT", tmp_path)
    manifest = _scope_reader_probe_manifest(tmp_path, "fixture")
    manifest.write_text("jobs: [broken", encoding="utf-8")
    reader = _manifest_scope_reader(manifest)
    with pytest.raises(PACK.ManifestError):
        reader()
    _scope_reader_probe_manifest(tmp_path, "repaired")
    assert reader()[0][0].job_id == "repaired"


def test_all_legacy_jobs_are_disabled_and_packable() -> None:
    jobs = PACK.load_legacy_jobs(MANIFEST)
    assert len(jobs) >= 86
    assert all(job.definition["if"] == PACK.DISABLED_IF for job in jobs)


def test_every_real_legacy_job_declares_its_gate() -> None:
    """Every job in the real manifest says which tree moves its verdict.

    The loader defaults an ABSENT `gate:` to "code" so synthetic fixtures keep
    working (and so nothing can leave the merge gate silently), but the real
    manifest must declare the field on every job: the code/data split is the
    W1 deliverable of research/CI_MERGE_GATE_RELIABILITY_ROOT_CAUSE_2026_08_19.md
    and an undeclared job is an unclassified one, not a classified-by-default
    one.
    """
    jobs = PACK.load_legacy_jobs(MANIFEST)
    undeclared = sorted(job.job_id for job in jobs if "gate" not in job.definition)
    assert not undeclared, (
        "legacy jobs without an explicit gate declaration: "
        + ", ".join(undeclared)
    )
    assert all(job.gate in PACK.GATE_VALUES for job in jobs)


def test_invalid_gate_value_fails_closed(tmp_path: Path) -> None:
    workflow = tmp_path / "ci.yml"
    workflow.write_text(
        """
jobs:
  ci-pack:
    runs-on: ubuntu-latest
    steps:
      - run: echo pack
  typo:
    if: ${{ false }}
    runs-on: ubuntu-latest
    gate: dtaa
    steps:
      - run: echo typo
"""
    )
    with pytest.raises(PACK.ManifestError, match="gate must be one of code/data"):
        PACK.load_legacy_jobs(workflow)


def test_absent_gate_defaults_to_code_never_data(tmp_path: Path) -> None:
    """An undeclared job stays a merge precondition — fail-closed direction."""
    workflow = tmp_path / "ci.yml"
    workflow.write_text(
        """
jobs:
  ci-pack:
    runs-on: ubuntu-latest
    steps:
      - run: echo pack
  bare:
    if: ${{ false }}
    runs-on: ubuntu-latest
    steps:
      - name: bare step
        proof_id: bare-step
        run: echo bare
"""
    )
    (job,) = PACK.load_legacy_jobs(workflow)
    assert job.gate == "code"


def test_two_packs_are_complete_disjoint_and_balanced() -> None:
    jobs = PACK.load_legacy_jobs(MANIFEST)
    packs = PACK.partition_jobs(jobs, 2)
    flattened = [job.job_id for pack in packs for job in pack]
    assert sorted(flattened) == sorted(job.job_id for job in jobs)
    assert len(flattened) == len(set(flattened))

    weights = [sum(job.weight for job in pack) for pack in packs]
    assert max(weights) - min(weights) <= max(job.weight for job in jobs)


def test_legacy_expressions_are_supported() -> None:
    for job in PACK.load_legacy_jobs(MANIFEST):
        for step in job.definition["steps"]:
            if "run" not in step:
                continue
            rendered = PACK.render_command(
                str(step["run"]), base_ref="main", head_ref="claude/example"
            )
            assert "${{" not in rendered


def test_unknown_job_semantics_fail_closed(tmp_path: Path) -> None:
    workflow = tmp_path / "ci.yml"
    workflow.write_text(
        """
jobs:
  ci-pack:
    runs-on: ubuntu-latest
    steps:
      - run: echo pack
  unsafe:
    if: ${{ false }}
    runs-on: ubuntu-latest
    services:
      db:
        image: postgres
    steps:
      - run: echo unsafe
"""
    )
    with pytest.raises(PACK.ManifestError, match="unsupported keys: services"):
        PACK.load_legacy_jobs(workflow)


def test_execute_refuses_to_clean_a_developer_checkout(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("GITHUB_ACTIONS", raising=False)
    monkeypatch.delenv("GITHUB_WORKSPACE", raising=False)
    with pytest.raises(RuntimeError, match="only inside GitHub Actions"):
        PACK._workspace_root()


def test_execution_restores_workspace_between_legacy_jobs(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo = tmp_path / "checkout"
    repo.mkdir()
    workflow = repo / "ci.yml"
    workflow.write_text(
        """
jobs:
  ci-pack:
    runs-on: ubuntu-latest
    steps:
      - run: echo pack
  first:
    if: ${{ false }}
    runs-on: ubuntu-latest
    steps:
      - name: create the leak fixture
        run: printf leak > leaked.tmp
  second:
    if: ${{ false }}
    runs-on: ubuntu-latest
    steps:
      - name: prove the checkout was restored
        run: test ! -e leaked.tmp
"""
    )
    subprocess.run(["git", "init"], cwd=repo, check=True, capture_output=True)
    subprocess.run(
        ["git", "config", "user.email", "ci-pack@example.invalid"],
        cwd=repo,
        check=True,
    )
    subprocess.run(
        ["git", "config", "user.name", "CI Pack Test"], cwd=repo, check=True
    )
    subprocess.run(["git", "add", "ci.yml"], cwd=repo, check=True)
    subprocess.run(
        ["git", "commit", "-m", "fixture"], cwd=repo, check=True, capture_output=True
    )

    monkeypatch.chdir(repo)
    monkeypatch.setenv("GITHUB_ACTIONS", "true")
    monkeypatch.setenv("GITHUB_WORKSPACE", str(repo))
    monkeypatch.setenv("RUNNER_TEMP", str(tmp_path / "runner-temp"))
    jobs = PACK.load_legacy_jobs(workflow)
    assert PACK.execute_pack(jobs) == 0
    assert not (repo / "leaked.tmp").exists()


def test_workflows_cancel_superseded_pr_runs() -> None:
    """PR runs coalesce by cancel; MAIN proofs must be allowed to conclude.

    THE 2026-08-09 BASELINE LIVELOCK — a flat `cancel-in-progress: true` on these two
    workflows made main's CI proof structurally unreachable, and 12 merge-blocked +
    56 cap-deferred pull requests could not drain (sweep run 31311549150, 11:44:42Z:
    "0 main commit(s) classified … main proof: NO clean name at unknown-sha").

      ci.yml has no `push` trigger, so main is proven ONLY by a workflow_dispatch,
      and every main-ref dispatch shares `ci-refs/heads/main`. Each pinned session
      re-firing the documented `gh workflow run ci.yml --ref main` lever therefore
      KILLED the proof already running: 31309720615 cancelled at 44 minutes by
      31311537537, itself cancelled 4 minutes later by 31311693575.

      fences.yml is the OTHER proof merge_on_green reads, and the only one that
      triggers on push to main — but main takes a wire/nightly push every ~30-90s,
      and each one cancelled its predecessor (5 runs between 11:40:38Z and
      11:43:04Z). All ten runs in the sweeper's walk were `cancelled`. A run longer
      than the gap between pushes can NEVER conclude.

    So the expressions below are load-bearing, not stylistic. Reverting either to a
    flat `true` re-closes the sweeper's base-inherited-red refresh and re-pins the
    whole fleet — if this test is what is in your way, you are removing the fix.
    Dedup is NOT what the expressions cost: GitHub replaces the single PENDING run
    per group regardless of the flag, so bursts still collapse; only the kill is gone.
    """
    ci = _yaml(WORKFLOW)
    fences = _yaml(FENCES)
    # PR events keep cancel-on-newer-push. Dispatches (ci) and main pushes (fences)
    # do not — those are the two proof paths.
    assert ci["concurrency"]["cancel-in-progress"] == (
        "${{ github.event_name != 'workflow_dispatch' }}"
    ), "a main baseline dispatch must never cancel the proof already running"
    assert fences["concurrency"]["cancel-in-progress"] == (
        "${{ github.event_name == 'pull_request' }}"
    ), "a push to main must never cancel the fence run proving an earlier main SHA"
    assert "pull_request.number" in ci["concurrency"]["group"]
    assert "github.ref" in ci["concurrency"]["group"]
    assert "pull_request.number" in fences["concurrency"]["group"]
    assert ci["concurrency"]["group"] == (
        "ci-${{ github.event.pull_request.number || github.ref }}"
    )
    triggers = ci.get("on") or ci.get(True)
    assert triggers["pull_request"]["types"] == [
        "opened", "synchronize", "reopened"
    ], "a closed event must never occupy or replace the active PR proof slot"
    assert "merged" not in ci["concurrency"]["group"]
    assert "github.event.action" not in ci["concurrency"]["group"]


def test_scope_glob_separator_semantics() -> None:
    """`*` must not cross `/`, or a one-directory scope silently covers a subtree."""
    match = lambda pattern, path: bool(  # noqa: E731
        PACK._glob_to_regex(pattern).match(path)
    )
    assert match("engine/*", "engine/a.py")
    assert not match("engine/*", "engine/a/b.py")
    assert match("engine/**", "engine/a/b.py")
    assert match("engine/", "engine/a/b.py")
    assert match("tests/test_x*.py", "tests/test_xy.py")
    assert not match("tests/test_x*.py", "tests/test_y.py")
    assert match("**/conftest.py", "tests/conftest.py")
    assert match("**/conftest.py", "conftest.py")



def _manifest_job(run: str, *, gate: str = "code") -> dict:
    return {
        "if": PACK.DISABLED_IF,
        "gate": gate,
        "runs-on": "ubuntu-latest",
        "steps": [{"name": "contract", "run": run}],
    }


def test_manifest_job_local_delta_is_bounded_to_changed_job() -> None:
    base = {
        "jobs": {
            "owner": _manifest_job(
                "python -m pytest tests/test_existing.py -q"
            ),
            "other": _manifest_job(
                "python -m pytest tests/test_other.py -q"
            ),
        }
    }
    candidate = {
        "jobs": {
            "owner": _manifest_job(
                "python -m pytest tests/test_existing.py tests/test_new.py -x"
            ),
            "other": _manifest_job(
                "python -m pytest tests/test_other.py -q"
            ),
        }
    }

    assert PACK._classify_bounded_manifest_job_delta(
        base, candidate
    ) == ("owner",)


def test_manifest_multiple_job_local_deltas_are_all_forced() -> None:
    base = {
        "jobs": {
            "first": _manifest_job(
                "python -m pytest tests/test_first.py -q"
            ),
            "second": _manifest_job(
                "python -m pytest tests/test_second.py -q"
            ),
            "third": _manifest_job(
                "python -m pytest tests/test_third.py -q"
            ),
        }
    }
    candidate = {
        "jobs": {
            "first": _manifest_job(
                "python -m pytest tests/test_first.py tests/test_new.py -q"
            ),
            "second": _manifest_job(
                "python -m pytest tests/test_second.py -x"
            ),
            "third": _manifest_job(
                "python -m pytest tests/test_third.py -q"
            ),
        }
    }

    assert PACK._classify_bounded_manifest_job_delta(
        base, candidate
    ) == ("first", "second")


def test_manifest_semantic_noop_is_positive_bounded_evidence() -> None:
    document = {
        "jobs": {
            "owner": _manifest_job(
                "python -m pytest tests/test_existing.py -q"
            ),
        }
    }
    assert PACK._classify_bounded_manifest_job_delta(
        document, document
    ) == ()


def test_manifest_job_delta_rejects_topology_gate_and_top_level_changes() -> None:
    base = {
        "jobs": {
            "owner": _manifest_job(
                "python -m pytest tests/test_existing.py -q"
            ),
        }
    }
    changed_gate = {
        "jobs": {
            "owner": _manifest_job(
                "python -m pytest tests/test_existing.py tests/test_new.py -q",
                gate="data",
            ),
        }
    }
    added_job = {
        "jobs": {
            **base["jobs"],
            "new-owner": _manifest_job(
                "python -m pytest tests/test_new.py -q"
            ),
        }
    }
    deleted_job = {"jobs": {}}
    extra_top_level = {**base, "defaults": {"timeout": 10}}

    assert PACK._classify_bounded_manifest_job_delta(
        base, changed_gate
    ) is None
    assert PACK._classify_bounded_manifest_job_delta(
        base, added_job
    ) == ("new-owner",)
    assert PACK._classify_bounded_manifest_job_delta(
        base, deleted_job
    ) is None
    assert PACK._classify_bounded_manifest_job_delta(
        base, extra_top_level
    ) is None


def test_safe_manifest_job_delta_uses_canonical_trusted_repo_root(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo = tmp_path / "candidate"
    manifest = repo / PACK.LEGACY_MANIFEST_PATH
    manifest.parent.mkdir(parents=True)
    base = {
        "jobs": {
            "owner": _manifest_job(
                "python -m pytest tests/test_existing.py -q"
            ),
        }
    }
    manifest.write_text(yaml.safe_dump(base, sort_keys=False))
    subprocess.run(["git", "init"], cwd=repo, check=True, capture_output=True)
    subprocess.run(
        ["git", "config", "user.email", "ci@example.invalid"],
        cwd=repo,
        check=True,
    )
    subprocess.run(
        ["git", "config", "user.name", "CI Test"],
        cwd=repo,
        check=True,
    )
    subprocess.run(["git", "add", "."], cwd=repo, check=True)
    subprocess.run(
        ["git", "commit", "-m", "base"],
        cwd=repo,
        check=True,
        capture_output=True,
    )
    base_sha = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=repo,
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()
    candidate = {
        "jobs": {
            "owner": _manifest_job(
                "python -m pytest tests/test_existing.py tests/test_new.py -q"
            ),
        }
    }
    manifest.write_text(yaml.safe_dump(candidate, sort_keys=False))

    monkeypatch.setattr(AUDIT, "ROOT", repo)

    assert PACK._safe_manifest_changed_job_ids(
        manifest,
        base_sha,
    ) == ("owner",)


def test_copied_trusted_control_plans_manifest_delta_against_candidate_root(
    tmp_path: Path,
) -> None:
    candidate = tmp_path / "candidate"
    candidate.mkdir()
    manifest = candidate / PACK.LEGACY_MANIFEST_PATH
    manifest.parent.mkdir(parents=True)
    tests_dir = candidate / "tests"
    tests_dir.mkdir()
    (tests_dir / "test_existing.py").write_text(
        "def test_existing():\n    assert True\n",
        encoding="utf-8",
    )
    (tests_dir / "test_other.py").write_text(
        "def test_other():\n    assert True\n",
        encoding="utf-8",
    )
    base_document = {
        "jobs": {
            "owner": _manifest_job(
                "python -m pytest tests/test_existing.py -q"
            ),
            "other": _manifest_job(
                "python -m pytest tests/test_other.py -q"
            ),
        }
    }
    manifest.write_text(yaml.safe_dump(base_document, sort_keys=False))
    subprocess.run(["git", "init"], cwd=candidate, check=True, capture_output=True)
    subprocess.run(
        ["git", "config", "user.email", "ci@example.invalid"],
        cwd=candidate,
        check=True,
    )
    subprocess.run(
        ["git", "config", "user.name", "CI Test"],
        cwd=candidate,
        check=True,
    )
    subprocess.run(["git", "add", "."], cwd=candidate, check=True)
    subprocess.run(
        ["git", "commit", "-m", "base"],
        cwd=candidate,
        check=True,
        capture_output=True,
    )
    base_sha = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=candidate,
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()

    candidate_document = {
        "jobs": {
            "owner": _manifest_job(
                "python -m pytest tests/test_existing.py tests/test_new.py -q"
            ),
            "other": _manifest_job(
                "python -m pytest tests/test_other.py -q"
            ),
        }
    }
    manifest.write_text(yaml.safe_dump(candidate_document, sort_keys=False))
    (tests_dir / "test_new.py").write_text(
        "def test_new():\n    assert True\n",
        encoding="utf-8",
    )
    subprocess.run(["git", "add", "."], cwd=candidate, check=True)
    subprocess.run(
        ["git", "commit", "-m", "candidate"],
        cwd=candidate,
        check=True,
        capture_output=True,
    )
    head_sha = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=candidate,
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()

    control = tmp_path / "trusted-ci-control"
    control_scripts = control / "scripts"
    control_scripts.mkdir(parents=True)
    for filename in (
        "__init__.py",
        "run_ci_pack.py",
        "ci_semantic_proof.py",
        "ci_authority_paths.py",
        "ci_scope_dependencies.py",
        "audit_unrun_tests.py",
        "workflow_run_source.py",
    ):
        (control_scripts / filename).write_bytes(
            (ROOT / "scripts" / filename).read_bytes()
        )

    plan_path = tmp_path / "plan.json"
    environment = dict(os.environ)
    environment["PYTHONPATH"] = str(control)
    environment["MASTERMIND_TRUSTED_CI_REPO_ROOT"] = str(candidate)
    result = subprocess.run(
        [
            sys.executable,
            str(control_scripts / "run_ci_pack.py"),
            "--workflow",
            ".github/ci/legacy-jobs.yml",
            "--gate",
            "code",
            "--pack-count",
            "12",
            "--changed-from",
            base_sha,
            "--scope-mode",
            "active",
            "--plan-only",
            "--emit-plan-json",
            str(plan_path),
            "--workflow-run-id",
            "trusted-root-regression",
            "--workflow-name",
            "ci",
            "--event",
            "pull_request",
            "--role",
            "pr_head",
            "--tested-tree-sha",
            head_sha,
            "--subject-head-sha",
            head_sha,
            "--base-sha",
            base_sha,
        ],
        cwd=candidate,
        env=environment,
        text=True,
        capture_output=True,
        check=False,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    assert "bounded manifest job delta" in plan["reason"], plan
    assert "full suite" not in plan["reason"], plan
    assert plan["eligible_jobs"] == ["owner"], plan
    assert plan["nonempty_pack_indices"] == [0], plan


def test_manifest_job_reorder_or_rename_still_fails_closed() -> None:
    base = {
        "jobs": {
            "first": _manifest_job("python -m pytest tests/test_first.py -q"),
            "second": _manifest_job("python -m pytest tests/test_second.py -q"),
        }
    }
    reordered = {
        "jobs": {
            "second": base["jobs"]["second"],
            "first": base["jobs"]["first"],
        }
    }
    renamed = {
        "jobs": {
            "first": base["jobs"]["first"],
            "second-renamed": base["jobs"]["second"],
        }
    }

    assert PACK._classify_bounded_manifest_job_delta(
        base, reordered
    ) is None
    assert PACK._classify_bounded_manifest_job_delta(
        base, renamed
    ) is None


def test_safe_manifest_job_delta_reads_the_exact_base_commit(
    tmp_path: Path,
) -> None:
    repo = tmp_path / "repo"
    manifest = repo / PACK.LEGACY_MANIFEST_PATH
    manifest.parent.mkdir(parents=True)
    base = {
        "jobs": {
            "owner": _manifest_job(
                "python -m pytest tests/test_existing.py -q"
            ),
        }
    }
    manifest.write_text(yaml.safe_dump(base, sort_keys=False))
    subprocess.run(["git", "init"], cwd=repo, check=True, capture_output=True)
    subprocess.run(
        ["git", "config", "user.email", "ci@example.invalid"],
        cwd=repo,
        check=True,
    )
    subprocess.run(
        ["git", "config", "user.name", "CI Test"],
        cwd=repo,
        check=True,
    )
    subprocess.run(["git", "add", "."], cwd=repo, check=True)
    subprocess.run(["git", "commit", "-m", "base"], cwd=repo, check=True, capture_output=True)
    base_sha = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=repo,
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()

    candidate = {
        "jobs": {
            "owner": _manifest_job(
                "python -m pytest tests/test_existing.py tests/test_new.py -x"
            ),
        }
    }
    manifest.write_text(yaml.safe_dump(candidate, sort_keys=False))

    assert PACK._safe_manifest_changed_job_ids(
        manifest,
        base_sha,
        repo_root=repo,
    ) == ("owner",)
    assert PACK._safe_manifest_changed_job_ids(
        manifest,
        "not-an-exact-sha",
        repo_root=repo,
    ) is None


def test_selection_fails_safe_toward_running_everything(real_manifest_scopes) -> None:
    """Unknown changed-sets and global invalidators still widen; unowned paths do not.

    A wasted runner-minute is cheap; a false green on a control-plane file is
    not. The two remaining wideners are the only ways scoping can be unknowable
    rather than merely unowned. An unowned path used to be a third widener and
    that was the speed hole: one hook file ran all 185 jobs (PR #5488).
    """
    jobs, summary = real_manifest_scopes
    scoped = [job for job in jobs if job.paths]
    assert len(scoped) >= 25, summary

    # 1. changed set unknowable (git failed, or main's baseline passes no ref)
    assert len(PACK.select_jobs(jobs, None)[0]) == len(jobs)
    # 2. a global invalidator can change what ANY job means
    for invalidator in ("scripts/run_ci_pack.py", "tests/conftest.py",
                        "requirements.txt", "worker/requirements-dev.txt",
                        "config/dag.yml", "config/synapse.yml",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
                        ".github/ci/legacy-jobs.yml"):
        selected, reason = PACK.select_jobs(jobs, [invalidator])
        assert len(selected) == len(jobs), f"{invalidator} must force a full run"
        assert "full suite" in reason
    # 3. an unowned path stays on always-on fences; it does not mint a full suite
    selected, reason = PACK.select_jobs(jobs, ["no/such/path/at/all.txt"])
    assert len(selected) < len(jobs), reason
    assert "did not widen" in reason
    # `is_scoped`, not `paths`: after the #5586 tier split a job can be scoped
    # entirely by opaque `fallback_paths`, and such a job is NOT always-on.
    unscoped = [job for job in jobs if not job.is_scoped]
    for job in unscoped:
        assert job in selected, f"always-on {job.job_id} must still run"
    # 4. a scoped job runs whenever its own scope matches
    for job in scoped:
        probe = job.paths[0].replace("**/", "").replace("**", "x").replace("*", "x")
        hit, _ = PACK.select_jobs(jobs, [probe])
        assert job in hit, f"{job.job_id} must run when {probe} changes"


def test_declared_scope_must_cover_paths_the_job_itself_reads() -> None:
    """A scope narrower than the job's own commands is a hard manifest error.

    This is what makes scoping reviewable instead of trusted: a job that runs
    `pytest tests/test_x.py` but scopes itself elsewhere would never re-run when
    that test changed, and would report green forever.
    """
    findings = PACK._scope_coverage_findings(
        "demo",
        {"steps": [{"run": "python -m pytest tests/test_ci_pack.py"}]},
        ("engine/nowhere/**",),
    )
    assert findings and "tests/test_ci_pack.py" in findings[0]
    # Widening to cover it clears the finding.
    assert not PACK._scope_coverage_findings(
        "demo",
        {"steps": [{"run": "python -m pytest tests/test_ci_pack.py"}]},
        ("tests/**",),
    )
    # A path that no longer exists must not be able to fail the build.
    assert not PACK._scope_coverage_findings(
        "demo",
        {"steps": [{"run": "python -m pytest tests/test_deleted_long_ago.py"}]},
        ("engine/nowhere/**",),
    )


def test_every_declared_scope_in_the_real_manifest_is_covered() -> None:
    """The production manifest itself must satisfy the coverage rule."""
    PACK.load_legacy_jobs(MANIFEST)  # raises ManifestError on any gap


def test_real_manifest_has_non_vacuous_derived_scopes(real_manifest_scopes) -> None:
    """The mechanism shipped with 0/179 owners; the 180-job manifest must stay live."""
    jobs, summary = real_manifest_scopes
    scoped = {job.job_id: set(job.paths) for job in jobs if job.paths}
    assert len(scoped) >= 25, summary
    assert "unrun-government-revenue-candidate-projection" in scoped
    assert "stock-seasonality" in scoped
    assert "synapse-read-gate" in scoped
    assert "falsifier-tripwires" in scoped
    assert "tests/test_falsifier_tripwires.py" in scoped["falsifier-tripwires"]
    assert "engine/falsifier_tripwires.py" in scoped["falsifier-tripwires"]  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
    assert "lib/store.py" in scoped["falsifier-tripwires"]  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
    assert "lib/config.py" in scoped["falsifier-tripwires"]  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
    assert "unrun-dark-guards" in scoped
    assert ".claude/hooks/gh_quota_guard.py" in scoped["unrun-dark-guards"]  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)


def test_derived_closure_follows_relative_first_party_imports() -> None:
    """Package-local imports are ownership edges, not optional implementation detail."""
    closure = suite_dependency_closure("tests/test_admin_modules.py")
    assert "admin/ai_cost.py" in closure.files  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
    assert "admin/config_store.py" in closure.files  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
    assert "admin/flags.py" in closure.files  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
    assert "admin/paths.py" in closure.files  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)

    materializer = suite_dependency_closure(
        "tests/test_capital_structure_share_count_materializer.py"
    )
    assert "engine/capital_structure/share_count_materializer.py" in materializer.files  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
    assert "engine/capital_structure/share_count_truth.py" in materializer.files  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)


def _declared_scan_dirs(rel: str) -> tuple[str, ...]:
    """The `SCAN_DIRS` literal a scanner suite declares, read without importing it.

    Parsed rather than imported so this stays a statement about the scanner's
    own source. The selector derives its roots from `CODE_SCAN_ROOTS`, so the
    two sides remain independent evidence and a root added to one but not
    reachable by the other is a real finding, not a tautology.
    """
    tree = ast.parse((ROOT / rel).read_text())
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id == "SCAN_DIRS"
            for target in node.targets
        ):
            return tuple(ast.literal_eval(node.value))
    raise AssertionError(f"{rel} no longer declares SCAN_DIRS at module level")


def test_whole_tree_glob_job_owns_every_scanned_code_root(real_manifest_scopes) -> None:
    """A tree scan cannot be narrowed to the scanner suite's import closure.

    `all-exports-resolve` AST-walks every `*.py` under eight directories, so a
    scope narrower than those roots is a guard that stops running on exactly the
    pull requests that can break it, and reports green forever.

    The roots reach the job on the OPAQUE tier: an `rglob("*.py")` is the
    textbook `fallback_paths` claim (#5586 split provenance out of `paths`).
    Reading `paths` alone reported the tier split ITSELF as the narrowing —
    after the split that field holds `tests/test_all_exports_resolve.py` and
    nothing else, which is precisely the scanner suite's own import closure
    this test is named for.

    The tier is also observable behavior, not merely an explanation: owned
    paths match before passive-file suppression, while fallback paths must not
    select narrative Markdown. Pin both the executable selection and the
    passive-file exclusion so a later refactor cannot silently undo #5586.
    """
    scan_dirs = _declared_scan_dirs("tests/test_all_exports_resolve.py")
    assert len(scan_dirs) >= 8, scan_dirs
    jobs, _ = real_manifest_scopes
    export_guard = next(job for job in jobs if job.job_id == "all-exports-resolve")
    surface = export_guard.paths + export_guard.fallback_paths
    missing = [f"{root}/**" for root in scan_dirs if f"{root}/**" not in surface]
    assert not missing, (
        f"all-exports-resolve scans {missing} but no scope pattern claims them: "
        f"{surface}"
    )

    # Membership is not selection: a pattern nothing matches is a scope that
    # reads correct and runs never. A NEW module under a scanned root is the
    # case that matters most — that is where an unbound `__all__` name is born.
    for root in scan_dirs:
        assert f"{root}/**" in export_guard.fallback_paths
        probe = f"{root}/__whole_tree_probe__.py"
        assert PACK._job_diff_match(export_guard, [probe]) == (probe, "fallback")
        selected, reason = PACK.select_jobs(jobs, [probe])
        assert export_guard in selected, (probe, reason)
        narrative_probe = f"{root}/__whole_tree_probe__.md"
        assert PACK._job_diff_match(export_guard, [narrative_probe]) is None

    # And the probe that pins non-vacuity: an existing file OUTSIDE the scanner
    # suite's dependency closure, i.e. one the narrowed scope would have lost.
    closure = suite_dependency_closure("tests/test_all_exports_resolve.py").files
    assert "engine/market_state.py" not in closure  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
    selected, reason = PACK.select_jobs(jobs, ["engine/market_state.py"])  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
    assert export_guard in selected, reason


def test_a_glob_pattern_bounds_the_file_kinds_its_scan_can_reach() -> None:
    """`d.glob("*.parquet")` cannot be changed by a `.json` or `.py` edit.

    The classifier used to read a traversal's pattern only to pick a root SET and
    then claim every file under those roots.  Measured across the 181-job manifest
    on 2026-08-11, that is what handed `data/**` to 90 jobs off one parquet scan in
    a hub module and pinned the narrow-diff contract at exactly zero headroom.

    The narrowing is a strict subset, never a new claim: every path
    `data/**/*.parquet` matches, `data/**` already matched.
    """
    narrowed = PACK.narrow_to_suffixes(("data/**", "site/**", "*"), (".parquet",))
    assert "data/**/*.parquet" in narrowed
    assert "site/**/*.parquet" in narrowed
    assert "*.parquet" in narrowed
    assert "data/**" not in narrowed
    # pyarrow writes partitioned datasets as `x.parquet/part-0.parquet`, so the
    # subtree under a matched entry keeps its owner.
    assert "data/**/*.parquet/**" in narrowed
    for covered in ("data/x.parquet", "data/a/b/x.parquet", "data/a/x.parquet/p.json"):
        assert PACK._matches_any(narrowed, covered), covered
        assert PACK._matches_any(("data/**",), covered), covered
    for outside in ("data/cycle_ontology/falsifiers.json", "data/a/b.py"):
        assert not PACK._matches_any(narrowed, outside), outside
    # No suffix evidence means no narrowing at all.
    assert PACK.narrow_to_suffixes(("data/**",), ()) == ("data/**",)


def test_exclude_peer_test_ownership_drops_catch_alls_keeps_fixtures() -> None:
    """Named pytest jobs must not own every tests/*.py edit via opaque globs."""
    filtered = PACK.exclude_peer_test_ownership(
        (
            "*",
            "*.py",
            "tests/**",
            "tests/**/*.py",
            "tests/**/*.py/**",
            "tests/**/*.json",
            "research/**",
            "docs/**",
            "content/**",
            "research/**/*.md",
            "engine/**",
            "tests/test_foo.py",
        )
    )
    assert "*" not in filtered
    assert "tests/**" not in filtered
    assert "tests/**/*.py" not in filtered
    assert "docs/**" not in filtered
    assert "content/**" not in filtered
    assert "research/**" in filtered
    assert "tests/**/*.json" in filtered
    assert "research/**/*.md" in filtered
    assert "engine/**" in filtered
    assert "tests/test_foo.py" in filtered


def test_resolve_changed_files_prefers_planner_json(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Packs must not git-diff a shallow clone when ci-plan already listed the files."""
    monkeypatch.setattr(
        PACK, "changed_files", lambda base: (_ for _ in ()).throw(AssertionError("git"))
    )
    assert PACK.resolve_changed_files(
        "abc123", explicit_json='["tests/test_foo.py","engine/bar.py"]'
    ) == ["tests/test_foo.py", "engine/bar.py"]
    assert PACK.resolve_changed_files("abc123", explicit_json="null") is None
    assert PACK.resolve_changed_files("abc123", explicit_json="not-json") is None
    monkeypatch.setenv("CI_CHANGED_FILES_JSON", '["app/x.py"]')
    assert PACK.resolve_changed_files("abc123") == ["app/x.py"]
    monkeypatch.delenv("CI_CHANGED_FILES_JSON")
    monkeypatch.setattr(PACK, "changed_files", lambda base: ["from-git.py"])
    assert PACK.resolve_changed_files("abc123") == ["from-git.py"]
    assert PACK.resolve_changed_files(None) is None


def test_p0b_closure_accepts_null_on_exactly_the_events_that_publish_it() -> None:
    """The p0b closure gate's `null` allow-list is the planner's own table.

    Every main proof publishes `null` (a full-suite plan has no list), and so
    does the base replay for its base-as-main child. #7237 refused `null`
    outright, which redded every main ci.yml proof. The fix accepts it on
    those events and nowhere else. If the planner gains a main-role event,
    this fails until the gate's set follows.
    """
    from scripts import check_p0b_receipt_closure as P0B

    main_role_events = {
        event for role, event in PACK.SUPPORTED_PLAN_ROLE_EVENTS if role == "main"
    }
    source = Path(PACK.__file__).read_text(encoding="utf-8")
    assert '"GITHUB_EVENT_NAME": "base_replay"' in source
    assert 'base_changed_files.write_text("null\\n"' in source
    assert P0B.NO_DIFF_SUBJECT_EVENTS == main_role_events | {"base_replay"}
    assert "pull_request" not in P0B.NO_DIFF_SUBJECT_EVENTS


# ─── The 2026-08-14 E2BIG transport regression (run 31775693780) ──────────────
#
# PR #5578 carried a handful of files, and every one of its twelve packs died
# before executing a single test:
#
#     An error occurred trying to start process '/usr/bin/bash' ...
#     Argument list too long
#
# The chain: ci-plan diffed against the PR's opening base SHA; by run time main
# had advanced 45 commits and 8,581 distinct paths through the nightly bake
# window; the whole drift was attributed to the PR; and the resulting list rode
# a job output into the pack step's `env:` as CI_CHANGED_FILES_JSON — 350,264
# measured bytes against Linux's 131,072-byte MAX_ARG_STRLEN, the per-STRING cap
# execve applies before any program runs.
#
# These tests pin the TRANSPORT — the property that the list's size stops
# mattering — and the first one is the mutation proof: it fires a real execve at
# a population no environment can hold.

_E2BIG_MIN_JSON_BYTES = 2_000_000

# The child proves three things at once, in one real process: the giant env
# string did not follow it through execve, the file transport did, and the paths
# survived byte-exact across the boundary.
_E2BIG_CHILD = """
import json, os, sys
assert "CI_CHANGED_FILES_JSON" not in os.environ, "the inline list reached a child"
with open(os.environ["CI_CHANGED_FILES_FILE"], encoding="utf-8") as handle:
    paths = json.load(handle)
assert len(paths) == int(sys.argv[1]), (len(paths), sys.argv[1])
assert paths[7] == sys.argv[2], (paths[7], sys.argv[2])
"""


def _e2big_population() -> list[str]:
    """A changed-file list no process environment can carry.

    Deliberately unpleasant, because the transport has to be indifferent to it:
    spaces, an em dash, Han characters and a Greek letter — the shapes a naive
    shell round-trip mangles — over enough volume to clear BOTH caps this suite
    fires against (Linux's 131,072-byte per-string MAX_ARG_STRLEN and macOS's
    ~1 MiB total ARG_MAX). The incident itself needed only 350,264 bytes; the
    margin keeps the proof honest on either kernel.
    """
    return [
        f"data/研究/{index:05d}/sector-rotation-quarterly-snapshot/"
        f"季度报告 {index} α — final draft.parquet"
        for index in range(18_000)
    ]


@pytest.mark.skipif(sys.platform == "win32", reason="execve argument caps are POSIX")
def test_a_large_changed_file_list_cannot_cross_a_process_environment() -> None:
    """The launch failure itself, reproduced — this is what must never be wired.

    Not a hypothetical: it is `subprocess.run` refusing to start a process that
    does nothing, purely because one environment string is too long. Every
    legacy step in a pack is exactly this call shape (`bash -eo pipefail -c`),
    which is why all twelve packs reported a bash startup error rather than a
    test failure.
    """
    population = _e2big_population()
    assert len(population) >= 12_000
    giant = json.dumps(population, separators=(",", ":"))
    assert len(giant.encode("utf-8")) > _E2BIG_MIN_JSON_BYTES
    with pytest.raises(OSError) as caught:
        subprocess.run(
            [sys.executable, "-c", "pass"],
            env={**os.environ, "CI_CHANGED_FILES_JSON": giant},
            check=True,
        )
    assert caught.value.errno == errno.E2BIG, (
        f"expected E2BIG, got errno {caught.value.errno}: {caught.value}"
    )


@pytest.mark.skipif(sys.platform == "win32", reason="execve argument caps are POSIX")
def test_the_file_transport_carries_the_list_that_e2bigs_the_environment(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Same population, same paths, byte for byte — and a child that launches.

    Three legs, in the order the production chain runs them: the planner
    resolving from a file must reach the identical plan it would reach from an
    in-memory list; `--emit-changed-files` must round-trip the array back out
    byte-exact; and a real child spawned through `_dependency_environment` must
    START, with the inline name absent from its environ and the file carrying
    the full count.

    The last leg is the mutation detector for `_child_environment`: the inline
    string is planted in `os.environ` at a size no execve accepts, so a child
    spawned from an environment that still forwards it CANNOT start. Drop the
    pop and this test does not merely fail an equality check — it reproduces the
    incident.
    """
    population = _e2big_population()
    handle = tmp_path / "changed-files.json"
    handle.write_text(
        json.dumps(population, separators=(",", ":")), encoding="utf-8"
    )
    monkeypatch.setenv("CI_CHANGED_FILES_FILE", str(handle))
    resolved = PACK.resolve_changed_files("stale-base-sha")
    assert resolved == population, "the file transport must not reshape the list"

    _freeze_scope_inference(monkeypatch)
    jobs = [
        _plan_job("data-owner", 0, paths=("data/**",)),
        _plan_job("engine-owner", 1, paths=("engine/**",)),
    ]
    from_file = PACK.build_plan(
        jobs, resolved, changed_from="stale-base-sha", scope_mode="active",
        pack_count=12,
    )
    in_memory = PACK.build_plan(
        jobs, population, changed_from="stale-base-sha", scope_mode="active",
        pack_count=12,
    )
    assert from_file.plan_sha256 == in_memory.plan_sha256
    assert from_file.changed_files_sha256 == in_memory.changed_files_sha256
    assert from_file.changed_files_count == len(population)
    assert from_file.eligible_job_ids == in_memory.eligible_job_ids

    # The artifact this planner publishes must be readable back as the same
    # list — a reshaped array would hash to something else and refuse the plan.
    republished = tmp_path / "published" / "changed-files.json"
    PACK._write_changed_files_artifact(republished, from_file.changed_paths)
    assert json.loads(republished.read_text(encoding="utf-8")) == population

    monkeypatch.setenv(
        "CI_CHANGED_FILES_JSON", json.dumps(population, separators=(",", ":"))
    )
    command_env = PACK._dependency_environment(None)
    assert "CI_CHANGED_FILES_JSON" not in command_env
    assert command_env["CI_CHANGED_FILES_FILE"] == str(handle)
    completed = subprocess.run(
        [sys.executable, "-c", _E2BIG_CHILD, str(len(population)), population[7]],
        env=command_env,
        capture_output=True,
        text=True,
    )
    assert completed.returncode == 0, (
        f"a legacy step could not launch with the list present as a file: "
        f"{completed.stderr}"
    )


def test_a_stale_comparison_base_never_smears_mains_paths_into_scope(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """The other half of the 2026-08-14 chain: git must not be consulted at all.

    PR #5578's planner diffed an immutable base SHA that main had left 45
    commits behind, so `git diff` answered with 8,581 paths of somebody else's
    nightly bake. The published list is the ONLY authority — when a handle is
    configured, a stale `--changed-from` must not reach git even as a fallback,
    because the answer it would give is the incident.
    """
    handle = tmp_path / "changed-files.json"
    handle.write_text('["engine/example.py","tests/test_foo.py"]', encoding="utf-8")
    monkeypatch.setenv("CI_CHANGED_FILES_FILE", str(handle))
    monkeypatch.setattr(
        PACK,
        "changed_files",
        lambda base: (_ for _ in ()).throw(AssertionError(f"git diff {base}")),
    )
    assert PACK.resolve_changed_files("2ca4718") == [
        "engine/example.py", "tests/test_foo.py"
    ]
    # The file also out-ranks a contradicting inline string, so a stale env value
    # cannot out-vote the artifact the pack downloaded.
    monkeypatch.setenv("CI_CHANGED_FILES_JSON", '["site/decoy.html"]')
    assert PACK.resolve_changed_files("2ca4718") == [
        "engine/example.py", "tests/test_foo.py"
    ]
    # An unreadable handle widens; it must NOT fall through to that same git.
    monkeypatch.setenv("CI_CHANGED_FILES_FILE", str(tmp_path / "never-written.json"))
    assert PACK.resolve_changed_files("2ca4718") is None
    # And the explicit flag out-ranks both names, so a local reproduction can
    # replay a published list without touching the ambient environment.
    assert PACK.resolve_changed_files("2ca4718", explicit_file=handle) == [
        "engine/example.py", "tests/test_foo.py"
    ]


def test_changed_files_digest_is_an_affirmative_no_list_or_an_ordered_hash() -> None:
    """"" is not a hash — it is the encoding of "the planner had no list".

    That distinction is the whole reason a pack can tell "planned the full
    suite" from "planned this exact diff" without a second flag, and order is
    load-bearing because two transports that sorted differently would hash the
    same list to two values and refuse every plan.
    """
    assert PACK.changed_files_digest(None) == ""
    ordered = PACK.changed_files_digest(["b.py", "a.py"])
    assert len(ordered) == 64 and ordered != ""
    assert PACK.changed_files_digest(["a.py", "b.py"]) != ordered
    assert PACK.changed_files_digest(("b.py", "a.py")) == ordered


@pytest.mark.parametrize(
    ("body", "state", "count"),
    [
        ('["a.py","b.md"]', "list", 2),
        ("null", "null", 0),
        ('["", ""]', "null", 0),
        ("{nope", "malformed", 0),
        ("", "malformed", 0),
        ('"one string"', "malformed", 0),
        ("[1]", "malformed", 0),
    ],
)
def test_changed_files_handle_states_are_named_not_merely_falsy(
    tmp_path: Path, body: str, state: str, count: int
) -> None:
    """A pack that refuses has to say WHICH way the handle was wrong.

    `resolve_changed_files` only widens, which is right for the decision and
    useless for the diagnosis: since 2026-08-14 the most likely cause of a
    plan-sha parity failure is this file, not the manifest, so the annotation
    that accompanies the refusal names the state.
    """
    handle = tmp_path / "changed-files.json"
    handle.write_text(body, encoding="utf-8")
    got_state, paths = PACK._read_changed_files_handle(str(handle))
    assert (got_state, len(paths)) == (state, count)
    assert PACK._read_changed_files_handle(None) == ("absent", [])
    assert PACK._read_changed_files_handle(str(tmp_path / "gone.json")) == (
        "unreadable", []
    )


def test_plan_publishes_changed_paths_for_pack_shallow_checkout(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _freeze_scope_inference(monkeypatch)
    jobs = [_plan_job("owner", 0, paths=("tests/test_foo.py",))]
    plan = PACK.build_plan(
        jobs,
        ["tests/test_foo.py"],
        changed_from="base-sha",
        scope_mode="active",
        pack_count=12,
    )
    assert plan.changed_paths == ("tests/test_foo.py",)
    assert plan.nonempty_pack_indices == (0,)


def test_traversal_pattern_evidence_is_read_only_when_it_is_literal() -> None:
    """An unreadable or unlisted pattern keeps the full root claim."""
    closure = _closure_of(
        "from pathlib import Path\n"
        "import config\n"
        "def a(pattern):\n"
        "    return list((config.data_dir() / 'x').glob(pattern))\n"
        "def b():\n"
        "    return list((config.data_dir() / 'x').glob('*.parquet'))\n"
        "def c():\n"
        "    return list((config.data_dir() / 'x').glob('*.unlisted'))\n"
        "def d():\n"
        "    return list((config.data_dir() / 'x').iterdir())\n"
        "def e():\n"
        "    return list((config.data_dir() / 'x').glob('v1.2'))\n"
    )
    kinds = {int(item.split(":")[1]): item for item in closure.ambiguities}
    # a: runtime pattern; c: suffix outside the closed vocabulary; d: iterdir has
    # no pattern; e: a FIXED name that may well be a directory whose contents
    # would then lose their owner.  All four keep the unnarrowed claim.
    for line in (4, 8, 10, 12):
        assert " suffixes=" not in kinds[line], kinds[line]
    assert kinds[6].endswith(" suffixes=.parquet"), kinds[6]


def test_a_module_local_walk_is_not_a_filesystem_traversal() -> None:
    """`walk()` over a JSON document is not `os.walk` over the repository.

    `engine/sector_intelligence/contracts.py` defines a recursive document
    `walk()`; the label-only classifier read all five call sites as tree scans and
    charged four repository roots to the 35 jobs that import it.
    """
    document = _closure_of(
        "def walk(value, path):\n"
        "    if isinstance(value, dict):\n"
        "        for key, nested in value.items():\n"
        "            walk(nested, (*path, key))\n"
        "def check(document):\n"
        "    walk(document, ())\n"
    )
    assert not document.ambiguities, document.ambiguities
    # An imported os.walk with the same name is still a traversal.
    imported = _closure_of(
        "from os import walk\n"
        "def scan(root):\n"
        "    return list(walk(root))\n"
    )
    assert any("filesystem" in item for item in imported.ambiguities)


def test_a_code_suffix_must_end_a_filename_not_merely_appear_in_one() -> None:
    """`.js` inside `*.json` promoted artifact scans to whole-tree code scans.

    A json-only traversal claimed every Python file in eleven code roots because
    the classifier used a substring test.
    """
    artifact = _closure_of(
        "def scan(root):\n"
        "    return list(root.glob('*.json'))\n"
    )
    assert any("artifact traversal" in item for item in artifact.ambiguities)
    assert not any("code traversal" in item for item in artifact.ambiguities)
    code = _closure_of(
        "def scan(root):\n"
        "    return list(root.rglob('*.py'))\n"
    )
    assert any("code traversal" in item for item in code.ambiguities)


def test_derived_scopes_are_startable_by_the_ci_workflow(real_manifest_scopes) -> None:
    """A job owner is useless when its dependency edit cannot start ci.yml.

    BOTH tiers are audited. #5586 split the PROVENANCE of a claim out of
    `paths` and into `fallback_paths`; it did not split the selection, so an
    opaque root ci.yml cannot start is the same silent hole in a different
    field — the planner picks the job and the run never begins.

    Measured on the manifest that shipped the split: zero gaps on either tier,
    so reading both is a restoration of dropped coverage, not a relaxation —
    but 289 of the 327 fallback patterns appear in NO job's `paths`, and
    dropping `ops/**` from ci.yml's triggers opens 448 gaps that the
    `paths`-only form still reports as zero.
    """
    jobs, _ = real_manifest_scopes
    on = _yaml(WORKFLOW).get("on") or _yaml(WORKFLOW).get(True)
    triggers = tuple(on["pull_request"]["paths"])
    gaps: list[tuple[str, str]] = []
    for job in jobs:
        for path in job.paths + job.fallback_paths:
            if any(char in path for char in "*?"):
                if not PACK.scope_pattern_is_startable(path, triggers):
                    gaps.append((job.job_id, path))
            elif not PACK._matches_any(triggers, path):
                gaps.append((job.job_id, path))
    assert not gaps, gaps[:25]


def test_startability_accepts_only_provable_narrowings_of_a_trigger() -> None:
    """A derived scope may skip the trigger list only when a parent covers it.

    Literal membership used to be the whole rule, which forced one ci.yml entry
    per derived pattern.  With suffix- and subtree-narrowed scopes that vocabulary
    is open-ended, and a missing entry would red an unrelated pull request the
    first time any module globbed a new extension.  The replacement is a
    containment PROOF, not a relaxation: `data/**/*.parquet` and
    `data/smart_money/**` each match a strict subset of `data/**`, so an edit that
    reaches the job always starts the run.  A tree no trigger covers still fails.
    """
    triggers = ("data/**", "engine/**", "*", "config/dag.yml")  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
    for covered in (
        "data/**",                      # literal member
        "data/**/*.parquet",            # suffix-narrowed child of data/**
        "data/**/*.parquet/**",         # its directory-subtree companion
        "data/smart_money/**",          # subtree-narrowed child of data/**
        "data/a/b/c/**",                # deeper subtree
        "*.json",                       # repository-root form, `*` is a trigger
        "engine/*",                     # single-level subset of engine/**
        # SINGLE-LEVEL SUFFIX GLOB (2026-08-26).  SUFFIX_NARROWED_RE requires a
        # `**/` before the suffix, and the bare-`/*` test does not fire on a
        # pattern ending `*.py`, so these fell through to False despite being as
        # strictly contained in `engine/**` as `engine/*` is.  `defense-rail-laws`
        # derived exactly this shape and reported an unstartable gap against a
        # trigger list carrying `engine/**`.  ci-pack is path-scoped, so only a PR
        # touching .github/ci/ ever ran the test that noticed.
        "engine/*.py",
        "data/*.parquet",
        "data/smart_money/*.py",        # ancestor proof: ⊂ data/smart_money/** ⊂ data/**
    ):
        assert PACK.scope_pattern_is_startable(covered, triggers), covered
    for uncovered in (
        "brand_new_root/**",            # no ancestor is a trigger
        "brand_new_root/**/*.json",     # narrowing an untriggerable tree
        "brand_new_root/deep/**",
        "site/**",                      # a real root that this filter omits
        "app/*",                        # single-level, but app/** is not a trigger
        "app/*.py",                     # same, suffixed — must NOT be relaxed
        "*/engine/*.py",                # a glob in the PARENT proves nothing
    ):
        assert not PACK.scope_pattern_is_startable(uncovered, triggers), uncovered


def test_representative_narrow_diffs_skip_at_least_one_quarter_of_jobs(real_manifest_scopes) -> None:
    """The conservative first tranche must still deliver material speed."""
    jobs, _ = real_manifest_scopes
    cases = {
        "govrev": [
            "research/GOVERNMENT_REVENUE_FORESIGHT_HANDOFF_2026-08-09.md",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
            "scripts/build_government_revenue_candidates.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
            "tests/test_government_revenue_candidate_projection.py",
        ],
        "tripwires": [
            "data/cycle_ontology/falsifiers.json",
            "data/cycle_ontology/tripwire_state.json",
            "engine/falsifier_tripwires.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
            "tests/test_falsifier_tripwires.py",
        ],
    }
    for name, changed in cases.items():
        selected, reason = PACK.select_jobs(jobs, changed)
        assert len(selected) <= (len(jobs) * 4) // 5, (name, len(selected), reason)
    selected, _ = PACK.select_jobs(jobs, cases["tripwires"])
    assert any(job.job_id == "falsifier-tripwires" for job in selected)

    content, reason = PACK.select_jobs(jobs, ["content/seo/blog/example.md"])
    assert len(content) < len(jobs), reason
    assert any(job.job_id == "free-content-estate" for job in content)


def test_a_named_suite_edit_does_not_select_peer_pytest_jobs(real_manifest_scopes) -> None:
    """PR #5550 shape: one prophet test file used to mint 133/187 jobs and 12 packs.

    unrun-market-plumbing names tests/test_prophet_w1_intake_repair.py. marketing-engine
    and engine-render-guards do not. After exclude_peer_test_ownership they must not
    run for this diff, and the matrix must not be the full twelve.
    """
    jobs, _ = real_manifest_scopes
    changed = ["tests/test_prophet_w1_intake_repair.py"]
    selected, reason = PACK.select_jobs(jobs, changed)
    ids = {job.job_id for job in selected}
    assert "unrun-market-plumbing" in ids, reason
    assert "marketing-engine" not in ids, reason
    assert "engine-render-guards" not in ids, reason
    assert "full suite" not in reason, reason
    assert len(selected) <= len(jobs) // 4, (len(selected), len(jobs), reason)
    packs = PACK.partition_jobs(selected, 12)
    nonempty = [index for index, pack in enumerate(packs) if pack]
    assert len(nonempty) < 12, nonempty


def test_company_intelligence_workspace_chain_is_executed_by_pr_code_gate(real_manifest_scopes) -> None:
    """D5's hermetic real-reader chain suite must run before a PR can merge.

    A path-only owner is insufficient: the selected ``gate: code`` job must
    also name the suite in an executing ``run:`` step.
    """
    manifest = _yaml(MANIFEST)
    prophet_lab = manifest["jobs"]["prophet-lab"]
    suite = "tests/test_company_intelligence_workspace_chain.py"
    assert prophet_lab["gate"] == "code"
    assert suite in prophet_lab["paths"]
    assert any(
        suite in str(step.get("run") or "")
        for step in prophet_lab["steps"]
    )
    assert {"requests", "pyarrow"} <= _job_pip_packages(prophet_lab), (
        "prophet-lab's executing D5 suite imports requests and pyarrow in a clean "
        "Python 3.12 job; keep those dependencies on this owning job's install line"
    )

    jobs, _ = real_manifest_scopes
    code_jobs = [job for job in jobs if job.gate == "code"]
    selected, reason = PACK.select_jobs(code_jobs, [suite])
    assert "prophet-lab" in {job.job_id for job in selected}, reason
    assert "unowned path" not in reason, reason


def test_stock_dashboard_first_frame_contract_is_executed_by_pr_code_gate(real_manifest_scopes) -> None:
    """P0B's hermetic first-frame contract must run in the merge gate.

    The generated-page population receipt remains data-dependent and belongs
    in ``engine-render-guards``.  The template/composer/CSS/loader contract is
    source-only, so merely listing it in that ``gate: data`` job would leave
    the PR's real ``--gate code`` execution falsely green.
    """
    manifest = _yaml(MANIFEST)
    code_job = manifest["jobs"]["stock-dashboard-first-frame"]
    code_suite = "tests/test_stock_dashboard_first_frame.py"
    data_suite = "tests/test_stock_dashboard_first_frame_data.py"

    assert code_job["gate"] == "code"
    assert code_job["scope"] == "exclusive"
    required_paths = {
        "templates/hk.html.j2",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        "templates/canada.html.j2",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        "templates/stock-dashboard.css",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        "templates/dashboard-icons.js",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        "site/hk-stock-v36.js",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        "site/canada-stock-v36.js",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        "site/stock-dashboard.css",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        "site/dashboard-icons.js",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        "scripts/render_stock_dashboard_fixture.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        "scripts/verify_stock_dashboard_mobile_layout.cjs",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        "mockups/evidence/prophet-p0b-zero-fouc/manifest.json",
        "mockups/evidence/prophet-p0b-zero-fouc/inputs/canada-owner-fixture.json",
        "mockups/evidence/prophet-p0b-zero-fouc/inputs/hk-owner-fixture.json",
        "mockups/evidence/prophet-p0b-zero-fouc/inputs/canada-action-fixture.json",
        "mockups/evidence/prophet-p0b-zero-fouc/inputs/hk-action-fixture.json",
        "mockups/evidence/prophet-p0b-zero-fouc/inputs/browser-data/canadabasketdata/baskets.json",
        "mockups/evidence/prophet-p0b-zero-fouc/inputs/browser-data/canadabasketdata/sector_pulse_canada.json",
        "mockups/evidence/prophet-p0b-zero-fouc/inputs/browser-data/live/overlay.json",
        "mockups/evidence/prophet-p0b-zero-fouc/inputs/browser-data/live/quotes.json",
        "mockups/evidence/prophet-p0b-zero-fouc/inputs/browser-data/marketdata/rotation_events_hk.json",
        "mockups/evidence/prophet-p0b-zero-fouc/rendered-fixture.json",
        "mockups/evidence/prophet-p0b-zero-fouc/mobile-layout.json",
        "mockups/evidence/prophet-p0b-zero-fouc/mobile-layout-canada.json",
        "mockups/evidence/prophet-p0b-zero-fouc/hk-js-disabled-dark-390.png",
        "mockups/evidence/prophet-p0b-zero-fouc/hk-composer-failed-light-390.png",
        "mockups/evidence/prophet-p0b-zero-fouc/ca-js-disabled-dark-390.png",
        "mockups/evidence/prophet-p0b-zero-fouc/ca-composer-failed-light-390.png",
        code_suite,
    }
    assert required_paths <= set(code_job["paths"])
    assert any(code_suite in str(step.get("run") or "") for step in code_job["steps"])
    assert _job_pip_packages(code_job) == {"beautifulsoup4", "jinja2", "pytest"}

    data_job = manifest["jobs"]["engine-render-guards"]
    data_runs = "\n".join(str(step.get("run") or "") for step in data_job["steps"])
    assert data_job["gate"] == "data"
    assert data_suite in data_runs
    assert code_suite not in data_runs

    jobs, _ = real_manifest_scopes
    code_jobs = [job for job in jobs if job.gate == "code"]
    for changed in (
        [code_suite],
        ["templates/hk.html.j2"],  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        ["site/canada-stock-v36.js"],  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        ["scripts/render_stock_dashboard_fixture.py"],  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        ["mockups/evidence/prophet-p0b-zero-fouc/inputs/hk-owner-fixture.json"],
        ["mockups/evidence/prophet-p0b-zero-fouc/inputs/hk-action-fixture.json"],
        ["mockups/evidence/prophet-p0b-zero-fouc/inputs/browser-data/live/quotes.json"],
        ["mockups/evidence/prophet-p0b-zero-fouc/mobile-layout-canada.json"],
    ):
        selected, reason = PACK.select_jobs(code_jobs, changed)
        assert "stock-dashboard-first-frame" in {job.job_id for job in selected}, reason
        assert "unowned path" not in reason, reason


def test_bc2_validated_claims_source_half_is_executed_by_pr_code_gate(real_manifest_scopes) -> None:
    """BC-2 ran only on the data gate, so nothing graded a claim before merge.

    Every job that executed the checker was ``gate: data``, and ci.yml packs only
    ``gate: code``: 75 unearned 'validated' claims merged green between 2026-08-25
    and 2026-09-24 and were healed in one batch (#7979). The split pinned here:
    ``validated-claims-source`` scans the PR-authored roots on every PR that can
    move them, ``validated-claims-contract`` runs the checker's suites when the
    checker, the allowlist or a suite changes, and ``validated-claims`` keeps the
    FULL scan on the data gate — the rendered site and the registries move with
    nightly commits, so they must never red somebody else's PR. scripts/ joins the
    PR-authored roots at its top-level page builders only (``build_*``/``render_*``),
    the same cut the checker walks, so a checker or a research script never selects
    the source job.
    """
    manifest = _yaml(MANIFEST)
    checker = "scripts/check_validated_claims.py"  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
    allowlist = "data/regime/validated_claims_allowlist.json"

    source_job = manifest["jobs"]["validated-claims-source"]
    source_runs = [str(step.get("run") or "") for step in source_job["steps"]]
    assert source_job["gate"] == "code"
    assert source_job["scope"] == "exclusive"
    assert {"templates/**", "engine/**", "lib/**", "scripts/build_*.py", "scripts/render_*.py",
            checker, allowlist} <= set(source_job["paths"])
    assert f"python3 {checker} --scope source" in source_runs
    assert f"python3 {checker} --selftest" in source_runs

    contract_job = manifest["jobs"]["validated-claims-contract"]
    contract_runs = "\n".join(str(step.get("run") or "") for step in contract_job["steps"])
    assert contract_job["gate"] == "code"
    assert contract_job["scope"] == "exclusive"
    assert {checker, allowlist, "tests/test_validated_claims_*.py"} <= set(contract_job["paths"])
    assert "tests/test_validated_claims_source_scope.py" in contract_runs

    data_job = manifest["jobs"]["validated-claims"]
    data_runs = [str(step.get("run") or "") for step in data_job["steps"]]
    assert data_job["gate"] == "data"
    assert f"python3 {checker}" in data_runs, "the data gate keeps the full scan"
    assert not any("--scope" in run for run in data_runs)

    jobs, _ = real_manifest_scopes
    code_jobs = [job for job in jobs if job.gate == "code"]
    for changed, owners in (
        (["templates/dashboard.html.j2"], {"validated-claims-source"}),  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        (["engine/flow_signing.py"], {"validated-claims-source"}),  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        (["lib/pages.py"], {"validated-claims-source"}),  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        (["scripts/build_spvector.py"], {"validated-claims-source"}),  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        (["scripts/render_china_fast.py"], {"validated-claims-source"}),  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        ([checker], {"validated-claims-source", "validated-claims-contract"}),
        ([allowlist], {"validated-claims-source", "validated-claims-contract"}),
        (["tests/test_validated_claims_source_scope.py"], {"validated-claims-contract"}),
    ):
        selected, reason = PACK.select_jobs(code_jobs, changed)
        assert owners <= {job.job_id for job in selected}, (changed, reason)
        assert "unowned path" not in reason, reason
    for changed in (
        ["scripts/check_design_system.py"],  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        ["scripts/capture_page_evidence.py"],  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        ["scripts/research/build_delivery_waterfall.py"],  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
    ):
        selected, reason = PACK.select_jobs(code_jobs, changed)
        assert "validated-claims-source" not in {job.job_id for job in selected}, (
            changed, reason)


def test_unscoped_hook_diff_does_not_pull_the_full_suite(real_manifest_scopes) -> None:
    """PR #5488 shape: `.claude/hooks/gh_quota_guard.py` used to mint 187/187 jobs.

    CI_SCOPE_MODE is already active in ci.yml unless the repo var is exactly
    ``off``. The remaining hole was select_jobs treating an unowned path as a
    full-suite invalidator. After this PR the hook is owned by unrun-dark-guards
    and an unowned sibling still does not widen.
    """
    jobs, _ = real_manifest_scopes
    selected, reason = PACK.select_jobs(
        jobs, [".claude/hooks/gh_quota_guard.py"]  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
    )
    assert "full suite" not in reason, reason
    assert len(selected) < len(jobs) * 4 // 5, (len(selected), len(jobs), reason)
    assert any(job.job_id == "unrun-dark-guards" for job in selected)
    mixed, mixed_reason = PACK.select_jobs(
        jobs,
        [".claude/hooks/gh_quota_guard.py", "engine/spine.py"],  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
    )
    assert "full suite" not in mixed_reason, mixed_reason
    assert len(mixed) < len(jobs), mixed_reason


@pytest.mark.parametrize("graph", ["config/dag.yml", "config/synapse.yml"])  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
def test_graph_metadata_is_a_global_invalidator(graph: str, real_manifest_scopes) -> None:
    jobs, _ = real_manifest_scopes
    selected, reason = PACK.select_jobs(jobs, [graph])
    assert len(selected) == len(jobs)
    assert "global invalidator" in reason


def test_passive_markdown_stays_scoped_and_unknown_root_does_not_widen(real_manifest_scopes) -> None:
    jobs, _ = real_manifest_scopes
    docs, _ = PACK.select_jobs(jobs, ["research/UNOWNED_HANDOFF.md"])
    code, reason = PACK.select_jobs(jobs, ["brand_new_root/unowned_runtime.xyz"])
    assert len(docs) < len(jobs)
    assert len(code) < len(jobs)
    assert "did not widen" in reason
    unscoped = [job for job in jobs if not job.is_scoped]
    assert {job.job_id for job in unscoped} <= {job.job_id for job in code}


def test_name_status_diff_preserves_both_sides_of_rename(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    payload = (
        "R100\0engine/old.py\0engine/new.py\0"
        "D\0config/removed.yml\0M\0tests/test_kept.py\0"
    )

    def fake_run(*args: object, **kwargs: object) -> SimpleNamespace:
        return SimpleNamespace(stdout=payload)

    monkeypatch.setattr(PACK.subprocess, "run", fake_run)
    assert PACK.changed_files("deadbeef") == [
        "engine/old.py",
        "engine/new.py",
        "config/removed.yml",
        "tests/test_kept.py",
    ]


def test_name_status_diff_preserves_copy_spaces_and_unicode(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    payload = "C087\0docs/old name.md\0docs/新 name.md\0"
    commands: list[list[str]] = []

    def fake_run(command: list[str], **kwargs: object) -> SimpleNamespace:
        commands.append(command)
        return SimpleNamespace(stdout=payload)

    monkeypatch.setattr(
        PACK.subprocess,
        "run",
        fake_run,
    )
    assert PACK.changed_files("deadbeef") == ["docs/old name.md", "docs/新 name.md"]
    assert "--find-copies" in commands[0]


def test_empty_successful_diff_fails_closed(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        PACK.subprocess,
        "run",
        lambda *args, **kwargs: SimpleNamespace(stdout=""),
    )
    assert PACK.changed_files("deadbeef") is None


def _git_in(repo: Path, *args: str, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["git", *args],
        cwd=repo,
        check=check,
        capture_output=True,
        text=True,
    )


def _commit_fixture(repo: Path, message: str) -> str:
    _git_in(repo, "add", "-A")
    _git_in(repo, "commit", "-m", message)
    return _git_in(repo, "rev-parse", "HEAD").stdout.strip()


def _seed_tracked_path_repo(tmp_path: Path) -> tuple[Path, str, Path]:
    repo = tmp_path / "tracked-path-repo"
    repo.mkdir()
    _git_in(repo, "init", "-b", "main")
    _git_in(repo, "config", "user.email", "ci@example.invalid")
    _git_in(repo, "config", "user.name", "CI Fixture")
    for directory in ("engine", "tests", "site", "data"):
        (repo / directory).mkdir()
    (repo / "engine" / "__init__.py").write_text("", encoding="utf-8")
    (repo / "engine" / "core.py").write_text("VALUE = 1\n", encoding="utf-8")
    (repo / "tests" / "test_owner.py").write_text(
        "from pathlib import Path\n"
        "from engine import core\n\n"
        "def test_owner():\n"
        "    assert core.VALUE and Path('site/owner.json').read_text()\n",
        encoding="utf-8",
    )
    (repo / "tests" / "test_opaque.py").write_text(
        "from pathlib import Path\n\n"
        "def test_opaque():\n"
        "    assert list(Path('data').rglob('*.json'))\n",
        encoding="utf-8",
    )
    (repo / "site" / "owner.json").write_text('{"owner":true}\n', encoding="utf-8")
    (repo / "site" / "old.json").write_text('{"old":true}\n', encoding="utf-8")
    (repo / "site" / "omitted.py").write_text("VALUE = 1\n", encoding="utf-8")
    (repo / "data" / "feed.json").write_text("[]\n", encoding="utf-8")
    sha = _commit_fixture(repo, "seed exact tree")
    inventory = tmp_path / "tracked-paths.v1"
    DEPS.write_tracked_path_inventory(inventory, sha, root=repo)
    return repo, sha, inventory


def test_depth_two_merge_needs_no_parent1_parent2_merge_base(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """The authoritative diff is parent1...merge, not parent1...parent2.

    A depth-two checkout has the exact synthetic merge and both direct parents,
    but their common ancestor is deliberately outside the shallow boundary. The
    current planner diff still resolves exactly; progressive ancestry acquisition
    (the rejected #6261 design) is neither called nor needed.
    """
    source = tmp_path / "source"
    source.mkdir()
    _git_in(source, "init", "-b", "main")
    _git_in(source, "config", "user.email", "ci@example.invalid")
    _git_in(source, "config", "user.name", "CI Fixture")
    (source / "base.txt").write_text("base\n", encoding="utf-8")
    _commit_fixture(source, "base")
    _git_in(source, "switch", "-c", "feature")
    (source / "tests").mkdir()
    (source / "tests" / "feature.py").write_text("FEATURE = True\n", encoding="utf-8")
    _commit_fixture(source, "feature")
    _git_in(source, "switch", "main")
    (source / "engine").mkdir()
    (source / "engine" / "main.py").write_text("MAIN = True\n", encoding="utf-8")
    _commit_fixture(source, "main")
    _git_in(source, "merge", "--no-ff", "feature", "-m", "synthetic merge")
    _git_in(source, "branch", "candidate", "HEAD")

    shallow = tmp_path / "depth-two"
    subprocess.run(
        [
            "git", "clone", "--depth", "2", "--branch", "candidate",
            f"file://{source}", str(shallow),
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    fields = _git_in(shallow, "rev-list", "--parents", "-n", "1", "HEAD").stdout.split()
    assert len(fields) == 3
    merge_sha, parent1, parent2 = fields
    assert _git_in(shallow, "rev-parse", "HEAD").stdout.strip() == merge_sha
    assert _git_in(shallow, "merge-base", parent1, parent2, check=False).returncode == 1
    assert _git_in(shallow, "merge-base", parent1, "HEAD").stdout.strip() == parent1

    monkeypatch.chdir(shallow)
    assert PACK.changed_files(parent1) == ["tests/feature.py"]


def test_exact_tree_inventory_rejects_missing_malformed_wrong_and_mutated_inputs(
    tmp_path: Path,
) -> None:
    repo, sha, inventory = _seed_tracked_path_repo(tmp_path)
    loaded = DEPS.load_tracked_path_inventory(inventory, sha, root=repo)
    assert loaded.tested_tree_sha == sha
    assert "site/owner.json" in loaded.files
    assert "site" in loaded.directories

    with pytest.raises(DEPS.TrackedPathInventoryError, match="unreadable"):
        DEPS.load_tracked_path_inventory(tmp_path / "missing.v1", sha, root=repo)

    malformed = tmp_path / "malformed.v1"
    malformed.write_bytes(b"not-json\nsite/owner.json\0")
    with pytest.raises(DEPS.TrackedPathInventoryError, match="header is malformed"):
        DEPS.load_tracked_path_inventory(malformed, sha, root=repo)

    header_raw, _, payload = inventory.read_bytes().partition(b"\n")
    header = json.loads(header_raw)
    wrong_tree = tmp_path / "wrong-tree.v1"
    wrong_header = {**header, "tested_tree_sha": "0" * 40}
    wrong_tree.write_bytes(
        json.dumps(wrong_header, sort_keys=True, separators=(",", ":")).encode()
        + b"\n"
        + payload
    )
    with pytest.raises(DEPS.TrackedPathInventoryError, match="does not match expected"):
        DEPS.load_tracked_path_inventory(wrong_tree, sha, root=repo)

    # Remove a real tracked path AND repair the mutation's own count/digest. The
    # independent exact-tree comparison must still catch this, rather than
    # trusting self-consistent but incomplete metadata.
    records = payload[:-1].split(b"\0")
    records.remove(b"site/owner.json")
    truncated_payload = b"\0".join(records) + b"\0"
    truncated_header = {
        **header,
        "path_count": len(records),
        "paths_sha256": DEPS.hashlib.sha256(truncated_payload).hexdigest(),
    }
    truncated = tmp_path / "missing-path.v1"
    truncated.write_bytes(
        json.dumps(truncated_header, sort_keys=True, separators=(",", ":")).encode()
        + b"\n"
        + truncated_payload
    )
    with pytest.raises(DEPS.TrackedPathInventoryError, match="not byte-identical"):
        DEPS.load_tracked_path_inventory(truncated, sha, root=repo)


def test_exact_tree_inventory_rejects_checkout_identity_drift(tmp_path: Path) -> None:
    repo, sha, inventory = _seed_tracked_path_repo(tmp_path)
    (repo / "engine" / "later.py").write_text("LATER = True\n", encoding="utf-8")
    later = _commit_fixture(repo, "move checkout")
    assert later != sha
    with pytest.raises(DEPS.TrackedPathInventoryError, match="checkout HEAD"):
        DEPS.load_tracked_path_inventory(inventory, sha, root=repo)


def test_inventory_preserves_omitted_tracked_existence_but_never_fakes_content(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    repo, sha, inventory = _seed_tracked_path_repo(tmp_path)
    shutil.rmtree(repo / "site")
    monkeypatch.setattr(DEPS, "ROOT", repo)
    DEPS._selector_file_analysis.cache_clear()

    with DEPS.planner_tracked_path_inventory(inventory, sha, root=repo):
        reads = DEPS.direct_reads(repo / "tests" / "test_owner.py")
        assert "site/owner.json" in reads
        assert DEPS.pytest_invocation_ambiguities("pytest site") == (
            "directory pytest target 'site'",
        )
        with pytest.raises(DEPS.ScopeMaterializationError, match="omitted.py"):
            DEPS.suite_dependency_closure("site/omitted.py")


# A legacy-jobs `run:` block whose full-line comment holds ONE apostrophe, beside
# the same block with that comment line removed. The apostrophe used to be an
# unclosed quote to shlex, so the whole block was "unparseable" and the job lost
# its inferred closure (DSC:CI-RUN-BLOCK-COMMENT-QUOTE-BLINDS-CLOSURE-INFERENCE).
# Exactly one per block: a second apostrophe pairs with the first into a valid
# shlex quote and the case then proves nothing, which the positive control in
# the test below refuses.
_COMMENT_QUOTE_RUN_BLOCKS = (
    pytest.param(
        "# the planner's token names the tested tree\n"
        "python3 -m pytest {target}\n",
        "python3 -m pytest {target}\n",
        id="top-level-comment",
    ),
    pytest.param(
        "if true; then\n"
        "  # it's indented, and still a full-line comment\n"
        "  python3 -m pytest {target}\n"
        "fi\n",
        "if true; then\n  python3 -m pytest {target}\nfi\n",
        id="indented-comment",
    ),
)
_UNPARSEABLE_RUN_BLOCK = ("unparseable pytest invocation: No closing quotation",)


def _single_run_step_job(run: str) -> object:
    return PACK.LegacyJob(
        job_id="run-block-comment-quote",
        definition={"runs-on": "ubuntu-latest", "steps": [{"run": run}]},
        ordinal=0,
        weight=1,
    )


def test_named_suite_closure_is_traversed_once_per_command(monkeypatch) -> None:
    suite = "tests/test_scope_fixture.py"
    script = "scripts/scope_fixture.py"
    monkeypatch.setattr(AUDIT, "discover_suites", lambda: [suite])
    monkeypatch.setattr(PACK, "planner_path_is_file", lambda path: str(path) in {suite, script})
    calls = []

    def closure(path, *, pytest_command=None):
        calls.append((path, pytest_command))
        return DEPS.DependencyClosure(
            (str(path), "engine/scope_fixture.py"),
            (f"{path}:1: subprocess roots=scripts,tests",),
        )

    monkeypatch.setattr(DEPS, "suite_dependency_closure", closure)
    command = f"python -m pytest {suite} {suite}::test_second -q && python {script}"
    [job], _ = PACK.infer_job_scopes([_single_run_step_job(command)])
    assert calls == [(suite, command), (script, None)]
    assert set(job.paths) == {suite, script, "engine/scope_fixture.py"}
    assert job.fallback_paths == ("scripts/**",)

    # Reuse is confined to this command, never a stale result across calls.
    calls.clear()
    [again], _ = PACK.infer_job_scopes([_single_run_step_job(command)])
    assert again == job
    assert calls == [(suite, command), (script, None)]


def test_opaque_pytest_target_still_refuses_before_closure_reuse(monkeypatch) -> None:
    monkeypatch.setattr(AUDIT, "discover_suites", lambda: ["tests/test_scope_fixture.py"])

    def unexpected(*args, **kwargs):
        pytest.fail("opaque pytest discovery must not infer a narrow closure")

    monkeypatch.setattr(DEPS, "suite_dependency_closure", unexpected)
    [job], _ = PACK.infer_job_scopes([_single_run_step_job("python -m pytest tests/")])
    assert not job.is_scoped


@pytest.mark.parametrize(("commented", "comment_free"), _COMMENT_QUOTE_RUN_BLOCKS)
def test_full_line_comment_apostrophe_resolves_the_comment_free_targets(
    commented: str, comment_free: str
) -> None:
    suite = "tests/test_ci_trigger_closure.py"
    # Positive control: the fixture must still break a whole-block shlex, or
    # it no longer reproduces the defect and pins nothing.
    with pytest.raises(ValueError, match="No closing quotation"):
        shlex.split(commented.format(target=suite), comments=False, posix=True)

    for target, expected in (
        (suite, ()),
        ("tests", ("directory pytest target 'tests'",)),
    ):
        assert DEPS.pytest_invocation_ambiguities(commented.format(target=target)) == expected
        assert DEPS.pytest_invocation_ambiguities(comment_free.format(target=target)) == expected

    # The loss was the job's whole inferred closure, so pin that too: the
    # commented job must derive exactly the comment-free job's scope.
    [commented_job], _ = PACK.infer_job_scopes(
        [_single_run_step_job(commented.format(target=suite))]
    )
    [comment_free_job], _ = PACK.infer_job_scopes(
        [_single_run_step_job(comment_free.format(target=suite))]
    )
    assert suite in comment_free_job.paths, "the control job must derive a closure"
    assert (commented_job.paths, commented_job.fallback_paths) == (
        comment_free_job.paths,
        comment_free_job.fallback_paths,
    )


def test_run_block_quote_outside_a_full_line_comment_still_fails_closed() -> None:
    # On a command line an apostrophe is a real shell quote.
    assert (
        DEPS.pytest_invocation_ambiguities(
            "echo it's done\npython3 -m pytest tests/test_ci_trigger_closure.py"
        )
        == _UNPARSEABLE_RUN_BLOCK
    )
    # A trailing inline comment is deliberately left in place: only a line whose
    # first non-blank character is `#` is dropped, so this stays ambiguous.
    assert (
        DEPS.pytest_invocation_ambiguities(
            "python3 -m pytest tests/test_ci_trigger_closure.py  # the planner's token"
        )
        == _UNPARSEABLE_RUN_BLOCK
    )


def test_a_comment_that_names_pytest_is_not_the_invocation() -> None:
    """The first ``pytest`` word used to be taken from prose.

    self-mod-fence's agent-os step opens with a comment saying the pytest suite
    skips itself "when agentos/ is outside a sparse cone". Read as argv, that
    made ``agentos/`` a directory target, so the job stayed unscoped.
    """
    run = (
        "# the pytest suite skips itself\n"
        "# when agentos/ is outside a sparse cone\n"
        "python3 -m pytest tests/test_ci_trigger_closure.py\n"
    )
    # Positive control: whole-block tokens meet the comment's `pytest` first.
    tokens = shlex.split(run, comments=False, posix=True)
    assert tokens.index("pytest") < tokens.index("agentos/")
    assert DEPS.pytest_invocation_ambiguities(run) == ()


def test_comment_stripping_keeps_a_mid_word_hash_expansion_whole() -> None:
    """``${VAR#pattern}`` is one bash word, never the start of a comment.

    ``shlex.split(..., comments=True)`` would cut it to ``${PYTEST_TARGET`` and
    drop the rest of the line, hiding the ``tests`` directory target after it.
    """
    assert DEPS.pytest_invocation_ambiguities(
        "# strip the planner's ./ prefix\n"
        "python3 -m pytest ${PYTEST_TARGET#./} tests"
    ) == (
        "directory pytest target 'tests'",
        "dynamic pytest target '${PYTEST_TARGET#./}'",
    )


def test_invalid_inventory_enters_the_existing_full_suite_planner_fallback(
    tmp_path: Path,
) -> None:
    """Inventory doubt launches every pack; it can never publish no-work."""
    output = tmp_path / "github-output"
    sha = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=ROOT,
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()
    assert PACK.main(
        [
            "--workflow", str(MANIFEST),
            "--pack-count", "12",
            "--plan-only",
            "--github-output", str(output),
            "--tracked-paths-file", str(tmp_path / "missing.v1"),
            "--tested-tree-sha", sha,
        ]
    ) == 0
    outputs = _parse_github_output(output.read_text(encoding="utf-8"))
    assert json.loads(outputs["matrix"]) == {
        "include": [{"pack": index} for index in range(12)]
    }
    assert outputs["has_work"] == "true"
    assert outputs["plan_sha"] == ""
    assert "tracked-path inventory" in outputs["reason"]


def test_virtual_existence_oracle_is_confined_to_planner_scope_derivation() -> None:
    """The W3 oracle must never become a product/runtime filesystem law."""
    tree = ast.parse((ROOT / "scripts" / "run_ci_pack.py").read_text())
    oracle_calls = {
        "planner_path_exists": set(),
        "planner_path_is_file": set(),
        "planner_tracked_path_inventory": set(),
    }
    for function in (
        node for node in ast.walk(tree) if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    ):
        for node in ast.walk(function):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
                if node.func.id in oracle_calls:
                    oracle_calls[node.func.id].add(function.name)
    assert oracle_calls == {
        "planner_path_exists": {"_scope_coverage_findings"},
        # `infer_job_paths` is the nested implementation inside
        # `infer_job_scopes`; ast.walk reports both lexical owners.
        "planner_path_is_file": {"infer_job_paths", "infer_job_scopes"},
        "planner_tracked_path_inventory": {"plan_from_workflow"},
    }


def test_full_and_sparse_planners_are_field_and_byte_identical_over_replay_corpus(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Selection, partition, semantic identity, and plan hash survive sparsity.

    The corpus covers the handoff's distinct decision shapes. Changed path order
    is intentionally preserved, including both rename/copy sides; exact Git
    decoding is independently pinned by the hostile depth-two regression above.
    """
    repo, sha, inventory = _seed_tracked_path_repo(tmp_path)
    monkeypatch.chdir(repo)
    monkeypatch.setattr(DEPS, "ROOT", repo)
    monkeypatch.setattr(AUDIT, "ROOT", repo)

    def job(job_id: str, ordinal: int, suite: str, weight: int) -> object:
        return PACK.LegacyJob(
            job_id=job_id,
            definition={
                "if": PACK.DISABLED_IF,
                "runs-on": "ubuntu-latest",
                "steps": [
                    {
                        "name": f"{job_id} semantic proof",
                        "run": f"python -m pytest {suite}",
                    }
                ],
            },
            ordinal=ordinal,
            weight=weight,
        )

    jobs = [
        job("literal-owner", 0, "tests/test_owner.py", 5),
        job("opaque-data-owner", 1, "tests/test_opaque.py", 3),
    ]
    corpus = [
        ["tests/test_owner.py"],
        ["engine/core.py"],
        ["site/owner.json"],
        ["data/feed.json"],
        ["site/old.json", "site/owner.json"],
        [".github/ci/legacy-jobs.yml"],
        ["research/PASSIVE_NOTE.md"],
        ["brand_new_root/unknown.xyz"],
    ]
    identity = {
        "changed_from": sha,
        "scope_mode": "active",
        "pack_count": 3,
        "workflow_run_id": "replay",
        "workflow": "ci",
        "event": "pull_request",
        "role": "pr_head",
        "tested_tree_sha": sha,
        "subject_head_sha": sha,
        "base_sha": sha,
    }
    AUDIT._classify.cache_clear()
    DEPS._selector_file_analysis.cache_clear()
    full = [PACK.build_plan(jobs, changed, **identity) for changed in corpus]

    shutil.rmtree(repo / "data")
    shutil.rmtree(repo / "site")
    AUDIT._classify.cache_clear()
    DEPS._selector_file_analysis.cache_clear()
    with DEPS.planner_tracked_path_inventory(inventory, sha, root=repo):
        sparse = [PACK.build_plan(jobs, changed, **identity) for changed in corpus]

    assert len(full) == len(sparse) == len(corpus)
    for changed, full_plan, sparse_plan in zip(corpus, full, sparse, strict=True):
        assert sparse_plan.changed_paths == full_plan.changed_paths == tuple(changed)
        assert sparse_plan.changed_files_sha256 == PACK.changed_files_digest(changed)
        assert sparse_plan.to_dict() == full_plan.to_dict()
        assert sparse_plan.plan_sha256 == full_plan.plan_sha256


def test_scope_mode_kill_switch_defaults_and_can_be_disabled(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("CI_SCOPE_MODE", raising=False)
    assert PACK.parse_args(["--workflow", str(MANIFEST)]).scope_mode == "active"
    monkeypatch.setenv("CI_SCOPE_MODE", "off")
    assert PACK.parse_args(["--workflow", str(MANIFEST)]).scope_mode == "off"


def test_shadow_mode_emits_machine_readable_plan_and_job_results(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    definition = {"steps": [], "runs-on": "ubuntu-latest", "if": "${{ false }}"}
    owner = PACK.LegacyJob("owner", definition, 0, 1, ("engine/**",))
    skipped = PACK.LegacyJob("would-skip", definition, 1, 1, ("site/**",))
    jobs = [owner, skipped]
    monkeypatch.setattr(PACK, "load_legacy_jobs", lambda path, gate=None: jobs)
    _stub_planner_paths(monkeypatch, ["engine/example.py"])
    monkeypatch.setattr(PACK, "infer_job_scopes", lambda loaded: (loaded, "test scopes"))
    assert PACK.main([
        "--workflow", str(MANIFEST),
        "--changed-from", "base-sha",
        "--scope-mode", "shadow",
        "--validate-only",
        "--pack-count", "1",
    ]) == 0
    plan_line = next(
        line for line in capsys.readouterr().out.splitlines()
        if line.startswith("CI_SCOPE_SHADOW_PLAN=")
    )
    plan = json.loads(plan_line.split("=", 1)[1])
    assert plan["predicted_selected"] == ["owner"]
    assert plan["predicted_skipped"] == ["would-skip"]

    monkeypatch.setattr(PACK, "_workspace_root", lambda: ROOT)
    monkeypatch.setattr(PACK, "_restore_workspace", lambda *_args: None)
    monkeypatch.setattr(
        PACK,
        "_run_job",
        lambda job, **_kwargs: PACK.JobExecution(
            logical_job_id=job.job_id,
            job_exec_sha256=PACK.semantic_job_digest(job),
            infrastructure={"outcome": "passed"},
            steps=(),
            failure=None,
        ),
    )
    assert PACK.execute_pack(jobs, shadow_predicted=frozenset({"owner"})) == 0
    records = [
        json.loads(line.split("=", 1)[1])
        for line in capsys.readouterr().out.splitlines()
        if line.startswith("CI_SCOPE_SHADOW_RESULT=")
    ]
    assert records == [
        {"job": "owner", "predicted_selected": True, "status": "passed"},
        {"job": "would-skip", "predicted_selected": False, "status": "passed"},
    ]


def test_execute_pack_emits_legacy_job_annotations_and_failed_job_ids(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """merge_on_green parses `title=legacy-job-<id>` for live-inherited reds."""
    definition = {
        "steps": [{"name": "semantic proof", "run": "true"}],
        "runs-on": "ubuntu-latest",
    }
    jobs = [
        PACK.LegacyJob("unrun-government-revenue", definition, 0, 1, ("engine/**",)),
        PACK.LegacyJob("other", definition, 1, 1, ("engine/**",)),
    ]
    monkeypatch.setattr(PACK, "_workspace_root", lambda: ROOT)
    monkeypatch.setattr(PACK, "_restore_workspace", lambda *_args: None)

    def fake_run(job, **_kwargs):
        failed = job.job_id == "unrun-government-revenue"
        specs = PACK.semantic_step_specs(job)
        return PACK.JobExecution(
            logical_job_id=job.job_id,
            job_exec_sha256=PACK.semantic_job_digest(job),
            infrastructure={"outcome": "passed"},
            steps=tuple(
                {
                    **spec.plan_dict(),
                    "outcome": "failed" if failed else "passed",
                    "failure_signature": None,
                }
                for spec in specs
            ),
            failure=(f"{job.job_id}: step 'pytest' exited 1" if failed else None),
        )

    monkeypatch.setattr(PACK, "_run_job", fake_run)
    assert PACK.execute_pack(jobs) == 1
    out = capsys.readouterr().out
    assert any(
        line.startswith("::error title=legacy-job-unrun-government-revenue::")
        for line in out.splitlines()
    ), out
    failed = next(
        line for line in out.splitlines() if line.startswith("CI_PACK_FAILED_JOBS=")
    )
    assert json.loads(failed.split("=", 1)[1]) == ["unrun-government-revenue"]


def test_execution_timing_observations_do_not_change_semantic_fragment(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """Timing is useful evidence, never an input to semantic proof authority."""
    definition = {
        "steps": [{"name": "semantic proof", "run": "true"}],
        "runs-on": "ubuntu-latest",
    }
    job = PACK.LegacyJob("demo", definition, 0, 1, ("engine/**",))
    monkeypatch.setattr(PACK, "_workspace_root", lambda: ROOT)
    monkeypatch.setattr(PACK, "_restore_workspace", lambda *_args: None)
    monkeypatch.setattr(PACK, "_dependency_environment", lambda *_args, **_kwargs: {})

    def fake_run(current, **_kwargs):
        specs = PACK.semantic_step_specs(current)
        return PACK.JobExecution(
            logical_job_id=current.job_id,
            job_exec_sha256=PACK.semantic_job_digest(current),
            infrastructure={"outcome": "passed"},
            steps=tuple(
                {
                    **spec.plan_dict(),
                    "outcome": "passed",
                    "failure_signature": None,
                }
                for spec in specs
            ),
            failure=None,
        )

    monkeypatch.setattr(PACK, "_run_job", fake_run)
    without_timing = tmp_path / "without-timing.json"
    with_timing = tmp_path / "with-timing.json"
    observations = tmp_path / "timing-observations.jsonl"
    blocked_parent = tmp_path / "not-a-directory"
    blocked_parent.write_text("not a directory\n", encoding="utf-8")
    unwritable_observations = blocked_parent / "timing-observations.jsonl"
    with_unwritable_timing = tmp_path / "with-unwritable-timing.json"

    assert PACK.execute_pack([job], emit_semantic_fragment=without_timing) == 0
    ticks = iter((1_000, 1_100, 1_200, 1_500, 1_600, 1_700, 1_800, 2_100))
    monkeypatch.setattr(PACK.time, "monotonic_ns", lambda: next(ticks))
    assert (
        PACK.execute_pack(
            [job],
            emit_semantic_fragment=with_timing,
            emit_timing_observations=observations,
        )
        == 0
    )
    assert (
        PACK.execute_pack(
            [job],
            emit_semantic_fragment=with_unwritable_timing,
            emit_timing_observations=unwritable_observations,
        )
        == 0
    )

    assert with_timing.read_bytes() == without_timing.read_bytes()
    assert with_unwritable_timing.read_bytes() == without_timing.read_bytes()
    assert not unwritable_observations.exists()
    assert "::warning title=ci timing telemetry degraded::" in capsys.readouterr().out
    assert [
        json.loads(line)
        for line in observations.read_text(encoding="utf-8").splitlines()
    ] == [
        {
            "duration_ns": 100,
            "ended_monotonic_ns": 1_100,
            "logical_job_id": "demo",
            "phase": "dependency_install",
            "started_monotonic_ns": 1_000,
            "status": "observed",
        },
        {
            "duration_ns": 300,
            "ended_monotonic_ns": 1_500,
            "logical_job_id": "demo",
            "phase": "test",
            "started_monotonic_ns": 1_200,
            "status": "observed",
        },
    ]


def test_packs_stay_balanced_over_the_selected_subset() -> None:
    """Balance must be computed on the SELECTION, not the full manifest.

    Otherwise a scoped run leaves whole packs empty while one pack carries the
    work, and time-to-green gets worse instead of better.
    """
    jobs = PACK.load_legacy_jobs(MANIFEST)
    subset = sorted(jobs, key=lambda job: -job.weight)[:40]
    packs = PACK.partition_jobs(subset, 4)
    weights = [sum(job.weight for job in pack) for pack in packs]
    assert sum(len(pack) for pack in packs) == len(subset)
    assert max(weights) - min(weights) <= max(job.weight for job in subset)


# ── the plan is a contract between ci-plan and twelve packs ──────────────────
#
# Wave B (2026-08-11) moved the selection decision out of main() into
# build_plan(): ci-plan publishes one hashed plan, and every pack RECOMPUTES it
# and refuses when its own hash disagrees. So the tests below are not "does the
# plan look sensible" — they are the two ways that arrangement goes silently
# wrong.
#
#   1. THE PLAN NARROWS WHEN IT HAS NO RIGHT TO. `has_work: false` skips every
#      pack, and ci-gate then publishes an affirmative success anyway (it must:
#      merge_on_green requires a real pass, because absence of red is not a pass
#      — #4779). So a plan that wrongly proves no-work merges a completely unrun
#      PR green. Every widening rule is therefore re-pinned HERE, through
#      build_plan, not only through select_jobs: the rules moved, and a rule that
#      is correct in select_jobs but unreachable from build_plan is no rule.
#   2. THE PLAN AND THE EXECUTION DISAGREE. Twelve runners each deriving the
#      partition independently is exactly the shape a nondeterministic input
#      splits, and the resulting green means nothing. The parity test walks EVERY
#      index, because a divergence that only hits pack 7 is invisible to a test
#      that checks pack 0.


def _plan_job(
    job_id: str,
    ordinal: int,
    *,
    weight: int = 1,
    paths: tuple[str, ...] = (),
) -> object:
    """A minimal LegacyJob fixture: id, order, weight, hand-written scope."""
    return PACK.LegacyJob(
        job_id=job_id,
        definition={"if": PACK.DISABLED_IF, "runs-on": "ubuntu-latest", "steps": []},
        ordinal=ordinal,
        weight=weight,
        paths=paths,
    )


@pytest.fixture(autouse=True)
def _isolate_pack_runner_planner_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """Pack jobs inject planner env; unit tests must not inherit the live PR diff.

    Measured 2026-08-13: main ci.yml run 31746772926 and PR #5560 pack-1 redded
    workflow-yaml because packing-contract tests monkeypatched ``changed_files``
    while ``plan_from_workflow`` reads ``resolve_changed_files`` →
    ``CI_CHANGED_FILES_JSON``. On main the value was ``null`` (full suite); on
    #5560 it was the live 81-file PR list. Tests expecting an unscoped/full
    fixture plan then asserted against the hosted runner's diff.

    ``CI_CHANGED_FILES_FILE`` joined the list on 2026-08-14 and is now the one
    that matters: it is what every pack exports after downloading the
    changed-file artifact, and it OUT-RANKS the inline form, so leaving it
    ambient would leak the live PR diff into these fixtures exactly as #5560's
    inline value did.

    Semantic identity env joined on 2026-08-15 (PR #5750 pack-1 / job
    95003903089). ``build_plan`` now infers ``role=pr_head`` from
    ``GITHUB_EVENT_NAME=pull_request`` and then refuses a full-suite plan
    (``changed is None``) as "a PR semantic plan requires an exact
    changed-file inventory". Packing-contract tests that call
    ``plan_from_workflow(..., changed_from=None)`` or ``--plan-only``
    without ``--event/--role`` inherited the live PR event and the
    hosted-runner packing contract exited 1. Strip the identity vars so
    those tests keep the local ``workflow_dispatch`` / ``main`` default;
    tests that want a PR plan pass ``event``/``role`` or a file list
    explicitly. The production ci-plan path still passes ``--event`` and
    ``--role`` on the command line, so this does not weaken that gate.
    """
    for name in (
        "CI_CHANGED_FILES_FILE",
        "CI_CHANGED_FILES_JSON",
        "CI_SCOPE_MODE",
        "CI_DYNAMIC_MATRIX_MODE",
        "GITHUB_EVENT_NAME",
        "CI_SEMANTIC_ROLE",
        "CI_TESTED_TREE_SHA",
        "CI_SUBJECT_HEAD_SHA",
        "CI_BASE_SHA",
    ):
        monkeypatch.delenv(name, raising=False)


def _stub_planner_paths(
    monkeypatch: pytest.MonkeyPatch, paths: list[str] | None
) -> None:
    """Pin the #5564 production path (resolve_changed_files), not git."""
    monkeypatch.setattr(
        PACK,
        "resolve_changed_files",
        lambda changed_from, explicit_json=None, explicit_file=None, _paths=paths: (
            _paths
        ),
    )


def test_packing_contract_ignores_ambient_ci_changed_files_json(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The leak that redded every PR's pack-1 after #5564.

    Plant an 81-file live-PR list (the #5560 shape) as ambient env. The fixture
    still passes ``engine/example.py``. would-skip (``site/**``) must stay
    skipped — if this selects would-skip, the test inherited the hosted
    runner's diff and pack-1 is red on every unrelated PR.
    """
    ambient = [f"site/leak_{index}.html" for index in range(81)]
    monkeypatch.setenv("CI_CHANGED_FILES_JSON", json.dumps(ambient))
    assert PACK.resolve_changed_files("base-sha") == ambient
    _stub_planner_paths(monkeypatch, ["engine/example.py"])
    _freeze_scope_inference(monkeypatch)
    jobs = [
        _plan_job("owner", 0, paths=("engine/**",)),
        _plan_job("would-skip", 1, paths=("site/**",)),
    ]
    monkeypatch.setattr(PACK, "load_legacy_jobs", lambda path, gate=None: list(jobs))
    plan = PACK.plan_from_workflow(
        MANIFEST, changed_from="base-sha", scope_mode="active", pack_count=12
    )
    assert set(plan.eligible_job_ids) == {"owner"}
    assert plan.skipped_job_ids == ("would-skip",)
    assert PACK.resolve_changed_files("base-sha") == ["engine/example.py"]


def test_packing_contract_strips_ambient_pr_event_identity(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The leak that redded pack-1 on PR #5750 head 168e8e1f.

    Autouse isolation must leave ``GITHUB_EVENT_NAME`` unset so
    ``_full_plan()`` mints a local main plan. Planting the live Actions
    PR event afterwards must raise the inventory ManifestError — that is
    the law that fired inside the packing contract when the fixture
    still inherited ``pull_request``.
    """
    assert os.environ.get("GITHUB_EVENT_NAME") != "pull_request"
    assert "CI_SEMANTIC_ROLE" not in os.environ
    plan = _full_plan()
    assert plan.event == "workflow_dispatch"
    assert plan.role == "main"
    assert plan.changed_from is None
    monkeypatch.setenv("GITHUB_EVENT_NAME", "pull_request")
    with pytest.raises(PACK.ManifestError, match="exact changed-file inventory"):
        _full_plan()


def _freeze_scope_inference(monkeypatch: pytest.MonkeyPatch) -> None:
    """Keep the fixtures' hand-written scopes; real inference would erase them.

    infer_job_scopes derives ownership from a job's OWN commands, so a fixture
    job with no steps comes back UNSCOPED — which means always-on — and every
    selection assertion below would then pass for the wrong reason. It is also
    the expensive half of a real plan (106 s over the 180-job manifest, measured
    2026-08-11); a synthetic test must not pay it.
    """
    monkeypatch.setattr(
        PACK, "infer_job_scopes", lambda jobs: (list(jobs), "fixture scopes")
    )


def _parse_github_output(text: str) -> dict[str, str]:
    """Parse a `$GITHUB_OUTPUT` file the way the Actions runner does.

    Only the heredoc form is accepted, on purpose. A bare `name=value` line
    cannot carry the newline a multi-line ManifestError puts into `reason`, so
    emitting one would truncate the value GitHub hands to ci-gate — and the
    truncation would be invisible until a manifest actually broke.
    """
    values: dict[str, str] = {}
    lines = text.splitlines()
    index = 0
    while index < len(lines):
        head = lines[index]
        assert "<<" in head, f"not a heredoc $GITHUB_OUTPUT entry: {head!r}"
        name, delimiter = head.split("<<", 1)
        index += 1
        body: list[str] = []
        while lines[index] != delimiter:
            body.append(lines[index])
            index += 1
        values[name] = "\n".join(body)
        index += 1
    return values


def _full_plan() -> object:
    """The real manifest's baseline plan: no --changed-from, so no inference."""
    return PACK.plan_from_workflow(
        MANIFEST, changed_from=None, scope_mode="active", pack_count=12
    )


def _never_execute(*args: object, **kwargs: object) -> int:
    raise AssertionError("execute_pack must not be reached on this path")


DATA_HEALTH = ROOT / ".github" / "workflows" / "data-health.yml"


def test_every_data_health_trigger_can_actually_mint_a_plan() -> None:
    """The lane that took the data-gated jobs off the merge gate must be able to run.

    ``data-health.yml`` fires on ``workflow_run`` (daily completed) and on a
    13:30 UTC ``schedule`` backstop, and neither passes ``--role``/``--event``,
    so both resolve to role ``main`` from the ambient ``GITHUB_EVENT_NAME``.
    Until 2026-08-19 the supported set held only ``main/workflow_dispatch``, so
    both raised ManifestError BEFORE any legacy job ran: run 32262001614
    (schedule) died ``main/schedule is unsupported``, exit 2, in all six packs.
    That is not a fail-closed that protects anything — it silently emptied the
    only lane that grades the 74 ``gate: data`` jobs against a freshly written
    data tree, which is the entire promise W2 made when it moved them off ci.yml.

    This asserts the workflow's OWN trigger list, so adding a trigger there
    without teaching the planner reds here instead of going quiet in production.
    """
    workflow = _yaml(DATA_HEALTH)
    triggers = set((workflow.get("on") or workflow.get(True)).keys())
    assert triggers, "data-health.yml must declare triggers"
    for event in sorted(triggers):
        assert ("main", event) in PACK.SUPPORTED_PLAN_ROLE_EVENTS, (
            f"data-health.yml fires on {event!r} but the planner refuses "
            f"main/{event}; that pack dies at exit 2 before a single job runs"
        )


def test_a_main_role_plan_from_a_data_health_trigger_carries_every_data_job(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Widening the transport must not have relaxed what ``main`` MEANS.

    Both new events describe the shape ``main`` already required — a whole-tree
    run at one checked-out SHA with no diff — so the plan they mint must be the
    same full ``gate: data`` suite the manual dispatch minted, and it must carry
    ``house-law-registry``: the guard whose input (the newest
    ``data/symbol_directory`` snapshot) only ever moves on a nightly commit.
    """
    monkeypatch.setenv("GITHUB_SHA", "0" * 40)
    monkeypatch.delenv("CI_SEMANTIC_ROLE", raising=False)
    monkeypatch.delenv("CI_TESTED_TREE_SHA", raising=False)
    monkeypatch.delenv("CI_SUBJECT_HEAD_SHA", raising=False)
    monkeypatch.delenv("CI_BASE_SHA", raising=False)

    plans = {}
    for event in ("workflow_dispatch", "workflow_run", "schedule"):
        monkeypatch.setenv("GITHUB_EVENT_NAME", event)
        plan = PACK.plan_from_workflow(
            MANIFEST, changed_from=None, scope_mode="active",
            pack_count=6, gate="data",
        )
        assert plan.role == "main" and plan.event == event
        assert plan.changed_from is None
        plans[event] = {job for pack in plan.pack_jobs for job in pack}

    assert "house-law-registry" in plans["schedule"]
    assert plans["schedule"] == plans["workflow_dispatch"] == plans["workflow_run"]


def test_the_supported_role_event_set_stays_closed() -> None:
    """An unreasoned combination must still fail closed, both minting and consuming.

    The widening above is two named transports for a role whose substance is
    enforced elsewhere; it is not permission for any event to plan anything.
    """
    assert ("main", "push") not in PACK.SUPPORTED_PLAN_ROLE_EVENTS
    assert ("pr_head", "schedule") not in PACK.SUPPORTED_PLAN_ROLE_EVENTS
    assert ("pr_head", "workflow_dispatch") not in PACK.SUPPORTED_PLAN_ROLE_EVENTS
    # One constant, both gates: the planner and the authoritative-plan reader
    # cannot drift into disagreeing about what a legal plan is.
    source = (ROOT / "scripts" / "run_ci_pack.py").read_text()
    assert source.count("(role, event) not in SUPPORTED_PLAN_ROLE_EVENTS") == 2


def test_runner_contract_is_the_v2_linux_x86_64_string() -> None:
    """RUNNER_CONTRACT v2 (#6351 P0R bridge): a truthful logical claim about
    the runtime `attest_execution_profile` enforces, replacing the
    "ubuntu-latest" image name the v1 string aspirationally described.
    """
    assert PACK.RUNNER_CONTRACT == "ci-pack/linux-x86_64/python-3.12.13/node-20/v2"


def test_diagnostic_canary_workflow_constant_names_the_exact_workflow() -> None:
    assert PACK.DIAGNOSTIC_CANARY_WORKFLOW == "infrastructure-selfhosted-ci-canary"
    assert PACK.TRUSTED_EXECUTOR_WORKFLOW == "trusted-ci-executor"
    assert PACK.DIAGNOSTIC_PR_WORKFLOWS == frozenset(
        {PACK.DIAGNOSTIC_CANARY_WORKFLOW, PACK.TRUSTED_EXECUTOR_WORKFLOW}
    )


def test_runner_contract_v2_participates_in_the_job_semantic_digest(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Changing the runtime contract must change what every job's digest
    means — that is the whole point of a semantic contract version bump.
    """
    job = _plan_job("demo", 0)
    before = PACK.semantic_job_digest(job)
    monkeypatch.setattr(
        PACK, "RUNNER_CONTRACT", "ci-pack/linux-x86_64/python-3.12.13/node-20/v3"
    )
    after = PACK.semantic_job_digest(job)
    assert before != after


def test_build_plan_admits_the_diagnostic_pair_only_for_its_exact_workflow_name(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``(pr_head, workflow_dispatch)`` is admitted ONLY when ``workflow``
    equals the exact canary name — SUPPORTED_PLAN_ROLE_EVENTS itself stays
    closed (pinned separately by test_the_supported_role_event_set_stays_closed).
    """
    _freeze_scope_inference(monkeypatch)
    jobs = [_plan_job("demo", 0)]
    base = "b" * 40
    plan = PACK.build_plan(
        jobs,
        ["engine/example.py"],
        changed_from=base,
        scope_mode="active",
        pack_count=1,
        workflow=PACK.DIAGNOSTIC_CANARY_WORKFLOW,
        event="workflow_dispatch",
        role="pr_head",
        tested_tree_sha="a" * 40,
        subject_head_sha="c" * 40,
        base_sha=base,
    )
    assert plan.role == "pr_head"
    assert plan.event == "workflow_dispatch"
    assert plan.workflow == PACK.DIAGNOSTIC_CANARY_WORKFLOW

    for other_workflow in ("ci", "some-other-workflow"):
        with pytest.raises(PACK.ManifestError, match="unsupported"):
            PACK.build_plan(
                jobs,
                ["engine/example.py"],
                changed_from=base,
                scope_mode="active",
                pack_count=1,
                workflow=other_workflow,
                event="workflow_dispatch",
                role="pr_head",
                tested_tree_sha="a" * 40,
                subject_head_sha="c" * 40,
                base_sha=base,
            )


def test_p3a_executor_uses_the_same_closed_diagnostic_plan_admission(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _freeze_scope_inference(monkeypatch)
    base = "b" * 40
    plan = PACK.build_plan(
        [_plan_job("demo", 0)],
        ["engine/example.py"],
        changed_from=base,
        scope_mode="active",
        pack_count=1,
        workflow=PACK.TRUSTED_EXECUTOR_WORKFLOW,
        event="workflow_dispatch",
        role="pr_head",
        tested_tree_sha="a" * 40,
        subject_head_sha="c" * 40,
        base_sha=base,
    )
    assert plan.workflow == PACK.TRUSTED_EXECUTOR_WORKFLOW
    assert plan.role == "pr_head"
    assert plan.event == "workflow_dispatch"


def test_build_plan_still_requires_every_pr_head_invariant_for_the_diagnostic_pair(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The diagnostic pair is a narrower ADMISSION, not a relaxed invariant:
    exact changed-file inventory and changed_from == base_sha still apply
    (spec item A.2).
    """
    _freeze_scope_inference(monkeypatch)
    jobs = [_plan_job("demo", 0)]
    with pytest.raises(PACK.ManifestError, match="exact changed-file inventory"):
        PACK.build_plan(
            jobs,
            None,
            changed_from="b" * 40,
            scope_mode="active",
            pack_count=1,
            workflow=PACK.DIAGNOSTIC_CANARY_WORKFLOW,
            event="workflow_dispatch",
            role="pr_head",
            tested_tree_sha="a" * 40,
            subject_head_sha="c" * 40,
            base_sha="b" * 40,
        )
    with pytest.raises(PACK.ManifestError, match="changed_from must equal"):
        PACK.build_plan(
            jobs,
            ["engine/example.py"],
            changed_from="b" * 40,
            scope_mode="active",
            pack_count=1,
            workflow=PACK.DIAGNOSTIC_CANARY_WORKFLOW,
            event="workflow_dispatch",
            role="pr_head",
            tested_tree_sha="a" * 40,
            subject_head_sha="c" * 40,
            base_sha="f" * 40,
        )


def test_build_plan_refuses_the_old_broken_main_dispatch_with_changed_from(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Mutation-lock (#6351 addendum): the pre-fix canary passed
    ``--changed-from`` unconditionally, including for the ``pr_number=0``
    main dispatch. That shape must stay refused — the fix is to stop
    sending it for pr0, never to admit it.
    """
    _freeze_scope_inference(monkeypatch)
    jobs = [_plan_job("demo", 0)]
    with pytest.raises(PACK.ManifestError, match="main semantic plan"):
        PACK.build_plan(
            jobs,
            ["engine/example.py"],
            changed_from="a" * 40,
            scope_mode="active",
            pack_count=1,
            workflow=PACK.DIAGNOSTIC_CANARY_WORKFLOW,
            event="workflow_dispatch",
            role="main",
            tested_tree_sha="a" * 40,
            subject_head_sha="a" * 40,
            base_sha="a" * 40,
        )


def test_attest_execution_profile_refuses_on_a_non_linux_host(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The real guard refuses a deterministically simulated non-Linux host."""
    monkeypatch.setattr(PACK.platform, "system", lambda: "Darwin")
    with pytest.raises(PACK.ExecutionProfileError, match="Linux"):
        PACK.attest_execution_profile(None)


def test_attest_execution_profile_checks_system_machine_python_node_in_order(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(PACK.platform, "system", lambda: "Darwin")
    with pytest.raises(PACK.ExecutionProfileError, match="Linux"):
        PACK.attest_execution_profile(None)

    monkeypatch.setattr(PACK.platform, "system", lambda: "Linux")
    monkeypatch.setattr(PACK.platform, "machine", lambda: "arm64")
    with pytest.raises(PACK.ExecutionProfileError, match="x86_64"):
        PACK.attest_execution_profile(None)

    monkeypatch.setattr(PACK.platform, "machine", lambda: "x86_64")
    monkeypatch.setattr(PACK.platform, "python_version", lambda: "3.12.14")
    with pytest.raises(PACK.ExecutionProfileError, match="3.12.13"):
        PACK.attest_execution_profile(None)

    monkeypatch.setattr(PACK.platform, "python_version", lambda: "3.12.13")
    monkeypatch.setattr(PACK, "_node_major_version", lambda: 18)
    with pytest.raises(PACK.ExecutionProfileError, match="node 20"):
        PACK.attest_execution_profile(None)

    monkeypatch.setattr(PACK, "_node_major_version", lambda: 20)
    # All four checks satisfied and no plan -> success (tree-sha check skipped).
    PACK.attest_execution_profile(None)


def test_attest_execution_profile_checks_checkout_head_against_the_plan(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(PACK.platform, "system", lambda: "Linux")
    monkeypatch.setattr(PACK.platform, "machine", lambda: "x86_64")
    monkeypatch.setattr(PACK.platform, "python_version", lambda: "3.12.13")
    monkeypatch.setattr(PACK, "_node_major_version", lambda: 20)
    plan = _full_plan()
    monkeypatch.setattr(PACK, "_workspace_root", lambda: Path("/tmp"))
    monkeypatch.setattr(PACK, "_current_commit_sha", lambda root: "0" * 40)
    with pytest.raises(PACK.ExecutionProfileError, match="does not match attested"):
        PACK.attest_execution_profile(plan)

    monkeypatch.setattr(PACK, "_current_commit_sha", lambda root: plan.tested_tree_sha)
    PACK.attest_execution_profile(plan)  # no raise


def test_plan_is_deterministic() -> None:
    first = _full_plan()
    second = _full_plan()
    assert first == second
    assert first.plan_sha256 == second.plan_sha256
    # Not satisfied by two empty plans agreeing about nothing.
    assert any(first.pack_jobs)


def test_measured_heavy_weights_rebalance_without_changing_execution_proofs(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Calibration changes the attested assignment, never the work it proves."""
    calibrated = _full_plan()
    for job_id in ("fif-kernel-guards", "earnings-economic-dossier"):
        monkeypatch.delitem(PACK.OBSERVED_COMMAND_SECONDS, job_id, raising=False)
    heuristic = _full_plan()

    assert calibrated.eligible_job_ids == heuristic.eligible_job_ids
    assert calibrated.pack_count == heuristic.pack_count == 12
    assert calibrated.nonempty_pack_indices == heuristic.nonempty_pack_indices
    assert calibrated.pack_jobs != heuristic.pack_jobs
    assert calibrated.plan_sha256 != heuristic.plan_sha256
    before = {job.logical_job_id: job for job in heuristic.semantic_jobs}
    for job in calibrated.semantic_jobs:
        assert job.job_exec_sha256 == before[job.logical_job_id].job_exec_sha256
        assert job.steps == before[job.logical_job_id].steps
    flattened = [job_id for pack in calibrated.pack_jobs for job_id in pack]
    assert len(flattened) == len(set(flattened)) == len(calibrated.eligible_job_ids)
    assert set(flattened) == set(calibrated.eligible_job_ids)
    heavy = {"ci-control-plane-contracts", "fif-kernel-guards", "earnings-economic-dossier"}
    assert len({job.pack_index for job in calibrated.semantic_jobs if job.logical_job_id in heavy}) == 3


def test_plan_hash_covers_job_assignment_but_not_prose() -> None:
    """The hash is what makes twelve independent derivations one decision."""
    plan = _full_plan()
    payload = PACK.plan_hash_payload(
        workflow_run_id=plan.workflow_run_id,
        workflow=plan.workflow,
        event=plan.event,
        role=plan.role,
        tested_tree_sha=plan.tested_tree_sha,
        subject_head_sha=plan.subject_head_sha,
        base_sha=plan.base_sha,
        authority_changed=plan.authority_changed,
        changed_from=plan.changed_from,
        scope_mode=plan.scope_mode,
        changed_files_sha256=plan.changed_files_sha256,
        pack_count=plan.pack_count,
        eligible_job_ids=plan.eligible_job_ids,
        pack_jobs=plan.pack_jobs,
        pack_weights=plan.pack_weights,
        semantic_jobs=plan.semantic_jobs,
    )
    assert PACK._canonical_digest(payload) == plan.plan_sha256

    # WHICH DIFF, not merely which jobs (2026-08-14). The list left the job
    # outputs for an artifact nothing else hashes, so its digest has to be part
    # of the decision identity: a pack that downloaded the wrong file recomputes
    # a different plan sha and the parity check below refuses it. Without this
    # key that pack would pass parity and scope its guards to somebody else's
    # diff — see `test_a_pack_refuses_a_changed_file_list_it_cannot_prove`.
    assert payload["changed_files_sha256"] == plan.changed_files_sha256
    assert (
        PACK._canonical_digest({**payload, "changed_files_sha256": "f" * 64})
        != plan.plan_sha256
    )

    # Move ONE job to a different pack: same jobs, same membership, new plan.
    moved = [list(pack) for pack in plan.pack_jobs]
    assert moved[1], "fixture assumption: pack 1 carries jobs on the full suite"
    moved[2].append(moved[1].pop())
    assert PACK._canonical_digest({**payload, "pack_jobs": moved}) != plan.plan_sha256

    # Reordering the eligible list changes nothing about MEMBERSHIP and
    # everything about the partition: partition_jobs is greedy over
    # (-weight, ordinal), so the sequence is an input, which is why the payload
    # keeps plan order instead of sorting it.
    reordered = list(reversed(plan.eligible_job_ids))
    assert (
        PACK._canonical_digest({**payload, "eligible_job_ids": reordered})
        != plan.plan_sha256
    )

    # Prose is excluded BY CONSTRUCTION. If `reason` were hashed, rewording one
    # diagnostic would make every pack refuse a plan selecting identical jobs.
    assert "reason" not in payload
    assert "scope_summary" not in payload


def test_plan_keeps_the_fixed_twelve_pack_assignment() -> None:
    """Wave B changed WHERE the partition is decided, never WHAT it decides."""
    plan = _full_plan()
    assert plan.pack_count == 12
    assert len(plan.pack_jobs) == 12
    assert len(plan.pack_weights) == 12
    flattened = [job_id for pack in plan.pack_jobs for job_id in pack]
    assert sorted(flattened) == sorted(plan.eligible_job_ids)
    assert len(flattened) == len(set(flattened))
    by_id = {job.job_id: job for job in plan.scoped_jobs}
    for index, pack in enumerate(plan.pack_jobs):
        assert plan.pack_weights[index] == sum(by_id[job_id].weight for job_id in pack)
    # Same partition the standalone function produces from the same jobs.
    packs = PACK.partition_jobs(
        [by_id[job_id] for job_id in plan.eligible_job_ids], 12
    )
    assert plan.pack_jobs == tuple(
        tuple(job.job_id for job in pack) for pack in packs
    )


def test_full_suite_plan_emits_all_twelve_packs() -> None:
    """Main's baseline passes no --changed-from, so nothing may be narrowed."""
    plan = _full_plan()
    assert plan.reason == "full suite: changed-file set unavailable"
    assert plan.nonempty_pack_indices == tuple(range(12))
    assert plan.has_work is True
    assert plan.matrix() == {"include": [{"pack": index} for index in range(12)]}
    assert plan.skipped_job_ids == ()


def test_only_non_empty_pack_indices_reach_the_matrix(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _freeze_scope_inference(monkeypatch)
    jobs = [
        _plan_job("heavy", 0, weight=9),
        _plan_job("middle", 1, weight=5),
        _plan_job("light", 2, weight=3),
    ]
    plan = PACK.build_plan(
        jobs, None, changed_from=None, scope_mode="active", pack_count=12
    )
    # The DOCUMENT still describes all twelve packs; only the MATRIX narrows.
    assert len(plan.pack_jobs) == 12
    assert plan.to_dict()["packs"][11] == {"index": 11, "weight": 0, "jobs": []}
    assert plan.nonempty_pack_indices == (0, 1, 2)
    assert plan.matrix() == {"include": [{"pack": 0}, {"pack": 1}, {"pack": 2}]}
    assert plan.has_work is True


def test_one_selected_job_emits_one_pack(monkeypatch: pytest.MonkeyPatch) -> None:
    _freeze_scope_inference(monkeypatch)
    jobs = [
        _plan_job("owner", 0, paths=("engine/**",)),
        _plan_job("elsewhere", 1, paths=("site/**",)),
    ]
    plan = PACK.build_plan(
        jobs,
        ["engine/example.py"],
        changed_from="base-sha",
        scope_mode="active",
        pack_count=12,
    )
    assert plan.eligible_job_ids == ("owner",)
    assert plan.skipped_job_ids == ("elsewhere",)
    assert plan.nonempty_pack_indices == (0,)
    assert plan.matrix() == {"include": [{"pack": 0}]}
    assert plan.has_work is True


def test_passive_unowned_markdown_can_plan_no_work(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The ONE lawful road to has_work=false: an affirmative empty selection.

    Unreachable on the production manifest, which always carries unscoped
    always-on jobs — so it is pinned on fixtures rather than left untested until
    the day selection narrows enough to reach it in anger.
    """
    _freeze_scope_inference(monkeypatch)
    jobs = [
        _plan_job("engine-owner", 0, paths=("engine/**",)),
        _plan_job("site-owner", 1, paths=("site/**",)),
    ]
    plan = PACK.build_plan(
        jobs,
        ["research/CONTINUATION_HANDOFF.md"],
        changed_from="base-sha",
        scope_mode="active",
        pack_count=12,
    )
    assert plan.eligible_job_ids == ()
    assert plan.nonempty_pack_indices == ()
    assert plan.matrix() == {"include": []}
    assert plan.has_work is False
    document = plan.to_dict()
    assert document["has_work"] is False
    assert len(document["packs"]) == 12
    assert all(entry["jobs"] == [] for entry in document["packs"])


def test_unknown_top_level_path_does_not_widen_the_plan_to_the_full_suite(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _freeze_scope_inference(monkeypatch)
    jobs = [
        _plan_job("engine-owner", 0, paths=("engine/**",)),
        _plan_job("site-owner", 1, paths=("site/**",)),
        _plan_job("always-on", 2, paths=()),
    ]
    plan = PACK.build_plan(
        jobs,
        ["brand_new_root/unowned_runtime.xyz"],
        changed_from="base-sha",
        scope_mode="active",
        pack_count=12,
    )
    assert plan.eligible_job_ids == ("always-on",)
    assert "did not widen" in plan.reason
    assert plan.has_work is True



def test_proven_manifest_job_delta_forces_changed_job_without_full_suite(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _freeze_scope_inference(monkeypatch)
    jobs = [
        _plan_job("engine-owner", 0, paths=("engine/**",)),
        _plan_job("manifest-owner", 1, paths=("site/**",)),
        _plan_job("elsewhere", 2, paths=("docs/**",)),
        _plan_job("always-on", 3, paths=()),
    ]
    plan = PACK.build_plan(
        jobs,
        [PACK.LEGACY_MANIFEST_PATH, "engine/market_state.py"],  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        changed_from="a" * 40,
        scope_mode="active",
        pack_count=12,
        manifest_changed_job_ids=("manifest-owner",),
    )

    assert set(plan.eligible_job_ids) == {
        "engine-owner",
        "manifest-owner",
        "always-on",
    }
    assert "full suite" not in plan.reason
    assert "bounded manifest job delta" in plan.reason
    assert plan.scope_summary == "fixture scopes"


def test_global_invalidator_widens_the_plan_without_inferring_scopes(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A global invalidator changes what any job MEANS — and short-circuits.

    Skipping inference here is not an optimisation detail worth a comment
    elsewhere: it is a minute of work whose entire answer select_jobs is about
    to discard, paid on the one path where CI is already running everything.
    """
    calls: list[object] = []

    def record(jobs: object) -> tuple[list[object], str]:
        calls.append(jobs)
        return list(jobs), "inference ran"

    monkeypatch.setattr(PACK, "infer_job_scopes", record)
    jobs = [
        _plan_job("engine-owner", 0, paths=("engine/**",)),
        _plan_job("site-owner", 1, paths=("site/**",)),
    ]
    plan = PACK.build_plan(
        jobs,
        ["scripts/run_ci_pack.py", "engine/market_state.py"],  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        changed_from="base-sha",
        scope_mode="active",
        pack_count=12,
    )
    assert set(plan.eligible_job_ids) == {"engine-owner", "site-owner"}
    assert "global invalidator" in plan.reason
    assert plan.scope_summary == "scope inference not needed"
    assert calls == []
    assert plan.has_work is True


def test_rename_plans_both_the_old_and_the_new_owner(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """`--find-renames` emits BOTH sides; the plan must select both owners.

    Deleting or renaming a subject has to re-run the job that owned its OLD
    path — that job is often the only thing that would notice the subject went
    away — while the new path selects its new owner.
    """
    _freeze_scope_inference(monkeypatch)
    jobs = [
        _plan_job("owns-old", 0, paths=("engine/old.py",)),
        _plan_job("owns-new", 1, paths=("engine/new.py",)),
        _plan_job("elsewhere", 2, paths=("site/**",)),
    ]
    monkeypatch.setattr(PACK, "load_legacy_jobs", lambda path, gate=None: list(jobs))
    _stub_planner_paths(monkeypatch, ["engine/old.py", "engine/new.py"])
    plan = PACK.plan_from_workflow(
        MANIFEST, changed_from="base-sha", scope_mode="active", pack_count=12
    )
    assert set(plan.eligible_job_ids) == {"owns-old", "owns-new"}
    assert plan.skipped_job_ids == ("elsewhere",)

    # Non-vacuity: with only the new side in the diff, the old owner is skipped.
    _stub_planner_paths(monkeypatch, ["engine/new.py"])
    narrowed = PACK.plan_from_workflow(
        MANIFEST, changed_from="base-sha", scope_mode="active", pack_count=12
    )
    assert narrowed.eligible_job_ids == ("owns-new",)


def test_planner_failure_never_emits_no_work(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """An exception is not a proof. It must launch everything, and exit 0.

    This is the whole reason ci-plan is allowed to gate the matrix at all. If a
    planner crash could emit `has_work: false`, ci-gate would publish a green
    aggregate for a PR on which nothing ran.
    """

    def explode(path: object, gate: object = None) -> object:
        raise PACK.ManifestError("job 'x' is broken\njob 'y' is broken too")

    monkeypatch.setattr(PACK, "load_legacy_jobs", explode)
    output = tmp_path / "github_output"
    assert (
        PACK.main(
            [
                "--workflow", str(MANIFEST),
                "--pack-count", "12",
                "--plan-only",
                "--github-output", str(output),
            ]
        )
        == 0
    )
    outputs = _parse_github_output(output.read_text())
    assert json.loads(outputs["matrix"]) == {
        "include": [{"pack": index} for index in range(12)]
    }
    assert outputs["has_work"] == "true"
    assert outputs["plan_sha"] == ""
    assert outputs["reason"].startswith("full suite: planner error")
    # The list itself is no longer an output (2026-08-14); the widened plan
    # publishes the affirmative "no list" digest instead, and the artifact this
    # path writes carries the token `null`.
    assert "changed_files" not in outputs
    assert outputs["changed_files_sha256"] == ""
    assert outputs["changed_files_count"] == "0"
    warning = next(
        line
        for line in capsys.readouterr().out.splitlines()
        if line.startswith("::warning title=ci-plan-fallback::")
    )
    # A multi-line manifest error must not smuggle a newline into an annotation:
    # GitHub reads only the line that STARTS with `::`, so the rest would vanish
    # and the warning would under-report what broke.
    assert "job 'x' is broken" in warning
    assert "job 'y' is broken too" in warning


def test_planner_failure_without_github_output_still_fails_loudly(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """Only the ci-plan emission path widens; local validation stays fail-closed.

    Otherwise `--plan-only` would become a way to make a broken manifest look
    fine on a developer's machine.
    """

    def explode(path: object, gate: object = None) -> object:
        raise PACK.ManifestError("manifest is broken")

    monkeypatch.setattr(PACK, "load_legacy_jobs", explode)
    assert (
        PACK.main(
            ["--workflow", str(MANIFEST), "--pack-count", "12", "--plan-only"]
        )
        == 2
    )
    assert "manifest is broken" in capsys.readouterr().err


def test_expect_plan_sha_mismatch_refuses_before_any_job_runs(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """A pack that would run a different suite must not run a partial one first.

    Half a divergent pack is worse than none: its check name says ci-pack-N
    passed, and the sweeper reads that name as proof of the plan ci-plan
    published, not of whatever this runner actually derived.
    """
    monkeypatch.setattr(PACK, "execute_pack", _never_execute)
    assert (
        PACK.main(
            [
                "--workflow", str(MANIFEST),
                "--pack-index", "0",
                "--pack-count", "12",
                "--execute",
                "--expect-plan-sha", "0" * 64,
            ]
        )
        == 2
    )
    error = next(
        line
        for line in capsys.readouterr().out.splitlines()
        if line.startswith("::error title=ci-plan-parity::")
    )
    assert "0" * 64 in error


def test_a_pack_refuses_a_changed_file_list_it_cannot_prove(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """The list left the job outputs on 2026-08-14; this is what replaced it.

    Moving it to an artifact (run 31775693780: 350,264 bytes of `env:` against
    execve's 131,072-byte cap, twelve packs dead at launch) put it OUTSIDE every
    channel the packs already trust. That matters because the list is not
    decoration — the guards inside a pack scope THEMSELVES to it
    (conflict-markers, self-mod-fence, the selection itself), so a stale,
    swapped or truncated artifact shrinks what a green pack actually proved,
    silently.

    The repair needs no new gate: `changed_files_sha256` went into
    `plan_hash_payload`, so a pack that recomputes from the wrong file
    recomputes a different plan sha and the EXISTING `--expect-plan-sha` parity
    check refuses before a single legacy step runs. Every shape below is one
    that used to pass parity and run the wrong suite under a check name the
    sweeper reads as proof.
    """
    handle = tmp_path / "changed-files.json"
    listed = ["engine/example.py", "docs/存档 note.md"]
    handle.write_text(json.dumps(listed, separators=(",", ":")), encoding="utf-8")
    _freeze_scope_inference(monkeypatch)
    jobs = [
        _plan_job("engine-owner", 0, paths=("engine/**",)),
        _plan_job("site-owner", 1, paths=("site/**",)),
    ]
    monkeypatch.setattr(PACK, "load_legacy_jobs", lambda path, gate=None: list(jobs))
    plan = PACK.plan_from_workflow(
        MANIFEST,
        changed_from="basesha",
        scope_mode="active",
        pack_count=2,
        changed_files_file=handle,
    )
    assert plan.changed_files_count == 2
    assert plan.changed_files_sha256 == PACK.changed_files_digest(listed)

    reached: list[int] = []
    monkeypatch.setattr(
        PACK, "execute_pack", lambda jobs, **kwargs: reached.append(len(jobs)) or 0
    )

    def run(handle_path: Path | None, *, expect: str | None = None) -> int:
        argv = [
            "--workflow", str(MANIFEST),
            "--pack-index", "0", "--pack-count", "2",
            "--changed-from", "basesha",
            "--execute",
            "--expect-plan-sha", expect or plan.plan_sha256,
        ]
        if handle_path is not None:
            argv += ["--changed-files-file", str(handle_path)]
        return PACK.main(argv)

    # A positive control FIRST, or every refusal below could be passing for a
    # reason that has nothing to do with the changed-file list.
    assert run(handle) == 0
    assert reached, "the unmutated fixture must reach execution"

    def refusal(handle_path: Path | None, needle: str) -> None:
        assert run(handle_path) == 2
        lines = capsys.readouterr().out.splitlines()
        diagnosis = next(
            line for line in lines
            if line.startswith("::error title=ci-changed-files::")
        )
        assert needle in diagnosis, diagnosis
        assert any(
            line.startswith("::error title=ci-plan-parity::") for line in lines
        ), "the parity check is the gate; the diagnosis alone must not be it"

    # (i) A well-formed list that is simply not THIS plan's list — the swapped
    # or stale artifact, and the only shape no structural check can catch.
    other = tmp_path / "other.json"
    other.write_text('["engine/example.py"]', encoding="utf-8")
    refusal(other, "read as list")

    # (ii) The artifact landed truncated / corrupt. Never widen here: a pack
    # that quietly ran the full suite under a pinned plan's check name reports
    # green for a suite the published plan does not describe.
    corrupt = tmp_path / "corrupt.json"
    corrupt.write_text('["engine/example.py", "docs/', encoding="utf-8")
    refusal(corrupt, "read as malformed")

    # (iii) The download never landed.
    refusal(tmp_path / "missing.json", "read as unreadable")

    # (iv) No handle configured at all. `--changed-from` is still on the command
    # line, so without the file-first order this would silently git-diff a
    # depth-1 tree and widen — which is exactly the miss the pin now catches.
    monkeypatch.delenv("CI_CHANGED_FILES_FILE", raising=False)
    monkeypatch.setattr(
        PACK, "changed_files", lambda base: (_ for _ in ()).throw(RuntimeError(base))
    )
    assert run(None) == 2

    # (v) THE MIRROR IMAGE, and the one the old `changed_files` output could not
    # express: the plan recorded NO list (full suite, digest "") while the
    # handle carries a real one. Two channels describing different runs.
    widened = PACK.plan_from_workflow(
        MANIFEST, changed_from=None, scope_mode="active", pack_count=2
    )
    assert widened.changed_files_sha256 == ""
    assert (
        PACK.main(
            [
                "--workflow", str(MANIFEST),
                "--pack-index", "0", "--pack-count", "2",
                "--changed-from", "basesha",
                "--execute",
                "--expect-plan-sha", widened.plan_sha256,
                "--changed-files-file", str(handle),
            ]
        )
        == 2
    )

    # Non-vacuity: exactly one of the six runs reached execution.
    assert len(reached) == 1


def test_plan_and_execution_select_the_exact_same_jobs(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Every index, not one: a divergence at pack 7 is invisible at pack 0.

    This also pins that the plan hash does NOT depend on --pack-index. ci-plan
    computes it without one (default 0) and each pack recomputes it with its
    own; if the index ever entered the hashed payload, packs 1-11 would refuse
    every plan ci-plan ever published and CI would be permanently red.
    """
    plan = _full_plan()
    seen: list[str] = []
    for index in range(12):
        captured: list[str] = []

        def capture(jobs: list[object], **kwargs: object) -> int:
            captured.extend(job.job_id for job in jobs)
            return 0

        monkeypatch.setattr(PACK, "execute_pack", capture)
        assert (
            PACK.main(
                [
                    "--workflow", str(MANIFEST),
                    "--pack-index", str(index),
                    "--pack-count", "12",
                    "--execute",
                    "--expect-plan-sha", plan.plan_sha256,
                ]
            )
            == 0
        ), f"pack {index} refused the plan ci-plan published"
        assert tuple(captured) == plan.pack_jobs[index], index
        seen.extend(captured)
    # Non-vacuity: the twelve packs together are the whole eligible set, so this
    # cannot pass by every pack quietly executing nothing.
    assert sorted(seen) == sorted(plan.eligible_job_ids)


def test_github_output_is_byte_stable_and_parses_as_heredoc(tmp_path: Path) -> None:
    first, second = tmp_path / "one", tmp_path / "two"
    for path in (first, second):
        assert (
            PACK.main(
                [
                    "--workflow", str(MANIFEST),
                    "--pack-count", "12",
                    "--plan-only",
                    "--github-output", str(path),
                    "--matrix-mode", "active",
                ]
            )
            == 0
        )
    assert first.read_text() == second.read_text()
    outputs = _parse_github_output(first.read_text())
    # EXACTLY these six, and none of them scales with the size of the diff. A
    # job output becomes an `env:` string in the consuming job and execve caps
    # one at 131,072 bytes; the retired `changed_files` output measured 350,264
    # on PR #5578 and killed all twelve packs at launch (run 31775693780). A
    # seventh, unbounded output added here would reopen exactly that.
    assert set(outputs) == {
        "matrix", "has_work", "plan_sha", "reason",
        "changed_files_sha256", "changed_files_count",
    }
    assert json.loads(outputs["matrix"]) == {
        "include": [{"pack": index} for index in range(12)]
    }
    assert outputs["has_work"] == "true"
    assert len(outputs["plan_sha"]) == 64
    assert outputs["changed_files_sha256"] == ""
    assert outputs["changed_files_count"] == "0"


def test_matrix_mode_overrules_a_no_work_plan_without_changing_its_hash(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The dynamic matrix's kill switch, pinned where it is actually visible.

    After #5564, empty packs are omitted (`nonempty_pack_indices` only). A
    no-work plan must emit ``{"include": []}`` in active mode — not pack 0 —
    and shadow/off must still launch all twelve. The hash must be identical
    across modes: it is a plan input, and the mode is an emission policy. If
    the mode entered the hash, flipping the repository variable mid-run would
    make every in-flight pack refuse its own plan.
    """
    _freeze_scope_inference(monkeypatch)
    jobs = [_plan_job("engine-owner", 0, paths=("engine/**",))]
    monkeypatch.setattr(PACK, "load_legacy_jobs", lambda path, gate=None: list(jobs))
    _stub_planner_paths(monkeypatch, ["research/NOTE.md"])
    emitted: dict[str, dict[str, str]] = {}
    for mode in ("active", "shadow", "off"):
        path = tmp_path / mode
        assert (
            PACK.main(
                [
                    "--workflow", str(MANIFEST),
                    "--pack-count", "12",
                    "--plan-only",
                    "--changed-from", "base-sha",
                    "--matrix-mode", mode,
                    "--github-output", str(path),
                ]
            )
            == 0
        )
        emitted[mode] = _parse_github_output(path.read_text())

    assert json.loads(emitted["active"]["matrix"]) == {"include": []}
    assert emitted["active"]["has_work"] == "false"
    for mode in ("shadow", "off"):
        assert json.loads(emitted[mode]["matrix"]) == {
            "include": [{"pack": index} for index in range(12)]
        }
        assert emitted[mode]["has_work"] == "true"
        assert emitted[mode]["reason"].startswith(f"matrix {mode} (all 12 launch): ")
    assert len({outputs["plan_sha"] for outputs in emitted.values()}) == 1
    assert len(emitted["active"]["plan_sha"]) == 64


def test_matrix_mode_defaults_to_shadow_and_reads_its_own_environment(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Scope mode and matrix mode are separate switches with separate defaults."""
    monkeypatch.delenv("CI_DYNAMIC_MATRIX_MODE", raising=False)
    assert PACK.parse_args(["--workflow", str(MANIFEST)]).matrix_mode == "shadow"
    monkeypatch.setenv("CI_DYNAMIC_MATRIX_MODE", "active")
    assert PACK.parse_args(["--workflow", str(MANIFEST)]).matrix_mode == "active"
    # Flipping the matrix switch must not move scope selection, or the emergency
    # kill switch for one would silently be the kill switch for both.
    monkeypatch.setenv("CI_SCOPE_MODE", "off")
    args = PACK.parse_args(["--workflow", str(MANIFEST)])
    assert (args.scope_mode, args.matrix_mode) == ("off", "active")


def test_plan_only_never_executes_and_refuses_to_pair_with_execute(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(PACK, "execute_pack", _never_execute)
    assert (
        PACK.main(
            ["--workflow", str(MANIFEST), "--pack-count", "12", "--plan-only"]
        )
        == 0
    )
    with pytest.raises(SystemExit):
        PACK.parse_args(["--workflow", str(MANIFEST), "--plan-only", "--execute"])


def test_emit_plan_json_prints_exactly_one_machine_line(
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """`-` is a machine line in a human log, so a SECOND one would break parsers."""
    assert (
        PACK.main(
            [
                "--workflow", str(MANIFEST),
                "--pack-count", "12",
                "--plan-only",
                "--emit-plan-json", "-",
            ]
        )
        == 0
    )
    markers = [
        line
        for line in capsys.readouterr().out.splitlines()
        if line.startswith(PACK.PLAN_MARKER)
    ]
    assert len(markers) == 1
    document = json.loads(markers[0][len(PACK.PLAN_MARKER):])
    # The DIGEST and the COUNT joined this document on 2026-08-14, never the
    # list: it is printed as one machine line in the planner's log, so an
    # unbounded array here would only move the 350,264 bytes out of the pack
    # step's `env:` and into a log line nobody can read (run 31775693780).
    assert set(document) == {
        "schema", "changed_from", "scope_mode", "reason", "scope_summary",
        "legacy_job_count", "eligible_job_count", "eligible_jobs",
        "skipped_job_count", "skipped_jobs", "packs", "nonempty_pack_indices",
        "matrix", "has_work", "plan_sha256",
        "changed_files_sha256", "changed_files_count",
        "workflow_run_id", "workflow", "event", "role",
        "tested_tree_sha", "subject_head_sha", "base_sha",
        "authority_changed", "semantic_jobs",
    }
    # The full-suite baseline carries the affirmative "no list" encoding, which
    # is what lets a pack tell "planned everything" from "planned this exact
    # diff" without a second flag.
    assert document["changed_files_sha256"] == ""
    assert document["changed_files_count"] == 0
    assert document["schema"] == PACK.PLAN_SCHEMA == "ci.pack_plan.v2"
    assert [entry["index"] for entry in document["packs"]] == list(range(12))

    # A path gets the same document, indented, and no marker line on stdout.
    path = tmp_path / "plan.json"
    assert (
        PACK.main(
            [
                "--workflow", str(MANIFEST),
                "--pack-count", "12",
                "--plan-only",
                "--emit-plan-json", str(path),
            ]
        )
        == 0
    )
    assert json.loads(path.read_text()) == document
    assert PACK.PLAN_MARKER not in capsys.readouterr().out


def test_the_pack_report_survived_the_plan_refactor(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """The three lines every CI log is read by eye for, after the rewrite.

    `pack weights=` is the one that nearly broke: the plan stores weights as a
    TUPLE, and printing it directly would render `pack weights=(481, ...)` — a
    silent cosmetic regression in the only summary a human reads when a pack
    looks wrong.
    """
    plan = _full_plan()
    assert (
        PACK.main(
            [
                "--workflow", str(MANIFEST),
                "--pack-index", "3",
                "--pack-count", "12",
                "--validate-only",
            ]
        )
        == 0
    )
    lines = capsys.readouterr().out.splitlines()
    assert lines[0] == (
        f"::notice title=ci-pack-scope::{plan.reason}; {plan.scope_summary}"
    )
    validated = next(line for line in lines if line.startswith("Validated "))
    assert validated.startswith(
        f"Validated {plan.legacy_job_count} legacy jobs; "
        f"{len(plan.eligible_job_ids)} in scope ({plan.reason}); "
    )
    assert f"pack weights={list(plan.pack_weights)};" in validated
    assert f"selected pack 3 ({len(plan.pack_jobs[3])} jobs)." in validated
    selected = next(line for line in lines if line.startswith("Selected jobs: "))
    assert selected == "Selected jobs: " + ", ".join(plan.pack_jobs[3])


def test_workflow_scopes_only_pull_requests() -> None:
    """Main's baseline must never pass --changed-from: it runs the full manifest."""
    pack = _yaml(WORKFLOW)["jobs"]["ci-pack"]
    step = next(s for s in pack["steps"] if s.get("id") == "execute_semantic_pack")
    assert "CI_SCOPE_ARG" not in step.get("env", {})
    assert "--changed-from" not in step["run"]
    # A leftover `shadow` GitHub Actions variable must not hostage the fleet:
    # anything other than exact `off` is active. Quote: before #5515 the var
    # could sit at `shadow` and run the full 185-job suite while reporting a
    # predicted subset; after, and still after this PR, the expression admits
    # only `off` or `active`.
    plan = _yaml(WORKFLOW)["jobs"]["ci-plan"]
    plan_step = next(
        s for s in plan["steps"]
        if isinstance(s, dict) and s.get("id") == "plan"
    )
    assert plan_step["env"]["CI_SCOPE_MODE"] == (
        "${{ vars.CI_SCOPE_MODE == 'off' && 'off' || 'active' }}"
    )
    assert plan_step["env"]["CI_DYNAMIC_MATRIX_MODE"] == (
        "${{ vars.CI_DYNAMIC_MATRIX_MODE == 'off' && 'off' || 'active' }}"
    )
    scope_arg = str(plan_step["env"]["CI_SCOPE_ARG"])
    assert "github.event_name == 'pull_request'" in scope_arg
    assert "--changed-from" in scope_arg
    assert "steps.identity.outputs.tested_base_sha" in scope_arg
    assert "github.base_ref" not in scope_arg
    on = _yaml(WORKFLOW).get("on") or _yaml(WORKFLOW).get(True)
    pull_paths = on["pull_request"]["paths"]
    assert "**" in pull_paths
    assert "worker/**" in pull_paths
    assert "content/**" in pull_paths
    assert "wrangler.toml" in pull_paths
    assert "$CI_SCOPE_ARG" in str(plan_step["run"])


def test_pack_command_folds_to_exactly_one_shell_command() -> None:
    """A newline in the folded scalar splits one command into two, silently.

    Putting the scope expression inline across continuation lines did exactly
    that: YAML preserves newlines for MORE-indented lines inside `>-`, so
    `--execute` landed on its own line and the pack ran without it. Same family
    as the `#`-in-a-folded-scalar trap, and invisible in review.
    """
    pack = _yaml(WORKFLOW)["jobs"]["ci-pack"]
    for step in pack["steps"]:
        if not isinstance(step, dict) or "run" not in step:
            continue
        if not str(step["run"]).lstrip().startswith('"$RUNNER_TEMP'):
            continue
        command = str(step["run"])
        assert "\n" not in command, (
            "the pack command must fold to ONE line; a newline here silently "
            f"drops every argument after it: {command!r}"
        )
        assert command.rstrip().endswith("--execute")


def test_ci_pack_uses_twelve_balanced_hosted_anchors_or_fork_packs() -> None:
    workflow = _yaml(WORKFLOW)
    # This job set was EXACTLY {"ci-pack"} until Wave B (2026-08-11) added the
    # planner and the aggregate. Pinned as a subset, not as equality: the
    # invariant this file defends is that CI does not fan back out (86 VMs, one
    # per legacy suite), so a job-per-legacy-suite regression here is the thing
    # this guards against — while the exact ci-plan/ci-gate shape belongs to
    # tests/test_ci_plan_workflow.py, which owns it positively. Two suites
    # asserting the same equality would only mean two places to edit, and the
    # weaker one would win.
    #
    # `contract-delta` (2026-08-19) joined the allowed set deliberately: it is
    # one small, purposeful, path-independent job — same shape as ci-plan/
    # ci-pack/ci-gate, not a per-suite fan-out job — that re-derives two
    # CI-contract finding classes ci-pack's own path scoping cannot reach (see
    # scripts/check_contract_delta.py's module docstring). Adding it here is
    # the same class of change as ci-plan/ci-gate joining originally; it does
    # not reopen the 86-VM fan-out this test exists to prevent.
    # `trusted-ci` (P3B-B) is one protected-main reusable call, not another
    # planner, pack fan-out or scheduler. Its PC jobs are defined only by the
    # called main workflow; the caller's ci-pack matrix remains the stable hosted
    # anchor set and retains the full implementation only for forks.
    assert set(workflow["jobs"]) <= {
        "ci-plan",
        "trusted-ci",
        "ci-pack",
        "contract-delta",
        "ci-gate",
    }
    assert "ci-pack" in workflow["jobs"]
    pack = workflow["jobs"]["ci-pack"]
    # The pack COUNT tunes (2 -> 4 -> 12 as hosted capacity increased); the
    # SHAPE is the contract: a small ordered matrix of stable hosted anchors
    # (or full hosted fork packs), never one job per legacy suite (86 VMs), and
    # the matrix must agree with the --pack-count handed to the runner or some
    # packs' jobs would execute nowhere.
    #
    # Wave B made the matrix the PLANNER's, so the list of indices is no longer
    # in this file — `--pack-count 12` below is now the only place the twelve-way
    # partition is written down, and run_ci_pack.py always emits exactly that
    # many packs (tests/test_ci_pack.py::test_plan_keeps_the_fixed_twelve_pack_assignment).
    matrix = pack["strategy"]["matrix"]
    if isinstance(matrix, str):
        assert "fromJSON(needs.ci-plan.outputs.matrix)" in " ".join(matrix.split())
    else:
        static = matrix["pack"]
        assert static == list(range(len(static)))
        assert len(static) == 12
    # EVERY event runs on the hosted pool — one `runs-on`, no event-dependent routing,
    # so main's baseline and a pull request prove the packs the SAME way.
    #
    # This replaces the 2026-08-09 self-hosted detour. Main's proof was briefly routed
    # to `["self-hosted","render-linux"]` because it sat `queued` 30+ minutes behind 133
    # queued runs while that pool idled, and a starved main proof blocks the whole fleet
    # (`merge_on_green.main_proof` reads the newest CONCLUDED ci.yml run on main, so
    # without one the base-inherited-red refresh cannot fire). The repository then moved
    # to the MastermindX enterprise org and hosted capacity became large enough to start
    # all twelve packs together. There is nothing left to escape, and the detour cost
    # more than it saved: `render-linux` is FOUR runners shared with render.yml,
    # engine-render.yml and merge-on-green.yml, so even four packs took the entire pool
    # and starved the sweeper that merges every armed pull request.
    assert pack["runs-on"] == "ubuntu-latest"
    # The self-hosted pools are the render/nightly lanes and must never absorb CI packs.
    runs_on = " ".join(str(pack["runs-on"]).split())
    assert "macstudio" not in runs_on
    assert "render-linux" not in runs_on
    assert "self-hosted" not in runs_on
    # Sibling packs must finish so their proofs survive a single red. fail-fast
    # on pull_request cancelled the other eleven, ci-gate went red, and a heal
    # had to rerun everything. A real red still fails ci-gate.
    assert pack["strategy"]["fail-fast"] is False
    pack_src = WORKFLOW.read_text(encoding="utf-8")
    assert "fail-fast: false" in pack_src
    assert "fail-fast: ${{ github.event_name == 'pull_request' }}" not in pack_src
    assert 'fail-fast: "${{ github.event_name == \'pull_request\' }}"' not in pack_src
    # No `max-parallel`: it existed only to stop main's packs from taking all four
    # `render-linux` runners. With no shared pool to protect, throttling would only
    # double main's proof (~26 min -> ~50 min), and it cannot help against the hosted
    # ceiling because that limit is ACCOUNT-wide, not per-matrix.
    assert "max-parallel" not in pack["strategy"], (
        "reintroducing max-parallel only slows main's proof; the hosted concurrency "
        "ceiling is account-wide and this key cannot raise it"
    )
    assert pack["if"] == (
        "!cancelled() && needs.ci-plan.result == 'success' && "
        "needs.ci-plan.outputs.has_work == 'true' && "
        "(github.event.pull_request.head.repo.full_name != github.repository || "
        "vars.CI_EXECUTION_ROUTE != 'pc' || needs.trusted-ci.result == 'success')"
    )
    run_text = "\n".join(
        str(step.get("run", "")) for step in pack["steps"] if isinstance(step, dict)
    )
    assert "--workflow .github/ci/legacy-jobs.yml" in run_text
    assert "--pack-count 12" in run_text

    # A manifest edit must trigger CI even though GitHub does not interpret the
    # manifest itself as a workflow.
    triggers = workflow.get("on") or workflow.get(True)
    assert ".github/ci/legacy-jobs.yml" in triggers["pull_request"]["paths"]
    assert triggers["pull_request"]["types"] == [
        "opened", "synchronize", "reopened"
    ]


def test_company_intelligence_product_surfaces_reach_focused_ci_packs() -> None:
    """Both public product faces must trigger CI and run their focused suites."""
    workflow = _yaml(WORKFLOW)
    triggers = workflow.get("on") or workflow.get(True)
    paths = set(triggers["pull_request"]["paths"])
    required_paths = {
        "app/company_intelligence.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        "app/earnings.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        "tests/test_company_intelligence_api.py",
        "site/assets/js/company-intelligence-dossier.js",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        "templates/ticker.html.j2",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        "engine/earnings_narrative/public_wire.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        "engine/earnings_narrative/context_packets.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        "engine/earnings_narrative/private_publication.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        "engine/neuralweb/earnings_context_reader.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        "engine/prophet_bridge.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        "scripts/build_earnings_public_wire.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        "scripts/publish_earnings_private_store.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        "templates/earnings_wire/**",
        "tests/test_earnings_public_wire.py",
        "tests/test_earnings_api.py",
        "tests/test_earnings_private_store.py",
        "tests/test_prophet_bridge.py",
        "tests/test_earnings_worker_launchd.py",
        "tests/test_earnings_worker_terminal.py",
        "ops/bootstrap_earnings_worker.sh",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        "ops/launchd/com.mastermind.earnings-worker.plist",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        "ops/launchd/run_earnings_worker.sh",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        "tests/test_ticker_dossier_render_lane.py",
    }
    assert required_paths <= paths

    manifest = _yaml(MANIFEST)

    def job_commands(job_id: str) -> str:
        return "\n".join(
            str(step.get("run", ""))
            for step in manifest["jobs"][job_id]["steps"]
            if isinstance(step, dict)
        )

    assert "tests/test_company_intelligence_api.py" in job_commands(
        "prelaunch-hardening"
    )
    publish_ops = job_commands("unrun-publish-ops")
    publish_ops_install = next(
        step["run"]
        for step in manifest["jobs"]["unrun-publish-ops"]["steps"]
        if step.get("name") == "install minimal deps"
    )
    assert "tests/test_earnings_public_wire.py" in publish_ops
    assert "tests/test_earnings_api.py" in publish_ops
    assert "tests/test_earnings_private_store.py" in publish_ops
    assert "tests/test_earnings_worker_launchd.py" in publish_ops
    assert "tests/test_earnings_worker_terminal.py" in publish_ops
    assert "tests/test_ticker_dossier_render_lane.py" in publish_ops
    assert "tests/test_ticker_pages.py" in publish_ops
    assert re.search(r"\bfastapi\b", publish_ops_install)
    assert re.search(r"\bhttpx\b", publish_ops_install)


def test_ci_pack_partial_clone_keeps_history_without_historical_site_blobs() -> None:
    """ci-plan keeps full history; packs shallow-checkout the current tree.

    Measured PR #5550 / run 31729769728: twelve packs fetching fetch-depth:0 at
    once put ci-pack-1 in "Checking out the ref" for 31 minutes. Packs consume
    ci-plan's changed-file list and only need the current working tree (legacy
    suites inspect committed site/ artifacts, not historical blobs). Do not
    replace the PACK checkout with sparse checkout. W3 contains only ci-plan's
    working tree; ci-pack materialization remains W4.

    And no ``filter: blob:none`` on the pack checkout (2026-09-23,
    DSC:CI-PROMISOR-OBJECT-FETCH-TRUNCATION): a pack materialises the whole
    tree anyway, so the filter only moved ~5 GiB of blobs out of the retried
    ``git fetch`` into one unretried promisor request issued by ``git
    checkout``. Three of those died at 65–67 minutes ("N bytes of body are
    still expected" / "could not fetch 20ced735… from promisor remote" — the
    first index entry, not a corrupt object): runs 35876013221, 35885173966,
    35886408213. An unfiltered depth-1 fetch is retried by actions/checkout
    and leaves the checkout step with no network to fail on.
    """
    workflow = _yaml(WORKFLOW)
    pack = workflow["jobs"]["ci-pack"]
    checkout = next(
        step
        for step in pack["steps"]
        if str(step.get("uses", "")).startswith("actions/checkout@")
    )
    assert "filter" not in checkout["with"]
    assert checkout["with"]["fetch-depth"] == 1
    assert "sparse-checkout" not in checkout["with"]
    plan = workflow["jobs"]["ci-plan"]
    plan_checkout = next(
        step
        for step in plan["steps"]
        if str(step.get("uses", "")).startswith("actions/checkout@")
    )
    assert plan_checkout["with"]["fetch-depth"] == 0
    assert plan_checkout["with"]["sparse-checkout-cone-mode"] is False
    assert plan_checkout["with"]["sparse-checkout"].splitlines() == [
        "/*",
        "!/data/",
        "!/site/",
        "!/mockups/",
        "!/verify_shots/",
    ]


def test_same_repo_fences_share_one_runner_and_keep_required_contexts() -> None:
    workflow = _yaml(FENCES)
    assert workflow["permissions"]["checks"] == "write"
    jobs = workflow["jobs"]
    assert set(jobs) == {
        "fence-pack",
        "fork-self-mod-fence",
        "fork-capability-broker",
        "fork-grader-manifest",
    }
    pack = jobs["fence-pack"]
    assert pack["runs-on"] == "ubuntu-latest"
    checkout = next(
        step
        for step in pack["steps"]
        if str(step.get("uses", "")).startswith("actions/checkout@")
    )
    assert checkout["with"]["filter"] == "blob:none"
    # Commit 09abde056620 "fix(ci): contain fence checkout to proof surface"
    # bounded fence-pack's checkout to fetch-depth 256 + sparse-checkout
    # (~74.7k -> 4,994 files, production-proven). The exact shape (paths,
    # cone-mode) is canonically owned by test_fence_checkout_contract.py;
    # this assertion only keeps this file from drifting back to the old pin.
    assert checkout["with"]["fetch-depth"] == 256

    publish = next(step for step in pack["steps"] if step.get("id") == "publish")
    assert publish["if"] == "always()"
    assert publish["uses"].startswith("actions/github-script@")
    script = publish["with"]["script"]
    for context in ("self-mod-fence", "capability-broker", "grader-manifest"):
        assert f"name: '{context}'" in script
    assert "github.rest.checks.create" in script

    # Fork tokens cannot write check runs. Their compatibility jobs retain the
    # exact contexts only when the PR truly comes from a fork; on the high-volume
    # same-repo path their skipped names are deliberately different, so they
    # cannot satisfy a required fence before fence-pack publishes its verdict.
    for job_id, context in (
        ("fork-self-mod-fence", "self-mod-fence"),
        ("fork-capability-broker", "capability-broker"),
        ("fork-grader-manifest", "grader-manifest"),
    ):
        fallback = jobs[job_id]
        assert "head.repo.full_name != github.repository" in fallback["if"]
        assert fallback["runs-on"] == "ubuntu-latest"
        assert context in fallback["name"]
        assert f"fork-{context}-unused" in fallback["name"]

    # The fork self-mod fence also compares against the base branch and needs
    # complete ancestry without downloading obsolete generated-site contents.
    fork_checkout = next(
        step
        for step in jobs["fork-self-mod-fence"]["steps"]
        if str(step.get("uses", "")).startswith("actions/checkout@")
    )
    assert fork_checkout["with"]["filter"] == "blob:none"
    assert fork_checkout["with"]["fetch-depth"] == 0


# ── every tests/*.py a workflow names must exist ─────────────────────────────
#
# `pytest a.py b.py missing.py` does not skip the missing path — it aborts the
# whole invocation with "ERROR: file or directory not found" and runs NOTHING.
# So one deleted test file silently disables every other test in its step.
# ci-main-heartbeat's engine-render-guards step listed
# tests/test_leadership_board.py, deleted with the Mag-7 board in #3359; the job
# had been erroring out ever since, taking 2084 passing tests in the other 73
# files down with it, and main's heartbeat red, until #3555.
#
# This is the [[ci-trigger-must-reach-the-guard]] class one turn worse: there the
# guard could not be triggered, here it is triggered and then never runs. A red
# job is not evidence that the tests under it ran.

_TEST_PATH_RE = re.compile(r'(?<![\w/-])(tests/[A-Za-z0-9_][A-Za-z0-9_./-]*\.py)')


def test_every_workflow_test_path_exists() -> None:
    """No workflow may name a tests/*.py file that is not on disk."""
    missing: list[str] = []
    checked = sorted((ROOT / ".github" / "workflows").glob("*.yml")) + [MANIFEST]
    for workflow_or_manifest in checked:
        text = workflow_or_manifest.read_text(encoding="utf-8")
        for rel in sorted(set(_TEST_PATH_RE.findall(text))):
            if not (ROOT / rel).exists():
                missing.append(f"{workflow_or_manifest.name} -> {rel}")

    assert not missing, (
        "Workflow steps name test files that do not exist:\n  "
        + "\n  ".join(missing)
        + "\n\npytest aborts the ENTIRE invocation on an unresolvable path, so "
        "every other test listed in that step never runs and the job is red for "
        "a reason unrelated to the code. Delete the stale path from the workflow "
        "(or restore the file if the deletion was a mistake)."
    )


# ── a MIRROR that drifts measures its own venv, not the boundary ─────────────
#
# ci-main-heartbeat.yml claims, in its own header, that "Job names + steps mirror
# ci.yml exactly, so 'green here' means the same thing as 'green on the PR gate'".
# On 2026-08-18 that claim was false for `tier-gate`. The PR lane had grown
# `requests numpy pandas` — with a comment saying to keep the environment "closed
# over the real production import graph", because engine/etf_pulse.py imports numpy
# at module scope — and the heartbeat copy had not. So tests/test_etfs_gate.py
# stopped SKIPPING there and started ERRORING with ModuleNotFoundError, and the
# heartbeat went red about its own pip line while reporting a failure named
# "tier-preview split contract (no paid row in the free shell)" — i.e. it read as a
# PAYWALL LEAK. It stayed that way ~30h because the sentinel that watches this lane
# was itself blind (see DSC:BLIND-SENTINEL-REPORTS-CLEAN).
#
# SCOPE — deliberately `tier-gate` only, and deliberately NOT a general
# "heartbeat venv >= manifest venv" rule, which is FALSE BY DESIGN elsewhere:
# heartbeat's template-site-sync omits jinja2 on purpose (its own comment routes
# the jinja2-gated cross-module test to free-content-estate instead), and
# engine-render-guards omits fastapi/httpx/jsonschema while its suites skip
# cleanly. A thin venv is legitimate when the tests SKIP and illegitimate when they
# ERROR, and only tier-gate has been shown to error. Widen this per-job, behind a
# job that has actually demonstrated the failure — never speculatively.
_HEARTBEAT_WORKFLOW = ROOT / ".github" / "workflows" / "ci-main-heartbeat.yml"
_PIP_INSTALL_RE = re.compile(r"pip install\s+(.+)")


def _job_pip_packages(job: dict) -> set[str]:
    """Every package name any `pip install` line in this job installs."""
    packages: set[str] = set()
    for step in job.get("steps") or []:
        for line in (step.get("run") or "").splitlines():
            found = _PIP_INSTALL_RE.search(line)
            if found:
                packages |= {tok for tok in found.group(1).split()
                             if not tok.startswith("-")}
    return packages


def _job_test_paths(job: dict) -> set[str]:
    joined = "\n".join((step.get("run") or "") for step in job.get("steps") or [])
    return set(_TEST_PATH_RE.findall(joined))


def test_heartbeat_tier_gate_venv_matches_the_pr_lane() -> None:
    """The heartbeat's tier-gate must not run a shared suite on a thinner venv."""
    heartbeat = yaml.safe_load(_HEARTBEAT_WORKFLOW.read_text(encoding="utf-8"))
    manifest = yaml.safe_load(MANIFEST.read_text(encoding="utf-8"))
    hb_job = heartbeat["jobs"]["tier-gate"]
    pr_job = manifest["jobs"]["tier-gate"]

    shared_suites = _job_test_paths(hb_job) & _job_test_paths(pr_job)
    assert shared_suites, (
        "heartbeat tier-gate and the manifest's tier-gate now share NO test file — "
        "either the mirror was renamed or one side stopped running the boundary "
        "suites. Re-point this guard rather than deleting it."
    )

    missing = sorted(_job_pip_packages(pr_job) - _job_pip_packages(hb_job))
    assert not missing, (
        f"ci-main-heartbeat.yml's tier-gate job runs {len(shared_suites)} of the PR "
        f"lane's own boundary suites but installs neither {missing}.\n\n"
        "The PR lane added those because the production import graph needs them at "
        "module scope. A suite that imports one of them does not skip here — it "
        "ERRORS, and the heartbeat then reports a red named for the serving "
        "boundary while actually failing on its own pip line. Add the packages to "
        "the heartbeat job; do not narrow the step to dodge them."
    )


# ── the converse: a suite NAMED BY NOTHING never runs ────────────────────────
#
# READ THIS BEFORE "FIXING" AN `if: ${{ false }}` LINE. `.github/ci/legacy-jobs.yml`
# is a MANIFEST, not a set of GitHub jobs. Every one of its ~162 jobs declares
# `if: ${{ false }}`, and that line is REQUIRED BOILERPLATE, not a disable switch:
# scripts/run_ci_pack.py FLAGS AS AN ERROR any manifest job that omits it, so that
# GitHub does not allocate a second, duplicate runner for steps the ci-pack matrix
# already executes. Removing or inverting it fails validation and breaks the pack.
# The manifest's jobs genuinely run — unrun-government-revenue executes in
# ci-pack-1.
#
# The real darkness sits one line away and looks like nothing at all: a suite that
# no `run:` step ANYWHERE names is executed by nothing, whatever any `if:` says.
# This repo has no catch-all `pytest tests/` sweep to pick up the omission, so an
# unnamed suite is silently inert. It passes locally, it is never red, and the lobe
# it guards reads green because its guards are INVISIBLE, not because they hold.
# Nineteen Government Revenue suites sat that way — among them
# test_government_revenue_award_spine.py and test_government_revenue_award_events.py,
# which own the forward award-event spine whose persistence break shipped to
# production on 2026-08-06. A line tracer over the seven suites CI did name
# executed 0 of 147 function bodies across metrics.py, candidates.py,
# opportunities.py, budget_program.py, freshness.py and federation.py (5,279
# lines) — including the fail-closed withholding gate in metrics.py.
#
# test_every_workflow_test_path_exists (above) checks NAMED -> EXISTS. The two
# below check the converse, EXISTS -> NAMED, and then the same question one layer
# down: a contract the ENGINE loads at runtime must be able to start the CI that
# validates against it.
#
# SCOPE — deliberately Government Revenue only. scripts/audit_unrun_tests.py
# measures 963 of 2,015 tests/test_*.py suites unrun repo-wide, so the generalised
# "every suite must be named" assertion would be red on ~48% of the tree the day it
# landed and would be deleted rather than fixed. Widen this per-program, behind a
# program that has actually closed its own darkness.

_GOVERNMENT_REVENUE_SUITE_GLOBS = (
    # also catches tests/test_prophet_government_revenue_context.py
    "tests/test_*government_revenue*.py",
    "tests/test_usaspending*.py",
)

_CLOSURE_SPEC = importlib.util.spec_from_file_location(
    "check_ci_trigger_closure", ROOT / "scripts" / "check_ci_trigger_closure.py"
)
assert _CLOSURE_SPEC and _CLOSURE_SPEC.loader
CLOSURE = importlib.util.module_from_spec(_CLOSURE_SPEC)
sys.modules[_CLOSURE_SPEC.name] = CLOSURE
_CLOSURE_SPEC.loader.exec_module(CLOSURE)


def _executable_run_commands() -> str:
    """Every `run:` body CI can execute: the packed manifest plus real workflows.

    The manifest is the usual home, but a suite wired into a standalone workflow
    genuinely runs too. Scanning both keeps this guard from going red on a correct
    fix — a guard that punishes the right answer gets weakened, not obeyed.
    """
    bodies: list[str] = []

    def walk(node: object) -> None:
        if isinstance(node, dict):
            for key, value in node.items():
                if key == "run" and isinstance(value, str):
                    bodies.append(value)
                else:
                    walk(value)
        elif isinstance(node, list):
            for item in node:
                walk(item)

    for path in [MANIFEST] + sorted((ROOT / ".github" / "workflows").glob("*.yml")):
        walk(yaml.safe_load(path.read_text(encoding="utf-8")))
    return "\n".join(bodies)


def test_every_government_revenue_suite_is_named_by_a_run_step() -> None:
    """A Government Revenue suite no `run:` step names is executed by nothing."""
    on_disk = sorted(
        {
            str(path.relative_to(ROOT))
            for pattern in _GOVERNMENT_REVENUE_SUITE_GLOBS
            for path in ROOT.glob(pattern)
        }
    )
    # Vacuity gate: if the globs stop matching the program, this guard would pass
    # by finding nothing at all. 29 suites exist as of 2026-08-06.
    assert len(on_disk) >= 25, (
        f"only {len(on_disk)} Government Revenue suites matched "
        f"{_GOVERNMENT_REVENUE_SUITE_GLOBS} — the program was renamed or moved and "
        "this guard is now measuring an empty set. Re-point the globs; do not "
        "lower this floor."
    )

    commands = _executable_run_commands()
    unnamed = [rel for rel in on_disk if rel not in commands]

    assert not unnamed, (
        f"{len(unnamed)} Government Revenue suite(s) are named by NO `run:` step in "
        ".github/ci/legacy-jobs.yml or .github/workflows/, so nothing executes "
        "them:\n  " + "\n  ".join(unnamed) + "\n\n"
        "This is NOT the `if: ${{ false }}` line, and 'enabling' a job does not fix "
        "it. That line is required boilerplate on every manifest job — "
        "scripts/run_ci_pack.py errors on any job missing it so GitHub does not "
        "allocate a duplicate runner — and the manifest's steps really are "
        "executed, by the ci-pack matrix in ci.yml. The defect is being UNNAMED: "
        "there is no catch-all `pytest tests/` sweep in this repo, so a suite no "
        "step lists is inert, green-by-absence, and its subject ships unguarded. "
        "Fix by naming the suite in a `run:` step of the owning manifest job "
        "(unrun-government-revenue) AND adding its path to ci.yml's "
        "on.pull_request.paths so an edit to it can start that job."
    )


_RUNTIME_SCHEMA_RE = re.compile(r'"([A-Za-z0-9_.]+\.schema\.json)"')
_WORKSPACE = ROOT / "engine" / "government_revenue" / "workspace.py"  # ci-trigger-closure: data — text-scanned for schema names, not imported; declared in ci-control-plane-contracts paths


def test_workspace_runtime_contracts_can_start_the_ci_that_validates_them() -> None:
    """A contract the engine loads at runtime must be a trigger for its own CI."""
    names = sorted(set(_RUNTIME_SCHEMA_RE.findall(_WORKSPACE.read_text("utf-8"))))
    assert names, (
        f"{_WORKSPACE.relative_to(ROOT)} no longer names a *.schema.json literal. "
        "Either the runtime loader moved (re-point this guard at its new home) or "
        "the extractor drifted — a silently empty extraction turns this assertion "
        "into a no-op, which is the exact failure mode it exists to prevent."
    )

    contracts = [f"contracts/government_revenue/{name}" for name in names]
    absent = [rel for rel in contracts if not (ROOT / rel).exists()]
    assert not absent, (
        "workspace.py loads contract files that are not in the tree:\n  "
        + "\n  ".join(absent)
        + "\n\nThe validator fails CLOSED on a missing schema, so every payload "
        "would read invalid at runtime."
    )

    workflow = _yaml(WORKFLOW)
    triggers = (workflow.get("on") or workflow.get(True))["pull_request"]["paths"]
    unmatched = [rel for rel in contracts if not CLOSURE.matched(rel, triggers)]

    assert not unmatched, (
        f"{len(unmatched)} contract(s) that engine/government_revenue/workspace.py "
        "loads AT RUNTIME match no glob in ci.yml's on.pull_request.paths:\n  "
        + "\n  ".join(unmatched)
        + "\n\nSo editing one of these schemas cannot fire the CI that validates "
        "against it. workspace.py's validator fails CLOSED — a schema edit that "
        "makes every payload read invalid merges without a single check running. "
        "scripts/check_ci_trigger_closure.py does not cover this: it is DEPTH 1 "
        "(the files a test file itself reads), and these are read one layer "
        "deeper, inside the engine module the test imports. Fix by adding "
        '- "contracts/government_revenue/**" to that paths list.'
    )


# ---------------------------------------------------------------------------
# CURATED `scope: exclusive` DECLARATIONS (2026-08-14 incident follow-up)
#
# The mechanism landed with one union-tier user and the incident's own handoff
# left "heavy code-file fanout (engine module still selects ~121 jobs)" open.
# These fixtures pin the curation that closed it. The load-bearing one is
# test_curated_exclusive_scopes_cover_their_own_import_closure: exclusivity
# SKIPS inference, so a declaration is a promise that nothing the job actually
# imports lost its owner, and only a test that re-derives the closure and
# compares can keep that promise honest as the tree moves.
# ---------------------------------------------------------------------------

CURATED_EXCLUSIVE = {
    "options-pilot-chronology-code",
    "stock-liquidity-profile",  # Native F08 import/read closure; no opaque fixture widening.
    # Vault code-gate closure from exact tracked-tree analysis; includes runtime
    # Jinja/page assets. Packing ceilings and suite coverage remain unchanged.
    "research-vault",
    "market-memory-e0-contract",  # E0 suites own their exact dependency closure.
    # BEA human/HTTP browser gate: measured literal closure, no opaque fallback smear.
    "bea-gvc-current-descriptive-consumer",
    # R2 original-intent context producer: the ten Agent OS knowledge suites
    # share their measured 43-file import/read closure plus the Agent OS corpus.
    # Source/fence execution remains in the existing self-mod job.
    "agentos-knowledge-contracts",
    # F04 real-Git acquisition reads three deploy scripts. Its dedicated job
    # preserves the broader self-heal owner without widening unrelated probes.
    "deploy-git-history",
    # PR #7861: Options matrix source/session/retention checks are hermetic.
    # The exclusive manifest scope retains both suites, their concrete import
    # closure, config.yml fallback and the retention-fixture wildcard. This
    # removes only the filesystem probes' unrelated opaque fallback scopes;
    # the code gate, closure audit and packing ceilings remain unchanged.
    "options-matrix-code",
    "push-retry-policy",
    # 2026-10-14 LR T17: the measured-group-read suite is pure-synthetic; the
    # exclusive scope is its measured literal closure (no fallback smear).
    "leadership-measured-read",
    # Paper International: retain the measured ITR closure, dropping opaque fallback.
    "itr-turn-rotation",
    # 2026-10-05 GMI #8455: remove transmission's opaque code fallback.
    # Preserve its concrete imports and dynamic corpus/asset/data inputs.
    # All packing ceilings, commands, data gate and weights remain unchanged.
    "transmission-chains",
    "quant-q01-arbfree-surface",  # Q01 quant assessment: suite imports importlib/subprocess; AST-derived closure
    "nw-lobe-unfreeze",
    "quant-q06-sparse-cal",  # Q06 quant assessment: suite imports importlib/subprocess; AST-derived closure
    "china-search-universe",
    "quant-q02-american-exercise",  # Q02 quant assessment: suite imports importlib/subprocess; AST-derived closure
    # 2026-09-25: the CI control plane's own contracts (this suite included), moved
    # off workflow-yaml, which was `gate: data` and never ran on a PR. Exclusive
    # because its suites read most of the repository: inferred, the job would add
    # one to every packing probe below. Its paths are the suites' import closure
    # plus the files they read. The cover-their-own-import-closure test and
    # check_ci_trigger_closure.py (both run in this job) keep that list honest.
    "ci-control-plane-contracts",
    "live-flow-recovery-guards",
    # 2026-09-23 B-HEAL-CI-PACK-CEILING-2 (main integration-baseline red on
    # this file's own packing-ceiling probe: templates/index.html 132 jobs /
    # 5,810 weight > 5,800; the two code probes over their job ceilings too).
    # Four smear-at-source curations, each an inferred opaque-fallback claim
    # its own block never justified — see the wave note on
    # test_exclusive_curation_narrows_ordinary_code_prs.
    # `market-os-macro-workspaces` is the follow-on named there at the
    # previous wave (B-CUR-MARKET-OS-MACRO-WORKSPACES-1): 21 paths declared
    # at birth without `scope: exclusive`, so a builder subprocess and a
    # jinja loader smeared engine/scripts/templates/site/data onto all three
    # probes. `uk-policy-desk` (#7771) keeps engine/**/*.py + scripts/**/*.py
    # on purpose — its no-scoring-import test rglobs both trees — and sheds
    # only the templates/** loader smear. `options-payoff-lab-consumer`
    # (#7763) reads one template and engine-render.yml as text.
    # `options-catalyst-links` (#7774) is hermetic and reads daily.yml and
    # this manifest as text. Closure-coverage audit: zero misses.
    "market-os-macro-workspaces",
    "uk-policy-desk",
    # 2026-09-24 Finance T1 contract lane: exclusive ownership for the new schema job.
    "finance-intelligence",
    # Consumer Cyclical V1-CORE: contract + deterministic projection. Exclusive
    # for the same reason finance-intelligence is — engine/sector_intelligence/
    # __init__.py pulls launch_slo_verifier -> earnings_narrative -> biocatalyst,
    # so the job's paths must cover its own import closure.
    "consumer-cyclical-economic-change",
    "options-payoff-lab-consumer",
    "options-catalyst-links",
    # 2026-09-23 Prophet US R6 wave 1 (#7823). `prophet-us-b4-prereg-registration` is
    # the gate:code home for tests/test_b4_entry_policy_calibration_prereg.py — its
    # thematic neighbours are `gate: data`. Curated because the measured import
    # closure is empty (stdlib only): the scope is the suite + the registration
    # store + the prose registration, nothing else.
    "prophet-us-b4-prereg-registration",
    "earnings-economic-dossier",
    # 2026-09-30: CDV-1 Task 2 owns truthful private PG acquisition currentness.
    "earnings-economic-source-selection",
    # 2026-09-24 GMI Mining M1 integration T01' (R-MIN-02/R-MIN-26). `mining-economic-dossier`
    # is gate-code pure (synthetic casebook + validator + typed route_unbound harness), so its
    # curated scope is exactly the Mining files it names.
    "mining-economic-dossier",
    "quant-q08-cov-shrinkage",  # Q08 quant assessment: suite imports importlib/subprocess; AST-derived closure
    # 2026-09-24 Healthcare D1 T02: gate:code home for the qualified FDA
    # observation and frozen supply probes; T01 probes remain intentionally red.
    "healthcare-fda-supply",
    # 2026-09-22 UD-B2 W4B (#7712). `markets-regime-strip` is the gate:code
    # home for tests/test_markets_regime_strip.py — its thematic neighbours
    # (engine-render-guards, unrun-picks-boards) are `gate: data`, which the
    # PR packs never plan. Curated for COVERAGE: its `paths:` are the measured
    # 54-path import closure of the suite (scripts/build_markets.py pulls the
    # collectors/ and engine.market_state chains), so exclusivity loses no
    # owner and contract-delta stays at 0 introduced.
    "markets-regime-strip",
    # #7971 (2026-09-25) declared two curated `scope: exclusive` jobs and
    # registered neither, so pure main failed this set-equality assertion from
    # 02:46Z until #7970 carried both pins. This PR retires one of those two —
    # `markets-regime-strip-bake-parity`, the `gate: data` twin that re-ran the
    # fresh-render byte guard — so its pin leaves with the job it named: a
    # registered name with no declaration fails this same assertion from the
    # other side. `p0b-receipt-closure` stays, bound to the live receipts by
    # test_p0b_receipt_closure_job_owns_every_receipt_pinned_path.
    "p0b-receipt-closure",
    # 2026-09-22 Meta-CEO A packet A-F03-W2-2 — store-host skew-accrual lane
    # (#7737). `skew-accrual-lane` is the gate:code home for the five W2-2
    # end-to-end suites (test_skew_accrual_gate/launchd/precheck/verify_ledger
    # + test_audit_options_skew_overlap), the W2-4 parity audit
    # (test_audit_options_skew_parity, #7756) and the two W2-5a payoff-lab
    # suites (test_options_payoff_lab + test_payoff_lab_launchd, #7759) —
    # eight suite runs on one run line. The lane has no signal-contract /
    # render subject — its subjects are the launchd plist, the sh runner,
    # argparse helpers, and the publish_r2._DATA_DIRS options_skew
    # registration — and it was previously parked in
    # config/unrun_test_waivers.yml, which the waiver file's own header
    # forbids for a new dark suite. Curated for COVERAGE: its `paths:`
    # name exactly the eight suites plus the load-bearing scripts they
    # actually invoke and the engine/lib chains those scripts import.
    "skew-accrual-lane",
    # 2026-09-22 A-F03-W2-1b (MO-PAID-013). `options-skew-engine` is the
    # gate:code home for tests/test_options_skew.py. The suite previously
    # lived on `flow-surface` (`gate: data`), which PR packs never plan, so
    # the migration test was dark on every pull request. Curated for
    # COVERAGE: paths are the measured import closure (options_skew,
    # thetadata_store, the builder, and the validate_options_skew import
    # the suite already reaches) plus every live caller whose legacy-source
    # pin the suite reads: engine-render.yml, closing-bell.yml, render.yml,
    # and scripts/ci/daily_engine_regional_desk_builders.sh. Exclusivity
    # drops the data/** filesystem fallback and loses no owner.
    "options-skew-engine",
    # 2026-08-20. `regwall-boundary` carries tests/test_regwall_json_gate.py out
    # of `tier-gate` (`gate: data`, never packed by ci.yml) and onto the merge
    # gate. It is curated for COVERAGE, not to narrow: the suite names its two
    # subjects — app/deploy/Caddyfile and config/site_access.yml — as segment
    # literals (REPO_ROOT / "app" / "deploy" / "Caddyfile"), and no segment
    # holds a `/`, so inference cannot see them and the job would not re-run on
    # the Caddyfile edit that is the whole regression class. Exclusive is what
    # makes the declared paths replace inference instead of riding a whole-tree
    # fallback tier. Sole probe delta: templates/index.html +1, from the five
    # public documents test_public_pages_fetch_nothing_under_paid_prefixes
    # actually reads; the other two probes are unmoved.
    "regwall-boundary",
    "quant-q11-episode-duration",  # Q11 quant assessment: suite imports importlib/subprocess; AST-derived closure
    # 2026-08-19 wave 5. #6027 moved #5984's three dossier suites into
    # conviction-profile — the right call, because their #6023 home
    # (unrun-publish-ops) is `gate: data`, which ci.yml never plans, so they
    # were named by a run: step and still dark on every PR. But those suites
    # import scripts/build_ticker_pages.py and check_stock_dossier_integrity.py,
    # which rglob templates/ and site/, so the job inherited whole-tree
    # fallback claims and newly matched templates/index.html — 128 > the 127
    # ceiling below. Curated rather than paid for: its 59 concrete owned files
    # plus the two templates build_ticker_pages loads by name. Probe returns
    # to 127; weight and pack ceilings unmoved.
    "conviction-profile",
    "unrun-government-revenue-grader",
    "biocatalyst-worker",
    "biocatalyst-serving",
    "quant-q13-rn-tail-density",  # Q13 quant assessment: suite imports importlib/subprocess; AST-derived closure
    "flow-surface",
    "biocatalyst-history",
    "quant-q14-horizon-vrp",  # Q14 quant assessment: suite imports importlib/subprocess; AST-derived closure
    "unrun-subsector-themes",
    "inline-js",
    "quant-q15-noise-robust-rv",  # Q15 quant assessment: suite imports importlib/subprocess; AST-derived closure
    "unrun-picks-boards",
    "intelligence-registry",
    # 2026-08-14 wave 2: the manifest grew 180→193 jobs and the new fallback
    # riders pushed scripts/build_free_content.py to 127 > 126, redding pack-1
    # fleet-wide. Curated: the three NEW subject-guards whose owner-written
    # `paths:` cover their measured import closure (dataos-foundation widened
    # by 6 files per the audit below; momoedge/vintage covered as written).
    # dataos-identity-seams was EVALUATED AND REJECTED — its genuine closure
    # spans 43 files across engine/, so exclusivity would either lie about
    # coverage or degenerate to fallback breadth; it stays inferred, like the
    # other new riders without paths (product-experience-capture/-registry,
    # wri-risk-core).
    "dataos-foundation",
    "momoedge-browser-observe",
    "vintage-pin-fence",
    # 2026-08-14 wave 3. options-estate-guards was listed above as a rider that
    # would stay inferred; that call is superseded. #5634 gave it
    # tests/test_options_gap_discipline.py, whose closure carries an opaque
    # construct, and the resulting whole-tree fallback claim made this job a
    # NEW selector on all three ratchet probes — smear, not evidence, and the
    # reason scripts/build_free_content.py ran out of headroom. The
    # dataos-identity-seams rejection does not transfer: an engine-heavy
    # closure only degenerates to fallback breadth when it needs `engine/**`,
    # and this one does not — its 35 engine files are top-level modules plus
    # four whole subpackages, so `engine/*` + four `engine/<pkg>/**` covers the
    # closure exactly and leaves engine/prophet/** outside. Measured: 100
    # closure files, zero uncovered; fallback tier drops to (); all four
    # probes in the test below were fallback-tier before and are unmatched
    # after, so nothing owned was lost.
    #
    # Derive that closure against a FULL checkout. `site` is in
    # audit_unrun_tests.FIRST_PARTY, but site/ literals are admitted through
    # `(ROOT / rel).is_file()`, which answers False for a tree a sparse
    # worktree omitted -- so the same job derives 85 files there and silently
    # loses all 15 site/ members. The first version of this curation was
    # derived sparse, declared `site/<dir>/**` for the 13 members it could
    # see, and was red HERE on the two top-level ones it could not
    # (site/flow_desk.json, site/options.html). This test is the check that
    # catches it; a sparse local run of it is not evidence that it passes.
    "options-estate-guards",
    "quant-q18-async-session-cov",  # Q18 quant assessment: suite imports importlib/subprocess; AST-derived closure
    # 2026-08-15 wave 4. The two jobs the #5754 re-base below deferred. Both had
    # NO owned tier at all — every inferred pattern was opaque fallback — after
    # scripts/build_china_library.py gained engine/china_intel_interest.py, whose
    # lazy china_intel_hub import reaches the full altdata convergence universe.
    # Neither reads templates/index.html; both matched it, which is what took
    # that probe 127 -> 129. Curated at the source instead of paid for again.
    #
    # These two are NOT the same declaration, and the difference is the point:
    # cn-standout-audit globs `scripts/**` because two of its suites rglob that
    # tree and AST-scan every hit (test_cn_board_lane_gate.py:361,
    # test_cn_entry_price_integrity.py:527) — the tree is their SUBJECT, so
    # enumerating it would stop the guard covering the new scripts it exists to
    # catch. coiled-mtf-anchor-era's two suites carry no traversal at all, so its
    # six scripts/ files are enumerated. Both glob `collectors/**`: the dynamic
    # import at build_china_library.py:1807 resolves seven collectors.tushare_*
    # drip modules the walker cannot see, so they are invisible to the coverage
    # test and enumeration would drop them silently.
    "cn-standout-audit",
    "coiled-mtf-anchor-era",
    "quant-q19-first-passage-ambiguity",  # Q19 quant assessment: suite imports importlib/subprocess; AST-derived closure
    # 2026-08-20 main-red-repair. serving-observability (#6115, Sentry arm for
    # the macro-api serving tier) shipped with no scope at all. Its own subject
    # (_release()'s `subprocess.run(["git", ...])` for the deployed SHA) is an
    # opaque subprocess call scope inference cannot see through, so it fell back
    # to SUBPROCESS_ROOTS — including site/** and templates/** — and matched
    # every ordinary templates/index.html PR (128 > the 127 ceiling below).
    # Curated at the source: its true subject is exactly app/observability.py
    # and tests/test_observability_sentry.py, both declared and covered.
    "serving-observability",
    # 2026-08-20 main-red-repair (same wave). govrev-company-bridge (D4
    # Company Financial Truth Bridge) also shipped with no scope. Its suite's
    # own `node` subprocess call (tests/test_government_revenue_company_bridge.py:197)
    # resolves to `subprocess roots=templates,tests`, widening to templates/**
    # and matching every ordinary templates/index.html PR. Curated at the
    # source: its true subject is the frozen fixture plus the two template
    # files its own header comment already documents as the only reads.
    "govrev-company-bridge",
    "quant-q20-spa-challenger",  # Q20 quant assessment: suite imports importlib/subprocess; AST-derived closure
    # #6117 (records(dislocation): P0-A1 price-blind candidate harvest) shipped
    # its own `scope: exclusive` declaration pre-curated — registered here so
    # this file's pin does not drift from the manifest (no fix required, the
    # job's own paths: already cover its full closure).
    "dislocation-p0-a1-blind-harvest",
    # 2026-08-26 (PR #6454): the D6-A + D6-B1 defense rail batteries moved
    # onto the merge gate (they sat in gate:data unrun-government-revenue,
    # which ci.yml never plans, so both commissioned merge-binding suites
    # were dark). tests/test_fms_ui.py imports app.government_revenue for
    # its route-boundary tests, whose closure's opaque edges smear whole-tree
    # fallback claims (app/**, templates/**, site/**) — measured
    # fallback-matching all four probes below and pushing
    # templates/index.html to 130 > 129. Curated at the source, same
    # treatment as stock-dossiers / cn-standout-audit / govrev-company-bridge:
    # the declaration names the earned 563-file closure (flat engine/*.py +
    # the read subpackages, deliberately not engine/**), the frozen fixture
    # trees, and the sha-frozen staged goldens.
    "defense-rail-laws",
    # 2026-09-04 (F01 R1B): the macro-suite page family, exclusive at birth.
    # The page builder's jinja FileSystemLoader is an opaque construct whose
    # fallback smear claimed templates/** and pushed templates/index.html to
    # 132 > 131 on the probe below. The declaration names the page family's
    # own closure (five templates, the two suite libs, lib/pages, the
    # workspace contract/registry, the published artifacts); the build_site
    # hook guard moved to tests/test_render_builder_ownership.py so this
    # job's closure stays the page family rather than the whole site builder.
    "market-os-macro-suite-pages",
    # 2026-09-05 (P0B current-head repair): the first-frame suite executes its
    # frozen Jinja/browser recipes through subprocess boundaries. Inference
    # therefore conservatively added scripts/**, site/**, and templates/**,
    # making this four-second gate a fallback selector for unrelated index and
    # free-content edits. The suite no longer imports the broad Canada/HK test
    # helpers; its measured 30-file closure is now declared exactly (including
    # the two moving-data path *labels* the recipe validates but never opens).
    # Exclusivity drops only those three opaque fallback roots while retaining
    # every executable, template, fixture, receipt, and helper input it owns.
    "stock-dashboard-first-frame",
    # 2026-09-22 main-red repair. Six jobs entered the broad
    # templates/index.html probe after the 64f8c248 calibration even though
    # none owns that page; market-ontology-f09-usgs-mcs separately entered the
    # build_free_content probe through a bounded subprocess/git-grep edge; and
    # unrun-government-revenue-candidate-projection entered the Prophet probe
    # through an opaque engine/** edge despite no plan-book file in its named
    # closure. Their declarations retain the measured full import closure plus
    # dynamic files read by the tests/builders. This restores 131/129/125
    # selections without raising the existing ratchet or allowing unrelated
    # fallback smear.
    "am-edition-producer",
    "covenant-headroom",
    "cycle-consistency",
    "ftr-tape-surfaces",
    "market-ontology-f09-usgs-mcs",
    "research-screener",
    "sanctions-map-page",
    "unrun-government-revenue-candidate-projection",
    # 2026-09-16 main-red repair. #7164 created a deliberately bounded,
    # hermetic PR owner for one recovered package and its root lineage test,
    # and declared both exact path surfaces — but omitted `scope: exclusive`.
    # Inference therefore unioned opaque package-test edges into whole-tree
    # fallback breadth and made this job a third unscoped always-on selector
    # for templates/index.html (133 > 132). Curate the stated owner boundary;
    # do not fund that unrelated match by raising the packing ceiling.
    "research-vault-source-lineage",
    # 2026-09-24 GMI INDUSTRIALS first vertical T01 (PR #7924, R-IND-02).
    # `industrials-result-cash` is the gate:code home for the synthetic
    # result-to-cash corpus, helper harness, and delivery-input validator.
    # One exclusive gate:code job for the whole Industrials program; every
    # later task (T02+) appends its suite to `paths:` and the run line (never
    # a second job). The suite imports three engine modules directly
    # (documents, financial_dossier, earnings_narrative.private_publication)
    # and reads the corpus. TWO non-stdlib transitive needs, both carried by the
    # job's install line: pyyaml (engine.earnings_narrative.promotion -> yaml) and
    # requests (scripts.refresh_event_workspaces:77 imports
    # engine.neuralweb.company_intelligence_reader, whose module scope imports
    # requests at :21). A T02+ suite appended to this job must keep BOTH.
    "industrials-result-cash",
    # 2026-09-23 gate:data -> PR-gate follow-up to #7712. `dashboard-render-contract`
    # is the gate:code home for the five suites that only gate:data lanes
    # (unrun-picks-boards, engine-render-guards) ran, so the #7503 pins in
    # tests/test_dashboard_template_render.py and the HK/CN spine-binding
    # contract in tests/test_unified_dashboard_b2w2.py never gated a PR.
    # Curated for COVERAGE: its `paths:` are the measured import closure of the
    # suites (scripts/build_site.py pulls most of engine/ and lib/), so
    # exclusivity loses no owner and contract-delta stays at 0 introduced.
    "dashboard-render-contract",
    # 2026-09-25 BC-2 gate:data -> PR-gate. `validated-claims-source` runs the
    # checker's `--scope source` scan over templates/**, engine/** and lib/** on
    # every PR that can move it — those trees ARE its subject, so it rides the
    # broad probes on purpose and carries only its two stdlib steps.
    # `validated-claims-contract` runs the checker's suites, selected by the
    # checker, the allowlist, the suites and their measured closure. Both are
    # exclusive because inference would smear the checker's traversal roots
    # (site/**, data/**) onto them — files that cannot move either verdict.
    "validated-claims-source",
    "validated-claims-contract",
    # 2026-10-03 Terminal599 OA-1C canonical-history repair (#8342 follow-up):
    # the options-alpha candidate feed composer is a code-plane artifact
    # (engine/options_alpha_candidate_feed.py + every schema it validates
    # against + the formation policy v2 JSON + the architecture / OA-1C
    # DECs), not a flow-surface data artefact. The composer was previously
    # registered on the gate:data flow-surface job; that lane's broader
    # site/templates/data ownership was reaching the test path through
    # opaque-fallback inference, and a future edit to a flow-surface file
    # could select this suite without the right behavioural checks running.
    # The exclusive declaration pins the exact transitive closure of the
    # composer (campaign engine + signal episode + ledger lane + session
    # digest + lib helpers + OPTIONS_SIGNAL_CAMPAIGN_V2_PREREG the test
    # reaches through dynamic importlib loads); widening is always the
    # safe direction.
    "options-alpha-candidate-feed",
    # 2026-10-03 PR #8350: options-signal-campaign-v2 is the gate:code owner
    # of tests/test_options_signal_campaign_effective_view.py. scope:
    # exclusive replaces inference, so the declared job must be pinned here
    # or the curated-set contract rejects the manifest.
    "options-signal-campaign-v2",
    # Pure International browser helpers have a closed source/test dependency
    # set; unrelated page changes must not select their Node-only PR check.
    "international-workspace-pure-js",
    # Numerical records reuse the performance owner's measured import closure.
    "international-workspace-foundation",
    # Actual macro template/controller with explicit supplied-frame browser fixture.
    "international-workspace-browser",
    # 2026-10-20 W28C-L29: the China Mechanics display suite renders its page
    # template and imports the builder (lib/config, lib/pages, lib/site_assets,
    # engine/i18n). As an ordinary job its inferred scope would widen the
    # templates/index.html packing probe past its ceiling. scope: exclusive
    # pins the measured static closure plus templates and ancestor inits.
    "china-mechanics-display",
    # 2026-10-05 GMI #8455 (lane gmi_a_packing_r1): regime-outlook-mapping's
    # reader import (world_state -> theme_state_generation_reader ->
    # theme_graph/thematic_state -> scripts/build_thematic_state.py) was an
    # opaque code fallback, so every ordinary code PR selected it. The exact
    # closure is now declared; packing ceilings remain unchanged.
    "regime-outlook-mapping",
    # 2026-10-07 PB-D event-quality implementation (#8576): one gate:code
    # job owns all four PB-D suites. Its exclusive declaration covers the
    # measured 50-path import/read closure; packing ceilings stay unchanged.
    "pb-d-event-quality",
    # 2026-10-07 Package N #8454: Terminal per-ticker news qbus correctness kernel.
    # gate:code home for the twenty-two ticker-news/qbus suites; scope: exclusive
    # so inference does not smear the measured import closure across ordinary code
    # PRs. paths: are the job's suite import closure; the cover-their-own-import-
    # closure test keeps that list honest as the tree moves.
    "ticker-news-qbus",
    # 2026-10-07 RS source delivery: retain the reviewed source-owner inventory.
    # Exact inventory only; scope audits and packing ceilings remain unchanged.
    "entry-radar-rs-pullback-calendar",
    # PR #9199: actual-file identity reader; keep equality and closure gates intact.
    "entry-radar-identity-snapshot",
    # 2026-10-07 RS source delivery: Register the reviewed native-reference owner and its complete declared read closure.
    # Exact inventory only; scope audits and packing ceilings remain unchanged.
    "dataos-prospective-reference",
    # 2026-10-13 Data OS completion acceptance suites (A02/A03/R01) - closure measured
    # against main's own inference; seat applies the legacy-jobs.yml half.
    "dataos-acceptance",
    "ratio-lens",
    # 2026-10-09 PR #8667: file and pinned-source relationship inspection.
    # Register the reviewed 68-path owner; closure audits and ceilings stay fixed.
    "company-relationship-candidates",
    # WP02 source-diagnostic research kernel: exact inputs and shared pytest imports.
    # Preserve closure audits, packing limits and incumbent owner declarations.
    "gmi-source-diagnostic-kernel",
    # Reviewed template-root curation; preserve other opaque domains and ceilings.
    "integrated-answer-v0",
    # 2026-10-11 PR #8758: bounded Data OS readers and canonical Lab access.
    # Register the reviewed 42-path owner; closure audits and ceilings stay fixed.
    "dataos-web-workspace",
    # 2026-10-13 Data OS completion verification suites (Q01/Q02/Q03/F01/A01) - closure
    # measured against main's own inference; seat applies the legacy-jobs.yml half.
    "dataos-verification",
    # 2026-10-12 PR #8873: news-impact Phase 0 contract freeze. Owner closure is
    # company_intelligence/** plus earnings_narrative/contracts.py; ceilings stay fixed.
    "news-impact-contracts",
    # 2026-10-11 #8805: the Information-to-Price receipt suites (SRC-A1, PIT
    # conformance, R4 V2 admission, EVAL-1 partition clock, EVAL-1 challenger
    # identity) leave unrun-factor-research, whose opaque engine/** and
    # collectors/** fallback smeared them onto templates/index.html and pushed
    # that probe to 5,802 (main) / 5,805 (this head) against its 5,800 ceiling.
    # Register the reviewed 18-path owner; closure audits and ceilings stay fixed.
    "information-to-price-eval-receipts",
    # 2026-10-11 lineage wave (#8802): leader-radar-unit gained the lineage
    # descriptor step (+3 weight) while still an opaque always-on selector:
    # inference smeared the builder's jinja loader (templates/**), the
    # integration suite's data/site roots and the lineage suite's AST import
    # scan (engine/**, scripts/**) onto it, so two packing probes breached on
    # the PR's merge ref (templates/index.html 5,806 > 5,800, where main was
    # already over at 5,802; scripts/build_free_content.py 5,603 > 5,600).
    # paths: = the measured 43-path import/read closure + the rendered
    # template and its include chain. Measured on the merged FULL checkout:
    # index.html 5,806 -> 5,781, build_free_content 5,603 -> 5,578, plan_book
    # 5,563 -> 5,538; the fallback tier drops to (); ceilings unchanged. Derive
    # the closure against a FULL checkout: the two site/ JSON literals are
    # invisible on a sparse tree, exactly as the options-estate-guards note warns.
    "leader-radar-unit",
    # The private runtime boundary has a closed helper/unit/updater/test scope.
    "company-intelligence-private-runtime",
    # 2026-10-11 SNI E0/M0 (#8837): the Alibaba/Tencent coverage-profile suite
    # reads only its own config/contracts trees; its 3-path owner is the whole
    # closure (closure findings 0, gated-unrun 0), so no inference fallback.
    "single-name-coverage-profiles",
    # 2026-10-12 Crypto Intelligence R2 (#8901, T23 pre-review BLOCKER B1): the
    # nine vector/BTC behavior suites leave `unrun-vector-dsr`, whose `gate: data`
    # made them DARK on every pull request (ci.yml plans `--gate code`;
    # DSC:A-DATA-GATED-JOB-IS-DARK-ON-EVERY-PULL-REQUEST), and whose inferred
    # weight 35 -> 54 pushed the packing probes over their ceilings on #8901's
    # merge ref (index.html 5,801 > 5,800; build_free_content 5,602 > 5,600).
    # paths: = the measured 360-path import/read closure of the nine suites
    # (collectors, config, engine incl. btc_*, lib, scripts incl. build_vector /
    # backfill_crypto / check_crypto_shelves, templates/crypto.html.j2, the three
    # site/ literals check_contract_delta surfaced). Measured on the merge ref:
    # probes return to base exactly (index.html 5,782, build_free_content 5,585,
    # plan_book 5,545); closure findings (); ceilings stay fixed — the #8805 shape.
    "crypto-vector-r2-organs",
    # 2026-10-13 cx-int engine: crypto-assistant-context. The crypto
    # assistant-context contract's import closure is the whole Mastermind
    # chat stack (context compiler, brain gateway, market packet, native
    # facts). It runs alone under scope: exclusive with that measured
    # closure instead of widening crypto-vector-r2-organs onto every
    # chat-stack change; closure findings stay empty and the probes keep their
    # base readings.
    "crypto-assistant-context",
    # 2026-10-12 Taxonomy V2 L05-L11: gmi-classification-axes. The geography
    # reader names scripts/build_security_master.py by path (its subprocess
    # call and parquet traversal join the closure) and the registry imports
    # axis modules by computed name. Both smeared the job onto the
    # build_free_content / plan_book packing probes. scope: exclusive pins it
    # to its measured closure, so it must be listed here.
    "gmi-classification-axes",
    # GovRev dependency changes must not select GR3 on unrelated page templates.
    "group-linked-outsiders",
    "govrev-program-ontology",
    # 2026-10-12 FIF kernel guards (seat ruling, candidate y): the class-A
    # Financial Intelligence Fabric suites moved off the data-health lanes.
    # Inference would union ~139 fallback roots (the app/ TestClient suites
    # import app.main) and breach all three PACKING_PROBES; scope: exclusive
    # pins the job to the FIF globs plus its measured static/runtime closure.
    "fif-kernel-guards",
    # 2026-10-12 SNI S2 event response (#8893): the runner's `git` subprocess
    # calls and the language test's rglob are opaque, so inference widened
    # the fallback to engine/** and the plan_book packing probe selected the
    # job (130 > 129). scope: exclusive pins it to its measured closure.
    "sni-s2-event-response",
    # 2026-10-13 SNI INT1: the shared inference/seal library, evaluation
    # ledger, US stress set and draft-prereg loaders import through sys.path
    # inserts. scope: exclusive pins the job to their measured closure so the
    # research/ fallback roots never reach the packing probes.
    "sni-shared-and-drafts",
    # 2026-10-13 SNI INT1: the cross-cutting guard suite (matrix, equivalence,
    # invariants, quarantine fence, run-seal repro, SCHK, A20, US stress) loads
    # through the same sys.path inserts; pinned to its measured closure.
    "sni-program-guards",
    # 2026-10-13 SNI INT1: the public-exposure scan reads publish surfaces as
    # TEXT (closure-marked data). Unpinned, those literal script names pulled
    # build_site.py's 757-file import closure into the job and every packing
    # probe selected it (templates/index.html 5815 > 5800). It declares its
    # scanned surfaces instead and pins them in its own test.
    "sni-public-exposure-scan",
    # 2026-10-13 SNI INT2: the acceptance-evidence suite (A03/A04/A07/A10/A12,
    # copy guard, A33, A36, A39, P03 ULP, register consistency) imports the
    # acceptance/, residual/, event_response/ and us_stress/ modules through
    # sys.path inserts; pinned to its measured closure like sni-program-guards.
    "sni-acceptance-evidence",
    # 2026-10-13 Grey Deer W3 (#8938): the stage-1 pullback runner suite reads
    # its own research tree, lib.nyse_calendar and the trial ledger. scope:
    # exclusive pins it to that measured closure (57 paths once W4 added the
    # stage-1b suites), so inference never unions the research/ fallback roots
    # onto the packing probes.
    "grey-deer-pullback-stage1",
    # 2026-10-13 Grey Deer W5 (#9128): the pullback forward-lane suites import
    # the frozen stage-1 runner, whose lazy risk_radar closure made inference
    # select the job on the plan_book (130 > 129) and build_free_content
    # (135 > 134 jobs, 5,604 > 5,600 s) probes. scope: exclusive pins it to its
    # measured 63-path closure; closure findings (); ceilings stay fixed.
    "grey-deer-pullback-forward",
    # 2026-10-13 FIF X2-n saved-research notifications (seat R3): the three
    # hermetic suites reach engine.fundamental_forensics and the research-vault
    # store, so inference unioned the whole-tree fallback roots and selected the
    # job on the PACKING_PROBES (check_contract_delta: 3 introduced findings).
    # scope: exclusive pins it to its derived import closure.
    "fif-saved-research-notifications",
    # 2026-10-13 Grey Deer GD-4C: the stdlib-only PBOC liquidity classifier.
    # As a step in china-native-collectors it moved templates/index.html to
    # 5,816 > 5,800; its own exclusive job keeps the import closure only.
    "grey-deer-pboc-liquidity",
    # 2026-10-20 W27-L27: the China Alt-Data catalyst-card render tests. As a
    # step in unrun-template-chips they moved the index-template (5,825 > 5,822)
    # and build_free_content (5,700 > 5,697) packing probes; its own exclusive
    # job keeps the static import closure plus ancestor inits; ceilings stay fixed.
    "china-altdata-catalysts",
    # 2026-10-13 main packing-probe heal: Node harness subprocesses, a git
    # subprocess and filesystem traversals rooted at templates/, scripts/,
    # engine/, data/ and site/ widened inference for these two lanes to those
    # whole roots, so both selected on all three PACKING_PROBES without
    # importing or naming a probe file (CI measured
    # scripts/build_free_content.py at 5604 > 5600 on main). scope: exclusive
    # pins each to its measured static closure plus its fixture globs.
    "research-price-panel",
    "washout-turn-organ",
    # 2026-10-14: rotation AST/render fallback curation; retain full static
    # closure plus observed runtime inputs. Assertions and probe limits stay fixed.
    "leadership-rotation-contract",
    "lr-rotation-evidence-modes",
    # 2026-10-14 RIC E0 (#9282): the M0/X0 retrospective-runner suites reach
    # the release-forecast stack, whose collector and neuralweb imports made
    # inference select the job on the build_free_content probe (135 > 134
    # jobs, check_contract_delta: 1 introduced). scope: exclusive pins it to
    # its declared static import closure; ceilings stay fixed.
    "ric-e0-retrospective-runners",
    # 2026-10-14 LR T11-T14 (WS:LEADERSHIP-ROTATION-INTELLIGENCE): the prereg
    # study harness suites are hermetic (synthetic arrays + tmp git fixtures);
    # scope: exclusive pins the job to its measured suite_dependency_closure.
    "leadership-rotation-science",
    # 2026-10-20 W27-L26: the China Sector Desk turn-signature gate render tests.
    # As a step in unrun-template-chips they moved the index-template
    # (5,825 > 5,822) and build_free_content (5,700 > 5,697) packing probes; its
    # own exclusive job keeps the static import closure plus ancestor inits.
    "china-sector-desk-gate",
    # 2026-10-14 LEADERSHIP-ROTATION T20 (LR-CHAL-T20R): the integrated counter-case suite reads
    #  scripts/build_sector_central.py via ast and the T18 panel template, so inference smeared it onto
    #  scripts/build_free_content.py (135 > 134). Register the reviewed 199-path owner (rates_command_basis.py added after #9317 widened the closure); closure audits and ceilings stay fixed.
    "leadership-rotation-countercases",
    # Fixed-runtime helpers have a separate source-only CI owner.
    "research-codegen-runtime-qualification",
    # 2026-10-17 C19 WP22: the DHI traversal suite's app/engine imports made
    # inference select it, at the fallback tier only, on the index-template
    # (137 > 136 jobs) and build_free_content (135 > 134) packing probes;
    # check_contract_delta: 2 introduced. scope: exclusive pins it to its
    # declared static import closure plus ancestor inits; ceilings stay fixed.
    "c19-wp22-dhi-traversal",
    # 2026-10-17 C19 WP31: the incremental-information evaluator's engine/lib
    # imports made inference select it on the same index-template (137 > 136)
    # and build_free_content (135 > 134) packing probes; check_contract_delta:
    # 2 introduced. scope: exclusive pins it to its declared static import
    # closure plus ancestor inits; ceilings stay fixed.
    "c19-wp31-incremental-information",
    # 2026-10-20 W28-L28: the CN Pick Lab SCOREABLE/close_at_fire render tests.
    # Appended to pick-lab-liquidity's run line they moved the index-template
    # packing probe (5,824 > 5,822); its own exclusive job keeps the static
    # import closure, the engine/pick_lab package imports and ancestor inits.
    "pick-lab-cn-render",
    # 2026-10-20 W28G-L31: the THS basket browser notes suite renders the factorwatch
    # template and its five includes with jinja2 and the new pure helper alone. As an
    # ordinary job its inferred scope would ride the shared template packing probes;
    # scope: exclusive pins the template closure, the helper, the suite and the inits.
    "ths-factorwatch-build-notes",
    # 2026-10-20 W28F-L30: the China narrative radar display suites render the page
    # template and its six includes with jinja2 alone. As an ordinary job their
    # inferred scope would ride the shared template packing probes; scope:
    # exclusive pins the template closure, both suites and the tests inits.
    "narrative-radar-display",
    # 2026-10-20 W28D-L33: the commodity strategies grid suite renders the page
    # template and its six includes with jinja2 and the new pure helper alone. As an
    # ordinary job its inferred scope would ride the shared template packing probes;
    # scope: exclusive pins the template closure, the helper, the suite and the inits.
    "commodity-strategies-grid-fields",
    # 2026-10-20 W28E-L32: the China reversal sleeve display suite renders the page
    # template and its three includes with jinja2 alone. As an ordinary job its
    # inferred scope would ride the shared template packing probes; scope:
    # exclusive pins the template closure, the suite and the tests inits.
    "cn-reversal-sleeve-display",
    # 2026-10-20 W28B-L34: the HK / Canada scoreboard suite renders both desk
    # templates and their five includes with jinja2 and the new pure helper alone. As
    # an ordinary job its inferred scope would ride the shared template packing probes;
    # scope: exclusive pins the template closure, the helper, the suite and the inits.
    "regional-baskets-scorecard",
    # 2026-10-18 C19 WP32: the P5/P6 integrated-answer pins import app/ and
    # engine/ modules, so inference selected the new job on the
    # build_free_content (135 > 134) and index-template (137 > 136) packing
    # probes. scope: exclusive pins it to its declared static import closure
    # plus ancestor inits; ceilings stay fixed.
    "c19-wp32-integrated-answer-correction-denial-pins",
    # 2026-10-20 W28D-L35: the China strategies income-tile suite renders the page
    # template and its six includes with jinja2 and the new pure helper alone. As an
    # ordinary job its inferred scope would ride the shared template packing probes;
    # scope: exclusive pins the template closure, the helper, the suite and the inits.
    "china-strategies-income-tile",
    # 2026-10-20 F10 native CSV runner: its CLI test enumerates tmp_path
    # fixtures, which opaque inference smeared onto build_free_content
    # (135 > 134 jobs, 5,646 > 5,642 weight; contract-delta run39355888732).
    # Pin the full measured static closure (including the native ALFRED panel) plus ancestor inits and
    # pytest fixture owners. No suite/assertion/packing ceiling is removed.
    "local-projections",
}


def _inferred_as_if_not_exclusive() -> dict[str, PACK.LegacyJob]:
    """What inference WOULD derive for the curated jobs, exclusivity aside.

    Thin wrapper over the shared ``scripts.run_ci_pack.inferred_as_if_not_exclusive``
    — kept so the other call sites below need no change; the computation itself now
    lives in exactly one place (see the import block above).
    """
    return inferred_as_if_not_exclusive(MANIFEST)


def test_the_curated_exclusive_set_is_actually_declared() -> None:
    """The set this file pins must be the set the manifest declares."""
    declared = {job.job_id for job in PACK.load_legacy_jobs(MANIFEST) if job.exclusive}
    assert declared == CURATED_EXCLUSIVE, sorted(declared ^ CURATED_EXCLUSIVE)


def test_research_vault_source_lineage_is_curated_to_its_recovered_package() -> None:
    """The recovered MarketDesk owner must not become a whole-tree CI rider."""
    manifest = _yaml(MANIFEST)
    job = manifest["jobs"]["research-vault-source-lineage"]

    assert job["gate"] == "code"
    assert job["scope"] == "exclusive"
    assert set(job["paths"]) == {
        "collectors/marketdesk_extractor/**",
        "tests/test_marketdesk_extractor_lineage.py",
    }


def test_curated_exclusive_scopes_cover_their_own_import_closure() -> None:
    """Zero MISS: every file a curated job imports must still select it.

    `scope: exclusive` REPLACES inference, so the declared paths are the whole
    scope — a closure file with no matching pattern is a job that stops running
    when its own dependency changes, and reports green forever. The manifest's
    load-time coverage audit only reaches the paths a job's COMMANDS name; the
    transitive import closure is one layer deeper and is checked here.

    The computation itself is ``scripts.run_ci_pack.curated_exclusive_closure_findings``
    — the same function ``scripts/check_contract_delta.py`` calls for the head side
    of its PR-vs-base delta, so this test and that gate can never quietly diverge on
    what "covered" means.
    """
    misses_full = curated_exclusive_closure_findings(MANIFEST)
    misses = {job_id: list(paths[:8]) for job_id, paths in misses_full.items()}
    assert not misses, (
        "curated exclusive scope(s) no longer cover their own import closure:\n  "
        + "\n  ".join(f"{k}: {v}" for k, v in misses.items())
        + "\n\nA new import reached a tree the declaration does not name, so that "
        "job silently stopped running for edits to it. Widen the job's `paths:` "
        "in .github/ci/legacy-jobs.yml to cover the listed files — widening is "
        "always the safe direction."
    )


def test_d5_route_closure_keeps_affected_curated_jobs_selecting_dependencies() -> None:
    """D5's Prophet Lab route closure must not become a five-job false green.

    These are the concrete dependencies introduced through ``app/prophet_lab.py``.
    The generic closure audit above re-derives the complete graph; this regression
    independently pins the exact five-job D5 repair so a future inference change
    cannot silently erase the manifest ownership that this branch requires.
    """
    required = {
        "biocatalyst-history": (
            "engine/path_risk_signals.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
            "engine/stock_identity/__init__.py",
            "engine/stock_identity/authority.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
            "engine/stock_identity/fingerprint.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
            "engine/stock_identity/plane.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
            "engine/us_candidate_episode.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        ),
        "biocatalyst-serving": (
            "engine/path_risk_signals.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
            "engine/stock_identity/__init__.py",
            "engine/stock_identity/authority.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
            "engine/stock_identity/fingerprint.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
            "engine/stock_identity/plane.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
            "engine/us_candidate_episode.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        ),
        "defense-rail-laws": (
            "engine/stock_identity/__init__.py",
            "engine/stock_identity/authority.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
            "engine/stock_identity/fingerprint.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
            "engine/stock_identity/plane.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        ),
        "flow-surface": (
            "engine/path_risk_signals.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
            "engine/stock_identity/__init__.py",
            "engine/stock_identity/authority.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
            "engine/stock_identity/fingerprint.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
            "engine/stock_identity/plane.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
            "engine/us_candidate_episode.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        ),
        "unrun-government-revenue-grader": (
            "engine/path_risk_signals.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
            "engine/stock_identity/__init__.py",
            "engine/stock_identity/authority.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
            "engine/stock_identity/fingerprint.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
            "engine/stock_identity/plane.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
            "engine/us_candidate_episode.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        ),
    }
    jobs = {job.job_id: job for job in PACK.load_legacy_jobs(MANIFEST)}

    for job_id, dependencies in required.items():
        job = jobs[job_id]
        assert job.exclusive, job_id
        for dependency in dependencies:
            selected, reason = PACK.select_jobs([job], [dependency])
            assert [item.job_id for item in selected] == [job_id], (
                job_id,
                dependency,
                reason,
            )
            match = PACK._job_diff_match(job, [dependency])
            assert match and match[1] == "declared", (job_id, dependency, match)


def test_unrun_picks_boards_owns_macro_risk_dialog_locale_token_source() -> None:
    """The risk-dialog suite reads the shipped token source, so its job owns it."""
    jobs = {job.job_id: job for job in PACK.load_legacy_jobs(MANIFEST)}
    job = jobs["unrun-picks-boards"]

    assert job.exclusive is True
    assert "site/theme.css" in job.paths  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
    selected, reason = PACK.select_jobs([job], ["site/theme.css"])  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
    assert [item.job_id for item in selected] == [job.job_id], reason
    match = PACK._job_diff_match(job, ["site/theme.css"])  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
    assert match and match[1] == "declared", match


def test_curated_exclusivity_drops_only_the_opaque_fallback_tier() -> None:
    """Every job the curation stops selecting was selected by smear, not evidence.

    This is the whole safety argument for the wave: exclusivity removes the
    opaque `site/**`-shaped claims a subprocess deep in the closure minted, and
    removes nothing that named the changed file as a real dependency.
    """
    would_infer = _inferred_as_if_not_exclusive()
    curated = {job.job_id: job for job in PACK.load_legacy_jobs(MANIFEST)
               if job.exclusive}
    probes = [
        "templates/index.html",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        "site/theme.css",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        "engine/prophet/plan_book.py",
        "scripts/build_free_content.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
    ]
    owned_losses: list[str] = []
    for job_id, job in sorted(curated.items()):
        before = would_infer[job_id]
        for probe in probes:
            was = PACK._job_diff_match(before, [probe])
            now = PACK._job_diff_match(job, [probe])
            if was and not now and was[1] != "fallback":
                owned_losses.append(f"{job_id} lost {probe} (tier={was[1]})")
    assert not owned_losses, owned_losses


# The packing probes and their ceilings: (changed path, max selected jobs, max
# selected weight-seconds), plus one pack ceiling for every probe. The history of
# each number is the docstring of the test below. scripts/check_contract_delta.py
# reads both names with ast.literal_eval, so keep them plain module-level literals.
PACKING_PROBES = (
    ("templates/index.html", 136, 5_829),  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
    ("scripts/build_free_content.py", 135, 5_795),  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
    ("engine/prophet/plan_book.py", 130, 5_600),
)
# Twelve packs per shape was the pre-curation measurement.
PACKING_PROBE_MAX_PACKS = 10


def test_exclusive_curation_narrows_ordinary_code_prs() -> None:
    """The measured before/after this wave exists to produce.

    2026-10-20 private company-news drafts bind the existing Press run/writer
    suites to ticker-news-qbus's code gate. The prior press-lane is data-gated,
    so it cannot prove an ordinary source PR. The unchanged canonical closure
    follows Press validators into scripts.build_free_content; dropping that
    dependency or either suite would remove real coverage. The news job keeps
    scope: exclusive with literal paths and adds no fallback or wildcard root.
    Full contract-delta on e6f78cfc against main 2d34f640 measured:

        templates/index.html          135 jobs, 5,822 -> 5,822 weight
        scripts/build_free_content.py 134 -> 135 jobs, 5,697 -> 5,795 weight
        engine/prophet/plan_book.py    128 jobs, 5,571 -> 5,571 weight

    The sole new selected job is ticker-news-qbus, exactly 98 estimator units.
    All three probes stay at ten packs. Record only that measured code-coverage
    addition: build's job ceiling 134 -> 135 and weight 5,697 -> 5,795, without
    padding. Other probe ceilings, the ten-pack limit, selector code, ancestor
    ratchet and every prior suite remain unchanged. Planning weights are not
    measured execution times. Retained red/green contract receipts accompany
    this candidate; current-head CI must execute this assertion.

    2026-10-19 Research Vault full-body/producer composition: the existing
    code-gated job gains its complete 36-suite invocation (estimated weight
    43 -> 76). Its exact tracked-tree import/read closure is now exclusive,
    with Jinja and committed page assets declared explicitly. This removes the
    template probe's opaque fallback selection while preserving the real
    scripts.build_free_content dependency reached through press.validators.
    Hosted contract-delta39234988640 measured build_free_content 5,576 -> 5,609;
    the scoped local probe independently measured 134 jobs / 5,609 against 5,600.
    The protected ff1b80af refresh also adds two alert-email suites (+4),
    producing the current measured 134 jobs / 5,613. The exact local four-case
    audit passed declaration, complete dependency coverage and opaque-tier-only
    removal; its sole breach was 5,613 against 5,609. Fund that final measured
    excess only: 5,600 -> 5,613, no padding. This is retained measurement reuse,
    not a new selector or suite change. Job counts, other weights and ten packs
    remain fixed; current-head hosted CI must execute the updated assertion.
    Dropping the imported validator or understating the suite weight would
    discard coverage or hide the actual added test load.

    The subsequent protected0ad974a9 integration measures 134 jobs / 5,618
    for build_free_content; the Python3.12 affected check records that exact
    five-unit excess over 5,613. Retained weight attribution records the
    inherited job deltas (including dataos-identity-seams 16 -> 21). Fund
    only the measured 5,618. Job counts, the other two weight ceilings,
    all suites and the ten-pack ceiling remain unchanged.

    Guarded dedicated-reader backend composition (2026-10-19) adds six
    backend suites to research-vault's existing canonical command: exactly
    twelve estimator units. Fund only the affected build_free_content probe's
    5,618 -> 5,630 increase. Job counts, other probe ceilings, selectors and
    the ten-pack bound remain unchanged; ordinary Brain F11 suites remain held.

    Retained SEC13D research composition (2026-10-19, PR9789) adds three
    explicit SEC suites to dataos-identity-seams: estimator weight21 ->27.
    Hosted contract-delta39318414980/job118285830478 measured the same134
    selected jobs and ten packs, base5628 -> head5634, with no new entrant.
    Fresh canonical-main composition235b8704/6cb3ba9 independently measures
    exactly134 jobs /5634 weight /10 packs. Fund only the four-unit excess
    over5630, to5634. Every suite, selector, job/pack bound and both other
    probe weight ceilings remain unchanged; no coverage is dropped.

    Seasonality style-card suite (2026-10-19, PR9793) adds
    tests/test_seasonality_now_call_strip.py to unrun-builders-render.
    The local probe on main 8df5aee4 measures build_free_content 134 jobs
    / 5,634; on the PR merged into that main, the same 134 job ids / 5,638
    (index.html and plan_book also +4, both under their ceilings). No new
    entrant. Fund only the four-unit excess: 5,634 -> 5,638. Every suite,
    selector, job/pack bound and both other probe ceilings stay unchanged.

    Methodology disclosures + seasonality page claims (2026-10-19, W23-L3/L6)
    add tests/test_methodology_disclosures.py and
    tests/test_seasonality_page_claims.py to unrun-builders-render. The local
    probe on main 55130f60 measures build_free_content 134 jobs / 5,638; on
    the PR merged into that main, the same 134 job ids / 5,642 (index.html
    5,767 and plan_book 5,516, both under their ceilings). No new entrant.
    Fund only the four-unit excess: 5,638 -> 5,642. Every suite, selector,
    job/pack bound and both other probe ceilings stay unchanged.

    Shared Shell composition (2026-10-20, PR7949) retains the new bridge
    coverage in data-base-shim (weight 7 -> 12: one command and two suites)
    and unrun-nav-chrome (30 -> 32: one suite). Hosted contract-delta
    run39352502392/job118399691090 measures the same 134 jobs / 10 packs,
    base5,642 -> merge5,649. The Python3.12 two-check reproduction on b98c5d1
    merged with d52827f independently reports 134/329 jobs and the same
    5,649 total. Preserve the incoming W23 four-unit change above and fund
    only this separate seven-unit increase: 5,642 -> 5,649. These are planner
    estimator units, not a measured seven-second runtime. All commands,
    suites, selectors, job/pack bounds and other weight ceilings stay fixed.

    SPR page JODI vintage + zh assess badges (2026-10-19, W23-L9) give
    tests/test_strategic_reserves.py (off the unrun baseline),
    tests/test_spr_jodi_vintage.py and tests/test_spr_assess_badge_zh.py
    their own step in unrun-macro-panels. contract-delta on the PR merged
    into main d52827f2 measures build_free_content 134 jobs / 5,649 (base
    the same 134 / 5,642; index.html 5,774 and plan_book 5,523, both under
    their ceilings). No new entrant. Fund only the seven-unit excess:
    5,642 -> 5,649. Every suite, selector, job/pack bound and both other
    probe ceilings stay unchanged.

    Spvector gate chips (W23-L11, PR #9819) and the country-cycles panels
    (W23-L10/L12, PR #9818), 2026-10-20, give
    tests/test_spvector_gate_chips.py its own step in unrun-vector-baskets
    (job weight 31 -> 34) and the four tests/test_country_cycles_*.py
    suites their own step in unrun-macro-panels (69 -> 78). contract-delta
    on each PR against base 5,642 measures build_free_content 134 jobs /
    5,645 (#9819, run 39363164849) and 5,651 (#9818, run 39362507998). No
    new entrant. The two jobs are disjoint and a job's weight is a pure
    function of its own run text, so on main 6629c268 (5,649) the excess
    adds: 5,652 with #9819, 5,658 with #9818 and 5,661 with both
    (index.html 5,786 and plan_book 5,535, both under their ceilings).
    Both PRs carry this identical note and ceiling, so the second to merge
    stays clean. Fund only the twelve-unit joint excess: 5,649 -> 5,661.
    Every suite, selector, job/pack bound and both other probe ceilings
    stay unchanged.

    Shared Shell/current-main composition (2026-10-20, PR7949):
    the four existing scope/packing checks on 0f058428 plus this branch
    measure index.html 135 jobs / 5,793, build_free_content 134 / 5,668,
    and plan_book 128 / 5,542, with ten packs and the same selected job
    IDs as the prior f54 composition. That prior composition measured
    5,665 while the vector suite was still pending. Incoming 0f058428
    now includes its exact unrun-vector-baskets 31 -> 34 (+3) change.
    On these same selected IDs, incoming-manifest command weight is
    5,661; the retained Shared Shell data-base-shim +5 and nav-chrome +2
    produce 5,668. Fund only that measured seven-unit excess, 5,661 ->
    5,668. Preserve both incoming histories above, all suites, selectors,
    job and pack bounds, and the other two weight ceilings.

    The S&P Vector scorecard basis (W23-L13, stacked on PR #9819),
    2026-10-20, gives tests/test_spvector_scorecard_basis.py its own step
    in unrun-vector-baskets right after W23-L11's (job weight 34 -> 37,
    measured on the merged run text). Same job, same pure run-text
    weight, no new entrant: build_free_content rises by exactly 3 on any
    base that already holds #9819, so fund 5,661 -> 5,664. index.html and
    plan_book stay under their ceilings even if they select this job
    (5,789 and 5,538 at most). Every other bound stays unchanged.

    Shared Shell/current-main92c51 composition (2026-10-20, PR7949):
    the four existing scope/packing checks measure index.html 135 jobs /
    5,796, build_free_content 134 / 5,671, and plan_book 128 / 5,545,
    all in ten packs. Selected IDs/order match the prior 0f05 composition;
    each weight rises exactly three with the incoming scorecard step.
    Incoming command weights on those same IDs are 5,789 / 5,664 / 5,538.
    The retained Shell data-base-shim +5 and nav-chrome +2 explain the
    entire seven-unit excess. Fund only 5,664 -> 5,671; keep all previous
    histories, suites, selectors, job/pack bounds and other ceilings.

    SPR JODI trend and gold vintage (W24-L19, PR #9839), 2026-10-20, add
    tests/test_spr_jodi_trend.py and tests/test_spr_gold_vintage.py to the
    W23-L9 SPR step in unrun-macro-panels (job weight 78 -> 82, measured
    on the merged run text). contract-delta on the PR (run 39379143776)
    measures build_free_content 134 jobs / 5,668 against base 5,664. No
    new entrant. index.html (5,793) and plan_book (5,542) stay under
    their ceilings. Fund only the four-unit excess: 5,664 -> 5,668.
    Every other bound stays unchanged.

    Baselines on the pre-curation manifest (PR #5585 planner, 188 jobs):
    templates/index.html 129 jobs / 6,677 weight-seconds; build_free_content.py
    129 / 6,430; engine/prophet/plan_book.py 123 / 6,416. Bounds below carry
    headroom so an unrelated job gaining or losing a scope does not red this,
    while a regression that gives the fallback tier back to the curated nine
    (~1,550 weight-seconds and three of twelve packs per shape) does.

    The templates/index.html job ceiling is 128 rather than 126 because
    `engine-render-guards` split into three lanes (#5587 on top of #5586): the
    sweep still owned-matches this probe, and the two sibling lanes
    (`express-render-guards`, `attested-history-guards`) still fallback-match
    it. That is +2 jobs / +210 weight-seconds vs the single pre-split job, not
    a return of the curated eight. Weight and pack ceilings are unchanged.

    JOB COUNTS RE-BASED +1 (129/127/121) for #5620, which added ONE new job,
    `intelligence-registry` (Eval OS T1). Measured against the pre-#5620
    manifest, it is the sole newcomer on all three probes and the ONLY delta:

        templates/index.html          128 -> 129 jobs, 5,253 -> 5,266 weight
        scripts/build_free_content.py 126 -> 127 jobs, 5,016 -> 5,029 weight
        engine/prophet/plan_book.py   120 -> 121 jobs, 5,002 -> 5,015 weight

    +13 weight-seconds per probe. The WEIGHT and PACK ceilings are deliberately
    NOT moved: they are what bound the incident this wave exists to prevent, and
    a regression that gave the fallback tier back to the curated eight would be
    ~1,550 weight-seconds and three of twelve packs — two orders of magnitude
    above this, so it still reds here. What moved is only the job count, and only
    because the previous bounds carried zero headroom on that axis: 128/126/120
    were the exact pre-#5620 measurements, so the very first honest new job
    breached all three. The docstring above promises headroom "so an unrelated
    job gaining or losing a scope does not red this"; `intelligence-registry` is
    exactly such a job, and that promise was not funded. Re-based to the new
    measurement rather than padded, so the next new job is again a visible event.

    This re-base is the same change carried by PR #5669 (authored there first).
    It is duplicated here because both fixes land in the SAME `workflow-yaml`
    job: run_ci_pack abandons a job's remaining steps on the first non-zero
    exit, so this assertion (step 5) masks `audit_unrun_tests.py` (step 12).
    A PR that healed only one of the two would leave `ci-pack-1` red and neither
    PR could ever merge — the two-partial-heals deadlock. Whichever lands second
    resolves to an identical tree.

    JOB COUNTS LOWERED to 127/124/119 (wave 3, 2026-08-14). The re-base above
    absorbed TWO newcomers on the two code probes, and only one of them was
    evidence. `intelligence-registry` matched on the DECLARED tier and stands.
    `options-estate-guards` matched on the FALLBACK tier: #5634 gave it
    tests/test_options_gap_discipline.py, an opaque construct in that suite's
    closure widened it to whole-tree scan roots, and it began selecting on
    files it does not read. That is smear, so it is curated away at the source
    (`scope: exclusive` in the manifest) rather than paid for here.

    Re-measured on the curated manifest, `options-estate-guards` is the sole
    delta and the ONLY job that leaves any probe:

        templates/index.html          127 -> 126 jobs, 5,259 -> 5,235 weight
        scripts/build_free_content.py 124 -> 123 jobs, 5,009 -> 4,985 weight
        engine/prophet/plan_book.py   119 -> 118 jobs, 5,001 -> 4,977 weight

    The ceilings are set at measurement + 1, not at measurement. The #5620
    re-base note above diagnosed zero headroom as the defect — "the very first
    honest new job breached all three" — and then re-based exact, funding the
    docstring's headroom promise with nothing again. One job of slack absorbs
    the next honest newcomer and still makes the second a visible event. Note
    the pre-curation measurements had already drifted BELOW the 129/127/121
    ceilings as later curation waves landed, so those bounds carried accidental
    slack of 2-3 jobs; this restores a ratchet that is tight on purpose.

    WEIGHT and PACK ceilings are again deliberately NOT moved, for the reason
    given above: they bound the incident, and a fallback-tier regression is
    ~1,550 weight-seconds — two orders of magnitude above the 24 removed here.

    JOB COUNT RE-BASED +2 on templates/index.html only (129, 2026-08-15).
    ``engine/china_intel_interest.py`` lazy-imports ``china_intel_hub``, and
    that hub's opaque constructs smear ``templates/**`` onto two inferred
    jobs that already imported ``build_china_library`` /
    ``china_standout_track`` (``cn-standout-audit``,
    ``coiled-mtf-anchor-era``). Measured 126 → 128 on this probe; the other
    two probes are unchanged. Weight and pack ceilings stay. Exclusive
    curation of those two jobs is the smear-at-source fix, but their
    closures run through ``build_china_library`` and would be a third
    exclusive-scope wave, not this packing-contract heal.

    THAT DEFERRAL IS NOW PAID (wave 4, 2026-08-15). Both jobs are curated
    ``scope: exclusive`` in the manifest, and the ceiling above comes back
    DOWN from 129 to 127. Neither job had an owned tier at all before this —
    every one of their 28 inferred patterns was opaque fallback, so they
    selected on ``*`` and on whole trees no suite in them reads. Re-measured
    on the curated manifest, they are the ONLY delta and NOTHING was added to
    any probe:

        templates/index.html          128 -> 126 jobs, 5,310 -> 5,292 weight
        scripts/build_free_content.py 123 -> 122 jobs, 5,044 -> 5,038 weight
        engine/prophet/plan_book.py   118 -> 118 jobs, 5,040 -> 5,040 weight

    Both jobs leave templates/index.html; only ``coiled-mtf-anchor-era``
    leaves build_free_content.py, because ``cn-standout-audit`` KEEPS
    ``scripts/**`` on the declared tier — two of its suites rglob that tree
    and AST-scan every hit for unlaned CN sink calls, so the tree is their
    subject and narrowing it would be the silent-stop failure this file's
    coverage test exists to prevent. Both keep ``engine/**`` for the same
    kind of reason, which is why plan_book.py does not move at all. That is
    the shape a correct curation has: it removes the fallback claims and
    keeps every earned one.

    The ceiling is set at measurement + 1 per the wave-3 note above, so 126
    measured -> 127. Note this lands exactly where wave 3 had it before
    #5754, which is the confirmation that these two jobs were the whole of
    that +2 and that no other drift hid inside the re-base. WEIGHT and PACK
    ceilings are again NOT moved: the 18 weight-seconds removed here are two
    orders of magnitude below the ~1,550 a fallback-tier regression costs,
    and packs were 9 on every probe before and after.

    JOB COUNT RE-BASED +1 on engine/prophet/plan_book.py only (120, wave 6,
    2026-08-20 main-red-repair). Measured against the last lane-green main
    commit (d972484c6474): baseline selects 119/195 jobs for this probe;
    the current manifest selects 120/196, and diffing the two selected-job
    NAME sets (not just counts) isolates the entire delta to one job,
    ``reference-integrity`` — present in both manifests, but newly matching
    this probe. #6122 (XPV2-SC-R3A, commit f4305a4485f6) added a third step
    to that already-existing job (`tests/test_xpv2_sector_r3_fixture.py`,
    over the frozen Sector Central fixture), and that suite's import closure
    carries several ``dynamic import`` / ``subprocess invocation``
    ambiguities several hops deep (engine/alert_triage.py,
    engine/codex_lane/runner.py) that resolve to CODE_SCAN_ROOTS/
    SUBPROCESS_ROOTS, which include ``engine/**`` — hence the new match on
    engine/prophet/plan_book.py specifically, not anything Sector Central or
    Prophet actually share.

    This is NOT curated away like serving-observability's smear (2026-08-20
    main-red-repair, same wave) or curated like dataos-identity-seams was
    REJECTED (wave 2 note above): reference-integrity's own header comment
    documents it as deliberately unscoped — "Unscoped on purpose: L7/L8/L9
    are namespace and coupling closures over mockups/design_system,
    research/migration_packets and the page registry, so a diff that adds a
    file anywhere in those roots must re-run this" — a whole-tree RIG V1
    reference-integrity gate that already existed pre-#6122 and is meant to
    fire broadly. Declaring `scope: exclusive` on a job whose real purpose is
    "catch reference laundering anywhere in these wide namespaces" would
    either lie about coverage or degenerate straight back to the fallback
    breadth it already carries — the identical failure mode
    dataos-identity-seams was rejected for. One extra match on an
    already-broad, already-reviewed, always-on gate costs nothing over the
    ~1,550 weight-seconds/3-pack fallback-regression bound this file guards;
    ratcheting the ceiling is the correct-risk response, not curation.
    WEIGHT and PACK ceilings stay unmoved (5,600 / 9 packs, unchanged).

    JOB COUNTS RE-BASED to 129/125/121 (wave 7, 2026-08-21) — a ratchet on the
    templates probe, and the wave-3 headroom promise re-funded on all three.
    Measured against the last commit at which this job's own lane was green
    (48bfd3c97e8a, data-health run 32380507121), diffing the selected-job NAME
    sets isolates one sole entrant per probe and nothing leaves:

        templates/index.html          127 -> 128 jobs, 5,390 -> 5,420 weight
        scripts/build_free_content.py 123 -> 124 jobs, 5,141 -> 5,173 weight
        engine/prophet/plan_book.py   119 -> 120 jobs, 5,143 -> 5,175 weight

    Only templates/index.html BREACHED (128 > 127). Its sole entrant is
    ``regwall-boundary``, the new ``gate: code`` job #6141 added so that
    tests/test_regwall_json_gate.py — whose only CI home had been the
    ``gate: data`` job ``tier-gate``, i.e. off the merge gate entirely — can
    actually block a merge. It matches on the DECLARED tier, not fallback:
    #6141 gave it an explicit ``scope: exclusive`` + ``paths:`` precisely
    because that suite names its subjects as segment literals
    (``REPO_ROOT / "templates" / "index.html"``, tests/test_regwall_json_gate.py:102),
    which SCOPE_REFERENCE_RE cannot see. So this is the ``intelligence-registry``
    case verbatim (wave 3 note above), not the ``options-estate-guards`` smear:
    there is no fallback claim to curate away, because the job arrived already
    curated to the narrowest honest scope it has. Narrowing it further would
    drop ``templates/index.html`` from the declaration of the one job whose
    entire purpose is to assert the regwall boundary inside that file — a
    silent false green, and ``curated_exclusive_closure_findings`` would hard-
    fail the manifest for it anyway. Ratcheting is the correct-risk response.

    The other two probes did NOT breach — but both sat at EXACTLY their
    ceiling (124/124 and 120/120), which is the zero-headroom defect the #5620
    note above already diagnosed once ("the very first honest new job breached
    all three") and which wave 6 re-introduced by re-basing plan_book exact.
    That is how this red reached main unseen: ``workflow-yaml`` is itself
    ``gate: data``, so under W2 of
    research/CI_MERGE_GATE_RELIABILITY_ROOT_CAUSE_2026_08_19.md this assertion
    is packed only by data-health.yml, which has no ``pull_request`` trigger —
    no PR can be blocked by it, so a zero-headroom ceiling does not red the
    newcomer's PR, it reds MAIN, silently, one commit later. All three are
    therefore set at measurement + 1 per the wave-3 rule, restoring the one
    job of slack that makes the NEXT newcomer a visible event rather than a
    fait accompli. WEIGHT and PACK ceilings stay unmoved (5,800 / 5,600 /
    5,600 and 10 packs): weights are 5,420 / 5,173 / 5,175, and a fallback-
    tier regression is still ~1,550 weight-seconds above them, so the bound
    this file exists to hold is untouched.

    JOB COUNTS RE-BASED to 131/127/122 (wave 8, 2026-08-28, TP-1 repair edge
    theme-parity-tp1-canada-20260828-sol-001). Measured on main a8075391fa89,
    diffing selected-job NAME sets per probe against the wave-7 green
    baseline manifest (48bfd3c97e8a):

        templates/index.html          130 jobs / 5,560 weight (was ceiling 129)
          entrants: regwall-boundary (declared — wave 7's own funded entrant),
                    design-governance (fallback, w16),
                    board-shadow-substrate (fallback, w7)
        scripts/build_free_content.py 126 jobs / 5,313 weight (was ceiling 125)
          entrants: design-governance, board-shadow-substrate,
                    reference-integrity (all fallback)
        engine/prophet/plan_book.py   121 jobs / 5,299 weight (AT ceiling —
          the zero-headroom defect again)
          entrants: board-shadow-substrate, reference-integrity

    Every unfunded entrant is a DELIBERATELY-UNSCOPED always-on gate, i.e.
    the ``reference-integrity`` class wave 6 already adjudicated ("ratcheting
    the ceiling is the correct-risk response, not curation"):
    ``design-governance`` is TP-0's forward-only design ratchet (#6579) —
    a diff gate over user-facing templates/site whose entire purpose is to
    run on exactly the PRs these probes model, so its match on
    templates/index.html is its subject, not smear; ``board-shadow-substrate``
    documents itself "Left UNSCOPED … always-on is correct for this job, not
    lazy" (its K6 kill is a repo-wide string walk inference cannot narrow);
    ``reference-integrity``'s breadth was adjudicated in wave 6 and its
    growth onto build_free_content.py is the same mockups/research/registry
    namespace closure firing as designed. Curating any of the three
    ``scope: exclusive`` would lie about coverage or degenerate back to
    fallback breadth — the dataos-identity-seams rejection, verbatim. The
    non-smear finding is affirmative: TP-1's own manifest edit (adding
    tests/test_stock_dashboard_css.py to the render-guard step, merge
    e2091032ad1f) adds ZERO probe matches — the selected-name-set delta
    across that merge is empty on all three probes, so the earned Canada CSS
    coverage rides a job that already owned-matched its subjects and costs
    these ceilings nothing.

    Ceilings are set at measurement + 1 per the wave-3 rule (131/127/122),
    re-funding the headroom promise on all three axes — plan_book.py sat AT
    its ceiling again, the exact silent-main-red mechanism the wave-7 note
    describes. WEIGHT and PACK ceilings stay unmoved (5,800 / 5,600 / 5,600
    and 10 packs): measured weights are 5,560 / 5,313 / 5,299 and a
    fallback-tier regression is still ~1,550 weight-seconds above them.
    The companion test below pins all three always-on gates so the OPPOSITE
    regression — a future curation silently narrowing a deliberate whole-tree
    gate off its subject — reds loudly instead of shipping a false green.

    JOB COUNTS RE-BASED to 132/129/125 (wave 9, 2026-09-13,
    B-HEAL-CI-PACK-CEILING-1). Measured on main 021b2ae3a4a6, diffing
    selected-job NAME sets per probe against the wave-8 baseline manifest
    (a8075391fa89); that baseline manifest re-measured on today's tree gives
    130/126/121 at 5,560/5,313/5,299 — the wave-8 figures above to the job
    and the weight-second — so the whole delta is manifest-side:

        templates/index.html          131 jobs / 5,703 weight (AT ceiling 131 —
          the zero-headroom defect again)
          entrants: market-os-macro-workspaces (fallback, w39)
        scripts/build_free_content.py 128 jobs / 5,460 weight (was ceiling 127)
          entrants: market-os-macro-workspaces (fallback, w39),
                    public-render-fastlane (fallback, w17)
        engine/prophet/plan_book.py   124 jobs / 5,454 weight (was ceiling 122)
          entrants: ccw-w3-credit-momentum (fallback, w10),
                    market-os-macro-workspaces (fallback, w39),
                    public-render-fastlane (fallback, w17)

    Nothing leaves any probe. Unlike wave 8, NONE of the three entrants is a
    deliberately-unscoped always-on gate: no block text claims whole-tree
    breadth on purpose, and every match is an inferred opaque-fallback claim
    that its own block does not justify. Each is therefore a CURATION
    CANDIDATE with a named follow-on; all three are ratcheted here so main
    goes green today, and the ceiling keeps flagging them until curated:

    ``ccw-w3-credit-momentum`` (legacy-jobs.yml ~6299; no ``paths:``, no
    ``scope:``; its header is a coverage inventory — "CCW-W3 credit momentum
    organ: engine/credit_momentum.py …" — with no self-justification for
    breadth). Present at wave 8 with ZERO probe-relevant ambiguities; #6904
    (merge 49451c5148c4) appended tests/test_credit_window.py to its step,
    and that suite carries five opaque constructs (:173/:175 tmp_path
    rglobs, :187 a ``root / "engine"`` ``.glob("*.py")`` AST scan in
    ``test_not_imported_by_any_scoring_module``, :196, :452 a
    ``git ls-files data/…`` subprocess) that resolve to ``engine/**`` and
    ``engine/**/*.py``. The one honest claim is on top-level ``engine/*.py``
    whose names contain score/regime/axis, which inference widens to the
    whole engine tree — the ``options-estate-guards`` shape, not the
    ``reference-integrity`` one. Follow-on: B-CUR-CCW-W3-1.

    ``public-render-fastlane`` (legacy-jobs.yml ~9033; no ``paths:``, no
    ``scope:``; block text describes "Public fast-path contract … Renders to
    a tmp dir; network-free", no always-on justification). Present at wave 8
    matching only templates/index.html (already funded). #6828 (F13-X1,
    8431aeafcc39) appended tests/test_help_directory.py + its contract suite
    to its step, B-F13-3 (dcd0eee135cc) added the ``--deselect``, and #6909
    (F13-1) appended three glossary suites. test_help_directory.py's closure is 543
    files because of ``import scripts.build_site as bs`` at :67 — inside the
    body of ``test_build_site_renders_help_page_with_the_full_view_model``,
    the ONE test the job's own command ``--deselect``s (inference does not
    read ``--deselect``); that closure reaches engine/alert_triage.py:639
    (dynamic import), engine/codex_lane/runner.py:531/:748 (subprocess
    invocation) and collectors/sec_document_spine.py:776 (filesystem glob),
    i.e. ``engine/**`` + ``scripts/**``. The contract sibling's closure is 9
    files. Smear from a test the job never runs. Follow-on:
    B-CUR-PUBLIC-RENDER-FASTLANE-1.

    ``market-os-macro-workspaces`` (legacy-jobs.yml ~14122; born after wave 8,
    Market Ontology F01 R1A). Declares 21 ``paths:`` (its contract schema,
    ``engine/market_os/**``, scripts/build_macro_workspaces.py and its 18
    suites) but NOT ``scope: exclusive``, so the declaration is unioned
    under inference and none of the declared paths covers any probe; every
    probe match is fallback: scripts/build_macro_workspaces.py:52
    (subprocess invocation → ``engine/**``, ``scripts/**``,
    ``templates/**``), tests/test_macro_workspace_build.py:69 (filesystem
    roots=scripts) and tests/test_macro_workspace_prior_publication.py:301/
    :470 (dynamic import → ``engine/**``, ``scripts/**``). Its block text is
    a NARROW self-description — "All four suites are offline and
    synthetic-fixture driven; the only real input ever read at build time
    is data/regime/latest.json" — and its sibling
    ``market-os-macro-suite-pages`` was curated ``scope: exclusive`` at
    birth. Follow-on: B-CUR-MARKET-OS-MACRO-WORKSPACES-1.

    Ceilings are set at measurement + 1 per the wave-3 rule (132/129/125),
    re-funding the headroom promise on all three axes — templates/index.html
    sat AT its ceiling again. WEIGHT and PACK ceilings stay unmoved (5,800 /
    5,600 / 5,600 and 10 packs): measured weights are 5,703 / 5,460 / 5,454;
    packs are 10 / 10 / 10 (the two code probes were 9 at wave 8), and with
    PACK_TARGET_SECONDS = 600 an 11th pack needs > 6,000 weight-seconds,
    above every weight ceiling, so the weight axis still reds first. This
    nodeid lives only in a ``gate: data`` job (``workflow-yaml``), so PR
    packs (``--gate code``) never run it; it runs only on push to main via
    integration-baseline.yml (direct pytest, :197) and in data-health.yml's
    ``--gate data`` packs — so the two breaches reached main unseen: the runner
    reproduces 131/128/124 exactly (integration-baseline run 34716383790 at
    c78d5a4f), the last fully green integration-baseline run on main is
    34290518926 at 4603d7bb392d (2026-09-08 23:24Z) — none of the 54
    non-cancelled runs since it was green as of this measurement — and the
    seat's finding places this step's own last green at 4b2f97f196d5
    (2026-09-09 00:20Z, 690 passed).

    WAVE 2026-09-23 (B-HEAL-CI-PACK-CEILING-2): the WEIGHT ceiling reds.
    Main's integration-baseline lane failed this nodeid alone (run
    35923703447 at 6ffa33740a49, "1 failed, 712 passed") at
    templates/index.html 132 jobs / 5,810 weight — the job ceiling met
    exactly, the weight ceiling breached by 10 — and the two code probes
    were over their JOB ceilings behind it (the loop asserts the first probe
    first): build_free_content.py 130 > 129, plan_book.py 127 > 125. The
    manifest had grown 212 → 227 jobs since the previous wave's baseline
    (021b2ae3a4a6). Diffing that baseline manifest RE-MEASURED on today's
    tree (133 / 5,713 on templates/index.html — inference drift accounts for
    +2 jobs / +10 weight of the delta) against the current manifest, the
    weight breach is NOT one entrant: it is +105 weight-seconds spread over
    ~20 already-selected fallback-tier jobs whose step lists grew
    (washout-turn-organ 31 → 52, unrun-page-guards 34 → 50, unrun-brain-gateway
    40 → 47, self-mod-fence 46 → 53, billing-emails 16 → 22, design-governance
    18 → 23, …), plus two 4-weight entrants on templates/index.html
    (uk-policy-desk #7771, options-payoff-lab-consumer #7763), one 8-weight
    entrant on both code probes (options-catalyst-links #7774), and
    design-governance newly riding engine/prophet/plan_book.py (23). Three
    small jobs left (am-edition-producer, ftr-tape-surfaces,
    unrun-government-revenue-candidate-projection).

    Every entrant matched on the FALLBACK tier and no block text claims
    whole-tree breadth on purpose, so — per the standing convention — the
    ceiling is not raised; the smear is curated at the source. FOUR jobs are
    curated ``scope: exclusive`` in the manifest, every declared path earned
    by the inferred import closure or by a read-as-text the suite performs
    (closure-coverage audit: zero misses; contract-delta: 0 introduced):

    ``market-os-macro-workspaces`` — the follow-on named at the previous
    wave (B-CUR-MARKET-OS-MACRO-WORKSPACES-1), now paid: 21 ``paths:``
    declared at birth WITHOUT ``scope: exclusive`` were unioned under
    inference, and scripts/build_macro_workspaces.py:52 (subprocess) plus
    test_macro_workspace_prior_publication.py:341 (jinja FileSystemLoader)
    minted engine/scripts/templates/site/data claims on all three probes.
    Declared: the 48-file closure (composers, lib/macro_suite_*,
    scripts/build_macro_suite_pages.py), the shell template it renders by
    name, and its committed fixture. Weight 39, leaves all three probes.

    ``uk-policy-desk`` (#7771) — "the suite imports nothing further" was
    true of the file and false of the closure (engine/uk_policy_brain.py
    reaches 133 first-party files). Its ``test_no_scoring_path_imports_this_desk``
    rglobs engine/ and scripts/ for ``*.py``, so ``engine/**/*.py`` and
    ``scripts/**/*.py`` are EARNED and declared — this job KEEPS both code
    probes on purpose (the cn-standout-audit shape) — and it sheds only the
    ``templates/**`` claim its jinja loader minted. Weight 4, leaves
    templates/index.html only.

    ``options-payoff-lab-consumer`` (#7763) — hermetic per its block; the
    ``templates/**`` claim came from scripts/build_options_command.py's
    jinja loader. Declared: the 14-file closure, templates/options.html.j2
    (read as text), .github/workflows/engine-render.yml (read as text for
    its R2-restore pins). Weight 4, leaves templates/index.html.

    ``options-catalyst-links`` (#7774) — hermetic per its block; the
    engine/**, scripts/**, data/** claims came from ledger-lane /
    session-digest opaque edges in the closure. Declared: the 19-file
    closure plus daily.yml and this manifest, which its nightly-shape suite
    reads as text. Weight 8, leaves both code probes.

    Re-measured on the curated manifest — the four curated jobs are the
    ONLY delta and NOTHING entered any probe:

        templates/index.html          132 -> 129 jobs, 5,810 -> 5,763 weight
        scripts/build_free_content.py 130 -> 128 jobs, 5,577 -> 5,530 weight
        engine/prophet/plan_book.py   127 -> 125 jobs, 5,583 -> 5,536 weight

    JOB ceilings re-based to measurement + 1 per the wave-3 rule
    (130 / 129 / 126): templates/index.html comes DOWN from 132, the
    build_free_content.py bound is unchanged, and plan_book.py goes UP by
    one — said explicitly: its measurement sits AT the old 125 bound
    because ``design-governance`` (w23) now fallback-matches it through
    scripts/check_p0b_receipt_closure.py:100's ``evidence.glob`` (the p0b
    receipt-closure step added 2026-09-23), a claim that is NOT earned
    (the design ratchets diff user-facing trees, never engine/) but that
    cannot be curated: ``test_deliberately_unscoped_gates_stay_always_on``
    pins that gate unscoped by design. Its fix is at the glob source, not in
    the manifest — follow-on: B-CUR-DESIGN-GOVERNANCE-P0B-1. Re-basing to
    125 would restore the zero-headroom defect this wave and the last both
    diagnosed. WEIGHT and PACK ceilings stay unmoved (5,800 / 5,600 / 5,600
    and 10 packs; measured 5,763 / 5,530 / 5,536, packs 10 / 10 / 10) —
    they bound the incident, and this wave's 47-weight cut on the index
    probe is the honest size of four small smears, not a re-base.

    2026-09-24 (#6872 postmortem — the p0b receipt-closure gate moves out of
    ``design-governance`` into its own curated job ``p0b-receipt-closure``,
    w7, ``scope: exclusive`` over templates/**, site/**, engine/i18n.py, the
    recipe, the verifier and mockups/evidence/prophet-p0b-zero-fouc/**).
    B-CUR-DESIGN-GOVERNANCE-P0B-1 above is thereby resolved at the source:
    with the gate gone from ``design-governance`` its closure no longer
    carries check_p0b_receipt_closure.py:100's ``evidence.glob`` root claim,
    so the unearned engine/** fallback disappears and design-governance
    stops riding the plan_book probe (w23 -> w18). Re-measured, full
    manifest, inference on:

        templates/index.html          131 -> 132 jobs, 5,790 -> 5,792 weight
                    (+1: p0b-receipt-closure rides templates/** by design)
        scripts/build_free_content.py 129 -> 129 jobs, 5,543 -> 5,538 weight
        engine/prophet/plan_book.py   126 -> 125 jobs, 5,549 -> 5,526 weight

    JOB ceilings re-based to measurement + 1 (133 / 130 / 126): the index
    probe's +1 is a gate entering on the PRs that are its subject, which the
    wave-7 note names as the correct-risk response ("ratcheting the ceiling
    is the correct-risk response, not curation"). Said explicitly: the
    PRE-change tree already measured 131 / 129 / 126 — over, at, and at the
    old bounds — and that is not this PR's doing. #6872 (merged 2026-09-24
    17:54Z) added ``ontology-explorer`` (w11) with an INFERRED scope: 614
    owned paths plus a whole-tree fallback smear (admin/**, app/**,
    collectors/**, config/**, ...), so it rides all three probes. Measured
    on main's manifest with that one job removed: 130 / 128 / 125, i.e. the
    old bounds' exact headroom. Nobody saw it because this suite's host job
    ``workflow-yaml`` is ``gate: data`` — off the merge gate — and the
    data-health lane had not run a post-#6872 tree by 2026-09-25 00:55Z
    (its last run, 17:54:26Z, predates the merge). Identical under Python
    3.12 and 3.14, full checkout. Curating ontology-explorer's smear is a
    follow-on (B-CUR-ONTOLOGY-EXPLORER-1); re-basing here keeps the ratchet
    honest instead of leaving it red-on-arrival. WEIGHT and PACK ceilings
    stay unmoved (5,800 / 5,600 / 5,600 and 10 packs; measured 5,792 /
    5,538 / 5,526, packs 10 / 10 / 10).

    2026-09-25 (BC-2 merge gate: #7998, then the page-builder root).
    ``validated-claims-source`` (w2, ``gate: code``, ``scope: exclusive``)
    grades the display copy of the PR-authored roots, so it rides the PRs
    that ARE its subject, on the DECLARED tier: templates/** and engine/**
    since #7998 (templates/index.html and plan_book.py, +1 job / +2 weight
    each — already on main, which had left both probes AT their bounds),
    and the top-level page builders scripts/build_*.py /
    scripts/render_*.py since this change (build_free_content.py, +1 / +2;
    nothing else under scripts/ selects it). That is the wave-7
    "ratcheting the ceiling is the correct-risk response, not curation"
    case. Main's other drift since #7971 is no manifest entrant:
    biocatalyst-contracts grew 50 -> 52 weight on all three probes, and
    #7971's own manifest re-measured on today's tree already selects
    130 jobs / 5,577 weight for build_free_content.py (+1 / +39 against its
    129 / 5,538) — an inferred scope widened as the tree moved (the
    selection code did not change), which left that probe AT its bound too.
    Re-measured, full manifest, inference on, before #8010:

        templates/index.html          133 jobs, 5,796 weight
        scripts/build_free_content.py 130 -> 131 jobs, 5,579 -> 5,581 weight
        engine/prophet/plan_book.py   126 jobs, 5,530 weight

    JOB ceilings re-based to measurement + 1 (134 / 132 / 127). WEIGHT and
    PACK ceilings stay unmoved (5,800 / 5,600 / 5,600 and 10 packs) — the
    builder root adds 2 weight-seconds to one probe and none to the other
    two.

    #8010 then landed ``finance-intelligence-site-wiring`` (w4, ``gate:
    code``, no declared scope). Its one suite reads scripts/build_site.py
    as text, and inference follows that file's import closure: 560 owned
    paths, none of them a probe, plus a whole-tree fallback smear
    (admin/**, app/**, collectors/**, config/**, ...). It rides all three
    probes on that FALLBACK tier only, +1 job / +4 weight each. On its own,
    that put main one job over all three ceilings as they stood (133 / 130
    / 126). Nothing in the merge gate runs this file, so the breach showed
    only in the data lane. Re-measured on main 7c22f6c5b79 with this change:

        templates/index.html          134 jobs, 5,800 weight
        scripts/build_free_content.py 132 jobs, 5,585 weight
        engine/prophet/plan_book.py   127 jobs, 5,534 weight

    The ceilings above are NOT raised for it. They are this change's
    measurement + 1, and the #8010 entrant fills that headroom exactly. All
    three probes now sit AT their job bound, and templates/index.html sits
    AT its 5,800 weight bound. Said explicitly: no headroom is left, so the
    next entrant on any of the three needs a decision recorded here, not a
    reflexive bump. The rule this file already follows: curate a
    fallback-tier smear away (a declared ``scope: exclusive`` for the job
    that caused it); ratchet a job that enters on its own declared subject
    (wave 7). By that rule finance-intelligence-site-wiring's own smear is
    a curation candidate, left to its owner. An exclusive declaration for it
    would have to cover that closure (#8010's manifest comment: 538
    uncovered paths), which is why it has none.

    2026-09-25: this test now runs on the PR code gate. Until today its host
    job, ``workflow-yaml``, was ``gate: data``, and ci.yml's ci-pack runs
    only ``gate: code`` jobs. That is how #8010's breach above merged green:
    the breach was a function of the PR tree, but nothing that ran on the
    PR measured it. The control plane's own contracts, this test included,
    moved to ``ci-control-plane-contracts`` (``gate: code``, ``scope:
    exclusive``, weight 1,400). Being exclusive, that job rides none of the
    three probes. ``workflow-yaml`` became ``gate: code`` with what was left
    (weight 438 -> 90), and ``engine-render-guards`` took the data-reading
    half of its suites (860 -> 875). Both still ride all three probes, and
    no job enters or leaves any of them. Re-measured, full manifest,
    inference on, main 9f5fa770022 before -> after:

        templates/index.html          134 jobs, 5,800 -> 5,467 weight
        scripts/build_free_content.py 132 jobs, 5,585 -> 5,252 weight
        engine/prophet/plan_book.py   127 jobs, 5,534 -> 5,201 weight

    No ceiling moves. The job bounds are still full, so the rule above for
    the next entrant stands. What changed is where a MANIFEST entrant reds.
    Adding or re-scoping a job edits .github/ci/legacy-jobs.yml, which is
    one of ci-control-plane-contracts' declared paths, so the #8010 shape
    now reds its own PR, where it can still be curated, instead of main. A
    probe can also drift with no manifest edit: an inferred scope widens as
    the tree moves (build_free_content.py's +1 above). That PR touches
    none of the job's paths, so it merges without running this test, and
    the drift surfaces after merge, on integration-baseline.yml. That lane
    runs this file on every source push to main and every 4 hours, and
    merge-on-green pauses ordinary merges while it is red.

    PR #8322 round 2 (2026-10-03): ``live-flow-recovery-guards`` (w1,
    ``gate: code``, 12 declared paths) joins the manifest with ordinary
    ``paths:`` inference — NOT ``scope: exclusive``, per the META-CEO
    ruling for this round ("Ordinary paths inference, not scope:exclusive
    until closure verified"). Its declared subject (engine/live_flow.py,
    engine/session_digest.py, lib/{__init__,config.py,nyse_calendar.py},
    scripts/live_flow_poller.py + build_flow_archive.py + build_flow_surface.py,
    tests/test_flow_archive.py + test_live_flow_recovery.py + test_live_flow_tiering.py,
    ops/LIVE_FLOW_RUNBOOK.md) touches NONE of the three probes directly,
    but ordinary inference widens its fallback tier to the directory globs
    the declared files live under (engine/**, scripts/**, templates/**).
    Re-measured, full manifest, inference on, before this entry:

        templates/index.html          134 -> 135 jobs, 5,800 weight (AT)
        scripts/build_free_content.py 132 -> 133 jobs, 5,585 weight
        engine/prophet/plan_book.py   127 -> 128 jobs, 5,534 weight

    JOB ceilings re-based to measurement + 1 (135 / 133 / 128) per the
    standing rule. The decision recorded here follows the wave-9 re-frame
    exactly: the job enters all three on its OWN inferred FALLBACK tier
    (templates/**, scripts/**, engine/**), so it is a curation candidate
    — its closure is small (one production source, one new test file,
    three path helpers; closure-coverage audit: zero misses) and ``scope:
    exclusive`` would cover it cleanly. The ruling pins that to round 3,
    not this round; this entry funds the headroom so the PR lands green,
    and the curation follow-on is named live-flow-recovery-guards-scope
    (must run before the next entrant). WEIGHT and PACK ceilings stay
    unmoved (5,800 / 5,600 / 5,600 and 10 packs): weights are 5,800 /
    5,585 / 5,534, packs are 10 / 10 / 10, and templates/index.html sits
    AT its 5,800 weight bound — the next weight delta is the same kind
    of decision this entry makes.

    2026-09-27: that drift now reds its own PR. The measurement and the
    verdict moved to scripts/run_ci_pack.py (packing_probe_measurements,
    packing_probe_breaches) and the ceilings to PACKING_PROBES above, so
    this test and ci.yml's contract-delta job share one copy. contract-delta
    runs on every PR, whatever it touches. It measures the probes on the
    PR's tested merge and on that merge's base, and reds when the PR takes
    a probe over its ceiling, or further over a ceiling the base already
    breaches. The case the #8033 review measured is now caught before
    merge: a suite edited to read templates/index.html puts a job on this
    probe (134 -> 135) without selecting ci-control-plane-contracts.
    Nothing was re-measured and no ceiling moved. integration-baseline.yml
    still runs this file on main.

    PR #8596 (2026-10-07): ``integrated-answer-v0`` (w4, ``gate: code``,
    Package I v0 composer, default-off) joins the manifest with ordinary
    ``paths:`` inference. Its one suite imports app.integrated_answer,
    app.forensics and tests.test_company_theme_exposure; the declared
    closure is 628 owned paths, none of them a probe, plus the whole-tree
    fallback smear (admin/**, app/**, collectors/**, config/**, ...). It
    rides all three probes on that FALLBACK tier only, +1 job / +4..7
    weight each. Re-measured, full manifest, inference on, on the PR's
    merge with main 96261883bee:

        templates/index.html          134 -> 135 jobs, 5,673 weight
        scripts/build_free_content.py 132 -> 133 jobs, 5,419 weight
        engine/prophet/plan_book.py   127 -> 128 jobs, 5,379 weight

    JOB ceilings re-based to measurement (135 / 133 / 128), the #8322
    shape: the entrant is a fallback-tier smear, so by the standing rule
    it is a curation candidate, and this entry funds the headroom so the
    default-off composer lands green. The curation follow-on is named
    integrated-answer-v0-scope (a ``scope: exclusive`` declaration must
    cover the 628-path closure, which is why it has none here). WEIGHT and
    PACK ceilings stay unmoved (5,800 / 5,600 / 5,600 and 10 packs):
    weights are 5,673 / 5,419 / 5,379, packs are 10 / 10 / 9. All three
    job bounds are full again, so the next entrant needs a decision
    recorded here, not a reflexive bump.

    PR #8656 (2026-10-08): the entire M0D v2 suite now runs in the existing
    CODE job ``research-price-panel``, including its static source/deployment
    contracts. Its bash harnesses run temporary helper copies and its v1-store
    scans use temporary roots. The selector conservatively attaches the
    module-wide engine/scripts path-literal roots to those subprocess and
    unpatterned rglob calls. The job therefore enters plan_book.py and
    build_free_content.py on engine/** and scripts/** FALLBACK claims, not
    because those two modules are directly read or exercised by M0D.

    Preserve the whole-file command and ordinary inference while funding this
    measured coverage cost, following the #8322/#8596 decisions above. Hosted
    contract-delta run 37857396564 / job 113584769049 measured head 1384a72307a
    on tested merge 742e4cbfce2 against base 7e6ce338a9f8:

        templates/index.html          135 -> 135 jobs, 5,725 -> 5,729 weight
        scripts/build_free_content.py 133 -> 134 jobs, 5,480 -> 5,524 weight
        engine/prophet/plan_book.py   128 -> 129 jobs, 5,440 -> 5,484 weight

    All three stay at 10 packs. research-price-panel is the sole newly
    selected job on the two changed probes. JOB ceilings move only to the
    exact measurements (135 / 134 / 129), with no padding. All WEIGHT and
    PACK ceilings remain 5,800 / 5,600 / 5,600 and 10; the template job ceiling
    also stays 135. No suite, DATA registration, assertion, or selector is
    removed or weakened to reduce selection.

    Scope-curation follow-on: research-price-panel-m0d-scope. Before any
    ``scope: exclusive`` declaration, audit the complete original-plus-M0D
    job closure and retain every source, fixture, deployment, and registration
    owner. A M0D-only path list cannot safely replace that whole-job closure.
    The fallback claims remain conservative until that audit; these two
    count changes do not assert direct ownership of the probe modules.

    2026-10-11 (#8805, EVAL-1 partition clock receipt): the fifth
    Information-to-Price receipt suite registered in unrun-factor-research
    took templates/index.html from 5,802 (already over the ceiling; main run
    38139442230 failed this test) to 5,805. The five ITP steps now live in the
    exclusive information-to-price-eval-receipts job with their measured
    closure, so the probe reads 5,793 (head) against 5,805 before
    the move. No ceiling moves; no suite, registration, assertion or selector
    is removed or weakened.

    2026-10-13 (SNI INT1, ``sni-public-exposure-scan``): the WEIGHT ceiling
    on templates/index.html is RATCHETED 5,800 -> 5,803. This is the
    decision the 2026-09-24 entry said the next entrant would need. The
    job is already ``scope: exclusive`` with no fallback tier. It enters
    this probe on its OWN declared subject: it reads templates/** as text
    to prove that no public template serves, renders or links SNI
    material, and its test_ci_job_declares_every_scanned_surface reds if
    that path is dropped. That is the wave-7 ratchet case, not a smear to
    curate. Its weight is the estimator floor for a one-suite job (two
    run steps + one tests/ path = 4). Hosted contract-delta run
    38379913058 / job 115237474626, base 70de9c667b80:

        templates/index.html          134 -> 135 jobs, 5,799 -> 5,803 weight
        scripts/build_free_content.py 134 -> 134 jobs, 5,602 -> 5,602 weight
        engine/prophet/plan_book.py   129 -> 129 jobs, 5,562 -> 5,562 weight

    sni-public-exposure-scan is the only newly selected job, and only on
    the template probe. The ceiling moves to the exact measurement, with
    no padding. Job ceilings (135 / 134 / 129), the other two weight
    ceilings (5,600 / 5,600) and the 10-pack ceiling are unchanged.
    Alternatives rejected:
    - dropping templates/** from the job would leave template edits
      unguarded;
    - folding the suite into an existing template-riding job still adds
      +2 (5,801);
    - an OBSERVED_COMMAND_SECONDS entry below the estimator would
      understate a job that installs packages.
    In the same run, build_free_content was already at 5,602 against its
    5,600 ceiling on the base. That was reported as inherited, not
    introduced, and is left for a separate heal.

    2026-10-14 (Market Memory UI integration with Leadership Rotation):
    hosted run 38530236436 on merge 2d524d3e1 of b3f9739 into
    703477f0 reproduced two JOB-only breaches. Full inference on current
    main union 44cc567d1edf (base 05bcc762fb16; all 313 jobs retained)
    measures 136 / 134 / 130 jobs and 5,678 / 5,475 / 5,441 weight,
    with ten packs for every probe. The two genuine main entrants are
    lr-rotation-evidence-modes on templates/index.html (its imported
    sector-cycle suites conservatively own templates/**), and
    leadership-rotation-contract on plan_book.py (engine/** fallback).
    Each weighs four; neither selects build_free_content.py.

    Fund only those measured counts: 135 -> 136 and 129 -> 130.
    Keep every suite and conservative dependency claim, the build-script
    count ceiling 134, all weight ceilings, and the ten-pack limit.
    Narrowing either job without a complete closure audit would discard
    coverage, while padding counts beyond the exact measured entrants
    would hide the next change. No selector or runtime source is edited.

    2026-10-18 (PR #8014, joined AI x Terminal and native rich answers):
    the existing unrun-brain-gateway job retains its selector and every prior
    suite while adding the registered chart-context/receipt/presentation and
    native-visual/browser regressions. Its deterministic weight rises 61 -> 90;
    it is the only job whose weight changes. The selected job sets are unchanged.
    Hosted contract-delta run 39122785381 / job 117661607889 measured head
    c4a938afc201df797146bb685cc0c7f1977312fd against base
    f3fefce7e893755dcec18cbfe06f421c2c4d2db8:

        templates/index.html          136 -> 136 jobs, 5,779 -> 5,808 weight
        scripts/build_free_content.py 134 -> 134 jobs, 5,566 -> 5,595 weight
        engine/prophet/plan_book.py   129 -> 129 jobs, 5,528 -> 5,557 weight

    All three remain at ten packs, with no newly selected job. Fund only the
    five weight-seconds beyond the previous 5,803 index-template ceiling, to
    the exact observed 5,808. Preserve both other weight limits, every job-count
    limit, all test coverage, selectors and the ten-pack limit. These are planning
    weights, not measured execution timings. Narrowing the shared Brain job
    without its complete dependency audit would discard conservative coverage;
    no assertion or semantic release rule is weakened to excuse a failing test.

    2026-10-19 (PR #8014, accepted-main issuer-context integration):
    the normal c3d25f38 + f5b7b273 merge retains every existing Brain and
    upstream regression. Accepted main registers
    tests/test_gmi_issuer_economic_context_api.py in prelaunch-hardening.
    It is the sole selected weight change, 45 -> 47; the existing job sets
    are unchanged. The other two changed exclusive jobs do not enter any
    probe. Full-manifest measurements bound to the merged checkout compare
    the prior and combined manifests on the SAME combined source tree
    d7ab4bf07968eb6a8db2c107c06c0ca2bdf93c9b (not historical source runs):

        templates/index.html          136 -> 136 jobs, 5,808 -> 5,810 weight
        scripts/build_free_content.py 134 -> 134 jobs, 5,595 -> 5,597 weight
        engine/prophet/plan_book.py   129 -> 129 jobs, 5,557 -> 5,559 weight

    All three still require ten packs. Fund only the measured two units
    beyond the existing index-template ceiling: 5,808 -> 5,810. Keep both
    other weight limits, all job-count limits, every suite and selector,
    and the ten-pack limit. These are deterministic planning weights, not
    execution timings. The initial pytest failure is retained as evidence;
    no runtime, scope, command, observed-duration override or semantic
    release gate is changed. In particular, the independent Sector RIG
    approval requirement remains active.

    2026-10-19 (PR #8014, current hosted/base and Research-mode composition):
    hosted run 39219648574 tested 0bbef372 against b73dbbd8 and exposed
    index/build weights 5,814/5,601, above 5,810/5,600. The same original
    branch now joins accepted main ff1b80af, preserving its Research mode and
    every chart/rich regression. The prior and combined manifests, measured
    on the SAME combined source tree bec31d6128b830212570dae2a60f0ce4c9ad072c,
    select identical jobs; these are not historical source executions:

        templates/index.html          136 -> 136 jobs, 5,810 -> 5,822 weight
        scripts/build_free_content.py 134 -> 134 jobs, 5,597 -> 5,609 weight
        engine/prophet/plan_book.py   129 -> 129 jobs, 5,559 -> 5,571 weight

    All three remain at ten packs. Exactly four accepted upstream additions
    contribute to each probe: prelaunch-hardening +2 (issuer-context parity),
    support-email-spine +4 (held-material delivery), unrun-brain-gateway +2
    (Research mode) and unrun-intl-libraries +4 (US/China cohort contract).
    Other changed jobs are absent from these selected sets. The incoming
    main manifest alone measures 5,793/5,580/5,542 on this same source.
    Fund only the necessary exact ceilings: index 5,810 -> 5,822 and build
    5,600 -> 5,609. Preserve the plan-book ceiling, every job-count limit,
    all suites, selectors, scope/closure audits, observed-duration overrides
    and the ten-pack limit. These are planning weights, not execution times.
    No reference-integrity rule or approval requirement changes here.

    2026-10-20 (original PR #8014, accepted ec836731 integration):
    The combined and incoming manifests were measured on the same current
    source tree 52d2c31d7d3f3865975e1f499505e43788e318d5. Selected job sets
    are identical. Retaining the existing chart/readback/rich-answer suites
    makes unrun-brain-gateway 92 rather than incoming main's 63 weight units:
    exactly +29 on each probe, with no new or removed selected job.

        templates/index.html          135 jobs, 5,763 -> 5,792 weight
        scripts/build_free_content.py 134 jobs, 5,638 -> 5,667 weight
        engine/prophet/plan_book.py    128 jobs, 5,512 -> 5,541 weight

    All remain at ten packs. Only the build probe exceeds its current bound;
    fund exactly 5,638 -> 5,667. Preserve the index/plan-book ceilings, all
    job-count bounds, scopes, suite commands, import-closure audits, observed
    duration overrides and ten-pack bound. These are planning weights, not
    execution times; this does not change any reference-integrity requirement.

    2026-10-20 (original PR #8014, accepted d52827f2 integration):
    The combined and incoming manifests were measured on the same current
    source tree f2b2ea007cd9921618d1d50793fa110a0679f3c1. Selected job sets
    are identical. Retaining the existing chart/readback/rich-answer suites
    makes unrun-brain-gateway 92 rather than incoming main's 63 weight units:
    exactly +29 on each probe, with no new or removed selected job.

        templates/index.html          135 jobs, 5,767 -> 5,796 weight
        scripts/build_free_content.py 134 jobs, 5,642 -> 5,671 weight
        engine/prophet/plan_book.py    128 jobs, 5,516 -> 5,545 weight

    All remain at ten packs. Only the build probe exceeds its current bound;
    fund exactly 5,642 -> 5,671. Preserve the index/plan-book ceilings, all
    job-count bounds, scopes, suite commands, import-closure audits, observed
    duration overrides and ten-pack bound. These are planning weights, not
    execution times; this does not change any reference-integrity requirement.

    2026-10-20 original PR8014 recovery joins accepted e1ae07b1 after
    completing the retained d63e59bc+d19e1fb1 merge. On combined source tree
    6891a298547461200549a463a18a956b7ab4441e, both current-main and combined
    manifests select identical jobs. Retained chart/readback/rich suites add
    exactly 29 estimator units on every probe:

        templates/index.html          135 jobs, 5793 -> 5822 weight
        scripts/build_free_content.py 134 jobs, 5668 -> 5697 weight
        engine/prophet/plan_book.py    128 jobs, 5542 -> 5571 weight

    Each remains ten packs. Fund only the measured index ceiling 5803 ->
    5822 and build ceiling 5668 -> 5697; the plan-book ceiling, all job-count
    ceilings, suites, scopes, commands, assertions and ten-pack limit remain
    unchanged. These are planning weights, not execution times.

    2026-10-20 (original PR #7949, accepted 5c2d0a04 integration):
    The actual four-node run on frozen combined index
    1a008b73af0ef56634ce89bb07c62b7a5e0a5988 passed all three scope
    contracts and reproduced the two packing-weight breaches below.
    Applying incoming-main manifest weights to those SAME candidate-selected
    IDs gives the left column; this is not an incoming-tree selection run.

        templates/index.html          135 jobs, 5,822 -> 5,829 weight
        scripts/build_free_content.py 134 jobs, 5,697 -> 5,704 weight
        engine/prophet/plan_book.py    128 jobs, 5,571 -> 5,578 weight

    All three use ten packs. The only changed declared weights are retained
    Shared Shell coverage: data-base-shim 7 -> 12 (+5) and unrun-nav-chrome
    30 -> 32 (+2). Both jobs are present in every measured row. Fund only
    the two breached weight ceilings: 5,822 -> 5,829 and 5,697 -> 5,704.
    Preserve the plan-book ceiling 5,600, every job-count and pack bound,
    all suites, selectors, scope/closure audits and duration overrides.
    These are deterministic planning weights, not execution timings.
    """
    rows = packing_probe_measurements(
        MANIFEST, PACKING_PROBES, max_packs=PACKING_PROBE_MAX_PACKS
    )
    breaches = packing_probe_breaches(rows)
    assert not breaches, [
        (breach, row["reason"])
        for breach in breaches
        for row in rows
        if row["probe"] == breach[0]
    ]


def test_deliberately_unscoped_gates_stay_always_on(real_manifest_scopes) -> None:
    """The wave-8 entrants are always-on BY DESIGN — pin both directions.

    Each of these gates carries a header comment documenting deliberate
    unscoped breadth (a repo-wide walk, a diff ratchet over user-facing
    trees, a namespace-closure gate). Two regressions would be silent
    without this pin: (a) someone declares ``scope: exclusive``/``paths:``
    on one of them to buy back a probe ceiling — the job stops running on
    the PRs that are its actual subject, a false green the wave-2/wave-6
    notes reject by name; (b) inference drift stops selecting one of them
    on an ordinary user-facing PR. Both now red here, with the probe named.
    """
    jobs = {job.job_id: job for job in PACK.load_legacy_jobs(MANIFEST)}
    scoped_jobs, _ = real_manifest_scopes
    # Measured membership at wave 8 (main a8075391fa89): each gate pinned on
    # the probes that are its SUBJECT. design-governance is a user-facing
    # diff ratchet, so it rides the template and site-builder probes but has
    # no claim on engine internals; the other two walk trees that include
    # engine/**, so they ride all three.
    expected = {
        "design-governance": ("templates/index.html",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
                              "scripts/build_free_content.py"),  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        "board-shadow-substrate": ("templates/index.html",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
                                   "scripts/build_free_content.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
                                   "engine/prophet/plan_book.py"),
        "reference-integrity": ("templates/index.html",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
                                "scripts/build_free_content.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
                                "engine/prophet/plan_book.py"),
    }
    problems: list[str] = []
    for job_id in expected:
        job = jobs.get(job_id)
        if job is None:
            problems.append(f"{job_id}: missing from manifest")
            continue
        if job.exclusive:
            problems.append(
                f"{job_id}: gained scope:exclusive — deliberate always-on "
                "breadth curated away; see the wave-8 note")
    selected_names = {}
    for probe in ("templates/index.html", "scripts/build_free_content.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
                  "engine/prophet/plan_book.py"):
        sel, _ = PACK.select_jobs(scoped_jobs, [probe])
        selected_names[probe] = {job.job_id for job in sel}
    for job_id, probes in expected.items():
        if job_id not in jobs:
            continue
        for probe in probes:
            if job_id not in selected_names[probe]:
                problems.append(f"{job_id}: no longer selected for {probe}")
    assert not problems, problems


def test_evidence_corpus_edits_select_design_governance(real_manifest_scopes) -> None:
    """An evidence-only PR must run the receipt-corpus gate (2026-10-02, #8278).

    ``test_committed_evidence_corpus_has_zero_findings`` discovers EVERY committed
    ``EVIDENCE.yml`` under mockups/evidence + mockups/refs at RUNTIME, so the
    static closure inference never owned those trees: PR #8278 (evidence-only)
    planned ``1/168 jobs … did not widen`` and merged a malformed receipt that
    reddened main. The job now declares the two trees as an additive floor
    (unioned with inference — NOT ``scope: exclusive``). Pin both directions.
    """
    jobs = {job.job_id: job for job in PACK.load_legacy_jobs(MANIFEST)}
    job = jobs["design-governance"]
    assert not job.exclusive, "design-governance must stay non-exclusive (floor, not ceiling)"
    assert set(job.paths) >= {"mockups/evidence/**", "mockups/refs/**"}, job.paths
    assert len(job.paths) == 9, job.paths  # 2 corpora globs + the 7 files the steps name (loader coverage audit)
    scoped_jobs, _ = real_manifest_scopes
    for probe in ("mockups/evidence/sanctions-map-event-mark/EVIDENCE.yml",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test
                  "mockups/refs/onboarding/EVIDENCE.yml",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test
                  "mockups/evidence/some-capture/manifest.json"):  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test
        sel, reason = PACK.select_jobs(scoped_jobs, [probe])
        assert "design-governance" in {j.job_id for j in sel}, (probe, reason)


def test_inline_js_owns_the_rendered_tree_it_lints() -> None:
    """`check_inline_js.py site templates` names both trees as BARE argv.

    No `/` means SCOPE_REFERENCE_RE never saw a path, so this linter's real
    subject lived only in the opaque fallback tier — one tier-split away from
    a site edit silently not running the site linter. The declaration makes
    that ownership explicit, which is a correctness fix, not a narrowing.
    """
    jobs = {job.job_id: job for job in PACK.load_legacy_jobs(MANIFEST)}
    inline_js = jobs["inline-js"]
    assert inline_js.exclusive
    for probe in ("site/theme.css", "site/index.html", "templates/index.html"):  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
        match = PACK._job_diff_match(inline_js, [probe])
        assert match and match[1] == "declared", (probe, match)


def test_exclusive_scope_replaces_inference_and_audits_coverage(tmp_path: Path) -> None:
    """`scope: exclusive` is declared-wins: inference must not re-widen it.

    And the coverage audit is FATAL for it: an exclusive job whose commands
    name a file outside its declared paths must refuse to load — mis-declaring
    narrow has to be loud, because the silent version is a guard that stops
    running on the PRs that can break it.
    """
    workflow = tmp_path / "legacy.yml"
    workflow.write_text(
        """
jobs:
  curated:
    if: ${{ false }}
    runs-on: ubuntu-latest
    scope: exclusive
    paths:
      - "engine/example/**"
    steps:
      - name: curated semantic proof
        run: echo engine/example only
  plain:
    if: ${{ false }}
    runs-on: ubuntu-latest
    steps:
      - name: plain semantic proof
        run: echo unscoped
""",
        encoding="utf-8",
    )
    jobs = PACK.load_legacy_jobs(workflow)
    curated = {job.job_id: job for job in jobs}["curated"]
    assert curated.exclusive and curated.paths == ("engine/example/**",)
    inferred, _ = PACK.infer_job_scopes(jobs)
    curated_after = {job.job_id: job for job in inferred}["curated"]
    assert curated_after.paths == ("engine/example/**",)
    assert curated_after.fallback_paths == ()

    bad = tmp_path / "bad.yml"
    bad.write_text(
        """
jobs:
  curated:
    if: ${{ false }}
    runs-on: ubuntu-latest
    scope: exclusive
    paths:
      - "engine/example/**"
    steps:
      - name: outside-scope semantic proof
        run: python -m pytest tests/test_ci_pack.py -q
""",
        encoding="utf-8",
    )
    with pytest.raises(PACK.ManifestError, match="do not cover"):
        PACK.load_legacy_jobs(bad)

    empty = tmp_path / "empty.yml"
    empty.write_text(
        """
jobs:
  curated:
    if: ${{ false }}
    runs-on: ubuntu-latest
    scope: exclusive
    steps:
      - run: echo no paths declared
""",
        encoding="utf-8",
    )
    with pytest.raises(PACK.ManifestError, match="scope: exclusive but no paths"):
        PACK.load_legacy_jobs(empty)


def _released_cpython_versions() -> set[tuple[int, int, int]]:
    """Patch releases `document_terms` will accept, read without importing it.

    The module is parsed rather than imported on purpose. Importing it executes
    `_make_validate_released_parser_runtime`, which seals itself against the
    *running* interpreter — so on an unreleased CPython the import path is
    exactly the thing under test, and a guard that dies the same way it is
    meant to detect proves nothing.
    """
    source = (ROOT / "engine" / "capital_structure" / "document_terms.py").read_text()  # ci-trigger-closure: data — parsed, not imported (docstring above); declared in ci-control-plane-contracts paths
    tree = ast.parse(source)
    allowlist = None
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign) and any(
            isinstance(t, ast.Name) and t.id == "_PARSER_V1_1_0_RUNTIME_ALLOWLIST"
            for t in node.targets
        ):
            allowlist = node.value
            break
    assert allowlist is not None, (
        "_PARSER_V1_1_0_RUNTIME_ALLOWLIST vanished from document_terms.py — this "
        "guard pins CI's Python against it and must be re-pointed, not deleted"
    )
    # MappingProxyType({...}) -> unwrap to the dict literal.
    if isinstance(allowlist, ast.Call):
        allowlist = allowlist.args[0]
    assert isinstance(allowlist, ast.Dict)

    versions: set[tuple[int, int, int]] = set()
    for key in allowlist.keys:
        assert isinstance(key, ast.Call), "allowlist keys are ParserRuntimeFingerprint(...)"
        for kw in key.keywords:
            if kw.arg != "version_info":
                continue
            parts = ast.literal_eval(kw.value)
            versions.add((int(parts[0]), int(parts[1]), int(parts[2])))
    assert versions, "no version_info keys parsed out of the runtime allowlist"
    return versions


def test_ci_python_is_pinned_to_a_released_parser_runtime() -> None:
    """A floating `python-version` lets a tool-cache bump red the whole fleet.

    `engine/capital_structure/document_terms.py` seals its parser behind an
    allowlist keyed on `sys.version_info` plus stdlib source digests, so a
    CPython PATCH bump produces an unreleased fingerprint and the parser fails
    closed — 22 tests at once, in whichever pack currently owns
    `capital-structure-intelligence`, on every PR regardless of its diff.

    Measured 2026-08-19: the hosted tool cache moved 3.12.13 -> 3.12.14,
    `python-version: "3.12"` followed it, and ci-pack-8 went red on two
    independent heads (#5737, #5903) with an identical failure neither PR's
    files could cause. The self-hosted lanes stayed green on Homebrew 3.12.13.

    So the pin must be EXACT and must name a release the allowlist carries.
    Moving it is therefore ordered: extend the allowlist first (a review act
    owned by the Capital Structure Intelligence lane), bump the pin second.
    """
    released = _released_cpython_versions()
    workflow = _yaml(WORKFLOW)

    pins: list[tuple[str, str]] = []
    for job_name, job in (workflow.get("jobs") or {}).items():
        for step in job.get("steps") or []:
            uses = str(step.get("uses") or "")
            if not uses.startswith("actions/setup-python"):
                continue
            pins.append((job_name, str((step.get("with") or {}).get("python-version", ""))))

    assert pins, "ci.yml no longer calls actions/setup-python — re-point this guard"

    for job_name, pin in pins:
        parts = pin.split(".")
        assert len(parts) == 3 and all(p.isdigit() for p in parts), (
            f"ci.yml job {job_name!r} pins python-version={pin!r}. A floating pin "
            "follows the hosted tool cache onto CPython releases the "
            "capital-structure parser allowlist has never reviewed, which reds "
            "every PR at once. Pin an exact major.minor.patch."
        )
        version = (int(parts[0]), int(parts[1]), int(parts[2]))
        assert version in released, (
            f"ci.yml job {job_name!r} pins CPython {pin}, which is NOT in "
            "_PARSER_V1_1_0_RUNTIME_ALLOWLIST in "
            "engine/capital_structure/document_terms.py "
            f"(released: {sorted('.'.join(map(str, v)) for v in released)}). "
            "Add the release to that allowlist first — with provenance, the way "
            "the 3.12.13 entry records its actions/python-versions archive "
            "SHA-256 — then bump this pin."
        )


# ---------------------------------------------------------------------------
# W2 of research/CI_MERGE_GATE_RELIABILITY_ROOT_CAUSE_2026_08_19.md: the merge
# gate packs only `gate: code` legacy jobs; `gate: data` jobs move to the
# post-nightly data-health.yml lane. `--gate` is the mechanism (load_legacy_jobs
# filters immediately, before any partition/weight arithmetic); the two tests
# below guard the mechanism itself and that every production caller actually
# uses it, so a future edit cannot silently widen the merge gate back to 194.
# ---------------------------------------------------------------------------

DATA_HEALTH_WORKFLOW = ROOT / ".github" / "workflows" / "data-health.yml"


def test_prophet_chronology_suites_run_in_the_code_gate() -> None:
    """A green PR must execute the clock/correction suites, not defer them to data-health."""
    suites = (
        "tests/test_prophet_plan_chronology_audit.py",  # ci-trigger-closure: data — suite name inspected in the manifest
        "tests/test_prophet_integrity.py",  # ci-trigger-closure: data — suite name inspected in the manifest
    )
    jobs = PACK.load_legacy_jobs(MANIFEST, gate="code")
    owners = [
        job for job in jobs
        if any(
            all(suite in str(step.get("run", "")).split() for suite in suites)
            for step in job.definition["steps"]
        )
    ]
    assert len(owners) == 1, "clock/correction suites need one code-gated owner"
    scopes, _ = PACK.infer_job_scopes(owners)
    for changed in (*suites, "scripts/audit_prophet_plan_chronology.py"):  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test
        selected, reason = PACK.select_jobs(scopes, [changed])
        assert [job.job_id for job in selected] == [owners[0].job_id], (changed, reason)


def test_gate_filter_selects_only_matching_jobs(tmp_path: Path) -> None:
    """`--gate` (via `load_legacy_jobs(gate=...)`) is a strict partition.

    A synthetic two-job manifest — one `gate: code`, one `gate: data` — proves
    `code` selection excludes the data job and vice versa, and that omitting
    `gate` entirely (the pre-W2 default) still returns both, unchanged.
    """
    workflow = tmp_path / "ci.yml"
    workflow.write_text(
        """
jobs:
  ci-pack:
    runs-on: ubuntu-latest
    steps:
      - run: echo pack
  code-job:
    if: ${{ false }}
    runs-on: ubuntu-latest
    gate: code
    steps:
      - name: code step
        proof_id: code-step
        run: echo code
  data-job:
    if: ${{ false }}
    runs-on: ubuntu-latest
    gate: data
    steps:
      - name: data step
        proof_id: data-step
        run: echo data
"""
    )

    code_only = PACK.load_legacy_jobs(workflow, gate="code")
    assert [job.job_id for job in code_only] == ["code-job"]

    data_only = PACK.load_legacy_jobs(workflow, gate="data")
    assert [job.job_id for job in data_only] == ["data-job"]

    unfiltered = PACK.load_legacy_jobs(workflow)
    assert sorted(job.job_id for job in unfiltered) == ["code-job", "data-job"]

    # partition_jobs only ever sees what it is handed — proving the filter
    # runs before partitioning, not merely that the loader can produce it.
    code_packs = PACK.partition_jobs(code_only, 3)
    assert sum(len(pack) for pack in code_packs) == 1
    assert "data-job" not in [job.job_id for pack in code_packs for job in pack]


def _run_ci_pack_invocation_blocks(text: str) -> list[str]:
    """Every shell block that actually invokes run_ci_pack.py, as raw text.

    Matches only an interpreter invocation (`.../bin/python" scripts/
    run_ci_pack.py`), never a `paths:` trigger entry or a prose/comment
    mention of the filename — both of which also appear in ci.yml. A block
    runs from the invocation line through every following line indented AT
    LEAST as deep as it (YAML nesting, not blank lines: this file has no
    blank line between many adjacent steps, so a blank-line terminator
    swallows unrelated later steps — verified against the false positive
    that shape produced here). This covers both invocation shapes used in
    this repo: the `>-` folded-scalar argument list, whose continuation
    lines sit at the SAME indentation as the interpreter line, and the
    backslash-continued `run: |` block, whose continuation lines sit deeper.
    Either way the block ends at the first line that DEDENTS below the
    interpreter line — the next YAML key/step.
    """
    lines = text.splitlines()
    invocation_re = re.compile(r'bin/python"?\s+scripts/run_ci_pack\.py\b')
    blocks: list[str] = []
    index = 0
    while index < len(lines):
        if invocation_re.search(lines[index]):
            indent = len(lines[index]) - len(lines[index].lstrip(" "))
            block: list[str] = [lines[index]]
            cursor = index + 1
            while cursor < len(lines):
                line = lines[cursor]
                if not line.strip():
                    cursor += 1
                    continue
                line_indent = len(line) - len(line.lstrip(" "))
                if line_indent < indent:
                    break
                block.append(line)
                cursor += 1
            blocks.append("\n".join(block))
            index = cursor
        else:
            index += 1
    return blocks


# Workflows allowed to invoke run_ci_pack.py WITHOUT an explicit --gate, each
# with a reason a reviewer can check. This is a NAMED exception list, not a
# way to silence the guard — adding an entry here must be a deliberate,
# reasoned call, the same way GATE_VALUES itself is deliberate.
GATE_REACHABILITY_ALLOWLIST: dict[str, str] = {
    "selfhosted-ci-canary.yml": (
        "deliberate full-suite parity/contamination canary: it exists to "
        "compare self-hosted runner output against the hosted baseline over "
        "the COMPLETE manifest, so narrowing it to one gate would defeat its "
        "purpose"
    ),
}


def test_no_data_gated_job_is_reachable_from_ci_gate() -> None:
    """Every merge-gate invocation of run_ci_pack.py passes `--gate code`.

    This is the reachability half of the W2 guard: it is not enough for the
    `--gate` flag to exist and work (see the unit test above) — every actual
    caller inside ci.yml (the plan step and both pack-execution paths, plan-
    json and the unpinned fail-safe fallback) must pass it, or a `gate: data`
    job stays reachable from the merge gate despite the split. Symmetrically,
    data-health.yml's own invocation must pass `--gate data`, or the new lane
    silently re-runs (or worse, never runs) the wrong half of the manifest.

    Widened (Opus review of commit 18e0f878) to enumerate EVERY workflow file
    repo-wide, not just ci.yml and data-health.yml: a run_ci_pack.py call
    anywhere without an explicit --gate is exactly the kind of silent
    reachability hole this guard exists to catch, whichever workflow it is
    added to later. `GATE_REACHABILITY_ALLOWLIST` is the one permitted
    exception, and it is named and reasoned, not blanket.
    """
    ci_text = WORKFLOW.read_text()
    ci_blocks = _run_ci_pack_invocation_blocks(ci_text)
    assert len(ci_blocks) == 3, (
        f"expected exactly 3 run_ci_pack.py invocations in ci.yml (ci-plan, "
        f"the plan-json pack execution, and the unpinned fallback), found "
        f"{len(ci_blocks)}: re-point this guard if ci.yml's call sites changed"
    )
    for block in ci_blocks:
        assert "--gate code" in block, (
            "a run_ci_pack.py invocation in ci.yml is missing --gate code — "
            "this would leave a gate: data job reachable from the merge gate:\n"
            + block
        )

    assert DATA_HEALTH_WORKFLOW.exists(), (
        "W2 of research/CI_MERGE_GATE_RELIABILITY_ROOT_CAUSE_2026_08_19.md "
        "requires .github/workflows/data-health.yml to exist"
    )
    data_health_text = DATA_HEALTH_WORKFLOW.read_text()
    data_health_blocks = _run_ci_pack_invocation_blocks(data_health_text)
    assert data_health_blocks, "data-health.yml never invokes run_ci_pack.py"
    for block in data_health_blocks:
        assert "--gate data" in block, (
            "a run_ci_pack.py invocation in data-health.yml is missing "
            "--gate data:\n" + block
        )

    data_health_workflow = _yaml(DATA_HEALTH_WORKFLOW)
    for job_name, job in (data_health_workflow.get("jobs") or {}).items():
        runs_on = job.get("runs-on")
        assert runs_on == "ubuntu-latest" or (
            isinstance(runs_on, list) and "self-hosted" not in runs_on
        ), (
            f"data-health.yml job {job_name!r} runs on {runs_on!r} — this lane "
            "must stay on GitHub-hosted runners, never self-hosted "
            "(CLAUDE.md — render/nightly compute stays off this pool)"
        )

    # Repo-wide sweep: any OTHER workflow (present or future) that invokes
    # run_ci_pack.py must carry an explicit --gate, unless it is named in
    # GATE_REACHABILITY_ALLOWLIST above.
    workflows_dir = ROOT / ".github" / "workflows"
    gate_flag_re = re.compile(r"--gate\s+(?:code|data)\b")
    for workflow_path in sorted(workflows_dir.glob("*.yml")):
        name = workflow_path.name
        if name in {"ci.yml", "data-health.yml"}:
            continue  # already fully covered above
        blocks = _run_ci_pack_invocation_blocks(workflow_path.read_text())
        if not blocks:
            continue
        if name in GATE_REACHABILITY_ALLOWLIST:
            continue
        for block in blocks:
            assert gate_flag_re.search(block), (
                f"{name} invokes run_ci_pack.py without an explicit --gate — "
                "either pass --gate code/data or add a NAMED, reasoned entry "
                f"to GATE_REACHABILITY_ALLOWLIST:\n{block}"
            )


def test_no_empty_pack_in_the_code_gate_partition() -> None:
    """An empty ci-pack-N under the code gate would vanish from main's baseline.

    ci-gate's base-inherited-red refresh resolves a PR's failing check NAMES
    against main's own newest concluded ci.yml run by NAME (CLAUDE.md
    "green proof against a stale base"; #5037). A pack index with zero jobs
    still has to exist and publish a name on main's baseline, or a PR whose
    plan happens to land work on that index has no baseline check of the same
    name to compare against, and any red there becomes permanently
    unrefreshable. The load-bearing property is "no pack is empty" — not any
    particular per-pack job count, which shifts as the manifest grows.
    """
    jobs = PACK.load_legacy_jobs(MANIFEST, gate="code")
    packs = PACK.partition_jobs(jobs, 12)
    empty = [index for index, pack in enumerate(packs) if not pack]
    assert not empty, (
        f"pack index(es) {empty} are empty under --gate code with --pack-count "
        "12 — an empty pack's name would vanish from main's ci.yml baseline "
        "and any PR whose plan lands work there could never refresh a red"
    )


# ── W7A_7070_HEAL H4: regression lock for # inside folded `run: >` scalars ──
#
# The W11 round-1 heal moved a 4-line `#` comment INTO a folded `run: >` pytest
# scalar at .github/ci/legacy-jobs.yml:2498-2501. YAML folds the scalar onto ONE
# shell line where `#` starts a shell comment, so the entire w11 suite was
# effectively dropped from the argv (effective 113 of 173 listed) without any of
# check_contract_delta / audit_unrun_tests / run_ci_pack validate catching it
# (those text-parse YAML rather than the folded shell). The exact fleet-hazard
# this round closed must not recur undetected.


_FOLDED_RUN_RE = re.compile(r"^( +)run: >-?\s*$", re.MULTILINE)


def _iter_folded_run_scalars(text: str) -> list[tuple[int, int, str]]:
    """Yield (indent, line_number, scalar_text) for every folded `run: >` scalar.

    A folded scalar ends at the first line whose indent is `<=` the indicator
    line's indent (or EOF). YAML folded scalars collapse newlines into spaces
    when consumed by a shell — so a `#` token anywhere inside is a shell
    comment, NOT a YAML comment.
    """
    out: list[tuple[int, int, str]] = []
    for m in _FOLDED_RUN_RE.finditer(text):
        indent = len(m.group(1))
        # line_number of the `run: >` indicator (YAML is 1-indexed for grep parity)
        line_no = text.count("\n", 0, m.start()) + 1
        # Walk subsequent lines collecting the scalar body
        body_lines: list[str] = []
        cursor = m.end()
        body_indent = indent + 1
        while cursor < len(text):
            nl = text.find("\n", cursor)
            if nl == -1:
                chunk = text[cursor:]
                nl = len(text)
            else:
                chunk = text[cursor:nl]
            stripped = chunk.lstrip(" ")
            if chunk == "" or chunk.startswith(" " * body_indent):
                body_lines.append(chunk)
                cursor = nl + 1
                continue
            # First non-empty line at <= indicator indent ends the scalar
            if stripped == "" or len(chunk) - len(chunk.lstrip(" ")) <= indent:
                if stripped == "":
                    # Blank line at <= indicator indent also ends it
                    break
                break
            break
        out.append((indent, line_no, "\n".join(body_lines)))
    return out


def test_no_hash_token_inside_folded_run_scalar_in_legacy_jobs_manifest() -> None:
    """Every folded `run: >` pytest scalar must be free of `#` shell-comment tokens.

    A `#` inside a folded scalar (e.g. ``run: >\\n  # W11 coverage-true\\n  python -m
    pytest ...``) becomes a shell comment when GitHub folds it back into one argv
    line, silently dropping every pytest token that follows. That is how
    a95d2856e077 / de288cf6706f dropped 60 of main's own suites while every
    contract-delta / audit_unrun_tests / run_ci_pack validate check stayed green.

    RED-first: inserting a `# ...` line inside the folded scalar at
    .github/ci/legacy-jobs.yml (e.g. at the engine-render-guards step) FAILS this
    test; reverting that insertion restores the green.
    """
    text = MANIFEST.read_text(encoding="utf-8")
    scalars = _iter_folded_run_scalars(text)
    assert scalars, "expected at least one folded run: > scalar in legacy-jobs.yml"

    # Vacuity guard: confirm at least one folded scalar is a pytest invocation,
    # otherwise a future PR could clear this test by deleting every folded pytest
    # step (and the harness would no longer catch the # hazard class at all).
    pytest_folded = [
        (indent, line_no, body)
        for indent, line_no, body in scalars
        if "pytest" in body
    ]
    assert pytest_folded, (
        "no folded `run: >` pytest scalar found — the vacuity guard below would "
        "be untestable; check that the manifest still carries folded pytest steps"
    )

    offenders: list[tuple[int, int, str, list[str]]] = []
    for indent, line_no, body in scalars:
        # A `#` token anywhere in the scalar body is the hazard; flag the lines.
        bad_lines = [
            ln for ln in body.splitlines() if "#" in ln
        ]
        if bad_lines:
            offenders.append((indent, line_no, body, bad_lines))

    assert not offenders, (
        "folded `run: >` scalars in .github/ci/legacy-jobs.yml must not contain "
        "# shell-comment tokens — YAML folds them onto one argv line where '#' "
        "starts a shell comment, silently dropping every pytest token that "
        "follows. Offenders (indicator line, offending body lines):\n"
        + "\n".join(
            f"  line {ln}: {bl[:120]}"
            for _indent, ln, _body, bl in offenders
        )
    )


# ---------------------------------------------------------------------------
# p0b-receipt-closure: own job, curated scope bound to the committed receipts
# (2026-09-24, #6872 postmortem — DSC:PACK-RUNNER-SKIPS-STEPS-AFTER-FIRST-RED)
# ---------------------------------------------------------------------------

P0B_JOB = "p0b-receipt-closure"
P0B_GATE_NEEDLE = "check_p0b_receipt_closure.py --diff-file"
# The exact pinned paths #6872 (merge ac61896da96c) changed without the receipts.
P0B_6872_PINNED_MOVES = (
    "templates/_navlinks.html.j2",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
    "mockups/evidence/prophet-p0b-zero-fouc/rendered-fixture.json",
)


def _p0b_run_commands(definition: dict) -> list[str]:
    return [
        str(step["run"])
        for step in definition.get("steps", [])
        if isinstance(step, dict) and "run" in step
        and "pip install" not in str(step["run"])
    ]


@pytest.mark.needs_full_checkout("mockups")
def test_p0b_receipt_closure_job_owns_every_receipt_pinned_path() -> None:
    """Every path the committed P0B receipts pin selects ``p0b-receipt-closure``.

    #6872 (2026-09-24) changed templates/_navlinks.html.j2 and the rendered
    fixture without re-minting mockups/evidence/prophet-p0b-zero-fouc/
    mobile-layout*.json, and main went red on ci-pack-9 for hours. The gate
    existed (#7613) but as trailing steps on ``design-governance``, and
    "unscoped" there was NOT always-on: ``infer_job_scopes`` derived a scope
    from the job's commands, ``mockups/`` sits outside every opaque scan root,
    and a diff touching only the fixture selected 3/158 jobs with the job
    skipped (measured on the pre-fix manifest, inference on).

    The job is now ``scope: exclusive`` over the ROOTS the pins live under.
    ``scope: exclusive`` replaces inference (``infer_job_scopes`` keeps the
    declared paths and clears the fallback tier), so ``select_jobs`` on the
    loaded manifest is exactly what ``ci-plan`` computes for this job — no
    minute-long inference pass is needed to pin it. The pin set is DERIVED
    from the receipts here, the same way the gate derives it at runtime, so a
    receipt that later pins a path outside the curated roots reds this test
    and names the path: widen ``paths:`` in the same PR, never narrow the
    receipts.
    """
    import scripts.check_p0b_receipt_closure as guard

    jobs = PACK.load_legacy_jobs(MANIFEST)
    by_id = {job.job_id: job for job in jobs}
    job = by_id.get(P0B_JOB)
    assert job is not None, f"{P0B_JOB} missing from {MANIFEST.name}"
    assert job.gate == "code", "the verdict is a function of the PR tree only"
    assert job.exclusive, (
        "curated scope must REPLACE inference — a unioned fallback tier is "
        "what let mockups-only diffs skip the gate on #6872")

    pin_sets, refuse = guard.derive_pin_sets(ROOT)
    assert refuse is None, refuse
    pinned: set[str] = set(pin_sets)
    for pins in pin_sets.values():
        pinned |= pins
    assert len(pinned) >= 20, sorted(pinned)  # receipts, fixture, inputs, assets

    unowned = sorted(
        path for path in pinned
        if P0B_JOB not in {j.job_id for j in PACK.select_jobs(jobs, [path])[0]}
    )
    assert not unowned, (
        f"{len(unowned)} receipt-pinned path(s) would not select {P0B_JOB}; "
        f"widen its paths: in .github/ci/legacy-jobs.yml: {unowned}")

    # The gate's own inputs re-run the gate too.
    for own in ("scripts/check_p0b_receipt_closure.py",
                "tests/test_check_p0b_receipt_closure.py"):
        assert P0B_JOB in {j.job_id for j in PACK.select_jobs(jobs, [own])[0]}, own


def test_p0b_receipt_closure_gate_runs_first_and_has_one_home() -> None:
    """The closure verdict is the job's FIRST run step, and nothing else hosts it.

    ``run_ci_pack.py`` skips a logical job's remaining steps once one fails
    (``ALLOWED_STEP_KEYS`` carries no per-step ``if``), so on #6872 the
    forward-only design ratchet's five ``color-mix(`` findings on
    templates/ontology.css ran first and the closure step NEVER EXECUTED —
    ci run 36036232964, ci-pack-3: no p0b step group follows the ratchet's
    ``exited 1``. Gate first means its verdict is printed whatever the
    selftest and unit suite do; one home means no sibling gate can shadow it
    again. The house-law registry must point at that home, or the textual
    wiring check would pass against a job that no longer runs the script.
    """
    manifest = _yaml(MANIFEST)["jobs"]
    commands = _p0b_run_commands(manifest[P0B_JOB])
    assert commands, "p0b-receipt-closure has no run steps"
    assert P0B_GATE_NEEDLE in commands[0], (
        "the receipt-closure gate must be the first run step; a red selftest "
        "or unit suite ahead of it would hide the verdict")
    assert "check_p0b_receipt_closure.py --selftest" in "\n".join(commands)
    assert "tests/test_check_p0b_receipt_closure.py" in "\n".join(commands)

    other_homes = sorted(
        job_id for job_id, definition in manifest.items()
        if job_id != P0B_JOB and isinstance(definition, dict)
        and "check_p0b_receipt_closure" in "\n".join(_p0b_run_commands(definition))
    )
    assert not other_homes, (
        f"the p0b closure gate has a second home {other_homes}; trailing steps "
        "on a sibling gate are exactly what shadowed it on #6872")

    registry = yaml.safe_load(
        (ROOT / "config" / "house_law_checks.yml").read_text(encoding="utf-8"))
    entries = registry["checks"] if isinstance(registry, dict) else registry
    law = next(e for e in entries if e.get("law_id") == "ui.p0b_receipt_closure")
    wired = {w.get("job") for w in law.get("ci_wiring", []) if w.get("lane") == "pr_ci"}
    assert wired == {P0B_JOB}, wired


@pytest.mark.needs_full_checkout("mockups")
def test_p0b_receipt_closure_job_would_block_6872_diff_shape(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    """Reproduction: #6872's diff shape is selected AND fails the gate.

    Selection: the two pinned paths that merge ``ac61896da96c`` moved without
    the receipts each select ``p0b-receipt-closure`` on their own — including
    the fixture, which lives under ``mockups/`` and selected nothing that
    runs the gate before this job existed. Verdict: fed that diff, the gate
    names both paths against BOTH committed receipts (four findings) and
    exits 1, which is the ``::error`` the PR's pack would now print as its
    own logical job instead of being skipped behind a sibling gate's red.
    """
    import scripts.check_p0b_receipt_closure as guard

    jobs = PACK.load_legacy_jobs(MANIFEST)
    for path in P0B_6872_PINNED_MOVES:
        selected = {j.job_id for j in PACK.select_jobs(jobs, [path])[0]}
        assert P0B_JOB in selected, (path, sorted(selected))
    selected, _reason = PACK.select_jobs(jobs, list(P0B_6872_PINNED_MOVES))
    assert P0B_JOB in {j.job_id for j in selected}

    pin_sets, refuse = guard.derive_pin_sets(ROOT)
    assert refuse is None, refuse
    changed = set(P0B_6872_PINNED_MOVES) | {
        "templates/ontology.css", "site/ontology.html", "app/main.py",  # ci-trigger-closure: data — file NAME handed to the planner, not read by this test (note at the top)
    }
    findings = guard.evaluate(changed, pin_sets)
    assert len(findings) >= 4, findings
    for path in P0B_6872_PINNED_MOVES:
        assert any(path in f for f in findings), (path, findings)
    for receipt in pin_sets:
        assert any(receipt in f for f in findings), (receipt, findings)

    # End to end, the way the job's step invokes it: exit 1 and line-start
    # ``::error`` annotations naming the moves and the remint command.
    diff_file = tmp_path / "p0b.changed"
    diff_file.write_text("\n".join(sorted(changed)) + "\n", encoding="utf-8")
    rc = guard.main(["--diff-file", str(diff_file), "--repo-root", str(ROOT)])
    out = capsys.readouterr().out
    assert rc == 1, out
    errors = [line for line in out.splitlines()
              if line.startswith("::error title=p0b-receipt-closure::")]
    assert sum("PINNED PATH CHANGED WITHOUT RECEIPT" in e for e in errors) >= 4, out
    assert any("re-mint with:" in e for e in errors), out


def test_markets_fresh_render_byte_match_is_code_gated_and_runs_exactly_once() -> None:
    """The markets.html fresh-render byte guard runs on the CODE gate, once.

    History this pins, in order. The guard baked ``scripts.build_markets`` IN
    PLACE and compared against the committed ``site/markets.html``, so it read
    the live ``data/regime`` + ``data/market_state`` feeds that closing-bell's
    scope=close render rewrites without re-baking the page — it reddened every
    merge ref cut between that data commit and the next ``render.yml`` bake, on
    a tree no PR had changed (measured on PR #7971's merge ref: HK Risk-on ->
    Risk-off in the fresh render only). #7971 therefore deselected the node here
    and ran it on a ``gate: data`` twin, ``markets-regime-strip-bake-parity``.

    #7986 removed the live read: the guard recovers the branch each strip row
    took from the committed page's own ``mx-stance`` modifiers, bakes into
    ``tmp_path`` with those views pinned in place of the three
    ``_persisted_ms_view`` reads, and normalises the lane-owned
    ``optimize_assets`` markup on both sides. A data-only commit can no longer
    flip it; a template, partial or builder edit shipped without a rebake still
    does. By GATE_VALUES' own definition that verdict is ``code``, so the node
    is back on the merge gate — the only gate a PR can act on.

    The twin is RETIRED rather than narrowed. Post-#7986 it would select the
    same node and assert the same thing this job asserts, because the node no
    longer reads the feeds the split was made for: a second run buys no
    coverage and re-creates a duplicate owner. A data-gated freshness check —
    committed strip verdicts versus the live persisted feeds — would be a NEW
    test, not this one, and is deliberately not minted in its place: it would
    alarm on exactly the between-bakes window #7971 was opened to stop
    alarming on.
    """
    manifest = _yaml(MANIFEST)["jobs"]
    node = ("tests/test_markets_regime_strip.py::"
            "test_fresh_render_byte_matches_committed_markets_html")
    selector = "test_fresh_render_byte_matches_committed_markets_html"

    strip = manifest["markets-regime-strip"]
    assert strip["gate"] == "code", strip["gate"]
    strip_cmds = "\n".join(str(s["run"]) for s in strip["steps"] if "run" in s)
    assert "tests/test_markets_regime_strip.py" in strip_cmds, strip_cmds
    # The node RUNS: the suite is named whole, with nothing that drops a node
    # from it. Any future narrowing has to come back through this fixture.
    assert "--deselect" not in strip_cmds, strip_cmds
    assert "-k " not in strip_cmds, strip_cmds

    # The data-gated twin is gone, and no other job re-runs the node.
    assert "markets-regime-strip-bake-parity" not in manifest, sorted(manifest)
    duplicates = []
    for name, job in manifest.items():
        if name == "markets-regime-strip" or not isinstance(job, dict):
            continue
        cmds = "\n".join(
            str(step["run"])
            for step in (job.get("steps") or [])
            if isinstance(step, dict) and "run" in step
        )
        if selector in cmds or node in cmds:
            duplicates.append(name)
    assert not duplicates, sorted(duplicates)


@pytest.mark.parametrize("probe", [row[0] for row in PACKING_PROBES])
def test_transmission_scope_does_not_match_unrelated_packing_probe(probe: str) -> None:
    """GMI's reader import must not restore transmission's opaque code fallback."""
    job = next(job for job in PACK.load_legacy_jobs(MANIFEST)
               if job.job_id == "transmission-chains")
    assert job.exclusive
    selected, _ = PACK.select_jobs([job], [probe])
    assert not selected, f"transmission does not read packing probe {probe}"


@pytest.mark.parametrize("owned_path", [
    "engine/transmission_chains.py",  # ci-trigger-closure: data — selector label, never opened
    "engine/neuralweb/world_state.py",  # ci-trigger-closure: data — selector label, never opened
    "engine/neuralweb/theme_state_generation_reader.py",  # ci-trigger-closure: data — selector label, never opened
    "scripts/build_transmission.py",  # ci-trigger-closure: data — selector label, never opened
    "tests/test_transmission_chains_nw.py",  # ci-trigger-closure: data — selector label, never opened
    "tests/fixtures/transmission/new_case.json",  # ci-trigger-closure: data — selector label, never opened
    "knowledge/transmission/new_chain.yaml",  # ci-trigger-closure: data — selector label, never opened
    "knowledge/transmission/proposed/new_chain.yaml",  # ci-trigger-closure: data — selector label, never opened
    "knowledge/transmission/killed/new_chain.yaml",  # ci-trigger-closure: data — selector label, never opened
    "data/yahoo/NEW_SERIES.parquet",  # ci-trigger-closure: data — selector label, never opened
    "data/transmission/chain_calibration.json",  # ci-trigger-closure: data — selector label, never opened
    "site/stockdata/NEW_SYMBOL.json",  # ci-trigger-closure: data — selector label, never opened
    "site/assets/css/0123abcd.css",  # ci-trigger-closure: data — selector label, never opened
    "templates/transmission.html.j2",  # ci-trigger-closure: data — selector label, never opened
    "templates/_navlinks.html.j2",  # ci-trigger-closure: data — selector label, never opened
    "templates/_future_fragment.html.j2",  # ci-trigger-closure: data — selector label, never opened
    "config.yml",  # ci-trigger-closure: data — selector label, never opened
])
def test_transmission_scope_retains_static_and_future_dynamic_inputs(owned_path: str) -> None:
    """Future corpus/asset/series members remain selected; no frozen-file loophole."""
    job = next(job for job in PACK.load_legacy_jobs(MANIFEST)
               if job.job_id == "transmission-chains")
    selected, _ = PACK.select_jobs([job], [owned_path])
    assert [job.job_id for job in selected] == ["transmission-chains"]


def test_price_ladder_deterministic_contract_is_owned_by_existing_code_gate(tmp_path: Path) -> None:
    """Production ladder source AND test-only edits run the deterministic suite."""
    manifest = _yaml(MANIFEST)
    owner = manifest["jobs"]["price-basis-census"]
    suite = "tests/test_price_ladder.py"  # ci-trigger-closure: data — suite NAME for planner/argv checks
    assert owner["gate"] == "code"
    assert {"pytest", "pandas", "numpy", "pyarrow"} <= _job_pip_packages(owner)
    runs = [str(step.get("run") or "") for step in owner["steps"]]
    pytest_runs = [command for command in runs if " -m pytest " in command]
    assert len(pytest_runs) == 1
    assert shlex.split(pytest_runs[0]) == [
        "python", "-m", "pytest", "tests/test_price_basis_graders.py", suite, "-q",
        "--deselect", suite + "::test_real_store_cfg_diverges_from_the_cache_by_a_dividend",
        "--deselect", suite + "::test_real_store_control_non_payers_agree_across_sources",
        "--deselect", suite + "::test_real_store_ladder_prefers_adjusted_for_a_cached_name",
    ]
    assert _job_pip_packages(manifest["jobs"]["dataos-foundation"]) == {"pytest", "pyyaml"}
    owner_manifest = tmp_path / "price-basis-owner.yml"
    owner_manifest.write_text(yaml.safe_dump({"jobs": {"price-basis-census": owner}}))
    jobs, scope_reason = PACK.infer_job_scopes(PACK.load_legacy_jobs(owner_manifest, gate="code"))
    assert len(jobs) == 1 and jobs[0].is_scoped, scope_reason
    for changed in (["engine/price_ladder.py"], [suite]):  # ci-trigger-closure: data — synthetic diff
        selected, reason = PACK.select_jobs(jobs, changed)
        assert [job.job_id for job in selected] == ["price-basis-census"], reason
        assert "unowned path" not in reason, reason
    selected, reason = PACK.select_jobs(jobs, ["tests/test_dataos_price.py"])  # ci-trigger-closure: data — synthetic diff
    assert not selected, reason


def test_options_pilot_chronology_runs_on_source_changes_without_unrelated_probes():
    jobs = {job.job_id: job for job in PACK.load_legacy_jobs(MANIFEST, gate="code")}
    job = jobs["options-pilot-chronology-code"]
    assert job.exclusive
    for dependency in (
        "scripts/options_pilot_study_adapter.py",  # ci-trigger-closure: data — selector name only
        "tests/test_options_pilot_chronology.py",  # ci-trigger-closure: data — selector name only
        "research/options_intelligence/2026-10-03/pilot-study-spec.v1.json",  # ci-trigger-closure: data — selector name only
        "research/options_intelligence/2026-10-03/pilot-p3-reference.py",  # ci-trigger-closure: data — selector name only
        "research/options_intelligence/2026-10-03/gex-published-board-extract.json",  # ci-trigger-closure: data — selector name only
    ):
        selected, _ = PACK.select_jobs([job], [dependency])
        assert [item.job_id for item in selected] == [job.job_id], dependency
    selected, _ = PACK.select_jobs([job], ["scripts/build_free_content.py"])  # ci-trigger-closure: data — selector name only
    assert selected == []
    manifest = _yaml(MANIFEST)["jobs"][job.job_id]
    assert any("tests/test_options_pilot_chronology.py" in shlex.split(step.get("run", ""))  # ci-trigger-closure: data — command membership only
               for step in manifest["steps"])
# ---------------------------------------------------------------------------
# W15-F-AIC lane — REPORT-ONLY ancestor-init census for curated-exclusive jobs.
#
# Importing a module executes every ancestor package's ``__init__.py``, but the
# closure the curator audits is literal paths: a non-declared ``__init__.py``
# is exactly the silent scope gap the curated tier exists to prevent. These
# tests pin the pure census function and the ``--ancestor-init-census`` report
# flag. Building the manifest, inits, and paths under ``tmp_path`` keeps the
# suite hermetic from HEAD's manifest and any other branch's history. The
# isolation mechanism is EXPLICIT, not the location of ``tmp_path``: the
# pure-function tests pass ``repo_root=tmp_path`` directly, and the CLI test
# runs its subprocess with ``GIT_CEILING_DIRECTORIES`` set to the fixture's
# PARENT so the git discovery inside ``_find_repo_root`` cannot chdir up out
# of the fixture tree (git never excludes the cwd itself, only the dirs it
# would chdir up into). Without that ceiling, a ``--basetemp`` placed inside
# a checkout makes the census resolve against the enclosing checkout and
# silently print ``pairs=0`` instead of the fixture's pairs.
# ---------------------------------------------------------------------------


def _aic_manifest(tmp_path: Path, *, job_id: str, paths: list[str]) -> Path:
    """Write a one-job legacy manifest declaring ``paths`` literally."""
    workflow = tmp_path / "legacy.yml"
    workflow.write_text(
        yaml.safe_dump(
            {
                "jobs": {
                    job_id: {
                        "if": PACK.DISABLED_IF,
                        "runs-on": "ubuntu-latest",
                        "scope": "exclusive",
                        "paths": list(paths),
                        "steps": [
                            {
                                "name": "ancestor-init fixture",
                                "run": "echo fixture",
                            }
                        ],
                    }
                }
            }
        ),
        encoding="utf-8",
    )
    return workflow


def _aic_optional_init(directory: Path, *, body: bytes = b"") -> None:
    """Materialise ``__init__.py`` in ``directory`` with ``len(body)`` bytes."""
    directory.mkdir(parents=True, exist_ok=True)
    (directory / "__init__.py").write_bytes(body)


def _aic_load(workflow: Path) -> list[PACK.LegacyJob]:
    jobs = PACK.load_legacy_jobs(workflow)
    assert len(jobs) == 1 and jobs[0].exclusive, [j.job_id for j in jobs]
    return jobs


def test_ancestor_init_census_two_inits_with_right_bytes(tmp_path: Path) -> None:
    """(a) two inits neither declared — exactly two findings, right bytes."""
    workflow = _aic_manifest(
        tmp_path, job_id="c-a", paths=["pkg/sub/mod.py"]
    )
    _aic_optional_init(tmp_path / "pkg", body=b"# package pkg\n")
    _aic_optional_init(tmp_path / "pkg" / "sub", body=b"")
    jobs = _aic_load(workflow)

    findings = PACK.ancestor_init_census(jobs, repo_root=tmp_path)

    assert len(findings) == 2, findings
    by_init = {f.init_path: f for f in findings}
    assert by_init["pkg/__init__.py"].init_bytes == 14
    assert by_init["pkg/sub/__init__.py"].init_bytes == 0
    assert {f.job for f in findings} == {"c-a"}
    assert {f.declared_path for f in findings} == {"pkg/sub/mod.py"}


def test_ancestor_init_census_both_inits_declared_literally(tmp_path: Path) -> None:
    """(b) both inits declared literally ⇒ 0 findings."""
    workflow = _aic_manifest(
        tmp_path,
        job_id="c-b",
        paths=[
            "pkg/sub/mod.py",
            "pkg/__init__.py",
            "pkg/sub/__init__.py",
        ],
    )
    _aic_optional_init(tmp_path / "pkg", body=b"# package\n")
    _aic_optional_init(tmp_path / "pkg" / "sub", body=b"")
    jobs = _aic_load(workflow)

    assert PACK.ancestor_init_census(jobs, repo_root=tmp_path) == ()


def test_ancestor_init_census_declared_glob_covers_inits(tmp_path: Path) -> None:
    """(c) a glob covering both inits ⇒ 0 findings."""
    workflow = _aic_manifest(
        tmp_path,
        job_id="c-c",
        paths=["pkg/**"],
    )
    _aic_optional_init(tmp_path / "pkg", body=b"# package\n")
    _aic_optional_init(tmp_path / "pkg" / "sub", body=b"")
    jobs = _aic_load(workflow)

    assert PACK.ancestor_init_census(jobs, repo_root=tmp_path) == ()


def test_ancestor_init_census_allowlist_suppresses_both_inits(
    tmp_path: Path,
) -> None:
    """(d) both inits in the allow-list ⇒ 0 findings."""
    workflow = _aic_manifest(
        tmp_path, job_id="c-d", paths=["pkg/sub/mod.py"]
    )
    _aic_optional_init(tmp_path / "pkg", body=b"# package\n")
    _aic_optional_init(tmp_path / "pkg" / "sub", body=b"")
    jobs = _aic_load(workflow)

    findings = PACK.ancestor_init_census(
        jobs,
        repo_root=tmp_path,
        allowlist=frozenset({"pkg/__init__.py", "pkg/sub/__init__.py"}),
    )

    assert findings == ()


def test_ancestor_init_census_namespace_subinit_omitted(tmp_path: Path) -> None:
    """(e) ``pkg/sub/__init__.py`` absent (namespace) ⇒ only the ``pkg`` finding."""
    workflow = _aic_manifest(
        tmp_path, job_id="c-e", paths=["pkg/sub/mod.py"]
    )
    _aic_optional_init(tmp_path / "pkg", body=b"# package\n")
    # NOTE: pkg/sub/__init__.py is intentionally NOT created.
    jobs = _aic_load(workflow)

    findings = PACK.ancestor_init_census(jobs, repo_root=tmp_path)

    assert len(findings) == 1, findings
    assert findings[0].init_path == "pkg/__init__.py"
    assert findings[0].init_bytes > 0


def test_ancestor_init_census_glob_only_declaration_emits_nothing(
    tmp_path: Path,
) -> None:
    """(f) a glob-only declared path list contributes no findings."""
    workflow = _aic_manifest(
        tmp_path,
        job_id="c-f",
        paths=["pkg/**", "pkg/sub/**"],
    )
    _aic_optional_init(tmp_path / "pkg", body=b"# package\n")
    _aic_optional_init(tmp_path / "pkg" / "sub", body=b"")
    jobs = _aic_load(workflow)

    assert PACK.ancestor_init_census(jobs, repo_root=tmp_path) == ()


def test_ancestor_init_census_ignores_non_exclusive_jobs(tmp_path: Path) -> None:
    """(g) a non-exclusive job is ignored even if its paths leave inits undeclared."""
    workflow = tmp_path / "legacy.yml"
    workflow.write_text(
        yaml.safe_dump(
            {
                "jobs": {
                    "not-curated": {
                        "if": PACK.DISABLED_IF,
                        "runs-on": "ubuntu-latest",
                        "paths": ["pkg/sub/mod.py"],
                        "steps": [
                            {
                                "name": "non-exclusive fixture",
                                "run": "echo fixture",
                            }
                        ],
                    }
                }
            }
        ),
        encoding="utf-8",
    )
    _aic_optional_init(tmp_path / "pkg", body=b"# package\n")
    _aic_optional_init(tmp_path / "pkg" / "sub", body=b"")
    jobs = PACK.load_legacy_jobs(workflow)
    assert len(jobs) == 1 and not jobs[0].exclusive

    assert PACK.ancestor_init_census(jobs, repo_root=tmp_path) == ()


def test_ancestor_init_census_dedupes_per_job_init(tmp_path: Path) -> None:
    """(h) two declared files under ``pkg/`` ⇒ one ``pkg/__init__.py`` finding.

    Dedupe keeps the lex first ``declared_path``: ``pkg/a.py`` (over ``pkg/b.py``).
    """
    workflow = _aic_manifest(
        tmp_path,
        job_id="c-h",
        paths=["pkg/b.py", "pkg/a.py", "pkg/sub/mod.py"],
    )
    _aic_optional_init(tmp_path / "pkg", body=b"# package\n")
    _aic_optional_init(tmp_path / "pkg" / "sub", body=b"")
    jobs = _aic_load(workflow)

    findings = PACK.ancestor_init_census(jobs, repo_root=tmp_path)

    by_init: dict[str, PACK.AncestorInitFinding] = {}
    for finding in findings:
        # (job, init_path) uniqueness ⇒ each init_path appears once per job.
        assert finding.init_path not in by_init, finding
        by_init[finding.init_path] = finding
    assert set(by_init) == {"pkg/__init__.py", "pkg/sub/__init__.py"}
    assert by_init["pkg/__init__.py"].declared_path == "pkg/a.py"
    assert by_init["pkg/sub/__init__.py"].declared_path == "pkg/sub/mod.py"


def test_ancestor_init_census_glob_entry_ancestors_not_walked(tmp_path: Path) -> None:
    """(j) a glob whose OWN ancestors are not covered by it emits nothing.

    ``tests/test_x_*.py`` sits under ``tests/``, and ``tests/__init__.py`` is
    neither declared literally nor matched by the glob. Only the rule that
    lexical ancestors of GLOB entries are not walked keeps this at zero
    findings — dropping the ``if _has_glob(declared): continue`` guard
    (mutant m2) walks ``test_x_*.py`` upward, finds the uncovered init, and
    turns this test RED.
    """
    workflow = _aic_manifest(tmp_path, job_id="c-j", paths=["tests/test_x_*.py"])
    _aic_optional_init(tmp_path / "tests", body=b"# tests package\n")
    jobs = _aic_load(workflow)

    assert PACK.ancestor_init_census(jobs, repo_root=tmp_path) == ()


def test_ancestor_init_census_glob_covered_init_suppresses_literal(
    tmp_path: Path,
) -> None:
    """(k) literal path + covering glob ⇒ 0 findings for both ancestors.

    ``pkg/**`` matches ``pkg/__init__.py`` and ``pkg/sub/__init__.py`` (verified
    against ``_glob_to_regex``: ``**`` crosses ``/``), so the ancestors walked
    from the literal ``pkg/sub/mod.py`` are suppressed by the glob-coverage
    check. Dropping ``if _matches_any(job.paths, init_path): continue``
    (mutant m3) emits both pairs and turns this test RED. The glob entry itself
    is still never walked — (j) pins that half.
    """
    workflow = _aic_manifest(
        tmp_path, job_id="c-k", paths=["pkg/sub/mod.py", "pkg/**"]
    )
    _aic_optional_init(tmp_path / "pkg", body=b"# package\n")
    _aic_optional_init(tmp_path / "pkg" / "sub", body=b"")
    jobs = _aic_load(workflow)

    assert PACK.ancestor_init_census(jobs, repo_root=tmp_path) == ()


def test_ancestor_init_census_findings_sorted_by_job_then_init(
    tmp_path: Path,
) -> None:
    """(l) return order is sorted by ``(job, init_path)``, not discovery order.

    Two jobs, two inits each, and the manifest lists ``z-job`` FIRST, so raw
    discovery would emit ``z-job`` findings before ``a-job`` ones. The census
    contract is the sorted tuple: reversing the return (mutant m6) puts
    ``z-job`` first and turns the exact-order assertion RED; dropping the sort
    altogether does the same.
    """
    workflow = tmp_path / "legacy.yml"
    job_block = {
        "if": PACK.DISABLED_IF,
        "runs-on": "ubuntu-latest",
        "scope": "exclusive",
        "steps": [{"name": "ancestor-init fixture", "run": "echo fixture"}],
    }
    workflow.write_text(
        yaml.safe_dump(
            {
                "jobs": {
                    "z-job": {**job_block, "paths": ["zsub/deep/mod.py"]},
                    "a-job": {**job_block, "paths": ["asub/deep/mod.py"]},
                }
            },
            sort_keys=False,
        ),
        encoding="utf-8",
    )
    _aic_optional_init(tmp_path / "zsub", body=b"# z\n")
    _aic_optional_init(tmp_path / "zsub" / "deep", body=b"")
    _aic_optional_init(tmp_path / "asub", body=b"# a\n")
    _aic_optional_init(tmp_path / "asub" / "deep", body=b"")
    jobs = PACK.load_legacy_jobs(workflow)
    assert [j.job_id for j in jobs] == ["z-job", "a-job"], "discovery order"

    findings = PACK.ancestor_init_census(jobs, repo_root=tmp_path)

    order = [(f.job, f.init_path) for f in findings]
    assert order == [
        ("a-job", "asub/__init__.py"),
        ("a-job", "asub/deep/__init__.py"),
        ("z-job", "zsub/__init__.py"),
        ("z-job", "zsub/deep/__init__.py"),
    ], order
    assert {f.declared_path for f in findings} == {
        "zsub/deep/mod.py",
        "asub/deep/mod.py",
    }


def test_ancestor_init_census_cli_flag_prints_summary_line(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    """(i) ``--ancestor-init-census`` on a tmp manifest exits 0 with summary line.

    ``GIT_CEILING_DIRECTORIES`` pins git discovery to the fixture tree, so the
    assertion holds whether pytest's ``--basetemp`` sits outside any checkout or
    inside this repository's worktree.
    """
    workflow = _aic_manifest(
        tmp_path, job_id="cli-fixture", paths=["pkg/sub/mod.py"]
    )
    _aic_optional_init(tmp_path / "pkg", body=b"# package pkg\n")
    _aic_optional_init(tmp_path / "pkg" / "sub", body=b"# sub\n")
    script = ROOT / "scripts" / "run_ci_pack.py"
    # The ceiling must name the PARENT of the fixture dir: observed with git
    # 2.43.0, ``GIT_CEILING_DIRECTORIES=<cwd itself>`` still discovered the
    # enclosing checkout (rc=0, the cwd is never excluded), while
    # ``GIT_CEILING_DIRECTORIES=<cwd's parent>`` stopped the walk-up with
    # ``fatal: not a git repository`` (rc=128). Blocked discovery makes
    # ``_find_repo_root`` fall back to ``workflow.parent`` == ``tmp_path``,
    # so the fixture census prints ``pairs=2`` under any ``--basetemp``.
    proc = subprocess.run(
        [
            sys.executable,
            str(script),
            "--workflow",
            str(workflow),
            "--ancestor-init-census",
        ],
        capture_output=True,
        text=True,
        check=False,
        cwd=str(tmp_path),
        env={**os.environ, "GIT_CEILING_DIRECTORIES": str(tmp_path.resolve().parent)},
    )
    assert proc.returncode == 0, (proc.stdout, proc.stderr)
    out_lines = proc.stdout.strip().splitlines()
    summary = out_lines[0]
    assert summary.startswith("ANCESTOR_INIT_CENSUS pairs=2 jobs=1/1 "), summary
    rest = summary[len("ANCESTOR_INIT_CENSUS "):]
    parts = dict(
        token.split("=", 1) for token in rest.split() if "=" in token
    )
    assert parts["pairs"] == "2"
    assert parts["jobs"] == "1/1"
    assert parts["nonempty_pairs"] == "2"
    assert parts["distinct_inits"] == "2"
    init_lines = out_lines[1:]
    assert len(init_lines) == 2, init_lines
    parsed = [tuple(line.split()) for line in init_lines]
    assert parsed == [
        ("pkg/__init__.py", "bytes=14", "jobs=1"),
        ("pkg/sub/__init__.py", "bytes=6", "jobs=1"),
    ], parsed


def test_ancestor_init_census_honours_gate_flag(
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """(o) the census honours ``--gate`` through the load choke point.

    ``--gate`` defaults to ``None`` (whole manifest), so the published
    census is unchanged; when present the census must filter exactly like
    every other mode does — ``load_legacy_jobs(path, gate=...)`` is the
    single choke point. A fixture with one ``code`` job (three ancestor
    inits) and one ``data`` job (two ancestor inits) prints five pairs
    whole-manifest, three under ``--gate code`` (only ``csub/`` rows), two
    under ``--gate data`` (only ``dsub/`` rows). Before the census passed
    ``args.gate`` every invocation printed the same five pairs (OBSERVED).

    ``GIT_CEILING_DIRECTORIES`` pins ``_find_repo_root`` to the fixture
    tree, same ceiling the CLI summary test documents.
    """
    workflow = tmp_path / "legacy.yml"
    job_block = {
        "if": PACK.DISABLED_IF,
        "runs-on": "ubuntu-latest",
        "scope": "exclusive",
        "steps": [{"name": "ancestor-init fixture", "run": "echo fixture"}],
    }
    workflow.write_text(
        yaml.safe_dump(
            {
                "jobs": {
                    "code-job": {
                        **job_block,
                        "gate": "code",
                        "paths": ["csub/deep/mod.py", "csub/other/mod.py"],
                    },
                    "data-job": {
                        **job_block,
                        "gate": "data",
                        "paths": ["dsub/deep/mod.py"],
                    },
                }
            },
            sort_keys=False,
        ),
        encoding="utf-8",
    )
    _aic_optional_init(tmp_path / "csub", body=b"# csub\n")
    _aic_optional_init(tmp_path / "csub" / "deep", body=b"")
    _aic_optional_init(tmp_path / "csub" / "other", body=b"")
    _aic_optional_init(tmp_path / "dsub", body=b"# dsub\n")
    _aic_optional_init(tmp_path / "dsub" / "deep", body=b"")
    monkeypatch.setenv(
        "GIT_CEILING_DIRECTORIES", str(tmp_path.resolve().parent)
    )

    def _census(gate_args: list[str]) -> str:
        args = PACK.parse_args(
            [
                "--workflow",
                str(workflow),
                "--ancestor-init-census",
                *gate_args,
            ]
        )
        assert PACK._run_ancestor_init_census(args) == 0
        return capsys.readouterr().out

    whole = _census([])
    code = _census(["--gate", "code"])
    data = _census(["--gate", "data"])

    assert whole.splitlines()[0].startswith("ANCESTOR_INIT_CENSUS pairs=5 "), whole
    assert "jobs=2/2" in whole.splitlines()[0], whole
    assert code.splitlines()[0].startswith("ANCESTOR_INIT_CENSUS pairs=3 "), code
    assert "jobs=1/1" in code.splitlines()[0], code
    assert data.splitlines()[0].startswith("ANCESTOR_INIT_CENSUS pairs=2 "), data
    assert "jobs=1/1" in data.splitlines()[0], data
    assert "csub/" in code and "dsub/" not in code, code
    assert "dsub/" in data and "csub/" not in data, data
    assert {line.split()[0] for line in code.splitlines()[1:]} == {
        "csub/__init__.py",
        "csub/deep/__init__.py",
        "csub/other/__init__.py",
    }, code
    assert whole != code and code != data and whole != data


@pytest.mark.parametrize(
    "other_flag,other_value",
    [
        pytest.param("--execute", None, id="--execute"),
        pytest.param("--validate-only", None, id="--validate-only"),
        pytest.param("--plan-only", None, id="--plan-only"),
        pytest.param("--plan-json", "/nonexistent/plan.json", id="--plan-json"),
        pytest.param("--emit-plan-json", "-", id="--emit-plan-json"),
        pytest.param("--emit-plan-json", "", id="--emit-plan-json-empty"),
        pytest.param("--emit-changed-files", "/nonexistent/x.json", id="--emit-changed-files"),
        pytest.param("--emit-changed-files", "", id="--emit-changed-files-empty"),
        pytest.param("--changed-files-file", "/nonexistent/x.json", id="--changed-files-file"),
        pytest.param("--expect-plan-sha", "0" * 40, id="--expect-plan-sha"),
        pytest.param("--emit-semantic-fragment", "x", id="--emit-semantic-fragment"),
        pytest.param("--emit-timing-observations", "x", id="--emit-timing-observations"),
        pytest.param("--github-output", "/nonexistent/out", id="--github-output"),
        pytest.param("--changed-from", "0" * 40, id="--changed-from"),
        pytest.param("--changed-from", "", id="--changed-from-empty"),
    ],
)
def test_ancestor_init_census_refuses_ambiguous_modes(
    other_flag: str, other_value: "str | None", capsys: pytest.CaptureFixture[str]
) -> None:
    """(n) the census is terminal: pairing it with another mode exits 2 at parse.

    Before this refusal ``--ancestor-init-census`` silently WON the dispatch
    in ``main`` (observed rc=0 with the paired flag ignored). ``parse_args``
    must now reject the combination the same way it rejects
    ``--execute``/``--validate-only`` — a usage error, exit code 2.

    ``--plan-json`` (``type=Path, default=None``) and ``--emit-plan-json``
    (``default=None``) are the remaining silent-win class: they are NOT
    ``store_true``, so a plain truthiness loop misses them and the valueless
    tokens cannot be passed bare — the pair is (flag, value) and the refusal
    keys on ``is not None``. Seven more ``default=None`` flags join that class.
    The empty-value pins kill a truthiness mutant (``""`` is falsy); an empty
    ``--plan-json``/``--github-output`` could not — both are ``type=Path``.

    rc 2 alone does not say WHICH refusal fired — any later ``parser.error``
    would do. The exact message is part of the contract (a renamed string is
    a silent UX break), so stderr is captured (``capsys``, as the rest of
    this suite uses) and asserted as well.
    """
    argv = ["--workflow", str(MANIFEST), "--ancestor-init-census", other_flag]
    if other_value is not None:
        argv.append(other_value)
    with pytest.raises(SystemExit) as excinfo:
        PACK.parse_args(argv)
    assert excinfo.value.code == 2
    captured = capsys.readouterr()
    assert (
        "--ancestor-init-census is a terminal report-only mode" in captured.err
    ), captured.err


# ---------------------------------------------------------------------------
# W15-F-FVE lane — RATCHET on the ancestor-init blind spot (ceiling, not fix).
#
# #9315 shipped the report-only census; the lane that measured it found the
# blind spot on main at seed 9b4bd85aa4f0a5c56bb0f025954aa743a2fe8c68: 340
# ``(job, ancestor __init__.py)`` rows across 106 of 112 curated-exclusive
# jobs, 136 of those rows (42 jobs) pointing at a SUBSTANTIVE init — one
# whose module body has a statement beyond a leading docstring and
# ``from __future__`` imports, i.e. code CPython actually executes on every
# import under that package while no job's ``paths:`` selects it. Fixing the
# closure is deferred (full ancestor expansion breaches the packing-probe
# ceilings), so these constants make the blind spot NON-GROWABLE meanwhile:
# a new exclusive declaration whose tracked ancestor ``__init__.py`` stays
# undeclared pushes the measured rows over the ceiling and REDs here. The
# comparison is ``<=`` on purpose — shrinking the blind spot stays green.
#
# Determinism: ``ancestor_init_census`` resolves existence with ``stat()``
# on the WORKING TREE (scripts/run_ci_pack.py:1822-1830), and a job checkout
# may be partial, so the ceiling counts are computed from the TRACKED
# inventory (``git ls-tree -r --name-only HEAD``) through the census module's
# own lexical mapping helpers (``_ancestor_init_paths``/``_has_glob``/
# ``_matches_any``/``ANCESTOR_INIT_ALLOWLIST``) — never from what happens to
# be materialised. The shipped function is still called and pinned as the
# cross-check: its rows must be a subset of the tracked mapping on any tree
# (an init can be tracked-but-absent from a sparse checkout; a clean checkout
# has no untracked package inits to invent extra rows).
# ---------------------------------------------------------------------------

# Lane W15-F-FVE measured 340 / 136 at seed 9b4bd85 (its sparse checkout's
# census printed the identical 340 because it excludes only data/, site/,
# mockups/, verify_shots/). Main moved before this landed, so the seat
# re-measured with the same tracked-inventory walk at main 3a316a30
# (2026-10-14) and the ceilings pin THAT measurement:
#   total rows       = 344 across 107/113 exclusive jobs
#   substantive rows = 138 across 43/113 exclusive jobs
_ANCESTOR_INIT_CENSUS_CEILING = 344
_ANCESTOR_INIT_SUBSTANTIVE_CEILING = 138

_ANCESTOR_INIT_CENSUS_CLI = (
    "python3 scripts/run_ci_pack.py --workflow .github/ci/legacy-jobs.yml "
    "--ancestor-init-census"
)


def _aic_tracked_paths(root: Path = ROOT) -> frozenset[str]:
    """Paths tracked at HEAD — stable under any sparse/partial checkout.

    The owning job ``ci-control-plane-contracts`` runs a bare
    ``actions/checkout@v4`` (.github/ci/legacy-jobs.yml:8142) with no
    ``sparse-checkout`` or ``filter`` option, so HEAD's tree and blobs are
    fetched whole and these git reads need no network in CI either.
    ``-z`` is used because it gives NUL-terminated, unquoted names
    regardless of ``core.quotePath``: with plain ``--name-only`` a
    non-ASCII or control-character path is emitted octal-escaped inside
    double quotes, so such an init would silently drop out of the
    inventory and the ratchet would fail open.
    """
    result = subprocess.run(
        ["git", "ls-tree", "-r", "-z", "--name-only", "HEAD"],
        cwd=root,
        capture_output=True,
        text=True,
        check=True,
    )
    return frozenset(p for p in result.stdout.split("\0") if p)


def test_aic_tracked_paths_keeps_non_ascii_paths(tmp_path: Path) -> None:
    """A non-ASCII or control-character tracked path survives ``core.quotePath`` escaping.

    Git's default ``core.quotePath=true`` makes a plain
    ``ls-tree -r --name-only`` print such paths octal-escaped inside
    double quotes (non-ASCII bytes become ``\\NNN`` octal sequences; a
    TAB becomes the C-style ``\\t``); the
    escaped line then never equals the real init row, so the census
    inventory would silently lose it (fail open). The quoting is pinned
    repo-locally so this test discriminates on every host regardless of
    any global git config.
    """
    target = tmp_path / "pkg" / "na\u00efve"
    target.mkdir(parents=True)
    (target / "__init__.py").write_text("", encoding="utf-8")
    tab_target = tmp_path / "tab\there"
    tab_target.mkdir(parents=True)
    (tab_target / "y.py").write_text("", encoding="utf-8")

    def git(*args: str) -> None:
        subprocess.run(
            # -c core.hooksPath= isolates the scratch repo from any
            # global hook configuration; a hostile global hook that
            # exit(1)s on commit would otherwise fail this test
            # without involving _aic_tracked_paths.
            ["git", "-c", "core.hooksPath=", *args],
            cwd=tmp_path,
            capture_output=True,
            text=True,
            check=True,
        )

    git("init", "-q")
    git("add", "pkg/na\u00efve/__init__.py", "tab\there/y.py")
    git("config", "core.quotePath", "true")
    git(
        "-c", "user.name=t",
        "-c", "user.email=t@example.invalid",
        "-c", "commit.gpgsign=false",
        "commit", "-qm", "x",
    )
    tracked = _aic_tracked_paths(tmp_path)
    assert "pkg/na\u00efve/__init__.py" in tracked
    assert "tab\there/y.py" in tracked

    # Pin the precondition the test discriminates on: a plain (non -z)
    # ls-tree with the repo-local `core.quotePath true` setting must
    # emit the escaped, double-quoted form, never the raw path;
    # otherwise the test would silently stop discriminating.
    plain = subprocess.run(
        ["git", "-c", "core.hooksPath=", "ls-tree", "-r", "--name-only", "HEAD"],
        cwd=tmp_path,
        capture_output=True,
        text=True,
        check=True,
    )
    plain_lines = plain.stdout.splitlines()
    assert '"pkg/na\\303\\257ve/__init__.py"' in plain_lines
    assert '"tab\\there/y.py"' in plain_lines
    assert "pkg/na\u00efve/__init__.py" not in plain_lines


def _aic_rows_from_tracked_inventory(
    jobs: list[PACK.LegacyJob], tracked_paths: frozenset[str]
) -> list[tuple[str, str, str]]:
    """``ancestor_init_census``'s declared-path -> ancestor-init mapping,
    with existence resolved from the tracked inventory instead of the working
    tree. Same walk, same three suppressions (literal declaration, glob match,
    allowlist), same per-``(job, init)`` dedupe keeping the lexicographically
    first declared path (scripts/run_ci_pack.py:1806-1838) — built from the
    module's own helpers so the mapping cannot drift from the shipped census.
    """
    rows: dict[tuple[str, str], tuple[str, str, str]] = {}
    for job in jobs:
        if not job.exclusive:
            continue
        declared_set = frozenset(job.paths)
        for declared in job.paths:
            if PACK._has_glob(declared):
                continue
            for rel_dir in PACK._ancestor_init_paths(declared):
                init_path = f"{rel_dir}/__init__.py"
                if init_path in declared_set:
                    continue
                if PACK._matches_any(job.paths, init_path):
                    continue
                if init_path in PACK.ANCESTOR_INIT_ALLOWLIST:
                    continue
                if init_path not in tracked_paths:
                    continue
                key = (job.job_id, init_path)
                if key not in rows or declared < rows[key][1]:
                    rows[key] = (job.job_id, declared, init_path)
    return sorted(rows.values(), key=lambda row: (row[0], row[2]))


def _aic_init_is_substantive(source: str) -> bool:
    """True if the module body holds any statement beyond a leading
    docstring and ``from __future__`` imports — the W15-F-FVE definition that
    measured 136 substantive rows at 9b4bd85 and 138 at 3a316a30. Such an
    init runs real code on every import of its package, which is exactly
    what an undeclared path hides. Unparseable source counts as substantive:
    the ratchet fails closed.
    """
    try:
        body = list(ast.parse(source).body)
    except SyntaxError:
        return True
    if (
        body
        and isinstance(body[0], ast.Expr)
        and isinstance(body[0].value, ast.Constant)
        and isinstance(body[0].value.value, str)
    ):
        body = body[1:]
    for stmt in body:
        if isinstance(stmt, ast.ImportFrom) and stmt.module == "__future__":
            continue
        return True
    return False


def _aic_ceiling_failure(
    kind: str, measured: int, ceiling: int, rows: list[tuple[str, str, str]]
) -> str:
    over_jobs = sorted({job for job, _declared, _init in rows})
    return (
        f"ancestor-init blind spot GREW: {kind} rows measured {measured} "
        f"against ceiling {ceiling} (main 3a316a30) — "
        f"{measured - ceiling} over. Remedy: declare the ancestor "
        "`__init__.py` in that job's `paths:` so the change that executes it "
        "selects the job. List every row with "
        f"`{_ANCESTOR_INIT_CENSUS_CLI}`; jobs currently covered: "
        f"{len(over_jobs)} ({', '.join(over_jobs[:8])} ...)"
    )


def test_ancestor_init_census_does_not_grow() -> None:
    """Ratchet: the undeclared-ancestor-init blind spot may not grow.

    Closes the 2026-10-14 measurement at main 3a316a30 (344 rows / 107
    jobs, 138 substantive / 43 jobs) behind two ``<=`` ceilings. Counts
    come from HEAD's tracked inventory, so the verdict is identical in a
    full CI checkout and in a sparse session tree.
    """
    # The CLI's own two calls (_run_ancestor_init_census,
    # scripts/run_ci_pack.py:4800 and :4802; ``gate`` defaults to None,
    # i.e. the whole manifest, which is what this call loads):
    #   jobs = load_legacy_jobs(args.workflow, gate=args.gate)
    #   findings = ancestor_init_census(jobs, repo_root=repo_root)
    jobs = PACK.load_legacy_jobs(MANIFEST)
    tracked_paths = _aic_tracked_paths()
    rows = _aic_rows_from_tracked_inventory(jobs, tracked_paths)

    # Cross-check against the shipped census function itself: every row it
    # emits from the working tree must exist in the tracked mapping too.
    census = PACK.ancestor_init_census(jobs, repo_root=ROOT)
    tracked_keys = {(job, init) for job, _declared, init in rows}
    census_keys = {(f.job, f.init_path) for f in census}
    assert census_keys, (
        "ancestor_init_census returned no rows — the cross-check "
        "would be vacuous"
    )
    assert census_keys <= tracked_keys, (
        "ancestor_init_census emitted working-tree rows absent from the "
        f"tracked mapping: {sorted(census_keys - tracked_keys)}"
    )

    substantive_cache: dict[str, bool] = {}

    def _substantive(init_path: str) -> bool:
        if init_path not in substantive_cache:
            blob = subprocess.run(
                ["git", "show", f"HEAD:{init_path}"],
                cwd=ROOT,
                capture_output=True,
                text=True,
                check=True,
            ).stdout
            substantive_cache[init_path] = _aic_init_is_substantive(blob)
        return substantive_cache[init_path]

    substantive_rows = [row for row in rows if _substantive(row[2])]

    assert len(rows) <= _ANCESTOR_INIT_CENSUS_CEILING, _aic_ceiling_failure(
        "total", len(rows), _ANCESTOR_INIT_CENSUS_CEILING, rows
    )
    assert len(substantive_rows) <= _ANCESTOR_INIT_SUBSTANTIVE_CEILING, (
        _aic_ceiling_failure(
            "substantive",
            len(substantive_rows),
            _ANCESTOR_INIT_SUBSTANTIVE_CEILING,
            substantive_rows,
        )
    )
