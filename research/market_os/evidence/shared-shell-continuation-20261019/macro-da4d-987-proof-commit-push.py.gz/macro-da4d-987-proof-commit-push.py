from pathlib import Path
import subprocess,json,hashlib,datetime
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","-C",str(W)]
H="6d56650ea21395e7ffb0412bde73881b58dd1a66";B="sol/market-os-shared-shell-design-20260924";R="b312bc4c08cf7633bf8fd259d2d46ec545fa120f";P="research/market_os/evidence/shared-shell-continuation-20261019";HP="agentos/handoffs/MARKET-OS-SHARED-SHELL-2026-09-24.md";WP="agentos/workstreams/WS-MARKET-OS.md"
OUT=E/"macro-da4d-987-proof-commit-push.json";assert not OUT.exists()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def dg(raw):return hashlib.sha256(raw).hexdigest()
def git(*a):return subprocess.check_output(G+list(a)).decode().strip()
imp=E/"macro-da4d-987-proof-import.json";r=json.loads(imp.read_text())
assert r["status"]=="PROOF_READY_NOT_COMMITTED_OR_PUSHED" and r["all_checks_pass"] and r["all_hashes_and_coverage_pass"]
assert git("branch","--show-current")==B and git("rev-parse","HEAD")==H and git("write-tree")==r["final_index"]
assert not git("diff","--name-only") and not git("ls-files","-u")
assert subprocess.run(G+["rev-parse","--verify","MERGE_HEAD"],capture_output=True).returncode!=0
assert git("ls-remote","origin","refs/heads/"+B).split()[0]==R
docs=git("diff","--cached","--name-only").splitlines();assert len(docs)==r["documentation_only_paths"] and all(p in [HP,WP] or p.startswith(P+"/") for p in docs)
assert dg((W/P/"MANIFEST.json").read_bytes())==r["manifest_sha256"]
assert not git("diff","--cached","--check",r["incoming"])
out={"started_at":now(),"state":"COMMIT_INTENT","head_before":H,"remote_before":R,"branch":B,"index":r["final_index"],"proof_import_receipt":{"bytes":imp.stat().st_size,"sha256":dg(imp.read_bytes())},"manifest_sha256":r["manifest_sha256"],"indexed_files":r["indexed_files"],"documentation_only_paths":len(docs),"candidate_paths_vs_incoming":r["candidate_paths_vs_incoming"],"pushed":False}
def save():OUT.write_text(json.dumps(out,indent=2)+"\n")
save()
msg=E/"macro-da4d-987-proof-commit-message.txt";msg.write_text("docs(market-os): preserve composed proof and beta recovery receipts\n\nPreserve the previous 509-file history and add actual composed source,\n996 passing tests, P0B and About browser receipts, and the failed strict\nservice proof with its separately verified same-A recovery.\n\nKeep public acceptance, hosted admission and publication gates open.\n")
log=E/"macro-da4d-987-proof-commit.log"
with log.open("xb") as f:cp=subprocess.run(G+["commit","-F",str(msg)],stdout=f,stderr=subprocess.STDOUT)
out.update(commit_exit=cp.returncode,commit_log_sha256=dg(log.read_bytes()),commit_log_bytes=log.stat().st_size,head_after=git("rev-parse","HEAD"),commit_finished_at=now());save()
assert cp.returncode==0 and out["head_after"]!=H
N=out["head_after"];assert git("rev-parse",N+"^")==H and git("rev-parse",N+"^{tree}")==r["final_index"] and not git("status","--porcelain","--untracked-files=no")
out["state"]="COMMITTED_LOCAL_ONLY";save()
assert git("ls-remote","origin","refs/heads/"+B).split()[0]==R
out.update(state="PUSH_INTENT",push_intent_at=now(),push_command=G+["push","origin","HEAD:refs/heads/"+B]);save()
plog=E/"macro-da4d-987-proof-push.log"
with plog.open("xb") as f:pp=subprocess.run(out["push_command"],stdout=f,stderr=subprocess.STDOUT)
out.update(push_exit=pp.returncode,push_log_sha256=dg(plog.read_bytes()),push_log_bytes=plog.stat().st_size,push_finished_at=now());save()
remote=git("ls-remote","origin","refs/heads/"+B).split()[0];out["remote_after"]=remote;out["clean"]=not git("status","--porcelain","--untracked-files=no")
assert pp.returncode==0 and remote==N and out["clean"] and git("rev-parse","HEAD")==N
out.update(state="ORIGINAL_BRANCH_COMMITTED_AND_PUSHED",pushed=True,finished_at=now());save();print(json.dumps(out,indent=2))
