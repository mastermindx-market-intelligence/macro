from pathlib import Path
import json,hashlib,datetime
E=Path("/tmp/shared-shell-css-visual-20261019T1107")
raw=(E/"macro-da4d-host-observation.stdout.json").read_bytes();x=json.loads(raw);old=json.loads((E/"macro-3b49-beta-health-20261020T1443.stdout.json").read_text())
A="e45bde2cac07ac3b29285ff70c40d68900fad62c"
def good(c):assert c["exit"]==0 and not c.get("truncated") and not c.get("timed_out");return c["stdout"]
def healthy(c):
 v=dict(line.split("=",1) for line in good(c).splitlines())
 assert v["ActiveState"]=="active" and v["SubState"]=="running" and v["UnitFileState"]=="enabled" and int(v["MainPID"])>0
 return v
beta=healthy(x["services"]["terminal-beta.service"]);assert beta==healthy(x["beta_after"])
prod=healthy(x["services"]["terminal.service"]);assert prod==healthy(x["production_after"]["service"])
assert good(x["beta_source_HEAD"]).strip()==A
for key,sha in (("runtime_pointer","698204ef4ad72a1bfa896110af875df080bf773687150890e8a2322bd6b452d7"),("source_pointer","9aac8ec8c132eecf4d2664d8f1e18e8a6bffce5f6d7176e4021b15d6d953cfa4")):
 assert x[key]["sha256"]==sha and x[key]["read_complete"] and x[key]["ancestor_trusted"] and x[key]["pointer_stable"]
for newrows,oldrows in ((x["beta_build"],old["beta_build"]),(x["production_build"],x["production_after"]["build"])):
 assert [(r["sha256"],r["text"]) for r in newrows]==[(r["sha256"],r["text"]) for r in oldrows]
 assert all(r["read_complete"] for r in newrows)
assert x["production_owner"]["sha256"]==x["production_after"]["owner"]["sha256"]=="c6759cc653e0f19102a015ec52842795bde24eb85766d2e73f3024b4eefe409d"
assert x["production_owner"]["read_complete"] and x["production_after"]["owner"]["read_complete"]
assert x["caddy"]["sha256"]==x["caddy_after"]["sha256"]==old["caddy"]["sha256"] and x["caddy"]["read_complete"] and x["caddy_after"]["read_complete"]
s=x["status"];assert s["status"]==200 and not s["truncated"] and s["proxy_disabled"] and s["redirects_disabled"]
assert s["body"]=={"enabled":True,"protocol":"mmx.shared-shell.v1","buildId":A,"bridgeVersion":"20261018.1","documentVersion":"20261018.1","registrySha256":"5307ea5a7964fde609a8f20f1af30b6bf483b7631f7232e5db74f9ef1d710023"}
assert not x["pending_exists"] and not x["beta_stages"]["entries"] and not x["beta_stages"]["truncated"]
for k in ("release_before","release_after"):
 r=x[k];assert r["sample_clear"] and not r["reservation"] and not r["lock"]["archives"]
assert good(x["macro"]["head_before"])==good(x["macro"]["head_after"])
out={"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"observer_interval":[x["observed_at"],x["finished_at"]],"raw_sha256":hashlib.sha256(raw).hexdigest(),"beta_service":beta,"production_service":prod,"production_matches_1442_baseline":prod==healthy(old["services"]["terminal.service"]),"accepted_A":A,"accepted_runtime_and_source_pointers_match":True,"beta_markers_match_1442":True,"production_build_and_owner_stable_within_sample":True,"loaded_caddy_file_stable_within_sample":True,"local_status_tuple":s["body"],"owner_and_hold_samples_clear":True,"sample_is_reservation":False,"no_pending_or_stages":True,"free_bytes":x["free_bytes"],"macro_head":good(x["macro"]["head_before"]).strip(),"macro_files":[{k:r.get(k) for k in ("path","exists","bytes","sha256","read_complete","error","errno")} for r in x["macro"]["files"]],"limits":"Read-only time-bounded sample, not loaded-Caddy runtime proof, MOG arm, publication, public DNS/TLS/auth/browser or withdrawal/recovery acceptance. Refresh before a later action boundary; no installer or production mutation."}
p=E/"macro-da4d-host-reconciliation.json";assert not p.exists();p.write_text(json.dumps(out,indent=2)+"\n");print(json.dumps(out,indent=2),flush=True)
