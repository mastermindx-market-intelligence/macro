from pathlib import Path
import subprocess,json,hashlib,datetime,sys,os
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27")
E=Path("/tmp/shared-shell-css-visual-20261019T1107")
G=["git","-C",str(W)]
H="8b51fb46d18739a4d10d1ef07dce3ca0f989f0da"
P=["lib/macro_suite_labels.py","site/macro_labor_markets.html","tests/test_macro_command_copy_law.py"]
OUT=E/"labor-copy-green.json"
assert not OUT.exists(),"Do not overwrite an actual result"
def git(*a): return subprocess.check_output(G+list(a))
def dg(b): return hashlib.sha256(b).hexdigest()
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def snap():
 return {"head":git("rev-parse","HEAD").decode().strip(),"status":git("status","--porcelain=v1").decode(),"diff_sha256":dg(git("diff","--binary","HEAD")),"index_tree":git("write-tree").decode().strip(),"files":{p:{"bytes":(W/p).stat().st_size,"sha256":dg((W/p).read_bytes())} for p in P}}
before=snap()
assert before["head"]==H
assert sorted(git("diff","--name-only","HEAD").decode().splitlines())==sorted(P)
assert git("diff","--cached","--name-only").strip()==b""
subprocess.run(G+["diff","--check"],check=True)
PY=str(W/".venv-shared-shell/bin/python")
groups=[
 ("rates",["tests/test_macro_rates_curves_route.py"]),
 ("suite",["tests/test_macro_suite_pages.py","tests/test_macro_workspace_prior_publication.py","tests/test_macro_command_shell.py","tests/test_macro_command_copy_law.py","tests/test_macro_command_read_strip.py","tests/test_macro_command_panels.py","tests/test_macro_command_empty_states.py","tests/test_macro_command_p4_copy.py","tests/test_macro_command_capture_guards.py"]),
 ("hub",["tests/test_macro_monetary_hub.py"]),
 ("packing",["tests/test_ci_pack.py::test_the_curated_exclusive_set_is_actually_declared","tests/test_ci_pack.py::test_curated_exclusive_scopes_cover_their_own_import_closure","tests/test_ci_pack.py::test_curated_exclusivity_drops_only_the_opaque_fallback_tier","tests/test_ci_pack.py::test_exclusive_curation_narrows_ordinary_code_prs"])
]
out={"started_at":now(),"source":"committed About candidate plus exact three recorded labor repair working changes","before":before,"python":subprocess.check_output([PY,"--version"],text=True).strip(),"groups":[]}
def save():OUT.write_text(json.dumps(out,indent=2,ensure_ascii=False)+"\n")
save()
for name,nodes in groups:
 cmd=[PY,"-B","-m","pytest","-q",*nodes]
 log=E/("labor-copy-green-"+name+".log")
 assert not log.exists()
 row={"name":name,"command":cmd,"started_at":now()}
 print(json.dumps({"group":name,"started_at":row["started_at"]}),flush=True)
 with log.open("wb") as f:
  p=subprocess.run(cmd,cwd=W,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,"PYTHONDONTWRITEBYTECODE":"1"})
 raw=log.read_bytes()
 row.update(exit=p.returncode,finished_at=now(),log_bytes=len(raw),log_sha256=dg(raw),tail=raw.decode(errors="replace").splitlines()[-12:])
 out["groups"].append(row);save();print(json.dumps(row,ensure_ascii=False),flush=True)
out["after"]=snap()
out["source_unchanged"]=out["after"]==before
out["passed"]=out["source_unchanged"] and all(r["exit"]==0 for r in out["groups"])
out["finished_at"]=now();save()
print(json.dumps({"passed":out["passed"],"source_unchanged":out["source_unchanged"],"finished_at":out["finished_at"]}),flush=True)
sys.exit(0 if out["passed"] else 1)
