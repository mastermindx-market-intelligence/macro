from pathlib import Path
import json,gzip,hashlib,subprocess,datetime
E=Path("/tmp/shared-shell-css-visual-20261019T1107");W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");P=W/"research/market_os/evidence/shared-shell-continuation-20261019"
mf=json.loads((P/"MANIFEST.json").read_text());rows={x["file"]:x for x in mf["files"]};prefixes=("macro-140bd-","macro-3b49-","macro-b312-","macro-da4d-","macro-ae3-5c2d-complete-merge","macro-full-checkpoint-","about-footer-","labor-copy-","beta-loaded-unit-root-","beta-same-a-")
exclude={E/"macro-da4d-987-proof-import.json",E/"macro-da4d-987-proof-validation.json",E/"macro-da4d-987-final-changed-paths.txt"}
sources=[]
for p in sorted(E.iterdir()):
 if p.is_file() and p not in exclude and p.name.startswith(prefixes):sources.append((p,p.name))
 elif p.is_dir() and p.name.startswith(("macro-da4d-987-","about-footer-","labor-copy-")):
  for f in sorted(p.rglob("*")):
   if f.is_file():sources.append((f,p.name+"--"+str(f.relative_to(p)).replace("/","--")))
targets={};collisions=[];added=[]
for p,name in sources:
 assert not p.is_symlink(),str(p)
 raw=p.read_bytes();gz=p.suffix!=".json" or len(raw)>65536 or raw.endswith(b"\n\n");target=name+(".gz" if gz else "");sha=hashlib.sha256(raw).hexdigest()
 assert target not in targets,(target,str(p))
 targets[target]={"source":str(p),"original_bytes":len(raw),"sha256":sha}
 if target in rows:
  row=rows[target];assert row.get("original_sha256",row["sha256"])==sha,target;collisions.append(target)
 else:added.append(target)
for f in ["macro-da4d-987-proof-import.py","beta-same-a-recovery.py"]:compile((E/f).read_text(),str(E/f),"exec")
cfg=json.loads((E/"macro-da4d-987-proof-config.json").read_text());refs=[]
for k,v in cfg["manifest_update"].items():
 if isinstance(v,dict):
  for kk,vv in v.items():
   if kk in ["receipt","binding","history_preparation","actual","health","reconciliation","recovery","original"] and isinstance(vv,str) and vv.endswith(".json"):refs.append(vv)
resolved={}
for r in refs:
 if r in targets or r in rows:resolved[r]=r
 elif r+".gz" in targets or r+".gz" in rows:resolved[r]=r+".gz"
 else:raise AssertionError(("missing_reference",r))
G=["git","-C",str(W)]
def git(*a):return subprocess.check_output(G+list(a)).decode().strip()
assert git("rev-parse","HEAD")=="6d56650ea21395e7ffb0412bde73881b58dd1a66" and not git("status","--porcelain","--untracked-files=no")
remote=git("ls-remote","origin","refs/heads/sol/market-os-shared-shell-design-20260924","refs/heads/main")
out={"observed_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"old_indexed_files":len(rows),"candidate_sources":len(sources),"identical_old_collisions":len(collisions),"new_files_before_validation":len(added),"raw_bytes":sum(x["original_bytes"] for x in targets.values()),"reference_map":resolved,"remote":remote,"head":git("rev-parse","HEAD"),"clean":True,"scope":"Read-only inventory before original proof import; no pack mutation or publication"}
(E/"macro-da4d-987-proof-inventory-preflight.json").write_text(json.dumps(out,indent=2)+"\n");print(json.dumps(out,indent=2))
