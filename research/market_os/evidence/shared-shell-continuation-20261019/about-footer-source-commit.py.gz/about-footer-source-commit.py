#!/usr/bin/env python3
from pathlib import Path
import subprocess,json,hashlib,datetime
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27")
E=Path("/tmp/shared-shell-css-visual-20261019T1107")
H="b312bc4c08cf7633bf8fd259d2d46ec545fa120f"
paths=["templates/landing.css","site/landing.css","templates/about.html","site/about.html","templates/index.html","site/index.html","site/products/market-terminal.html","site/products/market-dashboards.html","site/products/mastermind-ai.html"]
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args):return subprocess.check_output(["git",*args],cwd=W,text=True)
assert git("rev-parse","HEAD").strip()==H
assert git("diff","--cached","--name-only")==""
assert set(git("diff","--name-only").splitlines())==set(paths)
assert hashlib.sha256((E/"about-footer-source-final.patch").read_bytes()).hexdigest()=="b3707d47f574542aab72c1e7abc00b2bd89211b5882816754f37448d65686142"
r={"started_at":now(),"base_head":H,"source_review":"sector_rig_counsel NONBLOCKING exact final 115-line patch; browser verification remains pending","checks":[]}
log=E/"about-footer-source-commit.log"
def run(args):
 p=subprocess.run(args,cwd=W,capture_output=True,text=True)
 with log.open("a") as f:f.write(p.stdout+p.stderr)
 row={"command":args,"exit":p.returncode,"stdout":p.stdout,"stderr":p.stderr};r["checks"].append(row)
 (E/"about-footer-source-commit.json").write_text(json.dumps(r,indent=2)+"\n")
 assert p.returncode==0,row
 return p
run(["git","add","--",*paths]);r["source_tree"]=git("write-tree").strip()
assert set(git("diff","--cached","--name-only").splitlines())==set(paths)
run([str(W/".venv-shared-shell/bin/python"),"-B","-m","scripts.check_template_site_sync"])
run(["git","diff","--cached","--check"])
assert git("write-tree").strip()==r["source_tree"]
msg=E/"about-footer-source-message.txt";msg.write_text("fix(market-os): wrap the landing footer on narrow screens\n\nKeep the existing footer columns within the mobile viewport and refresh the\nlanding stylesheet stamp through the incumbent asset owner. Preserve the\nlight-only canvas, existing content, route admission and desktop layout.\n")
run(["git","commit","-F",str(msg)])
r["source_head"]=git("rev-parse","HEAD").strip();r["parents"]=git("show","-s","--format=%P","HEAD").strip().split()
assert r["parents"]==[H]
assert git("rev-parse","HEAD^{tree}").strip()==r["source_tree"]
assert git("status","--porcelain=v1")==""
r["finished_at"]=now();r["local_only"]=True;r["browser_acceptance"]="PENDING"
(E/"about-footer-source-commit.json").write_text(json.dumps(r,indent=2)+"\n")
print(json.dumps({k:r[k] for k in ["source_head","source_tree","parents","local_only","browser_acceptance","finished_at"]},indent=2))
