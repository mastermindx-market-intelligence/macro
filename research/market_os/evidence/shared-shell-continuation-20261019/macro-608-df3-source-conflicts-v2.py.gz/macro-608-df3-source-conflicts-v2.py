from pathlib import Path
import subprocess,json,hashlib,datetime,re,copy,yaml,ast
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","-C",str(W)]
B="9875169102cc6f36a64d465fe7c06f6bb8fb0220";H="608dfad299e2e48ab7703bf0b180e0dca1318229";M="df3cba80e5ff43e3411209381b32d9d4df06bd1f";OUT=E/"macro-608-df3-source-conflict-resolution.json";BACK=E/"macro-608-df3-source-conflicts-before"
def git(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
assert not OUT.exists() and not BACK.exists()
assert git("rev-parse","HEAD").decode().strip()==H and git("rev-parse","MERGE_HEAD").decode().strip()==M
pat=re.compile(r"^<<<<<<< HEAD\n(.*?)^=======\n(.*?)^>>>>>>> "+M+r"\n",re.M|re.S)
paths=[".github/ci/legacy-jobs.yml","tests/test_ci_pack.py","app/deploy/update.sh"];candidates={};checks={}
parents={p:{r:git("show",r+":"+p).decode() for r in [B,H,M]} for p in paths}
p=paths[0];raw=(W/p).read_text();matches=list(pat.finditer(raw));assert len(matches)==7
for m in matches:
 assert m.group(1)=='      - "lib/shared_shell.py"\n      - "lib/site_assets.py"\n'
 assert all(x.startswith("      - ") for x in m.group(2).splitlines())
candidates[p]=pat.sub(lambda m:m.group(1)+m.group(2),raw)
b,h,m=(yaml.safe_load(parents[p][rev]) for rev in [B,H,M]);c=yaml.safe_load(candidates[p]);assert set(c)==set(b)==set(h)==set(m)
assert set(c["jobs"])==set(h["jobs"])|set(m["jobs"])
both=[]
for job,v in c["jobs"].items():
 if job not in b["jobs"]:
  expected=h["jobs"].get(job,m["jobs"].get(job));assert v==expected,job;continue
 bv=b["jobs"][job];hv=h["jobs"][job];mv=m["jobs"][job]
 for key in set(bv)|set(hv)|set(mv):
  x=bv.get(key);y=hv.get(key);z=mv.get(key);actual=v.get(key)
  if y==x:assert actual==z,(job,key,"incoming")
  elif z==x:assert actual==y,(job,key,"head")
  elif y==z:assert actual==y,(job,key,"identical")
  elif key=="paths":
   assert set(x or [])<=set(y or []) and set(x or [])<=set(z or []) and set(actual)==set(y)|set(z),(job,key)
   assert all(actual.count(q)<=max((y or []).count(q),(z or []).count(q)) for q in set(actual)),(job,key,"novel duplicate")
   both.append(job)
  else:raise AssertionError((job,key,"concurrent non-path change"))
checks["manifest"]={"jobs":len(c["jobs"]),"concurrent_path_unions":both,"all_parent_fields_preserved":True,"inherited_path_multiplicities_not_expanded":True}
p=paths[1];raw=(W/p).read_text();matches=list(pat.finditer(raw));assert len(matches)==1
a=matches[0].group(1).splitlines(True);z=matches[0].group(2).splitlines(True);assert len(a)==len(z)==2 and '136, 5_829' in a[0] and '135, 5_795' in z[1]
candidates[p]=pat.sub(lambda _:a[0]+z[1],raw);compile(candidates[p],p,"exec")
checks["test"]={"resolution":"Retain H template5829 and incoming free-content135/5795 pending actual joint measurement; other bounds unchanged","provisional_packing_probes":[["templates/index.html",136,5829],["scripts/build_free_content.py",135,5795],["engine/prophet/plan_book.py",130,5600]]}
p=paths[2];raw=(W/p).read_text();matches=list(pat.finditer(raw));assert len(matches)==1
a=matches[0].group(1);z=matches[0].group(2);base=next(s+"\n" for s in parents[p][B].splitlines() if s.startswith('if [ "$API_UNIT_UPDATED" -eq 1 ] || ! mm_api_fence_marker_ready'))
old="|lib/(config|ai_costs";new="|lib/(config|shared_shell|ai_costs";before=r"|engine/qbus_news_.*\.py|engine/qkernel";after=r"|engine/qbus_news_.*\.py|engine/news_common\.py|engine/qkernel"
assert base.count(old)==1 and base.count(before)==1 and a==base.replace(old,new,1) and z==base.replace(before,after,1)
joined=z.replace(old,new,1);assert joined==a.replace(before,after,1);candidates[p]=pat.sub(lambda _:joined,raw)
checks["updater"]={"both_exact_additions_preserved":["lib/shared_shell.py","engine/news_common.py"],"ordinary_other_changes_retained":True}
for p,s in candidates.items():assert not re.search(r"^(<<<<<<<|=======|>>>>>>>)",s,re.M),p
before_index=git("ls-files","--stage","-z");BACK.mkdir()
out={"started_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"head":H,"base":B,"incoming":M,"state":"RESOLUTION_PREFLIGHT_PASS","checks":checks,"rows":[]}
def save():OUT.write_text(json.dumps(out,indent=2)+"\n")
for p,s in candidates.items():
 raw=(W/p).read_bytes();bp=BACK/p.replace("/","_");bp.write_bytes(raw);out["rows"].append({"path":p,"before_sha256":dg(raw),"candidate_sha256":dg(s.encode()),"backup":str(bp)})
save()
for p,s in candidates.items():(W/p).write_text(s)
assert git("ls-files","--stage","-z")==before_index
bash=subprocess.run(["bash","-n",str(W/"app/deploy/update.sh")],capture_output=True);out["updater_bash_syntax"]={"exit":bash.returncode,"stderr":bash.stderr.decode()};assert bash.returncode==0
subprocess.run(G+["add","--",*paths],check=True)
for p,s in candidates.items():assert git("show",":"+p)==s.encode()
out.update(state="THREE_SOURCE_CONFLICTS_RESOLVED_STAGED_MEASUREMENT_PENDING",finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),remaining_unmerged=git("diff","--name-only","--diff-filter=U").decode().splitlines());save();print(json.dumps(out,indent=2))
