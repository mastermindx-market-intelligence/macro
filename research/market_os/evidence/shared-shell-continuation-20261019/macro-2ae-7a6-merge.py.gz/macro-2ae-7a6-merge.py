from pathlib import Path
import json,subprocess,hashlib,datetime,os
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","-C",str(W)]
H="2ae6498d0b9f2a088af2e827abf6527799757f8c";M="7a6e21cb7d6a38855b7e06432c94f61acb0fe6f1";B="df3cba80e5ff43e3411209381b32d9d4df06bd1f";branch="sol/market-os-shared-shell-design-20260924";OUT=E/"macro-2ae-7a6-merge.json"
def g(*a):return subprocess.check_output(G+list(a)).decode().strip()
def dg(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert not OUT.exists() and g("rev-parse","HEAD")==H and g("branch","--show-current")==branch and not g("status","--porcelain")
assert g("ls-remote","origin","refs/heads/"+branch).split()[0]==H and g("merge-base",H,M)==B
assert subprocess.run(G+["rev-parse","--verify","MERGE_HEAD"],capture_output=True).returncode!=0
fetch=json.loads((E/"macro-2ae-main-reconcile.json").read_text());assert fetch["incoming"]==M and fetch["fetch_exit"]==0 and fetch["clean"]
delta=subprocess.check_output(G+["diff","--raw","--no-abbrev",B,M]);objects=set()
for line in delta.decode().splitlines():
 cols=line.split("\t",1)[0].split()
 for oid in cols[2:4]:
  if set(oid)!={"0"}:objects.add(oid)
batch=subprocess.run(G+["cat-file","--batch-check=%(objectname) %(objecttype) %(objectsize)"],input=("\n".join(sorted(objects))+"\n").encode(),capture_output=True,check=True)
assert not batch.stderr and "missing" not in batch.stdout.decode()
assert len(batch.stdout.decode().splitlines())==len(objects)
ob={"at":now(),"incoming":M,"base":B,"changed_paths":len(delta.decode().splitlines()),"delta_raw_sha256":dg(delta),"changed_parent_blob_objects_checked":len(objects),"objects":batch.stdout.decode().splitlines(),"all_changed_parent_blobs_readable":True,"scope":"Bounded changed-parent blobs only, not all historical objects"}
(E/"macro-2ae-7a6-object-preflight.json").write_text(json.dumps(ob,indent=2)+"\n")
out={"started_at":now(),"head_before":H,"incoming":M,"base":B,"state":"ORDINARY_MERGE_INTENT","scope":"Same original worktree/branch, actual dirty PR and unarmed MOG, bounded changed-parent blob availability verified; no complete-history availability claim"}
def save():OUT.write_text(json.dumps(out,indent=2)+"\n")
save();log=E/"macro-2ae-7a6-merge.log";trace=E/"macro-2ae-7a6-merge.trace.jsonl";cmd=G+["merge","--no-commit","--no-ff",M]
with log.open("xb") as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,"GIT_TRACE2_EVENT":str(trace)})
mh=subprocess.run(G+["rev-parse","--verify","MERGE_HEAD"],capture_output=True,text=True)
out.update(finished_at=now(),command=cmd,exit=p.returncode,log_bytes=log.stat().st_size,log_sha256=dg(log.read_bytes()),trace_bytes=trace.stat().st_size,head_after=g("rev-parse","HEAD"),merge_head=mh.stdout.strip() if mh.returncode==0 else None,unmerged=g("diff","--name-only","--diff-filter=U").splitlines(),unstaged=g("diff","--name-only").splitlines())
out["state"]="MERGE_OPEN_FOR_ORIGINAL_OWNER_RESOLUTION" if out["merge_head"]==M and out["head_after"]==H else "ACTUAL_MERGE_RESULT_REQUIRES_RECONCILIATION";save();print(json.dumps(out,indent=2))
