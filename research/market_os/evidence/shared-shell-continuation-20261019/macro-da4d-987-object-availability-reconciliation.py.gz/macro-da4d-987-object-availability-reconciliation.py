from pathlib import Path
import subprocess,json,hashlib,datetime
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","--no-optional-locks","-C",str(W)]
o={"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"source_or_config_mutation":False}
oid="4034805ee69b3c416899a2cf412b4b796b27146f"
r=subprocess.run(G+["cat-file","blob",oid],capture_output=True,timeout=30)
assert r.returncode==0,r.stderr.decode()
raw=r.stdout;actual=hashlib.sha1(("blob "+str(len(raw))+"\0").encode()+raw).hexdigest();assert actual==oid
o["previously_unavailable_remote_blob"]={"oid":oid,"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"native_now_available_and_object_id_verified":True}
r=subprocess.run(G+["rev-parse","-q","--verify","AUTO_MERGE"],capture_output=True,text=True)
o["auto_merge_ref"]={"exit":r.returncode,"stdout":r.stdout.strip(),"stderr":r.stderr.strip()}
if r.returncode==0:
 rows=subprocess.check_output(G+["ls-tree","-r",r.stdout.strip()],text=True)
 o["auto_merge_diagnostic_matches"]=[x for x in rows.splitlines() if "30d1e9578fdd46cc944321c84b1075e75088be7b" in x]
o["head"]=subprocess.check_output(G+["rev-parse","HEAD"],text=True).strip()
o["status"]=subprocess.check_output(G+["status","--porcelain=v1"],text=True)
p=E/"macro-da4d-987-object-availability-reconciliation.json";assert not p.exists();p.write_text(json.dumps(o,indent=2)+"\n");print(json.dumps(o,indent=2),flush=True)
