from pathlib import Path
import importlib.util,json,subprocess,socket,errno,datetime,hashlib
E=Path("/tmp/shared-shell-css-visual-20261019T1107")
spec=importlib.util.spec_from_file_location("boundary",E/"beta-same-a-service-boundary.py");b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
before=json.loads((E/"beta-same-a-effect-before-health.stdout.json").read_text());pre=json.loads((E/"beta-same-a-preflight.json").read_text())
h,hr=b.run_read("health","failed-reconcile-before");u,ur=b.run_read("unit","failed-reconcile-before")
def norm(d):
 z=dict(d)
 for k in ["Requires","Wants","Before","After","Conflicts","WantedBy","Requisite","RequisiteOf","BindsTo","PartOf","RequiredBy","BoundBy","ConsistsOf","ConflictedBy","PropagatesStopTo","StopPropagatedFrom","OnFailure","OnSuccess"]:
  if k in z:z[k]=sorted(z[k].split())
 return z
state=b.props(h["services"]["terminal-beta.service"])
assert state==b.props(h["beta_after"]) and state["ActiveState"]=="failed" and state["SubState"]=="failed" and state["MainPID"]=="0" and state["UnitFileState"]=="enabled"
for key in ["release_before","release_after"]:
 r=h[key];assert r["sample_clear"] and not r["lock"]["archives"] and r["reservation"] is False
assert not h["pending_exists"] and h["beta_stages"]=={"entries":[],"truncated":False}
assert b.beta_identity(h)==b.beta_identity(before)
assert b.production(h)==b.production(before)
assert h["production_build"]==h["production_after"]["build"] and h["production_owner"]==h["production_after"]["owner"] and h["caddy"]==h["caddy_after"] and b.props(h["services"]["terminal.service"])==b.props(h["production_after"]["service"])
assert u["observations_stable"] and u["before"]==u["after"]
old=json.loads((E/"beta-same-a-effect-before-unit.stdout.json").read_text())
assert u["files"]==old["files"] and u["before"]["command_hooks"]==old["before"]["command_hooks"]
assert norm({k:v for k,v in u["before"]["properties"].items() if k not in ["ActiveState","SubState","MainPID","ExecMainStartTimestampMonotonic"]})==norm(pre["unit_static"])
assert all(u["before"]["properties"][k]==state[k] for k in state)
remote='''import subprocess,json,socket,errno,datetime
p=subprocess.run(["systemctl","show","terminal-beta.service","--property=ActiveState,SubState,MainPID,ExecMainStartTimestampMonotonic,ExecMainExitTimestampMonotonic,ExecMainCode,ExecMainStatus,Result,StatusErrno,NRestarts,Job,ControlPID,ControlGroup"],capture_output=True,text=True,timeout=10)
r={"observed_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"command_exit":p.returncode,"stdout":p.stdout,"stderr":p.stderr}
try:
 s=socket.create_connection(("127.0.0.1",3001),timeout=5);s.close();r["connection"]={"connected":True}
except OSError as e:r["connection"]={"connected":False,"errno":e.errno,"type":type(e).__name__,"connection_refused":e.errno==errno.ECONNREFUSED}
print(json.dumps(r,indent=2))
'''
raw=remote.encode();p=subprocess.run(b.BASE+["python3 -I -B -"],input=raw,capture_output=True,timeout=30)
(E/"beta-same-a-failed-diagnostics-remote.py").write_bytes(raw)
(E/"beta-same-a-failed-diagnostics.stdout.json").write_bytes(p.stdout);(E/"beta-same-a-failed-diagnostics.stderr.log").write_bytes(p.stderr)
assert p.returncode==0 and not p.stderr
d=json.loads(p.stdout);assert d["command_exit"]==0 and not d["stderr"] and d["connection"].get("connection_refused") is True
props=dict(x.split("=",1) for x in d["stdout"].splitlines() if "=" in x)
assert props["ActiveState"]=="failed" and props["SubState"]=="failed" and props["MainPID"]=="0" and props["ControlPID"]=="0" and props["Job"]==""
out={"state":"FAILED_STATE_RECONCILED_SAME_A_ELIGIBLE_FOR_ONE_NORMAL_START","finished_at":b.now(),"health":hr,"unit":ur,"diagnostic":d,"accepted_A":b.A,"same_identity":True,"same_loaded_unit":True,"production_unchanged":True,"clear_release_boundary":True,"connection_refused":True,"start_executed":False,"reservation":False,"prior_proof_pass":False}
(E/"beta-same-a-failed-reconciliation.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps(out,indent=2))
