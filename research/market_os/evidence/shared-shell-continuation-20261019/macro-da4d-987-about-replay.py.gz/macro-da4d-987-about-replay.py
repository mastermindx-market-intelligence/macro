#!/usr/bin/env python3
"""Focused producing diagnostic using the existing native capture browser owner."""
from pathlib import Path
from urllib.parse import urlsplit
import sys, json, hashlib, subprocess, datetime, argparse
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27")
E=Path("/tmp/shared-shell-css-visual-20261019T1107")
sys.path.insert(0,str(W))
from scripts import capture_page_evidence as owner
p=argparse.ArgumentParser();p.add_argument("--head",required=True);a=p.parse_args()
assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=W,text=True).strip()==a.head
assert subprocess.check_output(["git","status","--porcelain=v1"],cwd=W,text=True)==""
M=json.loads((E/"macro-da4d-987-about-manifest.json").read_text())
assert M["macro_head"]==a.head
O=E/"macro-da4d-987-about-replay";O.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
record={"schema":"mastermind.about_footer_diagnostic.v1","started_at":now(),"source_head":a.head,"source_tree":subprocess.check_output(["git","rev-parse","HEAD^{tree}"],cwd=W,text=True).strip(),"capture_owner_sha256":sha((W/owner.MODULE_REF).read_bytes()),"runner_sha256":sha(Path(__file__).read_bytes()),"fixture_manifest_sha256":sha((E/"macro-da4d-987-about-manifest.json").read_bytes()),"scope":"anonymous standalone Macro About presentation fixture; no Terminal or public beta acceptance","actual_browser_zoom":"NOT_RUN","preceding_diagnostic":"R1 sampled focus geometry before incumbent smooth scrolling reached the focused links; retained exit1. V2 waits for actual focused-link viewport visibility without changing page scroll behavior.","cells":[]}
driver=owner.playwright_page_driver(headless=False,settle_ms=750)
record["browser_version"]=driver._browser.version
geometry="""() => {
 const box=e=>{const r=e.getBoundingClientRect();return {left:r.left,right:r.right,top:r.top,bottom:r.bottom,width:r.width,height:r.height}};
 const footer=document.querySelector('footer'),cols=document.querySelector('.f-cols');
 return {client:document.documentElement.clientWidth,document:document.documentElement.scrollWidth,
 lang:document.documentElement.lang,dataLang:document.documentElement.dataset.lang,
 colorScheme:getComputedStyle(document.documentElement).colorScheme,background:getComputedStyle(document.body).backgroundColor,
 footer:box(footer),columns:box(cols),wrap:getComputedStyle(cols).flexWrap,
 columnBoxes:[...document.querySelectorAll('.f-col')].map(box),
 links:[...footer.querySelectorAll('a')].map(e=>({text:e.innerText,href:e.getAttribute('href'),box:box(e),display:getComputedStyle(e).display,visibility:getComputedStyle(e).visibility,tabIndex:e.tabIndex}))};
}"""
try:
 for width,height in [(390,844),(320,844),(820,1180),(1440,900)]:
  for locale in ["en","zh"]:
   cell={"width":width,"height":height,"locale":locale,"started_at":now(),"responses":[],"blocked_requests":[],"errors":[]}
   context=driver._browser.new_context(viewport={"width":width,"height":height},locale="zh-CN" if locale=="zh" else "en-US",color_scheme="light",device_scale_factor=1,user_agent=owner.USER_AGENT)
   context.add_init_script(owner.state_seed_source({"theme":"light","locale":locale}))
   def route_guard(route):
    u=urlsplit(route.request.url)
    if u.scheme=="http" and u.netloc=="127.0.0.1:3110" and route.request.method in ("GET","HEAD"):route.continue_()
    else:cell["blocked_requests"].append({"origin":u.scheme+"://"+u.netloc,"path":u.path,"method":route.request.method});route.abort("blockedbyclient")
   context.route("**/*",route_guard)
   page=context.new_page()
   page.on("pageerror",lambda error:cell["errors"].append(str(error)))
   def response(r):
    path=urlsplit(r.url).path
    if path in ("/about.html","/landing.css","/shared_shell.css"):
     body=r.body();cell["responses"].append({"path":path,"status":r.status,"bytes":len(body),"sha256":sha(body),"fixture_header":r.headers.get("x-mmx-fixture-manifest")})
   page.on("response",response)
   try:
    page.goto("http://127.0.0.1:3110/about.html",wait_until="load",timeout=60000)
    page.evaluate(owner._APPLY_STATE_SCRIPT.strip(),{"theme":"light","locale":locale})
    page.evaluate("() => document.fonts.ready.then(() => true)")
    page.wait_for_timeout(750)
    cell["geometry"]=page.evaluate(geometry)
    links=page.locator("footer a");count=links.count();cell["keyboard"]=[]
    assert count>0
    links.first.focus()
    page.keyboard.press("Shift+Tab");page.keyboard.press("Tab")
    for i in range(count):
     page.wait_for_function("() => {const e=document.activeElement,r=e.getBoundingClientRect();return !!e.closest(\'footer\') && r.top>=-0.5 && r.bottom<=innerHeight+0.5}",timeout=5000)
     focused=page.evaluate("""() => {const e=document.activeElement,r=e.getBoundingClientRect(),s=getComputedStyle(e);return {footer:!!e.closest('footer'),href:e.getAttribute('href'),text:e.innerText,focusVisible:e.matches(':focus-visible'),left:r.left,right:r.right,top:r.top,bottom:r.bottom,viewportWidth:innerWidth,viewportHeight:innerHeight,outlineStyle:s.outlineStyle,outlineWidth:s.outlineWidth,outlineColor:s.outlineColor}}""")
     focused["expected_href"]=cell["geometry"]["links"][i]["href"]
     cell["keyboard"].append(focused)
     if i+1<count:page.keyboard.press("Tab")
    shot=O/f"footer-{width}-{locale}.png";page.locator("footer").screenshot(path=str(shot))
    cell["screenshot"]={"file":shot.name,"bytes":shot.stat().st_size,"sha256":sha(shot.read_bytes())}
    g=cell["geometry"]
    cell["checks"]={"no_document_overflow":g["document"]<=g["client"],"footer_columns_contained":g["columns"]["left"]>=-0.5 and g["columns"]["right"]<=g["client"]+0.5,"all_links_have_visible_boxes":all(l["box"]["width"]>0 and l["box"]["height"]>0 and l["visibility"]=="visible" and l["box"]["left"]>=-0.5 and l["box"]["right"]<=g["client"]+0.5 for l in g["links"]),"keyboard_order_and_visibility":all(k["footer"] and k["href"]==k["expected_href"] and k["focusVisible"] and k["outlineStyle"]!="none" and float(k["outlineWidth"].removesuffix("px"))>0 and k["left"]>=-0.5 and k["right"]<=k["viewportWidth"]+0.5 and k["bottom"]>0 and k["top"]<k["viewportHeight"] for k in cell["keyboard"]),"actual_bound_css":any(r["path"]=="/landing.css" and r["status"]==200 and r["sha256"]==M["files"]["/landing.css"]["sha256"] for r in cell["responses"]),"light_only_retained":set(g["colorScheme"].split())=={"light","only"},"locale_observed":g["dataLang"]==locale,"no_page_exception":not cell["errors"]}
    cell["passed"]=all(cell["checks"].values())
   except Exception as error:cell["error"]=repr(error);cell["passed"]=False
   finally:context.close()
   cell["finished_at"]=now();record["cells"].append(cell)
   (O/"actual.json").write_text(json.dumps(record,indent=2,ensure_ascii=False)+"\n")
   print(json.dumps({"width":width,"locale":locale,"passed":cell["passed"],"checks":cell.get("checks"),"geometry":{k:cell.get("geometry",{}).get(k) for k in ["client","document","wrap","colorScheme"]}},ensure_ascii=False),flush=True)
finally:driver.close()
record["finished_at"]=now();record["contexts_closed"]=True;record["passed"]=len(record["cells"])==8 and all(c["passed"] for c in record["cells"])
record["head_after"]=subprocess.check_output(["git","rev-parse","HEAD"],cwd=W,text=True).strip()
assert record["head_after"]==a.head
(O/"actual.json").write_text(json.dumps(record,indent=2,ensure_ascii=False)+"\n")
raise SystemExit(0 if record["passed"] else 1)