import copy,datetime,gzip,hashlib,json,pathlib,subprocess,yaml
W=pathlib.Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27")
E=pathlib.Path("/tmp/shared-shell-css-visual-20261019T1107")
REL="research/market_os/evidence/shared-shell-continuation-20261019";P=W/REL;G=["git","-C",str(W)]
commit=json.loads((E/"macro-da4d-987-source-commit.json").read_text())
H=commit["head_after"];M="9875169102cc6f36a64d465fe7c06f6bb8fb0220";SOURCE=commit["source_tree"]
HP="agentos/handoffs/MARKET-OS-SHARED-SHELL-2026-09-24.md";WP="agentos/workstreams/WS-MARKET-OS.md"
STEM="macro-da4d-987-proof-import";OUT=E/(STEM+".json")
def git(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def readj(n):return json.loads((E/n).read_text())
def savej(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+"\n")
assert not OUT.exists(),"existing partial import requires reconciliation"
assert git("rev-parse","HEAD").decode().strip()==H
assert subprocess.run(G+["rev-parse","--verify","MERGE_HEAD"],capture_output=True).returncode!=0
assert git("write-tree").decode().strip()==SOURCE
assert not git("diff","--name-only").strip() and not git("ls-files","-u").strip()
focused=readj("macro-da4d-987-composed-tests.json")
assert focused["pass"] and focused["after"]["index_tree"]==SOURCE and focused["index_unchanged"] and focused["source_unchanged"]
for p,h in focused["source_sha256"].items():assert dg((W/p).read_bytes())==h,p
about=readj("macro-da4d-987-about-wrapper.json")
assert about["pass"] and about["source_head"]==H and about["source_tree"]==SOURCE and about["capture"]["cells"]==8
assert commit["state"]=="SOURCE_COMMITTED_LOCAL_ONLY" and commit["clean"]
oldraw=(P/"MANIFEST.json").read_bytes()
assert dg(oldraw)=="eafb91bd7ffb2bf6e8b9cecfe72eae2627ce01175d3ddd13a8f57f32e5031dc6"
mf=json.loads(oldraw);oldrows=copy.deepcopy(mf["files"]);rows={r["file"]:r for r in oldrows}
assert len(rows)==len(oldrows)==509
def verify():
 for name,row in rows.items():
  raw=(P/name).read_bytes()
  assert len(raw)==row["bytes"] and dg(raw)==row["sha256"],name
  if row.get("encoding","identity")=="gzip":
   b=gzip.decompress(raw)
   assert len(b)==row["original_bytes"] and dg(b)==row["original_sha256"],name
 assert {str(p.relative_to(P)) for p in P.rglob("*") if p.is_file()}==set(rows)|{"MANIFEST.json"}
verify()
hb=(W/HP).read_bytes();wb=(W/WP).read_bytes();rb=(P/"README.md").read_bytes()
assert hb==git("show",":"+HP) and wb==git("show",":"+WP)
hs=hb.decode();cut=hs.index("\n---\n",4);meta=yaml.safe_load(hs[4:cut]);oldbody=hs[cut+5:]
assert meta["workstream"]=="WS:MARKET-OS" and meta["prs"]==[7949]
cfg=readj("macro-da4d-987-proof-config.json")
for key in ("state_before","unresolved","next_actions"):meta[key]=cfg[key]
for key in ("changed","verified"):meta[key].extend(cfg[key])
meta["do_not_redo"].append(cfg["do_not_redo_add"])
continuation=cfg["continuation"].rstrip()+"\n"
newh="---\n"+yaml.safe_dump(meta,sort_keys=False,allow_unicode=True,width=110)+"---\n"+oldbody+"\n\n"+continuation
neww=wb.decode()+"\n\n"+continuation
newr=rb+b"\n\n"+continuation.encode()
assert newh.split("\n---\n",1)[1]==oldbody+"\n\n"+continuation and neww.encode().startswith(wb) and newr.startswith(rb)
out={"started_at":now(),"status":"PRECHECKS_COMPLETE_IMPORT_BEGIN","head":H,"incoming":M,"source_index":SOURCE,"old_manifest_sha256":dg(oldraw),"old_indexed_files":509,"old_handoff_body_sha256":dg(oldbody.encode()),"old_workstream_sha256":dg(wb)}
savej(OUT,out)
(W/HP).write_text(newh);(W/WP).write_text(neww);(P/"README.md").write_bytes(newr)
rows["README.md"]={**rows["README.md"],"bytes":len(newr),"sha256":dg(newr)}
added=[];skipped=[]
def include(p,target=None):
 raw=p.read_bytes();target=target or p.name
 gz=p.suffix!=".json" or len(raw)>65536 or raw.endswith(b"\n\n")
 if gz:target+=".gz"
 if target in rows:
  r=rows[target]
  assert (r.get("original_sha256") if r.get("encoding","identity")=="gzip" else r["sha256"])==dg(raw),target
  skipped.append(target);return target
 assert pathlib.Path(target).name==target and not (P/target).exists(),target
 data=gzip.compress(raw,mtime=0) if gz else raw
 if gz:assert gzip.decompress(data)==raw
 else:raw.decode()
 (P/target).write_bytes(data)
 r={"file":target,"source":str(p),"bytes":len(data),"sha256":dg(data),"encoding":"gzip" if gz else "utf-8"}
 if gz:r.update(original_bytes=len(raw),original_sha256=dg(raw))
 rows[target]=r;added.append(target);return target
prefixes=("macro-140bd-","macro-3b49-","macro-b312-","macro-da4d-","macro-ae3-5c2d-complete-merge","macro-full-checkpoint-","about-footer-","labor-copy-","beta-loaded-unit-root-","beta-same-a-")
exclude={OUT,E/"macro-da4d-987-proof-validation.json",E/"macro-da4d-987-final-changed-paths.txt"}
for p in sorted(E.iterdir()):
 if p.is_file() and p not in exclude and p.name.startswith(prefixes):include(p)
 elif p.is_dir() and p.name.startswith(("macro-da4d-987-","about-footer-","labor-copy-")):
  for f in sorted(p.rglob("*")):
   if f.is_file():
    assert not f.is_symlink()
    include(f,p.name+"--"+str(f.relative_to(p)).replace("/","--"))
include(E/"macro-ae3-5c2d-proof-finalize.json")
assert "previous_frontier_before_987" not in mf
mf["previous_frontier_before_987"]={k:copy.deepcopy(v) for k,v in mf.items() if k!="files" and not k.startswith("previous_frontier")}
mf.update(cfg["manifest_update"])
mf.update({"macro_source_head":H,"macro_incoming_main":M,"macro_integrated_index_tree_before_proof":SOURCE,
 "latest_confirmed_macro_publication":"b312bc4c08cf7633bf8fd259d2d46ec545fa120f",
 "publication_of_this_package":"Precommit/prepush documentation extension after local ordinary987 merge. Original PR7949 checkpoint binds eventual push/landing/publication. Local source and fixture/service proof are separately scoped; no hosted, protected landing, rendered-main, served or public-beta acceptance claimed."})
def savemf():
 mf["files"]=[rows[k] for k in sorted(rows)];mf["indexed_at"]=now();savej(P/"MANIFEST.json",mf)
savemf()
subprocess.run(G+["add","--",HP,WP,REL],check=True)
record=git("write-tree").decode().strip()
docs=git("diff","--name-only",SOURCE,record).decode().splitlines()
allowed=lambda p:p in (HP,WP) or p.startswith(REL+"/")
assert docs and all(allowed(p) for p in docs) and not git("diff","--name-only").strip()
vpath=E/"macro-da4d-987-proof-validation.json";assert not vpath.exists()
validation={"started_at":now(),"source_index":SOURCE,"record_index_before_validation":record,"documentation_only_delta":docs,"old509_entries_verified":True,"previous_handoff_body_preserved":True,"previous_workstream_bytes_preserved":True,"previous_readme_bytes_preserved":True,"checks":[]}
savej(vpath,validation)
diffpath=E/"macro-da4d-987-final-changed-paths.txt";assert not diffpath.exists();diffpath.write_bytes(git("diff","--cached","--name-only",M))
py=str(W/".venv-shared-shell/bin/python")
commands=[
 ("agentos",[py,"-B","scripts/agentos.py","validate"]),
 ("template-sync",[py,"-B","scripts/check_template_site_sync.py"]),
 ("p0b-closure",[py,"-B","scripts/check_p0b_receipt_closure.py","--diff-file",str(diffpath),"--event","pull_request"]),
 ("owned-whitespace",G+["diff","--cached","--check",M])]
for name,args in commands:
 log=E/("macro-da4d-987-proof-"+name+".log");assert not log.exists();start=now()
 with log.open("xb") as f:r=subprocess.run(args,cwd=W,stdout=f,stderr=subprocess.STDOUT)
 item={"check":name,"command":args,"started_at":start,"finished_at":now(),"exit":r.returncode,"log":str(log),"bytes":log.stat().st_size,"sha256":dg(log.read_bytes())}
 validation["checks"].append(item);savej(vpath,validation)
 print(json.dumps({"check":name,"exit":r.returncode,"tail":log.read_text(errors="replace")[-2000:]}),flush=True)
 assert r.returncode==0,item
assert (W/HP).read_text()==newh and (W/WP).read_text()==neww
assert git("write-tree").decode().strip()==record and not git("diff","--name-only").strip()
validation.update(finished_at=now(),all_checks_pass=True,record_index_unchanged_during_checks=True,handoff_and_workstream_unchanged_during_checks=True)
savej(vpath,validation)
for c in validation["checks"]:include(pathlib.Path(c["log"]))
include(vpath);include(diffpath)
mf["documentation_validation"]={"receipt":vpath.name,"all_checks_exit0":True,"record_index":record,"agentos_exit":0,"template_sync_exit":0,"p0b_closure_exit":0,"owned_whitespace_exit":0,"handoff_and_workstream_unchanged_after_validation":True}
savemf();verify()
for row in oldrows:
 if row["file"]!="README.md":assert rows[row["file"]]==row,row["file"]
subprocess.run(G+["add","--",REL],check=True)
final=git("write-tree").decode().strip()
finaldocs=git("diff","--name-only",SOURCE,final).decode().splitlines()
assert all(allowed(p) for p in finaldocs)
assert not git("diff","--name-only").strip() and not git("ls-files","-u").strip()
assert not git("diff","--cached","--check",M).strip()
count=len(git("diff","--name-only",M,final).decode().splitlines());assert count<3000
out.update(finished_at=now(),status="PROOF_READY_NOT_COMMITTED_OR_PUSHED",final_index=final,documentation_only_paths=len(finaldocs),indexed_files=len(rows),added_files=added,skipped_existing_identical=skipped,manifest_bytes=(P/"MANIFEST.json").stat().st_size,manifest_sha256=dg((P/"MANIFEST.json").read_bytes()),candidate_paths_vs_incoming=count,validation_receipt_sha256=dg(vpath.read_bytes()),handoff_sha256=dg((W/HP).read_bytes()),workstream_sha256=dg((W/WP).read_bytes()),all_checks_pass=True,all_hashes_and_coverage_pass=True)
savej(OUT,out)
print(json.dumps({k:v for k,v in out.items() if k not in ("added_files","skipped_existing_identical")},indent=2),flush=True)