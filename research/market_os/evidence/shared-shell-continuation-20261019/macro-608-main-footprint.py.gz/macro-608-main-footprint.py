from pathlib import Path
import json,subprocess,collections,hashlib,datetime
E=Path("/tmp/shared-shell-css-visual-20261019T1107");W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");G=["git","-C",str(W)]
r=json.loads((E/"macro-608-main-reconcile.json").read_text());H=r["head"];M=r["incoming"];B=r["merge_base"]
def g(*a):return subprocess.check_output(G+list(a)).decode()
ours=set(g("diff","--name-only",B,H).splitlines());theirs=set(g("diff","--name-only",B,M).splitlines());overlap=sorted(ours&theirs)
code=[p for p in theirs if not p.startswith(("site/","data/","research/","agentos/","docs/","reports/","warehouse/"))]
stat={"observed_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"head":H,"incoming":M,"base":B,"new_main_commits":len(r["commits"].splitlines()),"main_changed_paths":len(theirs),"head_changed_paths":len(ours),"overlap_paths":overlap,"incoming_code_paths":sorted(code),"prefix_counts":dict(collections.Counter(p.split("/")[0] for p in theirs)),"incoming_commit_subjects":r["commits"].splitlines()[-10:]}
inputs={}
for name in ["macro-da4d-987-about-manifest.json","macro-da4d-987-p0b-actual.json","macro-da4d-987-composed-tests.json"]:
 j=json.loads((E/name).read_text());inputs[name]={"keys":list(j)}
stat["proof_input_structures"]=inputs
(E/"macro-608-main-footprint.json").write_text(json.dumps(stat,indent=2)+"\n");print(json.dumps(stat,indent=2))
