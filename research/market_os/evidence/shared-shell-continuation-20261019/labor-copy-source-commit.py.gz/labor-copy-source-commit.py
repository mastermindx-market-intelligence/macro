from pathlib import Path
import subprocess,json,hashlib,datetime,sys
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","-C",str(W)]
H="8b51fb46d18739a4d10d1ef07dce3ca0f989f0da";P=["lib/macro_suite_labels.py","site/macro_labor_markets.html","tests/test_macro_command_copy_law.py"];OUT=E/"labor-copy-source-commit.json"
def git(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert not OUT.exists()
test=json.loads((E/"labor-copy-green.json").read_text())
assert test["passed"] and test["source_unchanged"] and test["before"]==test["after"]
assert git("rev-parse","HEAD").decode().strip()==H and git("branch","--show-current").decode().strip()=="sol/market-os-shared-shell-design-20260924"
assert dg(git("diff","--binary","HEAD"))==test["before"]["diff_sha256"]
assert sorted(git("diff","--name-only","HEAD").decode().splitlines())==sorted(P) and not git("diff","--cached","--name-only").strip()
lineage=json.loads((E/"labor-copy-proof-lineage.json").read_text())
assert lineage["head"]==H and lineage["unchanged_after"] and len(lineage["p0b"])==82 and len(lineage["about"])==53
for row in [*lineage["p0b"],*lineage["about"]]:assert dg((W/row["path"]).read_bytes())==row["sha256"]
subprocess.run(G+["diff","--check"],check=True)
subprocess.run(G+["add","--",*P],check=True)
tree=git("write-tree").decode().strip()
assert sorted(git("diff","--cached","--name-only").decode().splitlines())==sorted(P)
out={"started_at":now(),"parent":H,"staged_tree":tree,"paths":P,"tested_working_diff_sha256":test["before"]["diff_sha256"],"test_receipt_sha256":dg((E/"labor-copy-green.json").read_bytes()),"lineage_receipt_sha256":dg((E/"labor-copy-proof-lineage.json").read_bytes()),"status":"STAGED_NOT_COMMITTED","pushed":False}
def save():OUT.write_text(json.dumps(out,indent=2)+"\n")
save()
message=E/"labor-copy-source-message.txt"
message.write_text("fix(macro): explain unavailable labor coverage in plain language\n\nMap the known labor coverage refusal through the existing bilingual copy owner,\npreserving the original disclosure and the explicit refusal to assume neutral.\nAdopt the labor page emitted by the existing suite renderer and asset optimizer.\n\nRetain the real copy-law guard. Add a regression that was observed red before\nthe mapping, then validate the original three constituents (645 passing tests)\nand four existing CI packing checks. No CI selectors or limits change.\n")
with (E/"labor-copy-source-commit.log").open("wb") as f:p=subprocess.run(G+["commit","-F",str(message)],stdout=f,stderr=subprocess.STDOUT)
out.update(commit_exit=p.returncode,finished_at=now(),head=git("rev-parse","HEAD").decode().strip(),tree=git("rev-parse","HEAD^{tree}").decode().strip(),status_after=git("status","--porcelain=v1").decode(),log_sha256=dg((E/"labor-copy-source-commit.log").read_bytes()))
if p.returncode==0:
 assert out["head"]!=H and out["tree"]==tree and git("rev-parse","HEAD^").decode().strip()==H and not out["status_after"]
 out["status"]="COMMITTED_LOCAL_ONLY"
else:out["status"]="COMMIT_FAILED_RECONCILE_BEFORE_RETRY"
save();print(json.dumps(out,indent=2),flush=True);sys.exit(p.returncode)
