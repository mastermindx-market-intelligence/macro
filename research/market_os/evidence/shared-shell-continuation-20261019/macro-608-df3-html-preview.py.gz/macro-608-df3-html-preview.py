from pathlib import Path
import subprocess,json,hashlib,datetime,os,sys
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");D=E/"macro-608-df3-html-preview";G=["git","--no-optional-locks","-C",str(W)]
B="9875169102cc6f36a64d465fe7c06f6bb8fb0220";H="608dfad299e2e48ab7703bf0b180e0dca1318229";M="df3cba80e5ff43e3411209381b32d9d4df06bd1f"
def git(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
def ident(p):
 b=(W/p).read_bytes();blob=hashlib.sha1(("blob "+str(len(b))+"\0").encode()+b).hexdigest();assert blob==git("rev-parse",":"+p).decode().strip(),p
 return {"bytes":len(b),"sha256":dg(b),"git_blob":blob}
assert not D.exists();D.mkdir()
assert git("rev-parse","HEAD").decode().strip()==H and git("rev-parse","MERGE_HEAD").decode().strip()==M
before=git("ls-files","--stage","-z")
owners={p:ident(p) for p in ["lib/pages.py","lib/shared_shell.py","lib/site_assets.py","lib/config.py","scripts/optimize_assets.py","templates/data_base.js","config.yml"]}
os.chdir(W);sys.path.insert(0,str(W))
from scripts.optimize_assets import make_optimizer
from lib.shared_shell import inject_shared_shell_text
from lib.pages import dbase_prefix
opt=make_optimizer(W/"site");closure=dict(zip(opt.__code__.co_freevars,[x.cell_contents for x in opt.__closure__]))
versions=[dg((W/"site"/p).read_bytes())[:8] for p in ["shared_shell_bridge.js","shared_shell.css"]]
def canon(raw,p):
 q=W/("site/chat.html" if p=="templates/chat.html" else p)
 return opt(inject_shared_shell_text(raw.decode(),dbase_prefix(q),version=versions[0],css_version=versions[1],site_dir=W/"site"),q.parent)
plain="try{ window.MDXAuth.open('signin'); }catch(e){ location.href = 'plans.html'; }";shared="if (window.MMXSharedShell) { window.MMXSharedShell.openAuth('signin'); return; } "+plain
whole={"site/us_stocks.html":[("        location.href = 'stock.html#' + encodeURIComponent(tk);","        var _d = 'stock.html#' + encodeURIComponent(tk); var _ss = window.MMXSharedShell; if (_ss) { _ss.navigate(_d, 'push'); } else { location.href = _d; }"),("    window.addEventListener('hashchange', fromHash);","    window.addEventListener('hashchange', fromHash);\n    window.addEventListener('mmx:shell-location', fromHash);"),("          try{ window.MDXAuth.open('signin'); }catch(e2){ location.href = 'plans.html'; }","          if(window.MMXSharedShell){ window.MMXSharedShell.openAuth('signin'); return; }\n          try{ window.MDXAuth.open('signin'); }catch(e2){ location.href = 'plans.html'; }")],**{p:[(plain,shared)] for p in ["site/etfs.html","site/special_situations.html","site/china_special_situations.html"]}}
paths=[p for p in git("diff","--name-only","--diff-filter=U").decode().splitlines() if p.endswith(".html") and p!="site/macro_labor_markets.html"];rows=[]
for p in paths:
 texts={};parents={}
 for label,rev in [("B",B),("H",H),("M",M)]:
  raw=git("show",rev+":"+p);assert git("rev-parse",":"+{"B":"1","H":"2","M":"3"}[label]+":"+p)==git("rev-parse",rev+":"+p)
  texts[label]=canon(raw,p);f=D/(p.replace("/","_")+"."+label);f.write_text(texts[label]);parents[label]={"commit":rev,"original_sha256":dg(raw),"canonical_sha256":dg(texts[label].encode()),"file":str(f)}
 if p in whole:
  def apply(text):
   for old,new in whole[p]:
    assert text.count(old)==1 and new not in text,(p,old)
    text=text.replace(old,new,1)
   return text
  assert apply(texts["B"])==texts["H"],p
  candidate=apply(texts["M"]);back=candidate
  for old,new in reversed(whole[p]):assert back.count(new)==1;back=back.replace(new,old,1)
  assert back==texts["M"];code=0;method="complete incoming generation + source-proven adapters, inverse recovers canonical M"
 else:
  r=subprocess.run(["git","merge-file","-p","--diff3","-L","H","-L","B","-L","M",parents["H"]["file"],parents["B"]["file"],parents["M"]["file"]],capture_output=True);assert not r.stderr
  code=r.returncode;candidate=r.stdout.decode();method="canonical normalization + ordinary three-way"
 f=D/(p.replace("/","_")+".candidate");f.write_text(candidate)
 row={"path":p,"method":method,"parents":parents,"exit":code,"candidate":str(f),"candidate_sha256":dg(candidate.encode()),"candidate_bytes":len(candidate.encode()),"conflict_markers":candidate.count("<<<<<<< H")};rows.append(row);print(json.dumps({k:row[k] for k in ["path","exit","conflict_markers"]}),flush=True)
assets=[]
for p,h in sorted(closure["cache"].items()):
 assert h is not None,("missing asset",str(p))
 row=ident(str(p.relative_to(W)));assert row["sha256"][:8]==h;assets.append({"path":str(p.relative_to(W)),**row})
assert owners=={p:ident(p) for p in owners} and git("ls-files","--stage","-z")==before
out={"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"head":H,"base":B,"incoming":M,"source_owners":owners,"rows":rows,"assets":assets,"all_assets_raw_equal_stage":True,"worktree_or_index_written":False,"all_clean":all(r["exit"]==0 for r in rows)}
(D/"receipt.json").write_text(json.dumps(out,indent=2)+"\n");print(json.dumps({"rows":len(rows),"all_clean":out["all_clean"],"assets":len(assets),"receipt_sha256":dg((D/"receipt.json").read_bytes())}))
