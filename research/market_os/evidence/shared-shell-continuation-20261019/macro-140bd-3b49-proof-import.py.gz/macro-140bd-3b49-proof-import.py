import copy,datetime,gzip,hashlib,json,pathlib,subprocess,yaml
W=pathlib.Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27")
E=pathlib.Path("/tmp/shared-shell-css-visual-20261019T1107")
REL="research/market_os/evidence/shared-shell-continuation-20261019";P=W/REL;G=["git","-C",str(W)]
H="140bd1ee79a44859915595fdf12c958c07a60e2b";M="3b49d6a5c8a6330652a926a8e5061e0dbb3d0387";SOURCE="4e8952ea930e29d38874eee2c5ef60c5bc9fdaeb"
HP="agentos/handoffs/MARKET-OS-SHARED-SHELL-2026-09-24.md";WP="agentos/workstreams/WS-MARKET-OS.md"
STEM="macro-140bd-3b49-proof-import";OUT=E/(STEM+".json")
def git(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def readj(n):return json.loads((E/n).read_text())
def savej(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+"\n")
assert not OUT.exists(),"existing partial import requires reconciliation"
assert git("rev-parse","HEAD").decode().strip()==H
assert git("rev-parse","MERGE_HEAD").decode().strip()==M
assert git("write-tree").decode().strip()==SOURCE
assert not git("diff","--name-only").strip() and not git("ls-files","-u").strip()
focused=readj("macro-140bd-3b49-focused.json")
assert focused["pytest_exit"]==0 and focused["index"]==SOURCE and focused["index_unchanged"] and focused["source_unchanged"]
assert focused["source_sha256"][".github/ci/legacy-jobs.yml"]==dg((W/".github/ci/legacy-jobs.yml").read_bytes())
assert focused["source_sha256"]["tests/test_ci_pack.py"]==dg((W/"tests/test_ci_pack.py").read_bytes())
oldraw=(P/"MANIFEST.json").read_bytes()
assert dg(oldraw)=="d00f7d0654264bfa414066e59206cdf5fa8ec7a02099c3a29dee77040af56fc7"
mf=json.loads(oldraw);oldrows=copy.deepcopy(mf["files"]);rows={r["file"]:r for r in oldrows}
assert len(rows)==len(oldrows)==460
def verify():
 for name,row in rows.items():
  raw=(P/name).read_bytes()
  assert len(raw)==row["bytes"] and dg(raw)==row["sha256"],name
  if row.get("encoding","identity")=="gzip":
   b=gzip.decompress(raw)
   assert len(b)==row["original_bytes"] and dg(b)==row["original_sha256"],name
 assert {str(p.relative_to(P)) for p in P.rglob("*") if p.is_file()}==set(rows)|{"MANIFEST.json"}
verify()
hb=(W/HP).read_bytes();wb=(W/WP).read_bytes();rb=(P/"README.md").read_bytes()
assert hb==git("show",":"+HP) and wb==git("show",":"+WP)
hs=hb.decode();cut=hs.index("\n---\n",4);meta=yaml.safe_load(hs[4:cut]);oldbody=hs[cut+5:]
assert meta["workstream"]=="WS:MARKET-OS" and meta["prs"]==[7949]
cfg=readj("macro-140bd-3b49-proof-config.json")
for key in ("state_before","unresolved","next_actions"):meta[key]=cfg[key]
for key in ("changed","verified"):meta[key].extend(cfg[key])
meta["do_not_redo"].append(cfg["do_not_redo_add"])
continuation=cfg["continuation"].rstrip()+"\n"
newh="---\n"+yaml.safe_dump(meta,sort_keys=False,allow_unicode=True,width=110)+"---\n"+oldbody+"\n\n"+continuation
neww=wb.decode()+"\n\n"+continuation
newr=rb+b"\n\n"+continuation.encode()
assert newh.split("\n---\n",1)[1]==oldbody+"\n\n"+continuation and neww.encode().startswith(wb) and newr.startswith(rb)
out={"started_at":now(),"status":"PRECHECKS_COMPLETE_IMPORT_BEGIN","head":H,"incoming":M,"source_index":SOURCE,"old_manifest_sha256":dg(oldraw),"old_indexed_files":460,"old_handoff_body_sha256":dg(oldbody.encode()),"old_workstream_sha256":dg(wb)}
savej(OUT,out)
(W/HP).write_text(newh);(W/WP).write_text(neww);(P/"README.md").write_bytes(newr)
rows["README.md"]={**rows["README.md"],"bytes":len(newr),"sha256":dg(newr)}
added=[];skipped=[]
def include(p,target=None):
 raw=p.read_bytes();target=target or p.name
 gz=p.suffix!=".json" or len(raw)>65536 or raw.endswith(b"\n\n")
 if gz:target+=".gz"
 if target in rows:
  r=rows[target]
  assert (r.get("original_sha256") if r.get("encoding","identity")=="gzip" else r["sha256"])==dg(raw),target
  skipped.append(target);return target
 assert pathlib.Path(target).name==target and not (P/target).exists(),target
 data=gzip.compress(raw,mtime=0) if gz else raw
 if gz:assert gzip.decompress(data)==raw
 else:raw.decode()
 (P/target).write_bytes(data)
 r={"file":target,"source":str(p),"bytes":len(data),"sha256":dg(data),"encoding":"gzip" if gz else "utf-8"}
 if gz:r.update(original_bytes=len(raw),original_sha256=dg(raw))
 rows[target]=r;added.append(target);return target
prefixes=("macro-140bd-","macro-3b49-","macro-ae3-5c2d-complete-merge","macro-full-checkpoint-1422-")
for p in sorted(E.iterdir()):
 if p.is_file() and p!=OUT and p.name.startswith(prefixes):include(p)
include(E/"macro-ae3-5c2d-proof-finalize.json")
for p in sorted((E/"macro-140bd-3b49-html-canonical-merge").iterdir()):
 if p.is_file():include(p,p.parent.name+"--"+p.name)
assert "previous_frontier_before_3b49" not in mf
mf["previous_frontier_before_3b49"]={k:copy.deepcopy(v) for k,v in mf.items() if k!="files" and not k.startswith("previous_frontier")}
mf.update({
 "macro_source_head":H,"macro_incoming_main":M,"macro_integrated_index_tree_before_proof":SOURCE,
 "latest_confirmed_macro_publication":"e2d10f933587f58be8716505529a37f8839901f7",
 "publication_of_this_package":"Precommit/prepush ordinary3b49 merge. The original PR7949 checkpoint binds eventual source head. No hosted, protected landing, rendered-main, served or public-beta acceptance claimed.",
 "latest_host_observed_at":"2026-10-20T14:42:38.136969Z",
 "beta_publication_gate":"Accepted R93 originalA bootstrap/runtime/filesystem unchanged; readonly current health passes. Production baseline externally changed and is recorded without actor attribution; refresh action-boundary predicates before arm. Canonical public DNS/TLS/auth/browser/applicable rollback remain.",
 "local_contract_gate_scope":"Actual four existing CI scope/packing nodes pass on index4e8952; deployment334/P0B producer results reused on unchanged inputs. New-head hosted admission remains separate.",
 "focused_current_composition":{"source_index":SOURCE,"incoming":M,"jobs":336,"three_measured_dependency_paths_added":True,"scope_and_packing_passes":4,"pytest_exit":0,"receipt":"macro-140bd-3b49-focused.json","deployment_passes_reused":334,"deployment_input_identity_receipt":"macro-140bd-3b49-composition.json","hosted_admission":False},
 "latest_main_read_before_publication":{"sha":M,"receipt":"macro-140bd-main-reconcile.json","read_method":"one main-only ordinary fetch; no later unrelated-main chase"},
 "current_host_baseline":{"health":"macro-3b49-beta-health-20261020T1443.json","raw":"macro-3b49-beta-health-20261020T1443.stdout.json","reconciliation":"macro-3b49-runtime-baseline-reconciliation.json","production_unchanged_claim":False,"owner_or_installer_invoked":False,"strict_public_tls_exit":60},
 "current_p0b":{"receipt":"macro-e2d-42c-p0b-actual.json","binding":"macro-e2d-42c-p0b-bind-stage.json","closure":"macro-e2d-42c-p0b-closure.json","lineage":"macro-ae3-5c2d-p0b-lineage-v2.json","current_composition_identity_check":"macro-140bd-3b49-composition.json","bound_paths":82,"screenshots":16,"actual_prior_cases":128,"rerun_for_3b49":False,"production":False}
})
def savemf():
 mf["files"]=[rows[k] for k in sorted(rows)];mf["indexed_at"]=now();savej(P/"MANIFEST.json",mf)
savemf()
subprocess.run(G+["add","--",HP,WP,REL],check=True)
record=git("write-tree").decode().strip()
docs=git("diff","--name-only",SOURCE,record).decode().splitlines()
allowed=lambda p:p in (HP,WP) or p.startswith(REL+"/")
assert docs and all(allowed(p) for p in docs) and not git("diff","--name-only").strip()
vpath=E/"macro-140bd-3b49-proof-validation.json";assert not vpath.exists()
validation={"started_at":now(),"source_index":SOURCE,"record_index_before_validation":record,"documentation_only_delta":docs,"old460_entries_verified":True,"previous_handoff_body_preserved":True,"previous_workstream_bytes_preserved":True,"previous_readme_bytes_preserved":True,"checks":[]}
savej(vpath,validation)
diffpath=E/"macro-140bd-3b49-final-changed-paths.txt";assert not diffpath.exists();diffpath.write_bytes(git("diff","--cached","--name-only",M))
py=str(W/".venv-shared-shell/bin/python")
commands=[
 ("agentos",[py,"-B","scripts/agentos.py","validate"]),
 ("template-sync",[py,"-B","scripts/check_template_site_sync.py"]),
 ("p0b-closure",[py,"-B","scripts/check_p0b_receipt_closure.py","--diff-file",str(diffpath),"--event","pull_request"]),
 ("owned-whitespace",G+["diff","--cached","--check",M])]
for name,args in commands:
 log=E/("macro-140bd-3b49-proof-"+name+".log");assert not log.exists();start=now()
 with log.open("xb") as f:r=subprocess.run(args,cwd=W,stdout=f,stderr=subprocess.STDOUT)
 item={"check":name,"command":args,"started_at":start,"finished_at":now(),"exit":r.returncode,"log":str(log),"bytes":log.stat().st_size,"sha256":dg(log.read_bytes())}
 validation["checks"].append(item);savej(vpath,validation)
 print(json.dumps({"check":name,"exit":r.returncode,"tail":log.read_text(errors="replace")[-2000:]}),flush=True)
 assert r.returncode==0,item
assert (W/HP).read_text()==newh and (W/WP).read_text()==neww
assert git("write-tree").decode().strip()==record and not git("diff","--name-only").strip()
validation.update(finished_at=now(),all_checks_pass=True,record_index_unchanged_during_checks=True,handoff_and_workstream_unchanged_during_checks=True)
savej(vpath,validation)
for c in validation["checks"]:include(pathlib.Path(c["log"]))
include(vpath);include(diffpath)
mf["documentation_validation"]={"receipt":vpath.name,"all_checks_exit0":True,"record_index":record,"agentos_exit":0,"template_sync_exit":0,"p0b_closure_exit":0,"owned_whitespace_exit":0,"handoff_and_workstream_unchanged_after_validation":True}
savemf();verify()
for row in oldrows:
 if row["file"]!="README.md":assert rows[row["file"]]==row,row["file"]
subprocess.run(G+["add","--",REL],check=True)
final=git("write-tree").decode().strip()
finaldocs=git("diff","--name-only",SOURCE,final).decode().splitlines()
assert all(allowed(p) for p in finaldocs)
assert not git("diff","--name-only").strip() and not git("ls-files","-u").strip()
assert not git("diff","--cached","--check",M).strip()
count=len(git("diff","--name-only",M,final).decode().splitlines());assert count<3000
out.update(finished_at=now(),status="PROOF_READY_NOT_COMMITTED_OR_PUSHED",final_index=final,documentation_only_paths=len(finaldocs),indexed_files=len(rows),added_files=added,skipped_existing_identical=skipped,manifest_bytes=(P/"MANIFEST.json").stat().st_size,manifest_sha256=dg((P/"MANIFEST.json").read_bytes()),candidate_paths_vs_incoming=count,validation_receipt_sha256=dg(vpath.read_bytes()),handoff_sha256=dg((W/HP).read_bytes()),workstream_sha256=dg((W/WP).read_bytes()),all_checks_pass=True,all_hashes_and_coverage_pass=True)
savej(OUT,out)
print(json.dumps({k:v for k,v in out.items() if k not in ("added_files","skipped_existing_identical")},indent=2),flush=True)
