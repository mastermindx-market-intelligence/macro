from pathlib import Path
import subprocess,json,datetime,hashlib
E=Path("/tmp/shared-shell-css-visual-20261019T1107");P=E/"macro-bd890-publication-preflight-remote.py";OUT=E/"macro-bd890-publication-preflight.json"
assert not OUT.exists()
raw=P.read_bytes()
cmd=["ssh","-i","/Users/chriswong/.ssh/macro_dashboard_deploy_v2","-o","BatchMode=yes","-o","IdentitiesOnly=yes","-o","IdentityAgent=none","-o","StrictHostKeyChecking=yes","-o","ConnectTimeout=8","root@146.190.142.17","python3 -I -B -"]
r={"started_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"command":cmd,"remote_source_sha256":hashlib.sha256(raw).hexdigest(),"scope":"Read-only existing publication prerequisite observation"}
p=subprocess.run(cmd,input=raw,capture_output=True,timeout=50)
for suffix,b in [(".stdout.json",p.stdout),(".stderr.log",p.stderr)]:
 q=E/("macro-bd890-publication-preflight"+suffix);assert not q.exists();q.write_bytes(b)
r.update(exit=p.returncode,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stdout_bytes=len(p.stdout),stderr_bytes=len(p.stderr),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
OUT.write_text(json.dumps(r,indent=2)+"\n");print(json.dumps(r,indent=2))
assert p.returncode==0 and not p.stderr
print(p.stdout.decode())
