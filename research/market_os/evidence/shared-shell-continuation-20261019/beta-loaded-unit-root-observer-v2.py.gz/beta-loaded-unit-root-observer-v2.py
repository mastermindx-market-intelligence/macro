import subprocess,json,hashlib,datetime,os,stat,shlex
UNIT="terminal-beta.service"
keys=["Id","Names","LoadState","ActiveState","SubState","UnitFileState","FragmentPath","DropInPaths","NeedDaemonReload","User","Group","MainPID","ExecMainStartTimestampMonotonic","Restart","TimeoutStopUSec","KillMode","KillSignal","SendSIGKILL","Requires","Wants","Requisite","RequisiteOf","BindsTo","PartOf","Conflicts","Before","After","RequiredBy","WantedBy","BoundBy","ConsistsOf","ConflictedBy","PropagatesStopTo","StopPropagatedFrom","OnFailure","OnSuccess","SuccessAction","FailureAction","JobTimeoutAction","StartLimitAction","StopWhenUnneeded","RefuseManualStop"]
hooks=["ExecStop","ExecStopPost","ExecReload"]
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def show():
 r=subprocess.run(["systemctl","show",UNIT,"--no-pager","--property="+",".join(keys+hooks)],capture_output=True,text=True,timeout=10)
 assert r.returncode==0 and not r.stderr,(r.returncode,r.stderr)
 d=dict(x.split("=",1) for x in r.stdout.splitlines() if "=" in x)
 h={}
 for k in hooks:
  v=d.pop(k,"");h[k]={"nonempty":bool(v),"sha256":hashlib.sha256(v.encode()).hexdigest()}
 return {"properties":d,"command_hooks":h}
def file(p):
 assert p.startswith(("/etc/systemd/system/","/usr/lib/systemd/system/","/lib/systemd/system/")),p
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
 try:
  s=os.fstat(fd);assert stat.S_ISREG(s.st_mode) and s.st_size<=65536,p
  b=os.read(fd,65537);assert len(b)==s.st_size
  s2=os.fstat(fd);assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(s2.st_dev,s2.st_ino,s2.st_size,s2.st_mtime_ns)
 finally:os.close(fd)
 named=os.lstat(p);assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(named.st_dev,named.st_ino,named.st_size,named.st_mtime_ns)
 active=[x.strip().split("=",1)[0] for x in b.decode().splitlines() if x.strip() and not x.lstrip().startswith(("#",";","[")) and "=" in x]
 return {"path":p,"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),"git_blob":hashlib.sha1(("blob "+str(len(b))+"\0").encode()+b).hexdigest(),"uid":s.st_uid,"gid":s.st_gid,"mode":oct(stat.S_IMODE(s.st_mode)),"device":s.st_dev,"inode":s.st_ino,"mtime_ns":s.st_mtime_ns,"directive_names":active,"path_binding_stable":True}
out={"started_at":now(),"scope":"Read-only loaded beta unit isolation and bounded file metadata/hash. No environment values, service operation, installer, lock operation or file mutation."}
out["before"]=show();p=out["before"]["properties"]
paths=[p["FragmentPath"]]+shlex.split(p.get("DropInPaths",""))
assert paths[0] and len(paths)<=16
out["files"]=[file(x) for x in paths]
out["after"]=show();out["observations_stable"]=out["before"]==out["after"]
out["finished_at"]=now()
print(json.dumps(out,indent=2))