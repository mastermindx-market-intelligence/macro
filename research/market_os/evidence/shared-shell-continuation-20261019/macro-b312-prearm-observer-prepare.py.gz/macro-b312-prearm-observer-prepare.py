import hashlib,json,pathlib
E=pathlib.Path("/tmp/shared-shell-css-visual-20261019T1107")
base=E/"macro-beta-before-e2d-publication-20261020T0536-remote.py"
target=E/"macro-b312-prearm-health-remote.py"
raw=base.read_bytes();assert hashlib.sha256(raw).hexdigest()=="c53b62c77cc27142fc31f20e771a50428be6311af72249eec6140e5a068e78c0"
assert not target.exists()
src=raw.decode()
extra=r'''
R93_SHA="c6759cc653e0f19102a015ec52842795bde24eb85766d2e73f3024b4eefe409d"
LOCK=pathlib.Path("/opt/terminal/.terminal-build-resource.lock")
def lmeta(p):
 try:
  s=p.lstat()
  return {"path":str(p),"exists":True,"type":"symlink" if stat.S_ISLNK(s.st_mode) else "directory" if stat.S_ISDIR(s.st_mode) else "regular" if stat.S_ISREG(s.st_mode) else "other","dev":s.st_dev,"ino":s.st_ino,"uid":s.st_uid,"gid":s.st_gid,"mode":oct(s.st_mode&0o777),"nlink":s.st_nlink,"bytes":s.st_size,"mtime_ns":s.st_mtime_ns}
 except FileNotFoundError:return {"path":str(p),"exists":False,"error":"ENOENT"}
 except OSError as ex:return {"path":str(p),"exists":None,"error":type(ex).__name__,"errno":ex.errno}
def hold_snapshot():
 out={"parent":lmeta(LOCK),"hold":lmeta(LOCK/"hold"),"owner":lmeta(LOCK/"hold"/"owner"),"archive_residue":[]}
 o=out["owner"];p=LOCK/"hold"/"owner"
 if o.get("type")=="regular" and o["bytes"]<=8192:
  try:
   fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
   try:
    before=os.fstat(fd);b=os.read(fd,8193);after=os.fstat(fd)
   finally:os.close(fd)
   shape=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns)
   o["read_identity_stable"]=shape(before)==shape(after) and before.st_dev==o["dev"] and before.st_ino==o["ino"] and len(b)==o["bytes"]
   o["sha256"]=hashlib.sha256(b).hexdigest()
   fields={}
   for line in b.decode("utf-8",errors="replace").splitlines():
    k,sep,v=line.partition("=")
    if sep and k in {"pid","uid","target","shared","started"}:
     if k in fields:o["duplicate_field"]=True
     fields[k]=v[:1024]
   o["declared_fields"]=fields
  except OSError as ex:o["read_error"]={"type":type(ex).__name__,"errno":ex.errno}
 if out["parent"].get("type")=="directory":
  try:out["archive_residue"]=[lmeta(p) for p in sorted(LOCK.glob("beta-bootstrap.*"))]
  except OSError as ex:out["archive_scan_error"]={"type":type(ex).__name__,"errno":ex.errno}
 return out
def release_process_snapshot():
 found=[];errors=[];vanished=0;shells=0
 for proc in pathlib.Path("/proc").iterdir():
  if not proc.name.isdigit():continue
  try:
   args=(proc/"cmdline").read_bytes()[:16384].split(b"\0")
   args=[a.decode("utf-8",errors="replace") for a in args if a]
   if not args or pathlib.Path(args[0]).name.lstrip("-") not in {"bash","sh","dash","zsh"}:continue
   shells+=1;i=1;inline=False
   while i<len(args) and args[i].startswith("-"):
    flag=args[i]
    if flag=="--":i+=1;break
    if not flag.startswith("--") and "c" in flag[1:]:inline=True;break
    i+=1
   if inline or i>=len(args):continue
   script=pathlib.Path(args[i])
   if not script.is_absolute():script=pathlib.Path(os.readlink(proc/"cwd"))/script
   st=script.stat()
   if not stat.S_ISREG(st.st_mode) or st.st_size>2097152:continue
   sha=hashlib.sha256(script.read_bytes()).hexdigest()
   if script.name!="terminal-build.sh" and sha!=R93_SHA:continue
   status=(proc/"stat").read_text();tail=status[status.rfind(")")+2:].split()
   found.append({"pid":int(proc.name),"uid":proc.stat().st_uid,"start_ticks":tail[19],"executable":os.readlink(proc/"exe"),"script":str(script),"script_sha256":sha,"matches_accepted_R93":sha==R93_SHA})
  except (FileNotFoundError,ProcessLookupError):vanished+=1
  except OSError as ex:errors.append({"pid":int(proc.name),"error":type(ex).__name__,"errno":ex.errno})
 return {"owners":found,"scan_errors":errors,"transient_vanished":vanished,"shell_processes_observed":shells,"matcher":"shell script argument: global basename terminal-build.sh or exact accepted R93 content SHA, including a private script-only copy; no environments or unrelated command lines retained","limitations":"Sample only; inline shell commands are not canonical script-owner invocations. No reservation or continuous-exclusion claim."}
def release_observation():
 return {"observed_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"lock":hold_snapshot(),"processes":release_process_snapshot()}
'''
src=src.replace("import datetime,hashlib,json,pathlib,subprocess,urllib.request,os","import datetime,hashlib,json,pathlib,subprocess,urllib.request,os,stat",1)
anchor="out={'observed_at':"
assert src.count(anchor)==1
src=src.replace(anchor,extra+"\n"+anchor,1)
anchor="props='ActiveState,SubState,UnitFileState,MainPID,ExecMainStartTimestampMonotonic'"
assert src.count(anchor)==1
src=src.replace(anchor,"out['scope']='read-only beta continuity, production before/after, and sampled canonical owner/hold; no installer, cleanup, browser/TLS bypass or reservation'\nout['release_before']=release_observation()\n"+anchor,1)
old="print(json.dumps(out,indent=2))"
assert src.count(old)==1
finish=r'''
out["production_after"]={"service":command(["systemctl","show","terminal.service","--property="+props]),"build":[identity(pathlib.Path("/opt/terminal/terminal")/n) for n in [".deployment-id",".next/BUILD_ID"]],"owner":file("/opt/terminal/terminal-build.sh")}
out["caddy_after"]=file("/etc/caddy/Caddyfile")
out["release_after"]=release_observation()
out["finished_at"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
print(json.dumps(out,indent=2))
'''
src=src.replace(old,finish,1)
compile(src,str(target),"exec")
target.write_text(src)
r={"operation":"prepare one-shot read-only prearm observer; no host connection/execution","base":str(base),"base_sha256":hashlib.sha256(raw).hexdigest(),"output":str(target),"bytes":len(src.encode()),"sha256":hashlib.sha256(src.encode()).hexdigest(),"compile_pass":True,"owner_source":"mastermind-terminal@93e303cc32566e72fb086af6d04ba3aa41866c5c:ops/terminal-build.sh","owner_blob":"25c24166d6a32ac851ee905afb2c36574bbb8e97"}
(E/"macro-b312-prearm-observer-preparation.json").write_text(json.dumps(r,indent=2)+"\n");print(json.dumps(r,indent=2))
