from pathlib import Path
import subprocess,json,hashlib,datetime
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","-C",str(W)]
H="da4df7d1e1ac709055c6fa1d482304a875e81824";M="9875169102cc6f36a64d465fe7c06f6bb8fb0220";REMOTE="b312bc4c08cf7633bf8fd259d2d46ec545fa120f";BRANCH="sol/market-os-shared-shell-design-20260924";OUT=E/"macro-da4d-987-source-commit.json"
def git(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert not OUT.exists()
tests=json.loads((E/"macro-da4d-987-composed-tests.json").read_text())
assert tests["pass"] and tests["index_unchanged"] and tests["source_unchanged"] and len(tests["commands"])==8
assert git("rev-parse","HEAD").decode().strip()==H and git("rev-parse","MERGE_HEAD").decode().strip()==M and git("branch","--show-current").decode().strip()==BRANCH
tree=git("write-tree").decode().strip();assert tree==tests["after"]["index_tree"]
assert not git("ls-files","-u").strip() and not git("diff","--name-only").strip()
remote=git("ls-remote","origin","refs/heads/"+BRANCH).decode().split();assert remote==[REMOTE,"refs/heads/"+BRANCH]
count=len(git("diff","--cached","--name-only",M).decode().splitlines());assert count<3000
subprocess.run(G+["diff","--cached","--check",M],check=True)
message=E/"macro-da4d-987-source-commit-message.txt";assert not message.exists()
message.write_text("Merge main into original Shared Shell delivery branch\n\nPreserve incoming render generations and existing shell adapters, keep all\nsix Sector views, emit the merged theme through its owner, and bind fresh\nHK/Canada fixture evidence while retaining both complete proof histories.\n\nIncludes the already reviewed About footer and labor copy repairs.\nExisting PR7949 remains the sole carrier; hosted admission and incumbent\nMacro rendering/publication remain separate gates.\n")
out={"started_at":now(),"state":"PRECHECKED_COMMIT_BEGIN","head_before":H,"incoming":M,"remote_before":REMOTE,"source_tree":tree,"changed_paths_vs_incoming":count,"test_receipt_sha256":dg((E/"macro-da4d-987-composed-tests.json").read_bytes()),"message_sha256":dg(message.read_bytes())}
def save():OUT.write_text(json.dumps(out,indent=2)+"\n")
save();log=E/"macro-da4d-987-source-commit.log";assert not log.exists()
with log.open("xb") as f:r=subprocess.run(G+["commit","-F",str(message)],stdout=f,stderr=subprocess.STDOUT)
out.update(commit_exit=r.returncode,log_bytes=log.stat().st_size,log_sha256=dg(log.read_bytes()));save();assert r.returncode==0
head=git("rev-parse","HEAD").decode().strip()
assert git("show","-s","--format=%P",head).decode().strip().split()==[H,M]
assert git("rev-parse","HEAD^{tree}").decode().strip()==tree and not git("status","--porcelain=v1").strip()
out.update(state="SOURCE_COMMITTED_LOCAL_ONLY",head_after=head,parents=[H,M],clean=True,pushed=False,finished_at=now());save();print(json.dumps(out,indent=2))
