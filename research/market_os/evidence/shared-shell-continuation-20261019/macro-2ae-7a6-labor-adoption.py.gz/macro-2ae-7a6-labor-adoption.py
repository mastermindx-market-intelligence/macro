from pathlib import Path
import subprocess,json,hashlib,datetime,os,sys,re,urllib.parse,html
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","-C",str(W)]
H="2ae6498d0b9f2a088af2e827abf6527799757f8c";M="7a6e21cb7d6a38855b7e06432c94f61acb0fe6f1";B="df3cba80e5ff43e3411209381b32d9d4df06bd1f";P="site/macro_labor_markets.html";OUT=E/"macro-2ae-7a6-labor-adoption.json";BACK=E/"macro-2ae-7a6-labor-before.html"
def git(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def ident(p):
 b=(W/p).read_bytes();return {"bytes":len(b),"sha256":dg(b)}
assert not OUT.exists() and not BACK.exists()
assert git("rev-parse","HEAD").decode().strip()==H and git("rev-parse","MERGE_HEAD").decode().strip()==M
s=json.loads((E/"macro-2ae-7a6-source-resolution.json").read_text());l=json.loads((E/"macro-2ae-7a6-labor-owner-render.json").read_text())
assert s["state"]=="FOUR_SOURCE_CONFLICTS_RESOLVED_STAGED" and l["state"]=="RENDERED_NOT_ADOPTED" and l["all_copy_guards_pass"] and l["source_and_data_unchanged"]
assert git("diff","--name-only","--diff-filter=U").decode().splitlines()==[P]
for stage,rev in [("1",B),("2",H),("3",M)]:assert git("rev-parse",":"+stage+":"+P)==git("rev-parse",rev+":"+P)
for p,r in {**l["source_inputs"],**l["data_inputs"]}.items():assert ident(p)=={k:r[k] for k in ["bytes","sha256"]},p
lr=next(x for x in l["pages"] if x["name"]=="macro_labor_markets.html");raw=Path(lr["path"]).read_bytes();assert len(raw)==lr["bytes"] and dg(raw)==lr["sha256"]
assets=set()
for value in re.findall(r'(?:src|href)=["\']([^"\']+)["\']',raw.decode()):
 u=urllib.parse.urlsplit(html.unescape(value))
 if u.scheme or u.netloc or not u.path:continue
 if Path(u.path).suffix not in {".css",".js",".svg",".png",".woff2",".ico"}:continue
 q=(W/"site"/u.path.lstrip("/")).resolve()
 assert q.is_relative_to((W/"site").resolve()) and q.is_file() and not q.is_symlink(),str(q)
 assets.add(str(q.relative_to(W)))
owners=["lib/pages.py","lib/shared_shell.py","lib/site_assets.py","scripts/optimize_assets.py"]
frozen={p:ident(p) for p in sorted(assets|set(owners))}
stage={}
for entry in git("ls-files","--stage","-z","--",*frozen).split(b"\0"):
 if not entry:continue
 left,p=entry.split(b"\t",1);mode,blob,index=left.decode().split();assert index=="0";stage[p.decode()]=blob
assert set(stage)==set(frozen)
for p,r in frozen.items():
 b=(W/p).read_bytes();assert hashlib.sha1(("blob "+str(len(b))+"\0").encode()+b).hexdigest()==stage[p],p
os.chdir(W);sys.path.insert(0,str(W))
from lib.pages import write_page,inject_text,dbase_prefix
from lib.shared_shell import inject_shared_shell_text
from scripts.optimize_assets import make_optimizer
from scripts.check_macro_command_copy import find_violations
opt=make_optimizer(W/"site");q=W/P;prefix=dbase_prefix(q)
def final(text):return opt(inject_shared_shell_text(inject_text(text,prefix),prefix,site_dir=W/"site"),q.parent)
candidate=final(raw.decode());assert final(candidate)==candidate and not find_violations(candidate)
out={"started_at":now(),"head":H,"incoming":M,"base":B,"state":"PREFLIGHT_PASS","render_receipt_sha256":dg((E/"macro-2ae-7a6-labor-owner-render.json").read_bytes()),"raw_owner_output":lr,"owner_asset_bindings":{p:{**r,"git_blob":stage[p]} for p,r in frozen.items()},"candidate_bytes":len(candidate.encode()),"candidate_sha256":dg(candidate.encode()),"copy_guard":[]}
def save():OUT.write_text(json.dumps(out,indent=2)+"\n")
save();BACK.write_bytes(q.read_bytes());out["before_sha256"]=dg(BACK.read_bytes());save()
write_page(q,candidate,encoding="utf-8");q.write_text(opt(q.read_text(),q.parent),encoding="utf-8");assert q.read_bytes()==candidate.encode()
for p,r in frozen.items():assert ident(p)==r,p
for p,r in {**l["source_inputs"],**l["data_inputs"]}.items():assert ident(p)=={k:r[k] for k in ["bytes","sha256"]},p
subprocess.run(G+["add","--",P],check=True);assert git("show",":"+P)==q.read_bytes()
assert not git("ls-files","-u").strip() and not git("diff","--name-only").strip()
out.update(state="ADOPTED_STAGED",finished_at=now(),index_tree=git("write-tree").decode().strip(),remaining_unmerged=[],unstaged=[],source_and_assets_unchanged=True);save()
print(json.dumps({k:v for k,v in out.items() if k!="owner_asset_bindings"},indent=2))
