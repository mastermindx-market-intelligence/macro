from pathlib import Path
import json,subprocess,hashlib,datetime,os
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","-C",str(W)]
H="608dfad299e2e48ab7703bf0b180e0dca1318229";M="df3cba80e5ff43e3411209381b32d9d4df06bd1f";B="9875169102cc6f36a64d465fe7c06f6bb8fb0220";branch="sol/market-os-shared-shell-design-20260924";OUT=E/"macro-608-df3-merge.json"
def g(*a):return subprocess.check_output(G+list(a)).decode().strip()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert not OUT.exists() and g("rev-parse","HEAD")==H and g("branch","--show-current")==branch and not g("status","--porcelain","--untracked-files=no")
assert g("ls-remote","origin","refs/heads/"+branch).split()[0]==H and g("merge-base",H,M)==B
assert subprocess.run(G+["rev-parse","--verify","MERGE_HEAD"],capture_output=True).returncode!=0
obj=json.loads((E/"macro-608-main-current-object-binding.json").read_text());assert obj["incoming"]==M and not obj["missing_objects_referenced_by_current_tree"]
out={"started_at":now(),"head_before":H,"incoming":M,"base":B,"state":"ORDINARY_MERGE_INTENT","scope":"Original worktree/branch only; actual dirty PR, no competing MOG writer; current incoming tree has no identified missing new objects. Historical13 missing objects are not asserted available."}
def save():OUT.write_text(json.dumps(out,indent=2)+"\n")
save();log=E/"macro-608-df3-merge.log";trace=E/"macro-608-df3-merge.trace.jsonl";cmd=G+["merge","--no-commit","--no-ff",M]
with log.open("xb") as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,"GIT_TRACE2_EVENT":str(trace)})
mh=subprocess.run(G+["rev-parse","--verify","MERGE_HEAD"],capture_output=True,text=True)
out.update(finished_at=now(),command=cmd,exit=p.returncode,log_bytes=log.stat().st_size,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),trace_bytes=trace.stat().st_size,head_after=g("rev-parse","HEAD"),merge_head=mh.stdout.strip() if mh.returncode==0 else None,unmerged=g("diff","--name-only","--diff-filter=U").splitlines(),unstaged=g("diff","--name-only").splitlines())
out["state"]="MERGE_OPEN_FOR_ORIGINAL_OWNER_RESOLUTION" if out["merge_head"]==M and out["head_after"]==H else "ACTUAL_MERGE_RESULT_REQUIRES_RECONCILIATION";save();print(json.dumps(out,indent=2))
