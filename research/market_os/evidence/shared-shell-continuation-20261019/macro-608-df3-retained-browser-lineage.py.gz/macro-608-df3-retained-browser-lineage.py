from pathlib import Path
import subprocess,json,hashlib,datetime
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","--no-optional-locks","-C",str(W)]
H="608dfad299e2e48ab7703bf0b180e0dca1318229";M="df3cba80e5ff43e3411209381b32d9d4df06bd1f";OUT=E/"macro-608-df3-retained-browser-lineage.json"
def git(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def row(p,expected=None):
 raw=(W/p).read_bytes();stage=git("show",":"+p);assert raw==stage,p
 if expected is not None:assert dg(raw)==expected,p
 return {"bytes":len(raw),"sha256":dg(raw),"stage_blob":git("rev-parse",":"+p).decode().strip()}
assert not OUT.exists()
before=git("write-tree").decode().strip()
assert before=="17f8cca6de011cb467cd13246c3cf076e56b9e05"
assert git("rev-parse","HEAD").decode().strip()==H and git("rev-parse","MERGE_HEAD").decode().strip()==M and not git("diff","--name-only").strip() and not git("ls-files","-u").strip()
ap=E/"macro-da4d-987-p0b-actual.json";bp=E/"macro-da4d-987-p0b-binding.json";a=json.loads(ap.read_text());b=json.loads(bp.read_text())
assert a["pass"] and a["source_unchanged"] and dg(ap.read_bytes())==b["producer"]["sha256"]=="b55bef40aa6cae2546122875f3e3d8044b5f1f0015aaa886bfc15b149bd8a6b0"
assert b["state"]=="ACTUAL_PROOF_BOUND_STAGED" and b["actual_cases"]==128 and b["screenshots"]==16 and len(a["source_before"])==67
sources={p:row(p,v["sha256"]) for p,v in a["source_before"].items()}
bound={p:row(p,h) for p,h in b["bound_inputs"].items()};assert len(bound)==56
expected={x["path"]:x["sha256"] for x in b["current_extension"]["screenshots"]}
expected.update({x["path"]:x["sha256"] for x in b["current_extension"]["browser_receipts"].values()})
x=b["current_extension"]["fixture_receipt"];expected[x["path"]]=x["sha256"]
expected["mockups/evidence/prophet-p0b-zero-fouc/manifest.json"]=b["manifest_after_sha256"]
assert set(expected)==set(b["selected_paths"]) and len(expected)==20
outputs={}
for p,h in expected.items():
 outputs[p]=row(p,h);assert (W/p).read_bytes()==git("show",H+":"+p),p
mf=json.loads((W/"mockups/evidence/prophet-p0b-zero-fouc/manifest.json").read_text())
am=E/"macro-da4d-987-about-manifest.json";ac=E/"macro-da4d-987-about-replay/actual.json";m=json.loads(am.read_text());c=json.loads(ac.read_text())
assert c["passed"] and c["contexts_closed"] and len(c["cells"])==8 and dg(am.read_bytes())==c["fixture_manifest_sha256"]
same={};changed={}
for path,v in m["files"].items():
 p="site"+path;r=row(p)
 if r["sha256"]==v["sha256"]:same[p]=r
 else:changed[p]={"old":v,"current":r}
assert len(same)==52 and list(changed)==["site/macro.html"]
response_paths=set()
for cell in c["cells"]:
 assert cell["passed"] and len(cell["keyboard"])==18
 for response in cell["responses"]:
  p="site"+response["path"];assert p in same and response["sha256"]==same[p]["sha256"] and response["status"]==200
  response_paths.add(p)
assert response_paths=={"site/about.html","site/shared_shell.css","site/landing.css"}
assert dg((W/"scripts/capture_page_evidence.py").read_bytes())==c["capture_owner_sha256"]
assert dg((E/"macro-da4d-987-about-replay.py").read_bytes())==c["runner_sha256"]
assert git("write-tree").decode().strip()==before and not git("diff","--name-only").strip()
out={"observed_at":now(),"head":H,"incoming":M,"source_index":before,"state":"RETAINED_FIXTURE_LINEAGE_VERIFIED","fresh_browser_execution":False,"p0b":{"producer_sha256":dg(ap.read_bytes()),"binding_sha256":dg(bp.read_bytes()),"source_inputs":sources,"bound_inputs":bound,"outputs":outputs,"case_count":128,"screenshot_count":16,"history_entries":12,"claim":"Retain actual 18:33-18:38 fixture proof; all 67 producer inputs, 56 bound inputs and 20 accepted outputs remain exact raw/staged bytes. No new browser run."},"about":{"actual_sha256":dg(ac.read_bytes()),"manifest_sha256":dg(am.read_bytes()),"unchanged_files":same,"changed_manifest_members":changed,"recorded_response_paths":sorted(response_paths),"claim":"Retain eight-cell About presentation/focus proof on identical About and all 52 presentation inputs. The unvisited macro.html changed: old 53-file manifest is historical, not fully current. No new route navigation, browser run, public proof or zoom claim."},"index_and_source_unchanged":True,"public_beta_acceptance":False,"terminal859_requalification":False}
OUT.write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps({"state":out["state"],"source_index":before,"p0b_sources":len(sources),"p0b_bound":len(bound),"p0b_outputs":len(outputs),"about_same":len(same),"about_changed":changed,"receipt_sha256":dg(OUT.read_bytes())},indent=2))
