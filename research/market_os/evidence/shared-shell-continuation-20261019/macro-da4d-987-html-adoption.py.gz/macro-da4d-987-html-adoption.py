from pathlib import Path
import subprocess,json,hashlib,datetime,os,sys
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");D=E/"macro-da4d-987-html-final-preview"
H="da4df7d1e1ac709055c6fa1d482304a875e81824";M="9875169102cc6f36a64d465fe7c06f6bb8fb0220";B="3b49d6a5c8a6330652a926a8e5061e0dbb3d0387"
OUT=E/"macro-da4d-987-html-adoption.json";BACK=E/"macro-da4d-987-html-before-adoption";G=["git","--no-optional-locks","-C",str(W)]
def git(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def ident(p):
 b=(W/p).read_bytes();return {"bytes":len(b),"sha256":dg(b)}
assert not OUT.exists() and not BACK.exists()
assert git("rev-parse","HEAD").decode().strip()==H and git("rev-parse","MERGE_HEAD").decode().strip()==M
preview=json.loads((D/"receipt.json").read_text());labor=json.loads((E/"macro-da4d-987-labor-owner-render.json").read_text())
assert preview["all_clean"] and preview["head"]==H and preview["incoming"]==M and len(preview["rows"])==25
assert labor["state"]=="RENDERED_NOT_ADOPTED" and labor["all_copy_guards_pass"] and labor["source_and_data_unchanged"]
for p,row in {**labor["source_inputs"],**labor["data_inputs"]}.items():assert ident(p)=={k:row[k] for k in ["bytes","sha256"]},p
for a in preview["assets"]:
 assert not a.get("missing"),a
 assert ident(a["path"])=={k:a[k] for k in ["bytes","sha256"]},a["path"]
 assert git("rev-parse",":"+a["path"]).decode().strip()==a["staged_blob"],a["path"]
ci=json.loads((E/"macro-da4d-987-ci-composition-preview.json").read_text())
for p,key in [(".github/ci/legacy-jobs.yml","manifest_sha256"),("tests/test_ci_pack.py","test_sha256")]:
 assert dg(git("show",":"+p))==ident(p)["sha256"]==ci[key],p
selected=[r["path"] for r in preview["rows"]]+["site/macro_labor_markets.html"]
unmerged=git("diff","--name-only","--diff-filter=U").decode().splitlines()
assert set(unmerged)==set(selected+["mockups/evidence/prophet-p0b-zero-fouc/"+x for x in ["manifest.json","mobile-layout.json","mobile-layout-canada.json"]])
for p in selected:
 for stage,rev in [("1",B),("2",H),("3",M)]:assert git("rev-parse",":"+stage+":"+p)==git("rev-parse",rev+":"+p),(p,stage)
os.chdir(W);sys.path.insert(0,str(W))
from lib.pages import write_page,inject_text,dbase_prefix
from lib.shared_shell import inject_shared_shell_text
from lib.site_assets import copy_asset
from scripts.optimize_assets import make_optimizer
opt=make_optimizer(W/"site")
ownerpaths=["lib/pages.py","lib/shared_shell.py","lib/site_assets.py","lib/config.py","scripts/optimize_assets.py","templates/data_base.js","config.yml"]
ownerbefore={p:ident(p) for p in ownerpaths}
def final(text,p):
 q=W/("site/chat.html" if p=="templates/chat.html" else p);prefix=dbase_prefix(q)
 return opt(inject_shared_shell_text(inject_text(text,prefix),prefix,site_dir=W/"site"),q.parent)
candidates={}
for row in preview["rows"]:
 raw=Path(row["candidate"]).read_bytes();assert len(raw)==row["candidate_bytes"] and dg(raw)==row["candidate_sha256"],row["path"]
 for v in row["parents"].values():assert dg(Path(v["file"]).read_bytes())==v["canonical_sha256"]
 text=raw.decode();assert "<<<<<<< " not in text and "?v=00000000" not in text
 cooked=final(text,row["path"]);assert cooked==text,("owner would change reviewed candidate",row["path"])
 candidates[row["path"]]=raw
assert candidates["templates/chat.html"]==candidates["site/chat.html"]
lp=next(x for x in labor["pages"] if x["name"]=="macro_labor_markets.html");lr=Path(lp["path"]).read_bytes();assert dg(lr)==lp["sha256"]
candidates["site/macro_labor_markets.html"]=final(lr.decode(),"site/macro_labor_markets.html").encode()
from scripts.check_macro_command_copy import find_violations
assert not find_violations(candidates["site/macro_labor_markets.html"].decode())
before_index=git("ls-files","--stage","-z")
out={"started_at":now(),"head":H,"incoming":M,"base":B,"state":"PREFLIGHT_PASS","preview_sha256":dg((D/"receipt.json").read_bytes()),"source_owner_before":ownerbefore,"asset_count":len(preview["assets"]),"CI_actual_raw_and_stage_match_preview":True,"four_whole_render_candidate_bytes_unchanged_from_reviewed_final_preview":True,"chat_source_pair_equal":True,"selected":selected,"before_index_sha256":dg(before_index),"rows":[]}
def save():OUT.write_text(json.dumps(out,indent=2)+"\n")
save();BACK.mkdir()
for p in selected:
 raw=(W/p).read_bytes();f=BACK/(p.replace("/","_"));f.write_bytes(raw)
 out["rows"].append({"path":p,"before_sha256":dg(raw),"backup":str(f),"candidate_bytes":len(candidates[p]),"candidate_sha256":dg(candidates[p])})
save()
for p in selected:
 if p=="site/chat.html":continue
 if p=="templates/chat.html":
  (W/p).write_bytes(candidates[p]);copy_asset("chat.html",W/"templates/chat.html",W/"site")
 else:
  q=W/p;write_page(q,candidates[p].decode(),encoding="utf-8");q.write_text(opt(q.read_text(),q.parent),encoding="utf-8")
 assert (W/p).read_bytes()==candidates[p],p
out["state"]="FILES_ADOPTED";save()
assert (W/"site/chat.html").read_bytes()==candidates["site/chat.html"]
assert {p:ident(p) for p in ownerpaths}==ownerbefore
for a in preview["assets"]:assert ident(a["path"])=={k:a[k] for k in ["bytes","sha256"]}
subprocess.run(G+["add","--",*selected],check=True)
for p in selected:assert git("show",":"+p)==candidates[p],p
out.update(state="ADOPTED_STAGED",finished_at=now(),owner_and_assets_unchanged=True,remaining_unmerged=git("diff","--name-only","--diff-filter=U").decode().splitlines(),after_index_sha256=dg(git("ls-files","--stage","-z")))
save();print(json.dumps({"state":out["state"],"selected":len(selected),"remaining_unmerged":out["remaining_unmerged"],"receipt":str(OUT),"sha256":dg(OUT.read_bytes())},indent=2))
