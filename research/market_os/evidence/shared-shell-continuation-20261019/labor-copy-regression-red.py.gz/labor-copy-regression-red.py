from pathlib import Path
import subprocess,json,hashlib,datetime
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107")
p=W/"tests/test_macro_command_copy_law.py";before=p.read_bytes()
anchor="\ndef test_machine_text_predicate_catches_slugs_tokens_and_iso() -> None:\n"
assert before.decode().count(anchor)==1
test='''
def test_labor_coverage_refusal_is_plain_without_claiming_neutral() -> None:
    from html import escape
    from lib.macro_suite_labels import PLAIN_FALLBACK, apply_plain_producer

    source = {
        "en": (
            "US labor-market state cannot be classified: axis coverage is below "
            "the disclosed floor. No quadrant is asserted rather than defaulting "
            "to a neutral state."
        ),
        "zh": "美国劳动力市场状态无法分类：轴覆盖低于披露下限。不默认中性状态，故不给出象限。",
    }
    unchanged = dict(source)
    reading, original = apply_plain_producer(source)

    assert source == unchanged
    assert original == unchanged
    assert original is not source
    assert reading is not None and reading != PLAIN_FALLBACK
    assert "not treated as neutral" in reading["en"]
    assert "不把信息缺失视为中性" in reading["zh"]
    customer = (
        '<main class="mc-shell"><p><span class="l-en">'
        + escape(reading["en"]) + '</span><span class="l-zh">'
        + escape(reading["zh"]) + "</span></p></main>"
    )
    assert guard.find_violations(customer) == []

'''
p.write_text(before.decode().replace(anchor,"\n"+test+anchor,1))
(E/"labor-copy-test-before.py").write_bytes(before)
r={"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"head":subprocess.check_output(["git","rev-parse","HEAD"],cwd=W,text=True).strip(),"delta":"new regression only, before labels repair","test_sha256":hashlib.sha256(p.read_bytes()).hexdigest()}
cmd=[str(W/".venv-shared-shell/bin/python"),"-B","-m","pytest","-q","tests/test_macro_command_copy_law.py::test_labor_coverage_refusal_is_plain_without_claiming_neutral"]
log=E/"labor-copy-regression-red.log"
with log.open("wb") as f:q=subprocess.run(cmd,cwd=W,stdout=f,stderr=subprocess.STDOUT)
r.update({"command":cmd,"exit":q.returncode,"finished_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"log_sha256":hashlib.sha256(log.read_bytes()).hexdigest()})
(E/"labor-copy-regression-red.json").write_text(json.dumps(r,indent=2)+"\n");print(json.dumps(r,indent=2));print(log.read_text()[-4000:])
assert q.returncode==1
