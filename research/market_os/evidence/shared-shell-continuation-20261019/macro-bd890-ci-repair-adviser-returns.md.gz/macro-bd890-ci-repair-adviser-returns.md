# Bounded adviser returns for the bd890 CI repairs

These are consultation records, not additional execution, independent hosted admission or merge authority.

## beta_recovery_counsel — press source review

NONBLOCKING for scripts/run_press.py SHA-256 c435e0d33b7672a9f5b792ace3d05c2bc3eaa8a5d6dc134cd6879be1f1c03968 and tests/test_press_run.py SHA-256 5fdf6e0bedb6add7bf31309b79ead1c1504004fd46a18f58d55dd4e5cab7ddee. The adviser read the actual implementation, new regression and repair receipt. Missing-only projection preserves text containing either marker; actual depth and explicit digests prevent asset provisioning; the inside-block substantive-content negative case protects against erasing real changes. No process or test rerun was performed. An older comparison docstring in _render_blog_subtree remains a nonblocking wording detail.

The subsequent dependency review was also NONBLOCKING. Root's bounded YAML read established explicit ticker-news-qbus paths for lib/shared_shell.py, lib/pages.py and lib/site_assets.py; the adviser read the existing runner and scope-owner headers. This resolves the named new-import risk without broadening the selector. It is not a complete dependency audit or a new-head CI result.

## sector_rig_counsel — canonical About receipt review

NONBLOCKING for exact-byte adoption and the three-key receipt. The adviser read the complete canonical manifest, smell report and wrapper receipt. All eight REST combinations have matching requested/applied locale and theme and positive PNG dimensions. Four distinct PNGs are consistent with content-addressed deduplication of the observed LIGHT_ONLY palette. The actual local billing 404 and console error, aggregate geometry sampling limits, anonymous-only scope and declared auth/state gaps must remain visible.

The adviser did not independently hash source or image bytes, inspect the screenshots visually, execute the capture, or run the guard. Root subsequently inspected all four unique PNGs, verified copied bytes and all 53 fixture inputs, and ran the actual existing guard with exit 0; those actions are recorded separately in macro-bd890-about-adoption.json.

Terminal #859 and accepted R93 recovery remain outside both reviews.
