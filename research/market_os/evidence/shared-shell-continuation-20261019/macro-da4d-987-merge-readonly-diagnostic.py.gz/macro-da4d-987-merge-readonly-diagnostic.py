from pathlib import Path
import subprocess,json
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");G=["git","-C",str(W)]
ps=subprocess.check_output(["ps","-axo","pid=,ppid=,etime=,stat=,comm="],text=True).splitlines()
rows=[]
for line in ps:
 a=line.strip().split(None,4)
 if len(a)==5:
  try:rows.append({"pid":int(a[0]),"ppid":int(a[1]),"elapsed":a[2],"state":a[3],"comm":a[4]})
  except ValueError:pass
ids={60909}
for _ in range(5):ids.update(r["pid"] for r in rows if r["ppid"] in ids)
print("OWNED_PROCESS_TREE",json.dumps([r for r in rows if r["pid"] in ids],indent=2))
for key in ["remote.origin.url","remote.origin.promisor","remote.origin.partialclonefilter","extensions.partialClone"]:
 r=subprocess.run(G+["config","--get",key],capture_output=True,text=True);print("CONFIG",key,r.returncode,r.stdout.strip())
r=subprocess.run(G+["ls-tree","-r","9875169102cc6f36a64d465fe7c06f6bb8fb0220"],capture_output=True,text=True,timeout=60)
print("INCOMING_OBJECT_PATH",json.dumps([line for line in r.stdout.splitlines() if "30d1e9578fdd46cc944321c84b1075e75088be7b" in line]))
print("MERGE_HEAD",subprocess.run(G+["rev-parse","-q","--verify","MERGE_HEAD"],capture_output=True,text=True).stdout.strip())
print("MERGE_LOG",Path("/tmp/shared-shell-css-visual-20261019T1107/macro-da4d-987-merge.log").read_text(errors="replace")[-5000:])
