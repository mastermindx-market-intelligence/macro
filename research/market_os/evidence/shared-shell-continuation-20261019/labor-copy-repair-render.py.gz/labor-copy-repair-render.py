from pathlib import Path
import sys,subprocess,json,hashlib,datetime,difflib
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107")
sys.path.insert(0,str(W))
p=W/"lib/macro_suite_labels.py";before=p.read_bytes()
anchor="PLAIN_PRODUCER: tuple[tuple[str, dict[str, str]], ...] = (\n"
assert before.decode().count(anchor)==1
entry='''    (
        "US labor-market state cannot be classified: axis coverage is below "
        "the disclosed floor. No quadrant is asserted rather than defaulting "
        "to a neutral state.",
        _pair(
            "The available labor-market readings do not meet the stated coverage "
            "requirement, so US labor-market conditions cannot be classified. "
            "No classification is shown; missing information is not treated as neutral.",
            "现有劳动力市场读数未达到已说明的覆盖要求，因此无法判断美国劳动力市场状况。"
            "暂不提供分类，也不把信息缺失视为中性。",
        ),
    ),
'''
p.write_text(before.decode().replace(anchor,anchor+entry,1));(E/"labor-copy-labels-before.py").write_bytes(before)
from scripts import build_macro_suite_pages as builder
from scripts import check_macro_command_copy as guard
out=E/"labor-copy-render"/"site";assert not out.exists()
stamp=datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
pages=builder.render(W,data_root=W/"site/macrodata",out_dir=out,page_built_at=stamp)
rows=[]
for page in pages:
 old=W/"site"/page.name;raw=page.read_bytes();previous=old.read_bytes() if old.exists() else b""
 rows.append({"name":page.name,"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"differs_from_committed":raw!=previous,"copy_guard":guard.find_violations(raw.decode())})
labor=out/"macro_labor_markets.html"
patch="".join(difflib.unified_diff((W/"site/macro_labor_markets.html").read_text().splitlines(True),labor.read_text().splitlines(True),fromfile="site/macro_labor_markets.html",tofile="canonical-preview/macro_labor_markets.html"))
(E/"labor-copy-generated-preview.patch").write_text(patch)
r={"started_at":stamp,"source_head":subprocess.check_output(["git","rev-parse","HEAD"],cwd=W,text=True).strip(),"working_delta":subprocess.check_output(["git","diff","--name-only"],cwd=W,text=True).splitlines(),"labels_sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"owner":"scripts.build_macro_suite_pages.render","args":{"root":str(W),"data_root":str(W/"site/macrodata"),"out_dir":str(out),"page_built_at":stamp},"pages":rows,"adopted":False,"patch_bytes":len(patch.encode()),"patch_sha256":hashlib.sha256(patch.encode()).hexdigest(),"finished_at":datetime.datetime.now(datetime.timezone.utc).isoformat()}
(E/"labor-copy-render.json").write_text(json.dumps(r,indent=2)+"\n")
print(json.dumps({"pages":len(rows),"dirty":[x for x in rows if x["copy_guard"]],"labor":next(x for x in rows if x["name"]=="macro_labor_markets.html"),"patch_bytes":r["patch_bytes"],"adopted":False},indent=2))
