from pathlib import Path
import subprocess,json,hashlib,datetime,importlib.util,time,sys,signal
E=Path("/tmp/shared-shell-css-visual-20261019T1107");OUT=E/"beta-same-a-service-proof.json";BFILE=E/"beta-same-a-service-boundary.py"
assert not OUT.exists()
def interrupted(signum,frame):raise InterruptedError("Attended wrapper interrupted by signal "+str(signum))
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
spec=importlib.util.spec_from_file_location("beta_boundary",BFILE);b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
pre=json.loads((E/"beta-same-a-preflight.json").read_text());assert pre["state"]=="READ_ONLY_PREFLIGHT_PASS" and not pre["stop_or_start_executed"]
boundary_sha=b.dg(BFILE.read_bytes())
out={"started_at":b.now(),"state":"FRESH_BOUNDARY_BEGIN","scope":"One attended stop and start of already accepted terminal-beta.service A. No release transaction, installer, source/pointer mutation, enablement change, Caddy/DNS operation or production service operation.","accepted_A":b.A,"boundary_source_sha256":boundary_sha,"preflight_sha256":b.dg((E/"beta-same-a-preflight.json").read_bytes()),"operations":[],"observations":[],"full_hostname_withdrawal":False,"A_to_B_to_A":False,"public_acceptance":False,"reservation":False}
def save():OUT.write_text(json.dumps(out,indent=2)+"\n")
def observe(phase):
 h,hr=b.run_read("health",phase);u,ur=b.run_read("unit",phase)
 out["observations"].append({"phase":phase,"health":hr,"unit":ur});save();return h,u
def effect(action):
 assert action in ["stop","start"] and not any(x["action"]==action for x in out["operations"])
 row={"action":action,"unit":"terminal-beta.service","started_at":b.now(),"command":b.BASE+["systemctl",action,"terminal-beta.service"],"state":"INTENT_RECORDED"};out["operations"].append(row);save()
 log=E/("beta-same-a-"+action+".stdout.log");err=E/("beta-same-a-"+action+".stderr.log");assert not log.exists() and not err.exists()
 try:
  with log.open("xb") as f,err.open("xb") as e:r=subprocess.run(row["command"],stdout=f,stderr=e,timeout=45)
  row.update(exit=r.returncode,state="RETURNED")
 except subprocess.TimeoutExpired:row.update(exit=None,state="CALL_TIMED_OUT_EFFECT_REQUIRES_OBSERVATION")
 row.update(finished_at=b.now(),stdout={"bytes":log.stat().st_size,"sha256":b.dg(log.read_bytes())},stderr={"bytes":err.stat().st_size,"sha256":b.dg(err.read_bytes())});save();return row
def refused_connection():
 code=b'import socket,json,errno\nr={"host":"127.0.0.1","port":3001,"fresh_connection":True}\ntry:\n s=socket.create_connection(("127.0.0.1",3001),2);s.close();r.update(connected=True,refused=False)\nexcept OSError as e:r.update(connected=False,refused=e.errno==errno.ECONNREFUSED,errno=e.errno,error=type(e).__name__)\nprint(json.dumps(r))\n'
 p=subprocess.run(b.BASE+["python3 -I -B -"],input=code,capture_output=True,timeout=10)
 raw=E/"beta-same-a-stopped-connect.stdout.json";err=E/"beta-same-a-stopped-connect.stderr.log";assert not raw.exists() and not err.exists();raw.write_bytes(p.stdout);err.write_bytes(p.stderr)
 row={"at":b.now(),"exit":p.returncode,"stdout_sha256":b.dg(p.stdout),"stderr_sha256":b.dg(p.stderr)}
 assert p.returncode==0 and not p.stderr,row
 row["result"]=json.loads(p.stdout);return row
def normalized_static(d):
 relations={"Requires","Wants","Requisite","RequisiteOf","BindsTo","PartOf","Conflicts","Before","After","RequiredBy","WantedBy","BoundBy","ConsistsOf","ConflictedBy","PropagatesStopTo","StopPropagatedFrom","OnFailure","OnSuccess"}
 return {k:sorted(set(v.split())) if k in relations else v for k,v in d.items()}
def identical_candidate(h,u,active):
 service=b.validate_health(h,active);static=normalized_static(b.validate_unit(u,active))
 assert b.beta_identity(h)==before_identity and static==before_static
 assert all(u["before"]["properties"][k]==service[k] for k in service)
 return service
save();before_identity=None;before_static=None;baseline=None;failure=None
try:
 h,u=observe("effect-before")
 svc=b.validate_health(h,True);before_static=normalized_static(b.validate_unit(u,True));before_identity=b.beta_identity(h);baseline=b.production(h)
 assert before_identity==pre["beta_identity"] and before_static==normalized_static(pre["unit_static"])
 assert all(u["before"]["properties"][k]==svc[k] for k in svc)
 out.update(state="FRESH_BOUNDARY_PASS",before_service=svc,before_identity=before_identity,production_baseline=baseline,preflight_production_equal=baseline==pre["production_baseline"]);save()
 stop=effect("stop")
 h,u=observe("effect-stopped");stopped=identical_candidate(h,u,False)
 connection=refused_connection();out["stopped_connection"]=connection
 assert connection["result"]["refused"] is True and connection["result"]["connected"] is False
 out.update(state="WITHDRAWAL_OBSERVED",stopped_service=stopped,stopped_production_unchanged=b.production(h)==baseline);save()
 start=effect("start")
 # Allow the existing process a bounded startup interval; all ensuing gates remain strict.
 time.sleep(2)
 h,u=observe("effect-recovered")
 recovered=identical_candidate(h,u,True)
 assert (recovered["MainPID"],recovered["ExecMainStartTimestampMonotonic"])!=(svc["MainPID"],svc["ExecMainStartTimestampMonotonic"])
 assert int(recovered["ExecMainStartTimestampMonotonic"])>int(svc["ExecMainStartTimestampMonotonic"])
 out.update(recovered_service=recovered,recovered_identity_unchanged=True,recovered_production_unchanged=b.production(h)==baseline)
 out["pass"]=stop["exit"]==0 and start["exit"]==0 and out["stopped_production_unchanged"] and out["recovered_production_unchanged"]
 out["state"]="SAME_A_SERVICE_PROOF_PASS" if out["pass"] else "RECOVERED_A_PROOF_NOT_ACCEPTED"
except (Exception,KeyboardInterrupt) as error:
 failure=repr(error);out.update(state="EFFECT_RECONCILIATION_REQUIRED",error=failure);out["pass"]=False;save()
 # One bounded state reconciliation; never repeat stop or start.
 if any(x["action"]=="stop" for x in out["operations"]) and not any(x["action"]=="start" for x in out["operations"]):
  try:
   h,u=observe("exception-reconciliation")
   current=b.props(h["beta_after"])
   if current["ActiveState"]=="inactive" and current["SubState"]=="dead":
    identical_candidate(h,u,False)
    out["recovery_reason"]="Accepted A/unit/lifecycle/release predicates still hold after interrupted proof; recover beta availability once";save()
    effect("start")
    h,u=observe("exception-after-start");out["recovered_service"]=identical_candidate(h,u,True);out["state"]="RECOVERED_A_AFTER_PROOF_FAILURE"
   elif current["ActiveState"]=="active" and current["SubState"]=="running":
    out["recovered_service"]=identical_candidate(h,u,True);out["state"]="A_ACTIVE_NO_SECOND_OPERATION"
   else:out["recovery_blocker"]="Existing unit still transitional; actual state needs reconciliation before another operation"
  except Exception as error2:out["recovery_blocker"]=repr(error2)
finally:
 out["boundary_source_unchanged"]=b.dg(BFILE.read_bytes())==boundary_sha
 out["pass"]=bool(out.get("pass") and out["boundary_source_unchanged"])
 if not out["boundary_source_unchanged"]:out["state"]="SOURCE_CHANGED_PROOF_NOT_ACCEPTED"
 out["finished_at"]=b.now();save()
print(json.dumps({k:v for k,v in out.items() if k not in ["before_identity","production_baseline","observations"]},indent=2))
sys.exit(0 if out.get("pass") and out["boundary_source_unchanged"] else 1)
