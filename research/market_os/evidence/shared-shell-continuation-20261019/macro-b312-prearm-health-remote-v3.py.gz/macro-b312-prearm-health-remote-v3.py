"""Read-only sampled admission evidence. Never acquires/releases a lock or invokes an installer."""
import contextlib,datetime,errno,hashlib,json,os,pathlib,selectors,stat,subprocess,time,urllib.request
B=pathlib.Path("/opt/terminal/beta")
LOCK=pathlib.Path("/opt/terminal/.terminal-build-resource.lock")
R93_SHA="c6759cc653e0f19102a015ec52842795bde24eb85766d2e73f3024b4eefe409d"
R93_BYTES=207242
D_FLAGS=os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW
F_FLAGS=os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def dg(b): return hashlib.sha256(b).hexdigest()
def meta(s):
 return {"dev":s.st_dev,"ino":s.st_ino,"uid":s.st_uid,"gid":s.st_gid,"mode":oct(s.st_mode&0o7777),"kind":"directory" if stat.S_ISDIR(s.st_mode) else "regular" if stat.S_ISREG(s.st_mode) else "symlink" if stat.S_ISLNK(s.st_mode) else "other","nlink":s.st_nlink,"bytes":s.st_size,"mtime_ns":s.st_mtime_ns,"ctime_ns":s.st_ctime_ns}
def shape(s): return (s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
def dirshape(s): return (s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid)
@contextlib.contextmanager
def parent_fd(path):
 p=pathlib.PurePosixPath(path)
 if not p.is_absolute() or ".." in p.parts: raise ValueError("absolute normalized path required")
 fds=[os.open("/",D_FLAGS)];edges=[];opened=[os.fstat(fds[0])]
 try:
  for part in p.parts[1:-1]:
   fd=os.open(part,D_FLAGS,dir_fd=fds[-1]);edges.append((fds[-1],part,fd));fds.append(fd);opened.append(os.fstat(fd))
  def stable():
   return all(dirshape(os.fstat(fd))==dirshape(s) for fd,s in zip(fds,opened)) and all(dirshape(os.stat(n,dir_fd=a,follow_symlinks=False))==dirshape(os.fstat(b)) for a,n,b in edges)
  def trusted():
   return all(s.st_uid==0 and not(s.st_mode&0o022) for s in opened)
  yield fds[-1],p.name,stable,trusted
 finally:
  for fd in reversed(fds):os.close(fd)
def bounded(fd,limit):
 chunks=[];left=limit+1
 while left:
  b=os.read(fd,min(left,65536))
  if not b:break
  chunks.append(b);left-=len(b)
 b=b"".join(chunks)
 return b[:limit],len(b)>limit
def read_file(path,limit=4194304,text=False,pointer_root=None):
 row={"path":str(path)}
 try:
  with parent_fd(path) as (parent,name,stable,trusted):
   named=os.stat(name,dir_fd=parent,follow_symlinks=False)
   if stat.S_ISLNK(named.st_mode):
    if pointer_root is None: raise ValueError("unexpected leaf symlink")
    target=os.readlink(name,dir_fd=parent)
    if not os.path.isabs(target) or pathlib.PurePosixPath(target).parent!=pathlib.PurePosixPath(pointer_root) or ".." in pathlib.PurePosixPath(target).parts: raise ValueError("lifecycle target outside accepted record directory")
    row=read_file(target,limit,text)
    link_stable=shape(named)==shape(os.stat(name,dir_fd=parent,follow_symlinks=False)) and target==os.readlink(name,dir_fd=parent) and stable()
    target_trusted=bool(row.get("ancestor_trusted"));pointer_trusted=trusted()
    row.update(path=str(path),resolved=target,pointer_metadata=meta(named),pointer_stable=link_stable,target_ancestor_trusted=target_trusted,pointer_ancestor_trusted=pointer_trusted,ancestor_trusted=target_trusted and pointer_trusted)
    row["read_complete"]=bool(row.get("read_complete") and link_stable and target_trusted and pointer_trusted)
    return row
   fd=os.open(name,F_FLAGS,dir_fd=parent)
   try:
    before=os.fstat(fd)
    if not stat.S_ISREG(before.st_mode):raise ValueError("not a regular file")
    if before.st_size>limit:raise ValueError("file exceeds bounded read limit")
    raw,truncated=bounded(fd,limit);after=os.fstat(fd)
    same=shape(before)==shape(after)==shape(named)==shape(os.stat(name,dir_fd=parent,follow_symlinks=False)) and stable() and len(raw)==before.st_size
   finally:os.close(fd)
   row.update(exists=True,resolved=str(path),metadata=meta(before),bytes=len(raw),sha256=dg(raw),identity_stable=same,ancestor_trusted=trusted(),truncated=truncated,read_complete=same and not truncated)
   if text:row["text"]=raw.decode("utf-8").strip()
 except (OSError,ValueError,UnicodeError) as e:
  row.update(exists=False if isinstance(e,OSError) and e.errno==errno.ENOENT else None,read_complete=False,error=type(e).__name__,errno=getattr(e,"errno",None),detail=str(e)[:300])
 return row
def hold_snapshot():
 out={"parent_path":str(LOCK),"hold_present":None,"complete":False,"archives":[],"archive_scan_truncated":False}
 try:
  with parent_fd(LOCK/"hold") as (lockfd,name,stable,trusted):
   lockst=os.fstat(lockfd);out["parent"]=meta(lockst)
   out["ancestor_and_parent_trusted"]=trusted() and lockst.st_uid==0 and not(lockst.st_mode&0o022)
   try: hs=os.stat(name,dir_fd=lockfd,follow_symlinks=False)
   except FileNotFoundError: hs=None
   out["hold_present"]=hs is not None
   if hs is not None:
    out["hold"]=meta(hs)
    # Any hold object excludes admission; owner fields are diagnostics only.
    if stat.S_ISDIR(hs.st_mode):
     owner=read_file(LOCK/"hold"/"owner",8192,True)
     raw=owner.pop("text",None)
     if raw is not None:
      fields={};duplicate=False;malformed=False
      for line in raw.splitlines():
       k,sep,v=line.partition("=")
       if sep and k in {"pid","uid","target","shared","started"}:
        duplicate|=k in fields;fields[k]=v[:1024]
        malformed|=len(v)>1024
       else:malformed=True
      owner.update(declared_fields=fields,duplicate_field=duplicate,malformed_field=malformed)
     out["owner"]=owner
     out["hold_identity_stable"]=shape(hs)==shape(os.stat(name,dir_fd=lockfd,follow_symlinks=False))
   count=0
   with os.scandir(lockfd) as entries:
    for item in entries:
     count+=1
     if count>512:out["archive_scan_truncated"]=True;break
     if item.name=="hold":
      out["hold_present"]=True;out["hold_observed_in_enumeration"]=True
     if item.name.startswith("beta-bootstrap."):
      if len(out["archives"])>=64:out["archive_scan_truncated"]=True;break
      out["archives"].append({"name":item.name[:200],"metadata":meta(item.stat(follow_symlinks=False))})
   try:
    final_hold=os.stat(name,dir_fd=lockfd,follow_symlinks=False)
    out["hold_present"]=True;out["final_hold"]=meta(final_hold)
   except FileNotFoundError:out["final_hold_absent"]=True
   out["path_identity_stable"]=stable()
   out["complete"]=out["path_identity_stable"] and out["ancestor_and_parent_trusted"] and not out["archive_scan_truncated"]
 except (OSError,ValueError) as e:
  out["error"]={"type":type(e).__name__,"errno":getattr(e,"errno",None),"detail":str(e)[:300]}
 return out
def read_at(fd,name,limit):
 f=os.open(name,F_FLAGS,dir_fd=fd)
 try:return bounded(f,limit)
 finally:os.close(f)
def proc_sig(fd):
 raw,truncated=read_at(fd,"stat",8192)
 if truncated:raise ValueError("truncated proc stat")
 t=raw.decode();tail=t[t.rfind(")")+2:].split()
 if len(tail)<20:raise ValueError("incomplete proc stat")
 return {"start_ticks":tail[19],"uid":os.fstat(fd).st_uid}
def release_process_snapshot():
 owners=[];errors=[];error_count=0;vanished=0;changed=0;shells=0;seen=0;enumeration_truncated=False
 def err(pid,kind,detail=""):
  nonlocal error_count
  error_count+=1
  if len(errors)<64:errors.append({"pid":pid,"kind":kind,"detail":detail[:300]})
 with os.scandir("/proc") as entries:
  for entry in entries:
   if not entry.name.isdecimal():continue
   seen+=1
   if seen>16384:enumeration_truncated=True;break
   pid=int(entry.name);fd=None;before=None;candidate=None
   try:
    fd=os.open(entry.path,D_FLAGS);before=proc_sig(fd)
    raw,truncated=read_at(fd,"cmdline",16384)
    if truncated:raise ValueError("truncated cmdline classification")
    args=[x.decode("utf-8",errors="strict") for x in raw.split(b"\0") if x]
    if raw and not raw.endswith(b"\0"):raise ValueError("unterminated cmdline classification")
    if not args or pathlib.PurePosixPath(args[0]).name.lstrip("-") not in {"bash","sh","dash","zsh"}:continue
    shells+=1;i=1;inline=False
    while i<len(args) and args[i].startswith(("-","+")):
     flag=args[i]
     if flag=="--":i+=1;break
     if flag.startswith("-") and not flag.startswith("--") and "c" in flag[1:]:inline=True;break
     i+=2 if flag in {"-o","+o","--rcfile","--init-file"} else 1
    if inline or i>=len(args):continue
    script=pathlib.Path(args[i])
    if not script.is_absolute():script=pathlib.Path(os.readlink("cwd",dir_fd=fd))/script
    basename_candidate=script.name=="terminal-build.sh"
    if basename_candidate:candidate={"pid":pid,**before,"script":str(script),"basename_match":True}
    # A renamed exact R93 owner has this byte length. Other live unreadable
    # script paths remain incomplete; ENOENT is not called a vanished PID.
    st=script.stat()
    if basename_candidate or (stat.S_ISREG(st.st_mode) and st.st_size==R93_BYTES):
     f=read_file(script,2097152)
     if candidate is None and f.get("sha256")==R93_SHA:candidate={"pid":pid,**before,"script":str(script),"basename_match":False}
     if candidate is not None:
      candidate.update(script_identity=f,matches_accepted_R93=f.get("sha256")==R93_SHA)
     if not f.get("read_complete"):raise ValueError("live script identity unreadable or unstable")
    after=proc_sig(fd)
    if after!=before:changed+=1
    if candidate is not None:
     candidate["same_process_after"]=after==before;owners.append(candidate);candidate=None
   except (OSError,ValueError,UnicodeError) as e:
    same_live=None
    if fd is not None:
     try:
      rechecked=proc_sig(fd)
      same_live=True
      if before is not None and rechecked!=before:
       changed+=1;err(pid,"process_identity_changed_during_classification")
     except OSError as e2:
      if e2.errno in {errno.ENOENT,errno.ESRCH}:same_live=False;vanished+=1
      else:err(pid,"process_identity_recheck_failed",type(e2).__name__)
     except ValueError as e2:err(pid,"process_identity_recheck_incomplete",str(e2))
    elif isinstance(e,OSError) and e.errno in {errno.ENOENT,errno.ESRCH}:same_live=False;vanished+=1
    if same_live is not False:err(pid,"live_or_unresolved_classification_failure",type(e).__name__+": "+str(e))
    if candidate is not None:
     candidate.update(same_process_after=same_live,classification_error=type(e).__name__)
     owners.append(candidate)
   finally:
    if fd is not None:os.close(fd)
 return {"owners":owners[:64],"owner_output_truncated":len(owners)>64,"scan_errors":errors,"scan_error_count":error_count,"error_output_truncated":error_count>64,"transient_vanished":vanished,"identity_changed":changed,"shell_processes_observed":shells,"processes_sampled":seen,"enumeration_truncated":enumeration_truncated,"complete":not(error_count or enumeration_truncated or len(owners)>64 or changed),"matcher":"shell script argument basename terminal-build.sh or exact accepted R93 content SHA including private copies","limits":"Sample only, no reservation. Inline shell wrappers are not canonical script invocations; their separately executing script child is the match. No environment or unrelated full command line retained."}
def release_observation():
 lock=hold_snapshot();processes=release_process_snapshot()
 return {"at":now(),"lock":lock,"processes":processes,"sample_clear":lock["complete"] and lock["hold_present"] is False and processes["complete"] and not processes["owners"],"reservation":False}
def command(argv,limit=65536):
 p=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 out={"argv":argv};buffers={"stdout":bytearray(),"stderr":bytearray()};sel=selectors.DefaultSelector();over=False;timedout=False;deadline=time.monotonic()+25
 for name,pipe in (("stdout",p.stdout),("stderr",p.stderr)):sel.register(pipe,selectors.EVENT_READ,name)
 try:
  while sel.get_map():
   remain=deadline-time.monotonic()
   if remain<=0:timedout=True;break
   for key,_ in sel.select(min(remain,1)):
    b=os.read(key.fileobj.fileno(),min(4096,limit-len(buffers[key.data])+1))
    if not b:sel.unregister(key.fileobj);continue
    buffers[key.data].extend(b)
    if len(buffers[key.data])>limit:over=True;break
   if over:break
  if over or timedout:p.kill()
  p.wait(timeout=3)
 finally:
  sel.close();p.stdout.close();p.stderr.close()
 out.update(exit=p.returncode,truncated=over,timed_out=timedout)
 out.update({k:bytes(v[:limit]).decode(errors="replace") for k,v in buffers.items()})
 return out
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*a,**kw):return None
def status():
 out={}
 try:
  opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
  with opener.open("http://127.0.0.1:3001/api/shared-shell/status",timeout=15) as r:
   raw=r.read(65537);over=len(raw)>65536
   out={"status":r.status,"headers":{k:v[:1024] for k,v in r.headers.items() if k.lower() in {"content-type","content-length","cache-control"}},"bytes":len(raw),"raw_sha256":dg(raw),"truncated":over,"proxy_disabled":True,"redirects_disabled":True}
   if not over:out["body"]=json.loads(raw)
 except Exception as e:out.update(error=type(e).__name__,detail=str(e)[:300])
 return out
def marker(p):return read_file(p,4096,True)
def stages():
 out=[];count=0;truncated=False
 with os.scandir(B) as it:
  for item in it:
   count+=1
   if count>512:truncated=True;break
   if item.name.startswith(".stage."):out.append({"name":item.name,"metadata":meta(item.stat(follow_symlinks=False))})
 return {"entries":out,"truncated":truncated}
props="ActiveState,SubState,UnitFileState,MainPID,ExecMainStartTimestampMonotonic"
def service(n):return command(["systemctl","show",n,"--property="+props])
def build(root):return [marker(root/n) for n in (".deployment-id",".next/BUILD_ID")]
out={"observed_at":now(),"scope":"read-only sampled beta continuity, production before/after, canonical release owner/hold, Macro publication files; no installer, cleanup, mutation or reservation"}
out["release_before"]=release_observation()
out["services"]={n:service(n) for n in ("terminal.service","terminal-beta.service")}
out["beta_source_HEAD"]=command(["git","--no-optional-locks","-C","/opt/terminal/.gitsrc-beta","rev-parse","HEAD"])
out["runtime_pointer"]=read_file(B/".runtime-accepted",65536,pointer_root="/var/lib/mastermind-terminal-beta/source-provisioned")
out["source_pointer"]=read_file(B/".source-provisioned",65536,pointer_root="/var/lib/mastermind-terminal-beta/source-provisioned")
out["beta_build"]=build(B/"terminal")
out["production_build"]=build(pathlib.Path("/opt/terminal/terminal"))
out["production_owner"]=read_file("/opt/terminal/terminal-build.sh")
out["caddy"]=read_file("/etc/caddy/Caddyfile")
out["status"]=status()
out["pending_exists"]=os.path.lexists(B/".release-pending")
out["beta_stages"]=stages()
out["free_bytes"]={p:os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for p in ("/","/opt/terminal")}
out["beta_after"]=service("terminal-beta.service")
M=pathlib.Path("/opt/macro")
out["macro"]={"head_before":command(["git","--no-optional-locks","-C",str(M),"rev-parse","HEAD"]),"services":{n:service(n) for n in ("macro-api.service","caddy.service")},"files":[read_file(p) for p in ("/usr/local/bin/macro-update","/etc/caddy/Caddyfile","/opt/macro/app/deploy/update.sh","/opt/macro/app/deploy/Caddyfile","/opt/macro/site/shared_shell_bridge.js","/opt/macro/site/shared_shell.css","/opt/macro/site/index.html","/opt/macro/site/sector_central.html","/opt/macro/site.served/shared_shell_bridge.js","/opt/macro/site.served/shared_shell.css","/opt/macro/site.served/index.html","/opt/macro/site.served/sector_central.html")]}
out["macro"]["head_after"]=command(["git","--no-optional-locks","-C",str(M),"rev-parse","HEAD"])
out["production_after"]={"service":service("terminal.service"),"build":build(pathlib.Path("/opt/terminal/terminal")),"owner":read_file("/opt/terminal/terminal-build.sh")}
out["caddy_after"]=read_file("/etc/caddy/Caddyfile")
out["release_after"]=release_observation()
out["finished_at"]=now()
print(json.dumps(out,indent=2))
