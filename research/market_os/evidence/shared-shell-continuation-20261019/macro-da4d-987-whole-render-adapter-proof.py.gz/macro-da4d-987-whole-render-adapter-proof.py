from pathlib import Path
import subprocess,json,hashlib,datetime
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");D=E/"macro-da4d-987-whole-render-preview";G=["git","--no-optional-locks","-C",str(W)]
B="3b49d6a5c8a6330652a926a8e5061e0dbb3d0387";H="da4df7d1e1ac709055c6fa1d482304a875e81824";M="9875169102cc6f36a64d465fe7c06f6bb8fb0220";T="11ad3c513bc73c9f03a06363ea9b810e0308b574"
def git(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
plain="try{ window.MDXAuth.open('signin'); }catch(e){ location.href = 'plans.html'; }"
shared="if (window.MMXSharedShell) { window.MMXSharedShell.openAuth('signin'); return; } "+plain
us=[
("        location.href = 'stock.html#' + encodeURIComponent(tk);","        var _d = 'stock.html#' + encodeURIComponent(tk); var _ss = window.MMXSharedShell; if (_ss) { _ss.navigate(_d, 'push'); } else { location.href = _d; }"),
("    window.addEventListener('hashchange', fromHash);","    window.addEventListener('hashchange', fromHash);\n    window.addEventListener('mmx:shell-location', fromHash);"),
("          try{ window.MDXAuth.open('signin'); }catch(e2){ location.href = 'plans.html'; }","          if(window.MMXSharedShell){ window.MMXSharedShell.openAuth('signin'); return; }\n          try{ window.MDXAuth.open('signin'); }catch(e2){ location.href = 'plans.html'; }")]
specs=[("us_stocks.html","templates/dashboard.html.j2",us),("etfs.html","templates/etfs.html.j2",[(plain,shared)]),("special_situations.html","templates/special_situations.html.j2",[(plain,shared)]),("china_special_situations.html","templates/china_special_situations.html.j2",[(plain,shared)])]
prepared=[];rows=[]
for name,tpl,ops in specs:
 src={l:git("show",r+":"+tpl) for l,r in [("B",B),("H",H),("M",M),("T",T)]}
 assert src["B"]==src["M"],tpl
 assert src["H"]==src["T"],tpl
 for old,new in ops:
  assert old in src["B"].decode() and new in src["H"].decode(),(name,old)
 texts={l:(D/(name+"."+l+".canonical.html")).read_text() for l in ["B","H","M"]}
 def forward(s):
  for old,new in ops:
   assert s.count(old)==1,(name,"old count",old,s.count(old));assert new not in s
   s=s.replace(old,new,1)
  return s
 assert forward(texts["B"])==texts["H"],name
 candidate=forward(texts["M"]);recovered=candidate
 for old,new in reversed(ops):
  assert recovered.count(new)==1;recovered=recovered.replace(new,old,1)
 assert recovered==texts["M"],name
 target=D/(name+".incoming-generation-plus-existing-adapters.html")
 assert not target.exists()
 prepared.append((target,candidate))
 rows.append({"path":"site/"+name,"source_template":tpl,"incoming_template_unchanged_from_base":True,"merged_template_equals_H":True,"source_template_blobs":{l:git("rev-parse",r+":"+tpl).decode().strip() for l,r in [("B",B),("H",H),("M",M),("T",T)]},"exact_existing_adapter_count":len(ops),"existing_adapters_reproduce_complete_normalized_H_from_B":True,"inverse_adapters_recover_complete_normalized_incoming_M":True,"complete_incoming_generation_sha256":dg(texts["M"].encode()),"candidate_sha256":dg(candidate.encode()),"candidate_bytes":len(candidate.encode()),"candidate_file":str(target)})
out={"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"base":B,"head":H,"incoming":M,"read_only_merge_tree":T,"scope":"Scratch-only four whole-render candidates; complete incoming generation plus exactly the already-owned source adapters, shared-shell block and canonical asset transformations. No three-way page text splice, payload/gating edit, W/index effect or publication.","rows":rows}
for p,v in prepared:p.write_text(v)
p=E/"macro-da4d-987-whole-render-adapter-proof.json";assert not p.exists();p.write_text(json.dumps(out,indent=2)+"\n");print(json.dumps(out,indent=2),flush=True)
