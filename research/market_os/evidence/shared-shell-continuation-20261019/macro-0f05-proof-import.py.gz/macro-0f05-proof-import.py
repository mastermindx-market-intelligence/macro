import datetime,gzip,hashlib,json,pathlib,subprocess,yaml
W=pathlib.Path('/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27')
E=pathlib.Path('/tmp/shared-shell-css-visual-20261019T1107')
P=W/'research/market_os/evidence/shared-shell-continuation-20261019'
H=W/'agentos/handoffs/MARKET-OS-SHARED-SHELL-2026-09-24.md'
def sha(b):return hashlib.sha256(b).hexdigest()
def g(*a):return subprocess.check_output(['git','-C',str(W),*a],text=True).strip()
r=json.loads((E/'macro-0f05-packing-after.json').read_text());assert r['exit']==0 and r['source_and_index_unchanged']
assert g('rev-parse','HEAD')==r['head'] and g('rev-parse','MERGE_HEAD')==r['incoming'] and g('write-tree')==r['index']
assert not g('diff','--name-only') and not g('ls-files','-u')
m_path=P/'MANIFEST.json';m=json.loads(m_path.read_text());old_rows=json.loads(json.dumps(m['files']))
assert len(old_rows)==210
for row in old_rows:
 raw=(P/row['file']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],row['file']
 if row.get('encoding')=='gzip':
  raw=gzip.decompress(raw);assert len(raw)==row['original_bytes'] and sha(raw)==row['original_sha256'],row['file']
assert {x.name for x in P.iterdir() if x.is_file()}=={x['file'] for x in old_rows}|{'MANIFEST.json'}
names='''macro-69-newmain-0415-reconcile.json
macro-69-newmain-0415-preview.txt
macro-69-newmain-0415-incoming_since_base.diff
macro-69-newmain-0415-ours_since_base.diff
macro-69-f54-prepare-candidates.py
macro-69-f54-prepare-candidates-v2.py
macro-69-f54-candidate-preflight-refusal.json
macro-69-f54-candidates.json
macro-69-f54-merge.py
macro-69-f54-merge-invocation.json
macro-69-f54-merge.log
macro-69-f54-actual-merge.json
macro-f54-focused-before-runner.py
macro-f54-focused-before-invocation.json
macro-f54-focused-before.json
macro-f54-focused-before.log
macro-f54-focused-before-probes.json
macro-f54-focused-before-attribution.json
macro-f54-budget-repair-and-check.py
macro-f54-intermediate-commit-message.txt
macro-f54-intermediate-commit.json
macro-f54-intermediate-commit.log
macro-f54-prepublication-fetch-observation.txt
macro-f54-prepublication-remote.diff
macro-f54-prepublication-remote.json
macro-postf54-0f05-preview.txt
macro-full-checkpoint-0408-published69.md
macro-6c-0f05-prepare.py
macro-6c-0f05-prepare-v2.py
macro-6c-0f05-candidate-preflight-refusal.txt
macro-6c-0f05-candidates.json
macro-6c-0f05-merge.py
macro-6c-0f05-merge-invocation.json
macro-6c-0f05-merge.log
macro-6c-0f05-merge-whitespace-refusal.txt
macro-6c-0f05-whitespace-comparison.json
macro-6c-0f05-actual-merge.json
macro-0f05-focused-before-runner.py
macro-0f05-focused-before-invocation.json
macro-0f05-focused-before.json
macro-0f05-focused-before.log
macro-0f05-focused-before-probes.json
macro-0f05-focused-before-attribution.json
macro-0f05-measured-budget-repair.py
macro-0f05-measured-budget-repair-v2.py
macro-0f05-budget-repair-static-refusal.json
macro-0f05-budget-repair.diff
macro-0f05-budget-repair.json
macro-0f05-packing-after-runner.py
macro-0f05-packing-after-invocation.json
macro-0f05-packing-after.log
macro-0f05-packing-after.json
macro-0f05-existing-adapters.json
macro-0f05-existing-adapters.log
beta-prepublication-after0f05-reader.py
beta-prepublication-after0f05-remote.py
beta-prepublication-after0f05.stdout.json
beta-prepublication-after0f05.stderr
beta-prepublication-after0f05.json
beta-prepublication-caddy-source-binding.json
macro-0f05-candidate-independent-review.md
macro-0f05-ci-independent-review.md
beta-namespace-v2-independent-result-review.md
macro-d528-sni-consultation-incomplete.md
beta-dns-browser-signin-frontier.md'''.splitlines()
assert len(names)==len(set(names))
payloads=[]
for name in names:
 src=E/name;raw=src.read_bytes()
 compressed=name.endswith(('.diff','.log','.txt')) or len(raw)>12000
 dest=name+('.gz' if compressed else '')
 assert not (P/dest).exists()
 payload=gzip.compress(raw,mtime=0) if compressed else raw
 row={'file':dest,'source':str(src),'bytes':len(payload),'sha256':sha(payload),'encoding':'gzip' if compressed else 'identity'}
 if compressed:row.update(original_bytes=len(raw),original_sha256=sha(raw));assert gzip.decompress(payload)==raw
 payloads.append((dest,payload,row))
health=json.loads((E/'beta-prepublication-after0f05.stdout.json').read_text())
assert health['status']['status']==200 and health['status']['body']['buildId']=='e45bde2cac07ac3b29285ff70c40d68900fad62c'
assert health['runtime_pointer']['sha256']=='698204ef4ad72a1bfa896110af875df080bf773687150890e8a2322bd6b452d7'
add=('''
## 2026-10-20 attended continuation — composed main0f058428 and measured CI budget

Same WS:MARKET-OS/root market-os-shared-shell-design-20260924-sol-001/parent shared-shell-production-20261018-c1, original PR7949/branch/shared-shell-r27. Compatible protected INDEX/laws065b7fe719bb07407eae965ffb15e300ae2395f6; no replacement carrier or watcher.

Published69e8566 was ordinarily merged with f54. Three exact conflicts preserved both manifest intents, incoming Caddy's four help_refresh.js entries and both test histories. The producing four CI nodes plus28boundary cases gave31PASS/1FAIL: only build-free-content5665>5661. Incoming-manifest weight on those same IDs5658; retained Shell commands+5/+2. That first candidate became local intermediate6c0f54d2 (parents69e8566/f54, tree4bac8f07), deliberately unpublished. The prepared5665 repair was UNRUN.

During secure sign-in, incoming0f058428 added the vector suite (+3 exact command weight), LP closure paths and a generated-site refresh. Its immutable fetch exited0 with retained old-object read warnings; the exact chosen input objects were usable. No broad repository repair/health claim. The original worktree then ordinarily merged0f05, true basef54, preview73c503c2. Exactly three conflicts: manifest retains all329 job fields/order/path multiplicities and both additions; ETF/US preserve incoming bytes through exact incumbent one/three adapters plus canonical block, proved by forward/reverse/idempotency. Eleven unchanged owner/access/Caddy/Sector-template bindings preserve earlier boundary evidence.

The actual resulting indexb4588872 has no unmerged or unstaged entries. Four incoming US whitespace lines were detected by the prior-head guard, retained unchanged, and independently matched to incoming. Owned delta against exactincoming passes whitespace. The first candidate preflight stopped before source edits because new Shell paths are absent from main; the corrected tree-entry comparison covers absence explicitly.

Actual Python3.12 four-node run04:41:56.866937–04:45:31.753659Z:3PASS/1FAIL, only5668>5661. Measured rows: index135/5793/10, build-free134/5668/10, plan128/5542/10. Selected IDs exactly match priorf54; incoming0f05 command weights on those sameIDs give5661 for build-free, plus retained Shell5+2. Minimal applied correction changes only5661→5668 and history; executable AST otherwise identical. A standalone helper first failed Python parsing before execution; retained original plus compiled v2 record that refusal honestly. Corrected source index252deb9ff390ad3677a2c29ce9fd05a54e609e04; patchSHA4b3bfe30934f96fd5f9c4369b0fe65c559aefdbc42652820f18526d0b386351e.
''' + '\nFinal packing-only producing validation: '+r['started_at']+' through '+r['finished_at']+', exit0; source/index unchanged. LogSHA'+r['log_sha256']+'. Three scope passes remain on unchanged manifest. Existing navigation/owner adapters78PASS/0skip. No new full local differential run or hosted-green claim.\n' + '''
Bounded current candidate and actual CI reviews are retained separately. Beta V2 actual-result review NONBLOCKING: outer filesystem acceptancePASS, inner conservative disposition retained; seccomp/cgroup equivalence not claimed. The older d528 SNI consultation never received its artifact read (aborted5079.4s), so it is explicitly UNQUALIFIED and creates no extra gate.

Fresh04:42 read: accepted beta A/PID2427329/start7560285026653/runtimec62950826aca6fd8 retained, loopbackHTTP200/private/no-store/noindex. Production PID2336355/start7552363880288/build50a8/globalowner6d05 unchanged. Installed Caddy17aefed changed externally and exactly matches incoming0f05; no actor attribution or root mutation. No pending/stage; rootfree36765310976B/mount16176545792B. R93 bootstrap/recovery and filesystem acceptance remain complete: DO NOT REPEAT.

Public DNS still EdgeOneCNAME with43.159.99.101/43.159.98.106; strictTLS hostname mismatch. DNSPod cloudtab3 remains Tencent sign-in; secure method choice selectedWeChat but its iframe isSiteUnavailable. No authenticated console/DNS change. This is a concrete remaining user sign-in boundary, not public beta acceptance. First-install containment/recovery of originalA is supported; previousruntimeNULL/futurebaseline eligibility does not prove executedA→B→A rollback.

Programme OPEN. This is a precommit proof snapshot; original PR checkpoint records eventual commit/push/head. Current-head hostedCI/review, merge-on-green LAST, incumbent coveringrender/generated-main and actualmacro-update served-tree remain required. DNS/TLS/auth/public1440×900/820×1180/390×844 navigation/history/theme/language/nativehandoff/errors and applicable recovery acceptance remain separate. No duplicate PR/renderer/sourcecarrier/watcher; no production mutation. Preserve overview/map/moving/money/explore/confluence and sector→basket; PaperREVISE; C4comments6255134033…6255716294 SPEC_ONLY/UNAPPLIED/UNRUN. Historical16-cell CSS fixture remains historical, not refreshed generated pixels.
''').encode()
old_h=H.read_text();parts=old_h.split('---',2);assert len(parts)==3 and parts[0]==''
fm=yaml.safe_load(parts[1]);body=parts[2]
fm['state_before']='Same original programme. Published69e8566; local intermediate6c preserves f54 merge and its observed budget breach. Current0f05 merge and minimal measured5668 correction pass focused local gates at index252deb9f. Beta originalA accepted under protectedR93; public DNS/TLS/browser and new-head hosted/publication remain distinct.'
fm['changed'].append({'path':'.github/ci/legacy-jobs.yml; app/deploy/Caddyfile; tests/test_ci_pack.py; site/etfs.html; site/us_stocks.html; existing evidence and handoff','what':'Ordinary f54 then0f05 merges preserve both owners and generated content. Actual5668 measurement funds only seven-unit retained Shell command cost; histories/suites/selectors/job/pack bounds preserved. Same proof pack retains producing failures/green and browser boundary.'})
fm['verified'].append({'claim':'Current0f05 composition and exact measured packing repair pass scoped local gates.','command':'Four existing CI scope/packing nodes; final packing-only check after exact literal/history change; two incumbent Node adapter suites; exact three-way source proofs.','result':'Three scope nodesPASS; actual packing5668vs5661 reproduced; minimal5661→5668 rerunPASS. Rows135/5793/10,134/5668/10,128/5542/10.78adapterPASS. Earlier28boundaryPASS bound to unchanged source. Hosted admission not inferred.'})
fm['verified'].append({'claim':'Accepted original beta generation remains healthy at04:42; V2 filesystem review is nonblocking.','command':'Read-only originalSSH owner service/receipt/build/status/DNS/TLS observation and bounded independent actual-V2 review.','result':'BetaA/PID2427329/runtime698204ef/HTTP200 stable; productionservice/build/owner stable. Caddy17aefed exactlyincoming0f05 changed independently. DNSstillEdgeOne/strictTLShostnamefailure. No rerun or mutation.'})
fm['unresolved']=[
'Programme OPEN. Current local index252deb9f is awaiting final proof commit/push and exact new-head hosted gates; remotePR7949 last observed69e8566/unarmed.',
'R93 bootstrap/runtime/filesystem acceptance complete. Do not repeat. First-install containment/recovery is supported; previous acceptedruntimeNULL means no executedupgrade rollback is claimed.',
'DNSPod secure choice selectedWeChat but iframeSiteUnavailable; resumedUIunchanged/sign-in. DNS remains EdgeOne and strictTLSfails. No credentials/security setting/DNS edit by root.',
'Incumbent coveringrender/generated-main and actualserved publication remain required after source landing.',
'Six Sector views and sector-to-basket retained; PaperREVISE; C4 SPEC_ONLY/UNAPPLIED/UNRUN.',
'Original SessionBridge backend_unavailable exception retained; bounded consultations are not replacement Fabric workers. Historical SNI artifact consultation unqualified because readneverreturned.'
]
fm['next_actions']=[
'Commit/push exact composed source and same proof pack on original branch, inspect actual new-head hostedCI/review, resolve concrete failures only.',
'Refresh actual publication prerequisites and arm existing Macro merge-on-green LAST after final gates; no nativeauto or post-arm push.',
'Consume incumbent render.yml/engine-render covering generated-main and macro-update actualserved asset/capability/header proof.',
'Complete DNSPod user sign-in boundary, original directbetaA/DNS/TLS/auth/public responsive navigation/history/theme/language/nativehandoff/error and applicablefirst-install/rollback acceptance.',
'Persist actual follow-on results into original PR7949 checkpoint/same handoff; programme staysOPEN until accepted.'
]
new_h=('---\n'+yaml.safe_dump(fm,sort_keys=False,allow_unicode=True,width=110)+'---'+body).encode()+add
assert new_h.decode().split('---',2)[2]==body+add.decode()
old_readme=(P/'README.md').read_bytes()
m['previous_frontier_before_0f05']={k:m.get(k) for k in ['indexed_at','macro_source_head','macro_incoming_main','latest_confirmed_macro_publication','latest_host_observed_at','visual_acceptance','beta_publication_gate','macro_integrated_index_tree_before_proof','documentation_validation','local_contract_gate']}
m.update(indexed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),macro_source_head=r['head'],macro_incoming_main=r['incoming'],latest_confirmed_macro_publication='69e8566dc85e701c70ace72320a16d4ba6c95847',latest_host_observed_at=health['observed_at'],macro_integrated_index_tree_before_proof=r['index'],visual_acceptance='Historical16-cell fixture only. Current11 owner/access/Sector-template bindings retained; incoming generated documents refreshed. New generated-main/served pixels and publicbeta unaccepted.',browser_connection='CloudDNSPodtab3 Tencent sign-in; secureWeChat choice submitted but iframeSiteUnavailable. NoDNSedit. Originalextension contextunavailable.',beta_publication_gate='ProtectedR93 originalA bootstrap/runtime/filesystem accepted and fresh04:42 health retained. No furtherbootstrap. PublicDNS/TLS/auth/browser/applicable recovery remain separate.',publication_of_this_package='Precommit/prepush frontier; original PR7949 checkpoint binds eventual publication.')
m['focused_current_composition']={'source_index':r['index'],'incoming':r['incoming'],'scope_passes':3,'packing_exit':0,'packing_receipt':'macro-0f05-packing-after.json','adapters_passed':78,'hosted_admission':False}
m['documentation_validation']={'status':'pending on this doc update before commit'}
for dest,payload,row in payloads:
 with (P/dest).open('xb') as f:f.write(payload)
H.write_bytes(new_h);(P/'README.md').write_bytes(old_readme+add)
m['files'].extend([row for _,_,row in payloads])
for row in m['files']:
 if row['file']=='README.md':row.update(bytes=len(old_readme+add),sha256=sha(old_readme+add))
m['files'].sort(key=lambda x:x['file']);m_path.write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n')
assert len({x['file'] for x in m['files']})==len(m['files'])
for row in m['files']:
 raw=(P/row['file']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],row['file']
 if row.get('encoding')=='gzip':
  raw=gzip.decompress(raw);assert len(raw)==row['original_bytes'] and sha(raw)==row['original_sha256'],row['file']
assert {x.name for x in P.iterdir() if x.is_file()}=={x['file'] for x in m['files']}|{'MANIFEST.json'}
assert all(row==next(n for n in m['files'] if n['file']==row['file']) for row in old_rows if row['file']!='README.md')
paths=[str((P/dest).relative_to(W)) for dest,_,_ in payloads]+[str((P/'README.md').relative_to(W)),str(m_path.relative_to(W)),str(H.relative_to(W))]
g('add','--',*paths)
I=g('write-tree');changed=g('diff','--name-only',r['index'],I).splitlines();assert set(changed)==set(paths),(set(changed)-set(paths),set(paths)-set(changed))
assert not g('diff','--name-only') and not g('ls-files','-u')
out={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_index_before':r['index'],'index_after':I,'old_files':210,'new_files':len(m['files']),'added_files':[row for _,_,row in payloads],'all_hashes_and_roundtrips_pass':True,'old_rows_preserved_except_readme':True,'historical_handoff_body_preserved':True,'only_proof_handoff_paths_differ':True,'manifest_sha256':sha(m_path.read_bytes()),'handoff_sha256':sha(new_h),'committed':False,'pushed':False}
raw=(json.dumps(out,indent=2)+'\n').encode();(E/'macro-0f05-proof-import.json').write_bytes(raw)
print(json.dumps({k:v for k,v in out.items() if k!='added_files'},indent=2));print('receipt_sha256',sha(raw))
