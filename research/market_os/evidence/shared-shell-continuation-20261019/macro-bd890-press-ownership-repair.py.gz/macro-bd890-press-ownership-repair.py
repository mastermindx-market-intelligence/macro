from pathlib import Path
import subprocess,json,hashlib,datetime,os,sys
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");PY=str(W/".venv-shared-shell/bin/python")
H="bd89047e4e403a93183c6a4763274e09acfdd044";BR="sol/market-os-shared-shell-design-20260924";OUT=E/"macro-bd890-press-ownership-repair.json"
def dg(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*a):return subprocess.check_output(["git","--no-optional-locks","-C",str(W),*a])
assert not OUT.exists()
capture=json.loads((E/"macro-bd890-about-canonical.json").read_text());assert capture["capture_completed"]
assert git("rev-parse","HEAD").decode().strip()==H and not git("status","--porcelain").strip()
assert git("branch","--show-current").decode().strip()==BR
assert git("ls-remote","origin","refs/heads/"+BR).decode().split()[0]==H
pr=json.loads(subprocess.check_output(["gh","api","repos/mastermindx-market-intelligence/macro/pulls/7949"],cwd=W))
assert pr["state"]=="open" and pr["head"]["sha"]==H and pr["auto_merge"] is None and "merge-on-green" not in {x["name"] for x in pr["labels"]}
out={"started_at":now(),"head":H,"scope":"Repair exact hosted press replay failure through missing-only in-memory capability comparison; preserve existing marked bytes, global estate comparator, shared injector, publisher and press write scope.","source_write_started":False,"commands":[],"before":{}}
def save():OUT.write_text(json.dumps(out,indent=2)+"\n")
def run(name,args):
 log=E/("macro-bd890-press-"+name+".log");assert not log.exists();row={"name":name,"argv":args,"started_at":now()};out["commands"].append(row);save()
 with log.open("xb") as f:p=subprocess.run(args,cwd=W,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,"PYTHONDONTWRITEBYTECODE":"1"},timeout=240)
 raw=log.read_bytes();row.update(exit=p.returncode,finished_at=now(),log_file=log.name,log_bytes=len(raw),log_sha256=dg(raw));save();print(json.dumps({"name":name,"exit":p.returncode,"tail":raw.decode(errors="replace").splitlines()[-16:]}),flush=True)
 return p.returncode,raw.decode(errors="replace")
save()
source=W/"scripts/run_press.py";tests=W/"tests/test_press_run.py"
for p in [source,tests]:
 raw=p.read_bytes();rel=str(p.relative_to(W));out["before"][rel]={"sha256":dg(raw),"bytes":len(raw)}
 assert git("hash-object",rel).decode().strip()==git("rev-parse",H+":"+rel).decode().strip()
 (E/("macro-bd890-press-before--"+rel.replace("/","--"))).write_bytes(raw)
frozen={p:dg((W/p).read_bytes()) for p in ["scripts/build_free_content.py","lib/shared_shell.py","lib/pages.py","scripts/optimize_assets.py",".github/ci/legacy-jobs.yml"]}
old=tests.read_text();anchor="def test_render_replay_is_idempotent_against_the_committed_estate():"
assert old.count(anchor)==1
insertion=(E/"macro-bd890-press-regression-insertion.txt").read_text()
assert "test_press_comparison_respects_common_shell_owner" not in old
out["source_write_started"]=True;save();tests.write_text(old.replace(anchor,insertion+"\n"+anchor))
rc,log=run("regression-red",[PY,"-B","-m","pytest","-q","--tb=short","tests/test_press_run.py::test_press_comparison_respects_common_shell_owner"])
assert rc==1 and "2 failed, 7 passed" in log,"Unexpected red outcome; inspect exact source/test state before continuing"
old=source.read_text()
a='''    HTML is compared through build_free_content._comparable, which strips the
    daily.yml-only wh_banner tag and normalises the `?v=` asset stamps — the two
    sweeps a press emit cannot replay and does not own.  Everything else (the
    RSS feed) is a plain byte compare.
'''
b='''    HTML uses build_free_content._comparable for the separately owned banner
    and asset stamps. A missing common-renderer Shared Shell block is projected
    in memory before that comparison; an existing block is never regenerated.
    Everything else (the RSS feed) remains a plain byte compare.
'''
assert old.count(a)==1;new=old.replace(a,b)
a='''    from scripts.build_free_content import _comparable  # noqa: PLC0415
    try:
        return _comparable(a.decode("utf-8")) == _comparable(b.decode("utf-8"))
    except UnicodeDecodeError:
        return False
'''
b='''    from scripts.build_free_content import _comparable  # noqa: PLC0415
    from lib.pages import dbase_prefix  # noqa: PLC0415
    from lib.shared_shell import END, START, inject_shared_shell_text  # noqa: PLC0415

    def comparison_text(raw: bytes, path: Path) -> str:
        text = raw.decode("utf-8")
        if START not in text and END not in text:
            # The common renderer owns this additive sweep. Explicit digests
            # keep this comparison pure; _comparable already ignores stamp values.
            # Never regenerate a present block: doing so could erase extra content
            # or malformed markup inside its markers and hide a real difference.
            text = inject_shared_shell_text(
                text, dbase_prefix(path), version="00000000", css_version="00000000",
            )
        return _comparable(text)

    try:
        return comparison_text(a, rendered) == comparison_text(b, committed)
    except (UnicodeDecodeError, ValueError):
        return False
'''
assert new.count(a)==1;new=new.replace(a,b);compile(new,str(source),"exec");source.write_text(new)
rc,_=run("regression-green",[PY,"-B","-m","pytest","-q","--tb=short","tests/test_press_run.py::test_press_comparison_respects_common_shell_owner"]);assert rc==0
rc,_=run("suite-green",[PY,"-B","-m","pytest","-q","--tb=short","tests/test_press_run.py"]);assert rc==0
assert all(dg((W/p).read_bytes())==v for p,v in frozen.items())
out["unchanged_owners"]=frozen;out["after"]={str(p.relative_to(W)):{"sha256":dg(p.read_bytes()),"bytes":p.stat().st_size} for p in [source,tests]}
out["diff"]=git("diff","--stat").decode();out["head_unchanged"]=git("rev-parse","HEAD").decode().strip()==H
out["state"]="NARROW_PRESS_OWNER_REPAIR_VALIDATED_UNCOMMITTED";out["finished_at"]=now();save();print(json.dumps(out,indent=2))
