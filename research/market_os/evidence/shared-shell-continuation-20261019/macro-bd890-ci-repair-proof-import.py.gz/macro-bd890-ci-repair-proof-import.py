import copy,datetime,gzip,hashlib,json,pathlib,subprocess,yaml
W=pathlib.Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=pathlib.Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","-C",str(W)]
H="bd89047e4e403a93183c6a4763274e09acfdd044";M="7a6e21cb7d6a38855b7e06432c94f61acb0fe6f1"
REL="research/market_os/evidence/shared-shell-continuation-20261019";P=W/REL
HP="agentos/handoffs/MARKET-OS-SHARED-SHELL-2026-09-24.md";WP="agentos/workstreams/WS-MARKET-OS.md"
STEM="macro-bd890-ci-repair-proof";OUT=E/(STEM+"-import.json")
def g(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def readj(n):return json.loads((E/n).read_text())
def savej(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+"\n")
assert not OUT.exists(),"existing partial proof import requires reconciliation"
assert g("rev-parse","HEAD").decode().strip()==H and not g("diff","--name-only").strip() and not g("ls-files","-u").strip()
assert subprocess.run(G+["rev-parse","--verify","MERGE_HEAD"],capture_output=True).returncode!=0
ad=readj("macro-bd890-about-adoption.json");press=readj("macro-bd890-press-ownership-repair.json")
assert ad["state"]=="CANONICAL_ABOUT_ADOPTED_VISUAL_GATE_PASS" and ad["gate_exit"]==0 and ad["source_inputs_unchanged"] and ad["old_receipt_unchanged"]
assert press["state"]=="NARROW_PRESS_OWNER_REPAIR_VALIDATED_UNCOMMITTED" and [x["exit"] for x in press["commands"]]==[1,0,0]
SOURCE=g("write-tree").decode().strip();assert SOURCE==ad["staged_tree"]
source_paths=set(press["after"])|{r["path"] for r in ad["adopted_files"]}
assert set(g("diff","--cached","--name-only",H).decode().splitlines())==source_paths
def verify_source():
 for p,row in press["after"].items():
  b=(W/p).read_bytes();assert len(b)==row["bytes"] and dg(b)==row["sha256"],p
 for p,h in press["unchanged_owners"].items():assert dg((W/p).read_bytes())==h,p
 for row in ad["adopted_files"]:
  b=(W/row["path"]).read_bytes();assert len(b)==row["bytes"] and dg(b)==row["sha256"],row["path"]
 for command in press["commands"]:
  b=(E/command["log_file"]).read_bytes();assert len(b)==command["log_bytes"] and dg(b)==command["log_sha256"]
verify_source()
decl=yaml.safe_load((W/".github/ci/legacy-jobs.yml").read_text())["jobs"]["ticker-news-qbus"]
needed=["lib/pages.py","lib/shared_shell.py","lib/site_assets.py"]
assert all(p in decl["paths"] for p in needed)
dep=E/"macro-bd890-ci-repair-dependency-coverage.json";assert not dep.exists()
savej(dep,{"observed_at":now(),"head":H,"manifest_sha256":dg((W/".github/ci/legacy-jobs.yml").read_bytes()),"job":"ticker-news-qbus","gate":decl["gate"],"scope":decl["scope"],"explicit_paths":needed,"manifest_modified":False,"scope":"Named new-import coverage only; not a full dependency audit or hosted result."})
oldraw=(P/"MANIFEST.json").read_bytes();assert dg(oldraw)=="4a58e853087035219bde71c34621936dd0d6f31d7bfb8c1c76aa684c3b96b13b"
mf=json.loads(oldraw);oldrows=copy.deepcopy(mf["files"]);rows={r["file"]:r for r in oldrows};assert len(rows)==len(oldrows)==1219
def verify_pack():
 for name,row in rows.items():
  b=(P/name).read_bytes();assert len(b)==row["bytes"] and dg(b)==row["sha256"],name
  if row.get("encoding","identity")=="gzip":
   raw=gzip.decompress(b);assert len(raw)==row["original_bytes"] and dg(raw)==row["original_sha256"],name
 assert {str(p.relative_to(P)) for p in P.rglob("*") if p.is_file()}==set(rows)|{"MANIFEST.json"}
verify_pack()
hb=(W/HP).read_bytes();wb=(W/WP).read_bytes();rb=(P/"README.md").read_bytes()
assert hb==g("show",":"+HP) and wb==g("show",":"+WP)
hs=hb.decode();cut=hs.index("\n---\n",4);meta=yaml.safe_load(hs[4:cut]);oldbody=hs[cut+5:]
assert meta["workstream"]=="WS:MARKET-OS" and meta["prs"]==[7949]
cfg=readj(STEM+"-config.json")
for key in ("state_before","unresolved","next_actions"):meta[key]=cfg[key]
for key in ("changed","verified"):meta[key].extend(cfg[key])
meta["do_not_redo"].append(cfg["do_not_redo_add"])
append=cfg["continuation"].rstrip()+"\n"
newh="---\n"+yaml.safe_dump(meta,sort_keys=False,allow_unicode=True,width=110)+"---\n"+oldbody+"\n\n"+append
neww=wb.decode()+"\n\n"+append;newr=rb+b"\n\n"+append.encode()
o={"started_at":now(),"state":"IMPORT_INTENT","head":H,"incoming":M,"qualified_repair_index":SOURCE,"old_manifest_sha256":dg(oldraw),"old_indexed_files":1219,"source_paths":sorted(source_paths),"checks":[]}
savej(OUT,o)
(W/HP).write_text(newh);(W/WP).write_text(neww);(P/"README.md").write_bytes(newr)
rows["README.md"]={**rows["README.md"],"bytes":len(newr),"sha256":dg(newr)}
added=[];skipped=[]
def include(p,target=None):
 assert p.is_file() and not p.is_symlink(),p
 raw=p.read_bytes();target=target or p.name
 gz=p.suffix!=".json" or len(raw)>65536 or raw.endswith(b"\n\n")
 if gz:target+=".gz"
 assert pathlib.Path(target).name==target,target
 if target in rows:
  row=rows[target];assert (row.get("original_sha256") if row.get("encoding","identity")=="gzip" else row["sha256"])==dg(raw),target
  skipped.append(target);return
 assert not (P/target).exists(),target
 data=gzip.compress(raw,mtime=0) if gz else raw
 if gz:assert gzip.decompress(data)==raw
 else:raw.decode()
 (P/target).write_bytes(data)
 row={"file":target,"source":str(p),"bytes":len(data),"sha256":dg(data),"encoding":"gzip" if gz else "utf-8"}
 if gz:row.update(original_bytes=len(raw),original_sha256=dg(raw))
 rows[target]=row;added.append(target)
prefixes=("macro-bd890-about-","macro-bd890-press-","macro-bd890-failed-job-","macro-bd890-ci-plan-","macro-bd890-dns-readiness","macro-bd890-publication-preflight","macro-bd890-ui-evidence-","macro-bd890-ci-repair-")
exclude={OUT,E/(STEM+"-validation.json")}
for p in sorted(E.iterdir()):
 if p.is_file() and p not in exclude and p.name.startswith(prefixes):include(p)
for name in ("manifest.json","ux_smell_report.json"):include(E/"macro-bd890-about-canonical"/name,"macro-bd890-about-canonical--"+name)
replay=E/"macro-bd890-press-replay-red";replay_receipt=readj("macro-bd890-press-replay-red.json")
for p in sorted(replay.iterdir()):
 if p.is_file():include(p,"macro-bd890-press-replay-red--"+p.name)
for row in replay_receipt["changed"]:
 p=replay/"site"/row["path"];b=p.read_bytes()
 assert len(b)==row["built_bytes"] and dg(b)==row["built_sha256"],p
 include(p,"macro-bd890-press-replay-red--site--"+row["path"].replace("/","--"))
for name in ("macro-bd890-checkpoint-1949.md","macro-2ae-7a6-proof-import.json","macro-2ae-7a6-proof-commit-push.py","macro-2ae-7a6-proof-commit-push.json","macro-2ae-7a6-proof-commit-message.txt","macro-2ae-7a6-proof-commit.log","macro-2ae-7a6-proof-push.log"):include(E/name)
assert "previous_frontier_before_bd890_ci_repair" not in mf
mf["previous_frontier_before_bd890_ci_repair"]={k:copy.deepcopy(v) for k,v in json.loads(oldraw).items() if k!="files" and not k.startswith("previous_frontier")}
mf.update(cfg["manifest_update"])
mf.update({"macro_source_head_before_repair":H,"macro_qualified_repair_tree_before_proof":SOURCE,"latest_confirmed_macro_publication":H,
"current_canonical_external_files":ad["adopted_files"],"publication_of_this_package":"Precommit/prepush extension on the original branch after two actual hosted failures. The original PR checkpoint binds the ensuing commit/push. Local tests and visual gate are not new-head hosted admission, protected landing, rendered publication or public beta acceptance."})
def save_manifest():
 mf["files"]=[rows[k] for k in sorted(rows)];mf["indexed_at"]=now();savej(P/"MANIFEST.json",mf)
save_manifest();verify_pack()
subprocess.run(G+["add","--",HP,WP,REL],check=True)
record=g("write-tree").decode().strip()
docs=g("diff","--name-only",SOURCE,record).decode().splitlines()
allowed=lambda p:p in (HP,WP) or p.startswith(REL+"/")
assert docs and all(allowed(p) for p in docs) and not g("diff","--name-only").strip()
vpath=E/(STEM+"-validation.json");assert not vpath.exists()
validation={"started_at":now(),"qualified_repair_index":SOURCE,"record_index_before_validation":record,"documentation_only_delta":docs,"old1219_entries_verified":True,"old_handoff_body_preserved":True,"old_workstream_bytes_preserved":True,"old_readme_bytes_preserved":True,"checks":[]}
savej(vpath,validation)
diff=E/(STEM+"-changed-paths.txt");assert not diff.exists();diff.write_bytes(g("diff","--cached","--name-only",M))
py=str(W/".venv-shared-shell/bin/python")
commands=[("agentos",[py,"-B","scripts/agentos.py","validate"]),("template-sync",[py,"-B","scripts/check_template_site_sync.py"]),("p0b-closure",[py,"-B","scripts/check_p0b_receipt_closure.py","--diff-file",str(diff),"--event","pull_request"]),("owned-whitespace",G+["diff","--cached","--check",M])]
for name,args in commands:
 log=E/(STEM+"-"+name+".log");assert not log.exists();start=now()
 with log.open("xb") as f:r=subprocess.run(args,cwd=W,stdout=f,stderr=subprocess.STDOUT)
 item={"check":name,"command":args,"started_at":start,"finished_at":now(),"exit":r.returncode,"log":str(log),"bytes":log.stat().st_size,"sha256":dg(log.read_bytes())}
 validation["checks"].append(item);savej(vpath,validation)
 print(json.dumps({"check":name,"exit":r.returncode,"tail":log.read_text(errors="replace")[-1600:]}),flush=True)
 assert r.returncode==0,item
verify_source()
assert g("write-tree").decode().strip()==record and not g("diff","--name-only").strip()
assert (W/HP).read_text()==newh and (W/WP).read_text()==neww and (P/"README.md").read_bytes().startswith(rb)
validation.update(finished_at=now(),all_checks_pass=True,index_unchanged_during_checks=True,source_and_handoff_unchanged=True)
savej(vpath,validation)
for row in validation["checks"]:include(pathlib.Path(row["log"]))
include(vpath);include(diff)
mf["documentation_validation"]={"receipt":vpath.name,"all_checks_exit0":True,"record_index":record,"agentos_exit":0,"template_sync_exit":0,"p0b_closure_exit":0,"owned_whitespace_exit":0}
save_manifest();verify_pack()
for row in oldrows:
 if row["file"]!="README.md":assert rows[row["file"]]==row,row["file"]
subprocess.run(G+["add","--",REL],check=True)
final=g("write-tree").decode().strip()
finaldocs=g("diff","--name-only",SOURCE,final).decode().splitlines()
assert all(allowed(p) for p in finaldocs)
assert not g("diff","--name-only").strip() and not g("ls-files","-u").strip() and not g("diff","--cached","--check",M).strip()
assert g("rev-parse","HEAD").decode().strip()==H
count=len(g("diff","--name-only",M,final).decode().splitlines());assert count<3000
o.update(state="REPAIR_AND_PROOF_READY_NOT_COMMITTED_OR_PUSHED",finished_at=now(),final_index=final,documentation_only_paths=len(finaldocs),indexed_files=len(rows),added_files=added,skipped_existing_identical=skipped,manifest_bytes=(P/"MANIFEST.json").stat().st_size,manifest_sha256=dg((P/"MANIFEST.json").read_bytes()),candidate_paths_vs_incoming=count,validation_receipt_sha256=dg(vpath.read_bytes()),handoff_sha256=dg((W/HP).read_bytes()),workstream_sha256=dg((W/WP).read_bytes()),all_checks_pass=True,all_hashes_and_coverage_pass=True)
savej(OUT,o)
print(json.dumps({k:v for k,v in o.items() if k not in ("added_files","skipped_existing_identical","checks","source_paths")},indent=2),flush=True)
