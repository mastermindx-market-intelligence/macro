from pathlib import Path
import json,hashlib,datetime,subprocess
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107")
def dg(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(["git","-C",str(W),*a])
out={"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"head":git("rev-parse","HEAD").decode().strip(),"working_diff_sha256":dg(git("diff","--binary","HEAD")),"p0b":[],"about":[]}
assert out["head"]=="8b51fb46d18739a4d10d1ef07dce3ca0f989f0da"
p0b=json.loads((E/"macro-ae3-5c2d-p0b-lineage-v2.json").read_text())
assert len(p0b["bound_paths"])==82
for r in p0b["bound_paths"]:
 p=r["path"];raw=(W/p).read_bytes();blob=git("rev-parse","HEAD:"+p).decode().strip()
 assert dg(raw)==r["sha256"] and blob==r["git_blob"],p
 out["p0b"].append({"path":p,"sha256":dg(raw),"git_blob":blob,"bytes":len(raw)})
about=json.loads((E/"about-footer-green-manifest.json").read_text())
assert len(about["files"])==53
for p,r in about["files"].items():
 path="site"+p;raw=(W/path).read_bytes()
 assert dg(raw)==r["sha256"] and len(raw)==r["bytes"],path
 assert git("show","HEAD:"+path)==raw,path
 out["about"].append({"path":path,"sha256":dg(raw),"bytes":len(raw),"git_blob":git("rev-parse","HEAD:"+path).decode().strip()})
out["deployment_named_source_and_test_delta_from_140bd"]=git("diff","--name-only","140bd1ee79a44859915595fdf12c958c07a60e2b","HEAD","--","app/deploy/","config/site_access.yml","tests/test_regwall_json_gate.py","tests/test_site_access_boundary.py","tests/test_deploy_update_self_heal.py").decode().splitlines()
assert not out["deployment_named_source_and_test_delta_from_140bd"]
out["scope"]="P0B82 actual raw and git bindings and About53 actual response closure unchanged; no rerun. Deployment334 remains prior actual result with these named sources unchanged, not a claim that every dynamically read input was re-enumerated."
out["unchanged_after"]=out["head"]==git("rev-parse","HEAD").decode().strip() and out["working_diff_sha256"]==dg(git("diff","--binary","HEAD"))
assert out["unchanged_after"]
path=E/"labor-copy-proof-lineage.json";assert not path.exists();path.write_text(json.dumps(out,indent=2)+"\n")
old=(E/"about-footer-source-reconciliation.json").read_bytes();recon=json.loads(old);initial=json.loads((E/"about-footer-source-change.json").read_text())
first={r["path"]:r["after_sha256"] for r in initial["writes"]}
clar={"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"raw_reconciliation_sha256":dg(old),"raw_reconciliation_preserved":True,"clarification":"The original field initial_canonical_candidate_sha256 records the pre-final intermediate bytes. The first product had already undergone the refused write_page attempt. Use the two distinct identities below; no source or actual receipt is rewritten.","products":[{"path":r["path"],"initial_canonical_candidate_sha256":first[r["path"]],"pre_final_intermediate_sha256":r["initial_canonical_candidate_sha256"],"final_sha256":r["final_sha256"]} for r in recon["products"]]}
p=E/"about-footer-source-reconciliation-clarification.json";assert not p.exists();p.write_text(json.dumps(clar,indent=2)+"\n")
print(json.dumps({"lineage":str(path),"lineage_sha256":dg(path.read_bytes()),"p0b_count":len(out["p0b"]),"about_count":len(out["about"]),"unchanged":out["unchanged_after"],"clarification_sha256":dg(p.read_bytes())},indent=2))
