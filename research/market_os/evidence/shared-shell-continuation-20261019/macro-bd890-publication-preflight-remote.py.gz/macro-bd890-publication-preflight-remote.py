import datetime,hashlib,importlib.util,json,os,pathlib,stat,subprocess
R=pathlib.Path("/opt/macro")
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def command(a):
 p=subprocess.run(a,capture_output=True,text=True,timeout=15);return {"argv":a,"exit":p.returncode,"stdout":p.stdout,"stderr":p.stderr}
def file(p):
 try:
  st=os.lstat(p)
  if not stat.S_ISREG(st.st_mode):return {"path":p,"kind":"nonregular","mode":oct(st.st_mode&0o7777)}
  with open(p,"rb") as f:b=f.read(524289)
  z=os.lstat(p)
  return {"path":p,"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),"complete":len(b)==st.st_size,"stable":(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns)==(z.st_dev,z.st_ino,z.st_size,z.st_mtime_ns),"uid":st.st_uid,"gid":st.st_gid,"mode":oct(st.st_mode&0o7777)}
 except OSError as e:return {"path":p,"error":type(e).__name__,"errno":e.errno}
out={"started_at":now(),"scope":"Read-only existing publication owner/runtime readiness. No updater, render, Caddy reload, installer or service operation."}
out["head_before"]=command(["git","--no-optional-locks","-C",str(R),"rev-parse","HEAD"])
out["free_bytes"]={p:os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for p in ["/","/opt/terminal","/opt/macro"]}
py="/opt/macro-api/.venv/bin/python"
out["existing_interpreter"]={"path":py,"exists":os.path.isfile(py),"executable":os.access(py,os.X_OK)}
if out["existing_interpreter"]["executable"]:
 out["dependency_presence"]=command([py,"-I","-B","-c","import importlib.util,json,sys;print(json.dumps({'python':sys.version.split()[0],'modules':{m:importlib.util.find_spec(m) is not None for m in ['yaml','rjsmin','bs4','jinja2']}}))"])
out["owner_files"]=[file(p) for p in ["/usr/local/bin/macro-update","/opt/macro/app/deploy/update.sh","/etc/caddy/Caddyfile"]]
owners=[];errors=[]
for x in pathlib.Path("/proc").iterdir():
 if not x.name.isdecimal():continue
 try:
  args=(x/"cmdline").read_bytes().split(b"\0")
  if any(a in [b"/usr/local/bin/macro-update",b"/opt/macro/app/deploy/update.sh"] for a in args):
   v=(x/"stat").read_text();owners.append({"pid":int(x.name),"start_ticks":v[v.rfind(")")+2:].split()[19],"uid":x.stat().st_uid})
 except (FileNotFoundError,ProcessLookupError):pass
 except (PermissionError,OSError) as e:errors.append({"pid":int(x.name),"type":type(e).__name__})
out["updater_process_observation"]={"owners":owners,"errors":errors,"reservation":False}
log=pathlib.Path("/var/log/macro-update.log")
if log.is_file():
 with log.open("rb") as f:
  f.seek(max(0,log.stat().st_size-16384));raw=f.read(16384)
 lines=raw.decode(errors="replace").splitlines()
 out["updater_log_tail"]={"path":str(log),"tail_bytes":len(raw),"tail_sha256":hashlib.sha256(raw).hexdigest(),"selected_lines":[x for x in lines if x.startswith(("macro-update:","HEAD is now","Already up to date","From github.com"))][-25:]}
out["head_after"]=command(["git","--no-optional-locks","-C",str(R),"rev-parse","HEAD"])
out["finished_at"]=now();print(json.dumps(out,indent=2))
