from pathlib import Path
import subprocess,json,hashlib,datetime,os,sys
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","-C",str(W)]
H="da4df7d1e1ac709055c6fa1d482304a875e81824";M="9875169102cc6f36a64d465fe7c06f6bb8fb0220";T="11ad3c513bc73c9f03a06363ea9b810e0308b574";OUT=E/"macro-da4d-987-theme-owner-resolution.json"
def git(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert not OUT.exists()
assert git("rev-parse","HEAD").decode().strip()==H and git("rev-parse","MERGE_HEAD").decode().strip()==M
assert "site/theme.js" in git("diff","--name-only","--diff-filter=U").decode().splitlines()
inputs=["lib/site_assets.py","lib/config.py","config.yml","templates/theme.js","templates/mm_brain.js","templates/terminal_overlay.js"]
frozen={p:(W/p).read_bytes() for p in inputs}
for p,b in frozen.items():assert b==git("show",T+":"+p),p
assert (W/"site/mm_brain.js").read_bytes()==frozen["templates/mm_brain.js"]
os.chdir(W);sys.path.insert(0,str(W))
from lib.site_assets import emit_theme_js,copy_asset,MM_BRAIN_VER_TOKEN,SUPABASE_TOKEN
import rjsmin
candidate=emit_theme_js(W/"templates/theme.js").encode()
assert MM_BRAIN_VER_TOKEN.encode() not in candidate and SUPABASE_TOKEN.encode() not in candidate and b"<<<<<<<" not in candidate
before=(W/"site/theme.js").read_bytes();(E/"macro-da4d-987-theme-conflict-before.js").write_bytes(before)
preview=E/"macro-da4d-987-theme-emitted.js";assert not preview.exists();preview.write_bytes(candidate)
out={"started_at":now(),"head":H,"incoming":M,"input_tree":T,"owner":"lib.site_assets.emit_theme_js/copy_asset","source_inputs":{p:{"sha256":dg(b),"bytes":len(b),"git_blob":git("rev-parse",T+":"+p).decode().strip()} for p,b in frozen.items()},"mm_brain_source_and_emitted_bytes_equal":True,"mm_brain_version":dg(frozen["templates/mm_brain.js"])[:8],"rjsmin_version":getattr(rjsmin,"__version__",None),"candidate_bytes":len(candidate),"candidate_sha256":dg(candidate),"conflict_before_sha256":dg(before),"state":"PRECHECKS_COMPLETE_OWNER_EMISSION_BEGIN"}
def save():OUT.write_text(json.dumps(out,indent=2)+"\n")
save()
copy_asset("theme.js",W/"templates/theme.js",W/"site")
assert (W/"site/theme.js").read_bytes()==candidate
assert all((W/p).read_bytes()==b for p,b in frozen.items())
subprocess.run(G+["add","--","site/theme.js"],check=True)
out.update(state="OWNER_EMITTED_STAGED",staged_blob=git("rev-parse",":site/theme.js").decode().strip(),finished_at=now());save();print(json.dumps(out,indent=2),flush=True)
