from pathlib import Path
import subprocess,json,datetime,hashlib
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","-C",str(W)];H="608dfad299e2e48ab7703bf0b180e0dca1318229";B="sol/market-os-shared-shell-design-20260924"
def g(*a):return subprocess.check_output(G+list(a)).decode().strip()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert g("rev-parse","HEAD")==H and g("branch","--show-current")==B and not g("status","--porcelain","--untracked-files=no")
assert g("ls-remote","origin","refs/heads/"+B).split()[0]==H
out={"started_at":now(),"head":H,"integrated_main":"9875169102cc6f36a64d465fe7c06f6bb8fb0220","remote_before":g("ls-remote","origin","refs/heads/main","refs/heads/"+B),"scope":"One original-owner main-only fetch after actual GitHubdirty/noPR-CI; no merge yet"}
log=E/"macro-608-main-fetch.log"
with log.open("xb") as f:p=subprocess.run(G+["fetch","--no-tags","origin","main"],stdout=f,stderr=subprocess.STDOUT)
out.update(fetch_exit=p.returncode,log_bytes=log.stat().st_size,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest());assert p.returncode==0
M=g("rev-parse","FETCH_HEAD");out["incoming"]=M;out["merge_base"]=g("merge-base",H,M);out["new_main_changes"]=g("diff","--name-status","9875169102cc6f36a64d465fe7c06f6bb8fb0220",M);out["commits"]=g("log","--format=%H %s","9875169102cc6f36a64d465fe7c06f6bb8fb0220.."+M)
out.update(finished_at=now(),head_unchanged=g("rev-parse","HEAD")==H,clean=not g("status","--porcelain","--untracked-files=no"))
(E/"macro-608-main-reconcile.json").write_text(json.dumps(out,indent=2)+"\n");print(json.dumps(out,indent=2))
