from pathlib import Path
import json,hashlib,subprocess,datetime
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","-C",str(W)];OUT=E/"macro-da4d-main-check.json"
def git(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
assert not OUT.exists()
head=git("rev-parse","HEAD").decode().strip();assert head=="da4df7d1e1ac709055c6fa1d482304a875e81824"
assert not git("status","--porcelain=v1").strip()
out={"started_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"head":head,"reason":"Host and GitHub show main advanced through render and new source jobs while local tests ran; inspect concrete mergeability before publishing. One main-only fetch, no branch/worktree/source mutation."}
f=E/"macro-da4d-main-fetch.log"
with f.open("xb") as log:r=subprocess.run(G+["fetch","--no-tags","origin","refs/heads/main:refs/remotes/origin/main"],stdout=log,stderr=subprocess.STDOUT)
out["fetch_exit"]=r.returncode;out["fetch_log_sha256"]=dg(f.read_bytes())
OUT.write_text(json.dumps(out,indent=2)+"\n")
assert r.returncode==0
main=git("rev-parse","refs/remotes/origin/main").decode().strip()
base=git("merge-base",head,main).decode().strip()
out.update(main=main,merge_base=base)
out["incoming_paths"]=len(git("diff","--name-only",base,main).splitlines())
out["incoming_commits"]=git("log","--format=%H %s",base+".."+main).decode().splitlines()
out["incoming_owned_source_paths"]=git("diff","--name-only",base,main,"--",".github/ci/legacy-jobs.yml","tests/test_ci_pack.py","templates/landing.css","templates/about.html","templates/index.html","lib/macro_suite_labels.py","tests/test_macro_command_copy_law.py","app/deploy/Caddyfile","app/deploy/update.sh","lib/shared_shell.py").decode().splitlines()
with (E/"macro-da4d-main-merge-tree.log").open("xb") as log:
 r=subprocess.run(G+["merge-tree","--write-tree",head,main],stdout=log,stderr=subprocess.STDOUT)
out["merge_tree_exit"]=r.returncode;raw=(E/"macro-da4d-main-merge-tree.log").read_bytes()
out["merge_tree_log_sha256"]=dg(raw);out["merge_tree_log_bytes"]=len(raw)
out["merge_tree_summary"]=raw.decode(errors="replace").splitlines()[:110]
out["head_after"]=git("rev-parse","HEAD").decode().strip();out["status_after"]=git("status","--porcelain=v1").decode()
assert out["head_after"]==head and not out["status_after"]
out["finished_at"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
OUT.write_text(json.dumps(out,indent=2)+"\n");print(json.dumps(out,indent=2),flush=True)
