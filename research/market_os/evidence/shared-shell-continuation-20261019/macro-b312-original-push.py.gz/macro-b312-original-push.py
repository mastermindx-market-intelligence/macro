import datetime,hashlib,json,pathlib,subprocess
W=pathlib.Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=pathlib.Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","-C",str(W)]
H="b312bc4c08cf7633bf8fd259d2d46ec545fa120f";R="e2d10f933587f58be8716505529a37f8839901f7";B="sol/market-os-shared-shell-design-20260924";T="5ffad38270d85abe5e7ace03f3c291ce405145a4"
out=E/"macro-b312-original-push.json";log=E/"macro-b312-original-push.log";assert not out.exists() and not log.exists()
def git(*a):return subprocess.check_output(G+list(a),text=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert git("rev-parse","HEAD").strip()==H and git("branch","--show-current").strip()==B
assert git("show","-s","--format=%T","HEAD").strip()==T and not git("status","--porcelain=v1").strip()
assert git("ls-remote","--heads","origin","refs/heads/"+B).split()[0]==R
subprocess.run(G+["merge-base","--is-ancestor",R,H],check=True)
p=json.loads(subprocess.check_output(["gh","pr","view","7949","--json","url,state,headRefOid,labels,autoMergeRequest"],cwd=W,text=True))
assert p["state"]=="OPEN" and p["headRefOid"]==R and p["autoMergeRequest"] is None
assert not any(x["name"]=="merge-on-green" for x in p["labels"])
assert "NONBLOCKING" in (E/"macro-140bd-3b49-proof-review.md").read_text()
r={"started_at":now(),"operation":"normal fast-forward push to original PR7949 branch; no force, merge or arm","local_head":H,"tree":T,"remote_before":R,"branch":B,"pr_before":p,"push_attempted":True}
out.write_text(json.dumps(r,indent=2)+"\n")
with log.open("xb") as f:c=subprocess.run(G+["push","--porcelain","origin","HEAD:refs/heads/"+B],stdout=f,stderr=subprocess.STDOUT,timeout=120)
r["push_exit"]=c.returncode;r["log"]={"path":str(log),"bytes":log.stat().st_size,"sha256":hashlib.sha256(log.read_bytes()).hexdigest()};out.write_text(json.dumps(r,indent=2)+"\n")
assert c.returncode==0,log.read_text()
r["remote_after"]=git("ls-remote","--heads","origin","refs/heads/"+B).split()[0]
assert r["remote_after"]==H and git("rev-parse","HEAD").strip()==H and not git("status","--porcelain=v1").strip()
r["pr_after"]=json.loads(subprocess.check_output(["gh","pr","view","7949","--json","url,state,headRefOid,labels,autoMergeRequest"],cwd=W,text=True))
assert r["pr_after"]["headRefOid"]==H and r["pr_after"]["state"]=="OPEN" and r["pr_after"]["autoMergeRequest"] is None
assert not any(x["name"]=="merge-on-green" for x in r["pr_after"]["labels"])
r.update(finished_at=now(),status="ORIGINAL_BRANCH_PUSH_CONFIRMED_UNARMED",clean=True,hosted_ci_accepted=False,production_mutation=False)
out.write_text(json.dumps(r,indent=2)+"\n");print(json.dumps(r,indent=2),flush=True)
