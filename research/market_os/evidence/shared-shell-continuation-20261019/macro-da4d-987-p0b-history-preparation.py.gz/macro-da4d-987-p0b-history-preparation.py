from pathlib import Path
import subprocess,json,hashlib,datetime,copy
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107")
H="da4df7d1e1ac709055c6fa1d482304a875e81824";M="9875169102cc6f36a64d465fe7c06f6bb8fb0220";P="mockups/evidence/prophet-p0b-zero-fouc/"
OUT=E/"macro-da4d-987-p0b-history-preparation.json";BACK=E/"macro-da4d-987-p0b-before-history"
def git(*a):return subprocess.check_output(["git","--no-optional-locks","-C",str(W),*a])
def dg(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert not OUT.exists() and not BACK.exists()
assert git("rev-parse","HEAD").decode().strip()==H and git("rev-parse","MERGE_HEAD").decode().strip()==M
paths=[P+n for n in ["manifest.json","mobile-layout.json","mobile-layout-canada.json"]]
assert set(git("diff","--name-only","--diff-filter=U").decode().splitlines())==set(paths)
parent={r:{p:git("show",r+":"+p) for p in paths} for r in [H,M]}
for r,label in [(H,"H"),(M,"M")]:
 for p,b in parent[r].items():assert b==(E/"macro-da4d-987-p0b-immutable-parents"/(label+"-"+Path(p).name)).read_bytes(),(label,p)
hp=json.loads(parent[H][paths[0]]);mp=json.loads(parent[M][paths[0]])
assert set(hp)==set(mp)
assert all(hp[k]==mp[k] for k in hp if k not in ["repair_extension","repair_extension_history"])
hh=hp["repair_extension_history"];mh=mp["repair_extension_history"];assert len(hh)==10 and len(mh)==7
mapping=[]
for entry in mh:
 hits=[i for i,x in enumerate(hh) if x==entry];assert len(hits)==1;mapping.append(hits[0])
assert mapping==[0,1,2,3,4,5,7]
assert hp["repair_extension"]!=mp["repair_extension"]
for r,d in [(H,hp),(M,mp)]:
 assert not any(x.get("extension")==d["repair_extension"] for x in hh)
assert dg(parent[H][paths[0]])=="14f79d2a743a267eca2f20e6f6029339b3fccdd7957eabed65898528482a84c0"
assert dg(parent[M][paths[0]])=="330c620d173928a9d7772fe07e179404c08ec2f5f3ba9e2ba37bbe0a6fc81fb9"
history=copy.deepcopy(hh)
for r,d in [(H,hp),(M,mp)]:history.append({"extension":d["repair_extension"],"prior_manifest_sha256":dg(parent[r][paths[0]]),"source_head":r})
assert len(history)==12 and history[:10]==hh
candidate=copy.deepcopy(hp);candidate["repair_extension_history"]=history
for p in paths[1:]:assert json.loads(parent[H][p])["historical_baseline"]==json.loads(parent[M][p])["historical_baseline"]
result={paths[0]:(json.dumps(candidate,ensure_ascii=False,sort_keys=True,indent=2)+"\n").encode(),**{p:parent[H][p] for p in paths[1:]}}
out={"started_at":now(),"head":H,"incoming":M,"state":"PREPARED_NOT_WRITTEN","operation":"Preserve H ten unchanged entries and both complete current extensions; exact H mobile receipts only as historical input to original fresh producer","final_candidate_accepted":False,"fresh_browser_run":False,"history_entries":12,"incoming_history_indices_in_H":mapping,"parent_receipts":{r:{p:{"bytes":len(b),"sha256":dg(b)} for p,b in rows.items()} for r,rows in parent.items()},"intermediate_files":{p:{"bytes":len(b),"sha256":dg(b)} for p,b in result.items()},"index_staged":False}
def save():OUT.write_text(json.dumps(out,indent=2)+"\n")
save();BACK.mkdir()
for p in paths:(BACK/Path(p).name).write_bytes((W/p).read_bytes())
for p,b in result.items():(W/p).write_bytes(b)
assert all((W/p).read_bytes()==b for p,b in result.items())
out.update(state="HISTORICAL_INPUT_PREPARED",finished_at=now());save()
print(json.dumps({"receipt":str(OUT),"sha256":dg(OUT.read_bytes()),"state":out["state"],"history_entries":12,"final_candidate_accepted":False,"fresh_browser_run":False},indent=2))
