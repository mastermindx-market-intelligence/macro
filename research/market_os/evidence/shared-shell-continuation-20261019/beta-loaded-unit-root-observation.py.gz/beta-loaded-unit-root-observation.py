from pathlib import Path
import subprocess,json,hashlib,datetime
E=Path("/tmp/shared-shell-css-visual-20261019T1107");source=E/"beta-loaded-unit-root-observer.py";raw=source.read_bytes();out=E/"beta-loaded-unit-root-observation.json";assert not out.exists()
record={"started_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"remote_source_bytes":len(raw),"remote_source_sha256":hashlib.sha256(raw).hexdigest(),"operation":"Read-only loaded beta unit; no service or installer operation","state":"STARTING"}
def save():out.write_text(json.dumps(record,indent=2)+"\n")
save()
args=["ssh","-T","-i","/Users/chriswong/.ssh/macro_dashboard_deploy_v2","-o","IdentitiesOnly=yes","-o","IdentityAgent=none","-o","BatchMode=yes","-o","StrictHostKeyChecking=yes","-o","ConnectTimeout=8","root@146.190.142.17","python3 -I -B -"]
r=subprocess.run(args,input=raw,capture_output=True,timeout=35)
for suffix,b in [(".stdout.json",r.stdout),(".stderr.log",r.stderr)]:
 p=E/("beta-loaded-unit-root-observation"+suffix);assert not p.exists();p.write_bytes(b)
record.update(exit=r.returncode,stdout_bytes=len(r.stdout),stdout_sha256=hashlib.sha256(r.stdout).hexdigest(),stderr_bytes=len(r.stderr),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),state="COMPLETE_READ")
save();assert r.returncode==0 and not r.stderr
j=json.loads(r.stdout);print(json.dumps({"receipt":record,"loaded_unit":j},indent=2),flush=True)
