import copy,datetime,hashlib,json,os,pathlib,re,runpy,subprocess,sys,yaml
W=pathlib.Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=pathlib.Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","-C",str(W)]
stem="macro-140bd-3b49-scope-repair";outpath=E/(stem+".json");diag=E/"macro-140bd-3b49-closure-before.json"
def git(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
R=json.loads((E/"macro-140bd-3b49-composition.json").read_text())
assert not outpath.exists() and not diag.exists()
assert git("rev-parse","HEAD").decode().strip()==R["head"] and git("rev-parse","MERGE_HEAD").decode().strip()==R["incoming"]
initial=git("write-tree").decode().strip();assert initial==R["index"] and not git("diff","--name-only").strip()
mp=W/".github/ci/legacy-jobs.yml";before=mp.read_bytes();test=(W/"tests/test_ci_pack.py").read_bytes()
os.chdir(W);sys.path.insert(0,str(W))
started=now();ns=runpy.run_path(str(W/"tests/test_ci_pack.py"))
findings={k:sorted(map(str,v)) for k,v in ns["curated_exclusive_closure_findings"](ns["MANIFEST"]).items()}
diagnostic={"started_at":started,"finished_at":now(),"head":R["head"],"incoming":R["incoming"],"index":initial,"manifest_sha256":dg(before),"test_sha256":dg(test),"owner":"tests/test_ci_pack.py curated_exclusive_closure_findings; same canonical computation used by the existing test and differential contract gate","findings":findings,"scope":"Actual unchanged integrated-tree diagnostic, not a pytest or hosted admission result"}
assert git("write-tree").decode().strip()==initial and mp.read_bytes()==before and (W/"tests/test_ci_pack.py").read_bytes()==test
diag.write_text(json.dumps(diagnostic,indent=2)+"\n");print(json.dumps({"actual_closure_findings":findings,"diagnostic":str(diag)}),flush=True)
expected={"china-mechanics-display":["lib/shared_shell.py"],"pick-lab-cn-render":["lib/shared_shell.py","lib/site_assets.py"]}
assert findings==expected,findings
text=before.decode();b=yaml.safe_load(before);c=copy.deepcopy(b)
for job,paths in expected.items():
 match=re.search(r"(?ms)^  "+re.escape(job)+r":\n.*?(?=^  [A-Za-z0-9_-]+:\n|\Z)",text);assert match,job
 block=match.group();anchor='      - "lib/pages.py"\n';assert block.count(anchor)==1 and not any('      - "'+p+'"\n' in block for p in paths)
 replacement=block.replace(anchor,anchor+"".join('      - "'+p+'"\n' for p in paths),1)
 text=text[:match.start()]+replacement+text[match.end():]
 cp=c["jobs"][job]["paths"];at=cp.index("lib/pages.py")+1;cp[at:at]=paths
after=text.encode();assert yaml.safe_load(after)==c
assert set(c)==set(b) and len(c["jobs"])==336
out={"started_at":now(),"head":R["head"],"incoming":R["incoming"],"index_before":initial,"diagnostic_sha256":dg(diag.read_bytes()),"actual_missing_paths":findings,"exact_added_paths":expected,"manifest_before_sha256":dg(before),"manifest_after_sha256":dg(after),"all_other_manifest_semantics_unchanged":True,"test_sha256_unchanged":dg(test),"manifest_three_way_all_fields_and_ids_pass":True,"writes_started":True}
outpath.write_text(json.dumps(out,indent=2)+"\n")
mp.write_bytes(after);subprocess.run(G+["add","--",".github/ci/legacy-jobs.yml"],check=True)
out["index"]=git("write-tree").decode().strip();out["finished_at"]=now()
assert not git("diff","--name-only").strip() and not git("ls-files","-u").strip()
assert (W/"tests/test_ci_pack.py").read_bytes()==test and git("show",":.github/ci/legacy-jobs.yml")==after
out["owning_four_node_validation"]="pending on frozen repaired index; no fresh PASS claimed"
outpath.write_text(json.dumps(out,indent=2)+"\n")
patch=git("diff",initial,out["index"],"--",".github/ci/legacy-jobs.yml");(E/(stem+".patch")).write_bytes(patch)
print(json.dumps({**out,"patch_sha256":dg(patch)},indent=2),flush=True)
