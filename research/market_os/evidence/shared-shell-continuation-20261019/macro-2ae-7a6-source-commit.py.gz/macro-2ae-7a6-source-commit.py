from pathlib import Path
import subprocess,json,hashlib,datetime
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","-C",str(W)]
H="2ae6498d0b9f2a088af2e827abf6527799757f8c";M="7a6e21cb7d6a38855b7e06432c94f61acb0fe6f1";BRANCH="sol/market-os-shared-shell-design-20260924";OUT=E/"macro-2ae-7a6-source-commit.json"
def git(*a):return subprocess.check_output(G+list(a))
def dg(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert not OUT.exists()
tp=E/"macro-2ae-7a6-composed-tests.json";lp=E/"macro-2ae-7a6-retained-browser-lineage.json";tests=json.loads(tp.read_text());lineage=json.loads(lp.read_text())
assert tests["pass"] and tests["index_unchanged"] and tests["source_unchanged"] and len(tests["commands"])==6
assert lineage["state"]=="RETAINED_FIXTURE_LINEAGE_VERIFIED" and lineage["index_and_source_unchanged"]
assert git("rev-parse","HEAD").decode().strip()==H and git("rev-parse","MERGE_HEAD").decode().strip()==M and git("branch","--show-current").decode().strip()==BRANCH
tree=git("write-tree").decode().strip();assert tree==tests["after"]["index_tree"]==lineage["source_index"]
assert not git("ls-files","-u").strip() and not git("diff","--name-only").strip()
for p,h in tests["source_sha256"].items():assert dg((W/p).read_bytes())==h,p
remote=git("ls-remote","origin","refs/heads/"+BRANCH).decode().split();assert remote==[H,"refs/heads/"+BRANCH]
count=len(git("diff","--cached","--name-only",M).decode().splitlines());assert count<3000
subprocess.run(G+["diff","--cached","--check",M],check=True)
message=E/"macro-2ae-7a6-source-commit-message.txt";assert not message.exists()
message.write_text("Merge current main into original Shared Shell delivery branch\n\nCompose MedTech and Shell CI dependencies and updater triggers. Keep one\ncanonical labor coverage mapping and both parents' regression guarantees;\nregenerate labor through its existing owner and canonical adoption path.\n\nAll 719 focused tests pass, including MedTech deployment. Existing packing\nbounds remain unchanged. Retain P0B and About proof through exact input\nlineage; hosted admission and public beta acceptance remain separate.\n")
out={"started_at":now(),"state":"PRECHECKED_COMMIT_BEGIN","head_before":H,"incoming":M,"remote_before":H,"source_tree":tree,"changed_paths_vs_incoming":count,"test_receipt_sha256":dg(tp.read_bytes()),"retained_browser_lineage_sha256":dg(lp.read_bytes()),"message_sha256":dg(message.read_bytes())}
def save():OUT.write_text(json.dumps(out,indent=2)+"\n")
save();log=E/"macro-2ae-7a6-source-commit.log";assert not log.exists()
with log.open("xb") as f:r=subprocess.run(G+["commit","-F",str(message)],stdout=f,stderr=subprocess.STDOUT)
out.update(commit_exit=r.returncode,log_bytes=log.stat().st_size,log_sha256=dg(log.read_bytes()));save();assert r.returncode==0
head=git("rev-parse","HEAD").decode().strip()
assert git("show","-s","--format=%P",head).decode().strip().split()==[H,M]
assert git("rev-parse","HEAD^{tree}").decode().strip()==tree and not git("status","--porcelain=v1").strip()
out.update(state="SOURCE_COMMITTED_LOCAL_ONLY",head_after=head,parents=[H,M],clean=True,pushed=False,finished_at=now());save();print(json.dumps(out,indent=2))