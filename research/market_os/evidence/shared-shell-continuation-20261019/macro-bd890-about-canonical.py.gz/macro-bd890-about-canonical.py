from pathlib import Path
import subprocess,json,hashlib,datetime,sys,os
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");K=Path("/tmp/shared-shell-local-browser-r7-20261019/kit")
D=E/"macro-bd890-about-canonical";OUT=E/"macro-bd890-about-canonical.json";MF=E/"macro-bd890-about-fixture-manifest.json";H="bd89047e4e403a93183c6a4763274e09acfdd044";PY=str(W/".venv-shared-shell/bin/python")
def dg(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*a):return subprocess.check_output(["git","--no-optional-locks","-C",str(W),*a])
assert not OUT.exists() and not D.exists() and not MF.exists()
assert git("rev-parse","HEAD").decode().strip()==H and not git("status","--porcelain").strip()
out={"started_at":now(),"source_head":H,"source_tree":git("rev-parse","HEAD^{tree}").decode().strip(),"scope":"Existing canonical anonymous About-only browser capture for missing visual-evidence matrix. Source input hashes bound separately; About LIGHT_ONLY canvas retained. No Terminal qualification, public beta or auth proof.","commands":[]}
def save():OUT.write_text(json.dumps(out,indent=2)+"\n")
def run(name,args):
 log=E/("macro-bd890-about-"+name+".log");assert not log.exists()
 row={"name":name,"argv":args,"started_at":now(),"log":str(log)};out["commands"].append(row);save()
 with log.open("xb") as f:p=subprocess.run(args,cwd=W,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,"PYTHONDONTWRITEBYTECODE":"1"},timeout=600)
 row.update(exit=p.returncode,finished_at=now(),log_bytes=log.stat().st_size,log_sha256=dg(log.read_bytes()));save()
 print(json.dumps({"name":name,"exit":p.returncode,"tail":log.read_text(errors="replace").splitlines()[-10:]}),flush=True);return p.returncode
save()
try:
 assert run("fixture-manifest",[PY,"-B",str(K/"fixture_manifest.py"),"--macro-root",str(W),"--macro-head",H,"--out",str(MF)])==0
 mf=json.loads(MF.read_text());out["fixture_inventory"]={"path":str(MF),"sha256":dg(MF.read_bytes()),"files":len(mf["files"])}
 out["capture_owner"]={"path":"scripts/capture_page_evidence.py","sha256":dg((W/"scripts/capture_page_evidence.py").read_bytes())};save()
 args=[PY,"-B","scripts/capture_page_evidence.py","--site-dir","site","--routes","/about.html","--viewports","desktop,mobile","--locales","en,zh","--themes","light,dark","--max-pages","1","--settle-ms","1500","--manifest",str(D/"manifest.json"),"--smells",str(D/"ux_smell_report.json"),"--output-dir",str(D/"evidence")]
 rc=run("canonical-capture",args);out["capture_exit"]=rc
 m=json.loads((D/"manifest.json").read_text());out["manifest"]={"schema":m.get("schema"),"bytes":(D/"manifest.json").stat().st_size,"sha256":dg((D/"manifest.json").read_bytes())}
 out["source_unchanged"]=all(dg((W/"site"/p.lstrip("/")).read_bytes())==row["sha256"] for p,row in mf["files"].items())
 out["capture_owner_unchanged"]=dg((W/"scripts/capture_page_evidence.py").read_bytes())==out["capture_owner"]["sha256"]
 out["head_unchanged"]=git("rev-parse","HEAD").decode().strip()==H;out["worktree_clean"]=not git("status","--porcelain").strip()
 out["capture_completed"]=rc==0 and out["source_unchanged"] and out["capture_owner_unchanged"] and out["head_unchanged"] and out["worktree_clean"]
 out["gate_acceptance_pending"]=True
except BaseException as ex:out["error"]=repr(ex);out["capture_completed"]=False
out["finished_at"]=now();save();print(json.dumps(out,indent=2));sys.exit(0 if out["capture_completed"] else 1)
