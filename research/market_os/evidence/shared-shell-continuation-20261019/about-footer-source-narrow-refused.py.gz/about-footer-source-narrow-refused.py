#!/usr/bin/env python3
from pathlib import Path
import sys,subprocess,json,hashlib,datetime
from urllib.parse import urlsplit
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27")
E=Path("/tmp/shared-shell-css-visual-20261019T1107")
sys.path.insert(0,str(W))
from lib.pages import optimize_assets_text,write_page
sha=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=W,text=True).strip()=="b312bc4c08cf7633bf8fd259d2d46ec545fa120f"
target=(W/"site/landing.css").resolve();stamp=sha(target.read_bytes())[:8];assert stamp=="c1ea6263"
rows=[]
for name in ["market-terminal.html","market-dashboards.html","mastermind-ai.html"]:
 rel="site/products/"+name;p=W/rel;before=(E/"about-footer-source"/"before"/rel).read_bytes();current=p.read_bytes()
 def h(url):
  u=urlsplit(url)
  return stamp if not u.scheme and not u.netloc and (p.parent/u.path).resolve()==target else None
 candidate=optimize_assets_text(before.decode(),h)
 assert candidate==before.decode().replace("landing.css?v=a44e4256","landing.css?v=c1ea6263")
 write_page(p,candidate);assert p.read_bytes()==candidate.encode()
 rows.append({"path":rel,"initial_canonical_candidate_sha256":sha(current),"final_sha256":sha(p.read_bytes()),"only_change":"landing.css query through incumbent lib.pages.optimize_assets_text"})
patch=subprocess.check_output(["git","diff"],cwd=W,text=True);(E/"about-footer-source-final.patch").write_text(patch)
r={"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"base_head":"b312bc4c08cf7633bf8fd259d2d46ec545fa120f","reason":"Constrain product normalization to the changed landing asset; initial broader canonical result remains retained as history.","preceding_narrow_attempt":"Refused before any writes because resolved target was compared with lexical worktree path; corrected identity comparison.","prior_guard_environment":"System python template guard exited1 because rjsmin unavailable; rerun with established .venv-shared-shell/bin/python, not a source-theme defect.","products":rows,"final_patch_sha256":sha(patch.encode()),"diff_stat":subprocess.check_output(["git","diff","--stat"],cwd=W,text=True)}
(E/"about-footer-source-reconciliation.json").write_text(json.dumps(r,indent=2)+"\n");print(json.dumps(r,indent=2))
