from pathlib import Path
import subprocess,json,hashlib,datetime
W=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27");E=Path("/tmp/shared-shell-css-visual-20261019T1107");G=["git","--no-optional-locks","-C",str(W)]
H="da4df7d1e1ac709055c6fa1d482304a875e81824";M="9875169102cc6f36a64d465fe7c06f6bb8fb0220";OUT=E/"macro-da4d-987-missing-object-census.json"
assert not OUT.exists()
assert subprocess.check_output(G+["rev-parse","HEAD"],text=True).strip()==H
assert not subprocess.check_output(G+["status","--porcelain=v1"]).strip()
out={"started_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"head":H,"incoming":M,"scope":"Read-only reachable-object census using --missing=print; no lazy hydration, source/index mutation, or retry."}
def save():OUT.write_text(json.dumps(out,indent=2)+"\n")
save()
args=G+["rev-list","--objects","--missing=print",M,"^"+H]
r=subprocess.run(args,capture_output=True,timeout=90)
raw=E/"macro-da4d-987-missing-object-census.txt";assert not raw.exists();raw.write_bytes(r.stdout)
out.update(exit=r.returncode,stderr=r.stderr.decode(errors="replace"),stdout_bytes=len(r.stdout),stdout_sha256=hashlib.sha256(r.stdout).hexdigest());save();assert r.returncode==0
missing={x[1:].decode() for x in r.stdout.splitlines() if x.startswith(b"?")}
tree=subprocess.check_output(G+["ls-tree","-rz",M]);paths={}
for rec in tree.split(b"\0"):
 if not rec:continue
 left,p=rec.split(b"\t",1);mode,kind,oid=left.decode().split()
 if oid in missing:paths.setdefault(oid,[]).append(p.decode())
out.update(all_reachable_missing_count=len(missing),incoming_head_missing_objects=[{"oid":o,"paths":paths[o]} for o in sorted(paths)],incoming_head_missing_count=len(paths),bad30d_present_in_missing_set="30d1e9578fdd46cc944321c84b1075e75088be7b" in missing,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
save();print(json.dumps({k:v for k,v in out.items() if k!="incoming_head_missing_objects"},indent=2),flush=True);print(json.dumps(out["incoming_head_missing_objects"][:20],indent=2),flush=True)
