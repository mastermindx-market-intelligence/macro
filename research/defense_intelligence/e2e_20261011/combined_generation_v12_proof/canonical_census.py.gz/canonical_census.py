import sys,json,time,subprocess
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from scripts import check_contract_delta as c
spec=json.loads(Path(sys.argv[1]).read_text())
t=time.monotonic()
head=c._head_findings()
head.update(c._head_control_plane_findings(spec))
head["source_sha"]=subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()
head["elapsed_seconds"]=round(time.monotonic()-t,2)
Path(sys.argv[2]).write_text(json.dumps(head,indent=2,sort_keys=True)+"\n")
print(json.dumps({"source_sha":head["source_sha"],"elapsed_seconds":head["elapsed_seconds"],"output":sys.argv[2]}))
