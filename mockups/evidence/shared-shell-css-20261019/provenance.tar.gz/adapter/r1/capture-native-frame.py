#!/usr/bin/env python3
"""Adapter for the existing capture owner; uses actual locally owned Playwright observations."""
import sys,json,subprocess,os,signal,hashlib,dataclasses
from pathlib import Path
REPO=Path("/Users/chriswong/Documents/Cluade/macro-main/.claude/worktrees/shared-shell-r27")
ROOT=Path("/tmp/shared-shell-css-visual-20261019T1107")
sys.path.insert(0,str(REPO))
from scripts import capture_page_evidence as capture
class NativeFrameDriver:
    def __init__(self,**kwargs):
        self.options=kwargs
    def capture(self,*,url,cell,timeout_s):
        slug=hashlib.sha256(cell.cell_id.encode()).hexdigest()[:16]
        out=Path(os.environ["MMX_CAPTURE_CELL_DIR"])
        payload={**self.options,"url":url,"cell":{**dataclasses.asdict(cell),"cell_id":cell.cell_id},
          "timeout_s":timeout_s,"macro_root":str(REPO),"macro_head":"b2ff80dfb558ea05d6c749391ca37b8ea4ad6df4",
          "terminal_root":"/Volumes/Mastermind 2/agent-workspaces/terminal/web/shared-shell-public-context-20261019",
          "terminal_head":"4bfca4043e1779b1bf74dd388e40783e3c4000e4",
          "css_sha256":"b1918ccaa2294f18c0fd5bca123e38267251c7e9d9a7c4fce1f296ef9e4c3c1e",
          "fixture_manifest":str(ROOT/"fixture-manifest.json"),"observer_script":capture._OBSERVER_SCRIPT.strip(),
          "shot":str(out/(slug+".png")),"evidence":str(out/(slug+".json"))}
        print("CAPTURE_START "+cell.cell_id,flush=True)
        process=subprocess.Popen(["node",str(ROOT/"adapter/native-frame-capture.cjs")],
          stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
        try:
            stdout,stderr=process.communicate(json.dumps(payload),timeout=max(180,timeout_s+60))
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGTERM)
            try: stdout,stderr=process.communicate(timeout=15)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid,signal.SIGKILL);stdout,stderr=process.communicate()
            (out/(slug+".process.json")).write_text(json.dumps({"exit":process.returncode,"timeout":True,"stderr":stderr}))
            raise capture.CaptureUnavailable("Owned native cell timed out; exact group stopped and evidence retained")
        (out/(slug+".process.json")).write_text(json.dumps({"exit":process.returncode,"stderr":stderr}))
        try: result=json.loads(stdout)
        except Exception as exc: raise capture.CaptureUnavailable("Native capture returned no parseable observation: "+stderr[-3000:]) from exc
        values=result["observation"]
        digest=values.pop("screenshot_sha256")
        png=Path(result["screenshot_path"]).read_bytes() if result["screenshot_path"] else b""
        if png and hashlib.sha256(png).hexdigest()!=digest: raise capture.CaptureUnavailable("Actual screenshot digest mismatch")
        print("CAPTURE_RESULT "+json.dumps({"cell":cell.cell_id,"loaded":values["loaded"],"exit":process.returncode,
          "errors":len(values["console_errors"]),"failed_responses":len(values["failed_responses"]),"error":values["error"]}),flush=True)
        return capture.CellObservation(**values,screenshot_png=png)
    def close(self): pass
if __name__=="__main__":
    raise SystemExit(capture.main(sys.argv[1:],driver_factory=NativeFrameDriver))
