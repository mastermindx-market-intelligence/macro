
async function main() {
  const input = JSON.parse(fs.readFileSync(0, "utf8"));
  const startedAt = new Date().toISOString();
  assert.equal(input.user_agent, "mastermind-page-census/1.0 (internal product observability)");
  assert(ROUTES.some(r => input.url === PARENT + r), "Only the original two parent routes are admitted");
  assert.equal(input.cell.force_state, null, "No forced presentation state");
  const fixtureBytes = fs.readFileSync(input.fixture_manifest);
  assert.equal(hash(fixtureBytes), input.fixture_manifest_sha256, "Frozen fixture identity changed");
  const manifest = JSON.parse(fixtureBytes);
  assert.equal(manifest.schema, "mastermind.shared_shell_local_fixture.v1");
  assert.equal(manifest.macro_head, input.macro_head);
  assert.deepEqual(manifest.routes, ROUTES);
  assert.equal(manifest.files["/shared_shell.css"].sha256, input.css_sha256);
  assert.equal(fs.realpathSync(manifest.site_directory),fs.realpathSync(path.join(input.macro_root,"site")));
  const childFiles = new Set(Object.keys(manifest.files));
  function verifySource() {
    for (const [root, expected] of [[input.macro_root,input.macro_head],[input.terminal_root,input.terminal_head]]) {
      assert.equal(execFileSync("git", ["rev-parse", "HEAD"], {cwd:root,encoding:"utf8"}).trim(), expected);
      assert.equal(execFileSync("git",["status","--porcelain=v1","--untracked-files=no"],{cwd:root,encoding:"utf8"}).trim(),"","Tracked source changed");
    }
    for (const [route, expected] of Object.entries(manifest.files)) {
      const bytes = fs.readFileSync(path.join(manifest.site_directory, route.slice(1)));
      assert.equal(bytes.length, expected.bytes, route + " size changed");
      assert.equal(hash(bytes), expected.sha256, route + " changed");
    }
    const css = fs.readFileSync(path.join(input.macro_root,"templates/shared_shell.css"));
    assert.equal(hash(css), input.css_sha256);
    assert.equal(hash(fs.readFileSync(path.join(input.macro_root,"site/shared_shell.css"))), input.css_sha256);
  }
  verifySource();
  const pw = require(require.resolve("playwright", {paths:[path.join(input.terminal_root,"terminal")]}));
  const evidence = {started_at:startedAt, cell:input.cell, parent_documents:[], native_parent_network:[],
    native_response_gates:[], transport_failures:[], blocked_http:[], requests:[], loaded_macro_files:{}, effects:{local_development_websocket_connection_requested:false}, allowed_websockets:[], blocked_websockets:[],
    response_bodies:[], request_failures:[], unreadable_body_sizes:[], console_errors:[], failed_responses:[],
    cleanup:{context_closed:false,browser_closed:false}, screenshot_scope:"actual parent viewport containing the active Macro iframe",
    metrics_scope:"actual active Macro iframe", fixture_manifest_sha256:hash(fixtureBytes),
    macro_head:input.macro_head, preview_terminal_head:input.terminal_head, application_release_acceptance:false};
  let context, page, browser, gate, screenshot;
  let failure = null, observed = {}, applied = {};
  let requests = 0, bytesTotal = 0;
  const pending = new Set();
  function track(p) {
    const item = Promise.resolve(p).catch(e=>evidence.transport_failures.push(String(e.message||e))).finally(()=>pending.delete(item));
    pending.add(item);
  }
  async function settle() { while (pending.size) await Promise.all([...pending]); }
  let cleanupPromise;
  async function bounded(promise,label,ms=15000) {
    let timer;
    try { return await Promise.race([promise,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error(label+" timed out")),ms);})]); }
    finally { clearTimeout(timer); }
  }
  function cleanup() {
    if (cleanupPromise) return cleanupPromise;
    cleanupPromise=(async()=>{
      const errors=[];
      try {
        if(gate) gate.closing();
        try { if(context) {await bounded(context.close(),"context.close");evidence.cleanup.context_closed=true;} } catch(e) {errors.push(String(e));}
        try { await bounded(settle(),"telemetry settlement",8000); } catch(e) {errors.push(String(e));}
        try { if(gate) await bounded(gate.settled(),"response gate settlement",8000); } catch(e) {errors.push(String(e));}
      } finally {
        try { if(browser) {await bounded(browser.close(),"browser.close");evidence.cleanup.browser_closed=true;} } catch(e) {errors.push(String(e));}
      }
      evidence.cleanup.errors=errors;
      if(errors.length) throw new Error(errors.join("; "));
    })();
    return cleanupPromise;
  }
  process.once("SIGTERM", () => { cleanup().finally(()=>process.exit(143)); });
  process.once("SIGINT", () => { cleanup().finally(()=>process.exit(130)); });
  try {
    browser = await pw.chromium.launch({headless:input.headless});
    evidence.browser_version = browser.version();
    evidence.playwright_version = require(require.resolve("playwright/package.json", {paths:[path.join(input.terminal_root,"terminal")]})).version;
    context = await browser.newContext({viewport:{width:input.cell.width,height:input.cell.height},
      userAgent:input.user_agent,locale:input.cell.locale==="zh"?"zh-CN":"en-US",colorScheme:input.cell.theme,
      deviceScaleFactor:1,serviceWorkers:"block",acceptDownloads:false});
    page = await context.newPage();
    page.setDefaultTimeout(25000);
    page.setDefaultNavigationTimeout(input.timeout_s*1000);
    context.on("page", other=>{if(other!==page){evidence.transport_failures.push("Unexpected popup");track(other.close());}});
    page.on("download", d=>{evidence.transport_failures.push("Unexpected download");track(d.cancel());});
    page.on("console", m=>{if(m.type()==="error") evidence.console_errors.push({text:m.text(),source_url:m.location().url||null});});
    page.on("pageerror", e=>evidence.console_errors.push({text:"pageerror: "+String(e.message||e),source_url:null}));
    page.on("request", ()=>requests++);
    page.on("requestfailed", req=>evidence.request_failures.push({url:logURL(req.url()),method:req.method(),error:req.failure()?.errorText||"unknown"}));
    page.on("requestfinished", req=>track((async()=>{
      try { bytesTotal += Number((await req.sizes()).responseBodySize||0); }
      catch(e) { evidence.unreadable_body_sizes.push({url:logURL(req.url()),error:String(e.message||e)}); }
    })()));
    page.on("response", response=>track((async()=>{
      if(response.status()>=400) evidence.failed_responses.push({url:logURL(response.url()),status:response.status()});
      const u = new URL(response.url());
      if(u.origin!==CHILD || response.request().method()!=="GET" || !response.ok()) return;
      const expected = manifest.files[u.pathname];
      assert(expected,"Unadmitted child response");
      assert.equal(response.headers()["x-mmx-fixture-manifest"],hash(fixtureBytes),"Child manifest identity mismatch");
      const b = await response.body();
      assert.equal(b.length,expected.bytes,"Child response size mismatch");
      assert.equal(hash(b),expected.sha256,"Child response digest mismatch");
      evidence.response_bodies.push({url:logURL(response.url()),sha256:hash(b),bytes:b.length});
    })()));
    gate = await installTransport(context,page,{childFiles,site:manifest.site_directory,manifest,preflight:{fixture_manifest_sha256:hash(fixtureBytes)}},evidence,{cssMissing:false});
    await context.addCookies(["mm_e2e_rs30","mm_e2e_guest"].map(name=>({name,value:"1",url:PARENT,sameSite:"Lax"})));
    const response=await page.goto(input.url,{waitUntil:"domcontentloaded"});
    assert.equal(response.status(),200);
    await page.locator("#shared-shell-content[aria-busy=false]").waitFor({state:"visible"});
    const host = page.locator("iframe[data-shared-shell-frame]");
    assert.equal(await host.count(),1);
    let frame=await (await host.elementHandle()).contentFrame();
    assert(frame,"Actual content frame is absent");
    await frame.waitForFunction(()=>document.documentElement.dataset.mmxSharedShell==="1",{},{timeout:25000});
    const readState=()=>frame.evaluate(()=>({theme:document.documentElement.dataset.theme,locale:document.documentElement.dataset.lang}));
    evidence.initial_applied = await readState();
    const controls = [
      {key:"theme",desired:input.cell.theme==="light",name:/^(Light theme|浅色主题)$/},
      {key:"locale",desired:input.cell.locale==="zh",name:/^(Chinese language|中文界面)$/}
    ];
    evidence.ui_actions=[];
    for(const control of controls){
      const locator=page.getByRole("button",{name:control.name});
      assert.equal(await locator.count(),1,"Exactly one visible public "+control.key+" control");
      const before=await locator.getAttribute("aria-pressed");
      assert(["true","false"].includes(before),"Control lacks observed state");
      if((before==="true")!==control.desired){
        await locator.click();
        evidence.ui_actions.push({control:control.key,action:"click",before,desired:String(control.desired)});
      }
    }
    await frame.waitForFunction(state=>document.documentElement.dataset.theme===state.theme && document.documentElement.dataset.lang===state.locale,
      {theme:input.cell.theme,locale:input.cell.locale},{timeout:25000});
    await page.locator("#shared-shell-content[aria-busy=false]").waitFor({state:"visible"});
    await page.waitForTimeout(Math.max(400,input.settle_ms));
    evidence.actual_user_agent = await page.evaluate(()=>navigator.userAgent);
    assert.equal(evidence.actual_user_agent,input.user_agent,"UA was not actually applied");
    evidence.actual_viewport = await page.evaluate(()=>({width:innerWidth,height:innerHeight}));
    assert.deepEqual(evidence.actual_viewport,{width:input.cell.width,height:input.cell.height});
    const routeName = new URL(input.url).pathname;
    evidence.active_frame = await frame.evaluate(({route,contentSelector})=>{
      const root=document.documentElement, region=document.querySelector(contentSelector);
      const chrome=Array.from(document.querySelectorAll('.site-nav,[data-mmx-all-tools],#mmx-all-tools,.public-nav,body > nav.nav[aria-label="Main"],.landing-nav'))
        .map(n=>({tag:n.tagName,classes:n.className,id:n.id,display:getComputedStyle(n).display,rectangles:n.getClientRects().length}));
      const rect=region?.getBoundingClientRect();
      return {url:location.href,route:location.pathname,root_flag:root.getAttribute("data-mmx-shared-shell"),
        css_ready:getComputedStyle(root).getPropertyValue("--mmx-shared-shell-css-ready").trim(),
        theme:root.dataset.theme,locale:root.dataset.lang,html_lang:root.lang,
        presentation:{root_background:getComputedStyle(root).backgroundColor,body_background:getComputedStyle(document.body).backgroundColor,body_color:getComputedStyle(document.body).color,content_color:region?getComputedStyle(region).color:null},
        content:{selector:contentSelector,matches:document.querySelectorAll(contentSelector).length,
          text_length:region?.innerText.length||0,width:rect?.width||0,height:rect?.height||0,
          display:region?getComputedStyle(region).display:null,visibility:region?getComputedStyle(region).visibility:null},
        chrome};
    },{route:routeName,contentSelector:routeName==="/macro.html"?"body > .grid":"main.ab-main"});
    const a=evidence.active_frame;
    assert.equal(new URL(a.url).origin,CHILD); assert.equal(a.route,routeName); assert.equal(a.root_flag,"1");
    assert.equal(a.css_ready,"1"); assert.equal(a.theme,input.cell.theme); assert.equal(a.locale,input.cell.locale);
    assert.equal(a.content.matches,1); assert(a.content.text_length>=200 && a.content.width>0 && a.content.height>0);
    assert(a.content.display!=="none" && a.content.visibility==="visible");
    assert(a.chrome.length>0 && a.chrome.every(n=>n.display==="none" && n.rectangles===0),"Actual child chrome must be suppressed");
    evidence.parent_frame = await host.evaluate(n=>{
      const r=n.getBoundingClientRect(),left=Math.max(0,r.left),right=Math.min(innerWidth,r.right),top=Math.max(0,r.top),bottom=Math.min(innerHeight,r.bottom);
      const width=Math.max(0,right-left),height=Math.max(0,bottom-top);
      const ancestry=[];
      for(let e=n;e;e=e.parentElement){const s=getComputedStyle(e);ancestry.push({tag:e.tagName,id:e.id,inert:e.inert,aria_hidden:e.getAttribute("aria-hidden"),hidden:e.hidden,display:s.display,visibility:s.visibility,opacity:s.opacity});}
      const points=[[.5,.5],[.1,.1],[.9,.1],[.1,.9],[.9,.9]];
      return {width:r.width,height:r.height,intersection_ratio:r.width*r.height?width*height/(r.width*r.height):0,
        hit_tests:points.map(([x,y])=>document.elementFromPoint(left+width*x,top+height*y)===n),ancestry,
        parent_busy:document.querySelector("#shared-shell-content")?.getAttribute("aria-busy")};
    });
    assert(evidence.parent_frame.width>0 && evidence.parent_frame.height>0 && evidence.parent_frame.intersection_ratio>=.9);
    assert(evidence.parent_frame.hit_tests.filter(Boolean).length>=3,"Actual iframe is obscured");
    assert.equal(evidence.parent_frame.parent_busy,"false");
    assert(evidence.parent_frame.ancestry.every(n=>!n.inert&&!n.hidden&&n.aria_hidden!=="true"&&n.display!=="none"&&n.visibility==="visible"&&Number(n.opacity)>0),"Actual iframe ancestor hidden or inert");
    applied={theme:a.theme,locale:a.locale};
    const observerFunction=new Function("return ("+input.observer_script+");")();
    assert.equal(typeof observerFunction,"function");
    observed=await frame.evaluate(observerFunction,input.observer_config);
    assert(observed&&Number.isFinite(observed.document_height_px)&&observed.visible_word_count>0,"Canonical observer did not return actual metrics");
    screenshot=await page.screenshot({type:"png",fullPage:false});
    await settle(); await gate.settled();
    for(const route of [routeName,"/shared_shell.css","/shared_shell_bridge.js"])
      assert(evidence.response_bodies.some(r=>new URL(r.url).pathname===route),"Required actual browser response missing: "+route);
    assert(evidence.native_parent_network.some(r=>r.remoteIPAddress==="127.0.0.1"&&r.remotePort===3100&&!r.fromDiskCache&&!r.fromServiceWorker));
    assert.equal(evidence.transport_failures.length,0,"A response identity or transport observation failed");
    verifySource();
  } catch(error) { failure=String(error.stack||error); }
  finally {
    try { await cleanup(); } catch(error) { failure=(failure||"")+" Cleanup failed: "+String(error.stack||error); }
  }
  if(evidence.transport_failures.length) failure=(failure||"")+" Transport failures: "+evidence.transport_failures.join("; ");
  evidence.completed_at=new Date().toISOString();
  evidence.pass = !failure;
  evidence.request_count=requests;
  evidence.payload_bytes_total=bytesTotal;
  const observation={cell_id:input.cell.cell_id,loaded:!failure,error:failure,observed,
    console_errors:evidence.console_errors,failed_responses:evidence.failed_responses,
    request_count:requests,payload_bytes_total:bytesTotal,applied_theme:applied.theme||null,applied_locale:applied.locale||null,
    applied_force_state:null,screenshot_sha256:screenshot?hash(screenshot):null};
  if(screenshot) fs.writeFileSync(input.shot,screenshot,{flag:"wx"});
  fs.writeFileSync(input.evidence,JSON.stringify({observation,evidence},null,2)+"\n",{flag:"wx"});
  process.stdout.write(JSON.stringify({observation,screenshot_path:screenshot?input.shot:null,evidence_path:input.evidence})+"\n");
  if(failure) process.exitCode=1;
}
main().catch(error=>{process.stderr.write(String(error.stack||error)+"\n");process.exitCode=2;});
